# Azure Services Integration - Production Configuration

Bu konfigürasyon, Bitwisers trading platformu için production-grade Azure services entegrasyonu sağlar.

## İçindekiler

- [Azure Database for PostgreSQL](#azure-database-for-postgresql)
- [Azure Cosmos DB](#azure-cosmos-db)
- [Azure Redis Cache](#azure-redis-cache)
- [Azure Container Registry](#azure-container-registry)
- [Azure Application Insights](#azure-application-insights)
- [Azure Key Vault](#azure-key-vault)
- [Azure Event Hubs](#azure-event-hubs)

## Genel Kurulum

### Önkoşullar

```bash
# Terraform CLI
terraform --version

# Azure CLI
az --version

# Docker
docker --version
```

### Backend Konfigürasyonu

Her servis için backend storage ve state management:

```hcl
# her_servis/main.tf'e eklenecek
terraform {
  backend "azurerm" {
    resource_group_name  = "bitwisers-terraform-rg"
    storage_account_name = "bitwisersterrafstate"
    container_name       = "tfstate"
    key                  = "bitwisers-azure.tfstate"
  }
}
```

## Azure Database for PostgreSQL

### Özellikler
- **TimescaleDB Replacement**: Time-series data için optimized
- **High Availability**: Zone-redundant deployment
- **Read Replica**: Scaling için read-only replica
- **Private Endpoint**: Secure network access
- **Extensions**: TimescaleDB, pg_stat_statements, UUID-OSSP

### Connection String
```bash
# Connection string format
postgresql://dbadmin:${password}@${fqdn}:5432/postgres

# Örnek
postgresql://dbadmin:securePassword123@bitwisers-postgres-prod.postgres.database.azure.com:5432/postgres
```

### Docker Compose
```yaml
services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: bitwisers
      POSTGRES_USER: dbadmin
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    command: >
      postgres -c shared_preload_libraries=timescaledb
      -c max_connections=200
      -c shared_buffers=256MB
    networks:
      - azure_network

  postgres-replica:
    image: postgres:15
    environment:
      POSTGRES_DB: bitwisers
      POSTGRES_USER: dbadmin
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
    command: >
      postgres -c max_connections=200
    networks:
      - azure_network
```

### SQL Örnekleri
```sql
-- TimescaleDB extension enable
CREATE EXTENSION IF NOT EXISTS timescaledb;

-- Time-series table oluşturma
CREATE TABLE trading_signals (
    time TIMESTAMPTZ NOT NULL,
    symbol TEXT NOT NULL,
    signal_type TEXT NOT NULL,
    signal_value DOUBLE PRECISION NOT NULL,
    confidence DOUBLE PRECISION NOT NULL,
    metadata JSONB
);

-- Hypertable convert
SELECT create_hypertable('trading_signals', 'time', chunk_time_interval => INTERVAL '1 day');

-- Time-based partition
CREATE TABLE order_history (
    time TIMESTAMPTZ NOT NULL,
    order_id TEXT NOT NULL,
    symbol TEXT NOT NULL,
    quantity DOUBLE PRECISION NOT NULL,
    price DOUBLE PRECISION NOT NULL,
    side TEXT NOT NULL
);
SELECT create_hypertable('order_history', 'time', chunk_time_interval => INTERVAL '1 hour');
```

## Azure Cosmos DB

### Özellikler
- **Feature Store**: ML feature storage için optimized
- **Multi-region Write**: High availability
- **Time-series Data**: TTL ve partitioning
- **Schema Flexibility**: JSON document storage

### Connection String
```bash
# MongoDB API
mongodb://${account}:${key}@${account}.mongo.cosmos.azure.com:10255/?ssl=true&replicaSet=globaldb

# Core SQL API
AccountEndpoint=https://${account}.documents.azure.com:443/;AccountKey=${key};Database=feature-store
```

### Docker Compose
```yaml
services:
  cosmos-emulator:
    image: mcr.microsoft.com/cosmosdb/linux/azure-cosmos-emulator
    ports:
      - "8081:8081"
      - "10250:10250"
      - "10251:10251"
      - "10252:10252"
    environment:
      AZURE_COSMOS_EMULATOR_PARTITION_COUNT: 10
      AZURE_COSMOS_EMULATOR_ENABLE_DATA_PERSISTENCE: true
    volumes:
      - cosmos_data:/tmp/cosmosdbdata
    networks:
      - azure_network
```

### Data Model
```json
{
  "id": "feature-btc-rsi-5min",
  "timestamp": "2025-01-15T10:30:00Z",
  "symbol": "BTCUSDT",
  "feature_type": "technical_indicator",
  "feature_name": "rsi",
  "timeframe": "5m",
  "value": 65.432,
  "metadata": {
    "calculation_window": 14,
    "market_regime": "bullish",
    "algorithm_version": "v2.1"
  }
}
```

## Azure Redis Cache

### Özellikler
- **Premium Tier**: High performance
- **Multiple Instances**: Main, Session, Real-time
- **AOF Persistence**: Data durability
- **Private Endpoint**: Secure access

### Connection String
```bash
# Redis SSL
rediss://:${password}@${hostname}:6380

# Regular Redis
redis://${hostname}:6379

# Örnek
rediss://:securePassword123@bitwisers-redis-prod.redis.cache.windows.net:6380
```

### Docker Compose
```yaml
services:
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    command: >
      redis-server
      --maxmemory 512mb
      --maxmemory-policy allkeys-lru
      --appendonly yes
    volumes:
      - redis_data:/data
    networks:
      - azure_network

  redis-session:
    image: redis:7-alpine
    ports:
      - "6380:6379"
    command: >
      redis-server
      --maxmemory 256mb
      --maxmemory-policy volatile-lru
    networks:
      - azure_network
```

### Python Client
```python
import redis
import json

# Redis connection
r = redis.Redis(
    host='bitwisers-redis-prod.redis.cache.windows.net',
    port=6380,
    password='your-password',
    ssl=True,
    decode_responses=True
)

# Time-series data storage
def store_trading_signal(signal):
    key = f"signal:{signal['symbol']}:{signal['timestamp']}"
    r.setex(key, 3600, json.dumps(signal))

# Real-time data cache
def cache_market_data(symbol, data):
    key = f"market:{symbol}"
    r.setex(key, 60, json.dumps(data))

# Session data
def store_session(session_id, session_data):
    key = f"session:{session_id}"
    r.setex(key, 86400, json.dumps(session_data))
```

## Azure Container Registry

### Özellikler
- **Premium Tier**: Geo-replication
- **Security**: Content trust, vulnerability scanning
- **Automation**: ACR Tasks for CI/CD
- **Private Endpoint**: Secure access

### Connection String
```bash
# Docker login
docker login bitwisersacr.azurecr.io -u admin -p your-password

# ACR URL
bitwisersacr.azurecr.io
```

### Docker Compose
```yaml
services:
  registry:
    image: registry:2
    ports:
      - "5000:5000"
    environment:
      REGISTRY_AUTH: htpasswd
      REGISTRY_AUTH_HTPASSWD_REALM: Registry Realm
      REGISTRY_AUTH_HTPASSWD_PATH: /auth/htpasswd
      REGISTRY_STORAGE_FILESYSTEM_ROOTDIRECTORY: /var/lib/registry
    volumes:
      - registry_data:/var/lib/registry
      - ./auth:/auth
    networks:
      - azure_network
```

### CI/CD Pipeline
```yaml
# .github/workflows/docker-build.yml
name: Build and Push to ACR

on:
  push:
    branches: [main]

jobs:
  build:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Login to ACR
      uses: azure/docker-login@v1
      with:
        login-server: ${{ secrets.ACR_LOGIN_SERVER }}
        username: ${{ secrets.ACR_USERNAME }}
        password: ${{ secrets.ACR_PASSWORD }}
    
    - name: Build and push
      uses: docker/build-push-action@v2
      with:
        context: .
        push: true
        tags: |
          ${{ secrets.ACR_LOGIN_SERVER }}/bitwisers:${{ github.sha }}
          ${{ secrets.ACR_LOGIN_SERVER }}/bitwisers:latest
```

## Azure Application Insights

### Özellikler
- **Real-time Monitoring**: Live metrics
- **Smart Detection**: Anomaly detection
- **Workbooks**: Custom dashboards
- **Alert Rules**: Proactive notifications

### Connection String
```bash
# Instrumentation key
InstrumentationKey=your-instrumentation-key

# Connection string
InstrumentationKey=your-key;IngestionEndpoint=https://westeurope-5.in.applicationinsights.azure.com/;LiveEndpoint=https://westeurope.livediagnostics.monitor.azure.com/
```

### Python Integration
```python
from opencensus.ext.azure.trace_exporter import AzureExporter
from opencensus.trace import tracer as tracer_module
from opencensus.trace.tracers import context_tracer

# Application Insights setup
tracer = context_tracer.Tracer(
    exporter=AzureExporter(
        connection_string="InstrumentationKey=your-key"
    )
)

# Custom metrics
def track_trading_metric(symbol, metric_value, metric_type):
    with tracer.span(name=f"trading_{metric_type}") as span:
        span.add_annotation(f"Processing {metric_type} for {symbol}")
        span.add_attribute("symbol", symbol)
        span.add_attribute("metric_value", metric_value)

# Custom events
def track_trading_event(event_name, properties=None):
    import logging
    logging.info(f"Tracking event: {event_name}", extra=properties)
```

### Custom Workbooks
```json
{
  "version": "NotebookGroup/1.0",
  "items": [
    {
      "type": 1,
      "content": {
        "json": "{\"version\":\"KqlItem/1.0\",\"query\":\"union * | where _time > ago(1d) | summarize count() by bin(_time, 1h), tostring(cloud_RoleInstance) | render timechart\",\"queryType\":0,\"id\":\"trading-volume-chart\"}"
      },
      "name": "trading-volume-chart"
    }
  ]
}
```

## Azure Key Vault

### Özellikler
- **RBAC Authorization**: Secure access control
- **Private Endpoint**: Network isolation
- **Soft Delete**: Data protection
- **Audit Logging**: Compliance tracking

### Connection String
```bash
# Key Vault URL
https://bitwisers-keyvault-prod.vault.azure.net/

# Secret example
az keyvault secret show --name trading-api-key --vault-name bitwisers-keyvault-prod
```

### Python Integration
```python
from azure.keyvault.secrets import SecretClient
from azure.identity import DefaultAzureCredential

# Key Vault client
credential = DefaultAzureCredential()
client = SecretClient(vault_url="https://bitwisers-keyvault-prod.vault.azure.net", credential=credential)

# Retrieve secrets
def get_secret(secret_name):
    secret = client.get_secret(secret_name)
    return secret.value

# Set secrets (admin only)
def set_secret(secret_name, secret_value):
    secret = client.set_secret(secret_name, secret_value)
    return secret.id

# Usage
trading_api_key = get_secret("trading-api-key")
cosmos_connection = get_secret("cosmos-db-connection-string")
```

### Secrets Management
```python
# Secret rotation example
import asyncio
from datetime import datetime, timedelta

class SecretRotationManager:
    def __init__(self, key_vault_client):
        self.client = key_vault_client
        self.rotation_schedule = {
            'api-keys': 30,      # 30 days
            'certificates': 90,  # 90 days
            'database-credentials': 60  # 60 days
        }
    
    async def rotate_secrets(self):
        """Rotate secrets based on schedule"""
        for secret_prefix, rotation_days in self.rotation_schedule.items():
            secrets = self.client.list_properties_of_secrets()
            
            for secret in secrets:
                if secret.name.startswith(secret_prefix):
                    last_updated = secret.updated_on or secret.created_on
                    days_since_update = (datetime.utcnow() - last_updated).days
                    
                    if days_since_update >= rotation_days:
                        await self.rotate_secret(secret.name)

    async def rotate_secret(self, secret_name):
        """Rotate individual secret"""
        current_secret = self.client.get_secret(secret_name)
        new_secret = self.generate_new_secret(current_secret.value)
        
        # Store new version
        self.client.set_secret(secret_name, new_secret)
        
        # Log rotation event
        print(f"Rotated secret: {secret_name}")
```

## Azure Event Hubs

### Özellikler
- **Kafka Protocol**: Kafka-compatible API
- **Premium Tier**: Low latency, high throughput
- **Schema Registry**: Avro schema management
- **Capture**: Azure Storage integration

### Connection String
```bash
# Event Hubs connection string
Endpoint=sb://bitwisers-eventhubs-prod.servicebus.windows.net/;SharedAccessKeyName=trading-events-manage;SharedAccessKey=your-key

# Kafka bootstrap servers
bitwisers-eventhubs-prod.servicebus.windows.net:9093
```

### Python Kafka Client
```python
from azure.eventhub import EventHubConsumerClient, EventData
from azure.eventhub.exceptions import EventHubError
import json

# Kafka-compatible client
connection_str = "Endpoint=sb://bitwisers-eventhubs-prod.servicebus.windows.net/;SharedAccessKeyName=trading-events-manage;SharedAccessKey=your-key"
consumer_group = "$Default"
eventhub_name = "trading-events"

# Event consumer
consumer = EventHubConsumerClient.from_connection_string(
    conn_str=connection_str,
    consumer_group=consumer_group,
    eventhub_name=eventhub_name
)

async def on_event(partition_context, event):
    try:
        data = json.loads(event.body_as_str())
        
        # Process trading event
        process_trading_event(data)
        
        # Update checkpoint
        await partition_context.update_checkpoint(event)
        
    except Exception as e:
        print(f"Error processing event: {e}")

# Start consuming
consumer.receive(
    on_event=on_event,
    starting_position="-1",  # Start from latest
)

# Event producer
from azure.eventhub import EventHubProducerClient

producer = EventHubProducerClient.from_connection_string(
    conn_str=connection_str,
    eventhub_name=eventhub_name
)

def send_trading_event(event_data):
    event_batch = producer.create_batch()
    event_batch.add(EventData(json.dumps(event_data)))
    producer.send_batch(event_batch)
```

### Schema Registry Integration
```python
# Avro schema registration
schema_definition = """
{
  "type": "record",
  "name": "TradingEvent",
  "namespace": "com.bitwisers.trading",
  "fields": [
    {"name": "timestamp", "type": "long"},
    {"name": "symbol", "type": "string"},
    {"name": "event_type", "type": "string"},
    {"name": "price", "type": "double"},
    {"name": "volume", "type": "double"},
    {"name": "metadata", "type": ["null", {"type": "map", "values": "string"}]}
  ]
}
"""

# Register schema
from azure.schemaregistry import SchemaRegistryClient
from azure.identity import DefaultAzureCredential

credential = DefaultAzureCredential()
schema_client = SchemaRegistryClient(
    endpoint="bitwisers-eventhubs-prod.servicebus.windows.net",
    credential=credential
)

schema = schema_client.register_schema(
    group_name="trading-schemas",
    name="TradingEvent",
    schema=schema_definition,
    format="Avro"
)
```

## Güvenlik Best Practices

### Network Security
1. **Private Endpoints**: Tüm servisler private endpoint kullanmalı
2. **NSG Rules**: Sadece gerekli portlar açık olmalı
3. **VNET Integration**: Servisler private network'te çalışmalı

### Access Control
1. **RBAC**: Azure AD ile role-based access
2. **Managed Identity**: Service principal yerine managed identity
3. **Just-in-time Access**: Kritik işlemler için JIT access

### Data Protection
1. **Encryption**: Tüm data at-rest ve in-transit encrypted
2. **Key Rotation**: Secrets düzenli rotasyonu
3. **Audit Logging**: Tüm access'ler loglanmalı

### Monitoring
1. **Application Insights**: Real-time monitoring
2. **Alert Rules**: Proactive alerting
3. **Log Analytics**: Centralized logging

## Deployment Pipeline

### Terraform Pipeline
```yaml
# .github/workflows/terraform.yml
name: Terraform Deploy

on:
  push:
    paths:
      - 'azure/**'
      - 'terraform/**'

jobs:
  terraform:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Setup Terraform
      uses: hashicorp/setup-terraform@v1
      with:
        terraform_version: 1.0.0
    
    - name: Azure Login
      uses: azure/login@v1
      with:
        creds: ${{ secrets.AZURE_CREDENTIALS }}
    
    - name: Terraform Init
      run: |
        cd azure/database
        terraform init -backend-config="environment=${{ github.ref_name }}"
    
    - name: Terraform Plan
      run: |
        cd azure/database
        terraform plan -out=tfplan
    
    - name: Terraform Apply
      run: |
        cd azure/database
        terraform apply -auto-approve tfplan
```

## Cost Optimization

### Resource Sizing
- **PostgreSQL**: GP_Standard_D4s_v3 (4 vCPU, 16GB RAM)
- **Cosmos DB**: 400 RU/s per container
- **Redis**: Premium_P1 (1GB cache)
- **Event Hubs**: 5-10 throughput units

### Auto-scaling
- **Cosmos DB**: Auto-scale with RU/s limits
- **Event Hubs**: Auto-inflate enabled
- **Redis**: Monitor memory usage

## Troubleshooting

### Common Issues
1. **Connection Timeouts**: Check firewall rules
2. **Authentication Failures**: Verify RBAC assignments
3. **Performance Issues**: Check resource allocation
4. **Data Consistency**: Monitor replication status

### Monitoring Queries
```kusto
// Application Insights - Failed requests
requests
| where success == false
| summarize count() by bin(timestamp, 1h), cloud_RoleInstance
| render timechart

// Log Analytics - PostgreSQL performance
AzureDiagnostics
| where ResourceType == "POSTGRESQLSERVERS"
| where Category == "QueryStoreRuntimeStatistics"
| summarize avg_cpu_percent = avg(todouble(cpu_percent)) by bin(TimeGenerated, 5m)
| render timechart
```

## Sonuç

Bu konfigürasyon, production-grade Azure services entegrasyonu için gerekli tüm bileşenleri sağlar. Her servis için:

1. **High Availability**: Zone-redundant deployment
2. **Security**: Private endpoints ve RBAC
3. **Monitoring**: Application Insights entegrasyonu
4. **Cost Optimization**: Auto-scaling ve right-sizing
5. **Compliance**: Audit logging ve data protection

Deployment öncesi:
- Environment variables set edilmeli
- Secrets Key Vault'ta güvenli şekilde saklanmalı
- RBAC permissions doğru atanmalı
- Network access rules configure edilmeli
