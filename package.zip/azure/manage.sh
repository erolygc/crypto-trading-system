#!/bin/bash

# Azure Services Management Script
# Production-grade Azure services integration management

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Project root directory
PROJECT_ROOT="/workspace/azure"

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}\n"
}

# Function to check prerequisites
check_prerequisites() {
    print_header "Checking Prerequisites"
    
    # Check if running from correct directory
    if [[ ! -f "$PROJECT_ROOT/README.md" ]]; then
        print_error "Please run this script from the correct directory"
        exit 1
    fi
    
    # Check required tools
    local tools=("terraform" "az" "docker" "docker-compose" "curl" "jq")
    for tool in "${tools[@]}"; do
        if command -v "$tool" &> /dev/null; then
            print_status "$tool is installed"
        else
            print_error "$tool is not installed. Please install it first."
            exit 1
        fi
    done
    
    # Check Azure login
    if ! az account show &> /dev/null; then
        print_error "Please login to Azure first: az login"
        exit 1
    fi
    
    print_status "All prerequisites are met"
}

# Function to show help
show_help() {
    echo "Azure Services Management Script"
    echo ""
    echo "Usage: $0 [COMMAND] [SERVICE] [OPTIONS]"
    echo ""
    echo "Commands:"
    echo "  init                    Initialize all Azure services"
    echo "  deploy                  Deploy all services to Azure"
    echo "  destroy                 Destroy all Azure services"
    echo "  status                  Show status of all services"
    echo "  logs                    Show logs of all services"
    echo "  backup                  Backup all service data"
    echo "  restore                 Restore service data"
    echo "  test                    Run tests for all services"
    echo "  health-check           Perform health check"
    echo ""
    echo "Services:"
    echo "  all                    All services"
    echo "  postgres               Azure Database for PostgreSQL"
    echo "  cosmos-db              Azure Cosmos DB"
    echo "  redis                  Azure Redis Cache"
    echo "  container-registry     Azure Container Registry"
    echo "  application-insights   Azure Application Insights"
    echo "  key-vault              Azure Key Vault"
    echo "  event-hubs             Azure Event Hubs"
    echo ""
    echo "Options:"
    echo "  --environment          Environment name (dev, staging, prod)"
    echo "  --location             Azure region (default: westeurope)"
    echo "  --dry-run              Show what would be done without executing"
    echo "  --force                Force operation without confirmation"
    echo ""
    echo "Examples:"
    echo "  $0 init all --environment prod"
    echo "  $0 deploy postgres --force"
    echo "  $0 status all"
    echo "  $0 health-check"
}

# Function to initialize Terraform backend
init_terraform_backend() {
    local service=$1
    local environment=$2
    
    print_status "Initializing Terraform for $service"
    
    cd "$PROJECT_ROOT/$service"
    
    if [[ ! -d ".terraform" ]]; then
        terraform init \
            -backend-config="environment=$environment" \
            -backend-config="resource_group_name=bitwisers-terraform-rg" \
            -backend-config="storage_account_name=bitwisersterrafstate" \
            -backend-config="container_name=tfstate"
    else
        terraform init -upgrade
    fi
}

# Function to plan Terraform deployment
plan_deployment() {
    local service=$1
    local environment=$2
    
    print_header "Planning deployment for $service"
    
    cd "$PROJECT_ROOT/$service"
    
    terraform plan \
        -var="environment=$environment" \
        -var="location=westeurope" \
        -out="tfplan-$environment"
    
    print_status "Deployment plan created for $service"
}

# Function to apply Terraform deployment
apply_deployment() {
    local service=$1
    local environment=$2
    local force=$3
    
    print_header "Applying deployment for $service"
    
    cd "$PROJECT_ROOT/$service"
    
    if [[ "$force" == "true" ]] || [[ -f "tfplan-$environment" ]]; then
        terraform apply -auto-approve "tfplan-$environment"
        print_status "Deployment completed for $service"
    else
        print_warning "Please run plan first or use --force flag"
    fi
}

# Function to destroy deployment
destroy_deployment() {
    local service=$1
    local environment=$2
    local force=$3
    
    print_header "Destroying deployment for $service"
    
    if [[ "$force" != "true" ]]; then
        read -p "Are you sure you want to destroy $service? This action cannot be undone. (y/N): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            print_status "Destruction cancelled"
            return
        fi
    fi
    
    cd "$PROJECT_ROOT/$service"
    terraform destroy -auto-approve
    print_status "Destruction completed for $service"
}

# Function to get service status
get_service_status() {
    local service=$1
    
    print_header "Status for $service"
    
    cd "$PROJECT_ROOT/$service"
    
    if terraform show &> /dev/null; then
        terraform show -json | jq '.values.root_module.resources[] | select(.values.state != null) | {type: .type, name: .name, state: .values.state}' 2>/dev/null || terraform show
    else
        print_warning "No deployment found for $service"
    fi
}

# Function to show service logs
show_service_logs() {
    local service=$1
    local environment=$2
    
    print_header "Logs for $service"
    
    case $service in
        "postgres")
            print_status "Checking PostgreSQL logs..."
            az monitor log-analytics query \
                --workspace $(terraform output -raw log_analytics_workspace_id 2>/dev/null || echo "") \
                --analytics-query "PostgreSQLLogs | where TimeGenerated > ago(1h) | order by TimeGenerated desc | limit 50" \
                --output table 2>/dev/null || print_warning "Could not retrieve logs"
            ;;
        "cosmos-db")
            print_status "Checking Cosmos DB logs..."
            az monitor log-analytics query \
                --workspace $(terraform output -raw log_analytics_workspace_id 2>/dev/null || echo "") \
                --analytics-query "DataPlaneRequests | where TimeGenerated > ago(1h) | order by TimeGenerated desc | limit 50" \
                --output table 2>/dev/null || print_warning "Could not retrieve logs"
            ;;
        "redis")
            print_status "Checking Redis metrics..."
            az monitor metrics list \
                --resource $(terraform output -raw redis_id 2>/dev/null || echo "") \
                --metric "used_memory,connected_clients" \
                --interval PT5M \
                --output table 2>/dev/null || print_warning "Could not retrieve metrics"
            ;;
        *)
            print_warning "Log retrieval not implemented for $service"
            ;;
    esac
}

# Function to perform health check
perform_health_check() {
    print_header "Performing Health Check"
    
    local services=("postgres" "cosmos-db" "redis" "container-registry" "application-insights" "key-vault" "event-hubs")
    local healthy=0
    local total=${#services[@]}
    
    for service in "${services[@]}"; do
        print_status "Checking $service..."
        
        case $service in
            "postgres")
                if [[ -f "$PROJECT_ROOT/$service/terraform.tfstate" ]]; then
                    local conn_string=$(terraform output -raw postgresql_connection_string 2>/dev/null)
                    if [[ -n "$conn_string" ]]; then
                        if pg_isready -h $(echo "$conn_string" | cut -d'@' -f2 | cut -d':' -f1) -p 5432 &>/dev/null; then
                            print_status "$service: HEALTHY"
                            ((healthy++))
                        else
                            print_error "$service: UNHEALTHY"
                        fi
                    else
                        print_warning "$service: Not configured"
                    fi
                else
                    print_warning "$service: Not deployed"
                fi
                ;;
            "redis")
                if [[ -f "$PROJECT_ROOT/$service/terraform.tfstate" ]]; then
                    local redis_host=$(terraform output -raw redis_primary_host 2>/dev/null)
                    if [[ -n "$redis_host" ]]; then
                        if redis-cli -h "$redis_host" ping &>/dev/null; then
                            print_status "$service: HEALTHY"
                            ((healthy++))
                        else
                            print_error "$service: UNHEALTHY"
                        fi
                    else
                        print_warning "$service: Not configured"
                    fi
                else
                    print_warning "$service: Not deployed"
                fi
                ;;
            *)
                if [[ -f "$PROJECT_ROOT/$service/terraform.tfstate" ]]; then
                    print_status "$service: DEPLOYED"
                    ((healthy++))
                else
                    print_warning "$service: NOT DEPLOYED"
                fi
                ;;
        esac
    done
    
    print_header "Health Check Summary"
    echo "Healthy services: $healthy/$total"
    
    if [[ $healthy -eq $total ]]; then
        print_status "All services are healthy!"
        return 0
    else
        print_warning "Some services are not healthy"
        return 1
    fi
}

# Function to backup service data
backup_service_data() {
    local service=$1
    local environment=$2
    
    print_header "Backing up $service data"
    
    case $service in
        "postgres")
            print_status "Backing up PostgreSQL database..."
            local backup_file="backups/postgres-$(date +%Y%m%d_%H%M%S).sql"
            mkdir -p "backups"
            
            if [[ -f "$PROJECT_ROOT/$service/terraform.tfstate" ]]; then
                local conn_string=$(terraform output -raw postgresql_connection_string 2>/dev/null)
                if [[ -n "$conn_string" ]]; then
                    PGPASSWORD=${conn_string##*:} pg_dump -h ${conn_string%@*} -U dbadmin -d postgres > "$backup_file"
                    print_status "Database backed up to $backup_file"
                fi
            fi
            ;;
        "cosmos-db")
            print_status "Exporting Cosmos DB data..."
            local backup_file="backups/cosmos-export-$(date +%Y%m%d_%H%M%S).json"
            mkdir -p "backups"
            
            if [[ -f "$PROJECT_ROOT/$service/terraform.tfstate" ]]; then
                # Use Azure CLI to export Cosmos DB data
                az cosmosdb sql container list \
                    --account-name $(terraform output -raw cosmos_account_name 2>/dev/null) \
                    --resource-group $(terraform output -raw resource_group_name 2>/dev/null) \
                    --database-name feature-store \
                    --query "[].id" \
                    --output tsv | while read container; do
                        az cosmosdb sql container show \
                            --account-name $(terraform output -raw cosmos_account_name 2>/dev/null) \
                            --resource-group $(terraform output -raw resource_group_name 2>/dev/null) \
                            --database-name feature-store \
                            --name "$container" \
                            --output json >> "$backup_file"
                    done
                print_status "Cosmos DB metadata backed up to $backup_file"
            fi
            ;;
        *)
            print_warning "Backup not implemented for $service"
            ;;
    esac
}

# Function to run tests
run_tests() {
    local service=$1
    
    print_header "Running tests for $service"
    
    case $service in
        "postgres")
            print_status "Running PostgreSQL connection tests..."
            cd "$PROJECT_ROOT/$service"
            if [[ -f "tests/test_postgres.py" ]]; then
                python tests/test_postgres.py
            else
                print_warning "No tests found for PostgreSQL"
            fi
            ;;
        "cosmos-db")
            print_status "Running Cosmos DB tests..."
            cd "$PROJECT_ROOT/$service"
            if [[ -f "tests/test_cosmos.py" ]]; then
                python tests/test_cosmos.py
            else
                print_warning "No tests found for Cosmos DB"
            fi
            ;;
        "redis")
            print_status "Running Redis tests..."
            cd "$PROJECT_ROOT/$service"
            if [[ -f "tests/test_redis.py" ]]; then
                python tests/test_redis.py
            else
                print_warning "No tests found for Redis"
            fi
            ;;
        *)
            print_warning "Tests not implemented for $service"
            ;;
    esac
}

# Main function
main() {
    local command=$1
    local service=$2
    local environment="prod"
    local force="false"
    local dry_run="false"
    
    # Parse additional options
    shift 2
    while [[ $# -gt 0 ]]; do
        case $1 in
            --environment)
                environment="$2"
                shift 2
                ;;
            --location)
                location="$2"
                shift 2
                ;;
            --force)
                force="true"
                shift
                ;;
            --dry-run)
                dry_run="true"
                shift
                ;;
            *)
                print_error "Unknown option: $1"
                exit 1
                ;;
        esac
    done
    
    # Set default location
    location="${location:-westeurope}"
    
    # Handle different commands
    case $command in
        "init")
            check_prerequisites
            
            if [[ "$service" == "all" ]]; then
                local services=("database" "cosmos-db" "redis" "container-registry" "application-insights" "key-vault" "event-hubs")
                for srv in "${services[@]}"; do
                    init_terraform_backend "$srv" "$environment"
                done
            else
                init_terraform_backend "$service" "$environment"
            fi
            ;;
        "deploy")
            if [[ "$service" == "all" ]]; then
                local services=("database" "cosmos-db" "redis" "container-registry" "application-insights" "key-vault" "event-hubs")
                for srv in "${services[@]}"; do
                    plan_deployment "$srv" "$environment"
                    apply_deployment "$srv" "$environment" "$force"
                done
            else
                plan_deployment "$service" "$environment"
                apply_deployment "$service" "$environment" "$force"
            fi
            
            print_status "Deployment completed!"
            perform_health_check
            ;;
        "destroy")
            if [[ "$service" == "all" ]]; then
                local services=("database" "cosmos-db" "redis" "container-registry" "application-insights" "key-vault" "event-hubs")
                for srv in "${services[@]}"; do
                    destroy_deployment "$srv" "$environment" "$force"
                done
            else
                destroy_deployment "$service" "$environment" "$force"
            fi
            
            print_status "Destruction completed!"
            ;;
        "status")
            if [[ "$service" == "all" ]]; then
                local services=("database" "cosmos-db" "redis" "container-registry" "application-insights" "key-vault" "event-hubs")
                for srv in "${services[@]}"; do
                    get_service_status "$srv"
                done
            else
                get_service_status "$service"
            fi
            ;;
        "logs")
            if [[ "$service" == "all" ]]; then
                local services=("database" "cosmos-db" "redis" "container-registry" "application-insights" "key-vault" "event-hubs")
                for srv in "${services[@]}"; do
                    show_service_logs "$srv" "$environment"
                done
            else
                show_service_logs "$service" "$environment"
            fi
            ;;
        "backup")
            if [[ "$service" == "all" ]]; then
                local services=("postgres" "cosmos-db" "redis")
                for srv in "${services[@]}"; do
                    backup_service_data "$srv" "$environment"
                done
            else
                backup_service_data "$service" "$environment"
            fi
            ;;
        "test")
            if [[ "$service" == "all" ]]; then
                local services=("postgres" "cosmos-db" "redis")
                for srv in "${services[@]}"; do
                    run_tests "$srv"
                done
            else
                run_tests "$service"
            fi
            ;;
        "health-check")
            perform_health_check
            ;;
        "help"|"-h"|"--help")
            show_help
            ;;
        *)
            print_error "Unknown command: $command"
            show_help
            exit 1
            ;;
    esac
}

# Script entry point
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    if [[ $# -eq 0 ]]; then
        show_help
        exit 1
    fi
    
    main "$@"
fi
