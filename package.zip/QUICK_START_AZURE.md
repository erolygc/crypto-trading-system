# 🚀 Crypto Trading System - Azure Quick Start Guide

## 📋 Hızlı Başlangıç

Bu rehber, kripto trading sisteminizi Azure'da **tek komutla** kurmanız için hazırlanmıştır.

## 🎯 Ön Gereksinimler

### 1. Azure CLI Kurulumu
```bash
# Windows (PowerShell)
Invoke-WebRequest -Uri https://aka.ms/installazurecliwindows -OutFile .\AzureCLI.msi; Start-Process msiexec.exe -Wait -ArgumentList '/I AzureCLI.msi /quiet'

# macOS
brew install azure-cli

# Linux (Ubuntu/Debian)
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash
```

### 2. Diğer Araçlar
```bash
# kubectl
az aks install-cli

# Docker (Ubuntu)
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Git
sudo apt install git  # Ubuntu/Debian
brew install git      # macOS
```

### 3. Azure Hesabı
- Azure hesabınızı oluşturun: https://azure.microsoft.com/free/
- Subscription aktifleştirin

## ⚡ Tek Komutla Kurulum

### Production Deployment
```bash
# Repository'yi klonlayın
git clone <repository-url>
cd crypto-trading-system

# Master deployment script'i çalıştırın
chmod +x azure-deployment-master.sh
./azure-deployment-master.sh production eastus
```

### Development Deployment
```bash
./azure-deployment-master.sh development westus2
```

## 📊 Deployment Sonrası Erişim

Deployment tamamlandıktan sonra:

| Service | URL | Description |
|---------|-----|-------------|
| **Smart Order Router** | `http://<LOAD_BALANCER_IP>:8080` | Ana trading API |
| **Performance Monitor** | `http://<LOAD_BALANCER_IP>:3000` | Gerçek zamanlı monitoring |
| **Grafana Dashboard** | `http://<LOAD_BALANCER_IP>:3030` | Grafana dashboard |
| **MLflow Tracking** | `http://<LOAD_BALANCER_IP>:5000` | ML experiments |

## 🛠️ Geliştirme Ortamı (VS Code)

### 1. Workspace'i Açın
```bash
# VS Code'da workspace'i açın
code .
```

### 2. Extensions Kurulumu
VS Code extensions otomatik olarak önerilecek:
- Python
- Docker
- Kubernetes
- GitLens

### 3. Development Server Başlatma
```bash
# Virtual environment oluştur
python -m venv venv
source venv/bin/activate  # Linux/macOS
# veya
venv\Scripts\activate     # Windows

# Dependencies yükle
pip install -r requirements-dev.txt

# Workspace setup
bash setup_workspace.sh
```

## 🔧 Konfigürasyon

### Environment Variables
```bash
# Azure services bilgilerini ayarlayın
export AZURE_CLIENT_ID="your-client-id"
export AZURE_CLIENT_SECRET="your-client-secret"
export AZURE_TENANT_ID="your-tenant-id"

# Database bağlantıları
export POSTGRES_CONNECTION_STRING="your-connection-string"
export COSMOS_DB_CONNECTION_STRING="your-cosmos-connection"
```

### API Keys
Azure Key Vault'e güvenli şekilde saklayın:
```bash
# Binance API
az keyvault secret set \
  --vault-name <keyvault-name> \
  --name binance-api-key \
  --value "your-binance-api-key"

# Diğer API keys...
```

## 📈 Monitoring ve Alerting

### Grafana Dashboard Erişimi
1. `http://<GRAFANA_IP>:3030` adresine gidin
2. Default credentials: `admin/admin`
3. Trading dashboard'larını görüntüleyin

### Prometheus Metrics
```bash
# Metrics'leri kontrol edin
kubectl port-forward svc/prometheus 9090:9090 -n monitoring
# http://localhost:9090 adresinde Prometheus UI
```

## 🔄 CI/CD Pipeline

### GitHub Actions
1. Repository'de GitHub Actions'ı aktifleştirin
2. Secrets'ları GitHub'da ayarlayın:
   - `AZURE_CLIENT_ID`
   - `AZURE_CLIENT_SECRET`
   - `AZURE_TENANT_ID`
   - `ACR_REGISTRY`

### Manual Deployment
```bash
# Production'a deploy
gh workflow run cd.yml -f environment=prod

# Rollback
gh workflow run rollback.yml -f environment=prod -f emergency=true
```

## 🧪 Test ve Validation

### Health Check
```bash
# Tüm servislerin sağlığını kontrol edin
kubectl get pods -n trading-system
kubectl get services -n trading-system

# Manual health check
./scripts/health-check.sh
```

### Load Testing
```bash
# Simple load test
kubectl run load-test --image=loadimpact/k6 --rm -i --restart=Never -- \
  run - <<< "http.get('http://smart-order-router:8080/health')"
```

## 🔒 Güvenlik

### SSL Sertifikaları
```bash
# Let's Encrypt ile SSL kurulumu
./scripts/certificate-renewal.sh install
```

### Key Vault Entegrasyonu
```bash
# Kubernetes'te Key Vault CSI Driver aktifleştirin
kubectl apply -f azure/keyvault-csi-driver.yaml
```

## 📊 Azure Portal İzleme

### Resource Group
- `crypto-trading-bot-production-rg` - Tüm kaynaklar
- Cost tracking ve optimization
- Performance monitoring

### Azure Monitor
- Application Insights
- Log Analytics
- Metrics ve alerting

## 🚨 Troubleshooting

### Common Issues

#### 1. AKS Cluster Connection
```bash
# Credentials yenileme
az aks get-credentials --resource-group crypto-trading-bot-production-rg --name crypto-trading-bot-production-aks

# Bağlantı testi
kubectl get nodes
```

#### 2. Docker Build Issues
```bash
# ACR login
az acr login --name <acr-name>

# Manuel build
docker build -t <acr-name>.azurecr.io/backtester:latest -f docker/Dockerfile.backtester .
docker push <acr-name>.azurecr.io/backtester:latest
```

#### 3. Database Connection
```bash
# PostgreSQL firewall ayarları
az postgres server firewall-rule create \
  --resource-group crypto-trading-bot-production-rg \
  --server crypto-trading-bot-production-pg \
  --name AllowAll \
  --start-ip-address 0.0.0.0 \
  --end-ip-address 255.255.255.255
```

### Logs İnceleme
```bash
# Pod logs
kubectl logs -f deployment/backtester -n trading-system

# Kubernetes events
kubectl get events -n trading-system --sort-by='.lastTimestamp'
```

## 📚 Ek Kaynaklar

### Dokümantasyon
- `docs/` - Teknik dokümantasyon
- `kubernetes/README.md` - K8s konfigürasyonu
- `azure/README.md` - Azure services
- `security/README.md` - Güvenlik kuralları

### Community
- GitHub Issues: Bug reports ve feature requests
- Documentation: Yeni özellikler ve best practices

## 💰 Maliyet Optimizasyonu

### Azure Cost Management
1. Azure Portal > Cost Management
2. Budgets oluşturun
3. Alerts kurun
4. Cost optimization önerilerini takip edin

### Resource Right-Sizing
```bash
# Kullanım analizi
az monitor metrics list \
  --resource /subscriptions/<subscription-id>/resourceGroups/crypto-trading-bot-production-rg/providers/Microsoft.ContainerService/managedClusters/crypto-trading-bot-production-aks \
  --metric PercentageCpu \
  --interval PT5M \
  --start-time $(date -d '1 hour ago' -u +%Y-%m-%dT%H:%M:%SZ) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%SZ)
```

## 🎉 Başarılı Kurulum Sonrası

1. **Dashboard'ları kontrol edin**
2. **API testleri yapın**
3. **Monitoring alerts'ları ayarlayın**
4. **Backup stratejilerini aktifleştirin**
5. **Security scanning çalıştırın**

---

**📞 Destek**: Herhangi bir sorun yaşarsanız, GitHub Issues'da detaylı bilgi vererek yardım isteyebilirsiniz.

**🔄 Güncelleme**: Sistem düzenli olarak güncellenir. `git pull` ile en son sürümü alın ve `./azure-deployment-master.sh` ile yeniden deploy edin.