#!/usr/bin/env python3
"""
CRYPTO TRADING SYSTEM - COMPREHENSIVE FINAL TEST
Tüm bileşenlerin sıralı testi
"""

import sys
sys.path.append('code')

def test_dvk_engine():
    """DVK Engine test"""
    print("🔬 DVK ENGINE TEST")
    print("=" * 20)
    
    try:
        import numpy as np
        import pandas as pd
        from dvk_engine.dvk_engine import DVKEngine
        
        # Test verisi
        np.random.seed(42)
        prices = 50000 + np.random.randn(100).cumsum() * 100
        prices_series = pd.Series(prices)
        price_data = pd.DataFrame({'close': prices})
        
        # DVK Engine test
        dvk = DVKEngine()
        indicators = dvk.technical_indicators.calculate_rsi(prices_series)
        sma = dvk.technical_indicators.calculate_sma(prices_series, 20)
        regime = dvk.regime_detector.detect_regime(price_data)
        
        print(f"✅ DVK Engine: RSI={len(indicators)}, SMA={len(sma)}")
        return True
        
    except Exception as e:
        print(f"❌ DVK Engine error: {e}")
        return False

def test_genetic_engine():
    """Genetic Engine test"""
    print("\n🧬 GENETIC ENGINE TEST")
    print("=" * 25)
    
    try:
        from genetic_engine.core.engine import EvolutionEngine, EvolutionConfig
        
        config = EvolutionConfig(population_size=10, generations=2)
        engine = EvolutionEngine(config)
        
        print(f"✅ Genetic Engine: {config.population_size} pop, {config.generations} gen")
        return True
        
    except Exception as e:
        print(f"❌ Genetic Engine error: {e}")
        return False

def test_backtester():
    """Backtester test"""
    print("\n📊 BACKTESTER TEST")
    print("=" * 18)
    
    try:
        from backtester.core.order_book import Portfolio
        from backtester.core.event_system import Event, EventBus
        
        portfolio = Portfolio(initial_capital=100000)
        event_bus = EventBus()
        
        print(f"✅ Backtester: Portfolio=${portfolio.initial_capital}")
        return True
        
    except Exception as e:
        print(f"❌ Backtester error: {e}")
        return False

def main():
    """Ana test fonksiyonu"""
    print("🚀 CRYPTO TRADING SYSTEM - FINAL COMPREHENSIVE TEST")
    print("=" * 55)
    
    results = []
    
    # DVK Engine test
    results.append(test_dvk_engine())
    
    # Genetic Engine test  
    results.append(test_genetic_engine())
    
    # Backtester test
    results.append(test_backtester())
    
    # Sonuçlar
    print("\n" + "=" * 55)
    print("📊 FİNAL TEST SONUÇLARI:")
    print("=" * 55)
    
    if all(results):
        print("🎉 TÜM SİSTEMLER BAŞARIYLA ÇALIŞIYOR!")
        print("✅ DVK Engine: OK")
        print("✅ Genetic Engine: OK") 
        print("✅ Backtester: OK")
        print("\n🚀 CRYPTO TRADING SİSTEMİ HAZIR!")
        return True
    else:
        print("❌ Bazı sistemlerde hata var:")
        for i, result in enumerate(results):
            component = ["DVK", "Genetic", "Backtester"][i]
            status = "OK" if result else "ERROR"
            print(f"  {component} Engine: {status}")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)