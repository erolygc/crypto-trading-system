# 🚀 Çözüm: Dependencies Yükleme
# pandas, numpy ve diğer gerekli paketler eksik

## PowerShell'de sırayla çalıştırın:

# 1️⃣ Dependencies yükle
pip install -r requirements-dev.txt

# 2️⃣ Eğer requirements-dev.txt yoksa, temel paketleri yükle
pip install pandas numpy scikit-learn matplotlib seaborn requests fastapi uvicorn

# 3️⃣ Tekrar test et
python test_dvk_algorithm.py

# 4️⃣ Trading modüllerini test et
python -c "
import sys
sys.path.append('code')
from dvk_engine import DVKEngine
from genetic_engine import GeneticEngine
from backtester import Backtester
print('✅ Tüm trading modülleri çalışıyor!')
"