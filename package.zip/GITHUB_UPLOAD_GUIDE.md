# 🚀 Crypto Trading System - GitHub Yükleme Rehberi

## GitHub Repository Oluşturma

### Yöntem 1: GitHub Web Interface (Önerilen)

1. **GitHub'a gidin:** https://github.com
2. **Yeni Repository Oluşturun:**
   - Sağ üstteki "+" butonuna tıklayın → "New repository"
   - Repository adı: `crypto-trading-system`
   - Açıklama: `Production-ready automated crypto trading system with AI algorithms`
   - Public seçeneğini seçin
   - ✅ Add a README file
   - ✅ Add .gitignore (Python)
   - ✅ Choose a license (MIT)
3. **"Create repository" butonuna tıklayın**

### Yöntem 2: GitHub CLI (Terminal'den)

```bash
# GitHub CLI ile repository oluşturma
gh repo create crypto-trading-system --public --description "Production-ready automated crypto trading system with AI algorithms"
```

## Sistemi GitHub'a Yükleme

### Seçenek A: GitHub'dan Çekip Visual Studio Code'a Alma

```bash
# 1. Repository'yi GitHub'dan klonlayın
git clone https://github.com/YOUR_USERNAME/crypto-trading-system.git

# 2. Dizine geçin
cd crypto-trading-system

# 3. Visual Studio Code'da açın
code .

# 4. Python extensions'ları yükleyin
# VS Code'da: Ctrl+Shift+P → "Extensions: Install Extensions" → "Python", "Pylance", "Python Debugger"
```

### Seçenek B: Mevcut Sistemi Push Yapma

Eğer GitHub repository'si hazırsa, sistemi aşağıdaki komutlarla push yapabilirsiniz:

```bash
# GitHub repository URL'nizi buraya ekleyin
GITHUB_REPO_URL="https://github.com/YOUR_USERNAME/crypto-trading-system.git"

# Remote ekleme
git remote add origin $GITHUB_REPO_URL

# Ana branch'i main olarak değiştir
git branch -M main

# GitHub'a push yap
git push -u origin main
```

## Gerekli Bilgiler

- **GitHub Username:** [Kullanıcı adınızı girin]
- **Repository URL:** https://github.com/[USERNAME]/crypto-trading-system

## Visual Studio Code Kurulumu

VS Code'da proje açıldıktan sonra:

1. **Python Environment:**
   ```bash
   # Virtual environment oluşturun
   python -m venv venv
   
   # Aktifleştirin
   # Windows: venv\Scripts\activate
   # macOS/Linux: source venv/bin/activate
   
   # Requirements yükleyin
   uv pip install -r requirements-dev.txt
   ```

2. **VS Code Extensions:**
   - Python
   - Pylance  
   - Python Debugger
   - GitLens
   - Docker

3. **Workspace Settings:**
   - `Ctrl+Shift+P` → "Python: Select Interpreter" → venv'deki Python seçin
   - `Ctrl+Shift+P` → "Python: Format Document" ile auto-formatting

## Azure Deployment

Kurulumdan sonra Azure deployment için:

```bash
# Azure setup script'ini çalıştırın
chmod +x azure-deployment-master.sh
./azure-deployment-master.sh

# Veya QUICK_START_AZURE.md dosyasını takip edin
```

## Sistem İçeriği

Repository şu bileşenleri içerir:
- ✅ 348 Python modülü
- ✅ 1,487 dosya
- ✅ Production-ready Docker setup
- ✅ Kubernetes deployment
- ✅ Azure infrastructure
- ✅ CI/CD pipelines
- ✅ Monitoring (Prometheus/Grafana)
- ✅ Security compliance
- ✅ VS Code workspace setup

---

**Tepki:** Bu rehberi takip ederek sisteminizi GitHub'a yükleyip VS Code'da kullanmaya başlayabilirsiniz!
