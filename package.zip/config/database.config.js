/**
 * Database Configuration Manager
 * 
 * Bu modül database bağlantıları ve konfigürasyonları yönetir:
 * - PostgreSQL bağlantı pooling
 * - Redis configuration  
 * - MongoDB setup
 * - Connection validation
 * 
 * @author Crypto Trading Bot Team
 * @version 1.0.0
 */

const { Pool } = require('pg');
const Redis = require('redis');
const { MongoClient } = require('mongodb');

class DatabaseManager {
    constructor() {
        this.pools = new Map();
        this.clients = new Map();
        this.isInitialized = false;
    }

    /**
     * Database bağlantılarını initialize eder
     */
    async initialize() {
        if (this.isInitialized) {
            return;
        }

        console.log('🔧 Initializing database connections...');

        // Initialize PostgreSQL
        await this.initPostgreSQL();
        
        // Initialize Redis
        await this.initRedis();
        
        // Initialize MongoDB
        await this.initMongoDB();

        this.isInitialized = true;
        console.log('✅ Database connections initialized');
    }

    /**
     * PostgreSQL bağlantısını kurar
     */
    async initPostgreSQL() {
        const config = {
            host: process.env.DB_HOST,
            port: process.env.DB_PORT || 5432,
            database: process.env.DB_NAME,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
            max: parseInt(process.env.DB_POOL_MAX) || 10,
            min: parseInt(process.env.DB_POOL_MIN) || 2,
            idleTimeoutMillis: parseInt(process.env.DB_TIMEOUT) || 30000,
            connectionTimeoutMillis: 5000,
            statement_timeout: 60000,
            query_timeout: 60000
        };

        try {
            const pool = new Pool(config);
            
            // Test connection
            const client = await pool.connect();
            const result = await client.query('SELECT NOW() as current_time, version() as version');
            client.release();

            console.log(`✅ PostgreSQL connected: ${result.rows[0].version}`);
            console.log(`   Host: ${config.host}:${config.port}/${config.database}`);

            this.pools.set('postgresql', pool);
        } catch (error) {
            console.error(`❌ PostgreSQL connection failed: ${error.message}`);
            throw error;
        }
    }

    /**
     * Redis bağlantısını kurar
     */
    async initRedis() {
        const config = {
            host: process.env.REDIS_HOST || 'localhost',
            port: parseInt(process.env.REDIS_PORT) || 6379,
            password: process.env.REDIS_PASSWORD,
            db: parseInt(process.env.REDIS_DB) || 0,
            retryDelayOnFailover: 100,
            enableReadyCheck: true,
            maxRetriesPerRequest: 3
        };

        try {
            const client = Redis.createClient(config);

            // Setup event handlers
            client.on('error', (error) => {
                console.error(`❌ Redis error: ${error.message}`);
            });

            client.on('connect', () => {
                console.log('🔗 Redis connected');
            });

            client.on('ready', () => {
                console.log('✅ Redis ready');
            });

            await client.connect();

            // Test connection
            const pong = await client.ping();
            if (pong === 'PONG') {
                console.log(`✅ Redis connected: ${config.host}:${config.port}/${config.db}`);
                this.clients.set('redis', client);
            } else {
                throw new Error(`Unexpected Redis response: ${pong}`);
            }
        } catch (error) {
            console.error(`❌ Redis connection failed: ${error.message}`);
            throw error;
        }
    }

    /**
     * MongoDB bağlantısını kurar
     */
    async initMongoDB() {
        const uri = process.env.MONGO_URI;
        
        if (!uri) {
            console.log('⚠️ MongoDB URI not configured, skipping...');
            return;
        }

        const config = {
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 60000,
            maxPoolSize: 10,
            minPoolSize: 2,
            retryWrites: true,
            w: 'majority'
        };

        try {
            const client = new MongoClient(uri, config);
            await client.connect();

            // Test connection
            const dbName = client.db().databaseName;
            await client.db().admin().ping();

            console.log(`✅ MongoDB connected: ${dbName}`);
            this.clients.set('mongodb', client);
        } catch (error) {
            console.error(`❌ MongoDB connection failed: ${error.message}`);
            throw error;
        }
    }

    /**
     * PostgreSQL pool'unu getirir
     * @returns {Pool} PostgreSQL connection pool
     */
    getPostgreSQL() {
        const pool = this.pools.get('postgresql');
        if (!pool) {
            throw new Error('PostgreSQL pool not initialized');
        }
        return pool;
    }

    /**
     * Redis client'ını getirir
     * @returns {RedisClient} Redis client
     */
    getRedis() {
        const client = this.clients.get('redis');
        if (!client) {
            throw new Error('Redis client not initialized');
        }
        return client;
    }

    /**
     * MongoDB client'ını getirir
     * @returns {MongoClient} MongoDB client
     */
    getMongoDB() {
        const client = this.clients.get('mongodb');
        if (!client) {
            throw new Error('MongoDB client not initialized');
        }
        return client;
    }

    /**
     * Database bağlantılarını test eder
     */
    async testConnections() {
        console.log('🧪 Testing database connections...');

        // Test PostgreSQL
        try {
            const pool = this.getPostgreSQL();
            const result = await pool.query('SELECT NOW() as time');
            console.log(`✅ PostgreSQL test passed: ${result.rows[0].time}`);
        } catch (error) {
            console.error(`❌ PostgreSQL test failed: ${error.message}`);
        }

        // Test Redis
        try {
            const redis = this.getRedis();
            const result = await redis.ping();
            console.log(`✅ Redis test passed: ${result}`);
        } catch (error) {
            console.error(`❌ Redis test failed: ${error.message}`);
        }

        // Test MongoDB
        try {
            const client = this.getMongoDB();
            await client.db().admin().ping();
            console.log('✅ MongoDB test passed');
        } catch (error) {
            console.error(`❌ MongoDB test failed: ${error.message}`);
        }
    }

    /**
     * Database bağlantılarını kapatır
     */
    async close() {
        console.log('🔒 Closing database connections...');

        // Close PostgreSQL pools
        for (const [name, pool] of this.pools) {
            await pool.end();
            console.log(`✅ Closed ${name} pool`);
        }

        // Close clients
        for (const [name, client] of this.clients) {
            if (client.quit) {
                await client.quit();
            } else if (client.close) {
                await client.close();
            }
            console.log(`✅ Closed ${name} client`);
        }

        this.pools.clear();
        this.clients.clear();
        this.isInitialized = false;
    }

    /**
     * Database health check
     * @returns {Object} Health status
     */
    async healthCheck() {
        const health = {
            timestamp: new Date().toISOString(),
            status: 'healthy',
            databases: {}
        };

        // Check PostgreSQL
        try {
            const pool = this.getPostgreSQL();
            const result = await pool.query('SELECT NOW() as time');
            health.databases.postgresql = {
                status: 'healthy',
                responseTime: 'fast',
                currentTime: result.rows[0].time
            };
        } catch (error) {
            health.databases.postgresql = {
                status: 'unhealthy',
                error: error.message
            };
            health.status = 'unhealthy';
        }

        // Check Redis
        try {
            const redis = this.getRedis();
            const startTime = Date.now();
            await redis.ping();
            const responseTime = Date.now() - startTime;
            health.databases.redis = {
                status: 'healthy',
                responseTime: responseTime < 50 ? 'fast' : 'slow'
            };
        } catch (error) {
            health.databases.redis = {
                status: 'unhealthy',
                error: error.message
            };
            health.status = 'unhealthy';
        }

        // Check MongoDB
        try {
            const client = this.getMongoDB();
            const startTime = Date.now();
            await client.db().admin().ping();
            const responseTime = Date.now() - startTime;
            health.databases.mongodb = {
                status: 'healthy',
                responseTime: responseTime < 50 ? 'fast' : 'slow'
            };
        } catch (error) {
            health.databases.mongodb = {
                status: 'unhealthy',
                error: error.message
            };
            health.status = 'unhealthy';
        }

        return health;
    }

    /**
     * Migration runner
     * @param {string} sql - Migration SQL
     */
    async migrate(sql) {
        try {
            const pool = this.getPostgreSQL();
            await pool.query(sql);
            console.log('✅ Migration completed successfully');
        } catch (error) {
            console.error(`❌ Migration failed: ${error.message}`);
            throw error;
        }
    }

    /**
     * Database backup
     * @param {string} outputPath - Backup file path
     */
    async backup(outputPath) {
        const fs = require('fs');
        const { exec } = require('child_process');
        const util = require('util');
        const execPromise = util.promisify(exec);

        try {
            const config = {
                host: process.env.DB_HOST,
                port: process.env.DB_PORT || 5432,
                database: process.env.DB_NAME,
                user: process.env.DB_USER,
                password: process.env.DB_PASSWORD
            };

            const pgDump = `pg_dump -h ${config.host} -p ${config.port} -U ${config.user} -d ${config.database} > ${outputPath}`;
            
            await execPromise(pgDump, {
                env: { PGPASSWORD: config.password }
            });
            
            console.log(`✅ Database backup completed: ${outputPath}`);
        } catch (error) {
            console.error(`❌ Database backup failed: ${error.message}`);
            throw error;
        }
    }
}

// Singleton instance
let dbManager = null;

/**
 * Database Manager instance'ını döner
 * @returns {DatabaseManager} Manager instance
 */
function getDatabaseManager() {
    if (!dbManager) {
        dbManager = new DatabaseManager();
    }
    return dbManager;
}

module.exports = {
    DatabaseManager,
    getDatabaseManager
};

// CLI usage
if (require.main === module) {
    async function main() {
        const command = process.argv[2];
        const dbManager = new DatabaseManager();

        try {
            switch (command) {
                case 'init':
                    await dbManager.initialize();
                    break;
                    
                case 'test':
                    await dbManager.initialize();
                    await dbManager.testConnections();
                    break;
                    
                case 'health':
                    await dbManager.initialize();
                    const health = await dbManager.healthCheck();
                    console.log(JSON.stringify(health, null, 2));
                    break;
                    
                case 'backup':
                    const outputPath = process.argv[3] || './database-backup.sql';
                    await dbManager.initialize();
                    await dbManager.backup(outputPath);
                    break;
                    
                case 'close':
                    await dbManager.close();
                    break;
                    
                default:
                    console.log(`
Database Manager CLI

Usage:
  node database.config.js init         - Initialize connections
  node database.config.js test         - Test all connections
  node database.config.js health       - Health check
  node database.config.js backup [path] - Backup database
  node database.config.js close        - Close connections

Environment Variables:
  DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD
  REDIS_HOST, REDIS_PORT, REDIS_PASSWORD, REDIS_DB
  MONGO_URI
                    `);
            }
        } catch (error) {
            console.error(`❌ Error: ${error.message}`);
            process.exit(1);
        }
    }
    
    main();
}