/**
 * Security Configuration Manager
 * 
 * Bu modül güvenlik konfigürasyonları ve ayarları yönetir:
 * - JWT konfigürasyonu
 * - CORS ayarları
 * - Rate limiting
 * - Input validation
 * - Encryption/decryption
 * 
 * @author Crypto Trading Bot Team
 * @version 1.0.0
 */

const crypto = require('crypto');
const jwt = require('jsonwebtoken');

class SecurityManager {
    constructor() {
        this.environment = process.env.NODE_ENV || 'development';
        this.config = this.initConfig();
    }

    /**
     * Security konfigürasyonunu initialize eder
     */
    initConfig() {
        return {
            // JWT Configuration
            jwt: {
                secret: process.env.JWT_SECRET,
                expiresIn: process.env.JWT_EXPIRES_IN || '24h',
                refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
                issuer: process.env.APP_NAME || 'crypto-bot',
                audience: 'crypto-users'
            },

            // Encryption Configuration
            encryption: {
                algorithm: process.env.ENCRYPTION_ALGORITHM || 'aes-256-gcm',
                key: process.env.ENCRYPTION_KEY
            },

            // CORS Configuration
            cors: {
                origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',') : ['http://localhost:3000'],
                credentials: process.env.CORS_CREDENTIALS === 'true',
                methods: process.env.CORS_METHODS ? process.env.CORS_METHODS.split(',') : ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
                allowedHeaders: process.env.CORS_HEADERS ? process.env.CORS_HEADERS.split(',') : ['Content-Type', 'Authorization', 'X-Requested-With'],
                maxAge: 86400 // 24 hours
            },

            // Rate Limiting Configuration
            rateLimit: {
                windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
                max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100,
                skipFailedRequests: process.env.RATE_LIMIT_SKIP_FAILED_REQUESTS === 'true',
                message: {
                    error: 'Too many requests from this IP, please try again later'
                },
                standardHeaders: true,
                legacyHeaders: false
            },

            // Security Headers
            headers: {
                'X-Content-Type-Options': 'nosniff',
                'X-Frame-Options': 'DENY',
                'X-XSS-Protection': '1; mode=block',
                'Strict-Transport-Security': this.environment === 'production' ? 'max-age=31536000; includeSubDomains' : false,
                'Content-Security-Policy': this.getCSPHeader(),
                'Referrer-Policy': 'strict-origin-when-cross-origin'
            },

            // Input Validation
            validation: {
                maxRequestSize: '10mb',
                requestTimeout: 30000, // 30 seconds
                suspiciousPatterns: [
                    /(\<|\%3C)script(\>|\%3E)/i, // Script tags
                    /javascript:/i, // JavaScript protocol
                    /on\w+\s*=/i, // Event handlers
                    /eval\s*\(/i, // Eval function
                    /expression\s*\(/i, // CSS expressions
                    /<\s*link/i, // Link tags
                    /<\s*object/i, // Object tags
                    /<\s*embed/i // Embed tags
                ]
            }
        };
    }

    /**
     * Content Security Policy header'ını getirir
     */
    getCSPHeader() {
        if (this.environment !== 'production') {
            return false;
        }

        return "default-src 'self'; " +
               "script-src 'self' 'unsafe-inline'; " +
               "style-src 'self' 'unsafe-inline'; " +
               "img-src 'self' data: https:; " +
               "font-src 'self' https:; " +
               "connect-src 'self' wss: https:; " +
               "media-src 'self'; " +
               "object-src 'none'; " +
               "frame-src 'none';";
    }

    /**
     * JWT token oluşturur
     * @param {Object} payload - Token payload
     * @param {Object} options - JWT options
     * @returns {string} JWT token
     */
    createToken(payload, options = {}) {
        if (!this.config.jwt.secret) {
            throw new Error('JWT secret not configured');
        }

        const jwtOptions = {
            issuer: this.config.jwt.issuer,
            audience: this.config.jwt.audience,
            expiresIn: this.config.jwt.expiresIn,
            ...options
        };

        return jwt.sign(payload, this.config.jwt.secret, jwtOptions);
    }

    /**
     * JWT token'ı doğrular
     * @param {string} token - JWT token
     * @returns {Object} Decoded payload
     */
    verifyToken(token) {
        if (!this.config.jwt.secret) {
            throw new Error('JWT secret not configured');
        }

        return jwt.verify(token, this.config.jwt.secret, {
            issuer: this.config.jwt.issuer,
            audience: this.config.jwt.audience
        });
    }

    /**
     * Veriyi şifreler
     * @param {string} data - Şifrelenecek veri
     * @param {string} key - Şifreleme anahtarı (opsiyonel)
     * @returns {Object} Şifrelenmiş veri
     */
    encrypt(data, key = null) {
        if (!data) {
            throw new Error('Data to encrypt is required');
        }

        const encryptionKey = key || this.config.encryption.key;
        if (!encryptionKey) {
            throw new Error('Encryption key not configured');
        }

        if (encryptionKey.length !== 32) {
            throw new Error('Encryption key must be exactly 32 characters');
        }

        try {
            const iv = crypto.randomBytes(16);
            const cipher = crypto.createCipher(this.config.encryption.algorithm, encryptionKey);
            cipher.setAutoPadding(true);

            let encrypted = cipher.update(data, 'utf8', 'hex');
            encrypted += cipher.final('hex');

            // Generate authentication tag for GCM mode
            const authTag = cipher.getAuthTag ? cipher.getAuthTag() : '';

            return {
                encrypted: encrypted,
                iv: iv.toString('hex'),
                authTag: authTag || '',
                algorithm: this.config.encryption.algorithm
            };
        } catch (error) {
            throw new Error(`Encryption failed: ${error.message}`);
        }
    }

    /**
     * Şifreli veriyi çözer
     * @param {Object} encryptedData - Şifreli veri objesi
     * @param {string} key - Şifreleme anahtarı (opsiyonel)
     * @returns {string} Çözülmüş veri
     */
    decrypt(encryptedData, key = null) {
        if (!encryptedData) {
            throw new Error('Encrypted data is required');
        }

        const encryptionKey = key || this.config.encryption.key;
        if (!encryptionKey) {
            throw new Error('Encryption key not configured');
        }

        if (encryptionKey.length !== 32) {
            throw new Error('Encryption key must be exactly 32 characters');
        }

        try {
            const decipher = crypto.createDecipher(this.config.encryption.algorithm, encryptionKey);
            
            // Set IV for CBC mode
            if (encryptedData.iv) {
                decipher.setIV(Buffer.from(encryptedData.iv, 'hex'));
            }

            // Set auth tag for GCM mode
            if (encryptedData.authTag) {
                decipher.setAuthTag(Buffer.from(encryptedData.authTag, 'hex'));
            }

            let decrypted = decipher.update(encryptedData.encrypted, 'hex', 'utf8');
            decrypted += decipher.final('utf8');

            return decrypted;
        } catch (error) {
            throw new Error(`Decryption failed: ${error.message}`);
        }
    }

    /**
     * Güvenli password hash oluşturur
     * @param {string} password - Password
     * @param {string} salt - Salt (opsiyonel)
     * @returns {Object} Password hash ve salt
     */
    hashPassword(password, salt = null) {
        if (!password) {
            throw new Error('Password is required');
        }

        try {
            const useSalt = salt || crypto.randomBytes(32).toString('hex');
            const iterations = 100000; // OWASP recommended minimum
            
            const hash = crypto.pbkdf2Sync(password, useSalt, iterations, 32, 'sha512');
            
            return {
                hash: hash.toString('hex'),
                salt: useSalt,
                iterations: iterations
            };
        } catch (error) {
            throw new Error(`Password hashing failed: ${error.message}`);
        }
    }

    /**
     * Password'ü doğrular
     * @param {string} password - Test edilecek password
     * @param {string} hash - Stored hash
     * @param {string} salt - Stored salt
     * @param {number} iterations - Hash iterations
     * @returns {boolean} Password doğru mu
     */
    verifyPassword(password, hash, salt, iterations = 100000) {
        try {
            const testHash = crypto.pbkdf2Sync(password, salt, iterations, 32, 'sha512');
            return testHash.toString('hex') === hash;
        } catch (error) {
            return false;
        }
    }

    /**
     * Girdi validation yapar
     * @param {string} input - Validate edilecek input
     * @returns {Object} Validation sonucu
     */
    validateInput(input) {
        if (typeof input !== 'string') {
            return {
                valid: false,
                errors: ['Input must be a string']
            };
        }

        const errors = [];

        // Check for suspicious patterns
        for (const pattern of this.config.validation.suspiciousPatterns) {
            if (pattern.test(input)) {
                errors.push('Input contains suspicious content');
                break;
            }
        }

        // Length validation
        if (input.length > 10000) {
            errors.push('Input too long (max 10000 characters)');
        }

        // SQL injection patterns
        const sqlPatterns = [
            /('|(\\x27)|(\\x22))(\\d|\\d\\d|\\d\\d\\d)((\\x27)|(\\x22))/i,
            /((\\x27)|(\\x22))\\s*(exec(\\s|\\+)+(s|x)p\\w+)/i,
            /((\\x27)|(\\x22))union/i,
            /((\\x27)|(\\x22))drop/i,
            /((\\x27)|(\\x22))insert/i,
            /((\\x27)|(\\x22))delete/i,
            /((\\x27)|(\\x22))update/i,
            /((\\x27)|(\\x22))select/i
        ];

        for (const pattern of sqlPatterns) {
            if (pattern.test(input)) {
                errors.push('Input contains SQL injection patterns');
                break;
            }
        }

        return {
            valid: errors.length === 0,
            errors: errors,
            sanitized: this.sanitizeInput(input)
        };
    }

    /**
     * Input'u sanitization yapar
     * @param {string} input - Sanitize edilecek input
     * @returns {string} Sanitized input
     */
    sanitizeInput(input) {
        if (typeof input !== 'string') {
            return input;
        }

        return input
            .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove script tags
            .replace(/javascript:/gi, '') // Remove javascript protocol
            .replace(/on\w+\s*=/gi, '') // Remove event handlers
            .replace(/eval\s*\(/gi, '') // Remove eval functions
            .trim();
    }

    /**
     * CORS konfigürasyonunu getirir
     * @returns {Object} CORS options
     */
    getCORSOptions() {
        return this.config.cors;
    }

    /**
     * Rate limiting konfigürasyonunu getirir
     * @returns {Object} Rate limit options
     */
    getRateLimitOptions() {
        return this.config.rateLimit;
    }

    /**
     * Security headers'ları getirir
     * @returns {Object} Security headers
     */
    getSecurityHeaders() {
        return this.config.headers;
    }

    /**
     * API key generate eder
     * @param {string} prefix - API key prefix
     * @returns {string} Generated API key
     */
    generateAPIKey(prefix = 'api') {
        const timestamp = Date.now().toString(36);
        const randomBytes = crypto.randomBytes(32).toString('hex');
        return `${prefix}_${timestamp}_${randomBytes}`;
    }

    /**
     * Secret rotation yapar
     * @param {string} secretType - Secret tipi
     * @returns {Object} Yeni secret
     */
    rotateSecret(secretType) {
        switch (secretType) {
            case 'jwt':
                return crypto.randomBytes(64).toString('hex');
                
            case 'encryption':
                return crypto.randomBytes(32).toString('utf8');
                
            case 'api':
                return this.generateAPIKey();
                
            default:
                return crypto.randomBytes(32).toString('hex');
        }
    }

    /**
     * Security audit raporu oluşturur
     * @returns {Object} Security audit sonucu
     */
    securityAudit() {
        const audit = {
            timestamp: new Date().toISOString(),
            environment: this.environment,
            checks: []
        };

        // Check JWT secret
        const jwtSecret = this.config.jwt.secret;
        if (!jwtSecret) {
            audit.checks.push({
                name: 'JWT Secret',
                status: 'fail',
                message: 'JWT secret not configured'
            });
        } else if (jwtSecret.length < 32) {
            audit.checks.push({
                name: 'JWT Secret',
                status: 'warning',
                message: 'JWT secret should be at least 32 characters'
            });
        } else {
            audit.checks.push({
                name: 'JWT Secret',
                status: 'pass',
                message: 'JWT secret configuration looks good'
            });
        }

        // Check encryption key
        const encryptionKey = this.config.encryption.key;
        if (!encryptionKey) {
            audit.checks.push({
                name: 'Encryption Key',
                status: 'fail',
                message: 'Encryption key not configured'
            });
        } else if (encryptionKey.length !== 32) {
            audit.checks.push({
                name: 'Encryption Key',
                status: 'fail',
                message: 'Encryption key must be exactly 32 characters'
            });
        } else {
            audit.checks.push({
                name: 'Encryption Key',
                status: 'pass',
                message: 'Encryption key configuration looks good'
            });
        }

        // Check HTTPS enforcement
        if (this.environment === 'production' && !process.env.SSL_ENABLED) {
            audit.checks.push({
                name: 'HTTPS Enforcement',
                status: 'fail',
                message: 'SSL should be enabled in production'
            });
        } else {
            audit.checks.push({
                name: 'HTTPS Enforcement',
                status: 'pass',
                message: 'HTTPS configuration looks good'
            });
        }

        // Check CORS configuration
        const corsOrigins = this.config.cors.origin;
        if (this.environment === 'production' && corsOrigins.includes('http://localhost')) {
            audit.checks.push({
                name: 'CORS Configuration',
                status: 'warning',
                message: 'CORS allows localhost in production'
            });
        } else {
            audit.checks.push({
                name: 'CORS Configuration',
                status: 'pass',
                message: 'CORS configuration looks good'
            });
        }

        // Check rate limiting
        if (this.config.rateLimit.max < 100) {
            audit.checks.push({
                name: 'Rate Limiting',
                status: 'warning',
                message: 'Rate limiting threshold seems low'
            });
        } else {
            audit.checks.push({
                name: 'Rate Limiting',
                status: 'pass',
                message: 'Rate limiting configuration looks good'
            });
        }

        return audit;
    }
}

// Singleton instance
let securityManager = null;

/**
 * Security Manager instance'ını döner
 * @returns {SecurityManager} Manager instance
 */
function getSecurityManager() {
    if (!securityManager) {
        securityManager = new SecurityManager();
    }
    return securityManager;
}

module.exports = {
    SecurityManager,
    getSecurityManager
};

// CLI usage
if (require.main === module) {
    const securityManager = new SecurityManager();
    const command = process.argv[2];

    switch (command) {
        case 'audit':
            const audit = securityManager.securityAudit();
            console.log(JSON.stringify(audit, null, 2));
            break;
            
        case 'generate-key':
            const type = process.argv[3] || 'api';
            const key = securityManager.rotateSecret(type);
            console.log(`Generated ${type} key:`);
            console.log(key);
            break;
            
        case 'hash-password':
            const password = process.argv[3];
            if (!password) {
                console.log('Usage: node security.config.js hash-password <password>');
                process.exit(1);
            }
            const hashResult = securityManager.hashPassword(password);
            console.log(JSON.stringify(hashResult, null, 2));
            break;
            
        default:
            console.log(`
Security Manager CLI

Usage:
  node security.config.js audit                    - Run security audit
  node security.config.js generate-key [type]     - Generate secret key
  node security.config.js hash-password <password> - Hash password

Supported key types: jwt, encryption, api
            `);
    }
}