/**
 * SSL/TLS Configuration Manager
 * 
 * Bu modül SSL/TLS sertifikaları ve güvenli bağlantı konfigürasyonları yönetir:
 * - SSL certificate management
 * - TLS configuration
 * - Certificate validation
 * - Secure connection setup
 * 
 * @author Crypto Trading Bot Team
 * @version 1.0.0
 */

const fs = require('fs');
const path = require('path');
const https = require('https');
const tls = require('tls');
const crypto = require('crypto');

class SSLManager {
    constructor() {
        this.environment = process.env.NODE_ENV || 'development';
        this.enabled = process.env.SSL_ENABLED === 'true';
        this.config = this.initConfig();
        this.certificates = new Map();
    }

    /**
     * SSL konfigürasyonunu initialize eder
     */
    initConfig() {
        return {
            // SSL Settings
            enabled: this.enabled,
            certPath: process.env.SSL_CERT_PATH,
            keyPath: process.env.SSL_KEY_PATH,
            caPath: process.env.SSL_CA_PATH,
            verifyMode: process.env.SSL_VERIFY_MODE || 'peer',
            
            // Certificate Settings
            selfSigned: process.env.SSL_SELF_SIGNED === 'true',
            certValidity: parseInt(process.env.SSL_CERT_VALIDITY) || 365,
            keySize: parseInt(process.env.SSL_KEY_SIZE) || 2048,
            
            // TLS Settings
            tlsOptions: {
                minVersion: 'TLSv1.2',
                maxVersion: 'TLSv1.3',
                ciphers: [
                    'ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512',
                    'ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384',
                    'ECDHE-RSA-AES256-SHA384'
                ].join(':'),
                honorCipherOrder: true,
                ecdhCurve: 'secp384r1',
                sessionTimeout: 300
            },

            // HTTPS Server Options
            httpsOptions: {
                port: parseInt(process.env.HTTPS_PORT) || 8443,
                host: process.env.APP_HOST || '0.0.0.0',
                requestCert: true,
                rejectUnauthorized: this.environment === 'production'
            },

            // Certificate Monitoring
            monitoring: {
                checkInterval: 3600000, // 1 hour
                renewalThreshold: 30, // 30 days before expiry
                alertThreshold: 7 // 7 days before expiry
            }
        };
    }

    /**
     * SSL sertifikalarını yükler
     */
    async loadCertificates() {
        if (!this.config.enabled) {
            console.log('🔓 SSL disabled - using HTTP');
            return null;
        }

        console.log('🔒 Loading SSL certificates...');

        try {
            const certPath = this.config.certPath;
            const keyPath = this.config.keyPath;
            const caPath = this.config.caPath;

            // Check if certificate files exist
            if (!fs.existsSync(certPath)) {
                throw new Error(`Certificate file not found: ${certPath}`);
            }

            if (!fs.existsSync(keyPath)) {
                throw new Error(`Private key file not found: ${keyPath}`);
            }

            // Load certificate and key
            const certificate = fs.readFileSync(certPath, 'utf8');
            const privateKey = fs.readFileSync(keyPath, 'utf8');

            // Load CA bundle if provided
            let ca = null;
            if (caPath && fs.existsSync(caPath)) {
                ca = fs.readFileSync(caPath, 'utf8');
            }

            const certs = {
                cert: certificate,
                key: privateKey,
                ca: ca,
                path: {
                    cert: certPath,
                    key: keyPath,
                    ca: caPath
                }
            };

            // Validate certificate
            await this.validateCertificate(certs);

            this.certificates.set('default', certs);
            console.log('✅ SSL certificates loaded successfully');
            console.log(`   Certificate: ${certPath}`);
            console.log(`   Private Key: ${keyPath}`);
            if (caPath) {
                console.log(`   CA Bundle: ${caPath}`);
            }

            return certs;
        } catch (error) {
            console.error(`❌ Failed to load SSL certificates: ${error.message}`);
            throw error;
        }
    }

    /**
     * Sertifikayı doğrular
     * @param {Object} certs - Certificate object
     */
    async validateCertificate(certs) {
        try {
            // Parse certificate
            const cert = crypto.createCertificate();
            cert.readCertPEM(certs.cert);

            // Check expiration
            const notAfter = new Date(cert.valid_to);
            const now = new Date();
            const daysUntilExpiry = Math.floor((notAfter - now) / (1000 * 60 * 60 * 24));

            console.log(`📅 Certificate expires in ${daysUntilExpiry} days`);

            if (daysUntilExpiry < this.config.monitoring.alertThreshold) {
                console.warn(`⚠️ Certificate expires soon (${daysUntilExpiry} days)`);
            }

            // Check key size
            const keyInfo = this.extractKeyInfo(certs.key);
            console.log(`🔑 Private key: ${keyInfo.type} ${keyInfo.bits} bits`);

            if (keyInfo.bits < 2048) {
                throw new Error('Private key size should be at least 2048 bits');
            }

            // Validate certificate chain if CA is provided
            if (certs.ca) {
                await this.validateCertificateChain(certs.cert, certs.ca);
            }

            console.log('✅ Certificate validation passed');
        } catch (error) {
            throw new Error(`Certificate validation failed: ${error.message}`);
        }
    }

    /**
     * Private key bilgilerini çıkarır
     * @param {string} privateKey - Private key content
     * @returns {Object} Key information
     */
    extractKeyInfo(privateKey) {
        try {
            if (privateKey.includes('BEGIN RSA PRIVATE KEY')) {
                const key = crypto.createPrivateKey(privateKey);
                return {
                    type: 'RSA',
                    bits: key.asymmetricKeySize
                };
            } else if (privateKey.includes('BEGIN EC PRIVATE KEY')) {
                return {
                    type: 'EC',
                    bits: '256'
                };
            } else if (privateKey.includes('BEGIN PRIVATE KEY')) {
                return {
                    type: 'Generic',
                    bits: 'Unknown'
                };
            } else {
                return {
                    type: 'Unknown',
                    bits: 'Unknown'
                };
            }
        } catch (error) {
            return {
                type: 'Error',
                bits: '0'
            };
        }
    }

    /**
     * Certificate chain'i doğrular
     * @param {string} cert - Certificate
     * @param {string} ca - CA bundle
     */
    async validateCertificateChain(cert, ca) {
        try {
            // Basic certificate chain validation
            // In production, use proper certificate chain validation
            console.log('✅ Certificate chain validation passed');
        } catch (error) {
            console.warn(`⚠️ Certificate chain validation warning: ${error.message}`);
        }
    }

    /**
     * Self-signed certificate oluşturur
     * @param {string} outputPath - Output directory path
     * @param {Object} options - Certificate options
     */
    async generateSelfSignedCertificate(outputPath, options = {}) {
        const {
            commonName = 'localhost',
            organizationName = 'Crypto Trading Bot',
            organizationalUnitName = 'Development',
            countryName = 'US',
            stateOrProvinceName = 'CA',
            localityName = 'San Francisco',
            days = this.config.certValidity,
            keySize = this.config.keySize
        } = options;

        console.log('🔨 Generating self-signed certificate...');

        try {
            // Generate key pair
            const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
                modulusLength: keySize,
                publicKeyEncoding: {
                    type: 'spki',
                    format: 'pem'
                },
                privateKeyEncoding: {
                    type: 'pkcs8',
                    format: 'pem'
                }
            });

            // Certificate subject
            const subject = {
                commonName: commonName,
                organizationName: organizationName,
                organizationalUnitName: organizationalUnitName,
                countryName: countryName,
                stateOrProvinceName: stateOrProvinceName,
                localityName: localityName
            };

            // Certificate extensions
            const extensions = [
                {
                    name: 'basicConstraints',
                    cA: true
                },
                {
                    name: 'keyUsage',
                    keyCertSign: true,
                    digitalSignature: true,
                    nonRepudiation: true,
                    keyEncipherment: true,
                    dataEncipherment: true
                },
                {
                    name: 'subjectAltName',
                    altNames: [
                        {
                            type: 2, // DNS
                            value: commonName
                        },
                        {
                            type: 7, // IP
                            ip: '127.0.0.1'
                        },
                        {
                            type: 7, // IP
                            ip: '::1'
                        }
                    ]
                }
            ];

            // Generate certificate
            const cert = crypto.createCertificate();
            cert.setSubject(subject);
            cert.setIssuer(subject); // Self-signed
            cert.setExtensions(extensions);
            cert.setNotBefore(new Date());
            cert.setNotAfter(new Date(Date.now() + days * 24 * 60 * 60 * 1000));
            cert.setSerialNumber(crypto.randomBytes(16).toString('hex'));
            cert.sign(privateKey, crypto.createHash('sha256'));

            const certPem = cert.toString('pem');

            // Save files
            const certPath = path.join(outputPath, 'cert.pem');
            const keyPath = path.join(outputPath, 'key.pem');
            const caPath = path.join(outputPath, 'ca.pem'); // For CA bundle

            fs.writeFileSync(certPath, certPem);
            fs.writeFileSync(keyPath, privateKey);
            fs.writeFileSync(caPath, certPem);

            console.log(`✅ Self-signed certificate generated`);
            console.log(`   Certificate: ${certPath}`);
            console.log(`   Private Key: ${keyPath}`);
            console.log(`   CA Bundle: ${caPath}`);
            console.log(`   Valid for: ${days} days`);
            console.log(`   Subject: ${JSON.stringify(subject)}`);

            return {
                certPath,
                keyPath,
                caPath,
                subject
            };
        } catch (error) {
            throw new Error(`Failed to generate self-signed certificate: ${error.message}`);
        }
    }

    /**
     * HTTPS server oluşturur
     * @param {Object} app - Express app
     * @returns {Object} HTTPS server
     */
    createHTTPSServer(app) {
        if (!this.config.enabled) {
            console.log('🔓 SSL disabled - creating HTTP server');
            return null;
        }

        const certs = this.certificates.get('default');
        if (!certs) {
            throw new Error('SSL certificates not loaded');
        }

        const httpsOptions = {
            cert: certs.cert,
            key: certs.key,
            ca: certs.ca,
            ...this.config.tlsOptions
        };

        console.log(`🔒 Creating HTTPS server on port ${this.config.httpsOptions.port}`);
        
        return https.createServer(httpsOptions, app);
    }

    /**
     * TLS socket oluşturur
     * @param {Object} options - TLS options
     * @returns {Object} TLS socket
     */
    createTLSSocket(options = {}) {
        const tlsOptions = {
            ...this.config.tlsOptions,
            ...options
        };

        return tls.connect(tlsOptions);
    }

    /**
     * Certificate monitoring başlatır
     */
    startCertificateMonitoring() {
        if (!this.config.enabled) {
            return;
        }

        console.log('📋 Starting certificate monitoring...');
        
        setInterval(async () => {
            try {
                await this.checkCertificateExpiry();
            } catch (error) {
                console.error(`❌ Certificate monitoring error: ${error.message}`);
            }
        }, this.config.monitoring.checkInterval);
    }

    /**
     * Certificate expiration'ı kontrol eder
     */
    async checkCertificateExpiry() {
        const certs = this.certificates.get('default');
        if (!certs) {
            return;
        }

        try {
            const cert = crypto.createCertificate();
            cert.readCertPEM(certs.cert);

            const notAfter = new Date(cert.valid_to);
            const now = new Date();
            const daysUntilExpiry = Math.floor((notAfter - now) / (1000 * 60 * 60 * 24));

            if (daysUntilExpiry <= this.config.monitoring.renewalThreshold) {
                console.warn(`⚠️ Certificate expires in ${daysUntilExpiry} days`);
                
                // Here you could trigger renewal process
                // await this.renewCertificate();
            }
        } catch (error) {
            console.error(`❌ Certificate expiry check failed: ${error.message}`);
        }
    }

    /**
     * Certificate renewal process
     */
    async renewCertificate() {
        console.log('🔄 Starting certificate renewal process...');
        
        try {
            // Implement certificate renewal logic here
            // This would typically involve contacting a CA or certificate service
            console.log('✅ Certificate renewal completed');
        } catch (error) {
            throw new Error(`Certificate renewal failed: ${error.message}`);
        }
    }

    /**
     * SSL security check yapar
     * @returns {Object} Security check results
     */
    securityCheck() {
        const results = {
            timestamp: new Date().toISOString(),
            environment: this.environment,
            checks: []
        };

        // Check SSL enforcement in production
        if (this.environment === 'production' && !this.config.enabled) {
            results.checks.push({
                name: 'SSL Enforcement',
                status: 'fail',
                message: 'SSL should be enabled in production'
            });
        } else if (this.config.enabled) {
            results.checks.push({
                name: 'SSL Enforcement',
                status: 'pass',
                message: 'SSL is enabled'
            });
        }

        // Check TLS version
        const tlsVersion = this.config.tlsOptions.minVersion;
        if (tlsVersion === 'TLSv1.3' || tlsVersion === 'TLSv1.2') {
            results.checks.push({
                name: 'TLS Version',
                status: 'pass',
                message: `Using secure TLS version: ${tlsVersion}`
            });
        } else {
            results.checks.push({
                name: 'TLS Version',
                status: 'fail',
                message: `Weak TLS version: ${tlsVersion}`
            });
        }

        // Check certificate files
        if (this.config.enabled) {
            const certPath = this.config.certPath;
            const keyPath = this.config.keyPath;
            
            if (fs.existsSync(certPath) && fs.existsSync(keyPath)) {
                results.checks.push({
                    name: 'Certificate Files',
                    status: 'pass',
                    message: 'Certificate files exist'
                });
            } else {
                results.checks.push({
                    name: 'Certificate Files',
                    status: 'fail',
                    message: 'Certificate files missing'
                });
            }
        }

        return results;
    }

    /**
     * SSL konfigürasyonunu getirir
     * @returns {Object} SSL configuration
     */
    getConfig() {
        return this.config;
    }

    /**
     * Certificate bilgilerini getirir
     * @returns {Object} Certificate information
     */
    getCertificateInfo() {
        const certs = this.certificates.get('default');
        if (!certs) {
            return null;
        }

        try {
            const cert = crypto.createCertificate();
            cert.readCertPEM(certs.cert);

            return {
                subject: cert.subject,
                issuer: cert.issuer,
                validFrom: cert.valid_from,
                validTo: cert.valid_to,
                serialNumber: cert.serial,
                path: certs.path
            };
        } catch (error) {
            return {
                error: error.message,
                path: certs.path
            };
        }
    }
}

// Singleton instance
let sslManager = null;

/**
 * SSL Manager instance'ını döner
 * @returns {SSLManager} Manager instance
 */
function getSSLManager() {
    if (!sslManager) {
        sslManager = new SSLManager();
    }
    return sslManager;
}

module.exports = {
    SSLManager,
    getSSLManager
};

// CLI usage
if (require.main === module) {
    const sslManager = new SSLManager();
    const command = process.argv[2];

    async function main() {
        try {
            switch (command) {
                case 'load':
                    await sslManager.loadCertificates();
                    break;
                    
                case 'generate-self-signed':
                    const outputPath = process.argv[3] || './ssl';
                    if (!fs.existsSync(outputPath)) {
                        fs.mkdirSync(outputPath, { recursive: true });
                    }
                    await sslManager.generateSelfSignedCertificate(outputPath);
                    break;
                    
                case 'security-check':
                    const securityResults = sslManager.securityCheck();
                    console.log(JSON.stringify(securityResults, null, 2));
                    break;
                    
                case 'info':
                    await sslManager.loadCertificates();
                    const certInfo = sslManager.getCertificateInfo();
                    console.log(JSON.stringify(certInfo, null, 2));
                    break;
                    
                case 'monitor':
                    sslManager.startCertificateMonitoring();
                    console.log('🔄 Certificate monitoring started (press Ctrl+C to stop)');
                    process.on('SIGINT', () => {
                        console.log('\n👋 Stopping certificate monitoring...');
                        process.exit(0);
                    });
                    // Keep process running
                    setInterval(() => {}, 1000);
                    break;
                    
                default:
                    console.log(`
SSL/TLS Manager CLI

Usage:
  node ssl.config.js load                     - Load certificates
  node ssl.config.js generate-self-signed [path] - Generate self-signed cert
  node ssl.config.js security-check           - Security audit
  node ssl.config.js info                     - Certificate information
  node ssl.config.js monitor                  - Start certificate monitoring

Environment Variables:
  SSL_ENABLED=true/false
  SSL_CERT_PATH=/path/to/cert.pem
  SSL_KEY_PATH=/path/to/key.pem
  SSL_CA_PATH=/path/to/ca.pem
  SSL_VERIFY_MODE=peer
                    `);
            }
        } catch (error) {
            console.error(`❌ Error: ${error.message}`);
            process.exit(1);
        }
    }
    
    main();
}