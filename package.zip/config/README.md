# Environment & Secrets Management System

Bu proje, Crypto Trading Bot için kapsamlı environment variables ve secrets management sistemi sağlar. Security-first approach ile tasarlanmış, production-ready bir yapı sunar.

## 📁 Proje Yapısı

```
config/
├── .env.example                    # Environment variables template
├── environment/                    # Environment-specific configs
│   ├── dev.env                     # Development environment
│   ├── staging.env                 # Staging environment
│   └── prod.env                    # Production environment
├── scripts/                        # Management scripts
│   ├── azure-keyvault-integration.js  # Azure Key Vault integration
│   ├── environment-validator.js       # Environment validator
│   └── secrets-manager.js             # Secrets management
├── security/                       # Security configurations
│   ├── security.config.js          # Security settings
│   └── ssl.config.js               # SSL/TLS configuration
└── database.config.js              # Database configuration
```

## 🚀 Hızlı Başlangıç

### 1. Environment Setup

```bash
# Environment dosyasını kopyala
cp config/.env.example .env

# Environment-specific config yükle
node config/scripts/secrets-manager.js load development
```

### 2. Azure Key Vault Kurulumu

```bash
# Key Vault bağlantısını test et
node config/scripts/azure-keyvault-integration.js test

# Secrets'ları Key Vault'tan yükle
node config/scripts/secrets-manager.js load production
```

### 3. Configuration Validation

```bash
# Tüm konfigürasyonları doğrula
node config/scripts/environment-validator.js

# Sadece database bağlantılarını test et
node config/scripts/environment-validator.js --database-only

# Sadece security ayarlarını kontrol et
node config/scripts/environment-validator.js --security-only
```

## 🔧 Configuration Management

### Environment Types

- **Development**: Geliştirme ortamı için lokal değerler
- **Staging**: Test ortamı için production-benzeri değerler  
- **Production**: Canlı ortam için güvenli değerler

### Required Environment Variables

#### Temel Ayarlar
```bash
NODE_ENV=development|production|staging
APP_NAME=CryptoTradingBot
APP_PORT=3000
LOG_LEVEL=info|debug|error
```

#### Database Config
```bash
DB_HOST=localhost
DB_PORT=5432
DB_NAME=crypto_trading_db
DB_USER=crypto_user
DB_PASSWORD=secure_password
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=redis_password
```

#### Security Settings
```bash
JWT_SECRET=32_characters_minimum_secret_key
ENCRYPTION_KEY=32_character_exact_key
CORS_ORIGIN=https://yourdomain.com
```

#### Exchange APIs (Production)
```bash
BINANCE_API_KEY=your_binance_api_key
COINBASE_API_KEY=your_coinbase_api_key
KRAKEN_API_KEY=your_kraken_api_key
```

## 🔐 Azure Key Vault Integration

### Setup

1. **Azure Service Principal Oluştur**
```bash
az login
az ad sp create-for-rbac --name crypto-bot-keyvault --role Contributor --scopes /subscriptions/{subscription-id}
```

2. **Key Vault Oluştur**
```bash
az keyvault create --name your-keyvault --resource-group your-rg --location eastus
```

3. **Secrets Ekle**
```bash
az keyvault secret set --vault-name your-keyvault --name db-password --value "your_secure_password"
az keyvault secret set --vault-name your-keyvault --name jwt-secret --value "your_jwt_secret"
```

### Script Usage

```bash
# Key Vault'a bağlan
node config/scripts/azure-keyvault-integration.js test

# Secret'ları listele
node config/scripts/azure-keyvault-integration.js list

# Secret değerini getir
node config/scripts/azure-keyvault-integration.js get db-password

# Yeni secret ekle
node config/scripts/azure-keyvault-integration.js set-secret "secret-name" "secret-value"
```

## 🛡️ Security Features

### Security Configuration

**JWT Security**
- Minimum 32 karakter secret key
- Configurable expiration times
- Token rotation support

**Encryption**
- AES-256-GCM encryption
- Key rotation support
- Secure password hashing

**Input Validation**
- SQL injection protection
- XSS prevention
- Input sanitization

**Rate Limiting**
- Configurable request limits
- IP-based throttling
- Failed request handling

### SSL/TLS Configuration

**Self-signed Certificate Generation**
```bash
node config/security/ssl.config.js generate-self-signed ./ssl
```

**Production SSL Setup**
```bash
# Certificate files
SSL_CERT_PATH=/path/to/cert.pem
SSL_KEY_PATH=/path/to/key.pem
SSL_CA_PATH=/path/to/ca.pem

# Enable SSL
SSL_ENABLED=true
```

## 🔍 Validation & Monitoring

### Environment Validation

```bash
# Full validation
node config/scripts/environment-validator.js

# Quick check (env vars only)
node config/scripts/environment-validator.js --quick

# Database validation only
node config/scripts/environment-validator.js --database-only
```

### Security Audit

```bash
# Security check
node config/security/security.config.js audit

# Generate API key
node config/security/security.config.js generate-key api

# Hash password
node config/security/security.config.js hash-password "your_password"
```

### Certificate Monitoring

```bash
# Start certificate monitoring
node config/security/ssl.config.js monitor

# Security check
node config/security/ssl.config.js security-check

# Certificate info
node config/security/ssl.config.js info
```

## 📊 Database Management

### Connection Setup

```bash
# Initialize connections
node config/database.config.js init

# Test connections
node config/database.config.js test

# Health check
node config/database.config.js health

# Backup database
node config/database.config.js backup ./backup.sql
```

### Supported Databases

- **PostgreSQL**: Primary database with connection pooling
- **Redis**: Caching and session storage
- **MongoDB**: Logs and analytics storage

## 🔑 Secrets Management

### Secret Types

- **Database credentials**: PostgreSQL, Redis, MongoDB
- **API keys**: Exchange APIs, external services
- **JWT secrets**: Authentication tokens
- **Encryption keys**: Data encryption
- **Notification tokens**: Telegram, Slack, Discord

### Script Usage

```bash
# Load environment
node config/scripts/secrets-manager.js load development

# Validate secrets
node config/scripts/secrets-manager.js validate

# Generate new secret
node config/scripts/secrets-manager.js generate password --length 20

# Rotate secret
node config/scripts/secrets-manager.js rotate DB_PASSWORD

# List all secrets (masked)
node config/scripts/secrets-manager.js list

# Backup secrets
node config/scripts/secrets-manager.js backup ./secrets-backup.json
```

## 🔒 Security Best Practices

### Development vs Production

**Development**
- Local values acceptable
- Sandbox API endpoints
- Debug enabled
- Localhost CORS

**Production**
- Azure Key Vault mandatory
- Live API endpoints
- Debug disabled
- HTTPS enforcement
- Strong secrets

### Secret Rotation

```javascript
// Automatic rotation
const securityManager = require('./config/security/security.config.js');
const newSecret = securityManager.rotateSecret('jwt');
```

### Input Sanitization

```javascript
const securityManager = require('./config/security/security.config.js');
const result = securityManager.validateInput(userInput);
if (!result.valid) {
    console.error('Invalid input:', result.errors);
}
```

## 🚨 Troubleshooting

### Common Issues

**Azure Key Vault Connection Failed**
```bash
# Check credentials
echo $AZURE_CLIENT_ID
echo $AZURE_TENANT_ID

# Test connection
node config/scripts/azure-keyvault-integration.js test
```

**Database Connection Issues**
```bash
# Test database connections
node config/database.config.js test

# Check environment variables
node config/scripts/environment-validator.js --database-only
```

**SSL Certificate Issues**
```bash
# Generate self-signed for development
node config/security/ssl.config.js generate-self-signed ./ssl

# Check certificate info
node config/security/ssl.config.js info
```

### Debug Mode

```bash
# Enable debug logging
LOG_LEVEL=debug node config/scripts/environment-validator.js

# Verbose output
node config/scripts/secrets-manager.js load development --verbose
```

## 📝 Environment Templates

### Development Template
```bash
# Safe local values
NODE_ENV=development
DB_PASSWORD=dev_password_123
JWT_SECRET=dev-secret-change-in-production
BINANCE_SANDBOX=true
```

### Production Template
```bash
# Azure Key Vault references
NODE_ENV=production
DB_PASSWORD=KEY_VAULT_REF:db-password
JWT_SECRET=KEY_VAULT_REF:jwt-secret
BINANCE_SANDBOX=false
SSL_ENABLED=true
```

## 🎯 Next Steps

1. **Configure Azure Key Vault** for production secrets
2. **Set up SSL certificates** for production HTTPS
3. **Configure monitoring** and alerting
4. **Implement backup procedures**
5. **Set up CI/CD integration** for automated validation

## 🔧 Dependencies

Required Node.js packages:
```json
{
  "pg": "^8.8.0",
  "redis": "^4.5.1",
  "mongodb": "^4.12.0",
  "@azure/identity": "^3.1.0",
  "@azure/keyvault-secrets": "^4.6.0",
  "jsonwebtoken": "^9.0.0",
  "dotenv": "^16.0.0"
}
```

Install dependencies:
```bash
npm install pg redis mongodb @azure/identity @azure/keyvault-secrets jsonwebtoken dotenv
```

## 📞 Support

Environment ve secrets management sistemi hakkında yardım için:
1. Validation script'lerini çalıştır
2. Security audit yap
3. Logs'ları kontrol et
4. Azure Key Vault connectivity test et

Bu sistem production-ready, security-first bir yaklaşımla tasarlanmıştır ve Crypto Trading Bot projesinin güvenli ve yönetilebilir environment setup'ını sağlar.