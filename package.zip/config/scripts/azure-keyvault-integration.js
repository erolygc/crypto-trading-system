/**
 * Azure Key Vault Integration Module
 * 
 * Bu modül Azure Key Vault ile güvenli secret yönetimi sağlar.
 * Tüm sensitive bilgiler buradan çekilir ve local olarak saklanmaz.
 * 
 * @author Crypto Trading Bot Team
 * @version 1.0.0
 */

const { DefaultAzureCredential, ClientSecretCredential } = require('@azure/identity');
const { SecretClient } = require('@azure/keyvault-secrets');
const fs = require('fs');
const path = require('path');

class AzureKeyVaultManager {
    constructor(config = {}) {
        this.keyVaultUrl = config.keyVaultUrl || process.env.AZURE_KEY_VAULT_URL;
        this.tenantId = config.tenantId || process.env.AZURE_TENANT_ID;
        this.clientId = config.clientId || process.env.AZURE_CLIENT_ID;
        this.clientSecret = config.clientSecret || process.env.AZURE_CLIENT_SECRET;
        this.enabled = config.enabled || process.env.AZURE_KEY_VAULT_ENABLED === 'true';
        
        this.secretClient = null;
        this.credential = null;
        this.cache = new Map();
        this.cacheExpiry = 5 * 60 * 1000; // 5 dakika
        
        this.init();
    }

    /**
     * Azure Key Vault client'ını initialize eder
     */
    init() {
        if (!this.enabled) {
            console.warn('🔓 Azure Key Vault disabled - using environment variables');
            return;
        }

        if (!this.keyVaultUrl || !this.tenantId || !this.clientId || !this.clientSecret) {
            throw new Error('❌ Azure Key Vault configuration incomplete. Required: KEY_VAULT_URL, TENANT_ID, CLIENT_ID, CLIENT_SECRET');
        }

        try {
            // Service Principal ile authentication
            this.credential = new ClientSecretCredential(this.tenantId, this.clientId, this.clientSecret);
            this.secretClient = new SecretClient(this.keyVaultUrl, this.credential);
            console.log('✅ Azure Key Vault client initialized successfully');
        } catch (error) {
            console.error('❌ Failed to initialize Azure Key Vault:', error.message);
            throw error;
        }
    }

    /**
     * Secret değeri getirir (cache ile)
     * @param {string} secretName - Secret adı
     * @param {string} version - Secret versiyonu (opsiyonel)
     * @returns {Promise<string>} Secret değeri
     */
    async getSecret(secretName, version = '') {
        if (!this.enabled) {
            const envVar = this.getEnvVarName(secretName);
            const value = process.env[envVar];
            if (!value) {
                throw new Error(`❌ Environment variable ${envVar} not found`);
            }
            return value;
        }

        const cacheKey = `${secretName}:${version}`;
        const cached = this.cache.get(cacheKey);
        
        if (cached && (Date.now() - cached.timestamp) < this.cacheExpiry) {
            return cached.value;
        }

        try {
            const secret = await this.secretClient.getSecret(secretName, { version });
            const value = secret.value;
            
            // Cache'e ekle
            this.cache.set(cacheKey, {
                value: value,
                timestamp: Date.now()
            });
            
            return value;
        } catch (error) {
            console.error(`❌ Failed to get secret ${secretName}:`, error.message);
            throw new Error(`Secret retrieval failed: ${error.message}`);
        }
    }

    /**
     * Birden fazla secret'ı batch olarak getirir
     * @param {Array<string>} secretNames - Secret adları
     * @returns {Promise<Object>} Secret adları ve değerleri içeren obje
     */
    async getSecrets(secretNames) {
        const results = {};
        const errors = {};

        for (const secretName of secretNames) {
            try {
                results[secretName] = await this.getSecret(secretName);
            } catch (error) {
                errors[secretName] = error.message;
            }
        }

        if (Object.keys(errors).length > 0) {
            console.warn('⚠️ Some secrets failed to retrieve:', errors);
        }

        return { secrets: results, errors };
    }

    /**
     * Yeni secret oluşturur/günceller
     * @param {string} secretName - Secret adı
     * @param {string} secretValue - Secret değeri
     * @param {Object} options - Ek seçenekler
     */
    async setSecret(secretName, secretValue, options = {}) {
        if (!this.enabled) {
            throw new Error('❌ Cannot set secret - Azure Key Vault disabled');
        }

        try {
            const contentType = options.contentType || 'text/plain';
            const tags = options.tags || {
                'created-date': new Date().toISOString(),
                'created-by': 'crypto-bot',
                'environment': process.env.NODE_ENV || 'development'
            };

            await this.secretClient.setSecret(secretName, secretValue, {
                contentType,
                tags
            });

            // Cache'i temizle
            this.cache.delete(secretName);
            
            console.log(`✅ Secret ${secretName} set successfully`);
        } catch (error) {
            console.error(`❌ Failed to set secret ${secretName}:`, error.message);
            throw error;
        }
    }

    /**
     * Secret'ı siler
     * @param {string} secretName - Secret adı
     */
    async deleteSecret(secretName) {
        if (!this.enabled) {
            throw new Error('❌ Cannot delete secret - Azure Key Vault disabled');
        }

        try {
            await this.secretClient.beginDeleteSecret(secretName);
            
            // Cache'i temizle
            this.cache.delete(secretName);
            
            console.log(`✅ Secret ${secretName} deletion initiated`);
        } catch (error) {
            console.error(`❌ Failed to delete secret ${secretName}:`, error.message);
            throw error;
        }
    }

    /**
     * Tüm secret'ları listeler
     * @returns {Promise<Array>} Secret listesi
     */
    async listSecrets() {
        if (!this.enabled) {
            return [];
        }

        try {
            const secrets = [];
            for await (const secretProperties of this.secretClient.listPropertiesOfSecrets()) {
                secrets.push({
                    name: secretProperties.name,
                    enabled: secretProperties.enabled,
                    created: secretProperties.createdOn,
                    updated: secretProperties.updatedOn,
                    tags: secretProperties.tags
                });
            }
            return secrets;
        } catch (error) {
            console.error('❌ Failed to list secrets:', error.message);
            throw error;
        }
    }

    /**
     * Environment variable adını secret adından çevirir
     * @param {string} secretName - Secret adı
     * @returns {string} Environment variable adı
     */
    getEnvVarName(secretName) {
        // Secret naming convention'ı
        // Example: DB_PASSWORD -> db-password (Key Vault'ta)
        return secretName.toUpperCase().replace(/_/g, '-');
    }

    /**
     * Secret adını environment variable adından çevirir
     * @param {string} envVarName - Environment variable adı
     * @returns {string} Secret adı
     */
    getSecretName(envVarName) {
        // Example: DB_PASSWORD -> db-password
        return envVarName.toLowerCase().replace(/_/g, '-');
    }

    /**
     * Bağlantı durumunu test eder
     * @returns {Promise<boolean>} Bağlantı durumu
     */
    async testConnection() {
        if (!this.enabled) {
            return false;
        }

        try {
            const secrets = await this.listSecrets();
            console.log(`✅ Azure Key Vault connection test successful - ${secrets.length} secrets found`);
            return true;
        } catch (error) {
            console.error('❌ Azure Key Vault connection test failed:', error.message);
            return false;
        }
    }

    /**
     * Cache'i temizler
     */
    clearCache() {
        this.cache.clear();
        console.log('🧹 Azure Key Vault cache cleared');
    }

    /**
     * Environment variables'ı Key Vault'den yükler ve process.env'ye set eder
     * @param {Array<string>} requiredVars - Gerekli environment variables listesi
     */
    async loadEnvironmentVariables(requiredVars = []) {
        const secretNames = requiredVars.map(envVar => this.getSecretName(envVar));
        const { secrets, errors } = await this.getSecrets(secretNames);

        // Başarılı olanları set et
        for (const [envVar, secretName] of requiredVars.map((varName, index) => [varName, secretNames[index]])) {
            if (secrets[secretName] && !errors[secretName]) {
                process.env[envVar] = secrets[secretName];
            } else if (errors[secretName]) {
                console.error(`❌ Failed to load ${envVar}: ${errors[secretName]}`);
            }
        }

        return { secrets: secrets, errors: errors };
    }
}

// Singleton instance
let keyVaultManager = null;

/**
 * Key Vault Manager instance'ını döner
 * @param {Object} config - Configuration objesi
 * @returns {AzureKeyVaultManager} Manager instance
 */
function getKeyVaultManager(config = {}) {
    if (!keyVaultManager) {
        keyVaultManager = new AzureKeyVaultManager(config);
    }
    return keyVaultManager;
}

module.exports = {
    AzureKeyVaultManager,
    getKeyVaultManager
};

// CLI usage
if (require.main === module) {
    async function main() {
        const command = process.argv[2];
        const args = process.argv.slice(3);

        try {
            const manager = getKeyVaultManager();
            
            switch (command) {
                case 'test':
                    const isConnected = await manager.testConnection();
                    process.exit(isConnected ? 0 : 1);
                    break;
                    
                case 'list':
                    const secrets = await manager.listSecrets();
                    console.log(JSON.stringify(secrets, null, 2));
                    break;
                    
                case 'get':
                    const secretName = args[0];
                    if (!secretName) {
                        console.error('❌ Usage: node azure-keyvault-integration.js get <secret-name>');
                        process.exit(1);
                    }
                    const value = await manager.getSecret(secretName);
                    console.log(value);
                    break;
                    
                default:
                    console.log(`
Azure Key Vault Integration CLI

Usage:
  node azure-keyvault-integration.js test                    - Test connection
  node azure-keyvault-integration.js list                   - List all secrets
  node azure-keyvault-integration.js get <secret-name>      - Get secret value

Environment Variables:
  AZURE_KEY_VAULT_URL      - Key Vault URL
  AZURE_TENANT_ID          - Azure Tenant ID
  AZURE_CLIENT_ID          - Service Principal Client ID
  AZURE_CLIENT_SECRET      - Service Principal Secret
  AZURE_KEY_VAULT_ENABLED  - Enable/disable (true/false)
                    `);
            }
        } catch (error) {
            console.error('❌ Error:', error.message);
            process.exit(1);
        }
    }
    
    main();
}