#!/usr/bin/env node

/**
 * Secrets Management System
 * 
 * Bu modül güvenli secret yönetimi sağlar:
 * - Environment variables'ları doğru şekilde yükler
 * - Azure Key Vault ile entegrasyon
 * - Development vs Production secret handling
 * - Secret rotation ve güncelleme
 * 
 * @author Crypto Trading Bot Team
 * @version 1.0.0
 */

const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');
const { getKeyVaultManager } = require('./azure-keyvault-integration.js');

// ANSI color codes
const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    cyan: '\x1b[36m'
};

class SecretsManager {
    constructor(config = {}) {
        this.configPath = config.configPath || path.join(process.cwd(), 'config');
        this.keyVaultManager = getKeyVaultManager(config.keyVault || {});
        this.environment = config.environment || process.env.NODE_ENV || 'development';
        this.secrets = new Map();
        this.validationRules = this.initValidationRules();
    }

    /**
     * Validation kurallarını başlatır
     */
    initValidationRules() {
        return {
            // Database credentials
            'DB_PASSWORD': {
                required: ['development', 'staging', 'production'],
                minLength: 8,
                patterns: [/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, 'Must contain uppercase, lowercase, and number']
            },
            
            // JWT Secret
            'JWT_SECRET': {
                required: ['development', 'staging', 'production'],
                minLength: 32,
                description: 'Must be at least 32 characters'
            },
            
            // Encryption Key
            'ENCRYPTION_KEY': {
                required: ['development', 'staging', 'production'],
                length: 32,
                description: 'Must be exactly 32 characters'
            },
            
            // API Keys
            'BINANCE_API_KEY': {
                required: ['staging', 'production'],
                minLength: 32,
                environment: 'production'
            },
            'COINBASE_API_KEY': {
                required: ['staging', 'production'],
                minLength: 32,
                environment: 'production'
            },
            'KRAKEN_API_KEY': {
                required: ['staging', 'production'],
                minLength: 32,
                environment: 'production'
            },
            
            // External APIs
            'ALPHA_VANTAGE_API_KEY': {
                required: ['staging', 'production'],
                minLength: 16
            },
            'SENDGRID_API_KEY': {
                required: ['staging', 'production'],
                minLength: 69
            },
            
            // Notification Services
            'TELEGRAM_BOT_TOKEN': {
                required: ['production'],
                minLength: 45,
                patterns: [/^\d+:[a-zA-Z0-9_-]{35}$/, 'Must be in format: number:hash']
            }
        };
    }

    /**
     * Environment dosyasını yükler
     * @param {string} envType - Environment type (dev, staging, prod)
     * @returns {Object} Environment variables
     */
    async loadEnvironment(envType = null) {
        if (!envType) {
            envType = this.environment;
        }

        console.log(`${colors.cyan}🔧 Loading environment: ${envType}${colors.reset}`);

        const envFile = path.join(this.configPath, 'environment', `${envType}.env`);
        const envExampleFile = path.join(this.configPath, '.env.example');

        let envVars = {};

        // Load environment-specific file
        if (fs.existsSync(envFile)) {
            const envConfig = dotenv.parse(fs.readFileSync(envFile, 'utf8'));
            envVars = { ...envVars, ...envConfig };
            console.log(`${colors.green}✅ Loaded ${envType}.env${colors.reset}`);
        } else {
            console.log(`${colors.yellow}⚠️ ${envType}.env not found${colors.reset}`);
        }

        // Load example file for reference
        if (fs.existsSync(envExampleFile)) {
            const exampleConfig = dotenv.parse(fs.readFileSync(envExampleFile, 'utf8'));
            Object.keys(exampleConfig).forEach(key => {
                if (!envVars[key]) {
                    envVars[key] = exampleConfig[key];
                }
            });
            console.log(`${colors.green}✅ Loaded .env.example${colors.reset}`);
        }

        // Load from Azure Key Vault if enabled
        if (process.env.AZURE_KEY_VAULT_ENABLED === 'true') {
            await this.loadFromKeyVault(envVars);
        }

        // Apply environment variables
        this.applyToProcess(envVars);
        
        return envVars;
    }

    /**
     * Azure Key Vault'den secret'ları yükler
     * @param {Object} envVars - Mevcut environment variables
     */
    async loadFromKeyVault(envVars) {
        console.log(`${colors.cyan}🔐 Loading secrets from Azure Key Vault...${colors.reset}`);

        try {
            const keyVaultSecrets = [
                'db-password',
                'redis-password',
                'mongo-uri',
                'binance-api-key',
                'binance-secret-key',
                'coinbase-api-key',
                'coinbase-secret-key',
                'kraken-api-key',
                'kraken-private-key',
                'alpha-vantage-api-key',
                'news-api-key',
                'telegram-bot-token',
                'sendgrid-api-key',
                'jwt-secret',
                'encryption-key'
            ];

            const { secrets, errors } = await this.keyVaultManager.getSecrets(keyVaultSecrets);

            // Apply secrets that were successfully retrieved
            Object.entries(secrets).forEach(([secretName, value]) => {
                const envVarName = this.keyVaultManager.getEnvVarName(secretName);
                envVars[envVarName] = value;
                console.log(`${colors.green}✅ Loaded ${envVarName} from Key Vault${colors.reset}`);
            });

            // Log errors
            Object.entries(errors).forEach(([secretName, error]) => {
                console.log(`${colors.red}❌ Failed to load ${secretName}: ${error}${colors.reset}`);
            });

        } catch (error) {
            console.log(`${colors.red}❌ Key Vault error: ${error.message}${colors.reset}`);
        }
    }

    /**
     * Environment variables'ları process.env'ye uygular
     * @param {Object} envVars - Environment variables
     */
    applyToProcess(envVars) {
        Object.entries(envVars).forEach(([key, value]) => {
            if (value !== undefined && value !== null && value !== '') {
                process.env[key] = value;
                this.secrets.set(key, value);
            }
        });
    }

    /**
     * Secret validation kurallarını çalıştırır
     * @param {Object} envVars - Environment variables
     * @returns {Object} Validation results
     */
    validateSecrets(envVars) {
        console.log(`\n${colors.bright}🔍 Validating Secrets${colors.reset}\n`);

        const results = {
            passed: [],
            failed: [],
            warnings: []
        };

        Object.entries(this.validationRules).forEach(([secretName, rules]) => {
            const secretValue = envVars[secretName];
            const isRequired = rules.required.includes(this.environment);

            if (!secretValue) {
                if (isRequired) {
                    results.failed.push({
                        secret: secretName,
                        issue: 'Missing required secret',
                        rule: rules
                    });
                } else {
                    results.warnings.push({
                        secret: secretName,
                        issue: 'Optional secret not provided',
                        rule: rules
                    });
                }
                return;
            }

            // Check minimum length
            if (rules.minLength && secretValue.length < rules.minLength) {
                results.failed.push({
                    secret: secretName,
                    issue: `Secret too short (${secretValue.length}/${rules.minLength} chars)`,
                    rule: rules
                });
                return;
            }

            // Check exact length
            if (rules.length && secretValue.length !== rules.length) {
                results.failed.push({
                    secret: secretName,
                    issue: `Secret must be exactly ${rules.length} characters`,
                    rule: rules
                });
                return;
            }

            // Check patterns
            if (rules.patterns) {
                for (const pattern of rules.patterns) {
                    if (typeof pattern === 'object' && pattern.test && !pattern.test(secretValue)) {
                        results.failed.push({
                            secret: secretName,
                            issue: typeof pattern === 'string' ? pattern : 'Pattern validation failed',
                            rule: rules
                        });
                        return;
                    }
                }
            }

            // All validations passed
            results.passed.push({
                secret: secretName,
                length: secretValue.length,
                rule: rules
            });
        });

        // Print results
        this.printValidationResults(results);
        
        return results;
    }

    /**
     * Validation sonuçlarını yazdırır
     * @param {Object} results - Validation results
     */
    printValidationResults(results) {
        if (results.passed.length > 0) {
            console.log(`${colors.green}✅ Passed (${results.passed.length}):${colors.reset}`);
            results.passed.forEach(result => {
                console.log(`   ${result.secret} (${result.length} chars)`);
            });
        }

        if (results.warnings.length > 0) {
            console.log(`\n${colors.yellow}⚠️ Warnings (${results.warnings.length}):${colors.reset}`);
            results.warnings.forEach(result => {
                console.log(`   ${result.secret}: ${result.issue}`);
            });
        }

        if (results.failed.length > 0) {
            console.log(`\n${colors.red}❌ Failed (${results.failed.length}):${colors.reset}`);
            results.failed.forEach(result => {
                console.log(`   ${result.secret}: ${result.issue}`);
            });
        }
    }

    /**
     * Secret'ı güvenli bir şekilde generate eder
     * @param {string} type - Secret type (password, jwt-secret, encryption-key, etc.)
     * @param {Object} options - Generation options
     * @returns {string} Generated secret
     */
    generateSecret(type, options = {}) {
        const crypto = require('crypto');
        
        switch (type) {
            case 'password':
                return this.generateSecurePassword(options);
                
            case 'jwt-secret':
                return crypto.randomBytes(48).toString('hex');
                
            case 'encryption-key':
                return crypto.randomBytes(32).toString('utf8');
                
            case 'api-key':
                return crypto.randomBytes(32).toString('hex');
                
            case 'token':
                return crypto.randomBytes(40).toString('base64');
                
            default:
                return crypto.randomBytes(32).toString('hex');
        }
    }

    /**
     * Güvenli password generate eder
     * @param {Object} options - Password options
     * @returns {string} Generated password
     */
    generateSecurePassword(options = {}) {
        const {
            length = 16,
            includeUppercase = true,
            includeLowercase = true,
            includeNumbers = true,
            includeSpecialChars = true
        } = options;

        const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const lowercase = 'abcdefghijklmnopqrstuvwxyz';
        const numbers = '0123456789';
        const specialChars = '!@#$%^&*()_+-=[]{}|;:,.<>?';

        let chars = '';
        if (includeLowercase) chars += lowercase;
        if (includeUppercase) chars += uppercase;
        if (includeNumbers) chars += numbers;
        if (includeSpecialChars) chars += specialChars;

        if (chars === '') {
            throw new Error('At least one character type must be selected');
        }

        let password = '';
        for (let i = 0; i < length; i++) {
            password += chars.charAt(Math.floor(Math.random() * chars.length));
        }

        // Ensure at least one character from each selected type
        if (includeLowercase && !/[a-z]/.test(password)) {
            password = password.substring(1) + lowercase.charAt(Math.floor(Math.random() * lowercase.length));
        }
        if (includeUppercase && !/[A-Z]/.test(password)) {
            password = password.substring(1) + uppercase.charAt(Math.floor(Math.random() * uppercase.length));
        }
        if (includeNumbers && !/[0-9]/.test(password)) {
            password = password.substring(1) + numbers.charAt(Math.floor(Math.random() * numbers.length));
        }
        if (includeSpecialChars && !/[!@#$%^&*()_+\-=\[\]{}|;:,.<>?]/.test(password)) {
            password = password.substring(1) + specialChars.charAt(Math.floor(Math.random() * specialChars.length));
        }

        return password;
    }

    /**
     * Secret rotation işlemini yönetir
     * @param {string} secretName - Secret adı
     * @param {Object} options - Rotation options
     */
    async rotateSecret(secretName, options = {}) {
        console.log(`${colors.cyan}🔄 Rotating secret: ${secretName}${colors.reset}`);

        const rules = this.validationRules[secretName];
        if (!rules) {
            throw new Error(`No rotation rules defined for ${secretName}`);
        }

        const newSecret = this.generateSecret(
            options.type || 'api-key',
            options.generatorOptions || {}
        );

        if (process.env.AZURE_KEY_VAULT_ENABLED === 'true') {
            // Update in Key Vault
            await this.keyVaultManager.setSecret(secretName.toLowerCase().replace(/_/g, '-'), newSecret, {
                contentType: 'text/plain',
                tags: {
                    'rotation-date': new Date().toISOString(),
                    'rotated-by': 'secrets-manager',
                    'environment': this.environment
                }
            });
            console.log(`${colors.green}✅ Secret rotated in Key Vault${colors.reset}`);
        } else {
            // Update in environment
            process.env[secretName] = newSecret;
            console.log(`${colors.yellow}⚠️ Updated in environment only (not in Key Vault)${colors.reset}`);
        }

        return newSecret;
    }

    /**
     * Tüm secrets'ları listeler
     * @returns {Object} Secrets list
     */
    listSecrets() {
        const secrets = {};
        this.secrets.forEach((value, key) => {
            // Mask sensitive values
            if (this.isSensitiveKey(key)) {
                secrets[key] = '*'.repeat(8);
            } else {
                secrets[key] = value;
            }
        });
        return secrets;
    }

    /**
     * Key'in sensitive olup olmadığını kontrol eder
     * @param {string} key - Environment variable key
     * @returns {boolean} Is sensitive
     */
    isSensitiveKey(key) {
        const sensitivePatterns = [
            /password/i,
            /secret/i,
            /key/i,
            /token/i,
            /private/i,
            /credential/i
        ];
        return sensitivePatterns.some(pattern => pattern.test(key));
    }

    /**
     * Secret backup'ı oluşturur
     * @param {string} outputPath - Backup dosya yolu
     */
    backupSecrets(outputPath) {
        const backup = {
            environment: this.environment,
            timestamp: new Date().toISOString(),
            secrets: this.listSecrets(),
            validationRules: this.validationRules
        };

        fs.writeFileSync(outputPath, JSON.stringify(backup, null, 2));
        console.log(`${colors.green}✅ Secrets backed up to: ${outputPath}${colors.reset}`);
    }

    /**
     * CLI interface
     */
    static getCLI() {
        return {
            commands: {
                'load <env>': 'Load environment configuration',
                'validate': 'Validate current secrets',
                'generate <type>': 'Generate a new secret',
                'rotate <secret>': 'Rotate a specific secret',
                'list': 'List all secrets (masked)',
                'backup <path>': 'Backup secrets to file',
                'help': 'Show this help message'
            },
            examples: [
                'node secrets-manager.js load development',
                'node secrets-manager.js validate',
                'node secrets-manager.js generate password --length 20',
                'node secrets-manager.js rotate DB_PASSWORD',
                'node secrets-manager.js list',
                'node secrets-manager.js backup ./secrets-backup.json'
            ]
        };
    }
}

// CLI usage
function main() {
    const args = process.argv.slice(2);
    const command = args[0];
    const param = args[1];

    const secretsManager = new SecretsManager();

    switch (command) {
        case 'load':
            secretsManager.loadEnvironment(param).then(() => {
                console.log(`${colors.green}✅ Environment loaded successfully${colors.reset}`);
            }).catch(error => {
                console.error(`${colors.red}❌ Failed to load environment: ${error.message}${colors.reset}`);
                process.exit(1);
            });
            break;

        case 'validate':
            secretsManager.validateSecrets(process.env);
            break;

        case 'generate':
            const type = param || 'api-key';
            const generated = secretsManager.generateSecret(type);
            console.log(`Generated ${type}:`);
            console.log(generated);
            break;

        case 'rotate':
            if (!param) {
                console.log('❌ Secret name required: node secrets-manager.js rotate <secret-name>');
                process.exit(1);
            }
            secretsManager.rotateSecret(param).then(() => {
                console.log(`${colors.green}✅ Secret rotated successfully${colors.reset}`);
            }).catch(error => {
                console.error(`${colors.red}❌ Failed to rotate secret: ${error.message}${colors.reset}`);
                process.exit(1);
            });
            break;

        case 'list':
            const secrets = secretsManager.listSecrets();
            console.log(JSON.stringify(secrets, null, 2));
            break;

        case 'backup':
            const backupPath = param || './secrets-backup.json';
            secretsManager.backupSecrets(backupPath);
            break;

        case 'help':
        default:
            const cli = SecretsManager.getCLI();
            console.log(`
${colors.bright}Secrets Manager CLI${colors.reset}

Usage:
  node secrets-manager.js <command> [options]

Commands:
${Object.entries(cli.commands).map(([cmd, desc]) => `  ${cmd.padEnd(15)} ${desc}`).join('\n')}

Examples:
${cli.examples.map(example => `  ${example}`).join('\n')}
            `);
    }
}

if (require.main === module) {
    main();
}

module.exports = { SecretsManager };