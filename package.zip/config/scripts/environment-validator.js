#!/usr/bin/env node

/**
 * Environment Configuration Validator
 * 
 * Bu script environment configuration'ları doğrular:
 * - Gerekli environment variables'ların varlığını kontrol eder
 * - Database connection'ları test eder
 * - External API bağlantılarını kontrol eder
 * - Security configuration'ları validate eder
 * 
 * @author Crypto Trading Bot Team
 * @version 1.0.0
 */

const fs = require('fs');
const path = require('path');
const { Client } = require('pg');
const Redis = require('redis');
const { MongoClient } = require('mongodb');
const { getKeyVaultManager } = require('./azure-keyvault-integration.js');

// ANSI color codes
const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    cyan: '\x1b[36m'
};

class EnvironmentValidator {
    constructor() {
        this.results = {
            passed: 0,
            failed: 0,
            warnings: 0,
            total: 0,
            tests: []
        };
        this.keyVaultManager = getKeyVaultManager();
    }

    /**
     * Test sonucu kaydeder
     */
    addResult(testName, status, message, details = null) {
        const result = {
            name: testName,
            status: status, // 'pass', 'fail', 'warning'
            message: message,
            details: details,
            timestamp: new Date().toISOString()
        };

        this.results.tests.push(result);
        this.results.total++;

        if (status === 'pass') {
            this.results.passed++;
            console.log(`${colors.green}✅ PASS${colors.reset} ${testName}: ${message}`);
        } else if (status === 'fail') {
            this.results.failed++;
            console.log(`${colors.red}❌ FAIL${colors.reset} ${testName}: ${message}`);
        } else if (status === 'warning') {
            this.results.warnings++;
            console.log(`${colors.yellow}⚠️ WARN${colors.reset} ${testName}: ${message}`);
        }

        if (details) {
            console.log(`${colors.cyan}   Details:${colors.reset}`, JSON.stringify(details, null, 2));
        }
    }

    /**
     * Environment variable varlığını kontrol eder
     */
    async validateEnvironmentVariables() {
        console.log(`\n${colors.bright}🔍 Validating Environment Variables${colors.reset}\n`);

        // Required variables for basic operation
        const requiredVars = [
            'NODE_ENV',
            'APP_NAME',
            'APP_PORT',
            'JWT_SECRET',
            'ENCRYPTION_KEY'
        ];

        // Required for different environments
        const requiredForDev = ['DB_PASSWORD'];
        const requiredForProd = [
            'BINANCE_API_KEY',
            'COINBASE_API_KEY',
            'KRAKEN_API_KEY'
        ];

        const environment = process.env.NODE_ENV || 'development';
        
        // Check if we can load from Key Vault
        if (process.env.AZURE_KEY_VAULT_ENABLED === 'true') {
            try {
                // Test Key Vault connection
                const keyVaultConnected = await this.keyVaultManager.testConnection();
                if (keyVaultConnected) {
                    this.addResult(
                        'Key Vault Connection',
                        'pass',
                        'Successfully connected to Azure Key Vault'
                    );
                } else {
                    this.addResult(
                        'Key Vault Connection',
                        'fail',
                        'Failed to connect to Azure Key Vault'
                    );
                }
            } catch (error) {
                this.addResult(
                    'Key Vault Connection',
                    'fail',
                    `Key Vault error: ${error.message}`
                );
            }
        }

        // Check environment variables
        let missingVars = [];
        for (const varName of requiredVars) {
            if (!process.env[varName]) {
                missingVars.push(varName);
            }
        }

        if (environment === 'production') {
            for (const varName of requiredForProd) {
                if (!process.env[varName]) {
                    missingVars.push(varName);
                }
            }
        } else if (environment === 'development') {
            for (const varName of requiredForDev) {
                if (!process.env[varName]) {
                    missingVars.push(varName);
                }
            }
        }

        if (missingVars.length === 0) {
            this.addResult(
                'Required Environment Variables',
                'pass',
                'All required environment variables are present'
            );
        } else {
            this.addResult(
                'Required Environment Variables',
                'fail',
                `Missing environment variables: ${missingVars.join(', ')}`,
                { missing: missingVars }
            );
        }

        // Validate specific formats
        await this.validateVariableFormats();
    }

    /**
     * Environment variable formatlarını kontrol eder
     */
    async validateVariableFormats() {
        const formatValidations = [
            {
                varName: 'JWT_SECRET',
                test: (value) => value && value.length >= 32,
                message: 'JWT secret should be at least 32 characters'
            },
            {
                varName: 'ENCRYPTION_KEY',
                test: (value) => value && value.length === 32,
                message: 'Encryption key should be exactly 32 characters'
            },
            {
                varName: 'APP_PORT',
                test: (value) => value && parseInt(value) > 0 && parseInt(value) < 65536,
                message: 'APP_PORT should be a valid port number'
            },
            {
                varName: 'NODE_ENV',
                test: (value) => ['development', 'staging', 'production'].includes(value),
                message: 'NODE_ENV should be development, staging, or production'
            }
        ];

        for (const validation of formatValidations) {
            const value = process.env[validation.varName];
            if (value) {
                const isValid = validation.test(value);
                if (isValid) {
                    this.addResult(
                        `Format: ${validation.varName}`,
                        'pass',
                        `${validation.varName} format is valid`
                    );
                } else {
                    this.addResult(
                        `Format: ${validation.varName}`,
                        'fail',
                        validation.message,
                        { value: value, varName: validation.varName }
                    );
                }
            }
        }
    }

    /**
     * Database bağlantılarını test eder
     */
    async validateDatabaseConnections() {
        console.log(`\n${colors.bright}🗄️ Validating Database Connections${colors.reset}\n`);

        // Test PostgreSQL
        await this.validatePostgreSQL();
        
        // Test Redis
        await this.validateRedis();
        
        // Test MongoDB
        await this.validateMongoDB();
    }

    /**
     * PostgreSQL bağlantısını test eder
     */
    async validatePostgreSQL() {
        const dbConfig = {
            host: process.env.DB_HOST,
            port: process.env.DB_PORT,
            database: process.env.DB_NAME,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            ssl: process.env.DB_SSL === 'true'
        };

        // Check if all required DB config exists
        const requiredDbVars = ['DB_HOST', 'DB_NAME', 'DB_USER'];
        const missingDbVars = requiredDbVars.filter(varName => !process.env[varName]);

        if (missingDbVars.length > 0) {
            this.addResult(
                'PostgreSQL Configuration',
                'warning',
                `Missing PostgreSQL config variables: ${missingDbVars.join(', ')}`
            );
            return;
        }

        try {
            const client = new Client(dbConfig);
            await client.connect();
            
            const result = await client.query('SELECT NOW() as current_time, version() as version');
            const currentTime = result.rows[0].current_time;
            const version = result.rows[0].version;
            
            await client.end();
            
            this.addResult(
                'PostgreSQL Connection',
                'pass',
                'Successfully connected to PostgreSQL',
                { currentTime, version }
            );
        } catch (error) {
            this.addResult(
                'PostgreSQL Connection',
                'fail',
                `PostgreSQL connection failed: ${error.message}`,
                { config: { ...dbConfig, password: '***' } }
            );
        }
    }

    /**
     * Redis bağlantısını test eder
     */
    async validateRedis() {
        const redisConfig = {
            host: process.env.REDIS_HOST || 'localhost',
            port: parseInt(process.env.REDIS_PORT || '6379'),
            password: process.env.REDIS_PASSWORD,
            db: parseInt(process.env.REDIS_DB || '0')
        };

        try {
            const client = Redis.createClient(redisConfig);
            
            await new Promise((resolve, reject) => {
                client.on('error', reject);
                client.on('ready', () => {
                    client.set('validation:test', 'ok', (err) => {
                        if (err) reject(err);
                        else resolve();
                    });
                });
                client.connect();
            });
            
            const pong = await client.ping();
            await client.quit();
            
            if (pong === 'PONG') {
                this.addResult(
                    'Redis Connection',
                    'pass',
                    'Successfully connected to Redis',
                    { response: pong, config: redisConfig }
                );
            } else {
                this.addResult(
                    'Redis Connection',
                    'fail',
                    `Unexpected Redis response: ${pong}`
                );
            }
        } catch (error) {
            this.addResult(
                'Redis Connection',
                'fail',
                `Redis connection failed: ${error.message}`,
                { config: { ...redisConfig, password: '***' } }
            );
        }
    }

    /**
     * MongoDB bağlantısını test eder
     */
    async validateMongoDB() {
        const mongoUri = process.env.MONGO_URI;
        
        if (!mongoUri) {
            this.addResult(
                'MongoDB Configuration',
                'warning',
                'MONGO_URI not configured'
            );
            return;
        }

        try {
            const client = new MongoClient(mongoUri);
            await client.connect();
            
            const dbName = client.db().databaseName;
            const result = await client.db().admin().ping();
            
            await client.close();
            
            if (result.ok === 1) {
                this.addResult(
                    'MongoDB Connection',
                    'pass',
                    'Successfully connected to MongoDB',
                    { dbName, pingResult: result }
                );
            } else {
                this.addResult(
                    'MongoDB Connection',
                    'fail',
                    `MongoDB ping failed: ${JSON.stringify(result)}`
                );
            }
        } catch (error) {
            this.addResult(
                'MongoDB Connection',
                'fail',
                `MongoDB connection failed: ${error.message}`,
                { uri: mongoUri.replace(/\/\/.*@/, '//***@') } // Mask credentials
            );
        }
    }

    /**
     * Exchange API bağlantılarını test eder
     */
    async validateExchangeConnections() {
        console.log(`\n${colors.bright}💰 Validating Exchange APIs${colors.reset}\n`);

        const environment = process.env.NODE_ENV || 'development';
        const sandbox = environment !== 'production';

        // Test Binance API (if configured)
        await this.validateBinanceAPI(sandbox);
        
        // Test Coinbase API (if configured)  
        await this.validateCoinbaseAPI(sandbox);
        
        // Test Kraken API (if configured)
        await this.validateKrakenAPI(sandbox);
    }

    /**
     * Binance API'yi test eder
     */
    async validateBinanceAPI(sandbox) {
        const apiKey = process.env.BINANCE_API_KEY;
        const secretKey = process.env.BINANCE_SECRET_KEY;

        if (!apiKey || !secretKey) {
            this.addResult(
                'Binance API Configuration',
                'warning',
                'Binance API keys not configured'
            );
            return;
        }

        try {
            // Simple API test - get server time
            const response = await fetch(`https://api.binance${sandbox ? '-sandbox' : ''}.com/api/v3/time`);
            
            if (response.ok) {
                const data = await response.json();
                this.addResult(
                    'Binance API Connection',
                    'pass',
                    'Successfully connected to Binance API',
                    { serverTime: data.serverTime, sandbox }
                );
            } else {
                this.addResult(
                    'Binance API Connection',
                    'fail',
                    `Binance API error: HTTP ${response.status}`,
                    { status: response.status, sandbox }
                );
            }
        } catch (error) {
            this.addResult(
                'Binance API Connection',
                'fail',
                `Binance API connection failed: ${error.message}`,
                { sandbox }
            );
        }
    }

    /**
     * Coinbase API'yi test eder
     */
    async validateCoinbaseAPI(sandbox) {
        const apiKey = process.env.COINBASE_API_KEY;

        if (!apiKey) {
            this.addResult(
                'Coinbase API Configuration',
                'warning',
                'Coinbase API key not configured'
            );
            return;
        }

        try {
            // Test public endpoint
            const baseUrl = sandbox ? 'https://api-public.sandbox.exchange.coinbase.com' : 'https://api.exchange.coinbase.com';
            const response = await fetch(`${baseUrl}/products`);
            
            if (response.ok) {
                const products = await response.json();
                this.addResult(
                    'Coinbase API Connection',
                    'pass',
                    'Successfully connected to Coinbase API',
                    { productCount: products.length, sandbox }
                );
            } else {
                this.addResult(
                    'Coinbase API Connection',
                    'fail',
                    `Coinbase API error: HTTP ${response.status}`,
                    { status: response.status, sandbox }
                );
            }
        } catch (error) {
            this.addResult(
                'Coinbase API Connection',
                'fail',
                `Coinbase API connection failed: ${error.message}`,
                { sandbox }
            );
        }
    }

    /**
     * Kraken API'yi test eder
     */
    async validateKrakenAPI(sandbox) {
        const apiKey = process.env.KRAKEN_API_KEY;

        if (!apiKey) {
            this.addResult(
                'Kraken API Configuration',
                'warning',
                'Kraken API key not configured'
            );
            return;
        }

        try {
            // Kraken doesn't have a true sandbox, just test public endpoint
            const response = await fetch('https://api.kraken.com/0/public/Time');
            
            if (response.ok) {
                const data = await response.json();
                if (data.error && data.error.length === 0) {
                    this.addResult(
                        'Kraken API Connection',
                        'pass',
                        'Successfully connected to Kraken API',
                        { serverTime: data.result.unixtime }
                    );
                } else {
                    this.addResult(
                        'Kraken API Connection',
                        'fail',
                        `Kraken API error: ${data.error.join(', ')}`,
                        { error: data.error }
                    );
                }
            } else {
                this.addResult(
                    'Kraken API Connection',
                    'fail',
                    `Kraken API error: HTTP ${response.status}`,
                    { status: response.status }
                );
            }
        } catch (error) {
            this.addResult(
                'Kraken API Connection',
                'fail',
                `Kraken API connection failed: ${error.message}`
            );
        }
    }

    /**
     * Security configuration'ları kontrol eder
     */
    async validateSecurityConfiguration() {
        console.log(`\n${colors.bright}🔒 Validating Security Configuration${colors.reset}\n`);

        const environment = process.env.NODE_ENV || 'development';

        // Check CORS configuration
        const corsOrigin = process.env.CORS_ORIGIN;
        if (corsOrigin) {
            const origins = corsOrigin.split(',').map(o => o.trim());
            const isValidCORS = origins.every(origin => {
                // Allow localhost for development
                if (environment === 'development' && origin.startsWith('http://localhost')) {
                    return true;
                }
                // Production should use HTTPS
                if (environment === 'production') {
                    return origin.startsWith('https://');
                }
                return origin.startsWith('http://') || origin.startsWith('https://');
            });

            if (isValidCORS) {
                this.addResult(
                    'CORS Configuration',
                    'pass',
                    'CORS origin configuration looks valid',
                    { origins, environment }
                );
            } else {
                this.addResult(
                    'CORS Configuration',
                    'warning',
                    'Some CORS origins may be invalid',
                    { origins, environment }
                );
            }
        } else {
            this.addResult(
                'CORS Configuration',
                'warning',
                'CORS_ORIGIN not configured'
            );
        }

        // Check SSL configuration for production
        if (environment === 'production') {
            const sslEnabled = process.env.SSL_ENABLED === 'true';
            if (sslEnabled) {
                this.addResult(
                    'SSL Configuration',
                    'pass',
                    'SSL is enabled for production'
                );
            } else {
                this.addResult(
                    'SSL Configuration',
                    'fail',
                    'SSL should be enabled in production'
                );
            }
        }

        // Check rate limiting
        const rateLimitEnabled = process.env.RATE_LIMIT_MAX_REQUESTS;
        if (rateLimitEnabled) {
            const maxRequests = parseInt(rateLimitEnabled);
            if (maxRequests > 0) {
                this.addResult(
                    'Rate Limiting',
                    'pass',
                    `Rate limiting configured (${maxRequests} requests)`,
                    { maxRequests }
                );
            } else {
                this.addResult(
                    'Rate Limiting',
                    'fail',
                    'Invalid rate limiting configuration'
                );
            }
        } else {
            this.addResult(
                'Rate Limiting',
                'warning',
                'Rate limiting not configured'
            );
        }

        // Check development flags
        const devFlags = ['DEBUG_SQL', 'DEBUG_API_CALLS', 'DEBUG_TRADES'];
        for (const flag of devFlags) {
            const value = process.env[flag];
            if (value === 'true' && environment === 'production') {
                this.addResult(
                    `Security: ${flag}`,
                    'fail',
                    `${flag} should not be enabled in production`,
                    { value, environment }
                );
            } else if (value === 'true' && environment !== 'production') {
                this.addResult(
                    `Security: ${flag}`,
                    'warning',
                    `${flag} is enabled (appropriate for ${environment})`,
                    { value, environment }
                );
            }
        }
    }

    /**
     * Tüm validation'ları çalıştırır
     */
    async runAllValidations() {
        console.log(`${colors.bright}
╔════════════════════════════════════════════════════════════════╗
║           Environment Configuration Validator                 ║
║                    Crypto Trading Bot                        ║
╚════════════════════════════════════════════════════════════════╝
${colors.reset}`);

        try {
            await this.validateEnvironmentVariables();
            await this.validateDatabaseConnections();
            await this.validateExchangeConnections();
            await this.validateSecurityConfiguration();
            
            this.printSummary();
        } catch (error) {
            console.error(`\n${colors.red}❌ Validation failed with error: ${error.message}${colors.reset}`);
            process.exit(1);
        }
    }

    /**
     * Sonuçları özetler
     */
    printSummary() {
        console.log(`\n${colors.bright}📊 VALIDATION SUMMARY${colors.reset}\n`);

        const passRate = ((this.results.passed / this.results.total) * 100).toFixed(1);
        
        console.log(`${colors.green}✅ Passed:${colors.reset} ${this.results.passed}`);
        console.log(`${colors.red}❌ Failed:${colors.reset} ${this.results.failed}`);
        console.log(`${colors.yellow}⚠️ Warnings:${colors.reset} ${this.results.warnings}`);
        console.log(`${colors.blue}📈 Pass Rate:${colors.reset} ${passRate}%`);

        if (this.results.failed === 0) {
            console.log(`\n${colors.green}🎉 All critical validations passed!${colors.reset}\n`);
        } else {
            console.log(`\n${colors.red}💥 ${this.results.failed} critical issues need to be resolved!${colors.reset}\n`);
        }

        // Save results to file
        const outputPath = path.join(process.cwd(), 'environment-validation-results.json');
        fs.writeFileSync(outputPath, JSON.stringify(this.results, null, 2));
        console.log(`${colors.cyan}📁 Results saved to:${colors.reset} ${outputPath}`);

        // Exit code based on failures
        process.exit(this.results.failed > 0 ? 1 : 0);
    }
}

// CLI usage
async function main() {
    const args = process.argv.slice(2);
    const validator = new EnvironmentValidator();

    if (args.includes('--quick')) {
        // Quick validation - just check environment variables
        await validator.validateEnvironmentVariables();
        validator.printSummary();
    } else if (args.includes('--database-only')) {
        // Database only validation
        await validator.validateDatabaseConnections();
        validator.printSummary();
    } else if (args.includes('--security-only')) {
        // Security only validation
        await validator.validateSecurityConfiguration();
        validator.printSummary();
    } else {
        // Full validation
        await validator.runAllValidations();
    }
}

if (require.main === module) {
    main().catch(error => {
        console.error(`\n${colors.red}❌ Fatal error: ${error.message}${colors.reset}\n`);
        process.exit(1);
    });
}

module.exports = { EnvironmentValidator };