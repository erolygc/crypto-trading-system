#!/usr/bin/env node

/**
 * Master Setup Script for Environment & Secrets Management
 * 
 * Bu script environment ve secrets management sistemini kurar:
 * - Dependencies kontrolü
 * - Environment dosyası setup
 * - Azure Key Vault kurulumu
 * - SSL sertifikaları (development için)
 * - Database bağlantı testleri
 * - Security validation
 * 
 * @author Crypto Trading Bot Team
 * @version 1.0.0
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// ANSI color codes
const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    cyan: '\x1b[36m',
    magenta: '\x1b[35m'
};

class EnvironmentSetup {
    constructor() {
        this.projectRoot = process.cwd();
        this.configPath = path.join(this.projectRoot, 'config');
        this.environment = process.env.NODE_ENV || 'development';
        this.setupSteps = [];
        this.errors = [];
        this.warnings = [];
    }

    /**
     * Ana setup işlemini başlatır
     */
    async runSetup() {
        console.log(`${colors.bright}
╔══════════════════════════════════════════════════════════════════════╗
║               Environment & Secrets Management Setup                  ║
║                        Crypto Trading Bot                             ║
╚══════════════════════════════════════════════════════════════════════╝
${colors.reset}`);

        try {
            await this.checkPrerequisites();
            await this.setupEnvironment();
            await this.setupAzureKeyVault();
            await this.setupSSL();
            await this.setupDatabase();
            await this.setupSecurity();
            await this.runValidation();
            await this.finalizeSetup();

            this.printSummary();
        } catch (error) {
            console.error(`\n${colors.red}❌ Setup failed: ${error.message}${colors.reset}`);
            console.log('\n❗ Setup encountered errors. Please fix the issues and run setup again.');
            process.exit(1);
        }
    }

    /**
     * Prerequisites kontrol eder
     */
    async checkPrerequisites() {
        console.log(`${colors.cyan}🔍 Checking Prerequisites...${colors.reset}\n`);

        // Check Node.js version
        const nodeVersion = process.version;
        const majorVersion = parseInt(nodeVersion.slice(1).split('.')[0]);
        
        if (majorVersion >= 16) {
            this.logStep('Node.js Version', 'pass', `Node.js ${nodeVersion}`);
        } else {
            this.logStep('Node.js Version', 'fail', `Node.js ${nodeVersion} (requires >= 16.0.0)`);
        }

        // Check package.json
        const packageJsonPath = path.join(this.projectRoot, 'package.json');
        if (fs.existsSync(packageJsonPath)) {
            this.logStep('package.json', 'pass', 'Found');
        } else {
            this.logStep('package.json', 'warning', 'Not found (will create)');
        }

        // Check config directory
        if (fs.existsSync(this.configPath)) {
            this.logStep('Config Directory', 'pass', 'Exists');
        } else {
            this.logStep('Config Directory', 'fail', 'Missing');
        }

        // Check required files
        const requiredFiles = [
            'config/.env.example',
            'config/environment/dev.env',
            'config/environment/prod.env',
            'config/scripts/azure-keyvault-integration.js',
            'config/scripts/environment-validator.js',
            'config/scripts/secrets-manager.js',
            'config/security/security.config.js',
            'config/security/ssl.config.js',
            'config/database.config.js'
        ];

        let missingFiles = [];
        for (const file of requiredFiles) {
            const filePath = path.join(this.projectRoot, file);
            if (!fs.existsSync(filePath)) {
                missingFiles.push(file);
            }
        }

        if (missingFiles.length === 0) {
            this.logStep('Required Files', 'pass', 'All files present');
        } else {
            this.logStep('Required Files', 'fail', `Missing: ${missingFiles.join(', ')}`);
        }
    }

    /**
     * Environment setup yapar
     */
    async setupEnvironment() {
        console.log(`${colors.cyan}\n⚙️ Setting up Environment...${colors.reset}\n`);

        const envFile = path.join(this.projectRoot, '.env');
        const envExampleFile = path.join(this.configPath, '.env.example');

        if (fs.existsSync(envFile)) {
            this.logStep('.env File', 'warning', 'Already exists (will not overwrite)');
        } else if (fs.existsSync(envExampleFile)) {
            try {
                fs.copyFileSync(envExampleFile, envFile);
                this.logStep('.env File', 'pass', 'Created from template');
            } catch (error) {
                this.logStep('.env File', 'fail', `Copy failed: ${error.message}`);
            }
        } else {
            this.logStep('.env File', 'fail', 'Template not found');
        }

        // Set default environment
        if (!process.env.NODE_ENV) {
            process.env.NODE_ENV = this.environment;
            this.logStep('Environment Variable', 'pass', `NODE_ENV=${this.environment}`);
        }
    }

    /**
     * Azure Key Vault setup yapar
     */
    async setupAzureKeyVault() {
        console.log(`${colors.cyan}\n🔐 Setting up Azure Key Vault...${colors.reset}\n`);

        // Check if Azure CLI is installed
        try {
            execSync('az --version', { stdio: 'ignore' });
            this.logStep('Azure CLI', 'pass', 'Installed');
        } catch (error) {
            this.logStep('Azure CLI', 'warning', 'Not installed (optional)');
        }

        // Check Azure credentials
        const hasAzureCreds = process.env.AZURE_CLIENT_ID && 
                            process.env.AZURE_TENANT_ID && 
                            process.env.AZURE_CLIENT_SECRET;

        if (hasAzureCreds) {
            try {
                // Test Key Vault connection
                const keyVaultTest = require('./scripts/azure-keyvault-integration.js');
                const manager = keyVaultTest.getKeyVaultManager();
                const connected = await manager.testConnection();
                
                if (connected) {
                    this.logStep('Azure Key Vault', 'pass', 'Connection successful');
                } else {
                    this.logStep('Azure Key Vault', 'warning', 'Connection failed');
                }
            } catch (error) {
                this.logStep('Azure Key Vault', 'warning', `Setup needed: ${error.message}`);
            }
        } else {
            this.logStep('Azure Key Vault', 'warning', 'Credentials not configured');
        }

        // Offer to create sample Key Vault setup
        if (this.environment === 'development') {
            console.log(`${colors.yellow}💡 Tip: For development, you can skip Azure Key Vault setup${colors.reset}`);
            console.log(`${colors.yellow}   Production requires Azure Key Vault for security${colors.reset}`);
        }
    }

    /**
     * SSL setup yapar
     */
    async setupSSL() {
        console.log(`${colors.cyan}\n🔒 Setting up SSL/TLS...${colors.reset}\n`);

        const sslDir = path.join(this.projectRoot, 'ssl');
        const sslEnabled = process.env.SSL_ENABLED === 'true';

        if (sslEnabled) {
            const certPath = process.env.SSL_CERT_PATH;
            const keyPath = process.env.SSL_KEY_PATH;

            if (certPath && keyPath) {
                if (fs.existsSync(certPath) && fs.existsSync(keyPath)) {
                    this.logStep('SSL Certificates', 'pass', 'Found');
                } else {
                    this.logStep('SSL Certificates', 'fail', 'Not found');
                }
            } else {
                this.logStep('SSL Certificates', 'warning', 'Paths not configured');
            }
        } else if (this.environment === 'development') {
            // Generate self-signed certificate for development
            try {
                if (!fs.existsSync(sslDir)) {
                    fs.mkdirSync(sslDir, { recursive: true });
                }

                const SSLManager = require('./security/ssl.config.js');
                const sslManager = new SSLManager();
                await sslManager.generateSelfSignedCertificate(sslDir);
                
                this.logStep('Self-signed SSL', 'pass', 'Generated for development');
                console.log(`${colors.green}✅ SSL certificates generated in ${sslDir}${colors.reset}`);
            } catch (error) {
                this.logStep('Self-signed SSL', 'warning', `Generation failed: ${error.message}`);
            }
        } else {
            this.logStep('SSL Configuration', 'fail', 'Required for production');
        }
    }

    /**
     * Database setup yapar
     */
    async setupDatabase() {
        console.log(`${colors.cyan}\n🗄️ Setting up Database...${colors.reset}\n`);

        // Check database environment variables
        const dbVars = ['DB_HOST', 'DB_NAME', 'DB_USER'];
        const missingDbVars = dbVars.filter(varName => !process.env[varName]);

        if (missingDbVars.length === 0) {
            this.logStep('Database Config', 'pass', 'All variables present');
        } else {
            this.logStep('Database Config', 'warning', `Missing: ${missingDbVars.join(', ')}`);
        }

        // Test database connections if possible
        if (this.environment !== 'development' || process.env.TEST_DATABASE === 'true') {
            try {
                const dbManager = require('./database.config.js');
                const manager = dbManager.getDatabaseManager();
                await manager.initialize();
                await manager.testConnections();
                
                this.logStep('Database Connection', 'pass', 'Test successful');
            } catch (error) {
                this.logStep('Database Connection', 'warning', `Test failed: ${error.message}`);
            }
        } else {
            this.logStep('Database Connection', 'warning', 'Skipped (set TEST_DATABASE=true to test)');
        }
    }

    /**
     * Security setup yapar
     */
    async setupSecurity() {
        console.log(`${colors.cyan}\n🛡️ Setting up Security...${colors.reset}\n`);

        // Check security environment variables
        const securityManager = require('./security/security.config.js');
        const manager = new securityManager();
        const audit = manager.securityAudit();

        let securityScore = 0;
        audit.checks.forEach(check => {
            if (check.status === 'pass') securityScore++;
        });

        const securityPercentage = Math.round((securityScore / audit.checks.length) * 100);
        
        if (securityPercentage >= 80) {
            this.logStep('Security Configuration', 'pass', `${securityPercentage}% compliant`);
        } else if (securityPercentage >= 60) {
            this.logStep('Security Configuration', 'warning', `${securityPercentage}% compliant`);
        } else {
            this.logStep('Security Configuration', 'fail', `${securityPercentage}% compliant`);
        }

        // Generate security recommendations
        const failedChecks = audit.checks.filter(check => check.status === 'fail');
        if (failedChecks.length > 0) {
            this.warnings.push(...failedChecks.map(check => `Security: ${check.message}`));
        }
    }

    /**
     * Validation çalıştırır
     */
    async runValidation() {
        console.log(`${colors.cyan}\n🧪 Running Validation...${colors.reset}\n`);

        try {
            const validator = require('./scripts/environment-validator.js');
            const validatorInstance = new validator.EnvironmentValidator();
            await validatorInstance.runAllValidations();

            this.logStep('Environment Validation', 'pass', 'All tests passed');
        } catch (error) {
            this.logStep('Environment Validation', 'warning', `Validation failed: ${error.message}`);
        }
    }

    /**
     * Setup'ı finalize eder
     */
    async finalizeSetup() {
        console.log(`${colors.cyan}\n✨ Finalizing Setup...${colors.reset}\n`);

        // Create .gitignore for sensitive files
        const gitignorePath = path.join(this.projectRoot, '.gitignore');
        const sensitivePatterns = [
            '.env',
            'ssl/*.pem',
            'ssl/*.key',
            'ssl/*.cert',
            'backups/*.sql',
            'backups/*.json',
            'secrets-backup.json'
        ];

        let gitignoreContent = '';
        if (fs.existsSync(gitignorePath)) {
            gitignoreContent = fs.readFileSync(gitignorePath, 'utf8');
        }

        for (const pattern of sensitivePatterns) {
            if (!gitignoreContent.includes(pattern)) {
                gitignoreContent += `\n# Environment & Secrets\n${pattern}\n`;
            }
        }

        try {
            fs.writeFileSync(gitignorePath, gitignoreContent);
            this.logStep('.gitignore', 'pass', 'Updated with sensitive file patterns');
        } catch (error) {
            this.logStep('.gitignore', 'warning', `Update failed: ${error.message}`);
        }

        // Create setup completion marker
        const markerPath = path.join(this.projectRoot, '.setup-complete');
        try {
            fs.writeFileSync(markerPath, JSON.stringify({
                completedAt: new Date().toISOString(),
                environment: this.environment,
                version: '1.0.0'
            }, null, 2));
            this.logStep('Setup Marker', 'pass', 'Created');
        } catch (error) {
            this.logStep('Setup Marker', 'warning', `Creation failed: ${error.message}`);
        }
    }

    /**
     * Setup step log kaydeder
     */
    logStep(stepName, status, message) {
        this.setupSteps.push({
            name: stepName,
            status: status,
            message: message,
            timestamp: new Date().toISOString()
        });

        const colorMap = {
            pass: colors.green,
            fail: colors.red,
            warning: colors.yellow
        };

        const iconMap = {
            pass: '✅',
            fail: '❌',
            warning: '⚠️'
        };

        console.log(`${iconMap[status]} ${colorMap[status]}${stepName}${colors.reset}: ${message}`);

        if (status === 'fail') {
            this.errors.push(`${stepName}: ${message}`);
        } else if (status === 'warning') {
            this.warnings.push(`${stepName}: ${message}`);
        }
    }

    /**
     * Setup sonuçlarını özetler
     */
    printSummary() {
        const passSteps = this.setupSteps.filter(step => step.status === 'pass').length;
        const failSteps = this.setupSteps.filter(step => step.status === 'fail').length;
        const warningSteps = this.setupSteps.filter(step => step.status === 'warning').length;

        console.log(`\n${colors.bright}📋 SETUP SUMMARY${colors.reset}`);
        console.log(`━`.repeat(70));
        console.log(`${colors.green}✅ Completed:${colors.reset} ${passSteps}`);
        console.log(`${colors.yellow}⚠️ Warnings:${colors.reset} ${warningSteps}`);
        console.log(`${colors.red}❌ Failed:${colors.reset} ${failSteps}`);
        console.log(`━`.repeat(70));

        if (this.errors.length > 0) {
            console.log(`\n${colors.red}❌ Critical Issues:${colors.reset}`);
            this.errors.forEach(error => console.log(`   • ${error}`));
        }

        if (this.warnings.length > 0) {
            console.log(`\n${colors.yellow}⚠️ Recommendations:${colors.reset}`);
            this.warnings.forEach(warning => console.log(`   • ${warning}`));
        }

        // Print next steps
        console.log(`\n${colors.bright}🚀 NEXT STEPS:${colors.reset}`);
        
        if (this.environment === 'development') {
            console.log('1. Edit .env file with your local values');
            console.log('2. Start database services (PostgreSQL, Redis, MongoDB)');
            console.log('3. Run: node config/scripts/environment-validator.js');
            console.log('4. Start your application with: npm start');
        } else if (this.environment === 'staging') {
            console.log('1. Configure Azure Key Vault credentials');
            console.log('2. Set production-like values in Key Vault');
            console.log('3. Configure SSL certificates');
            console.log('4. Run full validation: node config/scripts/environment-validator.js');
        } else {
            console.log('1. Configure Azure Key Vault (MANDATORY)');
            console.log('2. Set all secrets in Key Vault');
            console.log('3. Configure production SSL certificates');
            console.log('4. Run security audit: node config/security/security.config.js audit');
            console.log('5. Start monitoring: node config/security/ssl.config.js monitor');
        }

        if (failSteps === 0) {
            console.log(`\n${colors.green}🎉 Setup completed successfully!${colors.reset}`);
            console.log(`${colors.cyan}📖 Check README.md for detailed usage instructions${colors.reset}\n`);
        } else {
            console.log(`\n${colors.yellow}⚠️ Setup completed with issues${colors.reset}`);
            console.log(`${colors.cyan}Please fix the errors above and run setup again${colors.reset}\n`);
        }
    }

    /**
     * Help mesajı gösterir
     */
    static showHelp() {
        console.log(`
${colors.bright}Environment & Secrets Management Setup${colors.reset}

${colors.cyan}Usage:${colors.reset}
  node setup.js [options]

${colors.cyan}Options:${colors.reset}
  --env <environment>     Set environment (development|staging|production)
  --test-database         Run database connection tests
  --skip-validation       Skip validation steps
  --help, -h             Show this help message

${colors.cyan}Environment Variables:${colors.reset}
  NODE_ENV               Environment (default: development)
  AZURE_KEY_VAULT_URL    Azure Key Vault URL
  AZURE_CLIENT_ID        Azure Client ID
  AZURE_CLIENT_SECRET    Azure Client Secret
  AZURE_TENANT_ID        Azure Tenant ID
  SSL_ENABLED            Enable SSL (true/false)
  TEST_DATABASE          Test database connections (true/false)

${colors.cyan}Examples:${colors.reset}
  # Development setup
  node setup.js --env development

  # Production setup with tests
  node setup.js --env production --test-database

  # Staging setup
  node setup.js --env staging
        `);
    }
}

// CLI interface
async function main() {
    const args = process.argv.slice(2);
    
    // Parse arguments
    let environment = 'development';
    let testDatabase = false;
    let skipValidation = false;

    for (let i = 0; i < args.length; i++) {
        const arg = args[i];
        
        switch (arg) {
            case '--env':
                environment = args[i + 1];
                i++;
                break;
            case '--test-database':
                testDatabase = true;
                break;
            case '--skip-validation':
                skipValidation = true;
                break;
            case '--help':
            case '-h':
                EnvironmentSetup.showHelp();
                return;
            default:
                if (arg.startsWith('--')) {
                    console.error(`❌ Unknown option: ${arg}`);
                    EnvironmentSetup.showHelp();
                    process.exit(1);
                }
        }
    }

    // Validate environment
    if (!['development', 'staging', 'production'].includes(environment)) {
        console.error(`❌ Invalid environment: ${environment}`);
        console.error('Must be one of: development, staging, production');
        process.exit(1);
    }

    // Set environment
    process.env.NODE_ENV = environment;

    // Run setup
    const setup = new EnvironmentSetup();
    
    if (testDatabase) {
        process.env.TEST_DATABASE = 'true';
    }

    if (skipValidation) {
        setup.runValidation = async () => {
            console.log(`${colors.yellow}⏭️ Skipping validation (--skip-validation)${colors.reset}`);
        };
    }

    await setup.runSetup();
}

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
    console.error(`\n${colors.red}❌ Uncaught Exception:${colors.reset}`, error.message);
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error(`\n${colors.red}❌ Unhandled Rejection:${colors.reset}`, reason);
    process.exit(1);
});

// Run if called directly
if (require.main === module) {
    main().catch(error => {
        console.error(`\n${colors.red}❌ Setup failed:${colors.reset}`, error.message);
        console.error(error.stack);
        process.exit(1);
    });
}

module.exports = { EnvironmentSetup };