"""
Monte Carlo Validation System
Stratejilerin istatistiksel doğrulama sistemi
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Callable, Any
from dataclasses import dataclass
from datetime import datetime, timedelta
import multiprocessing as mp
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
import itertools
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns

from ..performance.metrics import PerformanceCalculator, PerformanceMetrics


@dataclass
class MonteCarloConfig:
    """Monte Carlo konfigürasyonu"""
    num_simulations: int = 1000
    confidence_level: float = 0.95
    random_seed: Optional[int] = 42
    parallel_processing: bool = True
    max_workers: int = mp.cpu_count()
    
    # Resampling parameters
    block_size: Optional[int] = None  # For block bootstrap
    bootstrap_method: str = 'simple'  # 'simple', 'block', 'stationary'
    
    # Analysis parameters
    significance_level: float = 0.05
    performance_thresholds: Dict[str, float] = None
    
    def __post_init__(self):
        if self.performance_thresholds is None:
            self.performance_thresholds = {
                'min_sharpe_ratio': 0.5,
                'max_drawdown': 0.2,
                'min_win_rate': 0.4,
                'min_total_return': 0.1
            }


@dataclass
class MonteCarloResults:
    """Monte Carlo sonuçları"""
    simulations: List[PerformanceMetrics]
    confidence_intervals: Dict[str, Tuple[float, float]]
    probability_distributions: Dict[str, np.ndarray]
    statistical_tests: Dict[str, Any]
    risk_metrics: Dict[str, Any]
    out_of_sample_validation: Optional[Dict[str, Any]] = None


class BootstrapSampler:
    """Bootstrap sampling methods"""
    
    @staticmethod
    def simple_bootstrap(data: np.ndarray, n_samples: int, block_size: Optional[int] = None) -> List[np.ndarray]:
        """Simple bootstrap sampling"""
        samples = []
        n = len(data)
        
        for _ in range(n_samples):
            if block_size:
                # Block bootstrap
                n_blocks = n // block_size
                bootstrap_sample = []
                for _ in range(n_blocks):
                    start_idx = np.random.randint(0, n - block_size + 1)
                    bootstrap_sample.extend(data[start_idx:start_idx + block_size])
                
                # Pad to original size if needed
                while len(bootstrap_sample) < n:
                    start_idx = np.random.randint(0, n - block_size + 1)
                    bootstrap_sample.extend(data[start_idx:start_idx + block_size])
                
                bootstrap_sample = bootstrap_sample[:n]
            else:
                # Simple bootstrap
                bootstrap_sample = np.random.choice(data, size=n, replace=True)
            
            samples.append(np.array(bootstrap_sample))
        
        return samples
    
    @staticmethod
    def stationary_bootstrap(data: np.ndarray, n_samples: int, 
                           block_length: float = 10) -> List[np.ndarray]:
        """Stationary bootstrap (Politis & Romano)"""
        samples = []
        n = len(data)
        
        # Geometric distribution for block lengths
        p = 1 / block_length
        
        for _ in range(n_samples):
            bootstrap_sample = []
            current_idx = 0
            
            while len(bootstrap_sample) < n:
                # Generate block length from geometric distribution
                block_length = np.random.geometric(p)
                block_end = min(current_idx + block_length, n)
                
                # Add block
                remaining_needed = n - len(bootstrap_sample)
                add_length = min(block_end - current_idx, remaining_needed)
                bootstrap_sample.extend(data[current_idx:current_idx + add_length])
                
                # Move to next block
                if len(bootstrap_sample) < n:
                    current_idx = np.random.randint(0, n)
            
            samples.append(np.array(bootstrap_sample[:n]))
        
        return samples


class MonteCarloEngine:
    """Ana Monte Carlo engine"""
    
    def __init__(self, config: MonteCarloConfig):
        self.config = config
        self.performance_calculator = PerformanceCalculator()
        self.bootstrap_sampler = BootstrapSampler()
        
        # Random seed
        if config.random_seed:
            np.random.seed(config.random_seed)
    
    def run_backtest_validation(self, strategy_function: Callable,
                              original_data: Dict[str, Any],
                              baseline_performance: PerformanceMetrics) -> MonteCarloResults:
        """Backtest validation çalıştır"""
        
        # Extract returns data
        returns_data = self._extract_returns_data(original_data)
        
        # Generate bootstrap samples
        bootstrap_samples = self._generate_bootstrap_samples(returns_data)
        
        # Run simulations
        if self.config.parallel_processing:
            simulations = self._run_parallel_simulations(strategy_function, bootstrap_samples)
        else:
            simulations = self._run_sequential_simulations(strategy_function, bootstrap_samples)
        
        # Calculate confidence intervals
        confidence_intervals = self._calculate_confidence_intervals(simulations)
        
        # Statistical tests
        statistical_tests = self._run_statistical_tests(simulations, baseline_performance)
        
        # Risk analysis
        risk_metrics = self._analyze_risk_distribution(simulations)
        
        return MonteCarloResults(
            simulations=simulations,
            confidence_intervals=confidence_intervals,
            probability_distributions=self._create_probability_distributions(simulations),
            statistical_tests=statistical_tests,
            risk_metrics=risk_metrics
        )
    
    def _extract_returns_data(self, data: Dict[str, Any]) -> Dict[str, np.ndarray]:
        """Returns verilerini çıkar"""
        returns_data = {}
        
        if 'equity_curve' in data:
            equity = np.array([point[1] for point in data['equity_curve']])
            returns = np.diff(equity) / equity[:-1]
            returns_data['returns'] = returns
        
        if 'trade_returns' in data:
            returns_data['trade_returns'] = np.array(data['trade_returns'])
        
        return returns_data
    
    def _generate_bootstrap_samples(self, returns_data: Dict[str, np.ndarray]) -> Dict[str, List[np.ndarray]]:
        """Bootstrap samples oluştur"""
        bootstrap_samples = {}
        
        for data_type, data_array in returns_data.items():
            if self.config.bootstrap_method == 'simple':
                samples = self.bootstrap_sampler.simple_bootstrap(
                    data_array, self.config.num_simulations, self.config.block_size
                )
            elif self.config.bootstrap_method == 'stationary':
                samples = self.bootstrap_sampler.stationary_bootstrap(
                    data_array, self.config.num_simulations
                )
            else:
                raise ValueError(f"Unknown bootstrap method: {self.config.bootstrap_method}")
            
            bootstrap_samples[data_type] = samples
        
        return bootstrap_samples
    
    def _run_parallel_simulations(self, strategy_function: Callable,
                                bootstrap_samples: Dict[str, List[np.ndarray]]) -> List[PerformanceMetrics]:
        """Paralel simulation çalıştır"""
        simulations = []
        
        # Prepare arguments
        args_list = []
        for i in range(self.config.num_simulations):
            sample_data = {}
            for data_type, samples in bootstrap_samples.items():
                sample_data[data_type] = samples[i]
            args_list.append((strategy_function, sample_data))
        
        # Run parallel simulations
        with ThreadPoolExecutor(max_workers=self.config.max_workers) as executor:
            future_to_sim = {
                executor.submit(self._run_single_simulation, strategy_func, sample_data): i 
                for i, (strategy_func, sample_data) in enumerate(args_list)
            }
            
            for future in future_to_sim:
                try:
                    result = future.result(timeout=30)  # 30 second timeout
                    if result is not None:
                        simulations.append(result)
                except Exception as e:
                    print(f"Simulation failed: {e}")
        
        return simulations
    
    def _run_sequential_simulations(self, strategy_function: Callable,
                                  bootstrap_samples: Dict[str, List[np.ndarray]]) -> List[PerformanceMetrics]:
        """Sequential simulation çalıştır"""
        simulations = []
        
        for i in range(self.config.num_simulations):
            sample_data = {}
            for data_type, samples in bootstrap_samples.items():
                sample_data[data_type] = samples[i]
            
            result = self._run_single_simulation(strategy_function, sample_data)
            if result is not None:
                simulations.append(result)
        
        return simulations
    
    def _run_single_simulation(self, strategy_function: Callable,
                             sample_data: Dict[str, np.ndarray]) -> Optional[PerformanceMetrics]:
        """Tek simulation çalıştır"""
        try:
            # Reconstruct equity curve from returns
            if 'returns' in sample_data:
                returns = sample_data['returns']
                initial_equity = 100000  # Assume $100k starting capital
                
                equity_curve = []
                equity = initial_equity
                start_time = datetime(2020, 1, 1)
                
                for i, ret in enumerate(returns):
                    equity *= (1 + ret)
                    timestamp = start_time + timedelta(minutes=i)
                    equity_curve.append((timestamp, equity))
                
                # Mock trade data
                trades = []
                for i, ret in enumerate(returns):
                    if abs(ret) > 0.001:  # Simulate significant trades
                        trades.append({
                            'pnl': ret * 10000,
                            'timestamp': start_time + timedelta(minutes=i)
                        })
                
                # Calculate performance
                metrics = self.performance_calculator.calculate_full_metrics(
                    equity_curve, trades
                )
                
                return metrics
            
        except Exception as e:
            print(f"Error in simulation: {e}")
        
        return None
    
    def _calculate_confidence_intervals(self, simulations: List[PerformanceMetrics]) -> Dict[str, Tuple[float, float]]:
        """Confidence interval'ları hesapla"""
        if not simulations:
            return {}
        
        # Extract performance metrics
        metrics_dict = {}
        for attr_name in dir(simulations[0]):
            if not attr_name.startswith('_') and not callable(getattr(simulations[0], attr_name)):
                values = [getattr(sim, attr_name) for sim in simulations if hasattr(sim, attr_name)]
                if values and isinstance(values[0], (int, float)):
                    metrics_dict[attr_name] = np.array(values)
        
        # Calculate confidence intervals
        confidence_intervals = {}
        alpha = 1 - self.config.confidence_level
        
        for metric_name, values in metrics_dict.items():
            lower = np.percentile(values, (alpha/2) * 100)
            upper = np.percentile(values, (1 - alpha/2) * 100)
            confidence_intervals[metric_name] = (lower, upper)
        
        return confidence_intervals
    
    def _run_statistical_tests(self, simulations: List[PerformanceMetrics],
                             baseline: PerformanceMetrics) -> Dict[str, Any]:
        """Statistical test'leri çalıştır"""
        if not simulations:
            return {}
        
        tests = {}
        
        # Extract metrics for statistical tests
        returns = np.array([sim.total_return for sim in simulations])
        sharpe_ratios = np.array([sim.sharpe_ratio for sim in simulations])
        max_drawdowns = np.array([sim.max_drawdown for sim in simulations])
        
        # Jarque-Bera test for normality
        jb_stat, jb_pvalue = stats.jarque_bera(returns)
        tests['jarque_bera'] = {
            'statistic': jb_stat,
            'p_value': jb_pvalue,
            'is_normal': jb_pvalue > 0.05
        }
        
        # Shapiro-Wilk test
        if len(returns) <= 5000:  # Shapiro-Wilk has sample size limit
            sw_stat, sw_pvalue = stats.shapiro(returns)
            tests['shapiro_wilk'] = {
                'statistic': sw_stat,
                'p_value': sw_pvalue,
                'is_normal': sw_pvalue > 0.05
            }
        
        # Kolmogorov-Smirnov test against normal distribution
        ks_stat, ks_pvalue = stats.kstest(returns, 'norm', 
                                        args=(np.mean(returns), np.std(returns)))
        tests['kolmogorov_smirnov'] = {
            'statistic': ks_stat,
            'p_value': ks_pvalue,
            'is_normal': ks_pvalue > 0.05
        }
        
        # One-sample t-test against baseline
        t_stat, t_pvalue = stats.ttest_1samp(returns, baseline.total_return)
        tests['one_sample_t_test'] = {
            'statistic': t_stat,
            'p_value': t_pvalue,
            'significantly_different': t_pvalue < self.config.significance_level
        }
        
        # Wilcoxon signed-rank test (non-parametric)
        wilcoxon_stat, wilcoxon_pvalue = stats.wilcoxon(returns, 
                                                       [baseline.total_return] * len(returns))
        tests['wilcoxon_signed_rank'] = {
            'statistic': wilcoxon_stat,
            'p_value': wilcoxon_pvalue,
            'significantly_different': wilcoxon_pvalue < self.config.significance_level
        }
        
        return tests
    
    def _analyze_risk_distribution(self, simulations: List[PerformanceMetrics]) -> Dict[str, Any]:
        """Risk dağılımını analiz et"""
        if not simulations:
            return {}
        
        # Extract risk metrics
        returns = np.array([sim.total_return for sim in simulations])
        sharpe_ratios = np.array([sim.sharpe_ratio for sim in simulations])
        max_drawdowns = np.array([sim.max_drawdown for sim in simulations])
        volatilities = np.array([sim.volatility for sim in simulations])
        
        risk_analysis = {}
        
        # Return distribution
        risk_analysis['return_distribution'] = {
            'mean': np.mean(returns),
            'median': np.median(returns),
            'std': np.std(returns),
            'skewness': stats.skew(returns),
            'kurtosis': stats.kurtosis(returns),
            'percentiles': {
                '5': np.percentile(returns, 5),
                '25': np.percentile(returns, 25),
                '75': np.percentile(returns, 75),
                '95': np.percentile(returns, 95)
            }
        }
        
        # Risk metric distributions
        risk_analysis['sharpe_distribution'] = {
            'mean': np.mean(sharpe_ratios),
            'median': np.median(sharpe_ratios),
            'std': np.std(sharpe_ratios),
            'negative_count': np.sum(sharpe_ratios < 0),
            'negative_percentage': (np.sum(sharpe_ratios < 0) / len(sharpe_ratios)) * 100
        }
        
        risk_analysis['drawdown_distribution'] = {
            'mean': np.mean(max_drawdowns),
            'median': np.median(max_drawdowns),
            'std': np.std(max_drawdowns),
            'severe_drawdowns': np.sum(max_drawdowns > 0.3),  # >30% drawdown
            'severe_percentage': (np.sum(max_drawdowns > 0.3) / len(max_drawdowns)) * 100
        }
        
        # Correlation analysis
        risk_analysis['correlations'] = {
            'return_sharpe': np.corrcoef(returns, sharpe_ratios)[0, 1],
            'return_volatility': np.corrcoef(returns, volatilities)[0, 1],
            'sharpe_drawdown': np.corrcoef(sharpe_ratios, max_drawdowns)[0, 1]
        }
        
        return risk_analysis
    
    def _create_probability_distributions(self, simulations: List[PerformanceMetrics]) -> Dict[str, np.ndarray]:
        """Probability distributions oluştur"""
        if not simulations:
            return {}
        
        distributions = {}
        
        # Extract metrics as arrays
        metrics = ['total_return', 'sharpe_ratio', 'max_drawdown', 'volatility', 'win_rate']
        
        for metric in metrics:
            values = np.array([getattr(sim, metric) for sim in simulations])
            distributions[metric] = values
        
        return distributions
    
    def validate_strategy_robustness(self, results: MonteCarloResults) -> Dict[str, Any]:
        """Strateji robustness'u validate et"""
        robustness_check = {}
        
        # Success rate analysis
        success_metrics = results.probability_distributions
        
        if 'total_return' in success_metrics:
            returns = success_metrics['total_return']
            robustness_check['positive_return_probability'] = np.mean(returns > 0)
            robustness_check['exceed_benchmark_probability'] = np.mean(returns > 0.1)  # 10% benchmark
        
        if 'sharpe_ratio' in success_metrics:
            sharpe = success_metrics['sharpe_ratio']
            robustness_check['positive_sharpe_probability'] = np.mean(sharpe > 0)
            robustness_check['good_sharpe_probability'] = np.mean(sharpe > 1.0)
        
        if 'max_drawdown' in success_metrics:
            max_dd = success_metrics['max_drawdown']
            robustness_check['low_drawdown_probability'] = np.mean(max_dd < 0.2)  # <20% drawdown
        
        # Overall robustness score
        robustness_scores = []
        
        if 'positive_return_probability' in robustness_check:
            robustness_scores.append(robustness_check['positive_return_probability'])
        
        if 'positive_sharpe_probability' in robustness_check:
            robustness_scores.append(robustness_check['positive_sharpe_probability'])
        
        if 'low_drawdown_probability' in robustness_check:
            robustness_scores.append(robustness_check['low_drawdown_probability'])
        
        if robustness_scores:
            robustness_check['overall_robustness_score'] = np.mean(robustness_scores)
            robustness_check['is_robust'] = robustness_check['overall_robustness_score'] > 0.6
        
        return robustness_check


class SensitivityAnalyzer:
    """Sensitivity analysis için araçlar"""
    
    @staticmethod
    def parameter_sensitivity(strategy_function: Callable,
                            base_parameters: Dict[str, Any],
                            parameter_ranges: Dict[str, List[Any]],
                            num_samples: int = 100) -> Dict[str, Any]:
        """Parameter sensitivity analysis"""
        
        results = {}
        
        for param_name, param_range in parameter_ranges.items():
            param_results = []
            
            for param_value in param_range:
                # Set current parameter
                current_params = base_parameters.copy()
                current_params[param_name] = param_value
                
                # Run strategy with current parameters
                # Note: This is a simplified version. In practice, you'd need to
                # adapt the strategy_function to accept parameters
                performance_metrics = []
                
                for _ in range(num_samples // len(param_range)):
                    # Run multiple samples for each parameter value
                    result = strategy_function(current_params)
                    if result:
                        performance_metrics.append(result)
                
                if performance_metrics:
                    # Calculate average performance for this parameter value
                    avg_return = np.mean([m.total_return for m in performance_metrics])
                    avg_sharpe = np.mean([m.sharpe_ratio for m in performance_metrics])
                    
                    param_results.append({
                        'parameter_value': param_value,
                        'avg_return': avg_return,
                        'avg_sharpe': avg_sharpe,
                        'num_samples': len(performance_metrics)
                    })
            
            results[param_name] = param_results
        
        return results
    
    @staticmethod
    def market_condition_analysis(strategy_function: Callable,
                                market_scenarios: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        """Farklı piyasa koşullarında strateji performansı"""
        
        scenario_results = {}
        
        for scenario_name, scenario_config in market_scenarios.items():
            # Apply market scenario
            modified_performance = []
            
            # Run strategy under this scenario multiple times
            for _ in range(100):  # 100 simulations per scenario
                result = strategy_function(scenario_config)
                if result:
                    modified_performance.append(result)
            
            if modified_performance:
                scenario_results[scenario_name] = {
                    'avg_return': np.mean([m.total_return for m in modified_performance]),
                    'avg_sharpe': np.mean([m.sharpe_ratio for m in modified_performance]),
                    'max_drawdown': np.mean([m.max_drawdown for m in modified_performance]),
                    'volatility': np.mean([m.volatility for m in modified_performance]),
                    'win_rate': np.mean([m.win_rate for m in modified_performance]),
                    'num_simulations': len(modified_performance)
                }
        
        return scenario_results


class MonteCarloReportGenerator:
    """Monte Carlo sonuçları için rapor oluşturucu"""
    
    @staticmethod
    def generate_monte_carlo_report(results: MonteCarloResults,
                                  robustness_check: Dict[str, Any]) -> str:
        """Monte Carlo raporu oluştur"""
        
        report = []
        report.append("=" * 80)
        report.append("MONTE CARLO VALIDATION REPORT")
        report.append("=" * 80)
        report.append("")
        
        # Summary Statistics
        if results.simulations:
            report.append("SIMULATION SUMMARY:")
            report.append(f"Number of Simulations: {len(results.simulations)}")
            report.append("")
            
            # Performance distribution
            returns = [sim.total_return for sim in results.simulations]
            sharpe_ratios = [sim.sharpe_ratio for sim in results.simulations]
            max_drawdowns = [sim.max_drawdown for sim in results.simulations]
            
            report.append("PERFORMANCE DISTRIBUTION:")
            report.append(f"Return - Mean: {np.mean(returns):.2%}, Std: {np.std(returns):.2%}")
            report.append(f"Sharpe Ratio - Mean: {np.mean(sharpe_ratios):.3f}, Std: {np.std(sharpe_ratios):.3f}")
            report.append(f"Max Drawdown - Mean: {np.mean(max_drawdowns):.2%}, Std: {np.std(max_drawdowns):.2%}")
            report.append("")
            
            # Confidence Intervals
            if results.confidence_intervals:
                report.append("CONFIDENCE INTERVALS (95%):")
                for metric, (lower, upper) in results.confidence_intervals.items():
                    if isinstance(lower, (int, float)):
                        report.append(f"{metric}: [{lower:.4f}, {upper:.4f}]")
                report.append("")
        
        # Statistical Tests
        if results.statistical_tests:
            report.append("STATISTICAL TESTS:")
            for test_name, test_result in results.statistical_tests.items():
                if 'p_value' in test_result:
                    significance = "SIGNIFICANT" if test_result['p_value'] < 0.05 else "NOT SIGNIFICANT"
                    report.append(f"{test_name}: p-value = {test_result['p_value']:.4f} ({significance})")
            report.append("")
        
        # Robustness Analysis
        if robustness_check:
            report.append("ROBUSTNESS ANALYSIS:")
            for metric, value in robustness_check.items():
                if isinstance(value, float) and 'probability' in metric:
                    report.append(f"{metric}: {value:.2%}")
                elif isinstance(value, bool):
                    status = "PASS" if value else "FAIL"
                    report.append(f"{metric}: {status}")
                else:
                    report.append(f"{metric}: {value}")
            report.append("")
        
        # Risk Analysis
        if results.risk_metrics:
            report.append("RISK ANALYSIS:")
            risk_analysis = results.risk_metrics
            
            if 'return_distribution' in risk_analysis:
                dist = risk_analysis['return_distribution']
                report.append(f"Return Skewness: {dist['skewness']:.3f}")
                report.append(f"Return Kurtosis: {dist['kurtosis']:.3f}")
            
            if 'drawdown_distribution' in risk_analysis:
                dd_dist = risk_analysis['drawdown_distribution']
                report.append(f"Severe Drawdown Rate (>30%): {dd_dist['severe_percentage']:.2f}%")
            
            report.append("")
        
        return "\n".join(report)