"""
Event-Driven Simulation Engine
Tüm backtester bileşenlerini koordine eden ana motor
"""

import asyncio
import threading
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass
import time
import numpy as np
import pandas as pd

from ..core.event_system import EventBus, EventType, Event, TickEvent, TradeEvent, PortfolioEvent
from ..core.tick_engine import TickEngine, Tick
from ..core.order_book import OrderBook, Portfolio, OrderSide, OrderType
from ..utils.data_loader import TimescaleDBConnector


@dataclass
class SimulationConfig:
    """Simulation konfigürasyonu"""
    # Genel ayarlar
    start_time: datetime
    end_time: Optional[datetime] = None
    duration_seconds: Optional[float] = None
    time_speed: float = 1.0  # Simulation speed multiplier
    
    # Semboller
    symbols: List[str] = None
    initial_prices: Dict[str, float] = None
    volatilities: Dict[str, float] = None
    tick_frequencies: Dict[str, float] = None
    
    # Portfolio
    initial_cash: float = 100000.0
    commission_rate: float = 0.001
    slippage_bps: float = 1.0
    
    # Data source
    use_real_data: bool = False
    data_source: str = "timescale"
    
    # Performance tracking
    record_equity_interval: int = 100  # ticks
    
    def __post_init__(self):
        if self.symbols is None:
            self.symbols = ['BTCUSDT', 'ETHUSDT']
        
        if self.initial_prices is None:
            self.initial_prices = {'BTCUSDT': 50000, 'ETHUSDT': 3000}
        
        if self.volatilities is None:
            self.volatilities = {symbol: 0.02 for symbol in self.symbols}
        
        if self.tick_frequencies is None:
            self.tick_frequencies = {symbol: 100 for symbol in self.symbols}


class StrategyInterface:
    """Strategy interface - tüm stratejiler bu interface'i implement edecek"""
    
    def initialize(self, event_bus: EventBus, portfolio: Portfolio) -> None:
        """Stratejiyi initialize et"""
        pass
    
    def on_tick(self, tick_event: TickEvent) -> List[Event]:
        """Tick event'i işle"""
        return []
    
    def on_trade(self, trade_event: TradeEvent) -> List[Event]:
        """Trade event'i işle"""
        return []
    
    def on_portfolio_update(self, portfolio_event: PortfolioEvent) -> List[Event]:
        """Portfolio update event'i işle"""
        return []
    
    def cleanup(self) -> None:
        """Temizlik"""
        pass


class DataFeedInterface:
    """Data feed interface"""
    
    def __init__(self, config: SimulationConfig):
        self.config = config
        self.event_bus = None
        self.is_running = False
    
    def initialize(self, event_bus: EventBus) -> None:
        """Data feed'i initialize et"""
        self.event_bus = event_bus
    
    def start(self) -> None:
        """Data feed'i başlat"""
        pass
    
    def stop(self) -> None:
        """Data feed'i durdur"""
        pass


class TimescaleDataFeed(DataFeedInterface):
    """TimescaleDB'den veri çeken feed"""
    
    def __init__(self, config: SimulationConfig):
        super().__init__(config)
        self.db_connector = None
        self.current_timestamp = None
    
    def initialize(self, event_bus: EventBus) -> None:
        """TimescaleDB connector'ı initialize et"""
        super().initialize(event_bus)
        
        try:
            self.db_connector = TimescaleDBConnector()
            self.db_connector.connect()
        except Exception as e:
            print(f"Warning: Could not connect to TimescaleDB: {e}")
            print("Using simulated data instead.")
            self.config.use_real_data = False
    
    def start(self) -> None:
        """TimescaleDB'den veri çekmeye başla"""
        self.is_running = True
        
        if self.config.use_real_data and self.db_connector:
            self._fetch_real_data()
        else:
            self._simulate_data()
    
    def _fetch_real_data(self) -> None:
        """TimescaleDB'den gerçek veri çek"""
        def data_fetch_loop():
            while self.is_running:
                try:
                    # Get next batch of data
                    data_batch = self.db_connector.get_market_data_batch(
                        symbols=self.config.symbols,
                        start_time=self.current_timestamp or self.config.start_time,
                        batch_size=1000
                    )
                    
                    if data_batch.empty:
                        break
                    
                    # Process each tick
                    for _, row in data_batch.iterrows():
                        if not self.is_running:
                            break
                        
                        tick_event = TickEvent(
                            symbol=row['symbol'],
                            bid=row['bid'],
                            ask=row['ask'],
                            volume=row['volume'],
                            timestamp=row['timestamp']
                        )
                        
                        self.event_bus.publish(tick_event)
                        
                        self.current_timestamp = row['timestamp']
                    
                    time.sleep(0.01)  # Rate limiting
                    
                except Exception as e:
                    print(f"Error fetching real data: {e}")
                    # Fallback to simulation
                    self.config.use_real_data = False
                    self._simulate_data()
                    break
        
        thread = threading.Thread(target=data_fetch_loop, daemon=True)
        thread.start()
    
    def _simulate_data(self) -> None:
        """Simulated data feed"""
        # This will be handled by TickEngine
        pass
    
    def stop(self) -> None:
        """Data feed'i durdur"""
        self.is_running = False
        
        if self.db_connector:
            self.db_connector.disconnect()


class SimulationEngine:
    """Ana simulation engine"""
    
    def __init__(self, config: SimulationConfig):
        self.config = config
        self.event_bus = EventBus()
        
        # Core components
        self.tick_engine = TickEngine(self.event_bus)
        self.portfolio = Portfolio(config.initial_cash, self.event_bus)
        self.data_feed = TimescaleDataFeed(config)
        
        # Strategy
        self.strategy: Optional[StrategyInterface] = None
        
        # State
        self.is_running = False
        self.start_time = None
        self.end_time = None
        
        # Performance tracking
        self.ticks_processed = 0
        self.events_processed = 0
        self.last_equity_record = 0
        
        # Event handlers
        self._setup_event_handlers()
    
    def _setup_event_handlers(self) -> None:
        """Event handler'ları kur"""
        # Tick events
        self.event_bus.subscribe(EventType.TICK, self._handle_tick_event)
        
        # Trade events
        self.event_bus.subscribe(EventType.TRADE_EXECUTE, self._handle_trade_event)
        
        # Portfolio events
        self.event_bus.subscribe(EventType.PORTFOLIO_UPDATE, self._handle_portfolio_event)
    
    def set_strategy(self, strategy: StrategyInterface) -> None:
        """Strategy'yi ayarla"""
        self.strategy = strategy
        strategy.initialize(self.event_bus, self.portfolio)
    
    def initialize(self) -> None:
        """Simulation'ı initialize et"""
        # Setup tick engine
        for symbol in self.config.symbols:
            initial_price = self.config.initial_prices.get(symbol, 1000)
            volatility = self.config.volatilities.get(symbol, 0.02)
            tick_frequency = self.config.tick_frequencies.get(symbol, 100)
            
            self.tick_engine.add_symbol(symbol, initial_price, volatility, tick_frequency)
        
        # Setup data feed
        self.data_feed.initialize(self.event_bus)
        
        # Setup order books
        for symbol in self.config.symbols:
            order_book = OrderBook(symbol, self.event_bus)
            # Initialize with market data
            initial_price = self.config.initial_prices.get(symbol, 1000)
            spread = initial_price * 0.0002  # 2 bps spread
            order_book.update_market_data(
                bid=initial_price - spread/2,
                ask=initial_price + spread/2,
                last_price=initial_price
            )
    
    def start(self) -> None:
        """Simulation'ı başlat"""
        if self.is_running:
            return
        
        self.is_running = True
        self.start_time = datetime.utcnow()
        
        # Calculate end time
        if self.config.end_time:
            self.end_time = self.config.end_time
        elif self.config.duration_seconds:
            self.end_time = self.start_time + timedelta(seconds=self.config.duration_seconds)
        else:
            self.end_time = None
        
        # Start data feed
        self.data_feed.start()
        
        # Start tick engine
        if not self.config.use_real_data:
            duration = (self.end_time - self.start_time).total_seconds() if self.end_time else None
            self.tick_engine.start(duration)
        
        # Main simulation loop
        self._run_simulation_loop()
    
    def stop(self) -> None:
        """Simulation'ı durdur"""
        self.is_running = False
        
        # Stop components
        self.tick_engine.stop()
        self.data_feed.stop()
        
        # Cleanup strategy
        if self.strategy:
            self.strategy.cleanup()
        
        print(f"Simulation completed. Processed {self.ticks_processed} ticks, {self.events_processed} events.")
    
    def _run_simulation_loop(self) -> None:
        """Ana simulation loop"""
        try:
            while self.is_running:
                current_time = datetime.utcnow()
                
                # Check end time
                if self.end_time and current_time >= self.end_time:
                    break
                
                # Update market prices in portfolio
                self._update_portfolio_prices()
                
                # Record equity points
                if (self.ticks_processed - self.last_equity_record) >= self.config.record_equity_interval:
                    self.portfolio.record_equity_point()
                    self.last_equity_record = self.ticks_processed
                
                # Sleep for simulation speed
                sleep_time = 0.01 / self.config.time_speed
                time.sleep(sleep_time)
                
        except KeyboardInterrupt:
            print("Simulation interrupted by user.")
        except Exception as e:
            print(f"Error in simulation loop: {e}")
        finally:
            self.stop()
    
    def _update_portfolio_prices(self) -> None:
        """Portfolio fiyatlarını güncelle"""
        market_prices = {}
        
        for symbol in self.config.symbols:
            order_book = self.tick_engine.get_order_book(symbol)
            if order_book:
                best_bid = order_book.get_best_bid()
                best_ask = order_book.get_best_ask()
                
                if best_bid and best_ask:
                    market_prices[symbol] = (best_bid + best_ask) / 2
        
        if market_prices:
            self.portfolio.update_market_prices(market_prices)
    
    def _handle_tick_event(self, event: TickEvent) -> None:
        """Tick event'i işle"""
        self.ticks_processed += 1
        self.events_processed += 1
        
        # Update order book
        tick_engine = self.tick_engine
        order_book = tick_engine.get_order_book(event.symbol)
        if order_book:
            order_book.update_market_data(event.bid, event.ask, event.mid_price)
        
        # Strategy handling
        if self.strategy:
            strategy_events = self.strategy.on_tick(event)
            for strategy_event in strategy_events:
                self.event_bus.publish(strategy_event)
    
    def _handle_trade_event(self, event: TradeEvent) -> None:
        """Trade event'i işle"""
        self.events_processed += 1
        
        # Portfolio update
        side = OrderSide.BUY if event.side == 'BUY' else OrderSide.SELL
        self.portfolio.execute_trade(
            symbol=event.symbol,
            side=side,
            quantity=event.quantity,
            price=event.price,
            commission=event.commission,
            timestamp=event.timestamp
        )
        
        # Strategy handling
        if self.strategy:
            strategy_events = self.strategy.on_trade(event)
            for strategy_event in strategy_events:
                self.event_bus.publish(strategy_event)
    
    def _handle_portfolio_event(self, event: PortfolioEvent) -> None:
        """Portfolio update event'i işle"""
        self.events_processed += 1
        
        # Strategy handling
        if self.strategy:
            strategy_events = self.strategy.on_portfolio_update(event)
            for strategy_event in strategy_events:
                self.event_bus.publish(strategy_event)
    
    def get_simulation_stats(self) -> Dict[str, Any]:
        """Simulation istatistiklerini getir"""
        runtime = (datetime.utcnow() - self.start_time).total_seconds() if self.start_time else 0
        
        stats = {
            'is_running': self.is_running,
            'runtime_seconds': runtime,
            'ticks_processed': self.ticks_processed,
            'events_processed': self.events_processed,
            'ticks_per_second': self.ticks_processed / runtime if runtime > 0 else 0,
            'events_per_second': self.events_processed / runtime if runtime > 0 else 0,
            'portfolio_value': self.portfolio.get_portfolio_value(),
            'total_return_pct': self.portfolio.get_total_return(),
            'num_positions': len(self.portfolio.positions),
            'num_trades': len(self.portfolio.trades)
        }
        
        # Add tick engine stats
        tick_stats = self.tick_engine.get_performance_stats()
        stats.update(tick_stats)
        
        return stats
    
    def get_portfolio_summary(self) -> Dict[str, Any]:
        """Portfolio özeti"""
        return self.portfolio.get_portfolio_summary()
    
    def get_equity_curve(self) -> List[tuple]:
        """Equity curve'u getir"""
        return self.portfolio.get_equity_curve()


class BacktestSimulationEngine(SimulationEngine):
    """Backtest için özelleştirilmiş simulation engine"""
    
    def __init__(self, config: SimulationConfig):
        super().__init__(config)
        
        # Backtest specific settings
        self.config.time_speed = 10.0  # Faster simulation for backtesting
        self.config.record_equity_interval = 50  # More frequent equity recording
    
    def run_backtest(self, strategy_class: type) -> Dict[str, Any]:
        """Backtest çalıştır"""
        # Create strategy instance
        strategy = strategy_class()
        self.set_strategy(strategy)
        
        # Initialize
        self.initialize()
        
        # Start simulation
        self.start()
        
        # Wait for completion
        while self.is_running:
            time.sleep(1)
        
        # Get results
        results = self.get_backtest_results()
        
        return results
    
    def get_backtest_results(self) -> Dict[str, Any]:
        """Backtest sonuçlarını getir"""
        stats = self.get_simulation_stats()
        portfolio = self.get_portfolio_summary()
        equity_curve = self.get_equity_curve()
        
        # Calculate additional metrics
        performance_metrics = self._calculate_performance_metrics(equity_curve)
        
        return {
            'simulation_stats': stats,
            'portfolio_summary': portfolio,
            'equity_curve': equity_curve,
            'performance_metrics': performance_metrics
        }
    
    def _calculate_performance_metrics(self, equity_curve: List[tuple]) -> Dict[str, float]:
        """Performance metrikleri hesapla"""
        if len(equity_curve) < 2:
            return {}
        
        # Convert to returns
        values = [point[1] for point in equity_curve]
        returns = np.diff(values) / values[:-1]
        
        metrics = {
            'total_return': (values[-1] - values[0]) / values[0],
            'volatility': np.std(returns) * np.sqrt(252 * 24 * 60),  # Assuming minute data
            'max_drawdown': self._calculate_max_drawdown(values),
            'sharpe_ratio': self._calculate_sharpe_ratio(returns),
            'sortino_ratio': self._calculate_sortino_ratio(returns)
        }
        
        return metrics
    
    def _calculate_max_drawdown(self, values: List[float]) -> float:
        """Maximum drawdown hesapla"""
        peak = values[0]
        max_dd = 0
        
        for value in values:
            if value > peak:
                peak = value
            
            drawdown = (peak - value) / peak
            max_dd = max(max_dd, drawdown)
        
        return max_dd
    
    def _calculate_sharpe_ratio(self, returns: np.ndarray) -> float:
        """Sharpe ratio hesapla"""
        if len(returns) == 0:
            return 0
        
        excess_returns = returns - 0.02 / 252 / 24 / 60  # Assuming 2% annual risk-free rate
        return np.mean(excess_returns) / np.std(excess_returns) if np.std(excess_returns) > 0 else 0
    
    def _calculate_sortino_ratio(self, returns: np.ndarray) -> float:
        """Sortino ratio hesapla"""
        if len(returns) == 0:
            return 0
        
        excess_returns = returns - 0.02 / 252 / 24 / 60
        downside_returns = excess_returns[excess_returns < 0]
        
        if len(downside_returns) == 0:
            return float('inf')
        
        downside_deviation = np.std(downside_returns)
        return np.mean(excess_returns) / downside_deviation if downside_deviation > 0 else 0