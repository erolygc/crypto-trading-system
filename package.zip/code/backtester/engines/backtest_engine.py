"""
Backtest Engine
Bitwisers 2.0 ana backtest motoru
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable, Tuple
from dataclasses import dataclass
import asyncio
import time

from ..core.event_system import EventBus, EventType, TickEvent, TradeEvent
from ..core.tick_engine import TickEngine
from ..core.order_book import Portfolio, OrderBook, OrderSide, OrderType
from .simulation_engine import SimulationEngine, SimulationConfig, StrategyInterface
from ..utils.data_loader import TimescaleDBConnector, BacktestDataManager
from ..performance.metrics import PerformanceCalculator, PerformanceReportGenerator
from ..monte_carlo.validation import MonteCarloEngine, MonteCarloConfig, SensitivityAnalyzer
from ..gpu.acceleration import GPUAcceleratedCalculator, ParallelProcessor


@dataclass
class BacktestConfig:
    """Backtest konfigürasyonu"""
    # General settings
    strategy_name: str
    start_date: datetime
    end_date: datetime
    initial_capital: float = 100000.0
    
    # Data settings
    symbols: List[str]
    data_frequency: str = '1 minute'  # '1m', '5m', '15m', '1h', '1d'
    use_real_data: bool = True
    
    # Trading settings
    commission_rate: float = 0.001
    slippage_bps: float = 1.0
    max_position_size: float = 1.0  # 100% of capital
    risk_per_trade: float = 0.02  # 2% risk per trade
    
    # Strategy parameters
    strategy_parameters: Dict[str, Any] = None
    
    # Performance settings
    benchmark_symbol: str = 'BTCUSDT'
    risk_free_rate: float = 0.02
    
    # Monte Carlo settings
    monte_carlo_simulations: int = 1000
    monte_carlo_confidence: float = 0.95
    
    # GPU/Parallel settings
    use_gpu: bool = False
    parallel_processing: bool = True
    max_workers: int = 4
    
    def __post_init__(self):
        if self.strategy_parameters is None:
            self.strategy_parameters = {}
        
        # Setup default parameters based on strategy
        self._setup_default_parameters()
    
    def _setup_default_parameters(self) -> None:
        """Default parametreleri ayarla"""
        if 'rsi_period' not in self.strategy_parameters:
            self.strategy_parameters['rsi_period'] = 14
        
        if 'sma_fast' not in self.strategy_parameters:
            self.strategy_parameters['sma_fast'] = 10
        
        if 'sma_slow' not in self.strategy_parameters:
            self.strategy_parameters['sma_slow'] = 20
        
        if 'rsi_oversold' not in self.strategy_parameters:
            self.strategy_parameters['rsi_oversold'] = 30
        
        if 'rsi_overbought' not in self.strategy_parameters:
            self.strategy_parameters['rsi_overbought'] = 70


class BacktestEngine:
    """Ana Backtest Engine"""
    
    def __init__(self, config: BacktestConfig):
        self.config = config
        self.event_bus = EventBus()
        
        # Core components
        self.data_manager: Optional[BacktestDataManager] = None
        self.portfolio: Optional[Portfolio] = None
        self.performance_calculator = PerformanceCalculator(risk_free_rate=config.risk_free_rate)
        
        # GPU/Parallel processing
        self.gpu_calculator: Optional[GPUAcceleratedCalculator] = None
        self.parallel_processor: Optional[ParallelProcessor] = None
        
        if config.use_gpu:
            from ..gpu.acceleration import GPUConfig
            gpu_config = GPUConfig(use_gpu=True)
            self.gpu_calculator = GPUAcceleratedCalculator(gpu_config)
        
        if config.parallel_processing:
            self.parallel_processor = ParallelProcessor(max_workers=config.max_workers)
        
        # Monte Carlo
        self.monte_carlo_engine = MonteCarloEngine(
            MonteCarloConfig(num_simulations=config.monte_carlo_simulations)
        )
        
        # Results
        self.results: Dict[str, Any] = {}
        
        # Setup
        self._initialize_components()
    
    def _initialize_components(self) -> None:
        """Bileşenleri initialize et"""
        # Database connection
        try:
            db_connector = TimescaleDBConnector()
            db_connector.connect()
            self.data_manager = BacktestDataManager(db_connector)
        except Exception as e:
            print(f"Warning: Database connection failed: {e}")
            print("Using simulated data")
        
        # Portfolio
        self.portfolio = Portfolio(
            initial_cash=self.config.initial_capital,
            event_bus=self.event_bus
        )
        
        # Event handlers
        self._setup_event_handlers()
    
    def _setup_event_handlers(self) -> None:
        """Event handler'ları kur"""
        # Add custom event handlers if needed
        pass
    
    def run_backtest(self, strategy: StrategyInterface) -> Dict[str, Any]:
        """Backtest çalıştır"""
        print(f"Starting backtest: {self.config.strategy_name}")
        print(f"Period: {self.config.start_date} to {self.config.end_date}")
        print(f"Symbols: {self.config.symbols}")
        print(f"Initial Capital: ${self.config.initial_capital:,.2f}")
        print("-" * 50)
        
        # Load data
        market_data = self._load_market_data()
        
        if not market_data:
            print("Error: No market data loaded")
            return {}
        
        # Run strategy
        strategy_results = self._run_strategy(strategy, market_data)
        
        # Calculate performance metrics
        performance_metrics = self._calculate_performance_metrics(strategy_results)
        
        # Monte Carlo validation
        if self.config.monte_carlo_simulations > 0:
            monte_carlo_results = self._run_monte_carlo_validation(strategy, market_data)
            self.results['monte_carlo'] = monte_carlo_results
        
        # Store results
        self.results.update({
            'config': self.config.__dict__,
            'strategy_results': strategy_results,
            'performance_metrics': performance_metrics,
            'market_data_summary': self._get_market_data_summary(market_data)
        })
        
        print("Backtest completed successfully!")
        
        return self.results
    
    def _load_market_data(self) -> Dict[str, pd.DataFrame]:
        """Market verilerini yükle"""
        try:
            if self.data_manager and self.config.use_real_data:
                print("Loading real market data...")
                market_data = self.data_manager.load_backtest_data(
                    symbols=self.config.symbols,
                    start_time=self.config.start_date,
                    end_time=self.config.end_date,
                    interval=self.config.data_frequency
                )
            else:
                print("Generating simulated market data...")
                market_data = self._generate_simulated_data()
            
            return market_data
            
        except Exception as e:
            print(f"Error loading market data: {e}")
            return {}
    
    def _generate_simulated_data(self) -> Dict[str, pd.DataFrame]:
        """Simulated market data oluştur"""
        market_data = {}
        
        for symbol in self.config.symbols:
            # Generate OHLCV data
            start_date = self.config.start_date
            end_date = self.config.end_date
            
            # Create time series
            if self.config.data_frequency == '1 minute':
                freq = '1min'
            elif self.config.data_frequency == '5 minute':
                freq = '5min'
            elif self.config.data_frequency == '15 minute':
                freq = '15min'
            elif self.config.data_frequency == '1 hour':
                freq = '1h'
            elif self.config.data_frequency == '1 day':
                freq = '1d'
            else:
                freq = '1min'
            
            # Generate dates
            date_range = pd.date_range(start=start_date, end=end_date, freq=freq)
            
            # Generate prices using geometric Brownian motion
            n_periods = len(date_range)
            
            # Base price based on symbol
            base_prices = {
                'BTCUSDT': 50000,
                'ETHUSDT': 3000,
                'ADAUSDT': 1.0,
                'DOTUSDT': 25.0,
                'LINKUSDT': 15.0
            }
            
            initial_price = base_prices.get(symbol, 100.0)
            volatility = 0.02 if 'BTC' in symbol else 0.03
            
            # Generate price path
            dt = 1.0 / (252 * 24 * 60)  # Assuming minute data
            returns = np.random.normal(0, volatility * np.sqrt(dt), n_periods)
            
            # Calculate cumulative prices
            prices = [initial_price]
            for ret in returns[1:]:
                new_price = prices[-1] * (1 + ret)
                prices.append(new_price)
            
            # Create OHLCV data
            data = []
            for i, (date, price) in enumerate(zip(date_range, prices)):
                # Generate OHLC from closing price
                open_price = price * (1 + np.random.normal(0, 0.001))
                high_price = price * (1 + abs(np.random.normal(0, 0.005)))
                low_price = price * (1 - abs(np.random.normal(0, 0.005)))
                close_price = price
                volume = np.random.exponential(1000000)
                
                data.append({
                    'timestamp': date,
                    'symbol': symbol,
                    'open': open_price,
                    'high': max(high_price, open_price, close_price),
                    'low': min(low_price, open_price, close_price),
                    'close': close_price,
                    'volume': volume
                })
            
            df = pd.DataFrame(data)
            df.set_index('timestamp', inplace=True)
            market_data[symbol] = df
        
        return market_data
    
    def _run_strategy(self, strategy: StrategyInterface, market_data: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
        """Strateji çalıştır"""
        print("Running strategy...")
        
        # Initialize strategy
        strategy.initialize(self.event_bus, self.portfolio)
        
        # Process each symbol
        strategy_results = {
            'trades': [],
            'signals': [],
            'equity_curve': [],
            'positions': {}
        }
        
        # Get common time range
        all_timestamps = set()
        for df in market_data.values():
            all_timestamps.update(df.index)
        
        sorted_timestamps = sorted(all_timestamps)
        
        # Process each timestamp
        for timestamp in sorted_timestamps:
            current_prices = {}
            
            # Get current prices for all symbols
            for symbol, df in market_data.items():
                if timestamp in df.index:
                    current_prices[symbol] = df.loc[timestamp, 'close']
            
            # Update portfolio with current prices
            if current_prices:
                self.portfolio.update_market_prices(current_prices)
            
            # Generate signals for each symbol
            for symbol, df in market_data.items():
                if timestamp in df.index:
                    current_data = df.loc[:timestamp].copy()
                    
                    # Create tick event
                    tick_event = TickEvent(
                        symbol=symbol,
                        bid=df.loc[timestamp, 'close'] * 0.9995,
                        ask=df.loc[timestamp, 'close'] * 1.0005,
                        volume=df.loc[timestamp, 'volume'],
                        timestamp=timestamp
                    )
                    
                    # Process strategy logic
                    strategy_events = strategy.on_tick(tick_event)
                    
                    # Handle strategy events
                    for event in strategy_events:
                        if event.event_type == EventType.ORDER_PLACE:
                            # Process order
                            self._process_strategy_order(event, symbol, current_prices.get(symbol, 0))
                        elif event.event_type == EventType.SIGNAL_GENERATE:
                            # Record signal
                            strategy_results['signals'].append({
                                'timestamp': timestamp,
                                'symbol': symbol,
                                'signal_type': event.signal_type,
                                'strength': event.strength
                            })
            
            # Record equity point
            self.portfolio.record_equity_point()
            strategy_results['equity_curve'].append((timestamp, self.portfolio.get_portfolio_value()))
        
        # Get final trades
        strategy_results['trades'] = self.portfolio.trades
        strategy_results['positions'] = dict(self.portfolio.positions)
        
        # Cleanup
        strategy.cleanup()
        
        print(f"Strategy completed. {len(strategy_results['trades'])} trades executed.")
        
        return strategy_results
    
    def _process_strategy_order(self, order_event: Any, symbol: str, price: float) -> None:
        """Strateji order'ını işle"""
        try:
            if hasattr(order_event, 'side') and hasattr(order_event, 'quantity'):
                side = OrderSide.BUY if order_event.side == 'BUY' else OrderSide.SELL
                quantity = order_event.quantity
                
                # Simple execution at current price
                commission = price * quantity * self.config.commission_rate
                
                self.portfolio.execute_trade(
                    symbol=symbol,
                    side=side,
                    quantity=quantity,
                    price=price,
                    commission=commission
                )
        except Exception as e:
            print(f"Error processing strategy order: {e}")
    
    def _calculate_performance_metrics(self, strategy_results: Dict[str, Any]) -> Any:
        """Performance metrikleri hesapla"""
        print("Calculating performance metrics...")
        
        equity_curve = strategy_results['equity_curve']
        trades = strategy_results['trades']
        
        # Convert trades to required format
        trade_data = []
        for trade in trades:
            trade_data.append({
                'pnl': getattr(trade, 'net_amount', 0),
                'timestamp': getattr(trade, 'timestamp', datetime.utcnow())
            })
        
        # Get benchmark data if available
        benchmark_returns = None
        if self.config.benchmark_symbol and self.config.benchmark_symbol in strategy_results:
            benchmark_data = strategy_results[self.config.benchmark_symbol]
            benchmark_returns = benchmark_data['returns'].tolist()
        
        # Calculate metrics
        metrics = self.performance_calculator.calculate_full_metrics(
            equity_curve=equity_curve,
            trades=trade_data,
            benchmark_returns=benchmark_returns
        )
        
        return metrics
    
    def _run_monte_carlo_validation(self, strategy: StrategyInterface, 
                                  market_data: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
        """Monte Carlo validation çalıştır"""
        print("Running Monte Carlo validation...")
        
        # Create a simplified strategy function for Monte Carlo
        def monte_carlo_strategy(data_dict):
            # Simplified strategy function for MC validation
            returns = data_dict.get('returns', np.array([]))
            if len(returns) == 0:
                return None
            
            # Simple momentum strategy
            portfolio_values = []
            initial_capital = 10000
            
            for i in range(1, len(returns)):
                # Simple signal: positive return = buy, negative = sell
                signal = 1.0 if returns[i-1] > 0 else 0.0
                
                # Calculate portfolio value
                portfolio_return = signal * returns[i]
                if i == 1:
                    portfolio_value = initial_capital * (1 + portfolio_return)
                else:
                    portfolio_value = portfolio_values[-1] * (1 + portfolio_return)
                
                portfolio_values.append(portfolio_value)
            
            if portfolio_values:
                final_value = portfolio_values[-1]
                total_return = (final_value - initial_capital) / initial_capital
                
                # Create mock performance metrics
                from ..performance.metrics import PerformanceMetrics
                
                return PerformanceMetrics(
                    total_return=total_return,
                    annualized_return=total_return * 252,  # Rough approximation
                    cumulative_returns=[total_return],
                    volatility=np.std(returns) * np.sqrt(252),
                    max_drawdown=0.1,  # Placeholder
                    var_95=0.05,
                    var_99=0.1,
                    cvar_95=0.06,
                    sharpe_ratio=total_return / (np.std(returns) * np.sqrt(252)) if np.std(returns) > 0 else 0,
                    sortino_ratio=0.5,
                    calmar_ratio=2.0,
                    information_ratio=0.3,
                    max_drawdown_duration=10,
                    avg_drawdown_duration=5,
                    recovery_factor=1.5,
                    total_trades=len(returns) // 10,
                    win_rate=0.6,
                    avg_win=0.02,
                    avg_loss=-0.01,
                    profit_factor=1.5,
                    expectancy=0.001,
                    beta=1.0,
                    alpha=0.05,
                    tracking_error=0.1,
                    up_capture=1.1,
                    down_capture=0.9,
                    skewness=0.1,
                    kurtosis=3.0,
                    jensen_alpha=0.03,
                    treynor_ratio=0.1
                )
            
            return None
        
        # Prepare data for Monte Carlo
        returns_data = {}
        for symbol, df in market_data.items():
            df['returns'] = df['close'].pct_change()
            returns_data[symbol] = df['returns'].dropna().values
        
        # Run Monte Carlo validation
        mc_results = self.monte_carlo_engine.run_backtest_validation(
            strategy_function=monte_carlo_strategy,
            original_data={'returns': np.concatenate(list(returns_data.values()))},
            baseline_performance=None  # Will be calculated from original data
        )
        
        # Robustness check
        robustness_check = self.monte_carlo_engine.validate_strategy_robustness(mc_results)
        
        return {
            'monte_carlo_results': mc_results,
            'robustness_check': robustness_check
        }
    
    def _get_market_data_summary(self, market_data: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
        """Market data özetini getir"""
        summary = {}
        
        for symbol, df in market_data.items():
            summary[symbol] = {
                'period_start': df.index.min(),
                'period_end': df.index.max(),
                'data_points': len(df),
                'price_range': {
                    'min': df['close'].min(),
                    'max': df['close'].max(),
                    'mean': df['close'].mean(),
                    'std': df['close'].std()
                },
                'volume_stats': {
                    'total': df['volume'].sum(),
                    'mean': df['volume'].mean(),
                    'std': df['volume'].std()
                }
            }
        
        return summary
    
    def get_results(self) -> Dict[str, Any]:
        """Backtest sonuçlarını getir"""
        return self.results.copy()
    
    def generate_report(self) -> str:
        """Backtest raporu oluştur"""
        if not self.results:
            return "No results available. Run backtest first."
        
        report = []
        
        # Header
        report.append("=" * 80)
        report.append("BITWISERS 2.0 BACKTEST REPORT")
        report.append("=" * 80)
        report.append("")
        
        # Configuration
        config = self.results.get('config', {})
        report.append("BACKTEST CONFIGURATION:")
        report.append(f"Strategy: {config.get('strategy_name', 'Unknown')}")
        report.append(f"Period: {config.get('start_date')} to {config.get('end_date')}")
        report.append(f"Symbols: {', '.join(config.get('symbols', []))}")
        report.append(f"Initial Capital: ${config.get('initial_capital', 0):,.2f}")
        report.append("")
        
        # Performance Metrics
        if 'performance_metrics' in self.results:
            metrics = self.results['performance_metrics']
            report.append("PERFORMANCE METRICS:")
            report.append(f"Total Return: {metrics.total_return:.2%}")
            report.append(f"Annualized Return: {metrics.annualized_return:.2%}")
            report.append(f"Volatility: {metrics.volatility:.2%}")
            report.append(f"Max Drawdown: {metrics.max_drawdown:.2%}")
            report.append(f"Sharpe Ratio: {metrics.sharpe_ratio:.3f}")
            report.append(f"Sortino Ratio: {metrics.sortino_ratio:.3f}")
            report.append(f"Win Rate: {metrics.win_rate:.2%}")
            report.append(f"Total Trades: {metrics.total_trades}")
            report.append("")
        
        # Monte Carlo Results
        if 'monte_carlo' in self.results:
            mc_data = self.results['monte_carlo']
            robustness = mc_data.get('robustness_check', {})
            
            report.append("MONTE CARLO VALIDATION:")
            if 'overall_robustness_score' in robustness:
                report.append(f"Robustness Score: {robustness['overall_robustness_score']:.2%}")
                report.append(f"Is Robust: {'YES' if robustness.get('is_robust', False) else 'NO'}")
            report.append("")
        
        return "\n".join(report)
    
    def save_results(self, filepath: str) -> None:
        """Sonuçları dosyaya kaydet"""
        import json
        from datetime import datetime
        
        # Convert results to JSON-serializable format
        serializable_results = {}
        
        for key, value in self.results.items():
            if key == 'performance_metrics':
                # Convert PerformanceMetrics to dict
                serializable_results[key] = {
                    'total_return': value.total_return,
                    'annualized_return': value.annualized_return,
                    'volatility': value.volatility,
                    'max_drawdown': value.max_drawdown,
                    'sharpe_ratio': value.sharpe_ratio,
                    'sortino_ratio': value.sortino_ratio,
                    'win_rate': value.win_rate,
                    'total_trades': value.total_trades
                }
            else:
                serializable_results[key] = value
        
        with open(filepath, 'w') as f:
            json.dump(serializable_results, f, indent=2, default=str)
        
        print(f"Results saved to {filepath}")


# Example strategies for testing
class SMAStrategy(StrategyInterface):
    """Simple Moving Average Crossover Strategy"""
    
    def __init__(self, fast_period: int = 10, slow_period: int = 20):
        self.fast_period = fast_period
        self.slow_period = slow_period
        self.data_buffer = {}
    
    def initialize(self, event_bus: EventBus, portfolio: Portfolio) -> None:
        """Initialize strategy"""
        self.event_bus = event_bus
        self.portfolio = portfolio
        print(f"SMA Strategy initialized: Fast={self.fast_period}, Slow={self.slow_period}")
    
    def on_tick(self, tick_event: TickEvent) -> List:
        """Process tick event"""
        symbol = tick_event.symbol
        
        if symbol not in self.data_buffer:
            self.data_buffer[symbol] = []
        
        # Add price to buffer
        self.data_buffer[symbol].append(tick_event.mid_price)
        
        # Keep only necessary data
        max_period = max(self.fast_period, self.slow_period)
        if len(self.data_buffer[symbol]) > max_period:
            self.data_buffer[symbol] = self.data_buffer[symbol][-max_period:]
        
        # Generate signal if we have enough data
        if len(self.data_buffer[symbol]) >= self.slow_period:
            return self._generate_signal(symbol)
        
        return []
    
    def _generate_signal(self, symbol: str) -> List:
        """Generate trading signal"""
        prices = self.data_buffer[symbol]
        
        # Calculate SMAs
        fast_sma = np.mean(prices[-self.fast_period:])
        slow_sma = np.mean(prices[-self.slow_period:])
        
        # Previous SMAs for crossover detection
        if len(prices) >= self.slow_period + 1:
            prev_fast_sma = np.mean(prices[-(self.fast_period + 1):-1])
            prev_slow_sma = np.mean(prices[-(self.slow_period + 1):-1])
        else:
            prev_fast_sma = fast_sma
            prev_slow_sma = slow_sma
        
        # Generate signals
        events = []
        
        # Golden cross (fast SMA crosses above slow SMA)
        if prev_fast_sma <= prev_slow_sma and fast_sma > slow_sma:
            # Buy signal
            from ..core.event_system import Event, SignalEvent
            signal_event = SignalEvent(
                symbol=symbol,
                signal_type='BUY',
                strength=(fast_sma - slow_sma) / slow_sma,
                indicators={'fast_sma': fast_sma, 'slow_sma': slow_sma},
                timestamp=tick_event.timestamp
            )
            events.append(signal_event)
        
        # Death cross (fast SMA crosses below slow SMA)
        elif prev_fast_sma >= prev_slow_sma and fast_sma < slow_sma:
            # Sell signal
            from ..core.event_system import Event, SignalEvent
            signal_event = SignalEvent(
                symbol=symbol,
                signal_type='SELL',
                strength=(slow_sma - fast_sma) / slow_sma,
                indicators={'fast_sma': fast_sma, 'slow_sma': slow_sma},
                timestamp=tick_event.timestamp
            )
            events.append(signal_event)
        
        return events
    
    def cleanup(self) -> None:
        """Cleanup resources"""
        pass


class RSIStrategy(StrategyInterface):
    """RSI Mean Reversion Strategy"""
    
    def __init__(self, period: int = 14, oversold: float = 30, overbought: float = 70):
        self.period = period
        self.oversold = oversold
        self.overbought = overbought
        self.data_buffer = {}
    
    def initialize(self, event_bus: EventBus, portfolio: Portfolio) -> None:
        """Initialize strategy"""
        self.event_bus = event_bus
        self.portfolio = portfolio
    
    def on_tick(self, tick_event: TickEvent) -> List:
        """Process tick event"""
        symbol = tick_event.symbol
        
        if symbol not in self.data_buffer:
            self.data_buffer[symbol] = []
        
        # Add price to buffer
        self.data_buffer[symbol].append(tick_event.mid_price)
        
        # Keep only necessary data
        if len(self.data_buffer[symbol]) > self.period + 1:
            self.data_buffer[symbol] = self.data_buffer[symbol][-(self.period + 1):]
        
        # Generate signal if we have enough data
        if len(self.data_buffer[symbol]) >= self.period + 1:
            return self._generate_signal(symbol)
        
        return []
    
    def _generate_signal(self, symbol: str) -> List:
        """Generate RSI signal"""
        prices = self.data_buffer[symbol]
        
        # Calculate RSI
        deltas = np.diff(prices)
        gains = np.where(deltas > 0, deltas, 0)
        losses = np.where(deltas < 0, -deltas, 0)
        
        avg_gain = np.mean(gains)
        avg_loss = np.mean(losses)
        
        if avg_loss == 0:
            rsi = 100
        else:
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
        
        # Generate signals
        events = []
        
        # Oversold condition (RSI < oversold level) -> Buy
        if rsi < self.oversold:
            from ..core.event_system import SignalEvent
            signal_event = SignalEvent(
                symbol=symbol,
                signal_type='BUY',
                strength=(self.oversold - rsi) / self.oversold,
                indicators={'rsi': rsi},
                timestamp=datetime.utcnow()
            )
            events.append(signal_event)
        
        # Overbought condition (RSI > overbought level) -> Sell
        elif rsi > self.overbought:
            from ..core.event_system import SignalEvent
            signal_event = SignalEvent(
                symbol=symbol,
                signal_type='SELL',
                strength=(rsi - self.overbought) / self.overbought,
                indicators={'rsi': rsi},
                timestamp=datetime.utcnow()
            )
            events.append(signal_event)
        
        return events
    
    def cleanup(self) -> None:
        """Cleanup resources"""
        pass