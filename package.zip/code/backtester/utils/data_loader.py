"""
TimescaleDB Data Loader
TimescaleDB'den veri çekme ve işleme
"""

import psycopg2
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
import logging
from contextlib import contextmanager
import asyncio


class TimescaleDBConnector:
    """TimescaleDB bağlantı yöneticisi"""
    
    def __init__(self, host: str = "localhost", port: int = 5432,
                 database: str = "bitwisers", user: str = "postgres",
                 password: str = "password"):
        self.host = host
        self.port = port
        self.database = database
        self.user = user
        self.password = password
        
        self.connection = None
        self.logger = logging.getLogger(__name__)
    
    def connect(self) -> None:
        """TimescaleDB'ye bağlan"""
        try:
            self.connection = psycopg2.connect(
                host=self.host,
                port=self.port,
                database=self.database,
                user=self.user,
                password=self.password
            )
            self.logger.info("Connected to TimescaleDB successfully")
        except Exception as e:
            self.logger.error(f"Failed to connect to TimescaleDB: {e}")
            raise
    
    def disconnect(self) -> None:
        """Bağlantıyı kapat"""
        if self.connection:
            self.connection.close()
            self.logger.info("Disconnected from TimescaleDB")
    
    @contextmanager
    def get_cursor(self):
        """Context manager for cursor"""
        if not self.connection:
            raise Exception("Not connected to database")
        
        cursor = self.connection.cursor()
        try:
            yield cursor
            self.connection.commit()
        except Exception as e:
            self.connection.rollback()
            raise e
        finally:
            cursor.close()
    
    def get_market_data_batch(self, symbols: List[str], start_time: datetime,
                             batch_size: int = 1000) -> pd.DataFrame:
        """Market verilerini batch olarak getir"""
        query = """
        SELECT 
            time as timestamp,
            symbol,
            open_price as open,
            high_price as high,
            low_price as low,
            close_price as close,
            volume,
            (bid + ask) / 2 as mid_price,
            bid,
            ask
        FROM market_data 
        WHERE symbol = ANY(%s)
        AND time >= %s
        ORDER BY symbol, time
        LIMIT %s
        """
        
        with self.get_cursor() as cursor:
            cursor.execute(query, (symbols, start_time, batch_size))
            
            columns = [desc[0] for desc in cursor.description]
            rows = cursor.fetchall()
            
            if rows:
                df = pd.DataFrame(rows, columns=columns)
                df['timestamp'] = pd.to_datetime(df['timestamp'])
                return df
            else:
                return pd.DataFrame()
    
    def get_ohlcv_data(self, symbol: str, start_time: datetime, 
                      end_time: datetime, interval: str = '1 minute') -> pd.DataFrame:
        """OHLCV verilerini getir"""
        query = """
        SELECT 
            time_bucket(%s, time) AS bucket,
            symbol,
            first(open_price, time) AS open,
            max(high_price) AS high,
            min(low_price) AS low,
            last(close_price, time) AS close,
            sum(volume) AS volume
        FROM market_data 
        WHERE symbol = %s
        AND time BETWEEN %s AND %s
        GROUP BY bucket, symbol
        ORDER BY bucket
        """
        
        with self.get_cursor() as cursor:
            cursor.execute(query, (interval, symbol, start_time, end_time))
            
            columns = [desc[0] for desc in cursor.description]
            rows = cursor.fetchall()
            
            if rows:
                df = pd.DataFrame(rows, columns=columns)
                df['bucket'] = pd.to_datetime(df['bucket'])
                return df
            else:
                return pd.DataFrame()
    
    def get_technical_indicators(self, symbol: str, indicator_name: str,
                               start_time: datetime, end_time: datetime) -> pd.DataFrame:
        """Teknik indikatör verilerini getir"""
        query = """
        SELECT 
            time,
            value,
            values_array,
            indicator_params
        FROM technical_indicators 
        WHERE symbol = %s
        AND indicator_name = %s
        AND time BETWEEN %s AND %s
        ORDER BY time
        """
        
        with self.get_cursor() as cursor:
            cursor.execute(query, (symbol, indicator_name, start_time, end_time))
            
            columns = [desc[0] for desc in cursor.description]
            rows = cursor.fetchall()
            
            if rows:
                df = pd.DataFrame(rows, columns=columns)
                df['time'] = pd.to_datetime(df['time'])
                return df
            else:
                return pd.DataFrame()
    
    def get_price_series(self, symbols: List[str], start_time: datetime,
                        end_time: datetime, price_type: str = 'close') -> pd.DataFrame:
        """Fiyat serilerini getir"""
        price_columns = {
            'open': 'open_price',
            'high': 'high_price',
            'low': 'low_price',
            'close': 'close_price'
        }
        
        if price_type not in price_columns:
            raise ValueError(f"Invalid price type: {price_type}")
        
        column_name = price_columns[price_type]
        
        query = f"""
        SELECT 
            time,
            symbol,
            {column_name} as price
        FROM market_data 
        WHERE symbol = ANY(%s)
        AND time BETWEEN %s AND %s
        ORDER BY symbol, time
        """
        
        with self.get_cursor() as cursor:
            cursor.execute(query, (symbols, start_time, end_time))
            
            columns = [desc[0] for desc in cursor.description]
            rows = cursor.fetchall()
            
            if rows:
                df = pd.DataFrame(rows, columns=columns)
                df['time'] = pd.to_datetime(df['time'])
                return df
            else:
                return pd.DataFrame()
    
    def get_volume_data(self, symbols: List[str], start_time: datetime,
                       end_time: datetime) -> pd.DataFrame:
        """Volume verilerini getir"""
        query = """
        SELECT 
            time_bucket('1 minute', time) AS bucket,
            symbol,
            sum(volume) AS volume,
            count(*) AS trade_count
        FROM market_data 
        WHERE symbol = ANY(%s)
        AND time BETWEEN %s AND %s
        GROUP BY bucket, symbol
        ORDER BY bucket
        """
        
        with self.get_cursor() as cursor:
            cursor.execute(query, (symbols, start_time, end_time))
            
            columns = [desc[0] for desc in cursor.description]
            rows = cursor.fetchall()
            
            if rows:
                df = pd.DataFrame(rows, columns=columns)
                df['bucket'] = pd.to_datetime(df['bucket'])
                return df
            else:
                return pd.DataFrame()


class DataPreprocessor:
    """Veri ön işleme sınıfı"""
    
    @staticmethod
    def clean_market_data(df: pd.DataFrame) -> pd.DataFrame:
        """Market verilerini temizle"""
        if df.empty:
            return df
        
        # Remove rows with null prices
        df = df.dropna(subset=['open', 'high', 'low', 'close'])
        
        # Remove invalid prices (negative or zero)
        price_columns = ['open', 'high', 'low', 'close']
        for col in price_columns:
            df = df[df[col] > 0]
        
        # Ensure OHLC validity
        df = df[(df['high'] >= df['open']) & 
                (df['high'] >= df['close']) &
                (df['low'] <= df['open']) & 
                (df['low'] <= df['close'])]
        
        # Sort by timestamp
        if 'timestamp' in df.columns:
            df = df.sort_values('timestamp')
        elif 'bucket' in df.columns:
            df = df.sort_values('bucket')
        
        return df
    
    @staticmethod
    def resample_data(df: pd.DataFrame, target_interval: str = '1T') -> pd.DataFrame:
        """Veriyi yeniden örnekle"""
        if df.empty or 'timestamp' not in df.columns:
            return df
        
        # Set timestamp as index
        df_indexed = df.set_index('timestamp')
        
        # Resample
        ohlc_dict = {
            'open': 'first',
            'high': 'max',
            'low': 'min',
            'close': 'last',
            'volume': 'sum'
        }
        
        resampled = df_indexed.resample(target_interval).agg(ohlc_dict)
        resampled = resampled.dropna()
        
        # Reset index
        resampled = resampled.reset_index()
        
        return resampled
    
    @staticmethod
    def calculate_returns(df: pd.DataFrame, price_column: str = 'close') -> pd.DataFrame:
        """Getiri hesapla"""
        df = df.copy()
        
        if price_column in df.columns:
            df['returns'] = df[price_column].pct_change()
            df['log_returns'] = np.log(df[price_column] / df[price_column].shift(1))
        
        return df
    
    @staticmethod
    def add_technical_features(df: pd.DataFrame) -> pd.DataFrame:
        """Teknik özellikler ekle"""
        df = df.copy()
        
        if 'close' in df.columns:
            # Moving averages
            df['sma_5'] = df['close'].rolling(window=5).mean()
            df['sma_20'] = df['close'].rolling(window=20).mean()
            df['ema_12'] = df['close'].ewm(span=12).mean()
            df['ema_26'] = df['close'].ewm(span=26).mean()
            
            # RSI
            df['rsi'] = DataPreprocessor._calculate_rsi(df['close'])
            
            # Bollinger Bands
            df['bb_upper'], df['bb_lower'] = DataPreprocessor._calculate_bollinger_bands(df['close'])
            
            # MACD
            df['macd'], df['macd_signal'] = DataPreprocessor._calculate_macd(df['close'])
        
        return df
    
    @staticmethod
    def _calculate_rsi(prices: pd.Series, period: int = 14) -> pd.Series:
        """RSI hesapla"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
    
    @staticmethod
    def _calculate_bollinger_bands(prices: pd.Series, period: int = 20, 
                                 std_dev: float = 2) -> Tuple[pd.Series, pd.Series]:
        """Bollinger Bands hesapla"""
        sma = prices.rolling(window=period).mean()
        std = prices.rolling(window=period).std()
        
        upper = sma + (std * std_dev)
        lower = sma - (std * std_dev)
        
        return upper, lower
    
    @staticmethod
    def _calculate_macd(prices: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> Tuple[pd.Series, pd.Series]:
        """MACD hesapla"""
        ema_fast = prices.ewm(span=fast).mean()
        ema_slow = prices.ewm(span=slow).mean()
        
        macd = ema_fast - ema_slow
        macd_signal = macd.ewm(span=signal).mean()
        
        return macd, macd_signal


class DataValidator:
    """Veri doğrulama sınıfı"""
    
    @staticmethod
    def validate_market_data(df: pd.DataFrame) -> Dict[str, Any]:
        """Market verilerini doğrula"""
        if df.empty:
            return {'valid': False, 'errors': ['DataFrame is empty']}
        
        errors = []
        warnings = []
        
        # Check required columns
        required_columns = ['timestamp', 'symbol', 'open', 'high', 'low', 'close']
        missing_columns = [col for col in required_columns if col not in df.columns]
        
        if missing_columns:
            errors.append(f"Missing required columns: {missing_columns}")
        
        # Check data quality
        if not df.empty:
            # Null values
            null_counts = df.isnull().sum()
            if null_counts.any():
                warnings.append(f"Null values found: {null_counts.to_dict()}")
            
            # Price validity
            price_columns = ['open', 'high', 'low', 'close']
            for col in price_columns:
                if col in df.columns:
                    negative_prices = (df[col] <= 0).sum()
                    if negative_prices > 0:
                        errors.append(f"Found {negative_prices} non-positive prices in {col}")
                    
                    zero_prices = (df[col] == 0).sum()
                    if zero_prices > 0:
                        errors.append(f"Found {zero_prices} zero prices in {col}")
            
            # OHLC logic
            invalid_ohlc = (
                (df['high'] < df['open']) |
                (df['high'] < df['close']) |
                (df['low'] > df['open']) |
                (df['low'] > df['close'])
            ).sum()
            
            if invalid_ohlc > 0:
                errors.append(f"Found {invalid_ohlc} rows with invalid OHLC logic")
            
            # Time series continuity
            df_sorted = df.sort_values('timestamp')
            time_diffs = df_sorted['timestamp'].diff().dropna()
            median_diff = time_diffs.median()
            
            if median_diff > timedelta(minutes=60):
                warnings.append(f"Large time gaps detected, median interval: {median_diff}")
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings,
            'row_count': len(df),
            'date_range': {
                'start': df['timestamp'].min() if not df.empty else None,
                'end': df['timestamp'].max() if not df.empty else None
            }
        }


class DataCache:
    """Veri önbellekleme sistemi"""
    
    def __init__(self, cache_size: int = 1000):
        self.cache = {}
        self.cache_size = cache_size
        self.access_count = {}
    
    def get(self, key: str) -> Optional[Any]:
        """Cache'den veri getir"""
        if key in self.cache:
            self.access_count[key] = self.access_count.get(key, 0) + 1
            return self.cache[key]
        return None
    
    def set(self, key: str, data: Any) -> None:
        """Cache'e veri koy"""
        # LRU eviction
        if len(self.cache) >= self.cache_size:
            self._evict_lru()
        
        self.cache[key] = data
        self.access_count[key] = 1
    
    def _evict_lru(self) -> None:
        """En az kullanılanı çıkar"""
        if not self.access_count:
            return
        
        lru_key = min(self.access_count.keys(), key=lambda k: self.access_count[k])
        del self.cache[lru_key]
        del self.access_count[lru_key]
    
    def clear(self) -> None:
        """Cache'i temizle"""
        self.cache.clear()
        self.access_count.clear()


class BacktestDataManager:
    """Backtest için veri yönetimi"""
    
    def __init__(self, db_connector: TimescaleDBConnector):
        self.db = db_connector
        self.cache = DataCache()
        self.preprocessor = DataPreprocessor()
        self.validator = DataValidator()
    
    def load_backtest_data(self, symbols: List[str], start_time: datetime,
                          end_time: datetime, interval: str = '1 minute') -> Dict[str, pd.DataFrame]:
        """Backtest verilerini yükle"""
        data_dict = {}
        
        for symbol in symbols:
            # Cache key oluştur
            cache_key = f"{symbol}_{start_time}_{end_time}_{interval}"
            
            # Cache'den kontrol et
            cached_data = self.cache.get(cache_key)
            if cached_data is not None:
                data_dict[symbol] = cached_data
                continue
            
            # Veritabanından çek
            df = self.db.get_ohlcv_data(symbol, start_time, end_time, interval)
            
            if not df.empty:
                # Temizle ve doğrula
                df = self.preprocessor.clean_market_data(df)
                df = self.preprocessor.add_technical_features(df)
                
                # Validasyon
                validation_result = self.validator.validate_market_data(df)
                
                if not validation_result['valid']:
                    print(f"Warning: Data validation failed for {symbol}")
                    print(f"Errors: {validation_result['errors']}")
                
                # Cache'e koy
                self.cache.set(cache_key, df)
                data_dict[symbol] = df
            else:
                print(f"Warning: No data found for {symbol}")
        
        return data_dict
    
    def get_real_time_price(self, symbol: str) -> Optional[float]:
        """Gerçek zamanlı fiyat getir"""
        cache_key = f"realtime_{symbol}"
        cached_price = self.cache.get(cache_key)
        
        if cached_price is not None:
            return cached_price
        
        # En son fiyatı çek
        query = """
        SELECT close_price
        FROM market_data 
        WHERE symbol = %s
        ORDER BY time DESC
        LIMIT 1
        """
        
        try:
            with self.db.get_cursor() as cursor:
                cursor.execute(query, (symbol,))
                result = cursor.fetchone()
                
                if result:
                    price = float(result[0])
                    self.cache.set(cache_key, price)
                    return price
        except Exception as e:
            print(f"Error fetching real-time price for {symbol}: {e}")
        
        return None