"""
Performance Metrics Calculator
Backtest sonuçları için kapsamlı performans metrikleri
"""

import numpy as np
import pandas as pd
from datetime import datetime
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
import scipy.stats as stats
from scipy.optimize import minimize_scalar


@dataclass
class PerformanceMetrics:
    """Performance metrics data class"""
    # Return Metrics
    total_return: float
    annualized_return: float
    cumulative_returns: List[float]
    
    # Risk Metrics
    volatility: float
    max_drawdown: float
    var_95: float  # Value at Risk 95%
    var_99: float  # Value at Risk 99%
    cvar_95: float  # Conditional Value at Risk 95%
    
    # Risk-Adjusted Metrics
    sharpe_ratio: float
    sortino_ratio: float
    calmar_ratio: float
    information_ratio: float
    
    # Drawdown Analysis
    max_drawdown_duration: int
    avg_drawdown_duration: int
    recovery_factor: float
    
    # Trading Metrics
    total_trades: int
    win_rate: float
    avg_win: float
    avg_loss: float
    profit_factor: float
    expectancy: float
    
    # Benchmark Comparison
    beta: float
    alpha: float
    tracking_error: float
    up_capture: float
    down_capture: float
    
    # Additional Metrics
    skewness: float
    kurtosis: float
    jensen_alpha: float
    treynor_ratio: float


class PerformanceCalculator:
    """Ana performance hesaplayıcısı"""
    
    def __init__(self, risk_free_rate: float = 0.02, trading_days: int = 252):
        self.risk_free_rate = risk_free_rate
        self.trading_days = trading_days
    
    def calculate_full_metrics(self, equity_curve: List[Tuple[datetime, float]],
                             trades: List[Dict[str, Any]],
                             benchmark_returns: Optional[List[float]] = None) -> PerformanceMetrics:
        """Tüm performance metriklerini hesapla"""
        
        # Convert to pandas for easier calculation
        df = pd.DataFrame(equity_curve, columns=['timestamp', 'equity'])
        df['returns'] = df['equity'].pct_change()
        df['cumulative_returns'] = (1 + df['returns']).cumprod() - 1
        
        # Basic metrics
        total_return = df['cumulative_returns'].iloc[-1] if len(df) > 0 else 0
        returns = df['returns'].dropna()
        
        # Annualized return
        time_period = (df['timestamp'].iloc[-1] - df['timestamp'].iloc[0]).days / 365.25
        annualized_return = (1 + total_return) ** (1 / time_period) - 1 if time_period > 0 else 0
        
        # Risk metrics
        volatility = returns.std() * np.sqrt(self.trading_days)
        max_drawdown = self._calculate_max_drawdown(df['equity'].values)
        var_95 = self._calculate_var(returns, 0.05)
        var_99 = self._calculate_var(returns, 0.01)
        cvar_95 = self._calculate_cvar(returns, 0.05)
        
        # Risk-adjusted metrics
        excess_returns = returns - self.risk_free_rate / self.trading_days
        sharpe_ratio = excess_returns.mean() / returns.std() * np.sqrt(self.trading_days) if returns.std() > 0 else 0
        sortino_ratio = self._calculate_sortino_ratio(excess_returns, returns)
        calmar_ratio = annualized_return / max_drawdown if max_drawdown > 0 else 0
        
        # Drawdown analysis
        dd_duration = self._calculate_drawdown_duration(df['equity'].values)
        recovery_factor = total_return / max_drawdown if max_drawdown > 0 else 0
        
        # Trading metrics
        trade_metrics = self._calculate_trade_metrics(trades)
        
        # Benchmark comparison
        if benchmark_returns is not None and len(benchmark_returns) == len(returns):
            beta, alpha, information_ratio, tracking_error = self._calculate_benchmark_metrics(
                returns.values, np.array(benchmark_returns))
            up_capture, down_capture = self._calculate_capture_ratios(returns.values, np.array(benchmark_returns))
        else:
            beta = alpha = information_ratio = tracking_error = up_capture = down_capture = 0
        
        # Additional metrics
        skewness = stats.skew(returns)
        kurtosis = stats.kurtosis(returns)
        jensen_alpha = annualized_return - (self.risk_free_rate + beta * (np.mean(benchmark_returns) - self.risk_free_rate))
        treynor_ratio = annualized_return / beta if beta != 0 else 0
        
        return PerformanceMetrics(
            # Return metrics
            total_return=total_return,
            annualized_return=annualized_return,
            cumulative_returns=df['cumulative_returns'].tolist(),
            
            # Risk metrics
            volatility=volatility,
            max_drawdown=max_drawdown,
            var_95=var_95,
            var_99=var_99,
            cvar_95=cvar_95,
            
            # Risk-adjusted metrics
            sharpe_ratio=sharpe_ratio,
            sortino_ratio=sortino_ratio,
            calmar_ratio=calmar_ratio,
            information_ratio=information_ratio,
            
            # Drawdown analysis
            max_drawdown_duration=dd_duration['max'],
            avg_drawdown_duration=dd_duration['avg'],
            recovery_factor=recovery_factor,
            
            # Trading metrics
            total_trades=trade_metrics['total_trades'],
            win_rate=trade_metrics['win_rate'],
            avg_win=trade_metrics['avg_win'],
            avg_loss=trade_metrics['avg_loss'],
            profit_factor=trade_metrics['profit_factor'],
            expectancy=trade_metrics['expectancy'],
            
            # Benchmark comparison
            beta=beta,
            alpha=alpha,
            tracking_error=tracking_error,
            up_capture=up_capture,
            down_capture=down_capture,
            
            # Additional metrics
            skewness=skewness,
            kurtosis=kurtosis,
            jensen_alpha=jensen_alpha,
            treynor_ratio=treynor_ratio
        )
    
    def _calculate_max_drawdown(self, equity: np.ndarray) -> float:
        """Maximum drawdown hesapla"""
        peak = np.maximum.accumulate(equity)
        drawdown = (equity - peak) / peak
        return -np.min(drawdown)  # Return as positive number
    
    def _calculate_var(self, returns: pd.Series, confidence_level: float) -> float:
        """Value at Risk hesapla"""
        return -np.percentile(returns, confidence_level * 100)
    
    def _calculate_cvar(self, returns: pd.Series, confidence_level: float) -> float:
        """Conditional Value at Risk hesapla"""
        var = self._calculate_var(returns, confidence_level)
        return -returns[returns <= -var].mean()
    
    def _calculate_sortino_ratio(self, excess_returns: np.ndarray, returns: pd.Series) -> float:
        """Sortino ratio hesapla"""
        downside_returns = returns[returns < 0]
        if len(downside_returns) == 0:
            return np.inf
        
        downside_deviation = np.std(downside_returns)
        return np.mean(excess_returns) / downside_deviation * np.sqrt(self.trading_days) if downside_deviation > 0 else 0
    
    def _calculate_drawdown_duration(self, equity: np.ndarray) -> Dict[str, int]:
        """Drawdown sürelerini hesapla"""
        peak = np.maximum.accumulate(equity)
        drawdown = equity < peak
        
        # Find drawdown periods
        drawdown_periods = []
        in_drawdown = False
        start_idx = 0
        
        for i, is_dd in enumerate(drawdown):
            if is_dd and not in_drawdown:
                in_drawdown = True
                start_idx = i
            elif not is_dd and in_drawdown:
                in_drawdown = False
                drawdown_periods.append(i - start_idx)
        
        # Handle case where drawdown is ongoing
        if in_drawdown:
            drawdown_periods.append(len(drawdown) - start_idx)
        
        if drawdown_periods:
            return {
                'max': max(drawdown_periods),
                'avg': int(np.mean(drawdown_periods))
            }
        else:
            return {'max': 0, 'avg': 0}
    
    def _calculate_trade_metrics(self, trades: List[Dict[str, Any]]) -> Dict[str, float]:
        """Trading metrikleri hesapla"""
        if not trades:
            return {
                'total_trades': 0,
                'win_rate': 0,
                'avg_win': 0,
                'avg_loss': 0,
                'profit_factor': 0,
                'expectancy': 0
            }
        
        # Calculate individual trade P&L
        trade_pnls = []
        for trade in trades:
            pnl = trade.get('pnl', 0)
            trade_pnls.append(pnl)
        
        trade_pnls = np.array(trade_pnls)
        
        # Winning and losing trades
        winning_trades = trade_pnls[trade_pnls > 0]
        losing_trades = trade_pnls[trade_pnls < 0]
        
        total_trades = len(trades)
        win_rate = len(winning_trades) / total_trades if total_trades > 0 else 0
        avg_win = np.mean(winning_trades) if len(winning_trades) > 0 else 0
        avg_loss = np.mean(losing_trades) if len(losing_trades) > 0 else 0
        
        # Profit factor
        gross_profit = np.sum(winning_trades)
        gross_loss = abs(np.sum(losing_trades))
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else 0
        
        # Expectancy
        expectancy = (win_rate * avg_win) + ((1 - win_rate) * avg_loss)
        
        return {
            'total_trades': total_trades,
            'win_rate': win_rate,
            'avg_win': avg_win,
            'avg_loss': avg_loss,
            'profit_factor': profit_factor,
            'expectancy': expectancy
        }
    
    def _calculate_benchmark_metrics(self, returns: np.ndarray, 
                                   benchmark_returns: np.ndarray) -> Tuple[float, float, float, float]:
        """Benchmark karşılaştırma metrikleri hesapla"""
        # Beta calculation
        covariance = np.cov(returns, benchmark_returns)[0, 1]
        benchmark_variance = np.var(benchmark_returns)
        beta = covariance / benchmark_variance if benchmark_variance > 0 else 0
        
        # Alpha calculation
        alpha = np.mean(returns) - beta * np.mean(benchmark_returns)
        
        # Information ratio
        active_returns = returns - benchmark_returns
        information_ratio = np.mean(active_returns) / np.std(active_returns) if np.std(active_returns) > 0 else 0
        
        # Tracking error
        tracking_error = np.std(active_returns)
        
        return beta, alpha, information_ratio, tracking_error
    
    def _calculate_capture_ratios(self, returns: np.ndarray, 
                                benchmark_returns: np.ndarray) -> Tuple[float, float]:
        """Up/Down capture ratio hesapla"""
        # Up capture
        up_benchmark_returns = benchmark_returns[benchmark_returns > 0]
        up_returns = returns[benchmark_returns > 0]
        
        up_capture = (np.mean(up_returns) / np.mean(up_benchmark_returns) 
                     if len(up_benchmark_returns) > 0 and np.mean(up_benchmark_returns) > 0 else 0)
        
        # Down capture
        down_benchmark_returns = benchmark_returns[benchmark_returns < 0]
        down_returns = returns[benchmark_returns < 0]
        
        down_capture = (np.mean(down_returns) / np.mean(down_benchmark_returns) 
                       if len(down_benchmark_returns) > 0 and np.mean(down_benchmark_returns) < 0 else 0)
        
        return up_capture, down_capture


class AdvancedAnalytics:
    """Gelişmiş analitik araçları"""
    
    @staticmethod
    def calculate_rolling_metrics(equity_curve: List[Tuple[datetime, float]],
                                window: int = 252) -> Dict[str, List[float]]:
        """Rolling metrics hesapla"""
        df = pd.DataFrame(equity_curve, columns=['timestamp', 'equity'])
        df['returns'] = df['equity'].pct_change()
        
        # Rolling metrics
        rolling_sharpe = df['returns'].rolling(window).mean() / df['returns'].rolling(window).std() * np.sqrt(252)
        rolling_volatility = df['returns'].rolling(window).std() * np.sqrt(252)
        rolling_max_dd = df['equity'].rolling(window).apply(lambda x: AdvancedAnalytics._calculate_max_drawdown(x.values))
        
        return {
            'rolling_sharpe': rolling_sharpe.tolist(),
            'rolling_volatility': rolling_volatility.tolist(),
            'rolling_max_dd': rolling_max_dd.tolist()
        }
    
    @staticmethod
    def _calculate_max_drawdown(equity: np.ndarray) -> float:
        """Max drawdown helper"""
        peak = np.maximum.accumulate(equity)
        drawdown = (equity - peak) / peak
        return -np.min(drawdown)
    
    @staticmethod
    def analyze_monthly_returns(equity_curve: List[Tuple[datetime, float]]) -> Dict[str, Any]:
        """Aylık getiri analizi"""
        df = pd.DataFrame(equity_curve, columns=['timestamp', 'equity'])
        df['year_month'] = df['timestamp'].dt.to_period('M')
        df['returns'] = df['equity'].pct_change()
        
        monthly_returns = df.groupby('year_month')['returns'].apply(
            lambda x: (1 + x).prod() - 1
        )
        
        return {
            'monthly_returns': monthly_returns.tolist(),
            'months': [str(period) for period in monthly_returns.index],
            'best_month': monthly_returns.max(),
            'worst_month': monthly_returns.min(),
            'positive_months': (monthly_returns > 0).sum(),
            'negative_months': (monthly_returns < 0).sum(),
            'avg_monthly_return': monthly_returns.mean(),
            'monthly_volatility': monthly_returns.std()
        }
    
    @staticmethod
    def calculate_var_backtest(returns: pd.Series, confidence_levels: List[float] = [0.01, 0.05]) -> Dict[float, float]:
        """Historical VaR backtesting"""
        results = {}
        
        for confidence_level in confidence_levels:
            # Historical VaR
            var = np.percentile(returns, confidence_level * 100)
            
            # Number of violations
            violations = (returns < var).sum()
            violation_rate = violations / len(returns)
            
            results[confidence_level] = {
                'var': var,
                'violations': violations,
                'violation_rate': violation_rate
            }
        
        return results
    
    @staticmethod
    def stress_test(equity_curve: List[Tuple[datetime, float]], 
                   shock_scenarios: List[Dict[str, float]]) -> Dict[str, Dict[str, float]]:
        """Stress test scenarios"""
        df = pd.DataFrame(equity_curve, columns=['timestamp', 'equity'])
        current_value = df['equity'].iloc[-1]
        
        results = {}
        
        for scenario_name, shock in shock_scenarios.items():
            if 'price_shock' in shock:
                # Price shock scenario
                shocked_value = current_value * (1 + shock['price_shock'])
                impact = (shocked_value - current_value) / current_value
                results[scenario_name] = {
                    'impact': impact,
                    'new_value': shocked_value
                }
            elif 'volatility_shock' in shock:
                # Volatility shock - assume current volatility doubles
                current_vol = df['equity'].pct_change().std()
                shocked_vol = current_vol * shock['volatility_shock']
                results[scenario_name] = {
                    'volatility_multiplier': shock['volatility_shock'],
                    'new_volatility': shocked_vol
                }
        
        return results


class BenchmarkAnalyzer:
    """Benchmark analiz sistemi"""
    
    def __init__(self, benchmark_returns: pd.Series):
        self.benchmark_returns = benchmark_returns
    
    def calculate_relative_performance(self, strategy_returns: pd.Series) -> Dict[str, float]:
        """Relative performance hesapla"""
        # Excess returns
        excess_returns = strategy_returns - self.benchmark_returns
        
        # Information ratio
        information_ratio = excess_returns.mean() / excess_returns.std() * np.sqrt(252)
        
        # Beta
        covariance = np.cov(strategy_returns, self.benchmark_returns)[0, 1]
        benchmark_variance = np.var(self.benchmark_returns)
        beta = covariance / benchmark_variance if benchmark_variance > 0 else 0
        
        # Alpha
        alpha = strategy_returns.mean() - beta * self.benchmark_returns.mean()
        
        # Tracking error
        tracking_error = excess_returns.std() * np.sqrt(252)
        
        return {
            'information_ratio': information_ratio,
            'beta': beta,
            'alpha': alpha,
            'tracking_error': tracking_error,
            'excess_return': excess_returns.mean() * 252
        }
    
    def calculate_correlation_analysis(self, strategy_returns: pd.Series) -> Dict[str, float]:
        """Correlation analysis"""
        rolling_corr = strategy_returns.rolling(252).corr(self.benchmark_returns)
        
        return {
            'current_correlation': strategy_returns.corr(self.benchmark_returns),
            'avg_correlation': rolling_corr.mean(),
            'min_correlation': rolling_corr.min(),
            'max_correlation': rolling_corr.max(),
            'correlation_volatility': rolling_corr.std()
        }


class PerformanceReportGenerator:
    """Performance raporu oluşturucu"""
    
    @staticmethod
    def generate_summary_report(metrics: PerformanceMetrics) -> str:
        """Özet rapor oluştur"""
        report = []
        
        # Header
        report.append("=" * 60)
        report.append("PERFORMANCE SUMMARY REPORT")
        report.append("=" * 60)
        report.append("")
        
        # Return Metrics
        report.append("RETURN METRICS:")
        report.append(f"Total Return:     {metrics.total_return:.2%}")
        report.append(f"Annualized Return: {metrics.annualized_return:.2%}")
        report.append("")
        
        # Risk Metrics
        report.append("RISK METRICS:")
        report.append(f"Volatility:       {metrics.volatility:.2%}")
        report.append(f"Max Drawdown:     {metrics.max_drawdown:.2%}")
        report.append(f"VaR (95%):        {metrics.var_95:.2%}")
        report.append("")
        
        # Risk-Adjusted Metrics
        report.append("RISK-ADJUSTED METRICS:")
        report.append(f"Sharpe Ratio:     {metrics.sharpe_ratio:.3f}")
        report.append(f"Sortino Ratio:    {metrics.sortino_ratio:.3f}")
        report.append(f"Calmar Ratio:     {metrics.calmar_ratio:.3f}")
        report.append("")
        
        # Trading Metrics
        report.append("TRADING METRICS:")
        report.append(f"Total Trades:     {metrics.total_trades}")
        report.append(f"Win Rate:         {metrics.win_rate:.2%}")
        report.append(f"Profit Factor:    {metrics.profit_factor:.3f}")
        report.append(f"Expectancy:       {metrics.expectancy:.4f}")
        report.append("")
        
        return "\n".join(report)
    
    @staticmethod
    def generate_detailed_report(metrics: PerformanceMetrics, 
                               benchmark_analysis: Optional[Dict[str, Any]] = None) -> str:
        """Detaylı rapor oluştur"""
        report = []
        
        # Include summary
        report.append(PerformanceReportGenerator.generate_summary_report(metrics))
        
        # Additional sections
        report.append("=" * 60)
        report.append("DETAILED ANALYSIS")
        report.append("=" * 60)
        report.append("")
        
        # Benchmark Analysis
        if benchmark_analysis:
            report.append("BENCHMARK COMPARISON:")
            report.append(f"Beta:             {benchmark_analysis.get('beta', 0):.3f}")
            report.append(f"Alpha:            {benchmark_analysis.get('alpha', 0):.2%}")
            report.append(f"Information Ratio: {benchmark_analysis.get('information_ratio', 0):.3f}")
            report.append(f"Up Capture:       {metrics.up_capture:.2%}")
            report.append(f"Down Capture:     {metrics.down_capture:.2%}")
            report.append("")
        
        # Distribution Analysis
        report.append("RETURN DISTRIBUTION:")
        report.append(f"Skewness:         {metrics.skewness:.3f}")
        report.append(f"Kurtosis:         {metrics.kurtosis:.3f}")
        report.append("")
        
        # Drawdown Analysis
        report.append("DRAWDOWN ANALYSIS:")
        report.append(f"Max DD Duration:  {metrics.max_drawdown_duration} periods")
        report.append(f"Avg DD Duration:  {metrics.avg_drawdown_duration} periods")
        report.append(f"Recovery Factor:  {metrics.recovery_factor:.3f}")
        
        return "\n".join(report)