"""
Tick-by-Tick Simulation Engine
Gerçek zamanlı tick verileri simüle eden motor
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Callable, Tuple, Any
from dataclasses import dataclass
import asyncio
import threading
from queue import PriorityQueue, Empty
import time

from .event_system import EventBus, TickEvent, EventType


@dataclass
class Tick:
    """Tick veri yapısı"""
    timestamp: datetime
    symbol: str
    bid: float
    ask: float
    volume: float
    sequence_id: int


class TickGenerator:
    """Tick verisi üretici"""
    
    def __init__(self, symbol: str, initial_price: float, 
                 volatility: float = 0.01, tick_frequency: float = 100):
        self.symbol = symbol
        self.current_price = initial_price
        self.volatility = volatility
        self.tick_frequency = tick_frequency  # ticks per second
        self.sequence_id = 0
        self.last_bid = initial_price
        self.last_ask = initial_price
        self.spread_bps = 2  # basis points
    
    def generate_tick(self) -> Tick:
        """Yeni tick üret"""
        # Geometric Brownian Motion ile fiyat hareketi
        dt = 1.0 / self.tick_frequency
        price_change = np.random.normal(0, self.volatility * np.sqrt(dt))
        new_price = self.current_price * (1 + price_change)
        
        # Bid-Ask spread hesapla (spread volatility'ye bağlı)
        spread_multiplier = 1 + np.random.normal(0, 0.1)
        spread = (self.last_ask - self.last_bid) * spread_multiplier
        spread = max(spread, 0.0001)  # Minimum spread
        
        # Bid ve Ask fiyatlarını güncelle
        mid_price = (new_price + self.current_price) / 2
        self.last_bid = mid_price - spread / 2
        self.last_ask = mid_price + spread / 2
        self.current_price = new_price
        
        # Volume (Poisson dağılımı)
        volume = np.random.poisson(1000)  # Average 1000 units per tick
        
        tick = Tick(
            timestamp=datetime.utcnow(),
            symbol=self.symbol,
            bid=self.last_bid,
            ask=self.last_ask,
            volume=volume,
            sequence_id=self.sequence_id
        )
        
        self.sequence_id += 1
        return tick
    
    def set_price(self, price: float) -> None:
        """Mevcut fiyatı ayarla"""
        self.current_price = price
        self.last_bid = price
        self.last_ask = price


class OrderBookLevel:
    """Order book seviyesi"""
    
    def __init__(self, price: float, quantity: float):
        self.price = price
        self.quantity = quantity
    
    def update_quantity(self, quantity: float) -> None:
        """Miktarı güncelle"""
        self.quantity = quantity
    
    def is_empty(self) -> bool:
        """Seviye boş mu?"""
        return self.quantity <= 0


class OrderBook:
    """Order book simülatörü"""
    
    def __init__(self, symbol: str, initial_price: float):
        self.symbol = symbol
        self.order_book: Dict[str, List[OrderBookLevel]] = {
            'bids': [],  # Sorted descending
            'asks': []   # Sorted ascending
        }
        self._initialize_book(initial_price)
    
    def _initialize_book(self, price: float) -> None:
        """Order book'u başlat"""
        # Bid tarafı (fiyat azalan)
        for i in range(20):
            bid_price = price * (1 - 0.001 * i)  # 0.1% artan spread
            quantity = np.random.exponential(1000)  # Exponential distribution
            self.order_book['bids'].append(OrderBookLevel(bid_price, quantity))
        
        # Ask tarafı (fiyat artan)
        for i in range(20):
            ask_price = price * (1 + 0.001 * i)  # 0.1% artan spread
            quantity = np.random.exponential(1000)
            self.order_book['asks'].append(OrderBookLevel(ask_price, quantity))
        
        # Sırala
        self.order_book['bids'].sort(key=lambda x: x.price, reverse=True)
        self.order_book['asks'].sort(key=lambda x: x.price)
    
    def update_with_tick(self, tick: Tick) -> None:
        """Tick ile order book'u güncelle"""
        # En yakın seviyeleri güncelle
        best_bid = tick.bid
        best_ask = tick.ask
        
        # Best bid güncelle
        if self.order_book['bids']:
            self.order_book['bids'][0].price = best_bid
            self.order_book['bids'][0].quantity += tick.volume * 0.3
        
        # Best ask güncelle
        if self.order_book['asks']:
            self.order_book['asks'][0].price = best_ask
            self.order_book['asks'][0].quantity += tick.volume * 0.3
        
        # Random seviyeleri güncelle (market making effect)
        self._random_update_levels()
    
    def _random_update_levels(self) -> None:
        """Rastgele seviyeleri güncelle"""
        for side in ['bids', 'asks']:
            for level in self.order_book[side]:
                # Natural decay
                level.quantity *= (1 - np.random.exponential(0.01))
                level.quantity = max(level.quantity, 0)
                
                # Small price adjustments
                if np.random.random() < 0.1:  # 10% chance
                    price_change = np.random.normal(0, 0.0001)
                    level.price *= (1 + price_change)
    
    def get_best_bid(self) -> Optional[float]:
        """En iyi bid'i getir"""
        bids = self.order_book['bids']
        return bids[0].price if bids else None
    
    def get_best_ask(self) -> Optional[float]:
        """En iyi ask'i getir"""
        asks = self.order_book['asks']
        return asks[0].price if asks else None
    
    def get_spread(self) -> Optional[float]:
        """Bid-Ask spread'i getir"""
        bid = self.get_best_bid()
        ask = self.get_best_ask()
        return ask - bid if bid and ask else None
    
    def get_depth(self, side: str, levels: int = 5) -> List[Tuple[float, float]]:
        """Order book derinliğini getir"""
        if side not in ['bids', 'asks']:
            return []
        
        levels_data = self.order_book[side][:levels]
        return [(level.price, level.quantity) for level in levels_data]
    
    def execute_market_order(self, side: str, quantity: float) -> Tuple[float, float]:
        """Market order execute et (fiyat, miktar)"""
        executed_price = 0.0
        remaining_quantity = quantity
        
        target_levels = self.order_book['bids'] if side == 'SELL' else self.order_book['asks']
        
        for level in target_levels:
            if remaining_quantity <= 0:
                break
            
            take_quantity = min(remaining_quantity, level.quantity)
            executed_price += take_quantity * level.price
            remaining_quantity -= take_quantity
            level.quantity -= take_quantity
        
        if remaining_quantity > 0:
            # Slippage - market order'da tam execute olmayabilir
            pass
        
        avg_price = executed_price / (quantity - remaining_quantity) if quantity > remaining_quantity else 0
        return avg_price, quantity - remaining_quantity


class TickEngine:
    """Tick Engine - Ana simulation motoru"""
    
    def __init__(self, event_bus: EventBus):
        self.event_bus = event_bus
        self.tick_generators: Dict[str, TickGenerator] = {}
        self.order_books: Dict[str, OrderBook] = {}
        self.is_running = False
        self.tick_queue = PriorityQueue()
        self.thread_pool = []
        self.callbacks: List[Callable] = []
        
        # Performance metrics
        self.ticks_generated = 0
        self.start_time = None
    
    def add_symbol(self, symbol: str, initial_price: float, 
                   volatility: float = 0.01, tick_frequency: float = 100) -> None:
        """Yeni sembol ekle"""
        self.tick_generators[symbol] = TickGenerator(
            symbol, initial_price, volatility, tick_frequency
        )
        self.order_books[symbol] = OrderBook(symbol, initial_price)
    
    def remove_symbol(self, symbol: str) -> None:
        """Sembolü kaldır"""
        self.tick_generators.pop(symbol, None)
        self.order_books.pop(symbol, None)
    
    def set_price(self, symbol: str, price: float) -> None:
        """Sembol fiyatını ayarla"""
        if symbol in self.tick_generators:
            self.tick_generators[symbol].set_price(price)
        if symbol in self.order_books:
            self.order_books[symbol] = OrderBook(symbol, price)
    
    def start(self, duration_seconds: Optional[float] = None) -> None:
        """Simulation'ı başlat"""
        if self.is_running:
            return
        
        self.is_running = True
        self.start_time = datetime.utcnow()
        
        if duration_seconds:
            # Süreli simulation
            end_time = self.start_time + timedelta(seconds=duration_seconds)
            self._run_with_duration(end_time)
        else:
            # Süresiz simulation
            self._run_continuous()
    
    def stop(self) -> None:
        """Simulation'ı durdur"""
        self.is_running = False
        
        # Thread'leri bekle
        for thread in self.thread_pool:
            if thread.is_alive():
                thread.join(timeout=1.0)
        
        self.thread_pool.clear()
    
    def _run_continuous(self) -> None:
        """Sürekli simulation çalıştır"""
        def tick_generation_loop():
            while self.is_running:
                try:
                    # Tüm semboller için tick üret
                    for symbol, generator in self.tick_generators.items():
                        tick = generator.generate_tick()
                        self._process_tick(tick)
                    
                    # Rate limiting
                    time.sleep(0.01)  # 100 Hz maximum
                    
                except Exception as e:
                    print(f"Error in tick generation: {e}")
        
        # Background thread başlat
        thread = threading.Thread(target=tick_generation_loop, daemon=True)
        thread.start()
        self.thread_pool.append(thread)
    
    def _run_with_duration(self, end_time: datetime) -> None:
        """Süreli simulation çalıştır"""
        def tick_generation_loop():
            while self.is_running and datetime.utcnow() < end_time:
                try:
                    for symbol, generator in self.tick_generators.items():
                        tick = generator.generate_tick()
                        self._process_tick(tick)
                    
                    time.sleep(0.01)  # 100 Hz
                    
                except Exception as e:
                    print(f"Error in tick generation: {e}")
        
        thread = threading.Thread(target=tick_generation_loop, daemon=True)
        thread.start()
        self.thread_pool.append(thread)
    
    def _process_tick(self, tick: Tick) -> None:
        """Tick'i işle"""
        # Order book'u güncelle
        if tick.symbol in self.order_books:
            self.order_books[tick.symbol].update_with_tick(tick)
        
        # Event oluştur ve publish et
        tick_event = TickEvent(
            symbol=tick.symbol,
            bid=tick.bid,
            ask=tick.ask,
            volume=tick.volume,
            timestamp=tick.timestamp
        )
        self.event_bus.publish(tick_event)
        
        self.ticks_generated += 1
        
        # Callback'leri çağır
        for callback in self.callbacks:
            try:
                callback(tick)
            except Exception as e:
                print(f"Error in tick callback: {e}")
    
    def add_tick_callback(self, callback: Callable[[Tick], None]) -> None:
        """Tick callback'i ekle"""
        self.callbacks.append(callback)
    
    def get_order_book(self, symbol: str) -> Optional[OrderBook]:
        """Order book'u getir"""
        return self.order_books.get(symbol)
    
    def execute_market_order(self, symbol: str, side: str, quantity: float) -> Tuple[float, float]:
        """Market order execute et"""
        if symbol in self.order_books:
            return self.order_books[symbol].execute_market_order(side, quantity)
        return 0.0, 0.0
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Performance istatistiklerini getir"""
        runtime = (datetime.utcnow() - self.start_time).total_seconds() if self.start_time else 0
        ticks_per_second = self.ticks_generated / runtime if runtime > 0 else 0
        
        return {
            'ticks_generated': self.ticks_generated,
            'runtime_seconds': runtime,
            'ticks_per_second': ticks_per_second,
            'active_symbols': len(self.tick_generators),
            'is_running': self.is_running
        }
    
    def reset(self) -> None:
        """Engine'i sıfırla"""
        self.stop()
        self.ticks_generated = 0
        self.start_time = None
        
        for generator in self.tick_generators.values():
            generator.sequence_id = 0
        
        for order_book in self.order_books.values():
            # Order book'u yeniden başlat
            pass