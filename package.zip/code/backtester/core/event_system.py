"""
Event-Driven Architecture Sistemi
Bitwisers 2.0 backtester motorunun event sistemi
"""

import uuid
from datetime import datetime
from typing import Dict, List, Callable, Any, Optional
from enum import Enum
from dataclasses import dataclass, asdict
import json


class EventType(Enum):
    """Event türleri"""
    TICK = "tick"
    ORDER_PLACE = "order_place"
    ORDER_CANCEL = "order_cancel"
    ORDER_FILL = "order_fill"
    TRADE_EXECUTE = "trade_execute"
    PORTFOLIO_UPDATE = "portfolio_update"
    SIGNAL_GENERATE = "signal_generate"
    INDICATOR_UPDATE = "indicator_update"
    RISK_ALERT = "risk_alert"
    SYSTEM_ERROR = "system_error"
    SIMULATION_START = "simulation_start"
    SIMULATION_END = "simulation_end"
    DATA_FEED_ERROR = "data_feed_error"
    PERFORMANCE_UPDATE = "performance_update"


@dataclass
class Event:
    """Event sınıfı"""
    event_id: str
    event_type: EventType
    timestamp: datetime
    source: str
    symbol: Optional[str] = None
    data: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.data is None:
            self.data = {}
    
    @classmethod
    def create(cls, event_type: EventType, source: str, **kwargs) -> 'Event':
        """Yeni event oluştur"""
        return cls(
            event_id=str(uuid.uuid4()),
            event_type=event_type,
            timestamp=datetime.utcnow(),
            source=source,
            **kwargs
        )
    
    def to_dict(self) -> Dict[str, Any]:
        """Event'i dictionary'ye çevir"""
        result = asdict(self)
        result['event_type'] = self.event_type.value
        return result
    
    def to_json(self) -> str:
        """Event'i JSON'a çevir"""
        return json.dumps(self.to_dict(), default=str)


class EventHandler:
    """Event handler interface"""
    
    def handle_event(self, event: Event) -> None:
        """Event'i işle"""
        raise NotImplementedError


class EventBus:
    """Event bus - tüm event'leri yönetir"""
    
    def __init__(self):
        self._handlers: Dict[EventType, List[EventHandler]] = {}
        self._event_history: List[Event] = []
        self._max_history_size = 10000
        
    def subscribe(self, event_type: EventType, handler: EventHandler) -> None:
        """Event tipi için handler ekle"""
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        self._handlers[event_type].append(handler)
    
    def unsubscribe(self, event_type: EventType, handler: EventHandler) -> None:
        """Handler'ı çıkar"""
        if event_type in self._handlers:
            try:
                self._handlers[event_type].remove(handler)
            except ValueError:
                pass
    
    def publish(self, event: Event) -> None:
        """Event'i publish et"""
        # History'ye ekle
        self._add_to_history(event)
        
        # Handler'lara gönder
        if event.event_type in self._handlers:
            for handler in self._handlers[event.event_type]:
                try:
                    handler.handle_event(event)
                except Exception as e:
                    # Error event oluştur
                    error_event = Event.create(
                        EventType.SYSTEM_ERROR,
                        "event_bus",
                        data={
                            'original_event': event.to_dict(),
                            'error': str(e),
                            'handler': handler.__class__.__name__
                        }
                    )
                    # Recursive error handling
                    self._handle_error_event(error_event)
    
    def _add_to_history(self, event: Event) -> None:
        """Event'i history'ye ekle"""
        self._event_history.append(event)
        
        # Max boyutu aştıysa eski event'leri sil
        if len(self._event_history) > self._max_history_size:
            self._event_history = self._event_history[-self._max_history_size:]
    
    def _handle_error_event(self, error_event: Event) -> None:
        """Error event'i işle"""
        print(f"System Error: {error_event.data}")
        # TODO: Error handling ve logging sistemi entegre edilecek
    
    def get_history(self, event_type: Optional[EventType] = None, 
                   limit: int = 1000) -> List[Event]:
        """Event history'sini getir"""
        events = self._event_history
        
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        
        return events[-limit:]
    
    def clear_history(self) -> None:
        """History'yi temizle"""
        self._event_history.clear()


class TickEvent(Event):
    """Tick event - tick verilerini taşır"""
    
    def __init__(self, symbol: str, bid: float, ask: float, 
                 volume: float, timestamp: datetime, **kwargs):
        super().__init__(
            event_id=str(uuid.uuid4()),
            event_type=EventType.TICK,
            timestamp=timestamp,
            source="tick_engine",
            symbol=symbol,
            **kwargs
        )
        self.bid = bid
        self.ask = ask
        self.mid_price = (bid + ask) / 2
        self.spread = ask - bid
        self.volume = volume
    
    @property
    def tick_data(self) -> Dict[str, Any]:
        """Tick verisini getir"""
        return {
            'symbol': self.symbol,
            'bid': self.bid,
            'ask': self.ask,
            'mid': self.mid_price,
            'spread': self.spread,
            'volume': self.volume,
            'timestamp': self.timestamp
        }


class OrderEvent(Event):
    """Order event - order işlemlerini taşır"""
    
    def __init__(self, order_id: str, symbol: str, side: str, 
                 quantity: float, price: float, order_type: str, **kwargs):
        super().__init__(
            event_id=str(uuid.uuid4()),
            event_type=EventType.ORDER_PLACE,
            timestamp=datetime.utcnow(),
            source="order_manager",
            symbol=symbol,
            **kwargs
        )
        self.order_id = order_id
        self.side = side  # 'BUY' or 'SELL'
        self.quantity = quantity
        self.price = price
        self.order_type = order_type  # 'MARKET', 'LIMIT', 'STOP'


class TradeEvent(Event):
    """Trade event - trade işlemlerini taşır"""
    
    def __init__(self, trade_id: str, symbol: str, side: str,
                 quantity: float, price: float, commission: float,
                 timestamp: datetime, **kwargs):
        super().__init__(
            event_id=str(uuid.uuid4()),
            event_type=EventType.TRADE_EXECUTE,
            timestamp=timestamp,
            source="trade_engine",
            symbol=symbol,
            **kwargs
        )
        self.trade_id = trade_id
        self.side = side
        self.quantity = quantity
        self.price = price
        self.commission = commission
        self.net_amount = quantity * price - commission
    
    @property
    def total_cost(self) -> float:
        """Toplam maliyet"""
        if self.side == 'BUY':
            return self.quantity * self.price + self.commission
        else:
            return self.quantity * self.price - self.commission


class PortfolioEvent(Event):
    """Portfolio event - portföy güncellemelerini taşır"""
    
    def __init__(self, portfolio_data: Dict[str, Any], **kwargs):
        super().__init__(
            event_id=str(uuid.uuid4()),
            event_type=EventType.PORTFOLIO_UPDATE,
            timestamp=datetime.utcnow(),
            source="portfolio_manager",
            **kwargs
        )
        self.portfolio_data = portfolio_data


class SignalEvent(Event):
    """Signal event - trading sinyallerini taşır"""
    
    def __init__(self, symbol: str, signal_type: str, strength: float,
                 indicators: Dict[str, float], timestamp: datetime, **kwargs):
        super().__init__(
            event_id=str(uuid.uuid4()),
            event_type=EventType.SIGNAL_GENERATE,
            timestamp=timestamp,
            source="signal_generator",
            symbol=symbol,
            **kwargs
        )
        self.signal_type = signal_type  # 'BUY', 'SELL', 'HOLD'
        self.strength = strength
        self.indicators = indicators