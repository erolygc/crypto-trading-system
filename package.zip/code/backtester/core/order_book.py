"""
Order Book ve Portfolio Yönetim Sistemi
Gerçek zamanlı order execution ve portfolio tracking
"""

import uuid
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
import numpy as np

from .event_system import EventBus, Event, OrderEvent, TradeEvent, PortfolioEvent, EventType


class OrderSide(Enum):
    """Order tarafı"""
    BUY = "BUY"
    SELL = "SELL"


class OrderType(Enum):
    """Order tipi"""
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP = "STOP"
    STOP_LIMIT = "STOP_LIMIT"


class OrderStatus(Enum):
    """Order durumu"""
    PENDING = "PENDING"
    PARTIALLY_FILLED = "PARTIALLY_FILLED"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"


class PositionSide(Enum):
    """Pozisyon tarafı"""
    LONG = "LONG"
    SHORT = "SHORT"


@dataclass
class Order:
    """Order sınıfı"""
    order_id: str
    symbol: str
    side: OrderSide
    order_type: OrderType
    quantity: float
    price: Optional[float] = None
    stop_price: Optional[float] = None
    timestamp: datetime = field(default_factory=datetime.utcnow)
    filled_quantity: float = 0.0
    remaining_quantity: float = 0.0
    status: OrderStatus = OrderStatus.PENDING
    commission: float = 0.0
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        self.remaining_quantity = self.quantity
    
    @property
    def is_buy(self) -> bool:
        """Buy order mi?"""
        return self.side == OrderSide.BUY
    
    @property
    def is_sell(self) -> bool:
        """Sell order mi?"""
        return self.side == OrderSide.SELL
    
    @property
    def is_filled(self) -> bool:
        """Tam doldu mu?"""
        return self.status == OrderStatus.FILLED
    
    @property
    def is_partially_filled(self) -> bool:
        """Kısmen doldu mu?"""
        return self.status == OrderStatus.PARTIALLY_FILLED
    
    @property
    def fill_percentage(self) -> float:
        """Dolma yüzdesi"""
        return (self.filled_quantity / self.quantity) * 100 if self.quantity > 0 else 0


@dataclass
class Trade:
    """Trade sınıfı"""
    trade_id: str
    order_id: str
    symbol: str
    side: OrderSide
    quantity: float
    price: float
    commission: float
    timestamp: datetime = field(default_factory=datetime.utcnow)
    trade_type: str = "FILL"  # FILL, REJECT, CANCEL


@dataclass
class Position:
    """Pozisyon sınıfı"""
    symbol: str
    side: PositionSide
    quantity: float
    entry_price: float
    current_price: float
    unrealized_pnl: float = 0.0
    realized_pnl: float = 0.0
    commission_paid: float = 0.0
    entry_timestamp: datetime = field(default_factory=datetime.utcnow)
    last_update: datetime = field(default_factory=datetime.utcnow)
    
    @property
    def total_quantity(self) -> float:
        """Toplam miktar"""
        return abs(self.quantity)
    
    @property
    def is_long(self) -> bool:
        """Long pozisyon mu?"""
        return self.side == PositionSide.LONG
    
    @property
    def is_short(self) -> bool:
        """Short pozisyon mu?"""
        return self.side == PositionSide.SHORT
    
    @property
    def market_value(self) -> float:
        """Piyasa değeri"""
        return self.quantity * self.current_price
    
    @property
    def pnl_percentage(self) -> float:
        """PNL yüzdesi"""
        if self.entry_price == 0:
            return 0
        return ((self.current_price - self.entry_price) / self.entry_price) * 100
    
    def update_price(self, new_price: float) -> None:
        """Fiyatı güncelle ve PNL hesapla"""
        old_price = self.current_price
        self.current_price = new_price
        self.last_update = datetime.utcnow()
        
        # Unrealized PNL güncelle
        price_diff = new_price - old_price
        self.unrealized_pnl += self.quantity * price_diff


class TransactionCostModel:
    """Transaction cost ve slippage modeli"""
    
    def __init__(self, commission_rate: float = 0.001, 
                 slippage_bps: float = 1.0,
                 fixed_commission: float = 0.0):
        self.commission_rate = commission_rate  # % olarak (0.1% = 0.001)
        self.slippage_bps = slippage_bps  # basis points (1 bp = 0.01%)
        self.fixed_commission = fixed_commission  # Fixed cost per trade
    
    def calculate_commission(self, price: float, quantity: float) -> float:
        """Komisyon hesapla"""
        trade_value = price * quantity
        commission = trade_value * self.commission_rate + self.fixed_commission
        return commission
    
    def calculate_slippage(self, reference_price: float, side: OrderSide, 
                          market_impact: float = 0.0) -> float:
        """Slippage hesapla"""
        slippage_rate = self.slippage_bps / 10000  # Convert bps to decimal
        
        if side == OrderSide.BUY:
            return reference_price * (slippage_rate + market_impact)
        else:
            return -reference_price * (slippage_rate + market_impact)
    
    def execute_market_order(self, reference_price: float, side: OrderSide, 
                           quantity: float, market_volatility: float = 0.01) -> Tuple[float, float]:
        """Market order execute et ve maliyetleri hesapla"""
        # Market impact (volatility'ye bağlı)
        market_impact = market_volatility * np.random.uniform(0.1, 0.5)
        
        # Slippage
        slippage = self.calculate_slippage(reference_price, side, market_impact)
        
        # Execution price
        if side == OrderSide.BUY:
            execution_price = reference_price + slippage
        else:
            execution_price = reference_price + slippage
        
        # Commission
        commission = self.calculate_commission(execution_price, quantity)
        
        return execution_price, commission
    
    def execute_limit_order(self, limit_price: float, reference_price: float,
                          side: OrderSide, quantity: float, 
                          fill_probability: float = 0.8) -> Tuple[Optional[float], float]:
        """Limit order execute et"""
        # Fill probability kontrolü
        if np.random.random() > fill_probability:
            return None, 0.0  # Fill olmadı
        
        # Fiyat kontrolü
        if side == OrderSide.BUY and reference_price <= limit_price:
            return None, 0.0  # Koşul sağlanmadı
        elif side == OrderSide.SELL and reference_price >= limit_price:
            return None, 0.0  # Koşul sağlanmadı
        
        # Execution
        execution_price = limit_price
        commission = self.calculate_commission(execution_price, quantity)
        
        return execution_price, commission


class OrderBook:
    """Order Book - Order execution ve matching"""
    
    def __init__(self, symbol: str, event_bus: EventBus):
        self.symbol = symbol
        self.event_bus = event_bus
        self.orders: Dict[str, Order] = {}
        self.trades: List[Trade] = []
        
        # Order queues
        self.buy_orders: List[Order] = []  # Sorted by price desc, time asc
        self.sell_orders: List[Order] = []  # Sorted by price asc, time asc
        
        # Transaction cost model
        self.cost_model = TransactionCostModel()
        
        # Market data
        self.last_price = 0.0
        self.bid = 0.0
        self.ask = 0.0
        self.spread = 0.0
    
    def update_market_data(self, bid: float, ask: float, last_price: float) -> None:
        """Market verilerini güncelle"""
        self.bid = bid
        self.ask = ask
        self.last_price = last_price
        self.spread = ask - bid
        
        # Pending order'ları kontrol et
        self._process_pending_orders()
    
    def place_order(self, side: OrderSide, order_type: OrderType, 
                   quantity: float, price: Optional[float] = None,
                   stop_price: Optional[float] = None) -> str:
        """Order yerleştir"""
        order_id = str(uuid.uuid4())
        
        # Order validasyonu
        if not self._validate_order(side, order_type, quantity, price, stop_price):
            self._reject_order(order_id, "Invalid order parameters")
            return order_id
        
        # Order oluştur
        order = Order(
            order_id=order_id,
            symbol=self.symbol,
            side=side,
            order_type=order_type,
            quantity=quantity,
            price=price,
            stop_price=stop_price
        )
        
        self.orders[order_id] = order
        
        # Event publish et
        order_event = OrderEvent(
            order_id=order_id,
            symbol=self.symbol,
            side=side.value,
            quantity=quantity,
            price=price or 0.0,
            order_type=order_type.value
        )
        self.event_bus.publish(order_event)
        
        # Order processing
        if order_type == OrderType.MARKET:
            self._execute_market_order(order)
        elif order_type == OrderType.LIMIT:
            self._process_limit_order(order)
        
        return order_id
    
    def cancel_order(self, order_id: str) -> bool:
        """Order iptal et"""
        if order_id not in self.orders:
            return False
        
        order = self.orders[order_id]
        
        if order.status in [OrderStatus.FILLED, OrderStatus.CANCELLED]:
            return False
        
        # Order queue'dan çıkar
        self._remove_from_queue(order)
        
        # Durumu güncelle
        order.status = OrderStatus.CANCELLED
        
        return True
    
    def _validate_order(self, side: OrderSide, order_type: OrderType,
                       quantity: float, price: Optional[float], 
                       stop_price: Optional[float]) -> bool:
        """Order validasyonu"""
        if quantity <= 0:
            return False
        
        if order_type == OrderType.LIMIT and (price is None or price <= 0):
            return False
        
        if order_type in [OrderType.STOP, OrderType.STOP_LIMIT] and stop_price is None:
            return False
        
        return True
    
    def _execute_market_order(self, order: Order) -> None:
        """Market order execute et"""
        # Reference price kullan
        reference_price = self.last_price if self.last_price > 0 else (self.bid + self.ask) / 2
        
        # Execution
        execution_price, commission = self.cost_model.execute_market_order(
            reference_price, order.side, order.quantity
        )
        
        # Trade oluştur
        self._create_trade(order, execution_price, order.quantity, commission)
    
    def _process_limit_order(self, order: Order) -> None:
        """Limit order işle"""
        if order.price is None:
            return
        
        # Fiyat kontrolü
        should_fill = False
        
        if order.side == OrderSide.BUY and self.ask <= order.price:
            should_fill = True
        elif order.side == OrderSide.SELL and self.bid >= order.price:
            should_fill = True
        
        if should_fill:
            # Immediate fill
            execution_price, commission = self.cost_model.execute_market_order(
                order.price, order.side, order.quantity
            )
            self._create_trade(order, execution_price, order.quantity, commission)
        else:
            # Queue'ya ekle
            self._add_to_queue(order)
    
    def _process_pending_orders(self) -> None:
        """Pending order'ları işle"""
        # Buy orders - price condition
        for order in self.buy_orders.copy():
            if self.ask <= (order.price or 0):
                self._execute_order(order)
        
        # Sell orders - price condition
        for order in self.sell_orders.copy():
            if self.bid >= (order.price or 0):
                self._execute_order(order)
    
    def _execute_order(self, order: Order) -> None:
        """Order execute et"""
        execution_price, commission = self.cost_model.execute_market_order(
            order.price or self.last_price, order.side, order.quantity
        )
        
        self._create_trade(order, execution_price, order.quantity, commission)
    
    def _create_trade(self, order: Order, price: float, quantity: float, 
                     commission: float) -> None:
        """Trade oluştur"""
        # Order'u güncelle
        order.filled_quantity += quantity
        order.remaining_quantity -= quantity
        order.commission += commission
        
        if order.remaining_quantity <= 0:
            order.status = OrderStatus.FILLED
        else:
            order.status = OrderStatus.PARTIALLY_FILLED
        
        # Queue'dan çıkar
        self._remove_from_queue(order)
        
        # Trade oluştur
        trade = Trade(
            trade_id=str(uuid.uuid4()),
            order_id=order.order_id,
            symbol=self.symbol,
            side=order.side,
            quantity=quantity,
            price=price,
            commission=commission
        )
        
        self.trades.append(trade)
        
        # Event publish et
        trade_event = TradeEvent(
            trade_id=trade.trade_id,
            symbol=self.symbol,
            side=order.side.value,
            quantity=quantity,
            price=price,
            commission=commission,
            timestamp=trade.timestamp
        )
        self.event_bus.publish(trade_event)
    
    def _add_to_queue(self, order: Order) -> None:
        """Order'u queue'ya ekle"""
        if order.side == OrderSide.BUY:
            self.buy_orders.append(order)
            self.buy_orders.sort(key=lambda o: (-(o.price or 0), o.timestamp))
        else:
            self.sell_orders.append(order)
            self.sell_orders.sort(key=lambda o: (o.price or 0, o.timestamp))
    
    def _remove_from_queue(self, order: Order) -> None:
        """Order'u queue'dan çıkar"""
        if order.side == OrderSide.BUY:
            if order in self.buy_orders:
                self.buy_orders.remove(order)
        else:
            if order in self.sell_orders:
                self.sell_orders.remove(order)
    
    def _reject_order(self, order_id: str, reason: str) -> None:
        """Order'u reddet"""
        order = Order(
            order_id=order_id,
            symbol=self.symbol,
            side=OrderSide.BUY,  # Default
            order_type=OrderType.MARKET,
            quantity=0
        )
        order.status = OrderStatus.REJECTED
        
        # TODO: Reject event publish et
    
    def get_open_orders(self) -> List[Order]:
        """Açık order'ları getir"""
        return [order for order in self.orders.values() 
                if order.status in [OrderStatus.PENDING, OrderStatus.PARTIALLY_FILLED]]
    
    def get_order_history(self, limit: int = 100) -> List[Trade]:
        """Order geçmişini getir"""
        return self.trades[-limit:]


class Portfolio:
    """Portfolio yönetim sistemi"""
    
    def __init__(self, initial_cash: float = 100000.0, event_bus: EventBus = None):
        self.initial_cash = initial_cash
        self.cash = initial_cash
        self.event_bus = event_bus
        
        # Positions
        self.positions: Dict[str, Position] = {}
        self.closed_positions: List[Position] = []
        
        # Trading history
        self.trades: List[Trade] = []
        self.total_commission = 0.0
        self.realized_pnl = 0.0
        
        # Performance tracking
        self.equity_curve: List[Tuple[datetime, float]] = []
        self.last_update = datetime.utcnow()
    
    def execute_trade(self, symbol: str, side: OrderSide, quantity: float, 
                     price: float, commission: float, timestamp: datetime = None) -> None:
        """Trade execute et"""
        if timestamp is None:
            timestamp = datetime.utcnow()
        
        # Trade oluştur
        trade = Trade(
            trade_id=str(uuid.uuid4()),
            order_id="",  # Will be set by order book
            symbol=symbol,
            side=side,
            quantity=quantity,
            price=price,
            commission=commission,
            timestamp=timestamp
        )
        
        self.trades.append(trade)
        self.total_commission += commission
        
        # Cash güncelle
        trade_value = quantity * price
        if side == OrderSide.BUY:
            self.cash -= (trade_value + commission)
        else:
            self.cash += (trade_value - commission)
        
        # Position güncelle
        self._update_position(symbol, side, quantity, price, commission, timestamp)
        
        # Portfolio event
        if self.event_bus:
            portfolio_data = self.get_portfolio_summary()
            portfolio_event = PortfolioEvent(portfolio_data)
            self.event_bus.publish(portfolio_event)
    
    def _update_position(self, symbol: str, side: OrderSide, quantity: float,
                        price: float, commission: float, timestamp: datetime) -> None:
        """Position güncelle"""
        if symbol not in self.positions:
            # Yeni position
            position_side = PositionSide.LONG if side == OrderSide.BUY else PositionSide.SHORT
            position_quantity = quantity if side == OrderSide.BUY else -quantity
            
            position = Position(
                symbol=symbol,
                side=position_side,
                quantity=position_quantity,
                entry_price=price,
                current_price=price,
                commission_paid=commission,
                entry_timestamp=timestamp
            )
            
            self.positions[symbol] = position
        else:
            # Mevcut position güncelle
            position = self.positions[symbol]
            
            # Position closing logic
            if ((side == OrderSide.SELL and position.is_long) or 
                (side == OrderSide.BUY and position.is_short)):
                
                # Position kapatma
                close_quantity = min(abs(position.quantity), quantity)
                
                # Realized PNL hesapla
                if position.is_long:
                    pnl = (price - position.entry_price) * close_quantity - commission
                else:
                    pnl = (position.entry_price - price) * close_quantity - commission
                
                position.realized_pnl += pnl
                self.realized_pnl += pnl
                
                # Position miktarını azalt
                position.quantity -= (close_quantity if position.is_long else -close_quantity)
                
                # Position kapandı mı?
                if abs(position.quantity) <= 0.001:  # Tolerance
                    position.quantity = 0
                    self.closed_positions.append(position)
                    del self.positions[symbol]
            else:
                # Position artırma
                total_quantity = abs(position.quantity) + quantity
                weighted_price = ((abs(position.quantity) * position.entry_price) + 
                                (quantity * price)) / total_quantity
                
                position.quantity += (quantity if side == OrderSide.BUY else -quantity)
                position.entry_price = weighted_price
                position.commission_paid += commission
    
    def update_market_prices(self, prices: Dict[str, float]) -> None:
        """Piyasa fiyatlarını güncelle"""
        for symbol, price in prices.items():
            if symbol in self.positions:
                self.positions[symbol].update_price(price)
    
    def get_portfolio_value(self) -> float:
        """Toplam portföy değeri"""
        positions_value = sum(pos.market_value for pos in self.positions.values())
        return self.cash + positions_value
    
    def get_unrealized_pnl(self) -> float:
        """Realize olmamış PNL"""
        return sum(pos.unrealized_pnl for pos in self.positions.values())
    
    def get_realized_pnl(self) -> float:
        """Realize PNL"""
        return self.realized_pnl
    
    def get_total_pnl(self) -> float:
        """Toplam PNL"""
        return self.get_realized_pnl() + self.get_unrealized_pnl()
    
    def get_total_return(self) -> float:
        """Toplam getiri %"""
        current_value = self.get_portfolio_value()
        return ((current_value - self.initial_cash) / self.initial_cash) * 100
    
    def get_portfolio_summary(self) -> Dict[str, Any]:
        """Portföy özeti"""
        return {
            'cash': self.cash,
            'positions_value': sum(pos.market_value for pos in self.positions.values()),
            'portfolio_value': self.get_portfolio_value(),
            'unrealized_pnl': self.get_unrealized_pnl(),
            'realized_pnl': self.get_realized_pnl(),
            'total_pnl': self.get_total_pnl(),
            'total_return_pct': self.get_total_return(),
            'total_commission': self.total_commission,
            'num_positions': len(self.positions),
            'num_trades': len(self.trades)
        }
    
    def record_equity_point(self) -> None:
        """Equity noktası kaydet"""
        self.equity_curve.append((datetime.utcnow(), self.get_portfolio_value()))
        self.last_update = datetime.utcnow()
    
    def get_equity_curve(self) -> List[Tuple[datetime, float]]:
        """Equity curve'u getir"""
        return self.equity_curve.copy()
    
    def reset(self) -> None:
        """Portfolio'yu sıfırla"""
        self.cash = self.initial_cash
        self.positions.clear()
        self.closed_positions.clear()
        self.trades.clear()
        self.total_commission = 0.0
        self.realized_pnl = 0.0
        self.equity_curve.clear()
        self.last_update = datetime.utcnow()