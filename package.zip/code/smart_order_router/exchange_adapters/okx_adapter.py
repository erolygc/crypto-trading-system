"""
OKX Exchange Adapter
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
import time

from .base_adapter import BaseExchangeAdapter

try:
    import ccxt
except ImportError:
    ccxt = None

class OKXAdapter(BaseExchangeAdapter):
    """
    OKX borsa adaptörü
    """
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        
        self.client = None
        self.commission_rate = 0.0008  # %0.08 OKX'de
        
        # Sembol mapping (internal -> OKX)
        self.symbol_map = {
            'BTC/USDT': 'BTC-USDT',
            'ETH/USDT': 'ETH-USDT',
            'SOL/USDT': 'SOL-USDT',
            'ADA/USDT': 'ADA-USDT',
            'XRP/USDT': 'XRP-USDT',
            'DOGE/USDT': 'DOGE-USDT',
            'DOT/USDT': 'DOT-USDT',
            'AVAX/USDT': 'AVAX-USDT',
            'MATIC/USDT': 'MATIC-USDT',
            'BNB/USDT': 'BNB-USDT'
        }
    
    async def connect(self):
        """OKX'e bağlan"""
        if not ccxt:
            raise ImportError("CCXT kütüphanesi bulunamadı. pip install ccxt ile yükleyin.")
        
        try:
            if self.is_testnet:
                # Testnet bağlantısı
                self.client = ccxt.okx({
                    'apiKey': self.api_key,
                    'secret': self.api_secret,
                    'password': self.passphrase,  # OKX için password gerekli
                    'sandbox': True,
                    'enableRateLimit': True
                })
            else:
                # Mainnet bağlantısı
                self.client = ccxt.okx({
                    'apiKey': self.api_key,
                    'secret': self.api_secret,
                    'password': self.passphrase,
                    'enableRateLimit': True
                })
            
            # Bağlantı testi
            await self.get_server_time()
            self.is_connected = True
            
            self.logger.info("OKX bağlantısı başarılı")
            
        except Exception as e:
            self.logger.error(f"OKX bağlantı hatası: {e}")
            raise
    
    async def disconnect(self):
        """OKX bağlantısını kapat"""
        if self.client:
            await self.client.close()
            self.is_connected = False
            self.logger.info("OKX bağlantısı kapatıldı")
    
    async def get_ticker(self, symbol: str) -> Dict[str, Any]:
        """Ticker verisi al"""
        await self.rate_limiter.acquire()
        
        okx_symbol = self.get_symbol(symbol)
        
        try:
            ticker = await self._request_with_timing(
                self.client.fetch_ticker, okx_symbol
            )
            
            return {
                'symbol': symbol,
                'bid': ticker['bid'],
                'ask': ticker['ask'],
                'last': ticker['last'],
                'volume': ticker['baseVolume'],
                'high': ticker['high'],
                'low': ticker['low'],
                'change': ticker['change'],
                'timestamp': ticker['timestamp']
            }
            
        except Exception as e:
            self.logger.error(f"Ticker hatası {symbol}: {e}")
            raise
    
    async def get_order_book(self, symbol: str, depth: int = 20) -> Dict[str, Any]:
        """Order book verisi al"""
        await self.rate_limiter.acquire()
        
        okx_symbol = self.get_symbol(symbol)
        
        try:
            orderbook = await self._request_with_timing(
                self.client.fetch_order_book, okx_symbol, depth
            )
            
            return {
                'symbol': symbol,
                'bids': orderbook['bids'][:depth],
                'asks': orderbook['asks'][:depth],
                'timestamp': orderbook['timestamp']
            }
            
        except Exception as e:
            self.logger.error(f"Order book hatası {symbol}: {e}")
            raise
    
    async def submit_order(self, symbol: str, side: str, amount: float,
                          order_type: str, price: Optional[float] = None) -> Dict[str, Any]:
        """Sipariş ver"""
        await self.rate_limiter.acquire()
        
        okx_symbol = self.get_symbol(symbol)
        side = self.normalize_side(side)
        order_type = self.normalize_order_type(order_type)
        
        try:
            # CCXT parametrelerini hazırla
            params = {
                'symbol': okx_symbol,
                'side': side.upper(),
                'amount': amount,
                'type': order_type.upper()
            }
            
            if order_type == 'limit' and price:
                params['price'] = price
                params['timeInForce'] = 'GTC'
            
            order = await self._request_with_timing(
                self.client.create_order, **params
            )
            
            return {
                'success': True,
                'order_id': order['id'],
                'client_order_id': order.get('clientOrderId'),
                'status': order['status'],
                'filled': order.get('filled', 0),
                'remaining': order.get('remaining', amount),
                'average_price': order.get('average', 0)
            }
            
        except Exception as e:
            self.logger.error(f"Sipariş hatası {symbol}: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    async def cancel_order(self, order_id: str) -> Dict[str, Any]:
        """Sipariş iptal et"""
        await self.rate_limiter.acquire()
        
        try:
            await self._request_with_timing(
                self.client.cancel_order, order_id
            )
            
            return {'success': True}
            
        except Exception as e:
            self.logger.error(f"Sipariş iptal hatası {order_id}: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    async def get_order_status(self, order_id: str) -> Dict[str, Any]:
        """Sipariş durumu al"""
        await self.rate_limiter.acquire()
        
        try:
            order = await self._request_with_timing(
                self.client.fetch_order, order_id
            )
            
            # CCXT durumlarını normalize et
            status_mapping = {
                'open': 'pending',
                'closed': 'filled',
                'canceled': 'cancelled'
            }
            
            normalized_status = status_mapping.get(order['status'], order['status'])
            
            return {
                'order_id': order['id'],
                'status': normalized_status,
                'filled': order.get('filled', 0),
                'remaining': order.get('remaining', 0),
                'average_price': order.get('average', 0),
                'cost': order.get('cost', 0),
                'timestamp': order['timestamp']
            }
            
        except Exception as e:
            self.logger.error(f"Sipariş durum hatası {order_id}: {e}")
            raise
    
    async def get_server_time(self) -> Dict[str, Any]:
        """Sunucu zamanı al"""
        await self.rate_limiter.acquire()
        
        try:
            time_data = await self._request_with_timing(
                self.client.fetch_time
            )
            
            return {
                'server_time': time_data,
                'local_time': int(time.time() * 1000)
            }
            
        except Exception as e:
            self.logger.error(f"Sunucu zamanı hatası: {e}")
            raise