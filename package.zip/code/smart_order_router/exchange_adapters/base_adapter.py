"""
Base Exchange Adapter - Tüm borsa adaptörlerinin temel sınıfı
"""

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any
from datetime import datetime
import time

class BaseExchangeAdapter(ABC):
    """
    Tüm borsa adaptörlerinin temel sınıfı
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")
        
        # Temel özellikler
        self.name = self.__class__.__name__.replace('Adapter', '').lower()
        self.is_connected = False
        self.is_testnet = config.get('testnet', False)
        self.api_key = config.get('api_key')
        self.api_secret = config.get('api_secret')
        self.passphrase = config.get('passphrase')  # OKX için
        
        # Performans metrikleri
        self.latency_samples: List[float] = []
        self.success_rate = 100.0
        self.total_requests = 0
        self.successful_requests = 0
        self.commission_rate = 0.001  # Varsayılan %0.1
        
        # Rate limiting
        self.rate_limiter = RateLimiter()
        
        # Sembol mapping'i (internal symbol -> exchange symbol)
        self.symbol_map: Dict[str, str] = {}
        
    @abstractmethod
    async def connect(self):
        """Borsaya bağlan"""
        pass
    
    @abstractmethod
    async def disconnect(self):
        """Borsa bağlantısını kapat"""
        pass
    
    @abstractmethod
    async def get_ticker(self, symbol: str) -> Dict[str, Any]:
        """Ticker verisi al"""
        pass
    
    @abstractmethod
    async def get_order_book(self, symbol: str, depth: int = 20) -> Dict[str, Any]:
        """Order book verisi al"""
        pass
    
    @abstractmethod
    async def submit_order(self, symbol: str, side: str, amount: float, 
                          order_type: str, price: Optional[float] = None) -> Dict[str, Any]:
        """Sipariş ver"""
        pass
    
    @abstractmethod
    async def cancel_order(self, order_id: str) -> Dict[str, Any]:
        """Sipariş iptal et"""
        pass
    
    @abstractmethod
    async def get_order_status(self, order_id: str) -> Dict[str, Any]:
        """Sipariş durumu al"""
        pass
    
    @abstractmethod
    async def get_server_time(self) -> Dict[str, Any]:
        """Sunucu zamanı al"""
        pass
    
    async def _request_with_timing(self, func, *args, **kwargs):
        """Zaman ölçümü ile istek gönder"""
        start_time = time.time()
        self.total_requests += 1
        
        try:
            result = await func(*args, **kwargs)
            execution_time = (time.time() - start_time) * 1000  # ms
            
            # Latency ölçümlerini güncelle
            self.latency_samples.append(execution_time)
            if len(self.latency_samples) > 100:
                self.latency_samples = self.latency_samples[-100:]
            
            # Başarı istatistiklerini güncelle
            self.successful_requests += 1
            self.success_rate = (self.successful_requests / self.total_requests) * 100
            
            return result
            
        except Exception as e:
            self.logger.error(f"İstek hatası: {e}")
            raise
    
    def get_latency(self) -> float:
        """Ortalama latency getir"""
        if not self.latency_samples:
            return 0.0
        return sum(self.latency_samples) / len(self.latency_samples)
    
    def get_symbol(self, internal_symbol: str) -> str:
        """Internal sembolü borsa sembolüne çevir"""
        return self.symbol_map.get(internal_symbol, internal_symbol)
    
    def normalize_symbol(self, exchange_symbol: str) -> str:
        """Borsa sembolünü internal sembole çevir"""
        for internal, exchange in self.symbol_map.items():
            if exchange == exchange_symbol:
                return internal
        return exchange_symbol
    
    def normalize_side(self, side: str) -> str:
        """Side değerini normalize et"""
        side_lower = side.lower()
        if side_lower in ['buy', 'b']:
            return 'buy'
        elif side_lower in ['sell', 's']:
            return 'sell'
        else:
            raise ValueError(f"Geçersiz side değeri: {side}")
    
    def normalize_order_type(self, order_type: str) -> str:
        """Order type değerini normalize et"""
        order_type_lower = order_type.lower()
        type_mapping = {
            'market': 'market',
            'limit': 'limit',
            'stop': 'stop',
            'stop_market': 'stop_market',
            'take_profit': 'take_profit',
            'take_profit_market': 'take_profit_market'
        }
        
        normalized_type = type_mapping.get(order_type_lower)
        if normalized_type is None:
            raise ValueError(f"Desteklenmeyen sipariş türü: {order_type}")
        
        return normalized_type
    
    async def health_check(self) -> Dict[str, Any]:
        """Sağlık kontrolü"""
        try:
            start_time = time.time()
            await self.get_server_time()
            latency = (time.time() - start_time) * 1000
            
            return {
                'status': 'healthy',
                'latency': latency,
                'success_rate': self.success_rate,
                'is_connected': self.is_connected
            }
        except Exception as e:
            return {
                'status': 'unhealthy',
                'error': str(e),
                'is_connected': False
            }

class RateLimiter:
    """
    Rate limiting yöneticisi
    """
    
    def __init__(self):
        self.requests = []
        self.max_requests = 100  # Saniyede maksimum istek
        self.time_window = 1.0  # Zaman penceresi (saniye)
    
    async def acquire(self):
        """Rate limit kontrolü ve bekleme"""
        now = time.time()
        
        # Eski istekleri temizle
        self.requests = [req_time for req_time in self.requests 
                        if now - req_time < self.time_window]
        
        # Limit kontrolü
        if len(self.requests) >= self.max_requests:
            sleep_time = self.time_window - (now - self.requests[0]) + 0.01
            if sleep_time > 0:
                await asyncio.sleep(sleep_time)
        
        # Bu isteği ekle
        self.requests.append(now)

class SupportedExchanges:
    """
    Desteklenen borsalar
    """
    
    BINANCE = 'binance'
    BYBIT = 'bybit'
    KRAKEN = 'kraken'
    OKX = 'okx'
    COINBASE = 'coinbase'
    
    @classmethod
    def get_all(cls) -> List[str]:
        """Tüm desteklenen borsaları getir"""
        return [
            cls.BINANCE,
            cls.BYBIT,
            cls.KRAKEN,
            cls.OKX,
            cls.COINBASE
        ]
    
    @classmethod
    def is_supported(cls, exchange_name: str) -> bool:
        """Borsanın desteklenip desteklenmediğini kontrol et"""
        return exchange_name.lower() in [ex.lower() for ex in cls.get_all()]