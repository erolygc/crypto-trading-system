"""
Logger Utils - Logging konfigürasyonu
"""

import logging
import logging.handlers
import sys
from pathlib import Path
from typing import Optional
import json
from datetime import datetime

def setup_logger(name: str = "smart_order_router", 
                log_level: str = "INFO",
                log_file: Optional[str] = None,
                max_bytes: int = 10 * 1024 * 1024,  # 10MB
                backup_count: int = 5,
                format_string: Optional[str] = None) -> logging.Logger:
    """
    Logger konfigürasyonu oluştur
    
    Args:
        name: Logger adı
        log_level: Log seviyesi (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Log dosyası yolu (None ise konsola yazar)
        max_bytes: Maksimum dosya boyutu
        backup_count: Yedek dosya sayısı
        format_string: Log formatı
        
    Returns:
        Yapılandırılmış logger
    """
    
    # Varsayılan format
    if format_string is None:
        format_string = "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s"
    
    # Logger oluştur
    logger = logging.getLogger(name)
    
    # Mevcut handler'ları temizle
    logger.handlers.clear()
    
    # Log seviyesini ayarla
    log_level = getattr(logging, log_level.upper(), logging.INFO)
    logger.setLevel(log_level)
    
    # Formatter
    formatter = logging.Formatter(format_string, datefmt='%Y-%m-%d %H:%M:%S')
    
    # Konsol handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(log_level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Dosya handler (eğer belirtilmişse)
    if log_file:
        # Log dizinini oluştur
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Rotating file handler
        file_handler = logging.handlers.RotatingFileHandler(
            log_file, maxBytes=max_bytes, backupCount=backup_count, encoding='utf-8'
        )
        file_handler.setLevel(log_level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    # Propagate'i kapat (duplicate logları önlemek için)
    logger.propagate = False
    
    return logger

def setup_json_logger(name: str, log_file: str) -> logging.Logger:
    """
    JSON formatında loglama için özel logger
    """
    
    class JsonFormatter(logging.Formatter):
        def format(self, record):
            log_obj = {
                "timestamp": datetime.utcnow().isoformat(),
                "logger": record.name,
                "level": record.levelname,
                "message": record.getMessage(),
                "module": record.module,
                "function": record.funcName,
                "line": record.lineno
            }
            
            # Extra alanları ekle
            if hasattr(record, 'venue'):
                log_obj['venue'] = record.venue
            if hasattr(record, 'symbol'):
                log_obj['symbol'] = record.symbol
            if hasattr(record, 'latency'):
                log_obj['latency'] = record.latency
            
            return json.dumps(log_obj, ensure_ascii=False)
    
    logger = logging.getLogger(f"{name}_json")
    logger.setLevel(logging.INFO)
    
    # JSON formatter ile file handler
    json_handler = logging.handlers.RotatingFileHandler(
        log_file, maxBytes=10*1024*1024, backupCount=10, encoding='utf-8'
    )
    json_handler.setFormatter(JsonFormatter())
    logger.addHandler(json_handler)
    logger.propagate = False
    
    return logger

def get_performance_logger() -> logging.Logger:
    """
    Performans metrikleri için özel logger
    """
    return setup_logger("sor_performance", "INFO", "logs/performance.log")

def get_error_logger() -> logging.Logger:
    """
    Hata logları için özel logger
    """
    return setup_logger("sor_errors", "ERROR", "logs/errors.log")

def get_trade_logger() -> logging.Logger:
    """
    İşlem logları için özel logger
    """
    return setup_logger("sor_trades", "INFO", "logs/trades.log")

class LoggerMixin:
    """
    Logger karışımı - sınıflara logging eklemek için
    """
    
    @property
    def logger(self) -> logging.Logger:
        if not hasattr(self, '_logger'):
            self._logger = logging.getLogger(self.__class__.__name__)
        return self._logger

class StructuredLogger:
    """
    Yapılandırılmış loglama için yardımcı sınıf
    """
    
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
    
    def info_structured(self, message: str, **kwargs):
        """Yapılandırılmış info log"""
        extra = {k: v for k, v in kwargs.items() if k not in ['message']}
        self.logger.info(message, extra=extra)
    
    def error_structured(self, message: str, **kwargs):
        """Yapılandırılmış error log"""
        extra = {k: v for k, v in kwargs.items() if k not in ['message']}
        self.logger.error(message, extra=extra)
    
    def warning_structured(self, message: str, **kwargs):
        """Yapılandırılmış warning log"""
        extra = {k: v for k, v in kwargs.items() if k not in ['message']}
        self.logger.warning(message, extra=extra)
    
    def debug_structured(self, message: str, **kwargs):
        """Yapılandırılmış debug log"""
        extra = {k: v for k, v in kwargs.items() if k not in ['message']}
        self.logger.debug(message, extra=extra)

# Decorator for function execution time logging
def log_execution_time(logger: logging.Logger = None):
    """
    Fonksiyon çalışma süresini logla
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            import time
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                execution_time = time.time() - start_time
                
                if logger:
                    logger.debug(
                        f"Function {func.__name__} executed in {execution_time:.3f}s",
                        extra={'execution_time': execution_time, 'function': func.__name__}
                    )
                
                return result
                
            except Exception as e:
                execution_time = time.time() - start_time
                
                if logger:
                    logger.error(
                        f"Function {func.__name__} failed after {execution_time:.3f}s: {str(e)}",
                        extra={'execution_time': execution_time, 'function': func.__name__, 'error': str(e)}
                    )
                
                raise
        return wrapper
    return decorator

# Venue logging decorator
def log_venue_operation(venue_name: str, operation: str):
    """
    Venue operasyonlarını logla
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            logger = logging.getLogger(__name__)
            start_time = time.time()
            
            try:
                result = func(*args, **kwargs)
                execution_time = (time.time() - start_time) * 1000  # ms
                
                logger.info(
                    f"Operation {operation} on {venue_name} completed in {execution_time:.2f}ms",
                    extra={
                        'venue': venue_name,
                        'operation': operation,
                        'execution_time_ms': execution_time
                    }
                )
                
                return result
                
            except Exception as e:
                execution_time = (time.time() - start_time) * 1000
                
                logger.error(
                    f"Operation {operation} on {venue_name} failed after {execution_time:.2f}ms: {str(e)}",
                    extra={
                        'venue': venue_name,
                        'operation': operation,
                        'execution_time_ms': execution_time,
                        'error': str(e)
                    }
                )
                
                raise
        return wrapper
    return decorator

def setup_logging_directories():
    """Log dizinlerini oluştur"""
    log_dirs = ['logs', 'logs/performance', 'logs/errors', 'logs/trades']
    
    for log_dir in log_dirs:
        Path(log_dir).mkdir(parents=True, exist_ok=True)