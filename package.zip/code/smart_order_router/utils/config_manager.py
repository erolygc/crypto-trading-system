"""
Config Manager - Konfigürasyon yönetimi
"""

import json
import logging
from typing import Dict, Any, Optional
from pathlib import Path
import os
from datetime import datetime

class ConfigManager:
    """
    Konfigürasyon dosyalarını yönetir ve yükler
    """
    
    def __init__(self, config_dir: str = "configs"):
        self.config_dir = Path(config_dir)
        self.config_dir.mkdir(exist_ok=True)
        
        self.logger = logging.getLogger(__name__)
        
        # Yüklenen konfigürasyonlar
        self.configs: Dict[str, Dict[str, Any]] = {}
        
        # Varsayılan konfigürasyonlar
        self.default_configs = {
            'sor_engine': {
                'max_slippage': 0.001,
                'max_spread': 0.005,
                'min_liquidity': 1000.0,
                'check_interval': 30,
                'optimization_weights': {
                    'price': 0.4,
                    'liquidity': 0.25,
                    'speed': 0.2,
                    'cost': 0.15
                }
            },
            'venues': {
                'binance': {
                    'enabled': True,
                    'testnet': False,
                    'api_key': None,
                    'api_secret': None,
                    'commission_rate': 0.001
                },
                'bybit': {
                    'enabled': True,
                    'testnet': False,
                    'api_key': None,
                    'api_secret': None,
                    'commission_rate': 0.001
                },
                'kraken': {
                    'enabled': False,
                    'api_key': None,
                    'api_secret': None,
                    'commission_rate': 0.0026
                },
                'okx': {
                    'enabled': False,
                    'testnet': False,
                    'api_key': None,
                    'api_secret': None,
                    'passphrase': None,
                    'commission_rate': 0.0008
                },
                'coinbase': {
                    'enabled': False,
                    'api_key': None,
                    'api_secret': None,
                    'passphrase': None,
                    'commission_rate': 0.005
                }
            },
            'monitoring': {
                'health_check_interval': 30,
                'latency_threshold': 1000,
                'error_rate_threshold': 10,
                'consecutive_failure_threshold': 3
            },
            'arbitrage': {
                'min_spread_threshold': 0.0005,
                'min_profit_threshold': 10.0,
                'confidence_threshold': 0.7,
                'max_trade_size': 10000.0
            }
        }
    
    def load_config(self, config_name: str = "default") -> Dict[str, Any]:
        """Konfigürasyon dosyasını yükle"""
        config_file = self.config_dir / f"{config_name}.json"
        
        try:
            if config_file.exists():
                with open(config_file, 'r', encoding='utf-8') as f:
                    loaded_config = json.load(f)
                
                # Varsayılan konfigürasyon ile merge et
                full_config = self._merge_configs(
                    self.default_configs, loaded_config
                )
                
                self.configs[config_name] = full_config
                self.logger.info(f"Konfigürasyon yüklendi: {config_name}")
                
                return full_config
            else:
                # Varsayılan konfigürasyonu kaydet ve döndür
                self.save_config(self.default_configs, config_name)
                self.configs[config_name] = self.default_configs
                self.logger.info(f"Varsayılan konfigürasyon oluşturuldu: {config_name}")
                
                return self.default_configs
                
        except Exception as e:
            self.logger.error(f"Konfigürasyon yükleme hatası {config_name}: {e}")
            return self.default_configs.copy()
    
    def save_config(self, config: Dict[str, Any], config_name: str = "default"):
        """Konfigürasyonu kaydet"""
        config_file = self.config_dir / f"{config_name}.json"
        
        try:
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False, default=str)
            
            self.configs[config_name] = config
            self.logger.info(f"Konfigürasyon kaydedildi: {config_name}")
            
        except Exception as e:
            self.logger.error(f"Konfigürasyon kaydetme hatası {config_name}: {e}")
            raise
    
    def get_config(self, config_name: str = "default") -> Optional[Dict[str, Any]]:
        """Yüklenen konfigürasyonu getir"""
        return self.configs.get(config_name)
    
    def update_config(self, config_name: str, updates: Dict[str, Any]):
        """Konfigürasyonu güncelle"""
        if config_name in self.configs:
            current_config = self.configs[config_name]
            updated_config = self._merge_configs(current_config, updates)
            self.configs[config_name] = updated_config
            self.save_config(updated_config, config_name)
        else:
            self.logger.warning(f"Konfigürasyon bulunamadı: {config_name}")
    
    def _merge_configs(self, default: Dict[str, Any], loaded: Dict[str, Any]) -> Dict[str, Any]:
        """Varsayılan ve yüklenen konfigürasyonları merge et"""
        result = default.copy()
        
        for key, value in loaded.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_configs(result[key], value)
            else:
                result[key] = value
        
        return result
    
    def create_venue_config(self, venue_name: str, **kwargs) -> Dict[str, Any]:
        """Venue için konfigürasyon şablonu oluştur"""
        if venue_name.lower() in self.default_configs['venues']:
            venue_config = self.default_configs['venues'][venue_name.lower()].copy()
            venue_config.update(kwargs)
            return venue_config
        else:
            raise ValueError(f"Bilinmeyen venue: {venue_name}")
    
    def validate_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Konfigürasyonu validate et"""
        errors = []
        warnings = []
        
        # SOR Engine validasyonları
        sor_config = config.get('sor_engine', {})
        
        if sor_config.get('max_slippage', 0) > 0.01:  # %1'den fazla
            warnings.append("Max slippage çok yüksek (%1'den fazla)")
        
        if sor_config.get('max_spread', 0) > 0.02:  # %2'den fazla
            warnings.append("Max spread çok yüksek (%2'den fazla)")
        
        # Venue konfigürasyon validasyonları
        venues_config = config.get('venues', {})
        
        enabled_venues = []
        for venue_name, venue_config in venues_config.items():
            if venue_config.get('enabled', False):
                enabled_venues.append(venue_name)
                
                # API bilgileri kontrolü
                if venue_name.lower() == 'okx':
                    if not venue_config.get('passphrase'):
                        errors.append(f"OKX için passphrase gerekli")
                else:
                    if not venue_config.get('api_key') or not venue_config.get('api_secret'):
                        errors.append(f"{venue_name} için API bilgileri eksik")
        
        if len(enabled_venues) < 2:
            errors.append("En az 2 venue etkinleştirilmeli")
        
        # Monitoring validasyonları
        monitoring_config = config.get('monitoring', {})
        
        if monitoring_config.get('health_check_interval', 30) < 10:
            warnings.append("Sağlık kontrol aralığı çok kısa (10s'den az)")
        
        if monitoring_config.get('latency_threshold', 1000) < 100:
            warnings.append("Latency eşiği çok düşük")
        
        # Arbitraj validasyonları
        arbitrage_config = config.get('arbitrage', {})
        
        if arbitrage_config.get('min_spread_threshold', 0) < 0.0001:
            warnings.append("Min spread eşiği çok düşük")
        
        if arbitrage_config.get('confidence_threshold', 0.7) > 0.9:
            warnings.append("Güven eşiği çok yüksek")
        
        return {
            'valid': len(errors) == 0,
            'errors': errors,
            'warnings': warnings,
            'enabled_venues': enabled_venues
        }
    
    def create_sample_config(self) -> Dict[str, Any]:
        """Örnek konfigürasyon oluştur"""
        sample_config = self.default_configs.copy()
        
        # Örnek API bilgileri ekle (gerçek kullanımda değiştirilmeli)
        sample_venues = {
            'binance': {
                'enabled': True,
                'testnet': True,  # Test için
                'api_key': 'YOUR_BINANCE_API_KEY',
                'api_secret': 'YOUR_BINANCE_API_SECRET',
                'commission_rate': 0.001
            },
            'bybit': {
                'enabled': True,
                'testnet': True,
                'api_key': 'YOUR_BYBIT_API_KEY',
                'api_secret': 'YOUR_BYBIT_API_SECRET',
                'commission_rate': 0.001
            }
        }
        
        sample_config['venues'] = sample_venues
        
        # Tarih damgası ekle
        sample_config['created_at'] = datetime.utcnow().isoformat()
        sample_config['version'] = "2.0.0"
        
        return sample_config
    
    def export_config_template(self, filename: str = "config_template.json"):
        """Konfigürasyon şablonunu dışa aktar"""
        template = self.create_sample_config()
        template_file = self.config_dir / filename
        
        try:
            with open(template_file, 'w', encoding='utf-8') as f:
                json.dump(template, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"Konfigürasyon şablonu dışa aktarıldı: {template_file}")
            
        except Exception as e:
            self.logger.error(f"Konfigürasyon şablonu dışa aktarma hatası: {e}")
            raise
    
    def list_configs(self) -> List[str]:
        """Mevcut konfigürasyonları listele"""
        config_files = list(self.config_dir.glob("*.json"))
        return [f.stem for f in config_files]
    
    def delete_config(self, config_name: str):
        """Konfigürasyonu sil"""
        config_file = self.config_dir / f"{config_name}.json"
        
        try:
            if config_file.exists():
                config_file.unlink()
                if config_name in self.configs:
                    del self.configs[config_name]
                self.logger.info(f"Konfigürasyon silindi: {config_name}")
            else:
                self.logger.warning(f"Konfigürasyon bulunamadı: {config_name}")
                
        except Exception as e:
            self.logger.error(f"Konfigürasyon silme hatası {config_name}: {e}")
            raise