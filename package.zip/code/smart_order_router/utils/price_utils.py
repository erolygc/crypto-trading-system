"""
Price Utilities - Fiyat hesaplama ve dönüştürme yardımcıları
"""

import math
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import statistics

class PriceUtils:
    """
    Fiyat hesaplama ve dönüştürme yardımcı fonksiyonları
    """
    
    @staticmethod
    def calculate_spread(bid: float, ask: float) -> float:
        """Alış-satış farkını hesapla (yüzde olarak)"""
        if bid <= 0 or ask <= 0:
            return 0.0
        return (ask - bid) / bid
    
    @staticmethod
    def calculate_mid_price(bid: float, ask: float) -> float:
        """Orta fiyatı hesapla"""
        if bid <= 0 or ask <= 0:
            return 0.0
        return (bid + ask) / 2
    
    @staticmethod
    def calculate_price_impact(order_size: float, order_book: List[List[float]], 
                             side: str = 'buy') -> Tuple[float, float]:
        """
        Sipariş boyutuna göre fiyat etkisini hesapla
        
        Returns:
            (fiyat_etkisi, ortalama_doldurma_fiyatı)
        """
        if not order_book:
            return 0.0, 0.0
        
        side_orders = order_book if side == 'buy' else order_book[::-1]
        
        remaining_size = order_size
        total_cost = 0.0
        filled_size = 0.0
        
        for price, size in side_orders:
            if remaining_size <= 0:
                break
            
            price = float(price)
            size = float(size)
            fill_size = min(remaining_size, size)
            
            total_cost += fill_size * price
            filled_size += fill_size
            remaining_size -= fill_size
        
        if filled_size <= 0:
            return 0.0, 0.0
        
        # Fiyat etkisi hesapla
        average_price = total_cost / filled_size
        first_price = float(side_orders[0][0])
        price_impact = abs(average_price - first_price) / first_price
        
        return price_impact, average_price
    
    @staticmethod
    def calculate_liquidity_depth(order_book: List[List[float]], 
                                depth_levels: int = 10) -> float:
        """Belirli derinlik seviyelerindeki toplam likiditeyi hesapla"""
        if not order_book:
            return 0.0
        
        depth = min(depth_levels, len(order_book))
        total_liquidity = 0.0
        
        for i in range(depth):
            price, size = order_book[i]
            total_liquidity += float(price) * float(size)
        
        return total_liquidity
    
    @staticmethod
    def find_optimal_splits(order_book: List[List[float]], 
                          total_size: float, 
                          max_split_size: float) -> List[float]:
        """
        Siparişi optimal parçalara böl
        
        Args:
            order_book: Order book [price, size]
            total_size: Toplam sipariş boyutu
            max_split_size: Maksimum parça boyutu
            
        Returns:
            Optimal parça boyutları listesi
        """
        if not order_book or total_size <= 0:
            return []
        
        splits = []
        remaining_size = total_size
        
        for price, available_size in order_book:
            if remaining_size <= 0:
                break
            
            available_size = float(available_size)
            price = float(price)
            
            # Bu seviyeden ne kadar alabiliriz
            fill_amount = min(remaining_size, available_size)
            
            # Maksimum parça boyutunu aşmıyorsa tamamını al
            if fill_amount <= max_split_size:
                splits.append(fill_amount)
                remaining_size -= fill_amount
            else:
                # Maksimum parça boyutuna göre böl
                num_splits = math.ceil(fill_amount / max_split_size)
                split_size = fill_amount / num_splits
                
                for _ in range(num_splits):
                    if remaining_size >= split_size:
                        splits.append(split_size)
                        remaining_size -= split_size
        
        return [size for size in splits if size > 0]
    
    @staticmethod
    def calculate_venue_score(bid: float, ask: float, spread: float,
                            liquidity: float, latency: float, 
                            success_rate: float, weights: Dict[str, float]) -> float:
        """
        Venue'ları çoklu kriterle puanla
        
        Args:
            bid: En iyi alış fiyatı
            ask: En iyi satış fiyatı
            spread: Spread oranı
            liquidity: Likidite
            latency: Gecikme (ms)
            success_rate: Başarı oranı (%)
            weights: Kriter ağırlıkları
        """
        score = 0.0
        
        # Fiyat skoru (spread ters orantılı)
        if spread > 0:
            price_score = 1.0 / (spread + 0.0001)  # Küçük spread = yüksek skor
        else:
            price_score = 0.0
        score += price_score * weights.get('price', 0.4)
        
        # Likidite skoru (doğru orantılı)
        liquidity_score = min(liquidity / 100000, 1.0)  # 100K'ya normalize et
        score += liquidity_score * weights.get('liquidity', 0.25)
        
        # Hız skoru (latency ters orantılı)
        speed_score = max(0, 1 - (latency / 2000))  # 2s'den düşük = iyi
        score += speed_score * weights.get('speed', 0.2)
        
        # Başarı skoru (success_rate doğru orantılı)
        success_score = success_rate / 100
        score += success_score * weights.get('success_rate', 0.15)
        
        return score
    
    @staticmethod
    def detect_price_anomalies(price_history: List[float], 
                             threshold_std: float = 2.0) -> List[Dict[str, Any]]:
        """
        Fiyat anomalilerini tespit et
        
        Args:
            price_history: Fiyat geçmişi
            threshold_std: Standart sapma eşiği
            
        Returns:
            Anomali listesi
        """
        if len(price_history) < 10:
            return []
        
        anomalies = []
        
        # İstatistikleri hesapla
        mean_price = statistics.mean(price_history)
        std_dev = statistics.stdev(price_history)
        
        for i, price in enumerate(price_history):
            # Z-score hesapla
            if std_dev > 0:
                z_score = abs(price - mean_price) / std_dev
                
                if z_score > threshold_std:
                    anomalies.append({
                        'index': i,
                        'price': price,
                        'z_score': z_score,
                        'deviation': price - mean_price,
                        'timestamp': datetime.utcnow()  # Bu gerçek timestamp ile değişmeli
                    })
        
        return anomalies
    
    @staticmethod
    def calculate_cross_venue_arbitrage(venues_data: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Çoklu venue verilerinden arbitraj fırsatlarını hesapla
        
        Args:
            venues_data: {venue_name: {bid: float, ask: float, spread: float, volume: float}}
            
        Returns:
            Arbitraj fırsatları listesi
        """
        if len(venues_data) < 2:
            return []
        
        opportunities = []
        venue_names = list(venues_data.keys())
        
        # Tüm venue kombinasyonlarını kontrol et
        for i, buy_venue in enumerate(venue_names):
            for j, sell_venue in enumerate(venue_names[i+1:], i+1):
                buy_data = venues_data[buy_venue]
                sell_data = venues_data[sell_venue]
                
                # Al-sat kombinasyonları
                # buy_venue -> sell_venue
                if buy_data['ask'] > 0 and sell_data['bid'] > 0:
                    spread1 = (sell_data['bid'] - buy_data['ask']) / buy_data['ask']
                    if spread1 > 0.0001:  # %0.01'den büyük spread
                        opportunities.append({
                            'buy_venue': buy_venue,
                            'sell_venue': sell_venue,
                            'buy_price': buy_data['ask'],
                            'sell_price': sell_data['bid'],
                            'spread': spread1,
                            'potential_profit': spread1 * min(
                                buy_data.get('volume', 0),
                                sell_data.get('volume', 0)
                            )
                        })
                
                # sell_venue -> buy_venue  
                if sell_data['ask'] > 0 and buy_data['bid'] > 0:
                    spread2 = (buy_data['bid'] - sell_data['ask']) / sell_data['ask']
                    if spread2 > 0.0001:
                        opportunities.append({
                            'buy_venue': sell_venue,
                            'sell_venue': buy_venue,
                            'buy_price': sell_data['ask'],
                            'sell_price': buy_data['bid'],
                            'spread': spread2,
                            'potential_profit': spread2 * min(
                                sell_data.get('volume', 0),
                                buy_data.get('volume', 0)
                            )
                        })
        
        # En iyi fırsatları döndür
        opportunities.sort(key=lambda x: x['spread'], reverse=True)
        return opportunities[:5]  # En iyi 5 fırsat
    
    @staticmethod
    def format_price(price: float, decimals: int = 8) -> str:
        """Fiyatı formatla"""
        if price == 0:
            return "0.0"
        
        # Çok küçük değerler için bilimsel notasyon
        if price < 0.000001:
            return f"{price:.2e}"
        
        return f"{price:.{decimals}f}"
    
    @staticmethod
    def format_percentage(value: float, decimals: int = 4) -> str:
        """Yüzde değerini formatla"""
        return f"{value * 100:.{decimals}f}%"
    
    @staticmethod
    def round_to_precision(value: float, precision: int = 8) -> float:
        """Belirli hassasiyete yuvarla"""
        factor = 10 ** precision
        return round(value * factor) / factor