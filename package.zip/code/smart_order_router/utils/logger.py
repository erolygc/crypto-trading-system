"""
Logger Utility - SOR sistemi için merkezi log yönetimi
"""

import logging
import logging.handlers
import os
from datetime import datetime
from typing import Optional

def setup_logger(name: str, level: str = "INFO", log_file: Optional[str] = None) -> logging.Logger:
    """
    Merkezi logger kurulumu
    
    Args:
        name: Logger adı
        level: Log seviyesi (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Log dosyası yolu (None = console only)
    
    Returns:
        Yapılandırılmış logger
    """
    
    # Logger oluştur
    logger = logging.getLogger(name)
    
    # Eğer logger zaten yapılandırılmışsa, mevcut logger'ı döndür
    if logger.handlers:
        return logger
    
    # Log seviyesini ayarla
    log_level = getattr(logging, level.upper(), logging.INFO)
    logger.setLevel(log_level)
    
    # Formatter oluştur
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(log_level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # File handler (eğer log_file belirtilmişse)
    if log_file:
        # Log dizinini oluştur
        log_dir = os.path.dirname(log_file)
        if log_dir and not os.path.exists(log_dir):
            os.makedirs(log_dir, exist_ok=True)
        
        # Rotating file handler (10MB dosya boyutu, 5 dosya sakla)
        file_handler = logging.handlers.RotatingFileHandler(
            log_file, maxBytes=10*1024*1024, backupCount=5, encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)  # File'da tüm seviyeleri logla
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    # Propagate'ı kapat
    logger.propagate = False
    
    return logger

class SORLogger:
    """SOR sistemi için özelleştirilmiş logger sınıfı"""
    
    def __init__(self, name: str, level: str = "INFO"):
        """SOR logger'ı başlat"""
        self.logger = setup_logger(name, level)
        self.name = name
        
        # Performance metrics için özel log formatı
        self.performance_formatter = logging.Formatter(
            '%(asctime)s - PERFORMANCE - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
    
    def debug(self, message: str, **kwargs):
        """Debug log"""
        self.logger.debug(message, **kwargs)
    
    def info(self, message: str, **kwargs):
        """Info log"""
        self.logger.info(message, **kwargs)
    
    def warning(self, message: str, **kwargs):
        """Warning log"""
        self.logger.warning(message, **kwargs)
    
    def error(self, message: str, **kwargs):
        """Error log"""
        self.logger.error(message, **kwargs)
    
    def critical(self, message: str, **kwargs):
        """Critical log"""
        self.logger.critical(message, **kwargs)
    
    def log_order_execution(self, order_id: str, venue: str, side: str, 
                          amount: float, price: float, execution_time_ms: float):
        """Emir execution logu"""
        message = (
            f"ORDER_EXEC - ID:{order_id} Venue:{venue} Side:{side} "
            f"Amount:{amount:.6f} Price:{price:.6f} "
            f"ExecTime:{execution_time_ms:.2f}ms"
        )
        self.info(message)
    
    def log_arbitrage_opportunity(self, symbol: str, buy_venue: str, sell_venue: str,
                                profit_pct: float, volume: float, risk_score: float):
        """Arbitraj fırsat logu"""
        message = (
            f"ARBITRAGE - Symbol:{symbol} Buy:{buy_venue} Sell:{sell_venue} "
            f"Profit:{profit_pct:.3f}% Volume:{volume:.2f} "
            f"Risk:{risk_score:.3f}"
        )
        self.info(message)
    
    def log_performance_metrics(self, metrics: dict):
        """Performance metrik logu"""
        message = (
            f"METRICS - Orders:{metrics.get('total_orders', 0)} "
            f"Success:{metrics.get('successful_orders', 0)} "
            f"Volume:{metrics.get('total_volume', 0):.2f} "
            f"Savings:{metrics.get('total_savings', 0):.6f}"
        )
        self.info(message)
    
    def log_venue_health(self, venue: str, status: str, latency: float):
        """Venue sağlık logu"""
        message = f"HEALTH - Venue:{venue} Status:{status} Latency:{latency:.2f}ms"
        self.info(message)
    
    def log_routing_decision(self, symbol: str, strategy: str, venues: list, 
                           expected_savings: float):
        """Routing karar logu"""
        venue_list = ','.join([f"{v['venue']}:{v['amount']:.4f}" for v in venues])
        message = (
            f"ROUTING - Symbol:{symbol} Strategy:{strategy} "
            f"Venues:[{venue_list}] Savings:{expected_savings:.6f}"
        )
        self.info(message)
    
    def log_error_with_context(self, error: Exception, context: dict):
        """Hata logu ile context"""
        error_msg = f"ERROR - {type(error).__name__}: {str(error)}"
        context_str = " ".join([f"{k}:{v}" for k, v in context.items()])
        full_message = f"{error_msg} Context: {context_str}"
        self.error(full_message)
    
    def log_system_startup(self, enabled_venues: list, config: dict):
        """Sistem başlangıç logu"""
        venues_str = ','.join(enabled_venues)
        message = (
            f"SYSTEM_START - EnabledVenues:{venues_str} "
            f"MaxOrders:{config.get('max_concurrent_orders', 100)} "
            f"SplitThreshold:{config.get('order_split_min_size', 100)}"
        )
        self.info(message)
    
    def log_market_data_update(self, symbol: str, venues: list, best_bid: float, best_ask: float):
        """Market data güncelleme logu"""
        venues_str = ','.join(venues)
        spread = (best_ask - best_bid) / best_bid * 100 if best_bid > 0 else 0
        message = (
            f"MARKET_DATA - Symbol:{symbol} Venues:{venues_str} "
            f"Bid:{best_bid:.6f} Ask:{best_ask:.6f} Spread:{spread:.3f}%"
        )
        self.debug(message)

# Global logger instances
_loggers = {}

def get_logger(name: str, level: str = "INFO") -> SORLogger:
    """Global logger instance al"""
    if name not in _loggers:
        _loggers[name] = SORLogger(name, level)
    return _loggers[name]

def configure_logging():
    """Global logging yapılandırması"""
    # Root logger yapılandırması
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)
    
    # Basit console formatter
    console_formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        datefmt='%H:%M:%S'
    )
    
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(console_formatter)
    root_logger.addHandler(console_handler)
    
    # Third-party library loglarını bastır
    logging.getLogger("ccxt").setLevel(logging.WARNING)
    logging.getLogger("urllib3").setLevel(logging.WARNING)
    logging.getLogger("requests").setLevel(logging.WARNING)

# Log seviyeleri
class LogLevel:
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

# Log dosyaları için sabitler
LOG_FILES = {
    'main': 'logs/sor_system.log',
    'errors': 'logs/sor_errors.log',
    'performance': 'logs/sor_performance.log',
    'arbitrage': 'logs/sor_arbitrage.log'
}