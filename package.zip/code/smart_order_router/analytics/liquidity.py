"""
Likidite Analizörü - Market likiditesini derinlemesine analiz eder
"""

import asyncio
import logging
import time
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import statistics
import math

from ..exchanges.manager import ExchangeManager

class LiquidityAnalyzer:
    """
    Market Likidite Analizörü
    Order book verilerini analiz eder ve likidite metriklerini hesaplar
    """
    
    def __init__(self, exchange_manager: ExchangeManager):
        """Liquidity analyzer'ı başlat"""
        self.exchange_manager = exchange_manager
        self.logger = logging.getLogger("LiquidityAnalyzer")
        
        # Likidite geçmişi
        self.liquidity_history: Dict[str, List[Dict]] = {}
        
        # Likidite penceresi (saniye)
        self.analysis_window = 300  # 5 dakika
        
        # Minimum likidite seviyeleri
        self.min_levels = 10
    
    async def analyze_market_liquidity(self, symbol: str) -> Dict[str, Any]:
        """
        Market likiditesini kapsamlı olarak analiz et
        
        Args:
            symbol: Trading sembolü
        
        Returns:
            Likidite analiz sonuçları
        """
        try:
            self.logger.debug(f"Market likidite analizi başlatılıyor: {symbol}")
            
            # Order book verilerini al
            order_books = await self.exchange_manager.get_order_books(symbol, self.min_levels)
            
            if not order_books:
                raise ValueError("Order book verileri alınamadı")
            
            # Her venue için likidite analizi yap
            venue_analyses = {}
            for venue, order_book in order_books.items():
                if order_book:
                    venue_analyses[venue] = self._analyze_venue_liquidity(
                        venue, symbol, order_book
                    )
            
            # Cross-venue likidite analizi
            cross_venue_analysis = self._analyze_cross_venue_liquidity(
                symbol, order_books, venue_analyses
            )
            
            # Piyasa derinliği analizi
            market_depth_analysis = self._analyze_market_depth(symbol, order_books)
            
            # Spread analizi
            spread_analysis = self._analyze_spreads(symbol, order_books)
            
            # Likidite kalitesi skoru
            liquidity_quality_score = self._calculate_liquidity_quality_score(
                venue_analyses, cross_venue_analysis
            )
            
            analysis_result = {
                'symbol': symbol,
                'timestamp': datetime.now().isoformat(),
                'venue_analyses': venue_analyses,
                'cross_venue_analysis': cross_venue_analysis,
                'market_depth_analysis': market_depth_analysis,
                'spread_analysis': spread_analysis,
                'liquidity_quality_score': liquidity_quality_score,
                'recommendations': self._generate_liquidity_recommendations(
                    venue_analyses, cross_venue_analysis, liquidity_quality_score
                )
            }
            
            # Geçmişe ekle
            self._add_to_history(symbol, analysis_result)
            
            self.logger.info(f"Market likidite analizi tamamlandı: {symbol}")
            return analysis_result
            
        except Exception as e:
            self.logger.error(f"Market likidite analizi hatası: {e}")
            raise
    
    def _analyze_venue_liquidity(self, venue: str, symbol: str, order_book: Dict) -> Dict[str, Any]:
        """Belirli bir venue'ın likiditesini analiz et"""
        try:
            bids = order_book.get('bids', [])
            asks = order_book.get('asks', [])
            
            if not bids or not asks:
                return {'error': 'Insufficient order book data'}
            
            # Temel metrikler
            best_bid = float(bids[0][0])
            best_ask = float(asks[0][0])
            spread = best_ask - best_bid
            spread_percentage = (spread / best_bid) * 100
            
            # Likidite derinliği analizi
            depth_analysis = self._calculate_depth_metrics(bids, asks)
            
            # Volume analizi
            volume_analysis = self._calculate_volume_metrics(bids, asks)
            
            # Slippage tahmini
            slippage_estimate = self._estimate_slippage(bids, asks)
            
            # Likidite yoğunluğu
            liquidity_density = self._calculate_liquidity_density(bids, asks)
            
            # Market impact tahmini
            market_impact = self._estimate_market_impact(depth_analysis, slippage_estimate)
            
            return {
                'venue': venue,
                'best_bid': best_bid,
                'best_ask': best_ask,
                'spread': spread,
                'spread_percentage': spread_percentage,
                'depth_analysis': depth_analysis,
                'volume_analysis': volume_analysis,
                'slippage_estimate': slippage_estimate,
                'liquidity_density': liquidity_density,
                'market_impact': market_impact,
                'liquidity_score': self._calculate_venue_liquidity_score(
                    depth_analysis, volume_analysis, spread_percentage
                )
            }
            
        except Exception as e:
            self.logger.error(f"{venue} venue likidite analizi hatası: {e}")
            return {'error': str(e)}
    
    def _calculate_depth_metrics(self, bids: List, asks: List) -> Dict[str, float]:
        """Derinlik metriklerini hesapla"""
        depth_metrics = {}
        
        # Farklı derinlik seviyelerinde toplam miktar
        levels = [1, 5, 10]
        
        for level in levels:
            bid_volume = sum(float(bid[1]) for bid in bids[:level])
            ask_volume = sum(float(ask[1]) for ask in asks[:level])
            total_volume = bid_volume + ask_volume
            
            # Weighted average price (WAP)
            bid_wap = sum(float(bid[0]) * float(bid[1]) for bid in bids[:level]) / bid_volume if bid_volume > 0 else 0
            ask_wap = sum(float(ask[0]) * float(ask[1]) for ask in asks[:level]) / ask_volume if ask_volume > 0 else 0
            
            depth_metrics[f'depth_{level}'] = {
                'bid_volume': bid_volume,
                'ask_volume': ask_volume,
                'total_volume': total_volume,
                'bid_wap': bid_wap,
                'ask_wap': ask_wap,
                'imbalance': abs(bid_volume - ask_volume) / total_volume if total_volume > 0 else 0
            }
        
        return depth_metrics
    
    def _calculate_volume_metrics(self, bids: List, asks: List) -> Dict[str, Any]:
        """Volume metriklerini hesapla"""
        # Toplam volume
        total_bid_volume = sum(float(bid[1]) for bid in bids)
        total_ask_volume = sum(float(ask[1]) for ask in asks)
        total_volume = total_bid_volume + total_ask_volume
        
        # Volume dağılımı
        bid_volume_distribution = [float(bid[1]) for bid in bids]
        ask_volume_distribution = [float(ask[1]) for ask in asks]
        
        # Konsantrasyon metrikleri (HHI - Herfindahl-Hirschman Index)
        bid_concentration = self._calculate_hhi(bid_volume_distribution)
        ask_concentration = self._calculate_hhi(ask_volume_distribution)
        
        return {
            'total_bid_volume': total_bid_volume,
            'total_ask_volume': total_ask_volume,
            'total_volume': total_volume,
            'volume_imbalance': abs(total_bid_volume - total_ask_volume) / total_volume if total_volume > 0 else 0,
            'bid_concentration': bid_concentration,
            'ask_concentration': ask_concentration,
            'volume_concentration': (bid_concentration + ask_concentration) / 2
        }
    
    def _calculate_hhi(self, values: List[float]) -> float:
        """Herfindahl-Hirschman Index hesapla"""
        total = sum(values)
        if total == 0:
            return 0
        
        # Normalize et
        normalized_values = [v / total for v in values]
        
        # HHI hesapla (0-1 arası)
        hhi = sum(v ** 2 for v in normalized_values)
        return hhi
    
    def _estimate_slippage(self, bids: List, asks: List) -> Dict[str, float]:
        """Slippage tahmini hesapla"""
        slippage_estimates = {}
        
        # Farklı emir boyutları için slippage tahmini
        test_sizes = [1000, 5000, 10000, 50000, 100000]  # USD cinsinden
        
        best_bid = float(bids[0][0])
        best_ask = float(asks[0][0])
        mid_price = (best_bid + best_ask) / 2
        
        for size in test_sizes:
            # Buy slippage tahmini
            buy_slippage = self._calculate_order_slippage(asks, size, mid_price, 'buy')
            
            # Sell slippage tahmini
            sell_slippage = self._calculate_order_slippage(bids, size, mid_price, 'sell')
            
            slippage_estimates[f'{size}'] = {
                'buy_slippage_pct': buy_slippage,
                'sell_slippage_pct': sell_slippage
            }
        
        return slippage_estimates
    
    def _calculate_order_slippage(self, orders: List, size: float, mid_price: float, side: str) -> float:
        """Belirli bir boyut için slippage hesapla"""
        remaining_size = size
        total_cost = 0
        total_quantity = 0
        
        for price_str, quantity_str in orders:
            price = float(price_str)
            quantity = float(quantity_str)
            
            if remaining_size <= 0:
                break
            
            # Bu seviyeden ne kadar alacağız
            take_quantity = min(remaining_size / price, quantity)
            
            # Maliyet hesapla
            cost = take_quantity * price
            total_cost += cost
            total_quantity += take_quantity
            
            remaining_size -= take_quantity * price
        
        # Average execution price
        avg_price = total_cost / total_quantity if total_quantity > 0 else 0
        
        # Slippage hesapla
        if side == 'buy':
            slippage = (avg_price - mid_price) / mid_price * 100
        else:
            slippage = (mid_price - avg_price) / mid_price * 100
        
        return max(0, slippage)  # Negatif slippage'i 0'a sınırla
    
    def _calculate_liquidity_density(self, bids: List, asks: List) -> Dict[str, float]:
        """Likidite yoğunluğunu hesapla"""
        # Farklı fiyat seviyelerinde likidite yoğunluğu
        density_levels = []
        
        # Best bid/ask'u al
        best_bid = float(bids[0][0]) if bids else 0
        best_ask = float(asks[0][0]) if asks else 0
        
        if best_bid == 0 or best_ask == 0:
            return {'density_0.1_pct': 0, 'density_0.5_pct': 0, 'density_1_pct': 0}
        
        # Farklı yüzdelerdeki fiyat seviyelerini hesapla
        price_ranges = [
            0.001,  # %0.1
            0.005,  # %0.5
            0.01    # %1.0
        ]
        
        for pct in price_ranges:
            bid_price = best_bid * (1 - pct)
            ask_price = best_ask * (1 + pct)
            
            # Bu fiyat aralığındaki toplam likidite
            bid_density = self._calculate_price_range_volume(bids, bid_price, best_bid)
            ask_density = self._calculate_price_range_volume(asks, best_ask, ask_price)
            total_density = bid_density + ask_density
            
            density_levels.append(total_density)
        
        return {
            'density_0.1_pct': density_levels[0],
            'density_0.5_pct': density_levels[1],
            'density_1_pct': density_levels[2]
        }
    
    def _calculate_price_range_volume(self, orders: List, min_price: float, max_price: float) -> float:
        """Belirli bir fiyat aralığındaki toplam volume'u hesapla"""
        total_volume = 0
        
        for price_str, quantity_str in orders:
            price = float(price_str)
            quantity = float(quantity_str)
            
            if min_price <= price <= max_price:
                total_volume += quantity
        
        return total_volume
    
    def _estimate_market_impact(self, depth_analysis: Dict, slippage_estimate: Dict) -> Dict[str, float]:
        """Market impact tahmini"""
        # Basit market impact modeli
        # Gerçek uygulamada daha sofistike modeller kullanılabilir
        
        # Büyük emir için impact tahmini (100k USD)
        large_order_impact = slippage_estimate.get('100000', {})
        
        # Derinlik tabanlı impact
        depth_score = depth_analysis.get('depth_10', {}).get('total_volume', 0)
        
        # Market impact tahmini (yüzde)
        estimated_impact = 0
        
        if large_order_impact:
            avg_slippage = (
                large_order_impact.get('buy_slippage_pct', 0) + 
                large_order_impact.get('sell_slippage_pct', 0)
            ) / 2
            estimated_impact = avg_slippage
        
        # Derinlik ile impact ters orantılı
        if depth_score > 0:
            depth_factor = min(depth_score / 100000, 1.0)  # Normalize et
            estimated_impact *= (1 - depth_factor * 0.5)  # %50'ye kadar azalt
        
        return {
            'estimated_impact_pct': estimated_impact,
            'depth_factor': min(depth_score / 100000, 1.0) if depth_score > 0 else 0,
            'liquidity_risk': 'low' if estimated_impact < 0.1 else 'medium' if estimated_impact < 0.5 else 'high'
        }
    
    def _calculate_venue_liquidity_score(self, depth_analysis: Dict, volume_analysis: Dict, spread_pct: float) -> float:
        """Venue likidite skoru hesapla (0-100)"""
        score = 0
        
        # Derinlik skoru (40 puan)
        total_volume = depth_analysis.get('depth_10', {}).get('total_volume', 0)
        depth_score = min(total_volume / 50000, 1.0) * 40  # 50k volume = 40 puan
        
        # Volume konsantrasyon skoru (30 puan)
        concentration = volume_analysis.get('volume_concentration', 0.5)
        volume_score = (1 - concentration) * 30  # Düşük konsantrasyon = yüksek puan
        
        # Spread skoru (30 puan)
        spread_score = max(30 - spread_pct * 10, 0)  # Düşük spread = yüksek puan
        
        score = depth_score + volume_score + spread_score
        
        return min(100, max(0, score))
    
    def _analyze_cross_venue_liquidity(self, symbol: str, order_books: Dict, 
                                     venue_analyses: Dict) -> Dict[str, Any]:
        """Cross-venue likidite analizi"""
        try:
            # En iyi bid/ask'ları bul
            best_bids = [(venue, float(order_book['bids'][0][0])) 
                        for venue, order_book in order_books.items() 
                        if order_book and order_book.get('bids')]
            
            best_asks = [(venue, float(order_book['asks'][0][0])) 
                        for venue, order_book in order_books.items() 
                        if order_book and order_book.get('asks')]
            
            if not best_bids or not best_asks:
                return {'error': 'Insufficient cross-venue data'}
            
            # Cross-venue spread
            best_bid_price = max(best_bids, key=lambda x: x[1])[1]
            best_ask_price = min(best_asks, key=lambda x: x[1])[1]
            
            cross_venue_spread = best_ask_price - best_bid_price
            cross_venue_spread_pct = (cross_venue_spread / best_bid_price) * 100
            
            # Arbitraj fırsatları
            arbitrage_opportunities = []
            for bid_venue, bid_price in best_bids:
                for ask_venue, ask_price in best_asks:
                    if bid_venue != ask_venue:
                        profit = ask_price - bid_price
                        profit_pct = (profit / bid_price) * 100
                        
                        if profit_pct > 0.01:  # %0.01'den fazla profit
                            arbitrage_opportunities.append({
                                'buy_venue': bid_venue,
                                'sell_venue': ask_venue,
                                'buy_price': bid_price,
                                'sell_price': ask_price,
                                'profit': profit,
                                'profit_pct': profit_pct
                            })
            
            # Toplam likidite
            total_liquidity = sum(
                analysis.get('depth_analysis', {}).get('depth_10', {}).get('total_volume', 0)
                for analysis in venue_analyses.values()
            )
            
            return {
                'best_bid': best_bid_price,
                'best_ask': best_ask_price,
                'cross_venue_spread': cross_venue_spread,
                'cross_venue_spread_pct': cross_venue_spread_pct,
                'arbitrage_opportunities': arbitrage_opportunities,
                'total_liquidity': total_liquidity,
                'liquidity_distribution': self._calculate_liquidity_distribution(venue_analyses),
                'venue_count': len(venue_analyses)
            }
            
        except Exception as e:
            self.logger.error(f"Cross-venue likidite analizi hatası: {e}")
            return {'error': str(e)}
    
    def _calculate_liquidity_distribution(self, venue_analyses: Dict) -> Dict[str, float]:
        """Likidite dağılımını hesapla"""
        total_liquidity = sum(
            analysis.get('depth_analysis', {}).get('depth_10', {}).get('total_volume', 0)
            for analysis in venue_analyses.values()
        )
        
        if total_liquidity == 0:
            return {}
        
        distribution = {}
        for venue, analysis in venue_analyses.items():
            venue_liquidity = analysis.get('depth_analysis', {}).get('depth_10', {}).get('total_volume', 0)
            distribution[venue] = venue_liquidity / total_liquidity
        
        return distribution
    
    def _analyze_market_depth(self, symbol: str, order_books: Dict) -> Dict[str, Any]:
        """Market derinliği analizi"""
        depth_analysis = {
            'total_venues': len(order_books),
            'depth_levels': {},
            'market_microstructure': {}
        }
        
        # Her derinlik seviyesi için analiz
        for level in [1, 5, 10]:
            level_data = []
            
            for venue, order_book in order_books.items():
                if order_book:
                    bids = order_book.get('bids', [])
                    asks = order_book.get('asks', [])
                    
                    bid_volume = sum(float(bid[1]) for bid in bids[:level])
                    ask_volume = sum(float(ask[1]) for ask in asks[:level])
                    
                    level_data.append({
                        'venue': venue,
                        'bid_volume': bid_volume,
                        'ask_volume': ask_volume,
                        'total_volume': bid_volume + ask_volume
                    })
            
            depth_analysis['depth_levels'][f'level_{level}'] = {
                'venues_data': level_data,
                'total_bid_volume': sum(data['bid_volume'] for data in level_data),
                'total_ask_volume': sum(data['ask_volume'] for data in level_data),
                'avg_venue_volume': statistics.mean([data['total_volume'] for data in level_data]) if level_data else 0
            }
        
        return depth_analysis
    
    def _analyze_spreads(self, symbol: str, order_books: Dict) -> Dict[str, Any]:
        """Spread analizi"""
        spreads = []
        
        for venue, order_book in order_books.items():
            if order_book and order_book.get('bids') and order_book.get('asks'):
                best_bid = float(order_book['bids'][0][0])
                best_ask = float(order_book['asks'][0][0])
                spread = best_ask - best_bid
                spread_pct = (spread / best_bid) * 100
                
                spreads.append({
                    'venue': venue,
                    'spread': spread,
                    'spread_pct': spread_pct
                })
        
        if not spreads:
            return {'error': 'No spread data available'}
        
        spread_values = [s['spread_pct'] for s in spreads]
        
        return {
            'spreads': spreads,
            'avg_spread_pct': statistics.mean(spread_values),
            'median_spread_pct': statistics.median(spread_values),
            'min_spread_pct': min(spread_values),
            'max_spread_pct': max(spread_values),
            'spread_std': statistics.stdev(spread_values) if len(spread_values) > 1 else 0
        }
    
    def _calculate_liquidity_quality_score(self, venue_analyses: Dict, cross_venue_analysis: Dict) -> float:
        """Genel likidite kalitesi skoru hesapla"""
        if not venue_analyses:
            return 0
        
        # Venue skorlarının ortalaması
        venue_scores = [analysis.get('liquidity_score', 0) for analysis in venue_analyses.values()]
        avg_venue_score = statistics.mean(venue_scores)
        
        # Cross-venue bonus/malus
        cross_venue_bonus = 0
        if 'cross_venue_spread_pct' in cross_venue_analysis:
            spread_pct = cross_venue_analysis['cross_venue_spread_pct']
            # Düşük cross-venue spread = yüksek bonus
            cross_venue_bonus = max(0, 20 - spread_pct * 2)
        
        # Arbitraj fırsatları bonusu
        arbitrage_bonus = 0
        if 'arbitrage_opportunities' in cross_venue_analysis:
            arbitrage_count = len(cross_venue_analysis['arbitrage_opportunities'])
            arbitrage_bonus = min(arbitrage_count * 2, 10)
        
        total_score = avg_venue_score + cross_venue_bonus + arbitrage_bonus
        
        return min(100, max(0, total_score))
    
    def _generate_liquidity_recommendations(self, venue_analyses: Dict, 
                                          cross_venue_analysis: Dict, 
                                          quality_score: float) -> List[str]:
        """Likidite iyileştirme önerileri oluştur"""
        recommendations = []
        
        # Genel kalite skoru değerlendirmesi
        if quality_score < 50:
            recommendations.append("Düşük likidite kalitesi: Daha fazla venue eklenmeli")
        elif quality_score < 75:
            recommendations.append("Orta likidite kalitesi: Likidite artırıcı önlemler önerilir")
        else:
            recommendations.append("Yüksek likidite kalitesi: Mevcut likidite korunmalı")
        
        # Venue bazlı öneriler
        for venue, analysis in venue_analyses.items():
            score = analysis.get('liquidity_score', 0)
            spread_pct = analysis.get('spread_percentage', 0)
            
            if score < 40:
                recommendations.append(f"{venue}: Düşük likidite skoru, alternatif venue tercih edilmeli")
            
            if spread_pct > 0.1:
                recommendations.append(f"{venue}: Yüksek spread (%{spread_pct:.3f}), fee yapısı gözden geçirilmeli")
        
        # Cross-venue öneriler
        if 'arbitrage_opportunities' in cross_venue_analysis:
            arbitrage_count = len(cross_venue_analysis['arbitrage_opportunities'])
            if arbitrage_count > 5:
                recommendations.append("Çok sayıda arbitraj fırsatı: Cross-venue arbitrage stratejisi uygulanabilir")
        
        return recommendations
    
    def _add_to_history(self, symbol: str, analysis: Dict):
        """Analiz sonucunu geçmişe ekle"""
        if symbol not in self.liquidity_history:
            self.liquidity_history[symbol] = []
        
        self.liquidity_history[symbol].append(analysis)
        
        # Son 100 analizi tut
        if len(self.liquidity_history[symbol]) > 100:
            self.liquidity_history[symbol] = self.liquidity_history[symbol][-100:]
    
    def get_liquidity_trend(self, symbol: str) -> Dict[str, Any]:
        """Likidite trendini analiz et"""
        if symbol not in self.liquidity_history or len(self.liquidity_history[symbol]) < 10:
            return {'error': 'Insufficient historical data'}
        
        recent_analyses = self.liquidity_history[symbol][-20:]  # Son 20 analiz
        
        # Likidite kalitesi trendi
        quality_scores = [analysis.get('liquidity_quality_score', 0) for analysis in recent_analyses]
        
        # Trend analizi
        if len(quality_scores) >= 10:
            recent_avg = statistics.mean(quality_scores[-5:])
            earlier_avg = statistics.mean(quality_scores[:5])
            
            trend = 'improving' if recent_avg > earlier_avg else 'declining' if recent_avg < earlier_avg else 'stable'
        else:
            trend = 'insufficient_data'
        
        return {
            'symbol': symbol,
            'trend': trend,
            'avg_quality_score': statistics.mean(quality_scores),
            'quality_score_volatility': statistics.stdev(quality_scores) if len(quality_scores) > 1 else 0,
            'current_score': quality_scores[-1] if quality_scores else 0,
            'analyses_count': len(quality_scores)
        }