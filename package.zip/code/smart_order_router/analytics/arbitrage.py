"""
Arbitraj Detektörü - Cross-venue fiyat farklılıklarını tespit eder
"""

import asyncio
import logging
import time
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
import statistics
import math

from ..exchanges.manager import ExchangeManager

@dataclass
class ArbitrageOpportunity:
    """Arbitraj fırsatı veri yapısı"""
    symbol: str
    buy_venue: str
    sell_venue: str
    buy_price: float
    sell_price: float
    potential_profit: float
    profit_percentage: float
    volume_available: float
    estimated_execution_time: float
    risk_score: float
    timestamp: float
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'symbol': self.symbol,
            'buy_venue': self.buy_venue,
            'sell_venue': self.sell_venue,
            'buy_price': self.buy_price,
            'sell_price': self.sell_price,
            'potential_profit': self.potential_profit,
            'profit_percentage': self.profit_percentage,
            'volume_available': self.volume_available,
            'estimated_execution_time': self.estimated_execution_time,
            'risk_score': self.risk_score,
            'timestamp': self.timestamp
        }

class ArbitrageDetector:
    """
    Cross-venue Arbitraj Detektörü
    Farklı borsalar arasındaki fiyat farklılıklarını tespit eder
    """
    
    def __init__(self, exchange_manager: ExchangeManager):
        """Arbitraj detektörünü başlat"""
        self.exchange_manager = exchange_manager
        self.logger = logging.getLogger("ArbitrageDetector")
        
        # Arbitraj fırsatları geçmişi
        self.opportunities_history: List[ArbitrageOpportunity] = []
        
        # Aktif fırsatlar
        self.active_opportunities: Dict[str, ArbitrageOpportunity] = {}
        
        # Yapılandırma
        self.min_profit_threshold = 0.001  # %0.1 minimum kar
        self.min_volume_threshold = 100.0  # 100 USD minimum hacim
        self.max_risk_threshold = 0.3  # Maksimum risk skoru
        self.analysis_interval = 30  # Analiz aralığı (saniye)
        
        # Fee parametreleri (tahmini)
        self.fee_rates = {
            'binance': 0.001,
            'bybit': 0.001,
            'kraken': 0.0026,
            'okx': 0.001,
            'coinbase': 0.005
        }
    
    async def detect_opportunities(self, symbols: List[str] = None) -> List[Dict[str, Any]]:
        """
        Arbitraj fırsatlarını tespit et
        
        Args:
            symbols: Analiz edilecek semboller (None = tümü)
        
        Returns:
            Tespit edilen arbitraj fırsatları
        """
        try:
            if not symbols:
                # Varsayılan semboller
                symbols = ["BTC/USDT", "ETH/USDT", "ADA/USDT"]
            
            self.logger.debug(f"Arbitraj analizi başlatılıyor: {len(symbols)} sembol")
            
            all_opportunities = []
            
            for symbol in symbols:
                try:
                    opportunities = await self._analyze_symbol_arbitrage(symbol)
                    all_opportunities.extend(opportunities)
                except Exception as e:
                    self.logger.error(f"{symbol} arbitraj analizi hatası: {e}")
            
            # Fırsatları skorla ve sırala
            scored_opportunities = await self._score_opportunities(all_opportunities)
            
            # En iyi fırsatları filtrele
            filtered_opportunities = self._filter_opportunities(scored_opportunities)
            
            # Aktif fırsatları güncelle
            self._update_active_opportunities(filtered_opportunities)
            
            # Geçmişe ekle
            self.opportunities_history.extend(filtered_opportunities)
            
            # Son 1000 fırsatı tut
            if len(self.opportunities_history) > 1000:
                self.opportunities_history = self.opportunities_history[-1000:]
            
            self.logger.info(f"Arbitraj analizi tamamlandı: {len(filtered_opportunities)} fırsat tespit edildi")
            
            return [opp.to_dict() for opp in filtered_opportunities]
            
        except Exception as e:
            self.logger.error(f"Arbitraj tespit hatası: {e}")
            return []
    
    async def _analyze_symbol_arbitrage(self, symbol: str) -> List[ArbitrageOpportunity]:
        """Belirli bir sembol için arbitraj analizi yap"""
        try:
            # Tüm borsalardan fiyat verilerini al
            tickers = await self.exchange_manager.get_tickers(symbol)
            order_books = await self.exchange_manager.get_order_books(symbol, limit=5)
            
            if not tickers:
                return []
            
            opportunities = []
            
            # Her borsa çifti için arbitraj kontrolü yap
            venues = list(tickers.keys())
            
            for i, buy_venue in enumerate(venues):
                for j, sell_venue in enumerate(venues):
                    if i >= j:  # Aynı venue veya tekrar eden çift
                        continue
                    
                    try:
                        opportunity = await self._check_venue_pair_arbitrage(
                            symbol, buy_venue, sell_venue, tickers, order_books
                        )
                        
                        if opportunity:
                            opportunities.append(opportunity)
                            
                    except Exception as e:
                        self.logger.debug(f"{buy_venue}->{sell_venue} arbitraj kontrol hatası: {e}")
            
            return opportunities
            
        except Exception as e:
            self.logger.error(f"{symbol} arbitraj analiz hatası: {e}")
            return []
    
    async def _check_venue_pair_arbitrage(self, symbol: str, buy_venue: str, sell_venue: str,
                                        tickers: Dict, order_books: Dict) -> Optional[ArbitrageOpportunity]:
        """İki venue arasında arbitraj fırsatı kontrol et"""
        try:
            # Fiyat verilerini al
            buy_ticker = tickers.get(buy_venue)
            sell_ticker = tickers.get(sell_venue)
            
            if not buy_ticker or not sell_ticker:
                return None
            
            # Order book verilerini al
            buy_order_book = order_books.get(buy_venue)
            sell_order_book = order_books.get(sell_venue)
            
            if not buy_order_book or not sell_order_book:
                return None
            
            # Buy side (en yüksek bid)
            buy_bids = buy_order_book.get('bids', [])
            sell_asks = sell_order_book.get('asks', [])
            
            if not buy_bids or not sell_asks:
                return None
            
            buy_price = float(buy_bids[0][0])  # Buy venue'da satış fiyatı (bid)
            sell_price = float(sell_asks[0][0])  # Sell venue'da alış fiyatı (ask)
            
            # Arbitraj kontrolü (sell_price > buy_price olmalı)
            if sell_price <= buy_price:
                return None
            
            # Mevcut hacimleri kontrol et
            buy_volume = float(buy_bids[0][1])
            sell_volume = float(sell_asks[0][1])
            available_volume = min(buy_volume, sell_volume)
            
            if available_volume < self.min_volume_threshold:
                return None
            
            # Fees hesapla
            buy_fee_rate = self.fee_rates.get(buy_venue, 0.001)
            sell_fee_rate = self.fee_rates.get(sell_venue, 0.001)
            
            # Net kar hesapla
            gross_profit = sell_price - buy_price
            buy_fee = buy_price * buy_fee_rate
            sell_fee = sell_price * sell_fee_rate
            net_profit = gross_profit - buy_fee - sell_fee
            
            # Kar yüzdesi
            profit_percentage = (net_profit / buy_price) * 100
            
            # Minimum kar eşiğini kontrol et
            if profit_percentage < self.min_profit_threshold * 100:
                return None
            
            # Risk skoru hesapla
            risk_score = await self._calculate_risk_score(
                buy_venue, sell_venue, buy_price, sell_price, available_volume
            )
            
            # Execution time tahmini
            execution_time = await self._estimate_execution_time(
                buy_venue, sell_venue, available_volume
            )
            
            # Arbitraj fırsatı oluştur
            opportunity = ArbitrageOpportunity(
                symbol=symbol,
                buy_venue=buy_venue,
                sell_venue=sell_venue,
                buy_price=buy_price,
                sell_price=sell_price,
                potential_profit=net_profit,
                profit_percentage=profit_percentage,
                volume_available=available_volume,
                estimated_execution_time=execution_time,
                risk_score=risk_score,
                timestamp=time.time()
            )
            
            return opportunity
            
        except Exception as e:
            self.logger.error(f"Arbitraj kontrol hatası ({buy_venue}->{sell_venue}): {e}")
            return None
    
    async def _calculate_risk_score(self, buy_venue: str, sell_venue: str,
                                  buy_price: float, sell_price: float, volume: float) -> float:
        """Arbitraj risk skorunu hesapla (0-1, 1 = yüksek risk)"""
        risk_score = 0.0
        
        try:
            # 1. Venue güvenlik skoru (20% ağırlık)
            venue_risk = await self._assess_venue_risk(buy_venue, sell_venue)
            risk_score += venue_risk * 0.2
            
            # 2. Price volatility riski (30% ağırlık)
            volatility_risk = self._assess_price_volatility_risk(buy_price, sell_price)
            risk_score += volatility_risk * 0.3
            
            # 3. Execution riski (25% ağırlık)
            execution_risk = self._assess_execution_risk(buy_venue, sell_venue, volume)
            risk_score += execution_risk * 0.25
            
            # 4. Market depth riski (25% ağırlık)
            depth_risk = self._assess_market_depth_risk(volume)
            risk_score += depth_risk * 0.25
            
            return min(1.0, max(0.0, risk_score))
            
        except Exception as e:
            self.logger.error(f"Risk skoru hesaplama hatası: {e}")
            return 0.5  # Orta risk
    
    async def _assess_venue_risk(self, buy_venue: str, sell_venue: str) -> float:
        """Venue güvenlik riskini değerlendir"""
        risk_score = 0.0
        
        # Venue sağlık durumunu kontrol et
        buy_health = await self._get_venue_health_status(buy_venue)
        sell_health = await self._get_venue_health_status(sell_venue)
        
        # Sağlıksız venue'lar için risk artır
        if buy_health == 'unhealthy' or buy_health == 'error':
            risk_score += 0.3
        elif buy_health == 'warning':
            risk_score += 0.1
        
        if sell_health == 'unhealthy' or sell_health == 'error':
            risk_score += 0.3
        elif sell_health == 'warning':
            risk_score += 0.1
        
        return min(1.0, risk_score)
    
    async def _get_venue_health_status(self, venue: str) -> str:
        """Venue sağlık durumunu al (basitleştirilmiş)"""
        try:
            # Basit bağlantı kontrolü
            if self.exchange_manager.is_connected(venue):
                latency = self.exchange_manager.get_latency(venue)
                if latency < 100:
                    return 'healthy'
                elif latency < 500:
                    return 'warning'
                else:
                    return 'unhealthy'
            else:
                return 'error'
        except:
            return 'error'
    
    def _assess_price_volatility_risk(self, buy_price: float, sell_price: float) -> float:
        """Fiyat volatilite riskini değerlendir"""
        # Fiyat farkı ne kadar büyükse, volatilite riski o kadar yüksek
        price_diff_pct = abs(sell_price - buy_price) / buy_price
        
        # %0.1'den küçük farklar düşük risk
        # %1'den büyük farklar yüksek risk
        if price_diff_pct < 0.001:
            return 0.1
        elif price_diff_pct < 0.005:
            return 0.3
        elif price_diff_pct < 0.01:
            return 0.6
        else:
            return 0.9
    
    async def _assess_execution_risk(self, buy_venue: str, sell_venue: str, volume: float) -> float:
        """Execution riskini değerlendir"""
        risk_score = 0.0
        
        # Hacim riski - küçük hacimler yüksek risk
        if volume < 1000:
            risk_score += 0.4
        elif volume < 10000:
            risk_score += 0.2
        
        # Venue latency riski
        buy_latency = self.exchange_manager.get_latency(buy_venue)
        sell_latency = self.exchange_manager.get_latency(sell_venue)
        
        avg_latency = (buy_latency + sell_latency) / 2
        
        if avg_latency > 1000:  # 1 saniye üstü
            risk_score += 0.3
        elif avg_latency > 500:
            risk_score += 0.1
        
        return min(1.0, risk_score)
    
    def _assess_market_depth_risk(self, volume: float) -> float:
        """Market depth riskini değerlendir"""
        if volume < 1000:
            return 0.8
        elif volume < 10000:
            return 0.5
        elif volume < 50000:
            return 0.2
        else:
            return 0.1
    
    async def _estimate_execution_time(self, buy_venue: str, sell_venue: str, volume: float) -> float:
        """Execution time tahmini (saniye)"""
        buy_latency = self.exchange_manager.get_latency(buy_venue)
        sell_latency = self.exchange_manager.get_latency(sell_venue)
        
        # Base latency
        base_time = max(buy_latency, sell_latency) / 1000  # ms -> s
        
        # Volume adjustment
        volume_adjustment = volume / 10000  # 10k volume başına ek saniye
        
        # Network delay
        network_delay = 0.5  # Ek network gecikmesi
        
        total_time = base_time + volume_adjustment + network_delay
        
        return max(1.0, total_time)  # Minimum 1 saniye
    
    async def _score_opportunities(self, opportunities: List[ArbitrageOpportunity]) -> List[ArbitrageOpportunity]:
        """Arbitraj fırsatlarını skorla"""
        for opportunity in opportunities:
            # Risk-adjusted profit skoru
            risk_adjusted_profit = opportunity.profit_percentage * (1 - opportunity.risk_score)
            
            # Volume efficiency skoru
            volume_efficiency = min(opportunity.volume_available / 10000, 1.0)
            
            # Execution speed skoru
            execution_speed = max(0, (30 - opportunity.estimated_execution_time) / 30)
            
            # Genel skor
            opportunity.risk_score = (
                risk_adjusted_profit * 0.5 +
                volume_efficiency * 0.3 +
                execution_speed * 0.2
            )
        
        # Skorla sırala
        opportunities.sort(key=lambda x: x.risk_score, reverse=True)
        
        return opportunities
    
    def _filter_opportunities(self, opportunities: List[ArbitrageOpportunity]) -> List[ArbitrageOpportunity]:
        """Fırsatları filtrele"""
        filtered = []
        
        for opp in opportunities:
            # Risk skoru kontrolü
            if opp.risk_score < 0.1:  # Düşük skorlu fırsatları filtrele
                continue
            
            # Zaman kontrolü (çok eski fırsatları filtrele)
            age_seconds = time.time() - opp.timestamp
            if age_seconds > 300:  # 5 dakika üstü
                continue
            
            # Maksimum fırsat sayısını sınırla
            if len(filtered) >= 20:
                break
            
            filtered.append(opp)
        
        return filtered
    
    def _update_active_opportunities(self, opportunities: List[ArbitrageOpportunity]):
        """Aktif fırsatları güncelle"""
        # Yeni fırsatları ekle
        for opp in opportunities:
            key = f"{opp.symbol}_{opp.buy_venue}_{opp.sell_venue}"
            self.active_opportunities[key] = opp
        
        # Eski fırsatları kaldır
        current_time = time.time()
        expired_keys = []
        
        for key, opp in self.active_opportunities.items():
            if current_time - opp.timestamp > 300:  # 5 dakika
                expired_keys.append(key)
        
        for key in expired_keys:
            del self.active_opportunities[key]
    
    async def get_arbitrage_statistics(self) -> Dict[str, Any]:
        """Arbitraj istatistiklerini döndür"""
        if not self.opportunities_history:
            return {'error': 'No arbitrage data available'}
        
        # Temel istatistikler
        total_opportunities = len(self.opportunities_history)
        profit_percentages = [opp.profit_percentage for opp in self.opportunities_history]
        volumes = [opp.volume_available for opp in self.opportunities_history]
        risk_scores = [opp.risk_score for opp in self.opportunities_history]
        
        # Venue çiftleri analizi
        venue_pairs = {}
        for opp in self.opportunities_history:
            pair = f"{opp.buy_venue}_{opp.sell_venue}"
            if pair not in venue_pairs:
                venue_pairs[pair] = 0
            venue_pairs[pair] += 1
        
        # En iyi venue çiftleri
        best_pairs = sorted(venue_pairs.items(), key=lambda x: x[1], reverse=True)[:5]
        
        # Sembol analizi
        symbols = {}
        for opp in self.opportunities_history:
            if opp.symbol not in symbols:
                symbols[opp.symbol] = 0
            symbols[opp.symbol] += 1
        
        # Trend analizi
        recent_opportunities = [opp for opp in self.opportunities_history 
                              if time.time() - opp.timestamp < 3600]  # Son 1 saat
        
        return {
            'total_opportunities': total_opportunities,
            'active_opportunities': len(self.active_opportunities),
            'avg_profit_pct': statistics.mean(profit_percentages),
            'max_profit_pct': max(profit_percentages),
            'avg_volume': statistics.mean(volumes),
            'avg_risk_score': statistics.mean(risk_scores),
            'best_venue_pairs': best_pairs,
            'most_traded_symbols': sorted(symbols.items(), key=lambda x: x[1], reverse=True)[:5],
            'recent_hour_opportunities': len(recent_opportunities),
            'opportunities_per_hour': len(recent_opportunities),
            'success_rate_estimate': len(recent_opportunities) / max(1, len(self.opportunities_history)) * 100
        }
    
    def get_active_opportunities(self) -> List[Dict[str, Any]]:
        """Aktif arbitraj fırsatlarını döndür"""
        return [opp.to_dict() for opp in self.active_opportunities.values()]
    
    async def calculate_potential_roi(self, opportunity: Dict[str, Any], 
                                     investment_amount: float) -> Dict[str, Any]:
        """Yatırım tutarı için ROI hesapla"""
        try:
            # İşlem maliyetlerini hesapla
            buy_fee_rate = self.fee_rates.get(opportunity['buy_venue'], 0.001)
            sell_fee_rate = self.fee_rates.get(opportunity['sell_venue'], 0.001)
            
            # Buy işlemi
            buy_cost = investment_amount * (1 + buy_fee_rate)
            
            # Sell işlemi
            sell_revenue = investment_amount * (opportunity['sell_price'] / opportunity['buy_price'])
            sell_fee = sell_revenue * sell_fee_rate
            net_sell_revenue = sell_revenue - sell_fee
            
            # Net kar
            net_profit = net_sell_revenue - buy_cost
            roi_percentage = (net_profit / investment_amount) * 100
            
            # Risk faktörü
            risk_factor = opportunity['risk_score']
            risk_adjusted_roi = roi_percentage * (1 - risk_factor)
            
            return {
                'investment_amount': investment_amount,
                'buy_cost': buy_cost,
                'sell_revenue': sell_revenue,
                'total_fees': buy_cost - investment_amount + sell_fee,
                'net_profit': net_profit,
                'roi_percentage': roi_percentage,
                'risk_factor': risk_factor,
                'risk_adjusted_roi': risk_adjusted_roi,
                'execution_time_estimate': opportunity['estimated_execution_time']
            }
            
        except Exception as e:
            self.logger.error(f"ROI hesaplama hatası: {e}")
            return {'error': str(e)}