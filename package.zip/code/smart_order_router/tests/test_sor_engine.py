"""
SOR Engine testi
"""

import unittest
import asyncio
import sys
import os
from unittest.mock import Mock, AsyncMock, patch
from datetime import datetime

# Test dizinini Python path'ine ekle
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.sor_engine import SmartOrderRouter, OrderRequest, ExecutionResult
from core.venue_manager import VenueManager
from core.order_manager import OrderManager

class TestSOREngine(unittest.TestCase):
    """SOR Engine test sınıfı"""
    
    def setUp(self):
        """Test kurulumu"""
        self.config = {
            'venues': {
                'binance': {
                    'enabled': True,
                    'testnet': True,
                    'api_key': 'test_key',
                    'api_secret': 'test_secret'
                }
            },
            'sor_engine': {
                'max_slippage': 0.001,
                'max_spread': 0.005,
                'min_liquidity': 1000.0
            }
        }
        
        self.sor = SmartOrderRouter(self.config)
    
    def test_order_request_creation(self):
        """Sipariş isteği oluşturma testi"""
        order = OrderRequest(
            symbol='BTC/USDT',
            side='buy',
            amount=0.1,
            order_type='limit',
            price=50000.0
        )
        
        self.assertEqual(order.symbol, 'BTC/USDT')
        self.assertEqual(order.side, 'buy')
        self.assertEqual(order.amount, 0.1)
        self.assertEqual(order.order_type, 'limit')
        self.assertEqual(order.price, 50000.0)
        self.assertIsNotNone(order.client_order_id)
        self.assertIsInstance(order.created_at, datetime)
    
    @patch('core.venue_manager.VenueManager')
    async def test_price_discovery(self, mock_venue_manager):
        """Fiyat keşfi testi"""
        # Mock venue manager setup
        mock_venue = Mock()
        mock_venue.is_healthy = True
        mock_venue.is_connected = True
        mock_venue.get_ticker.return_value = {
            'bid': 50000.0,
            'ask': 50100.0,
            'last': 50050.0,
            'volume': 1000.0
        }
        mock_venue.get_order_book.return_value = {
            'bids': [[50000.0, 1.0], [49900.0, 2.0]],
            'asks': [[50100.0, 1.0], [50200.0, 2.0]]
        }
        mock_venue.get_latency.return_value = 100.0
        mock_venue.commission_rate = 0.001
        
        mock_venue_manager.venues = {'binance': mock_venue}
        
        # Fiyat keşfi testi
        price_data = await self.sor._discover_best_prices('BTC/USDT')
        
        self.assertIn('binance', price_data['venues'])
        self.assertEqual(price_data['best_ask'], 50100.0)
        self.assertEqual(price_data['best_bid'], 50000.0)
    
    @patch('core.venue_manager.VenueManager')
    async def test_execution_result_creation(self, mock_venue_manager):
        """Yürütme sonucu oluşturma testi"""
        result = ExecutionResult(
            order_id='test_order_123',
            symbol='BTC/USDT',
            side='buy',
            filled_amount=0.1,
            average_price=50050.0,
            total_cost=5005.0,
            commissions={'binance': 5.005},
            execution_time=0.5,
            venues_used=['binance']
        )
        
        self.assertEqual(result.order_id, 'test_order_123')
        self.assertEqual(result.symbol, 'BTC/USDT')
        self.assertEqual(result.side, 'buy')
        self.assertEqual(result.filled_amount, 0.1)
        self.assertEqual(result.average_price, 50050.0)
        self.assertEqual(result.total_cost, 5005.0)
        self.assertEqual(result.execution_time, 0.5)
        self.assertEqual(result.venues_used, ['binance'])
    
    def test_stats_initialization(self):
        """İstatistik başlatma testi"""
        self.assertEqual(self.sor.stats['total_orders'], 0)
        self.assertEqual(self.sor.stats['successful_orders'], 0)
        self.assertEqual(self.sor.stats['failed_orders'], 0)
        self.assertEqual(self.sor.stats['total_savings'], 0.0)
        self.assertEqual(self.sor.stats['avg_execution_time'], 0.0)
    
    @patch('core.venue_manager.VenueManager')
    @patch('core.order_manager.OrderManager')
    async def test_order_execution_workflow(self, mock_order_manager, mock_venue_manager):
        """Sipariş yürütme workflow testi"""
        # Mock setup
        order_request = OrderRequest(
            symbol='BTC/USDT',
            side='buy',
            amount=0.1,
            order_type='market'
        )
        
        # Mock execution result
        execution_result = ExecutionResult(
            order_id='test_order_123',
            symbol='BTC/USDT',
            side='buy',
            filled_amount=0.1,
            average_price=50050.0,
            total_cost=5005.0,
            commissions={'binance': 5.005},
            execution_time=0.5,
            venues_used=['binance']
        )
        
        # Mock methods
        self.sor._discover_best_prices = AsyncMock(return_value={})
        self.sor.route_optimizer.optimize_routes = AsyncMock(return_value=[])
        self.sor._execute_routes = AsyncMock(return_value=execution_result)
        
        # Test execution
        result = await self.sor.execute_order(order_request)
        
        self.assertEqual(result.order_id, 'test_order_123')
        self.assertEqual(result.filled_amount, 0.1)
        self.assertEqual(self.sor.stats['total_orders'], 1)
        self.assertEqual(self.sor.stats['successful_orders'], 1)
    
    def test_order_request_validation(self):
        """Sipariş isteği doğrulama testi"""
        # Geçerli sipariş
        valid_order = OrderRequest(
            symbol='BTC/USDT',
            side='buy',
            amount=0.1
        )
        self.assertTrue(valid_order.client_order_id)
        
        # Otomatik client_order_id
        order_without_id = OrderRequest(
            symbol='ETH/USDT',
            side='sell',
            amount=1.0
        )
        self.assertIsNotNone(order_without_id.client_order_id)
    
    @patch('core.sor_engine.VenueManager')
    async def test_max_slippage_validation(self, mock_venue_manager):
        """Maksimum kayma doğrulama testi"""
        # High slippage order request
        order_request = OrderRequest(
            symbol='BTC/USDT',
            side='buy',
            amount=10.0,  # Büyük miktar
            max_slippage=0.0001  # Çok düşük slippage
        )
        
        # Mock price data with high slippage
        price_data = {
            'venues': {
                'binance': {
                    'bid': 50000.0,
                    'ask': 50500.0,  # 1% spread
                    'latency': 100.0,
                    'commission_rate': 0.001
                }
            },
            'best_ask': 50500.0,
            'best_bid': 50000.0
        }
        
        # Test order book depth analysis
        depth_result = self.sor._analyze_order_book_depth(
            {'bids': [[50000.0, 0.1]], 'asks': [[50500.0, 0.1]]},
            'BTC/USDT'
        )
        
        self.assertIn('bid_depth', depth_result)
        self.assertIn('ask_depth', depth_result)
        self.assertIn('liquidity_score', depth_result)
    
    def test_client_order_id_generation(self):
        """Client order ID oluşturma testi"""
        order1 = OrderRequest(symbol='BTC/USDT', side='buy', amount=0.1)
        order2 = OrderRequest(symbol='ETH/USDT', side='sell', amount=1.0)
        
        # Unique ID'ler oluşturulmalı
        self.assertNotEqual(order1.client_order_id, order2.client_order_id)
        
        # UUID formatında olmalı
        self.assertEqual(len(order1.client_order_id.split('-')), 5)
    
    @patch('core.sor_engine.VenueManager')
    async def test_empty_price_data_handling(self, mock_venue_manager):
        """Boş fiyat verisi işleme testi"""
        # Mock unhealthy venue
        mock_venue = Mock()
        mock_venue.is_healthy = False
        mock_venue.is_connected = False
        
        mock_venue_manager.venues = {'binance': mock_venue}
        
        # Boş fiyat verisi ile test
        price_data = await self.sor._discover_best_prices('BTC/USDT')
        
        self.assertEqual(price_data['best_ask'], float('inf'))
        self.assertEqual(price_data['best_bid'], 0.0)
        self.assertEqual(len(price_data['venues']), 0)

def run_async_test(test_func):
    """Async test çalıştırıcı"""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        loop.run_until_complete(test_func())
    finally:
        loop.close()

if __name__ == '__main__':
    # Test örnekleri
    print("SOR Engine Test Suite çalıştırılıyor...")
    
    # Sync testler
    suite = unittest.TestLoader().loadTestsFromTestCase(TestSOREngine)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print(f"Test sonuçları: {'BAŞARILI' if result.wasSuccessful() else 'BAŞARISIZ'}")
    print(f"Test sayısı: {result.testsRun}")
    print(f"Hatalar: {len(result.errors)}")
    print(f"Başarısızlıklar: {len(result.failures)}")