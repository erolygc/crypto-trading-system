"""
Algorithm testleri
"""

import unittest
import asyncio
import sys
import os
from unittest.mock import Mock, AsyncMock, patch
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from algorithms.route_optimizer import RouteOptimizer, RouteOption
from algorithms.arbitrage_detector import ArbitrageDetector, ArbitrageOpportunity
from algorithms.commission_calculator import CommissionCalculator, CommissionRate

class TestAlgorithms(unittest.TestCase):
    """Algorithm test sınıfı"""
    
    def setUp(self):
        """Test kurulumu"""
        self.mock_venue_manager = Mock()
        self.mock_venue_manager.venue_metrics = {}
        self.mock_venue_manager.venues = {}
    
    def test_route_option_creation(self):
        """Route option oluşturma testi"""
        route = RouteOption(
            venue='binance',
            amount=0.1,
            price=50000.0,
            estimated_slippage=0.001,
            estimated_commission=5.0,
            total_cost=5005.0,
            liquidity_available=10000.0,
            execution_speed=100.0,
            score=0.85
        )
        
        self.assertEqual(route.venue, 'binance')
        self.assertEqual(route.amount, 0.1)
        self.assertEqual(route.price, 50000.0)
        self.assertEqual(route.estimated_slippage, 0.001)
        self.assertEqual(route.estimated_commission, 5.0)
        self.assertEqual(route.total_cost, 5005.0)
        self.assertEqual(route.liquidity_available, 10000.0)
        self.assertEqual(route.execution_speed, 100.0)
        self.assertEqual(route.score, 0.85)
    
    def test_arbitrage_opportunity_creation(self):
        """Arbitraj fırsatı oluşturma testi"""
        opportunity = ArbitrageOpportunity(
            symbol='BTC/USDT',
            buy_venue='binance',
            sell_venue='bybit',
            buy_price=50000.0,
            sell_price=50100.0,
            spread=0.002,
            potential_profit=10.0,
            max_trade_size=0.1,
            min_profitable_size=0.001,
            timestamp=datetime.utcnow(),
            confidence_score=0.8
        )
        
        self.assertEqual(opportunity.symbol, 'BTC/USDT')
        self.assertEqual(opportunity.buy_venue, 'binance')
        self.assertEqual(opportunity.sell_venue, 'bybit')
        self.assertEqual(opportunity.buy_price, 50000.0)
        self.assertEqual(opportunity.sell_price, 50100.0)
        self.assertEqual(opportunity.spread, 0.002)
        self.assertEqual(opportunity.potential_profit, 10.0)
        self.assertEqual(opportunity.confidence_score, 0.8)
    
    def test_commission_rate_creation(self):
        """Komisyon oranı oluşturma testi"""
        rate = CommissionRate(
            venue='binance',
            maker_rate=0.001,
            taker_rate=0.001,
            vip_level='vip1',
            volume_30d=100000.0,
            discount_rate=0.1,
            effective_rate=0.0009
        )
        
        self.assertEqual(rate.venue, 'binance')
        self.assertEqual(rate.maker_rate, 0.001)
        self.assertEqual(rate.taker_rate, 0.001)
        self.assertEqual(rate.vip_level, 'vip1')
        self.assertEqual(rate.volume_30d, 100000.0)
        self.assertEqual(rate.discount_rate, 0.1)
        self.assertEqual(rate.effective_rate, 0.0009)

class TestRouteOptimizer(unittest.TestCase):
    """Route Optimizer test sınıfı"""
    
    def setUp(self):
        """Test kurulumu"""
        self.mock_venue_manager = Mock()
        self.mock_venue_manager.venue_metrics = {}
        self.mock_venue_manager.venues = {}
        
        self.optimizer = RouteOptimizer(self.mock_venue_manager)
    
    def test_calculate_max_executable_amount(self):
        """Maksimum yürütülebilir miktar hesaplama testi"""
        venue_data = {
            'order_book': {
                'asks': [
                    [50000.0, 0.05],
                    [50100.0, 0.1],
                    [50200.0, 0.2]
                ]
            }
        }
        
        # Test cases
        amount_01 = self.optimizer._calculate_max_executable_amount(venue_data, 0.1)
        self.assertEqual(amount_01, 0.1)  # İlk iki level yeterli
        
        amount_15 = self.optimizer._calculate_max_executable_amount(venue_data, 0.15)
        self.assertAlmostEqual(amount_15, 0.15)  # Üç level gerekli
        
        amount_40 = self.optimizer._calculate_max_executable_amount(venue_data, 0.4)
        self.assertAlmostEqual(amount_40, 0.35)  # Toplam miktar = 0.35
    
    def test_estimate_slippage(self):
        """Kayma tahmini testi"""
        venue_data = {
            'bid': 49900.0,
            'ask': 50100.0,
            'order_book': {
                'asks': [
                    [50100.0, 0.1],
                    [50200.0, 0.2],
                    [50300.0, 0.3]
                ]
            }
        }
        
        # Normal sipariş
        slippage = self.optimizer._estimate_slippage(venue_data, 0.1, 'buy')
        self.assertGreaterEqual(slippage, 0.0)
        self.assertLessEqual(slippage, 0.1)  # Makul aralıkta
        
        # Büyük sipariş
        big_slippage = self.optimizer._estimate_slippage(venue_data, 0.5, 'buy')
        self.assertGreaterEqual(big_slippage, slippage)  # Büyük sipariş = daha fazla kayma
    
    def test_estimate_commission(self):
        """Komisyon tahmini testi"""
        venue_data = {
            'commission_rate': 0.001,
            'order_book': {}
        }
        
        commission = self.optimizer._estimate_commission(venue_data, 0.1, 50000.0)
        expected_commission = 0.1 * 50000.0 * 0.001  # amount * price * rate
        
        self.assertAlmostEqual(commission, expected_commission, places=6)
    
    def test_route_scoring(self):
        """Route puanlama testi"""
        routes = [
            RouteOption('binance', 0.1, 50000.0, 0.001, 5.0, 5005.0, 10000.0, 50.0, 0.0),
            RouteOption('bybit', 0.1, 50100.0, 0.002, 5.01, 5010.01, 8000.0, 100.0, 0.0)
        ]
        
        scored_routes = self.optimizer._score_routes(routes)
        
        # Skorlar atanmış olmalı
        for route in scored_routes:
            self.assertGreater(route.score, 0.0)
        
        # İlk route daha iyi fiyat (50000 vs 50100)
        self.assertGreaterEqual(scored_routes[0].score, scored_routes[1].score)
    
    def test_optimal_combination_selection(self):
        """Optimal kombinasyon seçimi testi"""
        routes = [
            RouteOption('binance', 0.1, 50000.0, 0.001, 5.0, 5005.0, 10000.0, 50.0, 0.9),
            RouteOption('bybit', 0.1, 50100.0, 0.002, 5.01, 5010.01, 8000.0, 100.0, 0.8),
            RouteOption('kraken', 0.1, 50200.0, 0.003, 5.02, 5020.02, 5000.0, 150.0, 0.7)
        ]
        
        routes = self.optimizer._score_routes(routes)
        
        # Optimal allocation
        allocation = self.optimizer._select_optimal_combination(routes, 0.15)
        
        self.assertGreaterEqual(len(allocation), 1)
        self.assertLessEqual(len(allocation), 3)
        
        # Toplam miktar doğru olmalı
        total_amount = sum(route['amount'] for route in allocation)
        self.assertAlmostEqual(total_amount, 0.15, places=6)
    
    def test_optimization_weight_update(self):
        """Optimizasyon ağırlık güncelleme testi"""
        original_weights = self.optimizer.weights.copy()
        
        new_weights = {
            'price': 0.5,
            'liquidity': 0.2,
            'speed': 0.2,
            'cost': 0.1
        }
        
        self.optimizer.update_optimization_weights(new_weights)
        
        # Ağırlıklar güncellenmiş olmalı
        self.assertEqual(self.optimizer.weights['price'], 0.5)
        self.assertEqual(self.optimizer.weights['liquidity'], 0.2)
        self.assertEqual(self.optimizer.weights['speed'], 0.2)
        self.assertEqual(self.optimizer.weights['cost'], 0.1)

class TestArbitrageDetector(unittest.TestCase):
    """Arbitrage Detector test sınıfı"""
    
    def setUp(self):
        """Test kurulumu"""
        self.mock_venue_manager = Mock()
        self.detector = ArbitrageDetector(self.mock_venue_manager)
    
    def test_get_venue_liquidity(self):
        """Venue likidite hesaplama testi"""
        venue_data = {
            'order_book': {
                'bids': [
                    [50000.0, 0.1],
                    [49900.0, 0.2],
                    [49800.0, 0.3]
                ],
                'asks': [
                    [50100.0, 0.1],
                    [50200.0, 0.2],
                    [50300.0, 0.3]
                ]
            }
        }
        
        bid_liquidity = self.detector._get_venue_liquidity(venue_data, 'bid')
        ask_liquidity = self.detector._get_venue_liquidity(venue_data, 'ask')
        
        # Bid likidite: 50000*0.1 + 49900*0.2 + 49800*0.3
        expected_bid = 50000.0 * 0.1 + 49900.0 * 0.2 + 49800.0 * 0.3
        self.assertAlmostEqual(bid_liquidity, expected_bid, places=2)
        
        # Ask likidite: 50100*0.1 + 50200*0.2 + 50300*0.3
        expected_ask = 50100.0 * 0.1 + 50200.0 * 0.2 + 50300.0 * 0.3
        self.assertAlmostEqual(ask_liquidity, expected_ask, places=2)
    
    def test_confidence_score_calculation(self):
        """Güven skoru hesaplama testi"""
        buy_data = {
            'ask': 50000.0,
            'latency': 100.0,
            'volume': 1000000.0
        }
        
        sell_data = {
            'bid': 50100.0,
            'latency': 120.0,
            'volume': 1000000.0
        }
        
        spread = 0.002  # %0.2
        confidence = self.detector._calculate_confidence_score(buy_data, sell_data, spread)
        
        # Güven skoru 0-1 arasında olmalı
        self.assertGreaterEqual(confidence, 0.0)
        self.assertLessEqual(confidence, 1.0)
        
        # Spread yüksek = güven yüksek (makul aralıkta)
        self.assertGreater(confidence, 0.5)
    
    def test_filter_and_rank_opportunities(self):
        """Arbitraj fırsatları filtreleme ve sıralama testi"""
        opportunities = [
            ArbitrageOpportunity('BTC/USDT', 'binance', 'bybit', 50000.0, 50100.0, 
                               0.002, 10.0, 0.1, 0.001, datetime.utcnow(), 0.8),
            ArbitrageOpportunity('BTC/USDT', 'bybit', 'binance', 50100.0, 50000.0, 
                               0.002, 10.0, 0.1, 0.001, datetime.utcnow(), 0.7),
            ArbitrageOpportunity('BTC/USDT', 'kraken', 'okx', 49900.0, 50000.0, 
                               0.002, 10.0, 0.1, 0.001, datetime.utcnow(), 0.9)
        ]
        
        filtered = self.detector._filter_and_rank_opportunities(opportunities)
        
        # Eşikleri geçen fırsatlar filtrelenmeli
        for opp in filtered:
            self.assertGreaterEqual(opp.spread, self.detector.min_spread_threshold)
            self.assertGreaterEqual(opp.potential_profit, self.detector.min_profit_threshold)
            self.assertGreaterEqual(opp.confidence_score, self.detector.confidence_threshold)
        
        # Potansiyel kara göre sıralanmış olmalı
        if len(filtered) > 1:
            self.assertGreaterEqual(filtered[0].potential_profit * filtered[0].confidence_score,
                                  filtered[1].potential_profit * filtered[1].confidence_score)
    
    def test_threshold_update(self):
        """Eşik güncelleme testi"""
        original_thresholds = {
            'min_spread': self.detector.min_spread_threshold,
            'min_profit': self.detector.min_profit_threshold,
            'confidence': self.detector.confidence_threshold,
            'max_trade_size': self.detector.max_trade_size
        }
        
        new_thresholds = {
            'min_spread': 0.001,
            'min_profit': 20.0,
            'confidence': 0.8,
            'max_trade_size': 20000.0
        }
        
        self.detector.update_thresholds(new_thresholds)
        
        # Eşikler güncellenmiş olmalı
        self.assertEqual(self.detector.min_spread_threshold, 0.001)
        self.assertEqual(self.detector.min_profit_threshold, 20.0)
        self.assertEqual(self.detector.confidence_threshold, 0.8)
        self.assertEqual(self.detector.max_trade_size, 20000.0)

class TestCommissionCalculator(unittest.TestCase):
    """Commission Calculator test sınıfı"""
    
    def setUp(self):
        """Test kurulumu"""
        self.calculator = CommissionCalculator()
    
    def test_default_commission_rates(self):
        """Varsayılan komisyon oranları testi"""
        # Binance varsayılan oranları
        binance_rates = self.calculator.default_rates.get('binance')
        self.assertIsNotNone(binance_rates)
        self.assertEqual(binance_rates['maker'], 0.001)
        self.assertEqual(binance_rates['taker'], 0.001)
        self.assertIn('vip_levels', binance_rates)
        
        # Kraken farklı oranlara sahip olmalı
        kraken_rates = self.calculator.default_rates.get('kraken')
        self.assertIsNotNone(kraken_rates)
        self.assertEqual(kraken_rates['maker'], 0.0026)
        self.assertEqual(kraken_rates['taker'], 0.0026)
    
    def test_vip_level_determination(self):
        """VIP seviye belirleme testi"""
        # Mock volume calculations
        with patch.object(self.calculator, '_calculate_30d_volume', return_value=100000):
            vip_level = self.calculator._determine_vip_level('binance')
            self.assertEqual(vip_level, 'vip1')
        
        with patch.object(self.calculator, '_calculate_30d_volume', return_value=1000000):
            vip_level = self.calculator._determine_vip_level('binance')
            self.assertEqual(vip_level, 'vip3')
        
        with patch.object(self.calculator, '_calculate_30d_volume', return_value=10000):
            vip_level = self.calculator._determine_vip_level('binance')
            self.assertEqual(vip_level, 'regular')
    
    def test_discount_rate_calculation(self):
        """İndirim oranı hesaplama testi"""
        # Regular user
        discount_regular = self.calculator._calculate_discount_rate(10000, 'regular')
        self.assertEqual(discount_regular, 0.0)
        
        # VIP user with high volume
        discount_vip_high = self.calculator._calculate_discount_rate(2000000, 'vip3')
        expected = 0.3 + 0.1  # VIP3 + volume bonus
        self.assertAlmostEqual(discount_vip_high, expected, places=2)
        
        # VIP user with medium volume
        discount_vip_med = self.calculator._calculate_discount_rate(600000, 'vip2')
        expected = 0.2 + 0.05  # VIP2 + volume bonus
        self.assertAlmostEqual(discount_vip_med, expected, places=2)
    
    def test_optimal_allocation(self):
        """Optimal alokasyon hesaplama testi"""
        # Mock commission rates
        self.calculator.venue_commission_rates['binance'] = CommissionRate(
            'binance', 0.001, 0.001, 'vip1', 100000, 0.1, 0.0009
        )
        self.calculator.venue_commission_rates['bybit'] = CommissionRate(
            'bybit', 0.001, 0.001, 'regular', 10000, 0.0, 0.001
        )
        
        venues = ['binance', 'bybit']
        order_amount = 1.0
        
        # Normal allocation
        allocation = self.calculator.calculate_optimal_allocation(venues, order_amount)
        
        # Binace düşük komisyonlu olduğu için daha fazla alan almalı
        self.assertGreater(allocation['binance'], allocation['bybit'])
        
        # Toplam miktar doğru olmalı
        total_allocated = sum(allocation.values())
        self.assertAlmostEqual(total_allocated, order_amount, places=6)
        
        # Aggressive allocation (sadece en iyi venue)
        aggressive_allocation = self.calculator.calculate_optimal_allocation(
            venues, order_amount, is_aggressive=True
        )
        
        # En iyi venue daha büyük pay almalı
        self.assertGreaterEqual(
            aggressive_allocation['binance'] / aggressive_allocation['bybit'],
            allocation['binance'] / allocation['bybit']
        )
    
    async def test_commission_calculation(self):
        """Komisyon hesaplama testi"""
        # Mock commission rates
        self.calculator.venue_commission_rates['binance'] = CommissionRate(
            'binance', 0.001, 0.001, 'vip1', 100000, 0.1, 0.0009
        )
        
        venues_used = ['binance']
        total_cost = 50000.0
        
        commissions = await self.calculator.calculate_commissions(venues_used, total_cost)
        
        # Beklenen komisyon: 50000 * 0.0009 = 45.0
        expected_commission = total_cost * 0.0009
        self.assertAlmostEqual(commissions['binance'], expected_commission, places=2)
    
    def test_stats_update(self):
        """İstatistik güncelleme testi"""
        initial_stats = self.calculator.stats.copy()
        
        # Commission calculation simulation
        self.calculator.stats['total_calculations'] = 1
        self.calculator.stats['avg_commission'] = 10.0
        self.calculator.stats['total_commission_saved'] = 5.0
        self.calculator.stats['optimization_calls'] = 1
        
        # Stats should be updated
        self.assertEqual(self.calculator.stats['total_calculations'], 1)
        self.assertEqual(self.calculator.stats['avg_commission'], 10.0)
        self.assertEqual(self.calculator.stats['total_commission_saved'], 5.0)
        self.assertEqual(self.calculator.stats['optimization_calls'], 1)

if __name__ == '__main__':
    print("Algorithm Test Suite çalıştırılıyor...")
    
    # Create test suite
    suite = unittest.TestSuite()
    
    # Add test cases
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestAlgorithms))
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestRouteOptimizer))
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestArbitrageDetector))
    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(TestCommissionCalculator))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print(f"\nTest sonuçları: {'BAŞARILI' if result.wasSuccessful() else 'BAŞARISIZ'}")
    print(f"Test sayısı: {result.testsRun}")
    print(f"Hatalar: {len(result.errors)}")
    print(f"Başarısızlıklar: {len(result.failures)}")