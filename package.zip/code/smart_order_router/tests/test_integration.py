"""
Entegrasyon testleri
"""

import unittest
import asyncio
import sys
import os
from unittest.mock import Mock, AsyncMock, patch
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.sor_engine import SmartOrderRouter, OrderRequest
from core.venue_manager import VenueManager
from core.order_manager import OrderManager
from algorithms.route_optimizer import RouteOptimizer
from algorithms.arbitrage_detector import ArbitrageDetector
from algorithms.commission_calculator import CommissionCalculator
from utils.price_utils import PriceUtils
from utils.config_manager import ConfigManager

class TestIntegration(unittest.TestCase):
    """Entegrasyon test sınıfı"""
    
    def setUp(self):
        """Test kurulumu"""
        self.config = {
            'venues': {
                'binance': {
                    'enabled': True,
                    'testnet': True,
                    'api_key': 'test_key',
                    'api_secret': 'test_secret',
                    'commission_rate': 0.001
                },
                'bybit': {
                    'enabled': True,
                    'testnet': True,
                    'api_key': 'test_key',
                    'api_secret': 'test_secret',
                    'commission_rate': 0.001
                }
            },
            'sor_engine': {
                'max_slippage': 0.001,
                'max_spread': 0.005,
                'min_liquidity': 1000.0
            },
            'monitoring': {
                'health_check_interval': 30,
                'latency_threshold': 1000
            },
            'arbitrage': {
                'min_spread_threshold': 0.0005,
                'min_profit_threshold': 10.0,
                'confidence_threshold': 0.7
            }
        }
    
    @patch('exchange_adapters.binance_adapter.BinanceAdapter')
    @patch('exchange_adapters.bybit_adapter.BybitAdapter')
    async def test_full_order_workflow(self, mock_bybit_class, mock_binance_class):
        """Tam sipariş workflow testi"""
        # Mock venues
        mock_binance = Mock()
        mock_bybit = Mock()
        
        # Mock venue responses
        mock_binance.get_ticker.return_value = {
            'bid': 50000.0, 'ask': 50100.0, 'last': 50050.0, 'volume': 1000.0
        }
        mock_binance.get_order_book.return_value = {
            'bids': [[50000.0, 1.0]], 'asks': [[50100.0, 1.0]]
        }
        mock_binance.get_server_time.return_value = {'server_time': 1234567890}
        mock_binance.submit_order.return_value = {'success': True, 'order_id': 'binance_123'}
        mock_binance.get_order_status.return_value = {'status': 'filled', 'filled': 0.1}
        mock_binance.connect = AsyncMock()
        mock_binance.disconnect = AsyncMock()
        
        mock_bybit.get_ticker.return_value = {
            'bid': 49950.0, 'ask': 50050.0, 'last': 50000.0, 'volume': 800.0
        }
        mock_bybit.get_order_book.return_value = {
            'bids': [[49950.0, 0.8]], 'asks': [[50050.0, 0.8]]
        }
        mock_bybit.get_server_time.return_value = {'server_time': 1234567890}
        mock_bybit.submit_order.return_value = {'success': True, 'order_id': 'bybit_456'}
        mock_bybit.get_order_status.return_value = {'status': 'filled', 'filled': 0.05}
        mock_bybit.connect = AsyncMock()
        mock_bybit.disconnect = AsyncMock()
        
        mock_binance_class.return_value = mock_binance
        mock_bybit_class.return_value = mock_bybit
        
        # Create SOR instance
        sor = SmartOrderRouter(self.config)
        
        # Initialize SOR
        await sor.initialize()
        
        # Create order request
        order_request = OrderRequest(
            symbol='BTC/USDT',
            side='buy',
            amount=0.15,
            order_type='market'
        )
        
        # Execute order
        result = await sor.execute_order(order_request)
        
        # Verify result
        self.assertIsNotNone(result)
        self.assertEqual(result.symbol, 'BTC/USDT')
        self.assertEqual(result.side, 'buy')
        self.assertGreater(result.filled_amount, 0)
        self.assertGreater(result.average_price, 0)
        self.assertGreater(len(result.venues_used), 0)
        
        # Stats should be updated
        self.assertEqual(sor.stats['total_orders'], 1)
        self.assertEqual(sor.stats['successful_orders'], 1)
        
        # Shutdown
        await sor.shutdown()
    
    async def test_price_utils_integration(self):
        """Price Utils entegrasyon testi"""
        # Test price calculations
        bid, ask = 50000.0, 50100.0
        
        spread = PriceUtils.calculate_spread(bid, ask)
        mid_price = PriceUtils.calculate_mid_price(bid, ask)
        
        self.assertAlmostEqual(spread, (ask - bid) / bid, places=6)
        self.assertAlmostEqual(mid_price, (bid + ask) / 2, places=6)
        
        # Test order book analysis
        order_book = [[50100.0, 0.1], [50200.0, 0.2], [50300.0, 0.3]]
        price_impact, avg_price = PriceUtils.calculate_price_impact(0.1, order_book, 'buy')
        
        self.assertGreaterEqual(price_impact, 0.0)
        self.assertGreaterEqual(avg_price, 0.0)
        
        # Test liquidity depth
        liquidity = PriceUtils.calculate_liquidity_depth(order_book, 2)
        expected_liquidity = 50100.0 * 0.1 + 50200.0 * 0.2
        self.assertAlmostEqual(liquidity, expected_liquidity, places=2)
        
        # Test optimal splits
        splits = PriceUtils.find_optimal_splits(order_book, 0.15, 0.1)
        total_split = sum(splits)
        self.assertAlmostEqual(total_split, 0.15, places=6)
        
        # Test venue scoring
        weights = {'price': 0.4, 'liquidity': 0.3, 'speed': 0.2, 'success_rate': 0.1}
        score = PriceUtils.calculate_venue_score(
            bid=50000.0, ask=50100.0, spread=0.002,
            liquidity=10000.0, latency=100.0, success_rate=95.0, weights=weights
        )
        self.assertGreater(score, 0.0)
        
        # Test cross-venue arbitrage
        venues_data = {
            'binance': {'bid': 50000.0, 'ask': 50100.0, 'volume': 1000.0},
            'bybit': {'bid': 49950.0, 'ask': 50050.0, 'volume': 800.0}
        }
        
        opportunities = PriceUtils.calculate_cross_venue_arbitrage(venues_data)
        self.assertIsInstance(opportunities, list)
    
    async def test_config_manager_integration(self):
        """Config Manager entegrasyon testi"""
        config_manager = ConfigManager("test_configs")
        
        # Load default config
        config = config_manager.load_config("test")
        
        # Verify structure
        self.assertIn('venues', config)
        self.assertIn('sor_engine', config)
        self.assertIn('monitoring', config)
        self.assertIn('arbitrage', config)
        
        # Test venue config creation
        binance_config = config_manager.create_venue_config(
            'binance', 
            api_key='test_key', 
            api_secret='test_secret'
        )
        
        self.assertEqual(binance_config['enabled'], True)
        self.assertEqual(binance_config['api_key'], 'test_key')
        self.assertEqual(binance_config['api_secret'], 'test_secret')
        
        # Test config validation
        validation_result = config_manager.validate_config(config)
        
        self.assertIsInstance(validation_result, dict)
        self.assertIn('valid', validation_result)
        self.assertIn('errors', validation_result)
        self.assertIn('warnings', validation_result)
        
        # Test config update
        updates = {'max_slippage': 0.002}
        config_manager.update_config("test", updates)
        
        updated_config = config_manager.get_config("test")
        self.assertEqual(updated_config['sor_engine']['max_slippage'], 0.002)
    
    async def test_algorithms_integration(self):
        """Algorithms entegrasyon testi"""
        # Mock venue manager
        mock_venue_manager = Mock()
        mock_venue_manager.venue_metrics = {}
        mock_venue_manager.venues = {}
        
        # Test route optimization
        route_optimizer = RouteOptimizer(mock_venue_manager)
        
        # Mock order request
        order_request = Mock()
        order_request.symbol = 'BTC/USDT'
        order_request.side = 'buy'
        order_request.amount = 0.1
        
        # Mock price data
        price_data = {
            'venues': {
                'binance': {
                    'bid': 50000.0,
                    'ask': 50100.0,
                    'latency': 100.0,
                    'commission_rate': 0.001,
                    'order_book': {'bids': [[50000.0, 1.0]], 'asks': [[50100.0, 1.0]]}
                }
            },
            'best_ask': 50100.0,
            'best_bid': 50000.0,
            'order_book_depth': {'binance': {'liquidity_score': 10000.0}}
        }
        
        routes = await route_optimizer.optimize_routes(order_request, price_data, [])
        self.assertIsInstance(routes, list)
        
        # Test arbitrage detection
        arbitrage_detector = ArbitrageDetector(mock_venue_manager)
        opportunities = await arbitrage_detector.detect_arbitrage('BTC/USDT', price_data)
        self.assertIsInstance(opportunities, list)
        
        # Test commission calculation
        commission_calculator = CommissionCalculator()
        
        # Mock commission rates
        from algorithms.commission_calculator import CommissionRate
        commission_calculator.venue_commission_rates['binance'] = CommissionRate(
            'binance', 0.001, 0.001, 'vip1', 100000, 0.1, 0.0009
        )
        
        commissions = await commission_calculator.calculate_commissions(['binance'], 5000.0)
        self.assertIn('binance', commissions)
        self.assertGreater(commissions['binance'], 0)
    
    @patch('monitoring.health_monitor.HealthMonitor')
    async def test_monitoring_integration(self, mock_health_monitor_class):
        """Monitoring entegrasyon testi"""
        # Mock health monitor
        mock_health_monitor = Mock()
        mock_health_monitor.start_monitoring = AsyncMock()
        mock_health_monitor.stop_monitoring = AsyncMock()
        mock_health_monitor.get_health_summary = AsyncMock(return_value={
            'summary': {'total_venues': 2, 'healthy_venues': 2},
            'venues': {},
            'active_alerts': 0
        })
        mock_health_monitor_class.return_value = mock_health_monitor
        
        # Create SOR with monitoring
        sor = SmartOrderRouter(self.config)
        
        # Initialize (should start monitoring)
        await sor.initialize()
        
        # Verify monitoring started
        mock_health_monitor.start_monitoring.assert_called_once()
        
        # Get health summary
        health_summary = await sor.health_monitor.get_health_summary()
        self.assertIsInstance(health_summary, dict)
        
        # Shutdown (should stop monitoring)
        await sor.shutdown()
        mock_health_monitor.stop_monitoring.assert_called_once()
    
    async def test_error_handling_integration(self):
        """Hata işleme entegrasyon testi"""
        sor = SmartOrderRouter(self.config)
        
        # Mock venue that fails
        with patch('exchange_adapters.binance_adapter.BinanceAdapter') as mock_adapter_class:
            mock_adapter = Mock()
            mock_adapter.connect = AsyncMock(side_effect=Exception("Connection failed"))
            mock_adapter_class.return_value = mock_adapter
            
            # Initialize should handle error gracefully
            try:
                await sor.initialize()
                # Should not crash, but venue should not be connected
                self.assertEqual(len(sor.venue_manager.venues), 0)
            except Exception as e:
                self.fail(f"Initialize should handle connection errors gracefully: {e}")
    
    async def test_performance_metrics_integration(self):
        """Performans metrikleri entegrasyon testi"""
        sor = SmartOrderRouter(self.config)
        
        # Get initial stats
        initial_stats = await sor.get_execution_stats()
        self.assertIsInstance(initial_stats, dict)
        self.assertIn('stats', initial_stats)
        
        # Mock some order execution
        with patch.object(sor, 'execute_order') as mock_execute:
            mock_execute.return_value = Mock(
                filled_amount=0.1,
                execution_time=0.5,
                venues_used=['binance']
            )
            
            # Execute mock orders
            for i in range(5):
                order_request = OrderRequest(
                    symbol=f'TEST{i}/USDT',
                    side='buy',
                    amount=0.1
                )
                await sor.execute_order(order_request)
            
            # Check updated stats
            final_stats = await sor.get_execution_stats()
            self.assertEqual(final_stats['stats']['total_orders'], 5)
            self.assertEqual(final_stats['stats']['successful_orders'], 5)
    
    def test_end_to_end_scenario(self):
        """Uçtan uca senaryo testi"""
        # Price Utils scenarios
        scenarios = [
            {
                'bid': 50000.0,
                'ask': 50100.0,
                'expected_spread': 0.002,
                'expected_mid': 50050.0
            },
            {
                'bid': 100.0,
                'ask': 100.5,
                'expected_spread': 0.005,
                'expected_mid': 100.25
            }
        ]
        
        for scenario in scenarios:
            bid = scenario['bid']
            ask = scenario['ask']
            
            spread = PriceUtils.calculate_spread(bid, ask)
            mid_price = PriceUtils.calculate_mid_price(bid, ask)
            
            self.assertAlmostEqual(spread, scenario['expected_spread'], places=3)
            self.assertAlmostEqual(mid_price, scenario['expected_mid'], places=3)
        
        # Format tests
        price_formatted = PriceUtils.format_price(0.00001234, 8)
        self.assertIsInstance(price_formatted, str)
        
        percentage_formatted = PriceUtils.format_percentage(0.0123, 2)
        self.assertIsInstance(percentage_formatted, str)
        self.assertIn('%', percentage_formatted)

if __name__ == '__main__':
    print("Integration Test Suite çalıştırılıyor...")
    
    suite = unittest.TestLoader().loadTestsFromTestCase(TestIntegration)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print(f"\nEntegrasyon Test Sonuçları: {'BAŞARILI' if result.wasSuccessful() else 'BAŞARISIZ'}")
    print(f"Test sayısı: {result.testsRun}")
    print(f"Hatalar: {len(result.errors)}")
    print(f"Başarısızlıklar: {len(result.failures)}")
    
    if result.errors:
        print("\nHatalar:")
        for error in result.errors:
            print(f"- {error[0]}: {error[1]}")
    
    if result.failures:
        print("\nBaşarısızlıklar:")
        for failure in result.failures:
            print(f"- {failure[0]}: {failure[1]}")