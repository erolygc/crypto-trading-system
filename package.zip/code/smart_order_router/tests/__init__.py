"""
Test paketi
"""

import unittest
import asyncio
import sys
import os

# Test dizinini Python path'ine ekle
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from test_sor_engine import TestSOREngine
from test_venue_manager import TestVenueManager  
from test_algorithms import TestAlgorithms
from test_integration import TestIntegration

def run_all_tests():
    """Tüm testleri çalıştır"""
    # Test suite oluştur
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Test sınıflarını ekle
    suite.addTests(loader.loadTestsFromTestCase(TestSOREngine))
    suite.addTests(loader.loadTestsFromTestCase(TestVenueManager))
    suite.addTests(loader.loadTestsFromTestCase(TestAlgorithms))
    suite.addTests(loader.loadTestsFromTestCase(TestIntegration))
    
    # Test runner
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()

if __name__ == '__main__':
    success = run_all_tests()
    sys.exit(0 if success else 1)