"""
Venue Manager testi
"""

import unittest
import asyncio
import sys
import os
from unittest.mock import Mock, AsyncMock, patch
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.venue_manager import VenueManager, VenueMetrics, VenueStatus

class TestVenueManager(unittest.TestCase):
    """Venue Manager test sınıfı"""
    
    def setUp(self):
        """Test kurulumu"""
        self.config = {
            'venues': {
                'binance': {
                    'enabled': True,
                    'testnet': True,
                    'api_key': 'test_key',
                    'api_secret': 'test_secret'
                },
                'bybit': {
                    'enabled': True,
                    'testnet': True,
                    'api_key': 'test_key',
                    'api_secret': 'test_secret'
                }
            }
        }
        
        self.venue_manager = VenueManager(self.config)
    
    def test_venue_metrics_creation(self):
        """Venue metrics oluşturma testi"""
        metrics = VenueMetrics(name='binance')
        
        self.assertEqual(metrics.name, 'binance')
        self.assertEqual(metrics.latency, 0.0)
        self.assertEqual(metrics.success_rate, 100.0)
        self.assertEqual(metrics.total_orders, 0)
        self.assertEqual(metrics.successful_orders, 0)
        self.assertEqual(metrics.avg_spread, 0.0)
        self.assertEqual(metrics.liquidity_score, 0.0)
        self.assertEqual(metrics.commission_rate, 0.001)
        self.assertIsInstance(metrics.last_updated, datetime)
        self.assertEqual(metrics.health_score, 100.0)
    
    def test_venue_status_creation(self):
        """Venue status oluşturma testi"""
        status = VenueStatus(name='binance')
        
        self.assertEqual(status.name, 'binance')
        self.assertFalse(status.is_connected)
        self.assertTrue(status.is_healthy)
        self.assertIsNone(status.last_heartbeat)
        self.assertEqual(status.error_count, 0)
        self.assertEqual(status.consecutive_errors, 0)
        self.assertIsNone(status.last_error)
        self.assertEqual(status.uptime, 0.0)
    
    @patch('exchange_adapters.binance_adapter.BinanceAdapter')
    async def test_get_ticker_success(self, mock_adapter_class):
        """Ticker başarı testi"""
        # Mock adapter setup
        mock_adapter = Mock()
        mock_adapter.get_ticker.return_value = {
            'bid': 50000.0,
            'ask': 50100.0,
            'last': 50050.0,
            'volume': 1000.0
        }
        mock_adapter_class.return_value = mock_adapter
        
        # Mock connection
        mock_adapter.connect = AsyncMock()
        
        # Venue manager'a ekle
        self.venue_manager.venues['binance'] = mock_adapter
        self.venue_manager.venue_metrics['binance'] = VenueMetrics('binance')
        self.venue_manager.venue_status['binance'] = VenueStatus('binance')
        
        # Test ticker
        ticker = await self.venue_manager.get_ticker('binance', 'BTC/USDT')
        
        self.assertEqual(ticker['bid'], 50000.0)
        self.assertEqual(ticker['ask'], 50100.0)
        self.assertEqual(ticker['last'], 50050.0)
        self.assertEqual(ticker['volume'], 1000.0)
        
        # Metrics güncellenmeli
        metrics = self.venue_manager.venue_metrics['binance']
        self.assertEqual(metrics.total_orders, 1)
        self.assertEqual(metrics.successful_orders, 1)
        self.assertEqual(metrics.success_rate, 100.0)
    
    @patch('exchange_adapters.binance_adapter.BinanceAdapter')
    async def test_get_ticker_error(self, mock_adapter_class):
        """Ticker hata testi"""
        # Mock adapter with error
        mock_adapter = Mock()
        mock_adapter.get_ticker.side_effect = Exception("API Error")
        mock_adapter_class.return_value = mock_adapter
        
        # Mock connection
        mock_adapter.connect = AsyncMock()
        
        # Setup venue
        self.venue_manager.venues['binance'] = mock_adapter
        self.venue_manager.venue_metrics['binance'] = VenueMetrics('binance')
        self.venue_manager.venue_status['binance'] = VenueStatus('binance')
        
        # Test error handling
        with self.assertRaises(Exception):
            await self.venue_manager.get_ticker('binance', 'BTC/USDT')
        
        # Error metrics güncellenmeli
        status = self.venue_manager.venue_status['binance']
        self.assertEqual(status.error_count, 1)
        self.assertEqual(status.consecutive_errors, 1)
        self.assertEqual(status.last_error, "API Error")
    
    def test_best_venue_selection_by_criteria(self):
        """Kriterlere göre en iyi venue seçimi"""
        # Metrics setup
        self.venue_manager.venue_metrics['binance'] = VenueMetrics('binance')
        self.venue_manager.venue_metrics['bybit'] = VenueMetrics('bybit')
        self.venue_manager.venue_status['binance'] = VenueStatus('binance')
        self.venue_manager.venue_status['bybit'] = VenueStatus('bybit')
        
        # Test data
        metrics_binance = self.venue_manager.venue_metrics['binance']
        metrics_binance.latency = 50.0
        metrics_binance.avg_spread = 0.0005
        metrics_binance.liquidity_score = 10000.0
        metrics_binance.success_rate = 95.0
        metrics_binance.health_score = 90.0
        
        metrics_bybit = self.venue_manager.venue_metrics['bybit']
        metrics_bybit.latency = 100.0
        metrics_bybit.avg_spread = 0.001
        metrics_bybit.liquidity_score = 5000.0
        metrics_bybit.success_rate = 90.0
        metrics_bybit.health_score = 85.0
        
        # Kriterler
        criteria = {
            'latency': {'weight': 0.3, 'max': 200},
            'spread': {'weight': 0.3, 'max': 0.002},
            'liquidity': {'weight': 0.2, 'min': 1000},
            'success_rate': {'weight': 0.2, 'min': 80}
        }
        
        best_venue = self.venue_manager.get_best_venue_by_criteria(criteria)
        
        # Binance daha iyi skor almalı (düşük latency, spread, yüksek likidite)
        self.assertEqual(best_venue, 'binance')
    
    def test_performance_metrics(self):
        """Performans metrikleri testi"""
        # Setup metrics
        metrics1 = VenueMetrics('binance')
        metrics1.latency = 50.0
        metrics1.success_rate = 95.0
        metrics1.avg_spread = 0.0005
        metrics1.liquidity_score = 10000.0
        metrics1.commission_rate = 0.001
        metrics1.health_score = 90.0
        
        metrics2 = VenueMetrics('bybit')
        metrics2.latency = 100.0
        metrics2.success_rate = 90.0
        metrics2.avg_spread = 0.001
        metrics2.liquidity_score = 5000.0
        metrics2.commission_rate = 0.001
        metrics2.health_score = 85.0
        
        self.venue_manager.venue_metrics['binance'] = metrics1
        self.venue_manager.venue_metrics['bybit'] = metrics2
        
        self.venue_manager.venue_status['binance'] = VenueStatus('binance')
        self.venue_manager.venue_status['bybit'] = VenueStatus('bybit')
        
        # Get performance metrics
        perf_metrics = self.venue_manager.get_performance_metrics()
        
        self.assertIn('binance', perf_metrics)
        self.assertIn('bybit', perf_metrics)
        
        # Binance metrics
        binance_perf = perf_metrics['binance']
        self.assertEqual(binance_perf['metrics']['latency'], 50.0)
        self.assertEqual(binance_perf['metrics']['success_rate'], 95.0)
        self.assertTrue(binance_perf['status']['is_connected'])
        self.assertTrue(binance_perf['status']['is_healthy'])
    
    async def test_health_check_success(self):
        """Sağlık kontrolü başarı testi"""
        # Mock healthy venue
        mock_venue = Mock()
        mock_venue.get_server_time = AsyncMock(return_value={'server_time': 1234567890})
        self.venue_manager.venues['binance'] = mock_venue
        
        # Health check
        health_result = await self.venue_manager.health_check('binance')
        
        self.assertEqual(health_result['status'], 'healthy')
        self.assertIn('latency', health_result)
        self.assertIn('timestamp', health_result)
        
        # Status güncellenmeli
        status = self.venue_manager.venue_status['binance']
        self.assertTrue(status.is_connected)
        self.assertTrue(status.is_healthy)
        self.assertEqual(status.consecutive_errors, 0)
    
    async def test_health_check_failure(self):
        """Sağlık kontrolü hata testi"""
        # Mock unhealthy venue
        mock_venue = Mock()
        mock_venue.get_server_time = AsyncMock(side_effect=Exception("Connection failed"))
        self.venue_manager.venues['binance'] = mock_venue
        
        # Health check
        health_result = await self.venue_manager.health_check('binance')
        
        self.assertEqual(health_result['status'], 'unhealthy')
        self.assertIn('error', health_result)
        self.assertIn('timestamp', health_result)
        
        # Status güncellenmeli
        status = self.venue_manager.venue_status['binance']
        self.assertFalse(status.is_connected)
        self.assertFalse(status.is_healthy)
        self.assertGreater(status.consecutive_errors, 0)
    
    def test_error_metrics_update(self):
        """Hata metrikleri güncelleme testi"""
        metrics = VenueMetrics('binance')
        self.venue_manager.venue_metrics['binance'] = metrics
        
        status = VenueStatus('binance')
        self.venue_manager.venue_status['binance'] = status
        
        # Error update
        self.venue_manager._update_error_metrics('binance', "Test error")
        
        self.assertEqual(status.error_count, 1)
        self.assertEqual(status.consecutive_errors, 1)
        self.assertEqual(status.last_error, "Test error")
        
        # Health score düşmeli
        self.assertLess(metrics.health_score, 100.0)
    
    def test_health_score_update(self):
        """Sağlık skoru güncelleme testi"""
        metrics = VenueMetrics('binance')
        initial_score = metrics.health_score
        self.venue_manager.venue_metrics['binance'] = metrics
        
        # Success update
        self.venue_manager._update_health_score('binance', True)
        self.assertGreater(metrics.health_score, initial_score)
        
        # Failure update
        self.venue_manager._update_health_score('binance', False)
        self.assertLess(metrics.health_score, initial_score)

def run_async_test(test_func):
    """Async test çalıştırıcı"""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        loop.run_until_complete(test_func())
    finally:
        loop.close()

if __name__ == '__main__':
    print("Venue Manager Test Suite çalıştırılıyor...")
    
    suite = unittest.TestLoader().loadTestsFromTestCase(TestVenueManager)
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print(f"Test sonuçları: {'BAŞARILI' if result.wasSuccessful() else 'BAŞARISIZ'}")
    print(f"Test sayısı: {result.testsRun}")
    print(f"Hatalar: {len(result.errors)}")
    print(f"Başarısızlıklar: {len(result.failures)}")