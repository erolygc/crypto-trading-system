"""
Borsa Yöneticisi - Çoklu borsa bağlantıları ve işlemler
"""

import asyncio
import ccxt
import time
import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import json

from ..config import ExchangeConfig

class ExchangeManager:
    """
    Çoklu borsa bağlantı yöneticisi
    Tüm borsalarla bağlantı kurar ve işlemleri yönetir
    """
    
    def __init__(self, exchange_configs: Dict[str, ExchangeConfig]):
        """Exchange manager'ı başlat"""
        self.exchange_configs = exchange_configs
        self.exchanges: Dict[str, ccxt.Exchange] = {}
        self.logger = logging.getLogger("ExchangeManager")
        
        # Durum bilgileri
        self.connection_status: Dict[str, bool] = {}
        self.last_heartbeat: Dict[str, float] = {}
        self.latency: Dict[str, float] = {}
        
        # Rate limiting
        self.rate_limiter = {}
    
    async def initialize(self) -> bool:
        """Tüm borsalarla bağlantı kur"""
        self.logger.info("Borsa bağlantıları başlatılıyor...")
        
        success_count = 0
        for exchange_name, config in self.exchange_configs.items():
            try:
                exchange = await self._create_exchange_instance(exchange_name, config)
                if exchange:
                    self.exchanges[exchange_name] = exchange
                    self.connection_status[exchange_name] = True
                    self.last_heartbeat[exchange_name] = time.time()
                    success_count += 1
                    self.logger.info(f"{exchange_name} bağlantısı kuruldu")
                else:
                    self.connection_status[exchange_name] = False
                    self.logger.warning(f"{exchange_name} bağlantısı kurulamadı")
                    
            except Exception as e:
                self.connection_status[exchange_name] = False
                self.logger.error(f"{exchange_name} bağlantı hatası: {e}")
        
        if success_count == 0:
            self.logger.error("Hiçbir borsa bağlantısı kurulamadı")
            return False
        
        self.logger.info(f"{success_count}/{len(self.exchange_configs)} borsa bağlantısı kuruldu")
        return True
    
    async def _create_exchange_instance(self, name: str, config: ExchangeConfig) -> Optional[ccxt.Exchange]:
        """Exchange instance'ı oluştur"""
        try:
            # CCXT exchange sınıfını al
            exchange_class = getattr(ccxt, name)
            
            if not exchange_class:
                raise ValueError(f"Bilinmeyen borsa: {name}")
            
            # Exchange instance'ı oluştur
            exchange = exchange_class({
                'apiKey': config.api_key,
                'secret': config.api_secret,
                'sandbox': config.sandbox,
                'enableRateLimit': True,
                'timeout': 30000,  # 30 saniye timeout
            })
            
            # Test bağlantısı
            await self._test_connection(exchange)
            
            return exchange
            
        except Exception as e:
            self.logger.error(f"{name} instance oluşturma hatası: {e}")
            return None
    
    async def _test_connection(self, exchange: ccxt.Exchange) -> bool:
        """Exchange bağlantısını test et"""
        try:
            # Basit bir API çağrısı yap
            start_time = time.time()
            await exchange.fetch_balance()
            latency = (time.time() - start_time) * 1000
            
            self.logger.debug(f"Bağlantı testi başarılı, latency: {latency:.2f}ms")
            return True
            
        except Exception as e:
            self.logger.error(f"Bağlantı testi başarısız: {e}")
            raise
    
    def get_exchanges(self) -> List[str]:
        """Bağlı borsaları döndür"""
        return list(self.exchanges.keys())
    
    def is_connected(self, exchange_name: str) -> bool:
        """Borsa bağlantı durumunu kontrol et"""
        return self.connection_status.get(exchange_name, False)
    
    def get_latency(self, exchange_name: str) -> float:
        """Borsa latency'sini döndür"""
        return self.latency.get(exchange_name, 0.0)
    
    async def get_order_books(self, symbol: str, limit: int = 20) -> Dict[str, Dict]:
        """Tüm borsalardan order book verilerini al"""
        order_books = {}
        
        tasks = []
        for exchange_name, exchange in self.exchanges.items():
            if self.connection_status.get(exchange_name, False):
                tasks.append(self._fetch_order_book(exchange_name, exchange, symbol, limit))
        
        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for i, result in enumerate(results):
                exchange_name = list(self.exchanges.keys())[i]
                if isinstance(result, Exception):
                    self.logger.error(f"{exchange_name} order book hatası: {result}")
                    order_books[exchange_name] = None
                else:
                    order_books[exchange_name] = result
        
        return order_books
    
    async def _fetch_order_book(self, exchange_name: str, exchange: ccxt.Exchange, 
                               symbol: str, limit: int) -> Optional[Dict]:
        """Order book verisini al"""
        try:
            start_time = time.time()
            order_book = await exchange.fetch_order_book(symbol, limit)
            latency = (time.time() - start_time) * 1000
            
            self.latency[exchange_name] = latency
            self.last_heartbeat[exchange_name] = time.time()
            
            return order_book
            
        except Exception as e:
            self.logger.error(f"{exchange_name} order book hatası: {e}")
            self.connection_status[exchange_name] = False
            return None
    
    async def get_tickers(self, symbol: str = None) -> Dict[str, Dict]:
        """Tüm borsalardan ticker verilerini al"""
        tickers = {}
        
        tasks = []
        for exchange_name, exchange in self.exchanges.items():
            if self.connection_status.get(exchange_name, False):
                tasks.append(self._fetch_ticker(exchange_name, exchange, symbol))
        
        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for i, result in enumerate(results):
                exchange_name = list(self.exchanges.keys())[i]
                if isinstance(result, Exception):
                    self.logger.error(f"{exchange_name} ticker hatası: {result}")
                    tickers[exchange_name] = None
                else:
                    tickers[exchange_name] = result
        
        return tickers
    
    async def _fetch_ticker(self, exchange_name: str, exchange: ccxt.Exchange, 
                           symbol: str = None) -> Optional[Dict]:
        """Ticker verisini al"""
        try:
            start_time = time.time()
            
            if symbol:
                ticker = await exchange.fetch_ticker(symbol)
            else:
                tickers = await exchange.fetch_tickers()
                ticker = tickers.get(symbol) if symbol else list(tickers.values())[0] if tickers else None
            
            latency = (time.time() - start_time) * 1000
            self.latency[exchange_name] = latency
            self.last_heartbeat[exchange_name] = time.time()
            
            return ticker
            
        except Exception as e:
            self.logger.error(f"{exchange_name} ticker hatası: {e}")
            return None
    
    async def place_order(self, exchange_name: str, symbol: str, side: str, 
                         amount: float, order_type: str = 'market', 
                         price: float = None, params: Dict = None) -> Optional[Dict]:
        """Borsaya emir yerleştir"""
        if not self.is_connected(exchange_name):
            self.logger.error(f"{exchange_name} bağlı değil")
            return None
        
        exchange = self.exchanges[exchange_name]
        params = params or {}
        
        try:
            # Rate limiting kontrolü
            await self._check_rate_limit(exchange_name)
            
            start_time = time.time()
            
            # Emir tipine göre işlem yap
            if order_type == 'market':
                order = await exchange.create_market_order(symbol, side, amount, params=params)
            elif order_type == 'limit':
                if price is None:
                    raise ValueError("Limit emir için fiyat gerekli")
                order = await exchange.create_limit_order(symbol, side, amount, price, params=params)
            else:
                raise ValueError(f"Desteklenmeyen emir tipi: {order_type}")
            
            latency = (time.time() - start_time) * 1000
            self.latency[exchange_name] = latency
            self.last_heartbeat[exchange_name] = time.time()
            
            self.logger.info(f"{exchange_name} emir yerleştirildi: {order.get('id', 'N/A')}")
            return order
            
        except Exception as e:
            self.logger.error(f"{exchange_name} emir yerleştirme hatası: {e}")
            return None
    
    async def cancel_order(self, exchange_name: str, order_id: str, 
                          symbol: str = None) -> bool:
        """Emir iptal et"""
        if not self.is_connected(exchange_name):
            return False
        
        exchange = self.exchanges[exchange_name]
        
        try:
            # Rate limiting kontrolü
            await self._check_rate_limit(exchange_name)
            
            await exchange.cancel_order(order_id, symbol)
            self.logger.info(f"{exchange_name} emir iptal edildi: {order_id}")
            return True
            
        except Exception as e:
            self.logger.error(f"{exchange_name} emir iptal hatası: {e}")
            return False
    
    async def get_order_status(self, exchange_name: str, order_id: str, 
                              symbol: str = None) -> Optional[Dict]:
        """Emir durumunu sorgula"""
        if not self.is_connected(exchange_name):
            return None
        
        exchange = self.exchanges[exchange_name]
        
        try:
            # Rate limiting kontrolü
            await self._check_rate_limit(exchange_name)
            
            order = await exchange.fetch_order(order_id, symbol)
            return order
            
        except Exception as e:
            self.logger.error(f"{exchange_name} emir durumu sorgu hatası: {e}")
            return None
    
    async def get_balance(self, exchange_name: str, currency: str = None) -> Optional[Dict]:
        """Bakiye sorgula"""
        if not self.is_connected(exchange_name):
            return None
        
        exchange = self.exchanges[exchange_name]
        
        try:
            # Rate limiting kontrolü
            await self._check_rate_limit(exchange_name)
            
            balance = await exchange.fetch_balance()
            
            if currency and currency in balance:
                return {currency: balance[currency]}
            
            return balance
            
        except Exception as e:
            self.logger.error(f"{exchange_name} bakiye sorgu hatası: {e}")
            return None
    
    async def get_trading_fees(self, exchange_name: str, symbol: str = None) -> Optional[Dict]:
        """Trading fee bilgilerini al"""
        if not self.is_connected(exchange_name):
            return None
        
        exchange = self.exchanges[exchange_name]
        
        try:
            fees = await exchange.fetch_trading_fees(symbol)
            return fees
            
        except Exception as e:
            self.logger.error(f"{exchange_name} fee bilgisi hatası: {e}")
            return None
    
    async def _check_rate_limit(self, exchange_name: str):
        """Rate limiting kontrolü"""
        # Basit rate limiting implementasyonu
        # Gerçek uygulamada daha sofistike olmalı
        if exchange_name not in self.rate_limiter:
            self.rate_limiter[exchange_name] = []
        
        now = time.time()
        self.rate_limiter[exchange_name] = [
            timestamp for timestamp in self.rate_limiter[exchange_name] 
            if now - timestamp < 1.0  # Son 1 saniye
        ]
        
        if len(self.rate_limiter[exchange_name]) >= 100:  # 100 istek/saniye
            sleep_time = 1.0 - (now - self.rate_limiter[exchange_name][0])
            if sleep_time > 0:
                await asyncio.sleep(sleep_time)
        
        self.rate_limiter[exchange_name].append(now)
    
    async def check_health(self) -> Dict[str, Dict]:
        """Tüm borsaların sağlık durumunu kontrol et"""
        health_status = {}
        
        for exchange_name in self.exchanges.keys():
            try:
                # Son heartbeat'ten bu yana geçen süre
                last_heartbeat = self.last_heartbeat.get(exchange_name, 0)
                time_since_heartbeat = time.time() - last_heartbeat
                
                # Bağlantı durumu
                connected = self.connection_status.get(exchange_name, False)
                
                # Latency
                latency = self.latency.get(exchange_name, 0)
                
                # Sağlık durumu
                if connected and time_since_heartbeat < 30:  # 30 saniye
                    status = 'healthy'
                elif connected and time_since_heartbeat < 60:
                    status = 'warning'
                else:
                    status = 'unhealthy'
                
                health_status[exchange_name] = {
                    'status': status,
                    'connected': connected,
                    'latency_ms': latency,
                    'last_heartbeat': last_heartbeat,
                    'time_since_heartbeat': time_since_heartbeat
                }
                
            except Exception as e:
                health_status[exchange_name] = {
                    'status': 'error',
                    'error': str(e)
                }
        
        return health_status
    
    async def reconnect_exchange(self, exchange_name: str) -> bool:
        """Belirli bir borsayla yeniden bağlantı kur"""
        if exchange_name in self.exchange_configs:
            self.logger.info(f"{exchange_name} yeniden bağlanıyor...")
            
            try:
                exchange = await self._create_exchange_instance(
                    exchange_name, self.exchange_configs[exchange_name]
                )
                
                if exchange:
                    self.exchanges[exchange_name] = exchange
                    self.connection_status[exchange_name] = True
                    self.last_heartbeat[exchange_name] = time.time()
                    self.logger.info(f"{exchange_name} yeniden bağlandı")
                    return True
                else:
                    self.logger.error(f"{exchange_name} yeniden bağlanamadı")
                    return False
                    
            except Exception as e:
                self.logger.error(f"{exchange_name} yeniden bağlanma hatası: {e}")
                return False
        
        return False
    
    async def shutdown(self):
        """Tüm bağlantıları kapat"""
        self.logger.info("Borsa bağlantıları kapatılıyor...")
        
        for exchange_name, exchange in self.exchanges.items():
            try:
                if hasattr(exchange, 'close'):
                    await exchange.close()
            except Exception as e:
                self.logger.warning(f"{exchange_name} kapatma hatası: {e}")
        
        self.exchanges.clear()
        self.connection_status.clear()
        self.logger.info("Borsa bağlantıları kapatıldı")