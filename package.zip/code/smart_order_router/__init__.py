"""
Bitwisers 2.0 Smart Order Router
Çoklu borsa optimizasyonu ve akıllı order routing sistemi
"""

from .sor import SmartOrderRouter, get_sor_instance, shutdown_sor
from .config import Config, SORConfig, ExchangeConfig

__version__ = "2.0.0"
__author__ = "Bitwisers Team"
__description__ = "Smart Order Router for Multi-Exchange Trading"

__all__ = [
    'SmartOrderRouter',
    'get_sor_instance', 
    'shutdown_sor',
    'Config',
    'SORConfig',
    'ExchangeConfig'
]