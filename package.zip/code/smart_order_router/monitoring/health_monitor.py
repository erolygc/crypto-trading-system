"""
Health Monitor - Gerçek zamanlı venue sağlık izleme sistemi
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import time
import statistics
import json

@dataclass
class HealthStatus:
    """Sağlık durumu veri modeli"""
    venue: str
    status: str  # healthy, degraded, unhealthy, offline
    latency: float  # ms
    error_rate: float  # %
    uptime: float  # %
    last_check: datetime
    consecutive_failures: int
    total_checks: int
    successful_checks: int
    last_error: Optional[str] = None
    
    # Detaylı metrikler
    avg_latency_5min: float = 0.0
    avg_latency_1hour: float = 0.0
    error_rate_5min: float = 0.0
    throughput: float = 0.0  # istek/saniye

@dataclass
class AlertRule:
    """Alarm kuralı"""
    name: str
    condition: Callable[[HealthStatus], bool]
    severity: str  # info, warning, critical
    message_template: str
    cooldown_period: timedelta = field(default_factory=lambda: timedelta(minutes=5))
    last_triggered: Optional[datetime] = None
    enabled: bool = True

class HealthMonitor:
    """
    Gerçek zamanlı venue sağlık izleme sistemi
    """
    
    def __init__(self, venue_manager):
        self.venue_manager = venue_manager
        self.logger = logging.getLogger(__name__)
        
        # Sağlık durumları
        self.health_statuses: Dict[str, HealthStatus] = {}
        
        # İzleme konfigürasyonu
        self.check_interval = 30  # 30 saniye
        self.latency_threshold = 1000  # 1 saniye
        self.error_rate_threshold = 10  # %10
        self.consecutive_failure_threshold = 3
        
        # Alarm kuralları
        self.alert_rules: List[AlertRule] = []
        self.active_alerts: List[Dict] = []
        
        # İstatistikler
        self.stats = {
            'total_checks': 0,
            'total_venues': 0,
            'healthy_venues': 0,
            'degraded_venues': 0,
            'unhealthy_venues': 0,
            'offline_venues': 0,
            'avg_latency': 0.0,
            'total_errors': 0
        }
        
        # İzleme döngüsü
        self.monitoring_task: Optional[asyncio.Task] = None
        self.is_monitoring = False
        
        # Alarm callback'leri
        self.alert_callbacks: List[Callable] = []
        
        # Sağlık geçmişi (son 24 saat)
        self.health_history: List[Dict] = []
    
    async def start_monitoring(self):
        """Sağlık izlemeyi başlat"""
        if self.is_monitoring:
            return
        
        self.is_monitoring = True
        self.logger.info("Sağlık izleme başlatılıyor...")
        
        # Varsayılan alarm kurallarını ayarla
        self._setup_default_alert_rules()
        
        # İzleme görevini başlat
        self.monitoring_task = asyncio.create_task(self._monitoring_loop())
        
        self.logger.info("Sağlık izleme başlatıldı")
    
    async def stop_monitoring(self):
        """Sağlık izlemeyi durdur"""
        self.is_monitoring = False
        
        if self.monitoring_task:
            self.monitoring_task.cancel()
            try:
                await self.monitoring_task
            except asyncio.CancelledError:
                pass
        
        self.logger.info("Sağlık izleme durduruldu")
    
    def _setup_default_alert_rules(self):
        """Varsayılan alarm kurallarını ayarla"""
        
        def high_latency_check(status: HealthStatus) -> bool:
            return status.latency > 2000  # 2 saniye üzeri
        
        def high_error_rate_check(status: HealthStatus) -> bool:
            return status.error_rate > 20  # %20 üzeri
        
        def consecutive_failures_check(status: HealthStatus) -> bool:
            return status.consecutive_failures >= 5
        
        def offline_check(status: HealthStatus) -> bool:
            return status.status == 'offline'
        
        def degraded_check(status: HealthStatus) -> bool:
            return status.status == 'degraded'
        
        # Alarm kurallarını ekle
        self.alert_rules.extend([
            AlertRule(
                name="Yüksek Gecikme",
                condition=high_latency_check,
                severity="warning",
                message_template="Venue {venue} gecikmesi çok yüksek: {latency:.2f}ms"
            ),
            AlertRule(
                name="Yüksek Hata Oranı", 
                condition=high_error_rate_check,
                severity="critical",
                message_template="Venue {venue} hata oranı çok yüksek: {error_rate:.2f}%"
            ),
            AlertRule(
                name="Ardışık Hatalar",
                condition=consecutive_failures_check,
                severity="critical", 
                message_template="Venue {venue} çok sayıda ardışık hata: {failures}"
            ),
            AlertRule(
                name="Bağlantı Kesildi",
                condition=offline_check,
                severity="critical",
                message_template="Venue {venue} bağlantısı kesildi"
            ),
            AlertRule(
                name="Performans Degrade",
                condition=degraded_check,
                severity="warning",
                message_template="Venue {venue} performansı degrade durumda"
            )
        ])
    
    async def _monitoring_loop(self):
        """Ana sağlık izleme döngüsü"""
        while self.is_monitoring:
            try:
                await self._check_all_venues()
                await self._process_alerts()
                await self._cleanup_old_data()
                await asyncio.sleep(self.check_interval)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Sağlık izleme hatası: {e}")
                await asyncio.sleep(5)
    
    async def _check_all_venues(self):
        """Tüm venue'ların sağlığını kontrol et"""
        for venue_name in self.venue_manager.venues.keys():
            try:
                await self._check_venue_health(venue_name)
            except Exception as e:
                self.logger.error(f"Venue sağlık kontrol hatası {venue_name}: {e}")
                continue
    
    async def _check_venue_health(self, venue_name: str):
        """Belirli bir venue'un sağlığını kontrol et"""
        start_time = time.time()
        
        try:
            # Sağlık kontrolü yap
            health_result = await self.venue_manager.health_check(venue_name)
            
            # Latency ölç
            latency = health_result.get('latency', 0) if health_result.get('status') == 'healthy' else float('inf')
            
            # Durum belirle
            status = self._determine_health_status(venue_name, health_result, latency)
            
            # Sağlık durumunu güncelle
            if venue_name in self.health_statuses:
                current_status = self.health_statuses[venue_name]
                current_status.status = status
                current_status.latency = latency
                current_status.last_check = datetime.utcnow()
                current_status.total_checks += 1
                
                if health_result.get('status') == 'healthy':
                    current_status.successful_checks += 1
                    current_status.consecutive_failures = 0
                else:
                    current_status.consecutive_failures += 1
                    current_status.last_error = health_result.get('error', 'Bilinmeyen hata')
                    self.stats['total_errors'] += 1
                
                # Hata oranını güncelle
                current_status.error_rate = (
                    (current_status.total_checks - current_status.successful_checks) / 
                    current_status.total_checks * 100
                )
                
                # Uptime hesapla
                current_status.uptime = (
                    current_status.successful_checks / current_status.total_checks * 100
                )
                
            else:
                # Yeni sağlık durumu oluştur
                self.health_statuses[venue_name] = HealthStatus(
                    venue=venue_name,
                    status=status,
                    latency=latency,
                    error_rate=0.0,
                    uptime=100.0,
                    last_check=datetime.utcnow(),
                    consecutive_failures=0 if health_result.get('status') == 'healthy' else 1,
                    total_checks=1,
                    successful_checks=1 if health_result.get('status') == 'healthy' else 0,
                    last_error=health_result.get('error') if health_result.get('status') != 'healthy' else None
                )
            
            # İstatistikleri güncelle
            await self._update_health_stats()
            
            # Geçmişe ekle
            self._add_to_history(venue_name, status, latency)
            
        except Exception as e:
            self.logger.error(f"Venue sağlık kontrol hatası {venue_name}: {e}")
    
    def _determine_health_status(self, venue_name: str, health_result: Dict, latency: float) -> str:
        """Sağlık durumunu belirle"""
        if health_result.get('status') != 'healthy':
            return 'offline'
        
        current_status = self.health_statuses.get(venue_name)
        consecutive_failures = current_status.consecutive_failures if current_status else 0
        
        # Kritik eşikler
        if latency > 5000 or consecutive_failures >= 5:  # 5s gecikme veya 5+ ardışık hata
            return 'unhealthy'
        elif latency > self.latency_threshold or consecutive_failures >= 2:  # 1s gecikme veya 2+ ardışık hata
            return 'degraded'
        else:
            return 'healthy'
    
    async def _update_health_stats(self):
        """Sağlık istatistiklerini güncelle"""
        total_venues = len(self.health_statuses)
        if total_venues == 0:
            return
        
        stats = {
            'total_venues': total_venues,
            'healthy_venues': 0,
            'degraded_venues': 0,
            'unhealthy_venues': 0,
            'offline_venues': 0,
            'avg_latency': 0.0,
            'total_errors': self.stats['total_errors']
        }
        
        total_latency = 0.0
        valid_latency_count = 0
        
        for status in self.health_statuses.values():
            if status.status == 'healthy':
                stats['healthy_venues'] += 1
            elif status.status == 'degraded':
                stats['degraded_venues'] += 1
            elif status.status == 'unhealthy':
                stats['unhealthy_venues'] += 1
            elif status.status == 'offline':
                stats['offline_venues'] += 1
            
            # Ortalama latency hesaplama
            if status.latency < float('inf') and status.latency > 0:
                total_latency += status.latency
                valid_latency_count += 1
        
        if valid_latency_count > 0:
            stats['avg_latency'] = total_latency / valid_latency_count
        
        self.stats.update(stats)
    
    async def _process_alerts(self):
        """Alarmları işle"""
        for status in self.health_statuses.values():
            for rule in self.alert_rules:
                if rule.enabled and rule.condition(status):
                    await self._trigger_alert(rule, status)
    
    async def _trigger_alert(self, rule: AlertRule, status: HealthStatus):
        """Alarm tetikle"""
        now = datetime.utcnow()
        
        # Cooldown kontrolü
        if (rule.last_triggered and 
            now - rule.last_triggered < rule.cooldown_period):
            return
        
        # Alarm mesajı oluştur
        alert_data = {
            'timestamp': now,
            'venue': status.venue,
            'rule': rule.name,
            'severity': rule.severity,
            'status': status.status,
            'latency': status.latency,
            'error_rate': status.error_rate,
            'consecutive_failures': status.consecutive_failures,
            'message': rule.message_template.format(
                venue=status.venue,
                latency=status.latency,
                error_rate=status.error_rate,
                failures=status.consecutive_failures
            )
        }
        
        # Aktif alarmlara ekle
        self.active_alerts.append(alert_data)
        
        # Callback'leri çağır
        for callback in self.alert_callbacks:
            try:
                await callback(alert_data)
            except Exception as e:
                self.logger.error(f"Alarm callback hatası: {e}")
        
        # Son tetikleme zamanını güncelle
        rule.last_triggered = now
        
        self.logger.warning(f"Alarm tetiklendi: {alert_data['message']}")
    
    def _add_to_history(self, venue: str, status: str, latency: float):
        """Sağlık geçmişine ekle"""
        self.health_history.append({
            'timestamp': datetime.utcnow(),
            'venue': venue,
            'status': status,
            'latency': latency
        })
        
        # 24 saatlik geçmişi sakla
        cutoff_time = datetime.utcnow() - timedelta(hours=24)
        self.health_history = [
            entry for entry in self.health_history 
            if entry['timestamp'] > cutoff_time
        ]
        
        # Maksimum 1000 kayıt
        if len(self.health_history) > 1000:
            self.health_history = self.health_history[-1000:]
    
    async def _cleanup_old_data(self):
        """Eski verileri temizle"""
        # Aktif alarmlardan eski olanları temizle (5 dakikadan eski)
        cutoff_time = datetime.utcnow() - timedelta(minutes=5)
        self.active_alerts = [
            alert for alert in self.active_alerts
            if alert['timestamp'] > cutoff_time
        ]
    
    async def get_health_summary(self) -> Dict[str, Any]:
        """Sağlık özetini getir"""
        venue_health = {}
        for venue_name, status in self.health_statuses.items():
            venue_health[venue_name] = {
                'status': status.status,
                'latency': status.latency,
                'uptime': status.uptime,
                'error_rate': status.error_rate,
                'last_check': status.last_check,
                'consecutive_failures': status.consecutive_failures
            }
        
        return {
            'summary': self.stats.copy(),
            'venues': venue_health,
            'active_alerts': len(self.active_alerts),
            'alert_rules_count': len(self.alert_rules),
            'is_monitoring': self.is_monitoring
        }
    
    async def get_detailed_health_status(self, venue_name: str) -> Optional[Dict[str, Any]]:
        """Detaylı sağlık durumu"""
        if venue_name not in self.health_statuses:
            return None
        
        status = self.health_statuses[venue_name]
        
        # Son 1 saatlik geçmiş
        cutoff_time = datetime.utcnow() - timedelta(hours=1)
        recent_history = [
            entry for entry in self.health_history
            if entry['venue'] == venue_name and entry['timestamp'] > cutoff_time
        ]
        
        if recent_history:
            latencies = [entry['latency'] for entry in recent_history if entry['latency'] < float('inf')]
            if latencies:
                status.avg_latency_1hour = statistics.mean(latencies)
        
        return {
            'current_status': {
                'status': status.status,
                'latency': status.latency,
                'uptime': status.uptime,
                'error_rate': status.error_rate,
                'total_checks': status.total_checks,
                'successful_checks': status.successful_checks,
                'consecutive_failures': status.consecutive_failures,
                'last_error': status.last_error,
                'last_check': status.last_check
            },
            'performance_metrics': {
                'avg_latency_5min': status.avg_latency_5min,
                'avg_latency_1hour': status.avg_latency_1hour,
                'error_rate_5min': status.error_rate_5min,
                'throughput': status.throughput
            },
            'recent_history': recent_history[-50:]  # Son 50 kayıt
        }
    
    def add_alert_callback(self, callback: Callable):
        """Alarm callback'i ekle"""
        self.alert_callbacks.append(callback)
    
    def update_thresholds(self, new_thresholds: Dict[str, float]):
        """Eşik değerlerini güncelle"""
        if 'latency' in new_thresholds:
            self.latency_threshold = new_thresholds['latency']
        if 'error_rate' in new_thresholds:
            self.error_rate_threshold = new_thresholds['error_rate']
        if 'consecutive_failures' in new_thresholds:
            self.consecutive_failure_threshold = new_thresholds['consecutive_failures']
        if 'check_interval' in new_thresholds:
            self.check_interval = new_thresholds['check_interval']
        
        self.logger.info(f"Sağlık eşikleri güncellendi: {new_thresholds}")
    
    def get_health_history(self, hours: int = 24) -> List[Dict]:
        """Sağlık geçmişini getir"""
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        return [
            entry for entry in self.health_history
            if entry['timestamp'] > cutoff_time
        ]