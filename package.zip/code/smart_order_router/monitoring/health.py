"""
Venue Health Monitor - Borsa sağlık durumu izleme sistemi
"""

import asyncio
import logging
import time
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
import statistics

from ..exchanges.manager import ExchangeManager
from ..config import SORConfig

@dataclass
class HealthMetric:
    """Sağlık metriği veri yapısı"""
    timestamp: float
    status: str  # healthy, warning, unhealthy, error
    latency_ms: float
    success_rate: float
    error_count: int
    total_requests: int
    uptime_percentage: float
    throughput_rps: float
    error_rate: float

@dataclass
class VenueHealthStatus:
    """Venue sağlık durumu"""
    venue: str
    overall_status: str
    last_check: float
    uptime: float
    latency_avg: float
    success_rate: float
    total_errors: int
    recommendations: List[str]

class VenueHealthMonitor:
    """
    Venue Sağlık Monitörü
    Tüm borsaların sağlık durumunu sürekli izler
    """
    
    def __init__(self, exchange_manager: ExchangeManager, config: SORConfig):
        """Health monitor'ü başlat"""
        self.exchange_manager = exchange_manager
        self.config = config
        self.logger = logging.getLogger("HealthMonitor")
        
        # Sağlık geçmişi
        self.health_history: Dict[str, List[HealthMetric]] = {}
        
        # Performans metrikleri
        self.performance_metrics: Dict[str, Dict] = {}
        
        # Alert thresholds
        self.thresholds = {
            'latency_warning': 100,  # ms
            'latency_critical': 500,  # ms
            'success_rate_warning': 0.95,  # %95
            'success_rate_critical': 0.90,  # %90
            'error_rate_warning': 0.05,  # %5
            'error_rate_critical': 0.10,  # %10
            'uptime_warning': 99.0,  # %
            'throughput_critical': 1.0  # request per second
        }
        
        # Alert callbacks
        self.alert_callbacks = []
    
    async def check_all_venues(self):
        """Tüm venue'ları kontrol et"""
        venues = self.exchange_manager.get_exchanges()
        
        self.logger.debug(f"Venue sağlık kontrolü başlatılıyor: {len(venues)} venue")
        
        for venue in venues:
            try:
                await self.check_venue_health(venue)
            except Exception as e:
                self.logger.error(f"{venue} sağlık kontrol hatası: {e}")
        
        # Global sağlık durumunu raporla
        await self._report_global_health()
    
    async def check_venue_health(self, venue: str) -> VenueHealthStatus:
        """Belirli bir venue'ın sağlığını kontrol et"""
        start_time = time.time()
        
        try:
            # Temel bağlantı kontrolü
            is_connected = self.exchange_manager.is_connected(venue)
            
            # Performans testleri
            latency = await self._test_latency(venue)
            success_rate = await self._calculate_success_rate(venue)
            throughput = await self._calculate_throughput(venue)
            
            # Hata oranı hesapla
            error_rate = 1.0 - success_rate
            
            # Uptime hesapla
            uptime = await self._calculate_uptime(venue)
            
            # Genel durumu belirle
            overall_status = self._determine_overall_status(
                is_connected, latency, success_rate, error_rate, uptime
            )
            
            # Metriği kaydet
            metric = HealthMetric(
                timestamp=time.time(),
                status=overall_status,
                latency_ms=latency,
                success_rate=success_rate,
                error_count=int(throughput * error_rate),
                total_requests=int(throughput),
                uptime_percentage=uptime,
                throughput_rps=throughput,
                error_rate=error_rate
            )
            
            if venue not in self.health_history:
                self.health_history[venue] = []
            
            self.health_history[venue].append(metric)
            
            # Son 100 metriği tut
            if len(self.health_history[venue]) > 100:
                self.health_history[venue] = self.health_history[venue][-100:]
            
            # Öneriler oluştur
            recommendations = self._generate_recommendations(
                venue, overall_status, metric
            )
            
            health_status = VenueHealthStatus(
                venue=venue,
                overall_status=overall_status,
                last_check=time.time(),
                uptime=uptime,
                latency_avg=latency,
                success_rate=success_rate,
                total_errors=metric.error_count,
                recommendations=recommendations
            )
            
            # Alert kontrolü
            await self._check_alerts(venue, health_status)
            
            self.logger.debug(f"{venue} sağlık kontrolü tamamlandı: {overall_status}")
            return health_status
            
        except Exception as e:
            self.logger.error(f"{venue} sağlık kontrol hatası: {e}")
            
            return VenueHealthStatus(
                venue=venue,
                overall_status='error',
                last_check=time.time(),
                uptime=0,
                latency_avg=0,
                success_rate=0,
                total_errors=0,
                recommendations=[f"Venue bağlantı hatası: {str(e)}"]
            )
    
    async def _test_latency(self, venue: str) -> float:
        """Venue latency'sini test et"""
        try:
            start_time = time.time()
            
            # Basit API çağrısı yap
            await self.exchange_manager.get_balance(venue)
            
            latency = (time.time() - start_time) * 1000  # ms
            return latency
            
        except Exception as e:
            self.logger.debug(f"{venue} latency test hatası: {e}")
            return 999.0  # Yüksek latency değeri
    
    async def _calculate_success_rate(self, venue: str) -> float:
        """Son 24 saatlik başarı oranını hesapla"""
        try:
            # Son 24 saatlik metrikleri al
            cutoff_time = time.time() - 86400  # 24 saat önce
            
            if venue not in self.health_history:
                return 0.95  # Default değer
            
            recent_metrics = [
                metric for metric in self.health_history[venue]
                if metric.timestamp > cutoff_time
            ]
            
            if not recent_metrics:
                return 0.95
            
            # Başarı oranını hesapla
            total_requests = sum(metric.total_requests for metric in recent_metrics)
            total_errors = sum(metric.error_count for metric in recent_metrics)
            
            if total_requests == 0:
                return 0.95
            
            success_rate = (total_requests - total_errors) / total_requests
            return max(0, min(1, success_rate))
            
        except Exception as e:
            self.logger.error(f"{venue} başarı oranı hesaplama hatası: {e}")
            return 0.95
    
    async def _calculate_throughput(self, venue: str) -> float:
        """İstek/saniye throughput'unu hesapla"""
        try:
            # Son 1 dakikalık metrikleri al
            cutoff_time = time.time() - 60  # 1 dakika önce
            
            if venue not in self.health_history:
                return 10.0  # Default değer
            
            recent_metrics = [
                metric for metric in self.health_history[venue]
                if metric.timestamp > cutoff_time
            ]
            
            if not recent_metrics:
                return 10.0
            
            total_requests = sum(metric.total_requests for metric in recent_metrics)
            duration_minutes = len(recent_metrics) / 60.0  # Yaklaşık süre
            
            throughput = total_requests / max(duration_minutes, 1.0/60)
            return throughput
            
        except Exception as e:
            self.logger.error(f"{venue} throughput hesaplama hatası: {e}")
            return 10.0
    
    async def _calculate_uptime(self, venue: str) -> float:
        """Uptime yüzdesini hesapla"""
        try:
            # Son 24 saatlik veriler
            cutoff_time = time.time() - 86400  # 24 saat
            
            if venue not in self.health_history:
                return 100.0  # Default değer
            
            recent_metrics = [
                metric for metric in self.health_history[venue]
                if metric.timestamp > cutoff_time
            ]
            
            if not recent_metrics:
                return 100.0
            
            # Sağlıklı saatleri say
            healthy_time = sum(
                1 for metric in recent_metrics 
                if metric.status in ['healthy', 'warning']
            )
            
            uptime_percentage = (healthy_time / len(recent_metrics)) * 100
            return uptime_percentage
            
        except Exception as e:
            self.logger.error(f"{venue} uptime hesaplama hatası: {e}")
            return 100.0
    
    def _determine_overall_status(self, is_connected: bool, latency: float, 
                                success_rate: float, error_rate: float, 
                                uptime: float) -> str:
        """Genel sağlık durumunu belirle"""
        # Kritik durumlar
        if not is_connected:
            return 'unhealthy'
        
        if latency > self.thresholds['latency_critical']:
            return 'unhealthy'
        
        if success_rate < self.thresholds['success_rate_critical']:
            return 'unhealthy'
        
        if error_rate > self.thresholds['error_rate_critical']:
            return 'unhealthy'
        
        if uptime < 95.0:  # %95 altı kritik
            return 'unhealthy'
        
        # Warning durumlar
        if latency > self.thresholds['latency_warning']:
            return 'warning'
        
        if success_rate < self.thresholds['success_rate_warning']:
            return 'warning'
        
        if error_rate > self.thresholds['error_rate_warning']:
            return 'warning'
        
        if uptime < self.thresholds['uptime_warning']:
            return 'warning'
        
        # Sağlıklı
        return 'healthy'
    
    def _generate_recommendations(self, venue: str, status: str, metric: HealthMetric) -> List[str]:
        """Venue için iyileştirme önerileri oluştur"""
        recommendations = []
        
        if status == 'unhealthy':
            recommendations.append("Kritik durum: Venue derhal incelenmeli")
            
            if metric.latency_ms > self.thresholds['latency_critical']:
                recommendations.append("Yüksek latency: Network bağlantısı kontrol edilmeli")
            
            if metric.success_rate < self.thresholds['success_rate_critical']:
                recommendations.append("Düşük başarı oranı: API limitleri ve hata logları incelenmeli")
            
            if metric.error_rate > self.thresholds['error_rate_critical']:
                recommendations.append("Yüksek hata oranı: API durumu ve kimlik bilgileri kontrol edilmeli")
        
        elif status == 'warning':
            recommendations.append("Uyarı: Performans iyileştirme önerilir")
            
            if metric.latency_ms > self.thresholds['latency_warning']:
                recommendations.append("Latency optimizasyonu gerekli")
            
            if metric.success_rate < self.thresholds['success_rate_warning']:
                recommendations.append("Başarı oranı artırılmalı")
        
        else:  # healthy
            recommendations.append("Venue sağlıklı çalışıyor")
        
        return recommendations
    
    async def _check_alerts(self, venue: str, health_status: VenueHealthStatus):
        """Alert durumlarını kontrol et"""
        if health_status.overall_status in ['unhealthy', 'error']:
            await self._send_alert(f"CRITICAL: {venue} venue sağlık sorunu", health_status)
        elif health_status.overall_status == 'warning':
            await self._send_alert(f"WARNING: {venue} venue performans uyarısı", health_status)
    
    async def _send_alert(self, message: str, health_status: VenueHealthStatus):
        """Alert gönder"""
        self.logger.warning(f"ALERT: {message}")
        
        # Callback'leri çağır
        for callback in self.alert_callbacks:
            try:
                await callback(message, health_status)
            except Exception as e:
                self.logger.error(f"Alert callback hatası: {e}")
    
    async def _report_global_health(self):
        """Global sağlık durumunu raporla"""
        try:
            venues = self.exchange_manager.get_exchanges()
            
            healthy_count = 0
            warning_count = 0
            unhealthy_count = 0
            error_count = 0
            
            for venue in venues:
                if venue in self.health_history:
                    latest_metric = self.health_history[venue][-1]
                    status = latest_metric.status
                    
                    if status == 'healthy':
                        healthy_count += 1
                    elif status == 'warning':
                        warning_count += 1
                    elif status == 'unhealthy':
                        unhealthy_count += 1
                    else:
                        error_count += 1
            
            total_venues = len(venues)
            health_percentage = (healthy_count / total_venues) * 100 if total_venues > 0 else 0
            
            self.logger.info(f"""
            === Global Venue Sağlık Durumu ===
            Toplam Venue: {total_venues}
            Sağlıklı: {healthy_count}
            Uyarı: {warning_count}
            Sağlıksız: {unhealthy_count}
            Hata: {error_count}
            Sağlık Yüzdesi: {health_percentage:.1f}%
            =================================
            """)
            
        except Exception as e:
            self.logger.error(f"Global sağlık rapor hatası: {e}")
    
    async def get_health_status(self) -> Dict[str, VenueHealthStatus]:
        """Tüm venue'ların sağlık durumunu döndür"""
        health_statuses = {}
        
        for venue in self.exchange_manager.get_exchanges():
            try:
                health_statuses[venue] = await self.check_venue_health(venue)
            except Exception as e:
                self.logger.error(f"{venue} sağlık durumu alma hatası: {e}")
        
        return health_statuses
    
    async def get_venue_performance(self, venue: str) -> Dict[str, Any]:
        """Venue performans verilerini döndür"""
        if venue not in self.health_history:
            return {}
        
        metrics = self.health_history[venue]
        
        if not metrics:
            return {}
        
        # Son 100 metrikten istatistikler
        recent_metrics = metrics[-100:]
        
        latencies = [m.latency_ms for m in recent_metrics]
        success_rates = [m.success_rate for m in recent_metrics]
        
        performance = {
            'venue': venue,
            'total_metrics': len(metrics),
            'avg_latency': statistics.mean(latencies),
            'median_latency': statistics.median(latencies),
            'min_latency': min(latencies),
            'max_latency': max(latencies),
            'avg_success_rate': statistics.mean(success_rates),
            'latest_status': recent_metrics[-1].status,
            'latest_latency': recent_metrics[-1].latency_ms,
            'latest_success_rate': recent_metrics[-1].success_rate,
            'total_uptime_hours': len([m for m in recent_metrics if m.status in ['healthy', 'warning']]) / 3600,
            'trend': self._calculate_trend(latencies)
        }
        
        return performance
    
    def _calculate_trend(self, values: List[float]) -> str:
        """Trend analizi yapar"""
        if len(values) < 10:
            return 'insufficient_data'
        
        # Son 10 değer ile ilk 10 değeri karşılaştır
        recent_avg = statistics.mean(values[-10:])
        earlier_avg = statistics.mean(values[:10])
        
        change_percentage = ((recent_avg - earlier_avg) / earlier_avg) * 100
        
        if change_percentage > 10:
            return 'degrading'
        elif change_percentage < -10:
            return 'improving'
        else:
            return 'stable'
    
    def add_alert_callback(self, callback):
        """Alert callback ekle"""
        self.alert_callbacks.append(callback)
    
    def remove_alert_callback(self, callback):
        """Alert callback kaldır"""
        if callback in self.alert_callbacks:
            self.alert_callbacks.remove(callback)
    
    def get_health_summary(self) -> Dict[str, Any]:
        """Sağlık özetini döndür"""
        if not self.health_history:
            return {'status': 'no_data', 'venues': 0}
        
        summary = {
            'total_venues': len(self.health_history),
            'venues': {},
            'global_health_score': 0
        }
        
        total_score = 0
        venue_count = 0
        
        for venue, metrics in self.health_history.items():
            if metrics:
                latest = metrics[-1]
                venue_summary = {
                    'status': latest.status,
                    'latency_ms': latest.latency_ms,
                    'success_rate': latest.success_rate,
                    'uptime_percentage': latest.uptime_percentage,
                    'last_check': latest.timestamp
                }
                
                summary['venues'][venue] = venue_summary
                
                # Sağlık skoru hesapla
                if latest.status == 'healthy':
                    score = 100
                elif latest.status == 'warning':
                    score = 70
                else:
                    score = 30
                
                total_score += score
                venue_count += 1
        
        if venue_count > 0:
            summary['global_health_score'] = total_score / venue_count
        
        return summary