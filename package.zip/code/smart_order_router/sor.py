"""
Bitwisers 2.0 Smart Order Router Ana Sistemi
Çoklu borsa optimizasyonu ve akıllı order routing
"""

import asyncio
import logging
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, timedelta
import json
import time

from ccxt import Exchange
import pandas as pd

from .config import Config, SORConfig
from .exchanges.manager import ExchangeManager
from .routing.optimizer import OrderRouter
from .monitoring.health import VenueHealthMonitor
from .analytics.liquidity import LiquidityAnalyzer
from .analytics.arbitrage import ArbitrageDetector
from .utils.logger import setup_logger

class SmartOrderRouter:
    """
    Ana Smart Order Router Sınıfı
    Çoklu borsa optimizasyonu ve akıllı order routing
    """
    
    def __init__(self, config: SORConfig = None):
        """SOR sistemini başlat"""
        self.config = config or Config.get_sor_config()
        self.logger = setup_logger("SOR", self.config.log_level)
        
        # Bileşenler
        self.exchange_manager: Optional[ExchangeManager] = None
        self.order_router: Optional[OrderRouter] = None
        self.health_monitor: Optional[VenueHealthMonitor] = None
        self.liquidity_analyzer: Optional[LiquidityAnalyzer] = None
        self.arbitrage_detector: Optional[ArbitrageDetector] = None
        
        # Durum bilgileri
        self.is_running = False
        self.active_orders: Dict[str, Dict] = {}
        self.market_data: Dict[str, Dict] = {}
        self.venue_performance: Dict[str, Dict] = {}
        
        # İstatistikler
        self.stats = {
            'total_orders': 0,
            'successful_orders': 0,
            'failed_orders': 0,
            'total_volume': 0.0,
            'total_savings': 0.0,
            'start_time': None
        }
        
        self.logger.info("Smart Order Router sistemi başlatıldı")
    
    async def initialize(self) -> bool:
        """SOR sistemini başlat"""
        try:
            self.logger.info("SOR sistemi başlatılıyor...")
            
            # Borsa yöneticisini başlat
            self.exchange_manager = ExchangeManager(Config.get_enabled_exchanges())
            if not await self.exchange_manager.initialize():
                self.logger.error("Borsa yöneticisi başlatılamadı")
                return False
            
            # Order router'ı başlat
            self.order_router = OrderRouter(self.exchange_manager, self.config)
            
            # Sağlık monitörünü başlat
            self.health_monitor = VenueHealthMonitor(self.exchange_manager, self.config)
            
            # Likidite analizörünü başlat
            self.liquidity_analyzer = LiquidityAnalyzer(self.exchange_manager)
            
            # Arbitraj detektörünü başlat
            self.arbitrage_detector = ArbitrageDetector(self.exchange_manager)
            
            # Background taskları başlat
            await self._start_background_tasks()
            
            self.is_running = True
            self.stats['start_time'] = datetime.now()
            
            self.logger.info("SOR sistemi başarıyla başlatıldı")
            return True
            
        except Exception as e:
            self.logger.error(f"SOR sistemi başlatma hatası: {e}")
            return False
    
    async def _start_background_tasks(self):
        """Background taskları başlat"""
        tasks = [
            asyncio.create_task(self._market_data_loop()),
            asyncio.create_task(self._health_check_loop()),
            asyncio.create_task(self._arbitrage_detection_loop()),
            asyncio.create_task(self._performance_monitoring_loop())
        ]
        
        self.background_tasks = tasks
    
    async def _market_data_loop(self):
        """Market data güncelleme döngüsü"""
        while self.is_running:
            try:
                # Her desteklenen sembol için fiyat verilerini güncelle
                for symbol in Config.SUPPORTED_SYMBOLS:
                    await self._update_market_data(symbol)
                
                await asyncio.sleep(self.config.price_update_interval)
                
            except Exception as e:
                self.logger.error(f"Market data güncelleme hatası: {e}")
                await asyncio.sleep(5)
    
    async def _update_market_data(self, symbol: str):
        """Belirli bir sembol için market data güncelle"""
        try:
            # Tüm borsalardan order book verilerini al
            order_books = await self.exchange_manager.get_order_books(symbol)
            
            # En iyi fiyatları belirle
            best_bids = []
            best_asks = []
            
            for exchange, order_book in order_books.items():
                if order_book and 'bids' in order_book and 'asks' in order_book:
                    if order_book['bids']:
                        best_bids.append((exchange, float(order_book['bids'][0][0])))
                    if order_book['asks']:
                        best_asks.append((exchange, float(order_book['asks'][0][0])))
            
            # Market data'yı güncelle
            self.market_data[symbol] = {
                'timestamp': time.time(),
                'best_bid': max(best_bids, key=lambda x: x[1]) if best_bids else None,
                'best_ask': min(best_asks, key=lambda x: x[1]) if best_asks else None,
                'order_books': order_books
            }
            
        except Exception as e:
            self.logger.error(f"{symbol} market data güncelleme hatası: {e}")
    
    async def _health_check_loop(self):
        """Venue sağlık kontrol döngüsü"""
        while self.is_running:
            try:
                await self.health_monitor.check_all_venues()
                await asyncio.sleep(self.config.health_check_interval)
                
            except Exception as e:
                self.logger.error(f"Sağlık kontrol hatası: {e}")
                await asyncio.sleep(5)
    
    async def _arbitrage_detection_loop(self):
        """Arbitraj tespit döngüsü"""
        while self.is_running:
            try:
                arbitrage_ops = await self.arbitrage_detector.detect_opportunities()
                if arbitrage_ops:
                    self.logger.info(f"Arbitraj fırsatları tespit edildi: {len(arbitrage_ops)}")
                
                await asyncio.sleep(30)  # 30 saniyede bir kontrol
                
            except Exception as e:
                self.logger.error(f"Arbitraj tespit hatası: {e}")
                await asyncio.sleep(30)
    
    async def _performance_monitoring_loop(self):
        """Performans izleme döngüsü"""
        while self.is_running:
            try:
                # Venue performansını güncelle
                await self._update_venue_performance()
                
                # İstatistikleri logla
                await self._log_stats()
                
                await asyncio.sleep(60)  # Her dakika
                
            except Exception as e:
                self.logger.error(f"Performans izleme hatası: {e}")
                await asyncio.sleep(60)
    
    async def _update_venue_performance(self):
        """Venue performansını güncelle"""
        for exchange in self.exchange_manager.get_exchanges():
            try:
                performance = await self.health_monitor.get_venue_performance(exchange)
                self.venue_performance[exchange] = performance
                
            except Exception as e:
                self.logger.error(f"{exchange} performans güncelleme hatası: {e}")
    
    async def _log_stats(self):
        """İstatistikleri logla"""
        success_rate = (self.stats['successful_orders'] / max(self.stats['total_orders'], 1)) * 100
        
        self.logger.info(f"""
        === SOR Performans Raporu ===
        Toplam Emir: {self.stats['total_orders']}
        Başarılı Emir: {self.stats['successful_orders']} (%{success_rate:.2f})
        Başarısız Emir: {self.stats['failed_orders']}
        Toplam Hacim: {self.stats['total_volume']:.2f}
        Toplam Tasarruf: {self.stats['total_savings']:.4f}
        Çalışma Süresi: {datetime.now() - self.stats['start_time'] if self.stats['start_time'] else 'N/A'}
        =============================
        """)
    
    async def place_order(self, symbol: str, side: str, amount: float, 
                         order_type: str = 'market', price: float = None,
                         time_in_force: str = 'GTC') -> Dict[str, Any]:
        """
        Akıllı emir yerleştirme
        
        Args:
            symbol: Trading sembolü (örn: 'BTC/USDT')
            side: 'buy' veya 'sell'
            amount: Emir miktarı
            order_type: 'market', 'limit', 'stop'
            price: Limit/stop fiyat (eğer gerekliyse)
            time_in_force: 'GTC', 'IOC', 'FOK'
        
        Returns:
            Emir sonucu bilgisi
        """
        if not self.is_running:
            raise RuntimeError("SOR sistemi çalışmıyor")
        
        start_time = time.time()
        
        try:
            self.logger.info(f"Emir alındı: {side} {amount} {symbol}")
            
            # Order routing optimizasyonu
            routing_plan = await self.order_router.create_routing_plan(
                symbol, side, amount, order_type, price
            )
            
            if not routing_plan['venues']:
                raise ValueError("Uygun venue bulunamadı")
            
            # Emirleri venue'lara dağıt
            results = []
            total_filled = 0.0
            total_cost = 0.0
            
            for venue_info in routing_plan['venues']:
                venue_name = venue_info['exchange']
                venue_amount = venue_info['amount']
                
                if venue_amount <= 0:
                    continue
                
                # Venue'ya emir yerleştir
                result = await self.exchange_manager.place_order(
                    venue_name, symbol, side, venue_amount, order_type, price, time_in_force
                )
                
                results.append({
                    'venue': venue_name,
                    'result': result,
                    'amount': venue_amount
                })
                
                if result and result.get('filled'):
                    total_filled += float(result['filled'])
                    total_cost += float(result['filled']) * float(result.get('average', price or 0))
            
            # Başarılı emir sayısını güncelle
            self.stats['total_orders'] += 1
            if total_filled > 0:
                self.stats['successful_orders'] += 1
                self.stats['total_volume'] += total_filled
                self.stats['total_savings'] += routing_plan.get('expected_savings', 0)
            else:
                self.stats['failed_orders'] += 1
            
            execution_time = (time.time() - start_time) * 1000  # ms
            
            response = {
                'success': total_filled > 0,
                'order_id': f"SOR_{int(time.time())}",
                'symbol': symbol,
                'side': side,
                'amount_requested': amount,
                'amount_filled': total_filled,
                'execution_time_ms': execution_time,
                'routing_plan': routing_plan,
                'venue_results': results,
                'total_cost': total_cost,
                'expected_savings': routing_plan.get('expected_savings', 0)
            }
            
            self.logger.info(f"Emir tamamlandı: {total_filled}/{amount} {symbol} "
                           f"({execution_time:.2f}ms, tasarruf: {routing_plan.get('expected_savings', 0):.4f})")
            
            return response
            
        except Exception as e:
            self.stats['total_orders'] += 1
            self.stats['failed_orders'] += 1
            self.logger.error(f"Emir yerleştirme hatası: {e}")
            
            return {
                'success': False,
                'error': str(e),
                'execution_time_ms': (time.time() - start_time) * 1000
            }
    
    async def cancel_order(self, order_id: str, venue: str = None) -> bool:
        """Emir iptal et"""
        try:
            if venue:
                return await self.exchange_manager.cancel_order(venue, order_id)
            else:
                # Tüm venue'lardan iptal et
                results = []
                for exchange in self.exchange_manager.get_exchanges():
                    try:
                        result = await self.exchange_manager.cancel_order(exchange, order_id)
                        results.append(result)
                    except Exception as e:
                        self.logger.warning(f"{exchange} emir iptal hatası: {e}")
                
                return any(results)
                
        except Exception as e:
            self.logger.error(f"Emir iptal hatası: {e}")
            return False
    
    async def get_order_status(self, order_id: str, venue: str) -> Dict[str, Any]:
        """Emir durumunu sorgula"""
        return await self.exchange_manager.get_order_status(venue, order_id)
    
    async def get_market_data(self, symbol: str) -> Dict[str, Any]:
        """Market data'yı getir"""
        return self.market_data.get(symbol, {})
    
    async def get_venue_health(self) -> Dict[str, Any]:
        """Venue sağlık durumunu getir"""
        return await self.health_monitor.get_health_status()
    
    async def get_performance_stats(self) -> Dict[str, Any]:
        """Performans istatistiklerini getir"""
        runtime = datetime.now() - self.stats['start_time'] if self.stats['start_time'] else timedelta(0)
        
        return {
            **self.stats,
            'runtime_seconds': runtime.total_seconds(),
            'venue_performance': self.venue_performance,
            'active_markets': len(self.market_data),
            'uptime_percentage': 100.0
        }
    
    async def shutdown(self):
        """SOR sistemini kapat"""
        self.logger.info("SOR sistemi kapatılıyor...")
        
        self.is_running = False
        
        # Background taskları durdur
        if hasattr(self, 'background_tasks'):
            for task in self.background_tasks:
                task.cancel()
            
            await asyncio.gather(*self.background_tasks, return_exceptions=True)
        
        # Borsa bağlantılarını kapat
        if self.exchange_manager:
            await self.exchange_manager.shutdown()
        
        self.logger.info("SOR sistemi kapatıldı")

# Global SOR instance
_sor_instance: Optional[SmartOrderRouter] = None

async def get_sor_instance() -> SmartOrderRouter:
    """Global SOR instance'ı getir"""
    global _sor_instance
    
    if _sor_instance is None:
        _sor_instance = SmartOrderRouter()
        await _sor_instance.initialize()
    
    return _sor_instance

async def shutdown_sor():
    """SOR sistemini kapat"""
    global _sor_instance
    
    if _sor_instance:
        await _sor_instance.shutdown()
        _sor_instance = None