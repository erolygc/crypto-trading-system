"""
Bitwisers 2.0 Smart Order Router Konfigürasyonu
Çoklu borsa bağlantıları ve sistem parametreleri
"""

import os
from typing import Dict, Any
from dataclasses import dataclass

@dataclass
class ExchangeConfig:
    """Borsa konfigürasyonu"""
    name: str
    api_key: str
    api_secret: str
    sandbox: bool = True
    rate_limit: int = 100
    enable: bool = True
    priority: int = 1
    max_slippage: float = 0.005  # %0.5
    max_order_size: float = 1000000.0
    min_order_size: float = 10.0
    commission_rate: float = 0.001  # %0.1

@dataclass
class SORConfig:
    """Smart Order Router konfigürasyonu"""
    # Sistem geneli ayarlar
    max_concurrent_orders: int = 100
    order_split_min_size: float = 100.0
    order_split_max_venues: int = 5
    latency_threshold_ms: int = 100
    price_tolerance: float = 0.0001  # %0.01
    
    # Risk parametreleri
    max_position_size: float = 10000000.0
    max_drawdown: float = 0.05  # %5
    stop_loss_percentage: float = 0.02  # %2
    
    # Arbitraj parametreleri
    min_arbitrage_profit: float = 0.001  # %0.1
    arbitrage_timeout_seconds: int = 30
    
    # Monitoring
    health_check_interval: int = 10  # saniye
    price_update_interval: int = 1  # saniye
    log_level: str = "INFO"

class Config:
    """Ana konfigürasyon sınıfı"""
    
    # Borsa API anahtarları (environment variables'dan alınacak)
    EXCHANGES = {
        "binance": ExchangeConfig(
            name="binance",
            api_key=os.getenv("BINANCE_API_KEY", ""),
            api_secret=os.getenv("BINANCE_API_SECRET", ""),
            sandbox=os.getenv("BINANCE_SANDBOX", "true").lower() == "true",
            priority=1,
            commission_rate=0.001
        ),
        "bybit": ExchangeConfig(
            name="bybit",
            api_key=os.getenv("BYBIT_API_KEY", ""),
            api_secret=os.getenv("BYBIT_API_SECRET", ""),
            sandbox=os.getenv("BYBIT_SANDBOX", "true").lower() == "true",
            priority=2,
            commission_rate=0.001
        ),
        "kraken": ExchangeConfig(
            name="kraken",
            api_key=os.getenv("KRAKEN_API_KEY", ""),
            api_secret=os.getenv("KRAKEN_API_SECRET", ""),
            sandbox=False,  # Kraken'ın sandbox'ı yok
            priority=3,
            commission_rate=0.0026
        ),
        "okx": ExchangeConfig(
            name="okx",
            api_key=os.getenv("OKX_API_KEY", ""),
            api_secret=os.getenv("OKX_API_SECRET", ""),
            sandbox=os.getenv("OKX_SANDBOX", "true").lower() == "true",
            priority=4,
            commission_rate=0.001
        ),
        "coinbase": ExchangeConfig(
            name="coinbase",
            api_key=os.getenv("COINBASE_API_KEY", ""),
            api_secret=os.getenv("COINBASE_API_SECRET", ""),
            sandbox=os.getenv("COINBASE_SANDBOX", "true").lower() == "true",
            priority=5,
            commission_rate=0.005
        )
    }
    
    # Desteklenen semboller (çiftler)
    SUPPORTED_SYMBOLS = [
        "BTC/USDT", "ETH/USDT", "ADA/USDT", "DOT/USDT", "LINK/USDT",
        "XRP/USDT", "LTC/USDT", "BCH/USDT", "EOS/USDT", "TRX/USDT",
        "BTC/USD", "ETH/USD", "ADA/USD", "DOT/USD", "LINK/USD"
    ]
    
    # Log ayarları
    LOG_CONFIG = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "standard": {
                "format": "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
            },
        },
        "handlers": {
            "default": {
                "level": "INFO",
                "formatter": "standard",
                "class": "logging.StreamHandler",
            },
            "file": {
                "level": "DEBUG",
                "formatter": "standard",
                "class": "logging.FileHandler",
                "filename": "logs/sor_system.log",
                "mode": "a",
            },
        },
        "loggers": {
            "": {
                "handlers": ["default", "file"],
                "level": "DEBUG",
                "propagate": False
            }
        }
    }
    
    @classmethod
    def get_sor_config(cls) -> SORConfig:
        """SOR konfigürasyonunu döndür"""
        return SORConfig()
    
    @classmethod
    def get_enabled_exchanges(cls) -> Dict[str, ExchangeConfig]:
        """Aktif borsaları döndür"""
        return {name: config for name, config in cls.EXCHANGES.items() 
                if config.enable and config.api_key and config.api_secret}