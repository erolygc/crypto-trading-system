"""
Venue Manager - Borsa bağlantıları ve durum yönetimi
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import time
import statistics
import json

from exchange_adapters.base_adapter import BaseExchangeAdapter
from exchange_adapters.binance_adapter import BinanceAdapter
from exchange_adapters.bybit_adapter import BybitAdapter
from exchange_adapters.kraken_adapter import KrakenAdapter
from exchange_adapters.okx_adapter import OKXAdapter
from exchange_adapters.coinbase_adapter import CoinbaseAdapter

@dataclass
class VenueMetrics:
    """Venue performans metrikleri"""
    name: str
    latency: float = 0.0
    success_rate: float = 100.0
    total_orders: int = 0
    successful_orders: int = 0
    avg_spread: float = 0.0
    liquidity_score: float = 0.0
    commission_rate: float = 0.001
    last_updated: datetime = field(default_factory=datetime.utcnow)
    health_score: float = 100.0
    
    # Zaman serisi veriler
    latency_history: List[float] = field(default_factory=list)
    spread_history: List[float] = field(default_factory=list)
    order_history: List[Dict] = field(default_factory=list)

@dataclass
class VenueStatus:
    """Venue durumu"""
    name: str
    is_connected: bool = False
    is_healthy: bool = True
    last_heartbeat: Optional[datetime] = None
    error_count: int = 0
    consecutive_errors: int = 0
    last_error: Optional[str] = None
    uptime: float = 0.0

class VenueManager:
    """
    Çoklu borsa bağlantı ve durum yöneticisi
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        self.venues: Dict[str, BaseExchangeAdapter] = {}
        self.venue_metrics: Dict[str, VenueMetrics] = {}
        self.venue_status: Dict[str, VenueStatus] = {}
        
        # Adaptör fabrikası
        self.adapter_factory = {
            'binance': BinanceAdapter,
            'bybit': BybitAdapter,
            'kraken': KrakenAdapter,
            'okx': OKXAdapter,
            'coinbase': CoinbaseAdapter
        }
        
        # İstatistikler
        self.total_data_points = 0
        self.price_feeds_count = 0
        
    async def initialize(self):
        """Tüm borsa bağlantılarını başlat"""
        self.logger.info("Venue Manager başlatılıyor...")
        
        venue_configs = self.config.get('venues', {})
        
        for venue_name, venue_config in venue_configs.items():
            try:
                await self._initialize_venue(venue_name, venue_config)
                self.logger.info(f"Venue başarıyla başlatıldı: {venue_name}")
            except Exception as e:
                self.logger.error(f"Venue başlatma hatası {venue_name}: {e}")
                continue
        
        self.logger.info(f"Toplam {len(self.venues)} venue başlatıldı")
    
    async def _initialize_venue(self, venue_name: str, venue_config: Dict[str, Any]):
        """Tek bir venue başlat"""
        # Adaptör oluştur
        adapter_class = self.adapter_factory.get(venue_name.lower())
        if not adapter_class:
            raise ValueError(f"Desteklenmeyen venue: {venue_name}")
        
        adapter = adapter_class(venue_config)
        await adapter.connect()
        
        # Durumları kaydet
        self.venues[venue_name] = adapter
        self.venue_metrics[venue_name] = VenueMetrics(name=venue_name)
        self.venue_status[venue_name] = VenueStatus(name=venue_name)
        
        # Performans metriklerini güncelle
        await self._update_venue_metrics(venue_name)
    
    async def get_ticker(self, venue_name: str, symbol: str) -> Dict[str, Any]:
        """Ticker verisi al"""
        if venue_name not in self.venues:
            raise ValueError(f"Bilinmeyen venue: {venue_name}")
        
        venue = self.venues[venue_name]
        start_time = time.time()
        
        try:
            ticker = await venue.get_ticker(symbol)
            latency = (time.time() - start_time) * 1000  # ms
            
            # Latency metriklerini güncelle
            metrics = self.venue_metrics[venue_name]
            metrics.latency_history.append(latency)
            metrics.latency = statistics.mean(metrics.latency_history[-10:])  # Son 10 veri
            
            # Başarı metriklerini güncelle
            metrics.successful_orders += 1
            metrics.total_orders += 1
            metrics.success_rate = (metrics.successful_orders / metrics.total_orders) * 100
            
            # Spread metriklerini güncelle
            if 'bid' in ticker and 'ask' in ticker:
                spread = (ticker['ask'] - ticker['bid']) / ticker['bid']
                metrics.spread_history.append(spread)
                metrics.avg_spread = statistics.mean(metrics.spread_history[-20:])
            
            return ticker
            
        except Exception as e:
            # Hata metriklerini güncelle
            self._update_error_metrics(venue_name, str(e))
            raise
    
    async def get_order_book(self, venue_name: str, symbol: str, depth: int = 20) -> Dict[str, Any]:
        """Order book verisi al"""
        if venue_name not in self.venues:
            raise ValueError(f"Bilinmeyen venue: {venue_name}")
        
        venue = self.venues[venue_name]
        start_time = time.time()
        
        try:
            order_book = await venue.get_order_book(symbol, depth)
            latency = (time.time() - start_time) * 1000
            
            # Metrikleri güncelle
            metrics = self.venue_metrics[venue_name]
            metrics.latency_history.append(latency)
            metrics.latency = statistics.mean(metrics.latency_history[-10:])
            
            return order_book
            
        except Exception as e:
            self._update_error_metrics(venue_name, str(e))
            raise
    
    async def submit_order(self, venue_name: str, symbol: str, side: str, 
                          amount: float, order_type: str, price: Optional[float] = None) -> Dict[str, Any]:
        """Sipariş gönder"""
        if venue_name not in self.venues:
            raise ValueError(f"Bilinmeyen venue: {venue_name}")
        
        venue = self.venues[venue_name]
        start_time = time.time()
        
        try:
            order_result = await venue.submit_order(symbol, side, amount, order_type, price)
            execution_time = (time.time() - start_time) * 1000
            
            # Başarı metriklerini güncelle
            metrics = self.venue_metrics[venue_name]
            metrics.total_orders += 1
            
            if order_result.get('success', False):
                metrics.successful_orders += 1
                self._update_health_score(venue_name, True)
            else:
                self._update_error_metrics(venue_name, order_result.get('error', 'Unknown error'))
            
            metrics.success_rate = (metrics.successful_orders / metrics.total_orders) * 100
            
            # Yürütme geçmişini kaydet
            order_record = {
                'timestamp': datetime.utcnow(),
                'symbol': symbol,
                'side': side,
                'amount': amount,
                'order_type': order_type,
                'success': order_result.get('success', False),
                'execution_time': execution_time,
                'error': order_result.get('error')
            }
            metrics.order_history.append(order_record)
            
            # Son 50 kaydı sakla
            if len(metrics.order_history) > 50:
                metrics.order_history = metrics.order_history[-50:]
            
            return order_result
            
        except Exception as e:
            self._update_error_metrics(venue_name, str(e))
            raise
    
    def _update_error_metrics(self, venue_name: str, error: str):
        """Hata metriklerini güncelle"""
        if venue_name in self.venue_status:
            status = self.venue_status[venue_name]
            status.error_count += 1
            status.consecutive_errors += 1
            status.last_error = error
            
            # Sağlık skorunu düşür
            if venue_name in self.venue_metrics:
                metrics = self.venue_metrics[venue_name]
                metrics.health_score = max(0, metrics.health_score - 10)
    
    def _update_health_score(self, venue_name: str, success: bool):
        """Sağlık skorunu güncelle"""
        if venue_name in self.venue_metrics:
            metrics = self.venue_metrics[venue_name]
            if success:
                metrics.health_score = min(100, metrics.health_score + 5)
            else:
                metrics.health_score = max(0, metrics.health_score - 20)
    
    async def _update_venue_metrics(self, venue_name: str):
        """Venue metriklerini güncelle"""
        if venue_name in self.venues:
            venue = self.venues[venue_name]
            metrics = self.venue_metrics[venue_name]
            
            # Commission rate'i adaptörden al
            metrics.commission_rate = venue.commission_rate
            
            # Latency testi yap
            try:
                latency_test_start = time.time()
                await venue.get_server_time()
                latency = (time.time() - latency_test_start) * 1000
                metrics.latency = latency
                metrics.latency_history.append(latency)
                
            except Exception as e:
                self.logger.warning(f"Latency test hatası {venue_name}: {e}")
    
    def get_best_venue_by_criteria(self, criteria: Dict[str, Any]) -> Optional[str]:
        """Kriterlere göre en iyi venue'yu bul"""
        venue_scores = {}
        
        for venue_name, metrics in self.venue_metrics.items():
            status = self.venue_status.get(venue_name)
            
            # Sağlık kontrolü
            if not status or not status.is_healthy:
                continue
            
            score = 0
            
            # Latency skoru (düşük latency yüksek skor)
            if 'latency' in criteria:
                latency_weight = criteria['latency']['weight']
                max_latency = criteria['latency']['max']
                latency_score = max(0, 100 - (metrics.latency / max_latency * 100))
                score += latency_score * latency_weight
            
            # Spread skoru (düşük spread yüksek skor)
            if 'spread' in criteria:
                spread_weight = criteria['spread']['weight']
                max_spread = criteria['spread']['max']
                spread_score = max(0, 100 - (metrics.avg_spread / max_spread * 100))
                score += spread_score * spread_weight
            
            # Likidite skoru
            if 'liquidity' in criteria:
                liquidity_weight = criteria['liquidity']['weight']
                min_liquidity = criteria['liquidity']['min']
                liquidity_score = min(100, metrics.liquidity_score / min_liquidity * 100)
                score += liquidity_score * liquidity_weight
            
            # Başarı oranı skoru
            if 'success_rate' in criteria:
                success_weight = criteria['success_rate']['weight']
                success_score = metrics.success_rate
                score += success_score * success_weight
            
            venue_scores[venue_name] = score
        
        if not venue_scores:
            return None
        
        return max(venue_scores, key=venue_scores.get)
    
    def get_performance_metrics(self) -> Dict[str, Any]:
        """Tüm venue'ların performans metriklerini getir"""
        return {
            venue_name: {
                'metrics': {
                    'latency': metrics.latency,
                    'success_rate': metrics.success_rate,
                    'avg_spread': metrics.avg_spread,
                    'liquidity_score': metrics.liquidity_score,
                    'commission_rate': metrics.commission_rate,
                    'health_score': metrics.health_score
                },
                'status': {
                    'is_connected': status.is_connected,
                    'is_healthy': status.is_healthy,
                    'error_count': status.error_count,
                    'consecutive_errors': status.consecutive_errors
                }
            }
            for venue_name, (metrics, status) in zip(
                self.venue_metrics.keys(),
                zip(self.venue_metrics.values(), self.venue_status.values())
            )
        }
    
    async def health_check(self, venue_name: str) -> Dict[str, Any]:
        """Venue sağlık kontrolü"""
        if venue_name not in self.venues:
            return {'status': 'unknown', 'error': 'Venue bulunamadı'}
        
        try:
            venue = self.venues[venue_name]
            start_time = time.time()
            
            # Basit bağlantı testi
            await venue.get_server_time()
            latency = (time.time() - start_time) * 1000
            
            # Sağlık durumunu güncelle
            status = self.venue_status[venue_name]
            status.is_connected = True
            status.is_healthy = True
            status.last_heartbeat = datetime.utcnow()
            status.consecutive_errors = 0
            
            return {
                'status': 'healthy',
                'latency': latency,
                'timestamp': datetime.utcnow()
            }
            
        except Exception as e:
            # Sağlık durumunu güncelle
            status = self.venue_status[venue_name]
            status.is_connected = False
            status.is_healthy = False
            status.consecutive_errors += 1
            status.last_error = str(e)
            
            return {
                'status': 'unhealthy',
                'error': str(e),
                'timestamp': datetime.utcnow()
            }
    
    async def disconnect_all(self):
        """Tüm bağlantıları kapat"""
        self.logger.info("Tüm venue bağlantıları kapatılıyor...")
        
        for venue_name, venue in self.venues.items():
            try:
                await venue.disconnect()
                self.logger.info(f"Venue bağlantısı kapatıldı: {venue_name}")
            except Exception as e:
                self.logger.warning(f"Venue bağlantı kapatma hatası {venue_name}: {e}")
        
        self.venues.clear()
        self.logger.info("Tüm venue bağlantıları kapatıldı")