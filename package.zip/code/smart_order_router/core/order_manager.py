"""
Order Manager - Sipariş yönetimi ve yürütme
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import uuid
import json

from exchange_adapters.base_adapter import BaseExchangeAdapter

@dataclass
class Order:
    """Sipariş veri modeli"""
    order_id: str
    client_order_id: str
    venue: str
    symbol: str
    side: str
    amount: float
    order_type: str
    price: Optional[float] = None
    status: str = 'pending'  # pending, filled, partially_filled, cancelled, rejected
    filled_amount: float = 0.0
    remaining_amount: float = 0.0
    average_price: float = 0.0
    commission: float = 0.0
    created_at: datetime = field(default_factory=datetime.utcnow)
    updated_at: datetime = field(default_factory=datetime.utcnow)
    error_message: Optional[str] = None

@dataclass
class Fill:
    """Doldurma veri modeli"""
    order_id: str
    venue: str
    fill_id: str
    amount: float
    price: float
    commission: float
    timestamp: datetime = field(default_factory=datetime.utcnow)

class OrderManager:
    """
    Sipariş yönetim sistemi
    """
    
    def __init__(self, venue_manager):
        self.venue_manager = venue_manager
        self.logger = logging.getLogger(__name__)
        
        # Sipariş takibi
        self.active_orders: Dict[str, Order] = {}
        self.client_order_map: Dict[str, str] = {}  # client_order_id -> order_id
        self.order_fills: Dict[str, List[Fill]] = {}
        
        # İstatistikler
        self.stats = {
            'total_orders': 0,
            'filled_orders': 0,
            'partially_filled': 0,
            'cancelled_orders': 0,
            'rejected_orders': 0,
            'total_filled_volume': 0.0,
            'avg_fill_time': 0.0
        }
        
        # Sipariş güncelleme döngüsü
        self.update_task: Optional[asyncio.Task] = None
        self.is_monitoring = False
    
    async def start_monitoring(self):
        """Sipariş durumu izlemeyi başlat"""
        if not self.is_monitoring:
            self.is_monitoring = True
            self.update_task = asyncio.create_task(self._order_update_loop())
            self.logger.info("Order monitoring başlatıldı")
    
    async def stop_monitoring(self):
        """Sipariş durumu izlemeyi durdur"""
        self.is_monitoring = False
        if self.update_task:
            self.update_task.cancel()
            try:
                await self.update_task
            except asyncio.CancelledError:
                pass
        self.logger.info("Order monitoring durduruldu")
    
    async def submit_order(self, venue: BaseExchangeAdapter, symbol: str, side: str,
                          amount: float, order_type: str, price: Optional[float] = None,
                          client_order_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Borsada sipariş ver
        
        Args:
            venue: Borsa adaptörü
            symbol: Sembol
            side: Alış/satış (buy/sell)
            amount: Miktar
            order_type: Sipariş türü (market, limit, etc.)
            price: Fiyat (limit siparişler için)
            client_order_id: İstemci sipariş ID'si
            
        Returns:
            Sipariş sonucu
        """
        if not client_order_id:
            client_order_id = str(uuid.uuid4())
        
        venue_name = getattr(venue, 'name', 'unknown')
        
        try:
            # Borsada sipariş ver
            order_result = await venue.submit_order(symbol, side, amount, order_type, price)
            
            if order_result.get('success', False):
                # Siparişi aktif siparişlere ekle
                order = Order(
                    order_id=order_result['order_id'],
                    client_order_id=client_order_id,
                    venue=venue_name,
                    symbol=symbol,
                    side=side,
                    amount=amount,
                    order_type=order_type,
                    price=price,
                    status='pending'
                )
                
                order.remaining_amount = amount
                self.active_orders[order.order_id] = order
                self.client_order_map[client_order_id] = order.order_id
                self.order_fills[order.order_id] = []
                
                # İstatistikleri güncelle
                self.stats['total_orders'] += 1
                
                self.logger.info(
                    f"Sipariş verildi: {order.order_id} - {venue_name} - "
                    f"{amount} {symbol} @ {price or 'market'}"
                )
                
                return {
                    'success': True,
                    'order_id': order.order_id,
                    'client_order_id': client_order_id,
                    'venue': venue_name
                }
            else:
                error_msg = order_result.get('error', 'Bilinmeyen hata')
                self.logger.warning(f"Sipariş başarısız {venue_name}: {error_msg}")
                return {
                    'success': False,
                    'error': error_msg
                }
                
        except Exception as e:
            self.logger.error(f"Sipariş verme hatası {venue_name}: {e}")
            return {
                'success': False,
                'error': str(e)
            }
    
    async def cancel_order(self, order_id: str, venue: Optional[BaseExchangeAdapter] = None) -> Dict[str, Any]:
        """
        Sipariş iptal et
        
        Args:
            order_id: Sipariş ID'si
            venue: Borsa adaptörü (opsiyonel)
            
        Returns:
            İptal sonucu
        """
        if order_id not in self.active_orders:
            return {'success': False, 'error': 'Sipariş bulunamadı'}
        
        order = self.active_orders[order_id]
        venue_name = order.venue
        
        try:
            # Venue'u bul
            if not venue:
                venue = self.venue_manager.venues.get(venue_name)
            
            if not venue:
                return {'success': False, 'error': 'Venue bulunamadı'}
            
            # İptal işlemi
            cancel_result = await venue.cancel_order(order_id)
            
            if cancel_result.get('success', False):
                order.status = 'cancelled'
                order.updated_at = datetime.utcnow()
                
                # İstatistikleri güncelle
                self.stats['cancelled_orders'] += 1
                
                self.logger.info(f"Sipariş iptal edildi: {order_id}")
                
                return {'success': True}
            else:
                error_msg = cancel_result.get('error', 'İptal başarısız')
                return {'success': False, 'error': error_msg}
                
        except Exception as e:
            self.logger.error(f"Sipariş iptal hatası {order_id}: {e}")
            return {'success': False, 'error': str(e)}
    
    async def get_order_status(self, order_id: str) -> Optional[Dict[str, Any]]:
        """Sipariş durumunu getir"""
        if order_id not in self.active_orders:
            return None
        
        order = self.active_orders[order_id]
        return {
            'order_id': order.order_id,
            'client_order_id': order.client_order_id,
            'venue': order.venue,
            'symbol': order.symbol,
            'side': order.side,
            'amount': order.amount,
            'filled_amount': order.filled_amount,
            'remaining_amount': order.remaining_amount,
            'status': order.status,
            'average_price': order.average_price,
            'commission': order.commission,
            'created_at': order.created_at,
            'updated_at': order.updated_at,
            'error_message': order.error_message
        }
    
    async def _order_update_loop(self):
        """Sipariş durumu güncelleme döngüsü"""
        while self.is_monitoring:
            try:
                await self._update_all_orders()
                await asyncio.sleep(1)  # 1 saniye bekle
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"Order update loop hatası: {e}")
                await asyncio.sleep(5)  # Hata durumunda daha uzun bekle
    
    async def _update_all_orders(self):
        """Tüm aktif siparişleri güncelle"""
        if not self.active_orders:
            return
        
        # Venue'lara göre grupla
        venue_orders = {}
        for order_id, order in self.active_orders.items():
            if order.status in ['pending', 'partially_filled']:
                venue_name = order.venue
                if venue_name not in venue_orders:
                    venue_orders[venue_name] = []
                venue_orders[venue_name].append(order)
        
        # Her venue için sipariş durumlarını güncelle
        for venue_name, orders in venue_orders.items():
            try:
                venue = self.venue_manager.venues.get(venue_name)
                if venue:
                    await self._update_venue_orders(venue, orders)
            except Exception as e:
                self.logger.warning(f"Venue sipariş güncelleme hatası {venue_name}: {e}")
    
    async def _update_venue_orders(self, venue: BaseExchangeAdapter, orders: List[Order]):
        """Belirli bir venue'daki siparişleri güncelle"""
        for order in orders:
            try:
                # Sipariş durumunu kontrol et
                order_status = await venue.get_order_status(order.order_id)
                
                if order_status:
                    await self._update_order_from_status(order, order_status)
                    
            except Exception as e:
                self.logger.warning(f"Sipariş durum güncelleme hatası {order.order_id}: {e}")
    
    async def _update_order_from_status(self, order: Order, status_data: Dict[str, Any]):
        """Status verisinden siparişi güncelle"""
        status = status_data.get('status', '')
        
        # Durum güncellemeleri
        if status == 'filled':
            order.status = 'filled'
            order.filled_amount = status_data.get('filled', order.amount)
            order.remaining_amount = 0.0
            self.stats['filled_orders'] += 1
            self.stats['total_filled_volume'] += order.filled_amount
            
        elif status == 'partially_filled':
            order.status = 'partially_filled'
            order.filled_amount = status_data.get('filled', 0.0)
            order.remaining_amount = order.amount - order.filled_amount
            self.stats['partially_filled'] += 1
            
        elif status == 'cancelled':
            order.status = 'cancelled'
            self.stats['cancelled_orders'] += 1
            
        elif status == 'rejected':
            order.status = 'rejected'
            order.error_message = status_data.get('error', 'Reddedildi')
            self.stats['rejected_orders'] += 1
        
        # Ortalama fiyat ve komisyon güncellemeleri
        if 'average_price' in status_data:
            order.average_price = status_data['average_price']
        
        if 'commission' in status_data:
            order.commission = status_data['commission']
        
        # Doldurma kayıtları
        if 'fills' in status_data:
            for fill_data in status_data['fills']:
                fill = Fill(
                    order_id=order.order_id,
                    venue=order.venue,
                    fill_id=fill_data.get('fill_id', ''),
                    amount=fill_data.get('amount', 0.0),
                    price=fill_data.get('price', 0.0),
                    commission=fill_data.get('commission', 0.0)
                )
                self.order_fills[order.order_id].append(fill)
        
        order.updated_at = datetime.utcnow()
        
        # Tamamlanmış siparişleri aktif listeden çıkar
        if order.status in ['filled', 'cancelled', 'rejected']:
            if order.order_id in self.active_orders:
                del self.active_orders[order.order_id]
            if order.client_order_id in self.client_order_map:
                del self.client_order_map[order.client_order_id]
            
            self.logger.debug(f"Sipariş tamamlandı: {order.order_id} - {order.status}")
    
    async def batch_submit_orders(self, orders: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Toplu sipariş gönderimi"""
        results = []
        
        for order_data in orders:
            try:
                venue_name = order_data['venue']
                venue = self.venue_manager.venues.get(venue_name)
                
                if venue:
                    result = await self.submit_order(
                        venue=venue,
                        symbol=order_data['symbol'],
                        side=order_data['side'],
                        amount=order_data['amount'],
                        order_type=order_data.get('order_type', 'market'),
                        price=order_data.get('price'),
                        client_order_id=order_data.get('client_order_id')
                    )
                    results.append(result)
                else:
                    results.append({
                        'success': False,
                        'error': f'Venue bulunamadı: {venue_name}'
                    })
                    
            except Exception as e:
                results.append({
                    'success': False,
                    'error': str(e)
                })
        
        return results
    
    def get_order_stats(self) -> Dict[str, Any]:
        """Sipariş istatistiklerini getir"""
        total_orders = self.stats['total_orders']
        if total_orders > 0:
            self.stats['fill_rate'] = (self.stats['filled_orders'] / total_orders) * 100
            self.stats['partial_fill_rate'] = (self.stats['partially_filled'] / total_orders) * 100
        else:
            self.stats['fill_rate'] = 0.0
            self.stats['partial_fill_rate'] = 0.0
        
        return self.stats.copy()
    
    def get_active_orders(self) -> List[Dict[str, Any]]:
        """Aktif siparişleri getir"""
        return [
            {
                'order_id': order.order_id,
                'client_order_id': order.client_order_id,
                'venue': order.venue,
                'symbol': order.symbol,
                'side': order.side,
                'amount': order.amount,
                'filled_amount': order.filled_amount,
                'remaining_amount': order.remaining_amount,
                'status': order.status,
                'created_at': order.created_at
            }
            for order in self.active_orders.values()
        ]