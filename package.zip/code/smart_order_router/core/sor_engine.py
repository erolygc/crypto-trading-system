"""
Smart Order Router Ana Motoru
Çoklu borsa optimizasyonu ve akıllı sipariş yönlendirme
"""

import asyncio
import logging
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import time
import uuid

from .venue_manager import VenueManager
from .order_manager import OrderManager
from ..algorithms.route_optimizer import RouteOptimizer
from ..algorithms.arbitrage_detector import ArbitrageDetector
from ..algorithms.commission_calculator import CommissionCalculator
from ..monitoring.health_monitor import HealthMonitor

@dataclass
class OrderRequest:
    """Sipariş isteği veri modeli"""
    symbol: str
    side: str  # 'buy' or 'sell'
    amount: float
    order_type: str = 'market'  # market, limit, stop, etc.
    price: Optional[float] = None
    time_in_force: str = 'GTC'
    client_order_id: Optional[str] = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: datetime = field(default_factory=datetime.utcnow)
    
    # Optimization parameters
    max_slippage: float = 0.001  # 0.1%
    max_spread: float = 0.005    # 0.5%
    min_liquidity: float = 1000.0
    preferred_venues: List[str] = field(default_factory=list)
    excluded_venues: List[str] = field(default_factory=list)

@dataclass
class ExecutionResult:
    """Yürütme sonucu veri modeli"""
    order_id: str
    symbol: str
    side: str
    filled_amount: float
    average_price: float
    total_cost: float
    commissions: Dict[str, float]
    execution_time: float
    venues_used: List[str]
    timestamp: datetime = field(default_factory=datetime.utcnow)

class SmartOrderRouter:
    """
    Ana Smart Order Router motoru
    Çoklu borsa optimizasyonu ve akıllı sipariş yönlendirme
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Core bileşenler
        self.venue_manager = VenueManager(config.get('venues', {}))
        self.order_manager = OrderManager(self.venue_manager)
        self.route_optimizer = RouteOptimizer(self.venue_manager)
        self.arbitrage_detector = ArbitrageDetector(self.venue_manager)
        self.commission_calculator = CommissionCalculator()
        self.health_monitor = HealthMonitor(self.venue_manager)
        
        # Durum
        self.is_running = False
        self.active_orders: Dict[str, OrderRequest] = {}
        self.execution_history: List[ExecutionResult] = []
        
        # İstatistikler
        self.stats = {
            'total_orders': 0,
            'successful_orders': 0,
            'failed_orders': 0,
            'total_savings': 0.0,
            'avg_execution_time': 0.0,
            'best_price_hits': 0
        }
        
    async def initialize(self):
        """SOR sistemini başlat"""
        try:
            self.logger.info("SOR sistemi başlatılıyor...")
            
            # Borsaları bağla
            await self.venue_manager.initialize()
            
            # Sağlık izleme başlat
            await self.health_monitor.start_monitoring()
            
            self.is_running = True
            self.logger.info("SOR sistemi başarıyla başlatıldı")
            
        except Exception as e:
            self.logger.error(f"SOR sistemi başlatma hatası: {e}")
            raise
    
    async def execute_order(self, order_request: OrderRequest) -> ExecutionResult:
        """
        Siparişi optimize ederek yürüt
        
        Args:
            order_request: Sipariş isteği
            
        Returns:
            ExecutionResult: Yürütme sonucu
        """
        start_time = time.time()
        self.stats['total_orders'] += 1
        
        try:
            # 1. Fiyat keşfi ve likidite analizi
            price_data = await self._discover_best_prices(order_request.symbol)
            
            # 2. Arbitraj kontrolü
            arbitrage_opportunities = await self.arbitrage_detector.detect_arbitrage(
                order_request.symbol, price_data
            )
            
            # 3. Route optimizasyonu
            optimal_routes = await self.route_optimizer.optimize_routes(
                order_request, price_data, arbitrage_opportunities
            )
            
            # 4. Sipariş yürütme
            execution_result = await self._execute_routes(
                order_request, optimal_routes, price_data
            )
            
            # 5. Komisyon hesaplama
            execution_result.commissions = await self.commission_calculator.calculate_commissions(
                execution_result.venues_used, execution_result.total_cost
            )
            
            execution_result.execution_time = time.time() - start_time
            
            # İstatistikleri güncelle
            self._update_stats(execution_result, arbitrage_opportunities)
            
            self.logger.info(
                f"Sipariş yürütüldü: {execution_result.order_id} - "
                f"Toplam: {execution_result.filled_amount} @ {execution_result.average_price:.4f}"
            )
            
            return execution_result
            
        except Exception as e:
            self.stats['failed_orders'] += 1
            self.logger.error(f"Sipariş yürütme hatası: {e}")
            raise
    
    async def _discover_best_prices(self, symbol: str) -> Dict[str, Any]:
        """En iyi fiyatları keşfet"""
        price_data = {
            'symbol': symbol,
            'venues': {},
            'best_ask': float('inf'),
            'best_bid': 0.0,
            'venue_scores': {},
            'order_book_depth': {}
        }
        
        # Tüm borsalardan fiyat verilerini topla
        for venue_name, venue in self.venue_manager.venues.items():
            try:
                if venue.is_healthy and venue.is_connected:
                    ticker = await venue.get_ticker(symbol)
                    order_book = await venue.get_order_book(symbol, depth=20)
                    
                    venue_data = {
                        'bid': ticker['bid'],
                        'ask': ticker['ask'],
                        'last': ticker['last'],
                        'volume': ticker['volume'],
                        'spread': ticker['ask'] - ticker['bid'],
                        'mid_price': (ticker['bid'] + ticker['ask']) / 2,
                        'order_book': order_book,
                        'latency': venue.get_latency(),
                        'commission_rate': venue.commission_rate
                    }
                    
                    price_data['venues'][venue_name] = venue_data
                    
                    # En iyi fiyatları güncelle
                    price_data['best_ask'] = min(price_data['best_ask'], ticker['ask'])
                    price_data['best_bid'] = max(price_data['best_bid'], ticker['bid'])
                    
                    # Derinlik analizi
                    price_data['order_book_depth'][venue_name] = self._analyze_order_book_depth(
                        order_book, symbol
                    )
                    
            except Exception as e:
                self.logger.warning(f"Fiyat verisi alınamadı {venue_name}: {e}")
                continue
        
        return price_data
    
    def _analyze_order_book_depth(self, order_book: Dict, symbol: str) -> Dict[str, float]:
        """Order book derinlik analizi"""
        depth_analysis = {
            'bid_depth': 0.0,
            'ask_depth': 0.0,
            'liquidity_score': 0.0,
            'market_impact_score': 0.0
        }
        
        try:
            # Bid derinlik
            if 'bids' in order_book:
                for price, amount in order_book['bids'][:10]:
                    depth_analysis['bid_depth'] += float(price) * float(amount)
            
            # Ask derinlik  
            if 'asks' in order_book:
                for price, amount in order_book['asks'][:10]:
                    depth_analysis['ask_depth'] += float(price) * float(amount)
            
            # Likidite skoru
            depth_analysis['liquidity_score'] = min(
                depth_analysis['bid_depth'], depth_analysis['ask_depth']
            )
            
            # Market etki skoru (spread + derinlik oranı)
            if len(order_book.get('bids', [])) > 0 and len(order_book.get('asks', [])) > 0:
                best_bid = float(order_book['bids'][0][0])
                best_ask = float(order_book['asks'][0][0])
                spread = (best_ask - best_bid) / best_bid
                depth_analysis['market_impact_score'] = spread / (depth_analysis['liquidity_score'] + 1)
            
        except Exception as e:
            self.logger.warning(f"Order book analiz hatası: {e}")
        
        return depth_analysis
    
    async def _execute_routes(self, order_request: OrderRequest, 
                            routes: List[Dict], price_data: Dict) -> ExecutionResult:
        """Route'ları yürüt"""
        filled_amount = 0.0
        total_cost = 0.0
        venues_used = []
        order_fills = []
        
        for route in routes:
            venue_name = route['venue']
            amount = route['amount']
            price = route['price']
            
            try:
                venue = self.venue_manager.venues[venue_name]
                fill = await self.order_manager.submit_order(
                    venue, order_request.symbol, order_request.side, 
                    amount, order_request.order_type, price
                )
                
                if fill['success']:
                    filled_amount += fill['filled']
                    total_cost += fill['cost']
                    venues_used.append(venue_name)
                    order_fills.append(fill)
                    
            except Exception as e:
                self.logger.warning(f"Route yürütme hatası {venue_name}: {e}")
                continue
        
        # Ortalama fiyat hesapla
        average_price = total_cost / filled_amount if filled_amount > 0 else 0.0
        
        return ExecutionResult(
            order_id=order_request.client_order_id,
            symbol=order_request.symbol,
            side=order_request.side,
            filled_amount=filled_amount,
            average_price=average_price,
            total_cost=total_cost,
            commissions={},  # Daha sonra hesaplanacak
            execution_time=0.0,  # Daha sonra ayarlanacak
            venues_used=venues_used
        )
    
    def _update_stats(self, result: ExecutionResult, arbitrage_opps: List[Dict]):
        """İstatistikleri güncelle"""
        self.stats['successful_orders'] += 1
        
        if arbitrage_opps:
            self.stats['best_price_hits'] += 1
        
        # Ortalama yürütme süresi güncelle
        total_orders = self.stats['total_orders']
        current_avg = self.stats['avg_execution_time']
        self.stats['avg_execution_time'] = (
            (current_avg * (total_orders - 1) + result.execution_time) / total_orders
        )
    
    async def get_execution_stats(self) -> Dict[str, Any]:
        """Yürütme istatistiklerini getir"""
        return {
            'stats': self.stats,
            'health_status': await self.health_monitor.get_health_summary(),
            'venue_performance': self.venue_manager.get_performance_metrics(),
            'recent_execution_history': self.execution_history[-10:] if self.execution_history else []
        }
    
    async def shutdown(self):
        """SOR sistemini kapat"""
        self.logger.info("SOR sistemi kapatılıyor...")
        
        self.is_running = False
        
        # Aktif siparişleri iptal et
        for order_id, order in self.active_orders.items():
            try:
                await self.order_manager.cancel_order(order.client_order_id)
            except Exception as e:
                self.logger.warning(f"Sipariş iptal hatası {order_id}: {e}")
        
        # Borsa bağlantılarını kapat
        await self.venue_manager.disconnect_all()
        
        # Sağlık izlemeyi durdur
        await self.health_monitor.stop_monitoring()
        
        self.logger.info("SOR sistemi başarıyla kapatıldı")