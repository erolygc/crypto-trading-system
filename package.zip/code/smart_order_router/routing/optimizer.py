"""
Order Router - Akıllı emir yönlendirme ve optimizasyon
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import statistics
import math

from ..config import SORConfig
from ..exchanges.manager import ExchangeManager

class OrderRouter:
    """
    Akıllı Order Router
    En iyi fiyat ve likidite için emirleri venue'lara dağıtır
    """
    
    def __init__(self, exchange_manager: ExchangeManager, config: SORConfig):
        """Order router'ı başlat"""
        self.exchange_manager = exchange_manager
        self.config = config
        self.logger = logging.getLogger("OrderRouter")
        
        # Routing algoritmaları
        self.routing_strategies = {
            'price_priority': self._price_priority_routing,
            'liquidity_priority': self._liquidity_priority_routing,
            'latency_priority': self._latency_priority_routing,
            'cost_optimized': self._cost_optimized_routing,
            'smart_split': self._smart_split_routing
        }
        
        # Venue performans geçmişi
        self.venue_performance_history = {}
    
    async def create_routing_plan(self, symbol: str, side: str, amount: float,
                                 order_type: str = 'market', price: float = None,
                                 strategy: str = 'smart_split') -> Dict[str, Any]:
        """
        Order routing planı oluştur
        
        Args:
            symbol: Trading sembolü
            side: 'buy' veya 'sell'
            amount: Toplam emir miktarı
            order_type: 'market' veya 'limit'
            price: Limit fiyatı (eğer gerekliyse)
            strategy: Routing stratejisi
        
        Returns:
            Routing plan bilgisi
        """
        try:
            self.logger.info(f"Routing planı oluşturuluyor: {side} {amount} {symbol} "
                           f"({strategy} stratejisi)")
            
            # Market verilerini al
            market_data = await self._get_market_data_for_routing(symbol)
            
            if not market_data:
                raise ValueError("Market verisi alınamadı")
            
            # Uygun venue'ları filtrele
            eligible_venues = self._filter_eligible_venues(market_data, side, amount)
            
            if not eligible_venues:
                raise ValueError("Uygun venue bulunamadı")
            
            # Routing stratejisini uygula
            routing_func = self.routing_strategies.get(strategy, self._smart_split_routing)
            routing_plan = await routing_func(symbol, side, amount, market_data, eligible_venues)
            
            # Planı optimize et
            optimized_plan = await self._optimize_routing_plan(routing_plan, symbol, side)
            
            # Expected savings hesapla
            expected_savings = await self._calculate_expected_savings(
                optimized_plan, market_data
            )
            
            response = {
                'strategy': strategy,
                'venues': optimized_plan,
                'total_amount': amount,
                'expected_savings': expected_savings,
                'timestamp': datetime.now().isoformat(),
                'eligible_venues_count': len(eligible_venues),
                'routing_complexity': len(optimized_plan)
            }
            
            self.logger.info(f"Routing planı oluşturuldu: {len(optimized_plan)} venue, "
                           f"expected savings: {expected_savings:.6f}")
            
            return response
            
        except Exception as e:
            self.logger.error(f"Routing plan oluşturma hatası: {e}")
            raise
    
    async def _get_market_data_for_routing(self, symbol: str) -> Dict[str, Any]:
        """Routing için market verilerini topla"""
        market_data = {
            'order_books': await self.exchange_manager.get_order_books(symbol),
            'tickers': await self.exchange_manager.get_tickers(symbol),
            'timestamp': datetime.now().timestamp()
        }
        
        # Her venue için likidite analizi yap
        for venue, order_book in market_data['order_books'].items():
            if order_book:
                market_data[f'liquidity_{venue}'] = self._analyze_liquidity(order_book)
        
        return market_data
    
    def _analyze_liquidity(self, order_book: Dict) -> Dict[str, float]:
        """Order book likiditesini analiz et"""
        if not order_book or 'bids' not in order_book or 'asks' not in order_book:
            return {'depth_1': 0, 'depth_5': 0, 'depth_10': 0, 'spread': 0}
        
        bids = order_book['bids'][:10]  # İlk 10 seviye
        asks = order_book['asks'][:10]
        
        # Depth hesaplamaları
        depth_1 = float(bids[0][1]) if bids else 0  # İlk seviye miktarı
        depth_5 = sum(float(bid[1]) for bid in bids[:5]) if len(bids) >= 5 else 0
        depth_10 = sum(float(bid[1]) for bid in bids) if bids else 0
        
        # Spread hesaplama
        spread = 0
        if bids and asks:
            best_bid = float(bids[0][0])
            best_ask = float(asks[0][0])
            spread = (best_ask - best_bid) / best_bid if best_bid > 0 else 0
        
        return {
            'depth_1': depth_1,
            'depth_5': depth_5,
            'depth_10': depth_10,
            'spread': spread
        }
    
    def _filter_eligible_venues(self, market_data: Dict, side: str, amount: float) -> List[Dict]:
        """Uygun venue'ları filtrele"""
        eligible = []
        
        for venue in self.exchange_manager.get_exchanges():
            if not self.exchange_manager.is_connected(venue):
                continue
            
            venue_info = {
                'venue': venue,
                'latency': self.exchange_manager.get_latency(venue),
                'order_book': market_data['order_books'].get(venue),
                'ticker': market_data['tickers'].get(venue),
                'liquidity': market_data.get(f'liquidity_{venue}', {}),
                'performance': self.venue_performance_history.get(venue, {})
            }
            
            # Likidite kontrolü
            if venue_info['liquidity'] and venue_info['order_book']:
                depth = venue_info['liquidity']['depth_10']
                if depth < amount * 0.1:  # En az %10 likidite
                    continue
            
            # Latency kontrolü
            if venue_info['latency'] > self.config.latency_threshold_ms:
                continue
            
            # Spread kontrolü
            spread = venue_info['liquidity'].get('spread', 0)
            if spread > self.config.price_tolerance:
                continue
            
            eligible.append(venue_info)
        
        return eligible
    
    async def _price_priority_routing(self, symbol: str, side: str, amount: float,
                                    market_data: Dict, eligible_venues: List[Dict]) -> List[Dict]:
        """Fiyat öncelikli routing"""
        venues_with_prices = []
        
        for venue_info in eligible_venues:
            if venue_info['order_book']:
                order_book = venue_info['order_book']
                
                if side == 'buy' and 'asks' in order_book and order_book['asks']:
                    price = float(order_book['asks'][0][0])
                    venues_with_prices.append((venue_info, price))
                elif side == 'sell' and 'bids' in order_book and order_book['bids']:
                    price = float(order_book['bids'][0][0])
                    venues_with_prices.append((venue_info, price))
        
        # Fiyata göre sırala
        if side == 'buy':
            venues_with_prices.sort(key=lambda x: x[1])  # En düşük fiyattan başla
        else:
            venues_with_prices.sort(key=lambda x: x[1], reverse=True)  # En yüksek fiyattan başla
        
        # Venue'lara miktar dağıt
        return self._distribute_amount(venues_with_prices, amount)
    
    async def _liquidity_priority_routing(self, symbol: str, side: str, amount: float,
                                        market_data: Dict, eligible_venues: List[Dict]) -> List[Dict]:
        """Likidite öncelikli routing"""
        venues_with_liquidity = []
        
        for venue_info in eligible_venues:
            liquidity = venue_info['liquidity']
            if liquidity:
                # Likidite skoru hesapla (derinlik + spread penalizasyonu)
                depth_score = liquidity['depth_10']
                spread_penalty = liquidity['spread'] * 1000  # Spread'i cezalandır
                liquidity_score = depth_score / (1 + spread_penalty)
                venues_with_liquidity.append((venue_info, liquidity_score))
        
        # Likidite skoruna göre sırala
        venues_with_liquidity.sort(key=lambda x: x[1], reverse=True)
        
        return self._distribute_amount(venues_with_liquidity, amount)
    
    async def _latency_priority_routing(self, symbol: str, side: str, amount: float,
                                      market_data: Dict, eligible_venues: List[Dict]) -> List[Dict]:
        """Latency öncelikli routing"""
        venues_with_latency = []
        
        for venue_info in eligible_venues:
            latency = venue_info['latency']
            venues_with_latency.append((venue_info, latency))
        
        # Latency'ye göre sırala (düşükten yükseğe)
        venues_with_latency.sort(key=lambda x: x[1])
        
        return self._distribute_amount(venues_with_latency, amount)
    
    async def _cost_optimized_routing(self, symbol: str, side: str, amount: float,
                                    market_data: Dict, eligible_venues: List[Dict]) -> List[Dict]:
        """Maliyet optimize edilmiş routing"""
        venues_with_cost = []
        
        for venue_info in eligible_venues:
            # Toplam maliyeti hesapla (fiyat + komisyon + slippage)
            total_cost = 0
            
            if venue_info['order_book'] and venue_info['ticker']:
                order_book = venue_info['order_book']
                ticker = venue_info['ticker']
                
                if side == 'buy' and 'asks' in order_book and order_book['asks']:
                    price = float(order_book['asks'][0][0])
                    spread = venue_info['liquidity'].get('spread', 0)
                    # Komisyon + spread + slippage
                    commission = price * 0.001  # %0.1 komisyon
                    slippage = price * spread
                    total_cost = price + commission + slippage
                    
                elif side == 'sell' and 'bids' in order_book and order_book['bids']:
                    price = float(order_book['bids'][0][0])
                    spread = venue_info['liquidity'].get('spread', 0)
                    # Komisyon + spread + slippage
                    commission = price * 0.001
                    slippage = price * spread
                    total_cost = price - commission - slippage
                    total_cost = -total_cost  # Negatif çünkü satış
                
                venues_with_cost.append((venue_info, total_cost))
        
        # Maliyete göre sırala
        if side == 'buy':
            venues_with_cost.sort(key=lambda x: x[1])  # En düşük maliyet
        else:
            venues_with_cost.sort(key=lambda x: x[1])  # En yüksek net fiyat
        
        return self._distribute_amount(venues_with_cost, amount)
    
    async def _smart_split_routing(self, symbol: str, side: str, amount: float,
                                 market_data: Dict, eligible_venues: List[Dict]) -> List[Dict]:
        """Akıllı split routing"""
        # Tüm faktörleri birleştirerek skor hesapla
        venues_with_score = []
        
        for venue_info in eligible_venues:
            score = self._calculate_venue_score(venue_info)
            venues_with_score.append((venue_info, score))
        
        # Skora göre sırala
        venues_with_score.sort(key=lambda x: x[1], reverse=True)
        
        # Miktar dağıtımı yap
        routing_plan = self._distribute_amount(venues_with_score, amount)
        
        # Her venue için optimal miktarı hesapla
        for venue_plan in routing_plan:
            venue_name = venue_plan['venue']
            venue_info = next(v for v in eligible_venues if v['venue'] == venue_name)
            
            # Likiditeye göre miktar ayarla
            optimal_amount = self._calculate_optimal_amount(
                venue_info, venue_plan['amount'], side
            )
            venue_plan['amount'] = optimal_amount
        
        return routing_plan
    
    def _calculate_venue_score(self, venue_info: Dict) -> float:
        """Venue için kapsamlı skor hesapla"""
        score = 0.0
        
        # Likidite skoru (0-40 puan)
        liquidity = venue_info['liquidity']
        if liquidity:
            depth_score = min(liquidity['depth_10'] / 1000, 40)  # Maksimum 40 puan
            spread_score = max(40 - liquidity['spread'] * 400, 0)  # Spread cezası
            score += (depth_score + spread_score) / 2
        
        # Latency skoru (0-30 puan)
        latency = venue_info['latency']
        latency_score = max(30 - latency / 10, 0)  # Düşük latency bonus
        score += latency_score
        
        # Performans skoru (0-30 puan)
        performance = venue_info['performance']
        if performance:
            success_rate = performance.get('success_rate', 0.5)
            avg_execution_time = performance.get('avg_execution_time', 100)
            perf_score = success_rate * 20 + (100 - min(avg_execution_time, 100)) * 0.1
            score += perf_score
        
        return score
    
    def _distribute_amount(self, venues_with_scores: List[Tuple[Dict, float]], 
                          total_amount: float) -> List[Dict]:
        """Miktarı venue'lara dağıt"""
        if not venues_with_scores:
            return []
        
        # Maksimum venue sayısını kontrol et
        max_venues = min(len(venues_with_scores), self.config.order_split_max_venues)
        venues_with_scores = venues_with_scores[:max_venues]
        
        # Skorları topla
        total_score = sum(score for _, score in venues_with_scores)
        
        if total_score == 0:
            # Eşit dağıtım
            equal_amount = total_amount / len(venues_with_scores)
            return [{
                'venue': venue_info['venue'],
                'exchange': venue_info['venue'],
                'amount': equal_amount,
                'score': score
            } for venue_info, score in venues_with_scores]
        
        # Skor oranında dağıtım
        routing_plan = []
        remaining_amount = total_amount
        
        for i, (venue_info, score) in enumerate(venues_with_scores):
            if i == len(venues_with_scores) - 1:
                # Son venue, kalan miktarı alır
                amount = remaining_amount
            else:
                # Skor oranında miktar
                amount = (total_amount * score / total_score)
                remaining_amount -= amount
            
            routing_plan.append({
                'venue': venue_info['venue'],
                'exchange': venue_info['venue'],
                'amount': amount,
                'score': score
            })
        
        return routing_plan
    
    def _calculate_optimal_amount(self, venue_info: Dict, requested_amount: float, side: str) -> float:
        """Venue için optimal miktarı hesapla"""
        liquidity = venue_info['liquidity']
        order_book = venue_info['order_book']
        
        if not liquidity or not order_book:
            return requested_amount
        
        # Likidite sınırlarını kontrol et
        max_affordable = liquidity['depth_1'] * 0.8  # %80'i kullan
        optimal_amount = min(requested_amount, max_affordable)
        
        # Minimum miktar kontrolü
        if optimal_amount < self.config.order_split_min_size:
            return 0.0
        
        return optimal_amount
    
    async def _optimize_routing_plan(self, routing_plan: List[Dict], symbol: str, side: str) -> List[Dict]:
        """Routing planını optimize et"""
        # Çok küçük emirleri birleştir
        consolidated_plan = []
        small_orders = []
        
        for venue_plan in routing_plan:
            if venue_plan['amount'] < self.config.order_split_min_size:
                small_orders.append(venue_plan)
            else:
                consolidated_plan.append(venue_plan)
        
        # Küçük emirleri en iyi venue'a birleştir
        if small_orders and consolidated_plan:
            total_small_amount = sum(order['amount'] for order in small_orders)
            best_venue = max(consolidated_plan, key=lambda x: x['score'])
            best_venue['amount'] += total_small_amount
        
        return consolidated_plan
    
    async def _calculate_expected_savings(self, routing_plan: List[Dict], market_data: Dict) -> float:
        """Beklenen tasarrufu hesapla"""
        total_expected_cost = 0
        
        for venue_plan in routing_plan:
            venue_name = venue_plan['venue']
            amount = venue_plan['amount']
            
            order_book = market_data['order_books'].get(venue_name)
            if order_book and (order_book.get('bids') or order_book.get('asks')):
                if venue_plan.get('side', '').lower() == 'buy' and order_book.get('asks'):
                    expected_price = float(order_book['asks'][0][0])
                elif order_book.get('bids'):
                    expected_price = float(order_book['bids'][0][0])
                else:
                    expected_price = 0
                
                venue_cost = amount * expected_price
                total_expected_cost += venue_cost
        
        # Naive single venue cost ile karşılaştır
        # (Bu basit bir hesaplama, gerçek uygulamada daha detaylı olmalı)
        baseline_cost = sum(venue['amount'] for venue in routing_plan) * 0.001  # Basit baseline
        
        return max(0, baseline_cost - total_expected_cost * 0.001)  # %0.1 tasarruf varsayımı
    
    def update_venue_performance(self, venue: str, success: bool, execution_time: float, 
                               volume: float):
        """Venue performansını güncelle"""
        if venue not in self.venue_performance_history:
            self.venue_performance_history[venue] = {
                'success_count': 0,
                'failure_count': 0,
                'total_execution_time': 0,
                'total_volume': 0,
                'success_rate': 0,
                'avg_execution_time': 0
            }
        
        perf = self.venue_performance_history[venue]
        
        if success:
            perf['success_count'] += 1
        else:
            perf['failure_count'] += 1
        
        perf['total_execution_time'] += execution_time
        perf['total_volume'] += volume
        
        # Ortalama değerleri güncelle
        total_attempts = perf['success_count'] + perf['failure_count']
        if total_attempts > 0:
            perf['success_rate'] = perf['success_count'] / total_attempts
        
        if total_attempts > 0:
            perf['avg_execution_time'] = perf['total_execution_time'] / total_attempts