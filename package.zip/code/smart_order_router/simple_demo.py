"""
Simple Smart Order Router Demo
Bitwisers 2.0 SOR Sistemi Temel Demo
"""

import asyncio
import logging
import json
from datetime import datetime
from pathlib import Path

# Simple demo without complex imports
def setup_simple_logger():
    """Basit logging setup"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('logs/sor_demo.log')
        ]
    )
    return logging.getLogger("SOR_Demo")

def simulate_price_data():
    """Simulated price data for demo"""
    import random
    random.seed(42)  # Deterministic
    
    return {
        'BTC/USDT': {
            'venues': {
                'binance': {'bid': 50000, 'ask': 50100, 'volume': 1000000, 'latency': 85},
                'bybit': {'bid': 49950, 'ask': 50050, 'volume': 800000, 'latency': 120},
                'kraken': {'bid': 50020, 'ask': 50150, 'volume': 500000, 'latency': 110}
            }
        },
        'ETH/USDT': {
            'venues': {
                'binance': {'bid': 3000, 'ask': 3005, 'volume': 2000000, 'latency': 90},
                'bybit': {'bid': 2995, 'ask': 3010, 'volume': 1500000, 'latency': 115},
                'kraken': {'bid': 3002, 'ask': 3008, 'volume': 800000, 'latency': 105}
            }
        }
    }

def calculate_spread(bid, ask):
    """Calculate spread percentage"""
    return (ask - bid) / bid

def find_best_prices(price_data, symbol):
    """Find best bid/ask across venues"""
    venues = price_data[symbol]['venues']
    
    best_bid = max(v['bid'] for v in venues.values())
    best_ask = min(v['ask'] for v in venues.values())
    
    return best_bid, best_ask

def detect_arbitrage(price_data, symbol):
    """Simple arbitrage detection"""
    venues = price_data[symbol]['venues']
    venue_names = list(venues.keys())
    opportunities = []
    
    for i, buy_venue in enumerate(venue_names):
        for sell_venue in venue_names[i+1:]:
            buy_data = venues[buy_venue]
            sell_data = venues[sell_venue]
            
            # Buy low, sell high
            spread = (sell_data['bid'] - buy_data['ask']) / buy_data['ask']
            if spread > 0.001:  # 0.1% minimum spread
                opportunities.append({
                    'buy_venue': buy_venue,
                    'sell_venue': sell_venue,
                    'buy_price': buy_data['ask'],
                    'sell_price': sell_data['bid'],
                    'spread': spread,
                    'potential_profit': spread * 10000  # Assuming $10k trade
                })
    
    return opportunities

def calculate_commission_rates():
    """Commission rates by venue"""
    return {
        'binance': {'rate': 0.001, 'level': 'VIP1'},
        'bybit': {'rate': 0.001, 'level': 'Regular'},
        'kraken': {'rate': 0.0026, 'level': 'Regular'},
        'okx': {'rate': 0.0008, 'level': 'VIP2'},
        'coinbase': {'rate': 0.005, 'level': 'Regular'}
    }

def health_status_simulation():
    """Simulate venue health status"""
    import random
    random.seed(123)
    
    venues = ['binance', 'bybit', 'kraken', 'okx', 'coinbase']
    health_data = {}
    
    for venue in venues:
        latency = random.uniform(50, 300)
        uptime = random.uniform(95, 100)
        error_rate = max(0, random.uniform(0, 5))
        
        if latency > 200 or error_rate > 2:
            status = 'degraded' if latency < 500 else 'unhealthy'
        else:
            status = 'healthy'
            
        health_data[venue] = {
            'status': status,
            'latency': round(latency, 1),
            'uptime': round(uptime, 1),
            'error_rate': round(error_rate, 2)
        }
    
    return health_data

async def run_sor_demo():
    """Main demo function"""
    logger = setup_simple_logger()
    
    print("🚀 Smart Order Router Demo - Bitwisers 2.0")
    print("=" * 60)
    
    # Create logs directory
    Path("logs").mkdir(exist_ok=True)
    
    logger.info("=== Smart Order Router Demo Başlatılıyor ===")
    
    # 1. Price Discovery Demo
    print("\n🔍 === Fiyat Keşfi Demo'su ===")
    price_data = simulate_price_data()
    
    for symbol in price_data:
        print(f"\n📊 {symbol} fiyatları:")
        venues = price_data[symbol]['venues']
        
        for venue, data in venues.items():
            spread_pct = calculate_spread(data['bid'], data['ask']) * 100
            print(f"  {venue.upper()}: Bid ${data['bid']:,} | Ask ${data['ask']:,} | "
                  f"Spread {spread_pct:.3f}% | Volume {data['volume']:,}")
        
        best_bid, best_ask = find_best_prices(price_data, symbol)
        print(f"  🏆 En iyi: Bid ${best_bid:,} | Ask ${best_ask:,}")
    
    # 2. Arbitrage Detection Demo
    print("\n💰 === Arbitraj Tespiti Demo'su ===")
    for symbol in price_data:
        opportunities = detect_arbitrage(price_data, symbol)
        print(f"\n🔍 {symbol} için arbitraj fırsatları:")
        
        if opportunities:
            for i, opp in enumerate(opportunities, 1):
                spread_pct = opp['spread'] * 100
                print(f"  {i}. {opp['buy_venue'].upper()} → {opp['sell_venue'].upper()}: "
                      f"Spread {spread_pct:.3f}% | Kar ${opp['potential_profit']:.2f}")
        else:
            print("  ❌ Şu anda arbitraj fırsatı bulunmuyor")
    
    # 3. Commission Analysis
    print("\n💳 === Komisyon Analizi Demo'su ===")
    commission_rates = calculate_commission_rates()
    order_value = 10000  # $10,000
    
    print(f"Test işlem değeri: ${order_value:,}")
    print("\n📊 Venue komisyon karşılaştırması:")
    
    for venue, data in commission_rates.items():
        commission = order_value * data['rate']
        print(f"  {venue.upper()}: %{data['rate']*100:.3f} = ${commission:.2f} ({data['level']})")
    
    best_venue = min(commission_rates.items(), key=lambda x: x[1]['rate'])
    worst_venue = max(commission_rates.items(), key=lambda x: x[1]['rate'])
    saving = order_value * (worst_venue[1]['rate'] - best_venue[1]['rate'])
    
    print(f"\n🏆 En düşük komisyon: {best_venue[0].upper()} (${order_value * best_venue[1]['rate']:.2f})")
    print(f"💰 Potansiyel tasarruf: ${saving:.2f}")
    
    # 4. Health Monitoring
    print("\n🏥 === Sağlık İzleme Demo'su ===")
    health_data = health_status_simulation()
    
    print("📊 Venue sağlık durumu:")
    status_emojis = {'healthy': '🟢', 'degraded': '🟡', 'unhealthy': '🔴'}
    
    for venue, status in health_data.items():
        emoji = status_emojis.get(status['status'], '❓')
        print(f"  {emoji} {venue.upper()}: {status['status'].upper()} | "
              f"Latency: {status['latency']}ms | Uptime: {status['uptime']}%")
    
    healthy_count = sum(1 for s in health_data.values() if s['status'] == 'healthy')
    print(f"\n📈 Özet: {healthy_count}/{len(health_data)} venue sağlıklı")
    
    # 5. Route Optimization Demo
    print("\n🎯 === Route Optimizasyonu Demo'su ===")
    
    test_orders = [
        {'symbol': 'BTC/USDT', 'side': 'buy', 'amount': 0.1, 'priority': 'price'},
        {'symbol': 'ETH/USDT', 'side': 'sell', 'amount': 2.0, 'priority': 'speed'}
    ]
    
    for order in test_orders:
        print(f"\n📋 {order['side'].upper()} {order['amount']} {order['symbol']} (Öncelik: {order['priority']})")
        
        venues = price_data[order['symbol']]['venues']
        
        # Simple scoring based on spread, volume, and latency
        venue_scores = []
        for venue, data in venues.items():
            spread_score = 100 - (calculate_spread(data['bid'], data['ask']) * 10000)
            volume_score = min(data['volume'] / 100000, 100)  # Normalize volume
            latency_score = max(0, 150 - data['latency'])  # Lower latency = higher score
            
            total_score = (spread_score * 0.4 + volume_score * 0.3 + latency_score * 0.3)
            venue_scores.append((venue, total_score, data))
        
        # Sort by score
        venue_scores.sort(key=lambda x: x[1], reverse=True)
        
        print("  📊 Venue skorları:")
        for venue, score, data in venue_scores:
            print(f"    {venue.upper()}: {score:.1f} (Spread: {calculate_spread(data['bid'], data['ask'])*100:.3f}%)")
        
        # Optimal allocation
        allocation = {}
        remaining = order['amount']
        for i, (venue, score, data) in enumerate(venue_scores):
            if remaining <= 0:
                break
            
            # Allocate based on score
            if i == 0:  # Best venue gets 60%
                alloc = min(remaining, order['amount'] * 0.6)
            elif i == 1:  # Second best gets 40%
                alloc = min(remaining, order['amount'] * 0.4)
            else:
                alloc = 0
            
            allocation[venue] = alloc
            remaining -= alloc
        
        print("  💡 Optimal allocation:")
        for venue, amount in allocation.items():
            if amount > 0:
                print(f"    {venue.upper()}: {amount:.4f} ({amount/order['amount']*100:.1f}%)")
    
    # 6. Performance Summary
    print("\n📊 === Demo Performans Özeti ===")
    total_venues = len(health_data)
    healthy_venues = sum(1 for s in health_data.values() if s['status'] == 'healthy')
    avg_latency = sum(s['latency'] for s in health_data.values()) / total_venues
    
    print(f"✅ Toplam venue sayısı: {total_venues}")
    print(f"🟢 Sağlıklı venue sayısı: {healthy_venues} (%{healthy_venues/total_venues*100:.1f})")
    print(f"⏱️  Ortalama latency: {avg_latency:.1f}ms")
    print(f"💰 Maksimum komisyon tasarrufu: ${saving:.2f}")
    
    # Save demo report
    demo_report = {
        'timestamp': datetime.utcnow().isoformat(),
        'system': 'Smart Order Router v2.0 Demo',
        'venues_tested': list(health_data.keys()),
        'symbols_analyzed': list(price_data.keys()),
        'arbitrage_opportunities': sum(len(detect_arbitrage(price_data, symbol)) for symbol in price_data),
        'commission_savings': saving,
        'healthy_venues_ratio': healthy_venues / total_venues,
        'avg_latency': avg_latency,
        'status': 'completed'
    }
    
    with open('logs/demo_report.json', 'w') as f:
        json.dump(demo_report, f, indent=2)
    
    print("\n🎉 === Demo Tamamlandı ===")
    print("Smart Order Router sistemi başarıyla test edildi!")
    print(f"📄 Detaylı rapor: logs/demo_report.json")
    
    print("\n⚙️ === Konfigürasyon Önerileri ===")
    print("1. Gerçek API anahtarlarınızı ekleyin")
    print("2. Testnet modunu production için kapatın")
    print("3. Risk parametrelerini stratejinize göre ayarlayın")
    print("4. Monitoring eşiklerini optimize edin")
    
    return demo_report

if __name__ == '__main__':
    try:
        asyncio.run(run_sor_demo())
    except KeyboardInterrupt:
        print("\n⏹️ Demo kullanıcı tarafından durduruldu")
    except Exception as e:
        print(f"❌ Demo hatası: {e}")
    finally:
        print("👋 Demo tamamlandı!")