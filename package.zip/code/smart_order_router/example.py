"""
Bitwisers 2.0 Smart Order Router - Example/Demo Uygulaması
SOR sisteminin temel kullanımını gösterir
"""

import asyncio
import os
import logging
from typing import Dict, Any

# SOR modülünü import et
from smart_order_router import SmartOrderRouter, Config, get_sor_instance, shutdown_sor

class SORDemo:
    """SOR sistemi demo uygulaması"""
    
    def __init__(self):
        """Demo uygulamasını başlat"""
        self.logger = logging.getLogger("SORDemo")
        self.sor = None
        
    async def run_demo(self):
        """Ana demo fonksiyonu"""
        try:
            self.logger.info("=== Bitwisers 2.0 SOR Demo Başlıyor ===")
            
            # 1. SOR sistemini başlat
            await self._initialize_sor()
            
            # 2. Sistem durumunu kontrol et
            await self._check_system_health()
            
            # 3. Market data örneği
            await self._demonstrate_market_data()
            
            # 4. Order routing örneği
            await self._demonstrate_order_routing()
            
            # 5. Arbitraj tespit örneği
            await self._demonstrate_arbitrage_detection()
            
            # 6. Performance metrikleri
            await self._demonstrate_performance_monitoring()
            
            self.logger.info("=== Demo Tamamlandı ===")
            
        except Exception as e:
            self.logger.error(f"Demo hatası: {e}")
        finally:
            # Temizleme
            await self.cleanup()
    
    async def _initialize_sor(self):
        """SOR sistemini başlat"""
        self.logger.info("1. SOR sistemi başlatılıyor...")
        
        # Global instance al
        self.sor = await get_sor_instance()
        
        # Aktif borsaları listele
        enabled_exchanges = Config.get_enabled_exchanges()
        self.logger.info(f"Aktif borsalar: {list(enabled_exchanges.keys())}")
        
        # Eğer API anahtarları yoksa, mock mode'da çalış
        if not any(config.api_key for config in enabled_exchanges.values()):
            self.logger.warning("API anahtarları bulunamadı. Demo mode'da çalışılıyor.")
            self.demo_mode = True
        else:
            self.logger.info("API anahtarları bulundu. Canlı trading mode.")
            self.demo_mode = False
    
    async def _check_system_health(self):
        """Sistem sağlık durumunu kontrol et"""
        self.logger.info("2. Sistem sağlık kontrolü...")
        
        # Venue sağlık durumunu al
        health_data = await self.sor.get_venue_health()
        
        for venue, health in health_data.items():
            status = health.overall_status
            latency = health.latency_avg
            success_rate = health.success_rate
            
            self.logger.info(f"   {venue}: {status} (Latency: {latency:.1f}ms, Success: {success_rate:.1%})")
    
    async def _demonstrate_market_data(self):
        """Market data örneği"""
        self.logger.info("3. Market data analizi...")
        
        # BTC/USDT için market data al
        symbol = "BTC/USDT"
        
        try:
            if self.demo_mode:
                # Demo mode'da mock data
                self._show_mock_market_data(symbol)
            else:
                # Canlı data
                market_data = await self.sor.get_market_data(symbol)
                self._show_real_market_data(symbol, market_data)
                
        except Exception as e:
            self.logger.error(f"Market data hatası: {e}")
            # Fallback to mock data
            self._show_mock_market_data(symbol)
    
    def _show_mock_market_data(self, symbol: str):
        """Mock market data göster"""
        mock_data = {
            'timestamp': '2025-10-30 06:49:52',
            'best_bid': ('binance', 67000.50),
            'best_ask': ('bybit', 67005.20),
            'order_books': {
                'binance': {
                    'bids': [[67000.50, 2.5], [66999.00, 5.1], [66998.50, 3.2]],
                    'asks': [[67002.00, 1.8], [67003.50, 4.2], [67005.20, 2.1]]
                },
                'bybit': {
                    'bids': [[66999.00, 1.9], [66998.50, 3.5], [66998.00, 2.8]],
                    'asks': [[67005.20, 3.1], [67006.50, 1.7], [67008.00, 5.2]]
                }
            }
        }
        
        self._show_real_market_data(symbol, mock_data)
    
    def _show_real_market_data(self, symbol: str, market_data: Dict[str, Any]):
        """Gerçek market data göster"""
        if 'best_bid' in market_data and market_data['best_bid']:
            bid_venue, bid_price = market_data['best_bid']
            self.logger.info(f"   En İyi Bid: {bid_price:.2f} ({bid_venue})")
        
        if 'best_ask' in market_data and market_data['best_ask']:
            ask_venue, ask_price = market_data['best_ask']
            self.logger.info(f"   En İyi Ask: {ask_price:.2f} ({ask_venue})")
        
        # Spread hesapla
        if market_data.get('best_bid') and market_data.get('best_ask'):
            spread = market_data['best_ask'][1] - market_data['best_bid'][1]
            spread_pct = (spread / market_data['best_bid'][1]) * 100
            self.logger.info(f"   Spread: {spread:.2f} ({spread_pct:.3f}%)")
    
    async def _demonstrate_order_routing(self):
        """Order routing örneği"""
        self.logger.info("4. Order routing demonstrasyonu...")
        
        # Test emri
        symbol = "BTC/USDT"
        side = "buy"
        amount = 0.1  # 0.1 BTC
        
        try:
            if self.demo_mode:
                # Demo mode'da simulasyon
                await self._simulate_order_routing(symbol, side, amount)
            else:
                # Gerçek emir
                result = await self.sor.place_order(
                    symbol=symbol,
                    side=side,
                    amount=amount,
                    order_type="limit"
                )
                self._show_order_result(result)
                
        except Exception as e:
            self.logger.error(f"Order routing hatası: {e}")
    
    async def _simulate_order_routing(self, symbol: str, side: str, amount: float):
        """Simülasyon modunda order routing"""
        # Mock routing planı
        mock_plan = {
            'strategy': 'smart_split',
            'venues': [
                {'venue': 'binance', 'exchange': 'binance', 'amount': 0.06, 'score': 85.2},
                {'venue': 'bybit', 'exchange': 'bybit', 'amount': 0.04, 'score': 78.9}
            ],
            'total_amount': amount,
            'expected_savings': 15.50,
            'timestamp': '2025-10-30T06:49:52',
            'eligible_venues_count': 2,
            'routing_complexity': 2
        }
        
        self.logger.info(f"   Routing Stratejisi: {mock_plan['strategy']}")
        self.logger.info(f"   Venue Sayısı: {mock_plan['eligible_venues_count']}")
        
        for venue in mock_plan['venues']:
            self.logger.info(f"   {venue['venue']}: {venue['amount']:.4f} BTC (Skor: {venue['score']:.1f})")
        
        self.logger.info(f"   Beklenen Tasarruf: ${mock_plan['expected_savings']:.2f}")
        
        # Simulated result
        result = {
            'success': True,
            'order_id': f"SOR_demo_{int(asyncio.get_event_loop().time())}",
            'symbol': symbol,
            'side': side,
            'amount_requested': amount,
            'amount_filled': amount,
            'execution_time_ms': 250.5,
            'routing_plan': mock_plan,
            'venue_results': [
                {'venue': 'binance', 'result': {'id': '12345'}, 'amount': 0.06},
                {'venue': 'bybit', 'result': {'id': '67890'}, 'amount': 0.04}
            ],
            'total_cost': amount * 67002.75,
            'expected_savings': mock_plan['expected_savings']
        }
        
        self._show_order_result(result)
    
    def _show_order_result(self, result: Dict[str, Any]):
        """Order sonucunu göster"""
        if result['success']:
            self.logger.info(f"   ✅ Emir Başarılı!")
            self.logger.info(f"   Order ID: {result['order_id']}")
            self.logger.info(f"   Doldurulan: {result['amount_filled']:.6f} / {result['amount_requested']:.6f}")
            self.logger.info(f"   Execution Time: {result['execution_time_ms']:.1f}ms")
            self.logger.info(f"   Tasarruf: ${result['expected_savings']:.2f}")
            
            # Venue results
            for venue_result in result['venue_results']:
                venue = venue_result['venue']
                amount = venue_result['amount']
                self.logger.info(f"   {venue}: {amount:.6f} BTC")
        else:
            self.logger.error(f"   ❌ Emir Başarısız: {result.get('error', 'Bilinmeyen hata')}")
    
    async def _demonstrate_arbitrage_detection(self):
        """Arbitraj tespit örneği"""
        self.logger.info("5. Arbitraj tespit demonstrasyonu...")
        
        try:
            if self.demo_mode:
                # Demo mode'da mock arbitraj fırsatları
                await self._show_mock_arbitrage_opportunities()
            else:
                # Gerçek arbitraj tespiti
                # Bu fonksiyonu analytics.arbitrage modülünden çağırmalıyız
                self.logger.info("   Arbitraj analizi devre dışı (demo mode)")
                
        except Exception as e:
            self.logger.error(f"Arbitraj tespit hatası: {e}")
    
    async def _show_mock_arbitrage_opportunities(self):
        """Mock arbitraj fırsatları göster"""
        mock_opportunities = [
            {
                'symbol': 'BTC/USDT',
                'buy_venue': 'binance',
                'sell_venue': 'bybit',
                'buy_price': 67000.00,
                'sell_price': 67012.50,
                'potential_profit': 12.50,
                'profit_percentage': 0.019,
                'volume_available': 2500.0,
                'estimated_execution_time': 3.2,
                'risk_score': 0.15,
                'timestamp': 1729998592.0
            },
            {
                'symbol': 'ETH/USDT',
                'buy_venue': 'kraken',
                'sell_venue': 'binance',
                'buy_price': 2650.30,
                'sell_price': 2655.80,
                'potential_profit': 5.50,
                'profit_percentage': 0.021,
                'volume_available': 1500.0,
                'estimated_execution_time': 2.8,
                'risk_score': 0.22,
                'timestamp': 1729998592.0
            }
        ]
        
        self.logger.info(f"   Tespit Edilen Fırsatlar: {len(mock_opportunities)}")
        
        for opp in mock_opportunities:
            profit_pct = opp['profit_percentage'] * 100
            self.logger.info(f"   📊 {opp['symbol']}: {opp['buy_venue']} → {opp['sell_venue']}")
            self.logger.info(f"      Kar: {profit_pct:.3f}% (${opp['potential_profit']:.2f})")
            self.logger.info(f"      Hacim: ${opp['volume_available']:.0f}, Risk: {opp['risk_score']:.2f}")
    
    async def _demonstrate_performance_monitoring(self):
        """Performance monitoring örneği"""
        self.logger.info("6. Performance metrikleri...")
        
        try:
            # Performance stats al
            stats = await self.sor.get_performance_stats()
            
            runtime_hours = stats['runtime_seconds'] / 3600 if stats['runtime_seconds'] else 0
            success_rate = (stats['successful_orders'] / max(stats['total_orders'], 1)) * 100
            
            self.logger.info(f"   Çalışma Süresi: {runtime_hours:.1f} saat")
            self.logger.info(f"   Toplam Emir: {stats['total_orders']}")
            self.logger.info(f"   Başarı Oranı: {success_rate:.1f}%")
            self.logger.info(f"   Toplam Hacim: {stats['total_volume']:.2f}")
            self.logger.info(f"   Toplam Tasarruf: ${stats['total_savings']:.2f}")
            
            # Venue performance
            if stats['venue_performance']:
                self.logger.info("   Venue Performansı:")
                for venue, perf in stats['venue_performance'].items():
                    latency = perf.get('avg_latency', 0)
                    success_rate = perf.get('success_rate', 0) * 100
                    self.logger.info(f"   {venue}: {latency:.1f}ms, {success_rate:.1f}% başarı")
            
        except Exception as e:
            self.logger.error(f"Performance monitoring hatası: {e}")
    
    async def cleanup(self):
        """Temizleme işlemleri"""
        self.logger.info("Temizleme işlemleri yapılıyor...")
        
        try:
            # SOR sistemini kapat
            await shutdown_sor()
            self.logger.info("SOR sistemi kapatıldı")
            
        except Exception as e:
            self.logger.error(f"Temizleme hatası: {e}")

async def main():
    """Ana fonksiyon"""
    # Logging kurulumu
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Demo uygulamasını çalıştır
    demo = SORDemo()
    await demo.run_demo()

if __name__ == "__main__":
    # Demo'yu çalıştır
    asyncio.run(main())