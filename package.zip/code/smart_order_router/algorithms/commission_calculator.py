"""
Commission Calculator - Dinamik komisyon hesaplama sistemi
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import math

@dataclass
class CommissionRate:
    """Komisyon oranı veri modeli"""
    venue: str
    maker_rate: float    # Yapıcı komisyonu
    taker_rate: float    # Alıcı komisyonu
    vip_level: str       # VIP seviyesi
    volume_30d: float    # 30 günlük işlem hacmi
    discount_rate: float # İndirim oranı
    effective_rate: float # Etkin oran

class CommissionCalculator:
    """
    Dinamik komisyon hesaplama motoru
    Borsa komisyon oranlarını hesaplar ve optimize eder
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Varsayılan komisyon oranları
        self.default_rates = {
            'binance': {
                'maker': 0.001,  # %0.1
                'taker': 0.001,  # %0.1
                'vip_levels': {
                    'regular': {'maker': 0.001, 'taker': 0.001},
                    'vip1': {'maker': 0.0009, 'taker': 0.001},
                    'vip2': {'maker': 0.0008, 'taker': 0.001},
                    'vip3': {'maker': 0.0007, 'taker': 0.001},
                    'vip4': {'maker': 0.0006, 'taker': 0.001}
                }
            },
            'bybit': {
                'maker': 0.001,
                'taker': 0.001,
                'vip_levels': {
                    'regular': {'maker': 0.001, 'taker': 0.001},
                    'vip1': {'maker': 0.0009, 'taker': 0.001},
                    'vip2': {'maker': 0.0008, 'taker': 0.001}
                }
            },
            'kraken': {
                'maker': 0.0026,  # %0.26
                'taker': 0.0026,  # %0.26
                'vip_levels': {
                    'regular': {'maker': 0.0026, 'taker': 0.0026},
                    'vip1': {'maker': 0.0024, 'taker': 0.0024},
                    'vip2': {'maker': 0.0022, 'taker': 0.0022}
                }
            },
            'okx': {
                'maker': 0.0008,  # %0.08
                'taker': 0.001,   # %0.1
                'vip_levels': {
                    'regular': {'maker': 0.0008, 'taker': 0.001},
                    'vip1': {'maker': 0.0006, 'taker': 0.0008},
                    'vip2': {'maker': 0.0004, 'taker': 0.0006}
                }
            },
            'coinbase': {
                'maker': 0.005,   # %0.5
                'taker': 0.005,   # %0.5
                'vip_levels': {
                    'regular': {'maker': 0.005, 'taker': 0.005},
                    'pro': {'maker': 0.005, 'taker': 0.005}
                }
            }
        }
        
        # Venue komisyon oranları cache
        self.venue_commission_rates: Dict[str, CommissionRate] = {}
        
        # İstatistikler
        self.stats = {
            'total_calculations': 0,
            'avg_commission': 0.0,
            'total_commission_saved': 0.0,
            'optimization_calls': 0
        }
    
    async def calculate_commissions(self, venues_used: List[str], total_cost: float) -> Dict[str, float]:
        """
        Kullanılan venue'lar için komisyonları hesapla
        
        Args:
            venues_used: Kullanılan venue'lar
            total_cost: Toplam işlem maliyeti
            
        Returns:
            Venue başına komisyon miktarları
        """
        self.stats['total_calculations'] += 1
        
        commissions = {}
        
        for venue in venues_used:
            try:
                commission_rate = await self.get_venue_commission_rate(venue)
                commission = total_cost * commission_rate.effective_rate
                commissions[venue] = commission
                
            except Exception as e:
                self.logger.warning(f"Komisyon hesaplama hatası {venue}: {e}")
                # Varsayılan %0.1 komisyon uygula
                commissions[venue] = total_cost * 0.001
        
        return commissions
    
    async def get_venue_commission_rate(self, venue_name: str) -> CommissionRate:
        """Venue komisyon oranını getir"""
        if venue_name in self.venue_commission_rates:
            return self.venue_commission_rates[venue_name]
        
        # Yeni komisyon oranı oluştur
        commission_rate = await self._fetch_venue_commission_rate(venue_name)
        self.venue_commission_rates[venue_name] = commission_rate
        
        return commission_rate
    
    async def _fetch_venue_commission_rate(self, venue_name: str) -> CommissionRate:
        """Venue komisyon oranını borsadan al"""
        venue_name_lower = venue_name.lower()
        
        # Varsayılan oranları al
        default_rate = self.default_rates.get(venue_name_lower, {
            'maker': 0.001,
            'taker': 0.001,
            'vip_levels': {'regular': {'maker': 0.001, 'taker': 0.001}}
        })
        
        # VIP seviyesini belirle (basitleştirilmiş)
        vip_level = await self._determine_vip_level(venue_name)
        
        # VIP seviyesine göre oranları al
        vip_rates = default_rate['vip_levels'].get(vip_level, default_rate['vip_levels']['regular'])
        
        # 30 günlük volume hesapla
        volume_30d = await self._calculate_30d_volume(venue_name)
        
        # İndirim oranını hesapla
        discount_rate = await self._calculate_discount_rate(volume_30d, vip_level)
        
        # Etkin oranı hesapla
        base_rate = (vip_rates['maker'] + vip_rates['taker']) / 2
        effective_rate = base_rate * (1 - discount_rate)
        
        return CommissionRate(
            venue=venue_name,
            maker_rate=vip_rates['maker'],
            taker_rate=vip_rates['taker'],
            vip_level=vip_level,
            volume_30d=volume_30d,
            discount_rate=discount_rate,
            effective_rate=effective_rate
        )
    
    async def _determine_vip_level(self, venue_name: str) -> str:
        """VIP seviyesini belirle"""
        # Basitleştirilmiş VIP seviyesi belirleme
        # Gerçek uygulamada borsa API'sinden kullanıcı bilgileri alınır
        
        try:
            # Simüle edilmiş volume kontrolü
            # Gerçek uygulamada: await venue.get_account_info()
            volume_30d = await self._calculate_30d_volume(venue_name)
            
            if volume_30d >= 1000000:  # $1M+
                return 'vip3'
            elif volume_30d >= 500000:   # $500K+
                return 'vip2'
            elif volume_30d >= 100000:   # $100K+
                return 'vip1'
            else:
                return 'regular'
                
        except Exception:
            return 'regular'
    
    async def _calculate_30d_volume(self, venue_name: str) -> float:
        """30 günlük işlem hacmini hesapla"""
        # Simüle edilmiş volume hesaplama
        # Gerçek uygulamada: venue API'sinden trade history alınır
        
        try:
            # Mock data - gerçek uygulamada trade history'den hesaplanır
            import random
            random.seed(venue_name)  # Deterministic values
            
            base_volume = random.uniform(10000, 500000)
            return base_volume
            
        except Exception as e:
            self.logger.warning(f"30d volume hesaplama hatası {venue_name}: {e}")
            return 10000.0  # Varsayılan değer
    
    async def _calculate_discount_rate(self, volume_30d: float, vip_level: str) -> float:
        """İndirim oranını hesapla"""
        # VIP seviyesine göre indirim oranları
        vip_discounts = {
            'regular': 0.0,
            'vip1': 0.1,   # %10 indirim
            'vip2': 0.2,   # %20 indirim
            'vip3': 0.3,   # %30 indirim
            'vip4': 0.4    # %40 indirim
        }
        
        # Volume tabanlı ek indirim
        volume_discount = 0.0
        if volume_30d >= 1000000:
            volume_discount = 0.1  # %10 ek indirim
        elif volume_30d >= 500000:
            volume_discount = 0.05  # %5 ek indirim
        elif volume_30d >= 100000:
            volume_discount = 0.02  # %2 ek indirim
        
        base_discount = vip_discounts.get(vip_level, 0.0)
        total_discount = min(base_discount + volume_discount, 0.5)  # Max %50 indirim
        
        return total_discount
    
    def calculate_optimal_allocation(self, venues: List[str], order_amount: float, 
                                   is_aggressive: bool = False) -> Dict[str, float]:
        """
        Komisyon optimizasyonu için optimal alokasyon hesapla
        
        Args:
            venues: Değerlendirilecek venue'lar
            order_amount: Sipariş miktarı
            is_aggressive: Agresif optimizasyon istenip istenmediği
            
        Returns:
            Venue başına optimal miktar alokasyonu
        """
        self.stats['optimization_calls'] += 1
        
        if not venues:
            return {}
        
        # Venue'ları komisyon oranına göre sırala
        venue_scores = []
        
        for venue in venues:
            if venue in self.venue_commission_rates:
                rate = self.venue_commission_rates[venue]
                
                # Skor hesaplama (düşük komisyon = yüksek skor)
                if is_aggressive:
                    # Agresif mod: sadece komisyon
                    score = 1000 / (rate.effective_rate + 0.0001)
                else:
                    # Dengeli mod: komisyon + likidite
                    score = 500 / (rate.effective_rate + 0.0001) + 50
                
                venue_scores.append((venue, score, rate.effective_rate))
        
        # Skor sırasına göre sırala
        venue_scores.sort(key=lambda x: x[1], reverse=True)
        
        # Optimal alokasyon hesapla
        allocations = {}
        remaining_amount = order_amount
        
        # En iyi venue'a %60-80, ikinciye %20-40, diğerlerine kalan
        for i, (venue, score, rate) in enumerate(venue_scores):
            if remaining_amount <= 0:
                break
            
            if i == 0:  # En iyi venue
                allocation = remaining_amount * 0.7 if not is_aggressive else remaining_amount * 0.8
            elif i == 1:  # İkinci venue
                allocation = remaining_amount * 0.3 if not is_aggressive else remaining_amount * 0.2
            else:  # Diğer venue'lar
                allocation = 0.0
            
            allocation = min(allocation, remaining_amount)
            allocations[venue] = allocation
            remaining_amount -= allocation
        
        return allocations
    
    async def estimate_total_commission(self, allocation: Dict[str, float], 
                                      prices: Dict[str, float]) -> Dict[str, Any]:
        """Toplam komisyon tahmini"""
        total_commission = 0.0
        commission_breakdown = {}
        
        for venue, amount in allocation.items():
            if venue in prices:
                cost = amount * prices[venue]
                if venue in self.venue_commission_rates:
                    rate = self.venue_commission_rates[venue]
                    commission = cost * rate.effective_rate
                    commission_breakdown[venue] = commission
                    total_commission += commission
        
        return {
            'total_commission': total_commission,
            'breakdown': commission_breakdown,
            'commission_rate': total_commission / sum(amount * prices.get(venue, 0) 
                                                   for venue, amount in allocation.items())
        }
    
    def get_commission_stats(self) -> Dict[str, Any]:
        """Komisyon istatistiklerini getir"""
        if self.venue_commission_rates:
            avg_rate = sum(rate.effective_rate for rate in self.venue_commission_rates.values()) / len(self.venue_commission_rates)
            min_rate = min(rate.effective_rate for rate in self.venue_commission_rates.values())
            max_rate = max(rate.effective_rate for rate in self.venue_commission_rates.values())
        else:
            avg_rate = min_rate = max_rate = 0.0
        
        return {
            'stats': self.stats.copy(),
            'current_rates': {
                venue: {
                    'maker': rate.maker_rate,
                    'taker': rate.taker_rate,
                    'effective': rate.effective_rate,
                    'vip_level': rate.vip_level,
                    'discount': rate.discount_rate
                }
                for venue, rate in self.venue_commission_rates.items()
            },
            'summary': {
                'avg_effective_rate': avg_rate,
                'min_effective_rate': min_rate,
                'max_effective_rate': max_rate,
                'venue_count': len(self.venue_commission_rates)
            }
        }
    
    def update_commission_rates(self, venue_name: str, new_rates: Dict[str, float]):
        """Komisyon oranlarını manuel güncelle"""
        if venue_name in self.venue_commission_rates:
            current_rate = self.venue_commission_rates[venue_name]
            
            if 'maker' in new_rates:
                current_rate.maker_rate = new_rates['maker']
            if 'taker' in new_rates:
                current_rate.taker_rate = new_rates['taker']
            if 'vip_level' in new_rates:
                current_rate.vip_level = new_rates['vip_level']
            
            # Etkin oranı yeniden hesapla
            current_rate.effective_rate = (
                (current_rate.maker_rate + current_rate.taker_rate) / 2 * 
                (1 - current_rate.discount_rate)
            )
            
            self.logger.info(f"Komisyon oranları güncellendi {venue_name}: {new_rates}")
    
    def clear_cache(self):
        """Komisyon oranı cache'ini temizle"""
        self.venue_commission_rates.clear()
        self.logger.info("Komisyon oranı cache'i temizlendi")