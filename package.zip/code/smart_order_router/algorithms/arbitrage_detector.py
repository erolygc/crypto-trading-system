"""
Arbitrage Detector - Çapraz borsa arbitraj tespiti
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import math

@dataclass
class ArbitrageOpportunity:
    """Arbitraj fırsatı"""
    symbol: str
    buy_venue: str
    sell_venue: str
    buy_price: float
    sell_price: float
    spread: float  # Yüzde olarak spread
    potential_profit: float
    max_trade_size: float
    min_profitable_size: float
    timestamp: datetime
    confidence_score: float

class ArbitrageDetector:
    """
    Arbitraj tespit motoru
    Çoklu borsalar arasındaki fiyat farklılıklarını tespit eder
    """
    
    def __init__(self, venue_manager):
        self.venue_manager = venue_manager
        self.logger = logging.getLogger(__name__)
        
        # Arbitraj eşiği değerleri
        self.min_spread_threshold = 0.0005  # %0.05 minimum spread
        self.min_profit_threshold = 10.0     # $10 minimum kar
        self.max_trade_size = 10000.0       # $10K maksimum işlem
        self.confidence_threshold = 0.7     # %70 minimum güven skoru
        
        # Tespit geçmişi
        self.detected_opportunities: List[ArbitrageOpportunity] = []
        self.opportunity_history: List[Dict] = []
        
        # İstatistikler
        self.stats = {
            'total_scans': 0,
            'opportunities_found': 0,
            'profitable_opportunities': 0,
            'avg_spread': 0.0,
            'avg_profit': 0.0
        }
    
    async def detect_arbitrage(self, symbol: str, price_data: Dict[str, Any]) -> List[ArbitrageOpportunity]:
        """
        Belirli bir sembol için arbitraj fırsatlarını tespit et
        
        Args:
            symbol: İşlem sembolü
            price_data: Fiyat verileri
            
        Returns:
            Tespit edilen arbitraj fırsatları
        """
        self.stats['total_scans'] += 1
        opportunities = []
        
        try:
            venues_data = price_data.get('venues', {})
            venue_names = list(venues_data.keys())
            
            if len(venue_names) < 2:
                return opportunities
            
            # Tüm venue kombinasyonlarını kontrol et
            for i, buy_venue in enumerate(venue_names):
                for j, sell_venue in enumerate(venue_names[i+1:], i+1):
                    try:
                        # Alım ve satım kombinasyonları
                        buy_opportunity = await self._check_arb_opportunity(
                            symbol, buy_venue, sell_venue, venues_data
                        )
                        sell_opportunity = await self._check_arb_opportunity(
                            symbol, sell_venue, buy_venue, venues_data
                        )
                        
                        if buy_opportunity:
                            opportunities.append(buy_opportunity)
                        
                        if sell_opportunity:
                            opportunities.append(sell_opportunity)
                    
                    except Exception as e:
                        self.logger.warning(f"Arbitraj kontrol hatası {buy_venue}/{sell_venue}: {e}")
                        continue
            
            # Fırsatları puanla ve filtrele
            filtered_opportunities = self._filter_and_rank_opportunities(opportunities)
            
            self.stats['opportunities_found'] += len(filtered_opportunities)
            
            # Detected opportunities'ı kaydet
            self.detected_opportunities.extend(filtered_opportunities)
            
            # Son 100 fırsatı sakla
            if len(self.detected_opportunities) > 100:
                self.detected_opportunities = self.detected_opportunities[-100:]
            
            # İstatistikleri güncelle
            self._update_stats(filtered_opportunities)
            
            self.logger.info(
                f"Arbitraj tespiti tamamlandı {symbol}: {len(filtered_opportunities)} fırsat"
            )
            
            return filtered_opportunities
            
        except Exception as e:
            self.logger.error(f"Arbitraj tespit hatası {symbol}: {e}")
            return []
    
    async def _check_arb_opportunity(self, symbol: str, buy_venue: str, 
                                   sell_venue: str, venues_data: Dict) -> Optional[ArbitrageOpportunity]:
        """Tek bir buy-sell venue kombinasyonunu kontrol et"""
        try:
            buy_data = venues_data.get(buy_venue)
            sell_data = venues_data.get(sell_venue)
            
            if not buy_data or not sell_data:
                return None
            
            # Alım fiyatı (en iyi ask)
            buy_price = buy_data.get('ask', 0)
            # Satım fiyatı (en iyi bid)
            sell_price = sell_data.get('bid', 0)
            
            if buy_price <= 0 or sell_price <= 0:
                return None
            
            # Spread hesapla
            spread = (sell_price - buy_price) / buy_price
            
            if spread < self.min_spread_threshold:
                return None
            
            # Likidite analizi
            buy_liquidity = self._get_venue_liquidity(buy_data, 'ask')
            sell_liquidity = self._get_venue_liquidity(sell_data, 'bid')
            
            max_trade_size = min(buy_liquidity, sell_liquidity) * 0.1  # %10'u kullan
            max_trade_size = min(max_trade_size, self.max_trade_size)
            
            # Minimum kararlı işlem boyutu
            min_profitable_size = self.min_profit_threshold / (sell_price - buy_price)
            
            if max_trade_size < min_profitable_size:
                return None
            
            # Potansiyel kar
            potential_profit = max_trade_size * spread
            
            # Güven skoru hesapla
            confidence_score = self._calculate_confidence_score(
                buy_data, sell_data, spread
            )
            
            if confidence_score < self.confidence_threshold:
                return None
            
            return ArbitrageOpportunity(
                symbol=symbol,
                buy_venue=buy_venue,
                sell_venue=sell_venue,
                buy_price=buy_price,
                sell_price=sell_price,
                spread=spread,
                potential_profit=potential_profit,
                max_trade_size=max_trade_size,
                min_profitable_size=min_profitable_size,
                timestamp=datetime.utcnow(),
                confidence_score=confidence_score
            )
            
        except Exception as e:
            self.logger.warning(f"Arbitraj fırsat kontrol hatası: {e}")
            return None
    
    def _get_venue_liquidity(self, venue_data: Dict, side: str) -> float:
        """Venue likiditesini hesapla"""
        try:
            order_book = venue_data.get('order_book', {})
            side_orders = order_book.get(side + 's', [])
            
            if not side_orders:
                return 0.0
            
            # İlk 10 seviyenin toplamını al
            total_liquidity = 0.0
            for price, amount in side_orders[:10]:
                total_liquidity += float(price) * float(amount)
            
            return total_liquidity
            
        except Exception as e:
            self.logger.warning(f"Likidite hesaplama hatası: {e}")
            return 0.0
    
    def _calculate_confidence_score(self, buy_data: Dict, sell_data: Dict, spread: float) -> float:
        """Güven skorunu hesapla"""
        try:
            score = 0.0
            
            # Spread güveni (yüksek spread = yüksek güven, ama çok yüksek değil)
            spread_score = min(spread / 0.01, 1.0)  # %1'e kadar normal
            score += spread_score * 0.4
            
            # Latency güveni
            buy_latency = buy_data.get('latency', 1000)
            sell_latency = sell_data.get('latency', 1000)
            avg_latency = (buy_latency + sell_latency) / 2
            
            latency_score = max(0, 1 - (avg_latency / 1000))  # 1 saniyeden düşük = iyi
            score += latency_score * 0.3
            
            # Volume güveni
            buy_volume = buy_data.get('volume', 0)
            sell_volume = sell_data.get('volume', 0)
            min_volume = min(buy_volume, sell_volume)
            
            volume_score = min(min_volume / 1000000, 1.0)  # 1M volume = tam puan
            score += volume_score * 0.3
            
            return score
            
        except Exception as e:
            self.logger.warning(f"Güven skoru hesaplama hatası: {e}")
            return 0.0
    
    def _filter_and_rank_opportunities(self, opportunities: List[ArbitrageOpportunity]) -> List[ArbitrageOpportunity]:
        """Arbitraj fırsatlarını filtrele ve sırala"""
        if not opportunities:
            return []
        
        # Minimum kriterleri karşılayanları filtrele
        filtered = [
            opp for opp in opportunities 
            if (opp.spread >= self.min_spread_threshold and
                opp.potential_profit >= self.min_profit_threshold and
                opp.confidence_score >= self.confidence_threshold)
        ]
        
        # Potansiyel kara göre sırala
        filtered.sort(key=lambda x: x.potential_profit * x.confidence_score, reverse=True)
        
        # En iyi 5 fırsatı döndür
        return filtered[:5]
    
    def _update_stats(self, opportunities: List[ArbitrageOpportunity]):
        """İstatistikleri güncelle"""
        if not opportunities:
            return
        
        profitable_count = len([opp for opp in opportunities if opp.potential_profit > self.min_profit_threshold])
        self.stats['profitable_opportunities'] += profitable_count
        
        # Ortalama spread ve kar güncelle
        total_spread = sum(opp.spread for opp in opportunities)
        total_profit = sum(opp.potential_profit for opp in opportunities)
        
        if self.stats['opportunities_found'] > 0:
            self.stats['avg_spread'] = (
                (self.stats['avg_spread'] * (self.stats['opportunities_found'] - len(opportunities)) +
                 total_spread) / self.stats['opportunities_found']
            )
            self.stats['avg_profit'] = (
                (self.stats['avg_profit'] * (self.stats['opportunities_found'] - len(opportunities)) +
                 total_profit) / self.stats['opportunities_found']
            )
        else:
            self.stats['avg_spread'] = total_spread / len(opportunities)
            self.stats['avg_profit'] = total_profit / len(opportunities)
    
    async def scan_multiple_symbols(self, symbols: List[str], price_data_cache: Dict[str, Dict]) -> Dict[str, List[ArbitrageOpportunity]]:
        """Birden fazla sembol için arbitraj taraması"""
        all_opportunities = {}
        
        for symbol in symbols:
            try:
                if symbol in price_data_cache:
                    opportunities = await self.detect_arbitrage(symbol, price_data_cache[symbol])
                    all_opportunities[symbol] = opportunities
                else:
                    self.logger.warning(f"Price data bulunamadı: {symbol}")
            except Exception as e:
                self.logger.error(f"Çoklu sembol tarama hatası {symbol}: {e}")
                continue
        
        return all_opportunities
    
    def get_recent_opportunities(self, hours: int = 1) -> List[ArbitrageOpportunity]:
        """Son N saatteki fırsatları getir"""
        cutoff_time = datetime.utcnow() - timedelta(hours=hours)
        
        return [
            opp for opp in self.detected_opportunities 
            if opp.timestamp > cutoff_time
        ]
    
    def get_arbitrage_stats(self) -> Dict[str, Any]:
        """Arbitraj istatistiklerini getir"""
        recent_opportunities = self.get_recent_opportunities(24)  # Son 24 saat
        
        if recent_opportunities:
            best_spread = max(opp.spread for opp in recent_opportunities)
            best_profit = max(opp.potential_profit for opp in recent_opportunities)
            avg_confidence = sum(opp.confidence_score for opp in recent_opportunities) / len(recent_opportunities)
        else:
            best_spread = 0.0
            best_profit = 0.0
            avg_confidence = 0.0
        
        return {
            'stats': self.stats.copy(),
            'recent_count': len(recent_opportunities),
            'best_spread': best_spread,
            'best_profit': best_profit,
            'avg_confidence': avg_confidence,
            'min_thresholds': {
                'spread': self.min_spread_threshold,
                'profit': self.min_profit_threshold,
                'confidence': self.confidence_threshold
            }
        }
    
    def update_thresholds(self, new_thresholds: Dict[str, float]):
        """Arbitraj eşiği değerlerini güncelle"""
        if 'min_spread' in new_thresholds:
            self.min_spread_threshold = new_thresholds['min_spread']
        if 'min_profit' in new_thresholds:
            self.min_profit_threshold = new_thresholds['min_profit']
        if 'confidence' in new_thresholds:
            self.confidence_threshold = new_thresholds['confidence']
        if 'max_trade_size' in new_thresholds:
            self.max_trade_size = new_thresholds['max_trade_size']
        
        self.logger.info(f"Arbitraj eşikleri güncellendi: {new_thresholds}")