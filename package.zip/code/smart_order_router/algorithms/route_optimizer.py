"""
Route Optimizer - En iyi sipariş yönlendirme stratejileri
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from datetime import datetime
import math
import statistics

@dataclass
class RouteOption:
    """Route seçeneği"""
    venue: str
    amount: float
    price: float
    estimated_slippage: float
    estimated_commission: float
    total_cost: float
    liquidity_available: float
    execution_speed: float  # ms
    score: float

class RouteOptimizer:
    """
    Route optimizasyon motoru
    En iyi fiyat, likidite ve yürütme hızını optimize eder
    """
    
    def __init__(self, venue_manager):
        self.venue_manager = venue_manager
        self.logger = logging.getLogger(__name__)
        
        # Optimizasyon ağırlıkları
        self.weights = {
            'price': 0.4,        # Fiyat önceliği
            'liquidity': 0.25,   # Likidite önceliği
            'speed': 0.2,        # Yürütme hızı
            'cost': 0.15         # Toplam maliyet
        }
        
        # Minimum eşik değerler
        self.min_liquidity = 1000.0  # Minimum likidite
        self.max_slippage = 0.005    # Maksimum kayma (%0.5)
        self.max_latency = 1000      # Maksimum gecikme (ms)
    
    async def optimize_routes(self, order_request, price_data: Dict[str, Any], 
                            arbitrage_opportunities: List[Dict]) -> List[Dict[str, Any]]:
        """
        Sipariş için optimal route'ları hesapla
        
        Args:
            order_request: Sipariş isteği
            price_data: Fiyat verileri
            arbitrage_opportunities: Arbitraj fırsatları
            
        Returns:
            Optimal route'ların listesi
        """
        self.logger.info(f"Route optimizasyonu başlatılıyor: {order_request.symbol}")
        
        # 1. Temel route seçeneklerini oluştur
        route_options = await self._generate_route_options(order_request, price_data)
        
        # 2. Arbitraj fırsatlarını değerlendir
        if arbitrage_opportunities:
            route_options = await self._incorporate_arbitrage_routes(
                route_options, arbitrage_opportunities
            )
        
        # 3. Route seçeneklerini puanla
        scored_routes = self._score_routes(route_options)
        
        # 4. En iyi route kombinasyonunu seç
        optimal_routes = self._select_optimal_combination(
            scored_routes, order_request.amount
        )
        
        self.logger.info(
            f"Route optimizasyonu tamamlandı: {len(optimal_routes)} route seçildi"
        )
        
        return optimal_routes
    
    async def _generate_route_options(self, order_request, price_data: Dict[str, Any]) -> List[RouteOption]:
        """Temel route seçeneklerini oluştur"""
        route_options = []
        
        for venue_name, venue_data in price_data.get('venues', {}).items():
            try:
                # Venue sağlık kontrolü
                venue_metrics = self.venue_manager.venue_metrics.get(venue_name)
                if not venue_metrics or venue_metrics.health_score < 50:
                    continue
                
                # Likidite kontrolü
                liquidity_score = price_data.get('order_book_depth', {}).get(
                    venue_name, {}
                ).get('liquidity_score', 0)
                
                if liquidity_score < self.min_liquidity:
                    continue
                
                # Fiyat kontrolü
                side_data = venue_data.get('bid' if order_request.side == 'sell' else 'ask')
                if not side_data or side_data <= 0:
                    continue
                
                # Miktar kontrolü
                max_amount = self._calculate_max_executable_amount(
                    venue_data, order_request.amount
                )
                
                if max_amount <= 0:
                    continue
                
                # Kayma tahmini
                slippage = self._estimate_slippage(
                    venue_data, max_amount, order_request.side
                )
                
                if slippage > self.max_slippage:
                    continue
                
                # Komisyon tahmini
                commission = self._estimate_commission(
                    venue_data, max_amount, side_data
                )
                
                # Toplam maliyet
                total_cost = max_amount * side_data + commission
                
                # Yürütme hızı
                execution_speed = venue_metrics.latency
                
                if execution_speed > self.max_latency:
                    continue
                
                route_option = RouteOption(
                    venue=venue_name,
                    amount=max_amount,
                    price=side_data,
                    estimated_slippage=slippage,
                    estimated_commission=commission,
                    total_cost=total_cost,
                    liquidity_available=liquidity_score,
                    execution_speed=execution_speed,
                    score=0.0  # Puanlama sonradan yapılacak
                )
                
                route_options.append(route_option)
                
            except Exception as e:
                self.logger.warning(f"Route seçeneği oluşturma hatası {venue_name}: {e}")
                continue
        
        return route_options
    
    def _calculate_max_executable_amount(self, venue_data: Dict, requested_amount: float) -> float:
        """Maksimum yürütülebilir miktarı hesapla"""
        try:
            order_book = venue_data.get('order_book', {})
            side_key = 'bids' if requested_amount > 0 else 'asks'
            side_orders = order_book.get(side_key, [])
            
            available_amount = 0.0
            total_cost = 0.0
            
            remaining_amount = abs(requested_amount)
            
            for price, amount in side_orders:
                price = float(price)
                amount = float(amount)
                
                if remaining_amount <= 0:
                    break
                
                fill_amount = min(remaining_amount, amount)
                available_amount += fill_amount
                total_cost += fill_amount * price
                remaining_amount -= fill_amount
            
            return available_amount
            
        except Exception as e:
            self.logger.warning(f"Maksimum miktar hesaplama hatası: {e}")
            return 0.0
    
    def _estimate_slippage(self, venue_data: Dict, amount: float, side: str) -> float:
        """Tahmini kayma oranını hesapla"""
        try:
            current_price = venue_data.get('bid' if side == 'sell' else 'ask', 0)
            if current_price <= 0:
                return float('inf')
            
            order_book = venue_data.get('order_book', {})
            side_key = 'bids' if side == 'sell' else 'asks'
            side_orders = order_book.get(side_key, [])
            
            # Market etkisi hesaplama (basit model)
            if not side_orders:
                return 0.05  # %5 varsayılan kayma
            
            cumulative_amount = 0.0
            weighted_price = 0.0
            
            for price, order_amount in side_orders:
                price = float(price)
                order_amount = float(order_amount)
                
                if cumulative_amount >= amount:
                    break
                
                fill_amount = min(amount - cumulative_amount, order_amount)
                weighted_price += price * fill_amount
                cumulative_amount += fill_amount
            
            if cumulative_amount > 0:
                average_price = weighted_price / cumulative_amount
                slippage = abs(average_price - current_price) / current_price
                return slippage
            
            return 0.02  # %2 varsayılan kayma
            
        except Exception as e:
            self.logger.warning(f"Kayma tahmin hatası: {e}")
            return 0.02
    
    def _estimate_commission(self, venue_data: Dict, amount: float, price: float) -> float:
        """Tahmini komisyonu hesapla"""
        try:
            commission_rate = venue_data.get('commission_rate', 0.001)
            notional_value = amount * price
            commission = notional_value * commission_rate
            return commission
            
        except Exception as e:
            self.logger.warning(f"Komisyon tahmin hatası: {e}")
            return 0.0
    
    async def _incorporate_arbitrage_routes(self, route_options: List[RouteOption],
                                          arbitrage_opportunities: List[Dict]) -> List[RouteOption]:
        """Arbitraj fırsatlarını route seçeneklerine dahil et"""
        for arb_opportunity in arbitrage_opportunities:
            try:
                # Arbitraj fırsatını route olarak değerlendir
                if arb_opportunity.get('spread', 0) > 0.001:  # %0.1'dan büyük spread
                    # Arbitraj için özel route oluştur
                    arb_route = RouteOption(
                        venue=arb_opportunity.get('buy_venue'),
                        amount=arb_opportunity.get('amount', 0),
                        price=arb_opportunity.get('buy_price', 0),
                        estimated_slippage=0.001,  # Düşük kayma varsayımı
                        estimated_commission=0.0,
                        total_cost=arb_opportunity.get('buy_price', 0) * arb_opportunity.get('amount', 0),
                        liquidity_available=10000.0,  # Yüksek likidite varsayımı
                        execution_speed=500.0,  # Orta hız
                        score=arb_opportunity.get('spread', 0) * 100  # Spread puanlaması
                    )
                    
                    route_options.append(arb_route)
                    
            except Exception as e:
                self.logger.warning(f"Arbitraj route hatası: {e}")
                continue
        
        return route_options
    
    def _score_routes(self, route_options: List[RouteOption]) -> List[RouteOption]:
        """Route seçeneklerini puanla"""
        if not route_options:
            return []
        
        # Her metrik için normalizasyon
        price_scores = []
        liquidity_scores = []
        speed_scores = []
        cost_scores = []
        
        for route in route_options:
            # Fiyat skoru (düşük fiyat = yüksek skor)
            price_scores.append(100 / (route.price + 0.01))
            
            # Likidite skoru
            liquidity_scores.append(min(route.liquidity_available, 10000))
            
            # Hız skoru (düşük gecikme = yüksek skor)
            speed_scores.append(1000 / (route.execution_speed + 10))
            
            # Maliyet skoru (düşük maliyet = yüksek skor)
            cost_scores.append(1000 / (route.total_cost + 100))
        
        # Normalize et
        max_price = max(price_scores) if price_scores else 1
        max_liquidity = max(liquidity_scores) if liquidity_scores else 1
        max_speed = max(speed_scores) if speed_scores else 1
        max_cost = max(cost_scores) if cost_scores else 1
        
        for i, route in enumerate(route_options):
            # Normalize edilmiş skorlar
            normalized_price = price_scores[i] / max_price if max_price > 0 else 0
            normalized_liquidity = liquidity_scores[i] / max_liquidity if max_liquidity > 0 else 0
            normalized_speed = speed_scores[i] / max_speed if max_speed > 0 else 0
            normalized_cost = cost_scores[i] / max_cost if max_cost > 0 else 0
            
            # Ağırlıklı toplam skor
            route.score = (
                normalized_price * self.weights['price'] +
                normalized_liquidity * self.weights['liquidity'] +
                normalized_speed * self.weights['speed'] +
                normalized_cost * self.weights['cost']
            )
        
        # Skor sırasına göre sırala
        route_options.sort(key=lambda x: x.score, reverse=True)
        
        return route_options
    
    def _select_optimal_combination(self, scored_routes: List[RouteOption], 
                                   total_amount: float) -> List[Dict[str, Any]]:
        """Optimal route kombinasyonunu seç"""
        if not scored_routes:
            return []
        
        optimal_routes = []
        remaining_amount = total_amount
        
        # En iyi skorlu route'lardan başla
        for route in scored_routes[:5]:  # İlk 5 route'u değerlendir
            if remaining_amount <= 0:
                break
            
            # Bu route'dan ne kadar kullanılabilir
            available_amount = min(route.amount, remaining_amount)
            
            if available_amount > 0:
                optimal_routes.append({
                    'venue': route.venue,
                    'amount': available_amount,
                    'price': route.price,
                    'estimated_slippage': route.estimated_slippage,
                    'estimated_commission': route.estimated_commission,
                    'score': route.score
                })
                
                remaining_amount -= available_amount
        
        return optimal_routes
    
    def update_optimization_weights(self, new_weights: Dict[str, float]):
        """Optimizasyon ağırlıklarını güncelle"""
        # Ağırlıkların toplamı 1.0 olmalı
        total_weight = sum(new_weights.values())
        if abs(total_weight - 1.0) > 0.01:
            self.logger.warning("Ağırlıklar 1.0'a normalize edildi")
            new_weights = {k: v / total_weight for k, v in new_weights.items()}
        
        self.weights.update(new_weights)
        self.logger.info(f"Optimizasyon ağırlıkları güncellendi: {self.weights}")
    
    def get_optimization_metrics(self) -> Dict[str, Any]:
        """Optimizasyon metriklerini getir"""
        return {
            'weights': self.weights.copy(),
            'thresholds': {
                'min_liquidity': self.min_liquidity,
                'max_slippage': self.max_slippage,
                'max_latency': self.max_latency
            },
            'venue_count': len(self.venue_manager.venues),
            'active_venues': len([v for v in self.venue_manager.venues.values() if v.is_connected])
        }