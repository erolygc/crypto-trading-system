"""
Signal Confidence Integration Modülü
===================================

Sinyal güven seviyesini hesaplayan ve pozisyon boyutlandırmasına entegre 
eden gelişmiş sistem. Mevcut signal scoring sistemi ile seamless entegrasyon.

Bu modül:
- Signal scoring sisteminden confidence skorlarını alır
- Multiple confidence metrics'i combine eder
- Pozisyon boyutlandırması için confidence-adjusted sizing yapar
- Historical performance ile confidence kalibrasyonu yapar
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass
from enum import Enum
from scipy import stats
import warnings

warnings.filterwarnings('ignore')


class ConfidenceSource(Enum):
    """Confidence kaynak tipleri"""
    SIGNAL_SCORE = "signal_score"
    MODEL_CONFIDENCE = "model_confidence"
    MARKET_REGIME = "market_regime"
    HISTORICAL_PERFORMANCE = "historical_performance"
    VOLATILITY_ADJUSTED = "volatility_adjusted"
    CORRELATION_ADJUSTED = "correlation_adjusted"


class ConfidenceLevel(Enum):
    """Confidence seviyeleri"""
    VERY_LOW = "very_low"      # 0.0 - 0.2
    LOW = "low"                # 0.2 - 0.4
    MODERATE = "moderate"      # 0.4 - 0.6
    HIGH = "high"              # 0.6 - 0.8
    VERY_HIGH = "very_high"    # 0.8 - 1.0


@dataclass
class ConfidenceMetrics:
    """Confidence metrikleri"""
    overall_confidence: float
    signal_confidence: float
    model_confidence: float
    regime_confidence: float
    performance_confidence: float
    volatility_confidence: float
    correlation_confidence: float
    confidence_level: ConfidenceLevel
    uncertainty_score: float
    confidence_interval: Tuple[float, float]
    calibration_score: float


@dataclass
class SignalData:
    """Signal veri yapısı"""
    signal_id: str
    signal_type: str
    asset: str
    signal_score: float
    model_outputs: Dict[str, float]
    market_regime: str
    historical_returns: np.ndarray
    position_size: float
    timestamp: pd.Timestamp
    additional_data: Dict[str, Any]


class SignalConfidenceIntegrator:
    """
    Signal Confidence Integrator
    
    Çoklu confidence kaynaklarını entegre eden ve pozisyon boyutlandırması
    için confidence-adjusted sizing yapan sistem.
    """
    
    def __init__(self):
        """Signal confidence integrator başlat"""
        self.confidence_history: Dict[str, List[float]] = {}
        self.performance_history: Dict[str, List[float]] = {}
        self.calibration_data: Dict[str, List[Tuple[float, float]]] = {}
        self.confidence_weights = {
            'signal_score': 0.3,
            'model_confidence': 0.25,
            'regime_confidence': 0.2,
            'performance_confidence': 0.15,
            'volatility_confidence': 0.05,
            'correlation_confidence': 0.05
        }
        self.min_confidence_threshold = 0.1
        self.max_confidence_threshold = 0.95
        
    def calculate_signal_confidence(self, signal_data: Dict[str, Any]) -> ConfidenceMetrics:
        """
        Sinyal için overall confidence hesapla
        
        Args:
            signal_data: Sinyal verisi
        
        Returns:
            ConfidenceMetrics: Confidence analizi sonucu
        """
        # Individual confidence component'ları hesapla
        signal_conf = self._calculate_signal_score_confidence(signal_data)
        model_conf = self._calculate_model_confidence(signal_data)
        regime_conf = self._calculate_regime_confidence(signal_data)
        performance_conf = self._calculate_performance_confidence(signal_data)
        volatility_conf = self._calculate_volatility_confidence(signal_data)
        correlation_conf = self._calculate_correlation_confidence(signal_data)
        
        # Weighted average
        confidence_components = {
            'signal_score': signal_conf,
            'model_confidence': model_conf,
            'regime_confidence': regime_conf,
            'performance_confidence': performance_conf,
            'volatility_confidence': volatility_conf,
            'correlation_confidence': correlation_conf
        }
        
        overall_confidence = sum(
            confidence_components[source] * weight 
            for source, weight in self.confidence_weights.items()
        )
        
        # Uncertainty score (1 - overall_confidence)
        uncertainty_score = 1.0 - overall_confidence
        
        # Confidence interval (normal dağılım varsayımı)
        confidence_interval = self._calculate_confidence_interval(overall_confidence, uncertainty_score)
        
        # Confidence level kategorisi
        confidence_level = self._categorize_confidence_level(overall_confidence)
        
        # Calibration score
        calibration_score = self._calculate_calibration_score(signal_data, overall_confidence)
        
        return ConfidenceMetrics(
            overall_confidence=overall_confidence,
            signal_confidence=signal_conf,
            model_confidence=model_conf,
            regime_confidence=regime_conf,
            performance_confidence=performance_conf,
            volatility_confidence=volatility_conf,
            correlation_confidence=correlation_conf,
            confidence_level=confidence_level,
            uncertainty_score=uncertainty_score,
            confidence_interval=confidence_interval,
            calibration_score=calibration_score
        )
    
    def _calculate_signal_score_confidence(self, signal_data: Dict[str, Any]) -> float:
        """Signal score confidence hesapla"""
        signal_score = signal_data.get('signal_score', 0.5)
        
        # Signal score'u confidence'e çevir
        # Higher scores typically indicate higher confidence
        confidence = min(signal_score * 1.2, 1.0)
        
        # Score kalitesi
        score_variance = signal_data.get('score_variance', 0.0)
        quality_adjustment = 1.0 - min(score_variance, 0.3)
        
        return confidence * quality_adjustment
    
    def _calculate_model_confidence(self, signal_data: Dict[str, Any]) -> float:
        """Model confidence hesapla"""
        model_outputs = signal_data.get('model_outputs', {})
        
        if not model_outputs:
            return 0.5  # Default
        
        # Model consensus hesapla
        values = list(model_outputs.values())
        consensus = 1.0 - (np.std(values) / (np.mean(values) + 1e-8)) if len(values) > 1 else 1.0
        
        # Model agreement score
        model_agreement = min(consensus, 1.0)
        
        # Model quality adjustment
        model_quality = signal_data.get('model_quality_score', 0.5)
        
        return model_agreement * model_quality
    
    def _calculate_regime_confidence(self, signal_data: Dict[str, Any]) -> float:
        """Market regime confidence hesapla"""
        market_regime = signal_data.get('market_regime', 'unknown')
        
        # Regime confidence mapping
        regime_confidence_map = {
            'trending_bull': 0.8,
            'trending_bear': 0.7,
            'sideways': 0.6,
            'high_volatility': 0.4,
            'low_volatility': 0.7,
            'crisis': 0.3,
            'unknown': 0.5
        }
        
        base_confidence = regime_confidence_map.get(market_regime, 0.5)
        
        # Regime stability adjustment
        regime_stability = signal_data.get('regime_stability', 0.5)
        
        return base_confidence * regime_stability
    
    def _calculate_performance_confidence(self, signal_data: Dict[str, Any]) -> float:
        """Historical performance confidence hesapla"""
        historical_returns = signal_data.get('historical_returns', np.array([]))
        
        if len(historical_returns) == 0:
            return 0.5
        
        # Performance metrikleri
        mean_return = np.mean(historical_returns)
        return_volatility = np.std(historical_returns)
        win_rate = np.sum(historical_returns > 0) / len(historical_returns)
        
        # Sharpe ratio
        sharpe = mean_return / (return_volatility + 1e-8)
        
        # Consistency (return stability)
        consistency = 1.0 - abs(np.mean(historical_returns)) / (return_volatility + 1e-8)
        
        # Performance confidence score
        performance_score = (
            0.4 * min(sharpe / 2.0, 1.0) +  # Sharpe ratio contribution
            0.3 * win_rate +                  # Win rate contribution  
            0.3 * min(consistency, 1.0)      # Consistency contribution
        )
        
        return min(max(performance_score, 0.0), 1.0)
    
    def _calculate_volatility_confidence(self, signal_data: Dict[str, Any]) -> float:
        """Volatility-adjusted confidence hesapla"""
        historical_returns = signal_data.get('historical_returns', np.array([]))
        
        if len(historical_returns) == 0:
            return 0.5
        
        current_vol = np.std(historical_returns)
        recent_vol = np.std(historical_returns[-30:]) if len(historical_returns) >= 30 else current_vol
        
        # Volatility stability
        vol_ratio = recent_vol / (current_vol + 1e-8)
        
        # Lower volatility typically means higher confidence for position sizing
        if vol_ratio < 0.8:  # Volatility decreased
            volatility_confidence = 0.8
        elif vol_ratio > 1.2:  # Volatility increased
            volatility_confidence = 0.4
        else:  # Stable volatility
            volatility_confidence = 0.6
        
        return volatility_confidence
    
    def _calculate_correlation_confidence(self, signal_data: Dict[str, Any]) -> float:
        """Correlation-adjusted confidence hesapla"""
        # Portfolio correlation data
        portfolio_correlations = signal_data.get('portfolio_correlations', {})
        current_exposure = signal_data.get('current_exposure', 0.0)
        
        if not portfolio_correlations:
            return 0.5
        
        # Calculate average correlation with current portfolio
        avg_correlation = np.mean(list(portfolio_correlations.values()))
        
        # High correlation typically reduces confidence due to concentration risk
        if avg_correlation > 0.8:
            correlation_confidence = 0.3
        elif avg_correlation > 0.6:
            correlation_confidence = 0.5
        elif avg_correlation > 0.4:
            correlation_confidence = 0.7
        else:
            correlation_confidence = 0.8
        
        # Adjust for current exposure level
        if current_exposure > 0.8:
            correlation_confidence *= 0.8  # Reduce confidence for high exposure
        
        return correlation_confidence
    
    def _calculate_confidence_interval(self, confidence: float, uncertainty: float) -> Tuple[float, float]:
        """Confidence interval hesapla"""
        # Normal dağılım varsayımı ile confidence interval
        z_score = 1.96  # 95% confidence interval
        
        margin_of_error = z_score * uncertainty * 0.5
        lower_bound = max(0.0, confidence - margin_of_error)
        upper_bound = min(1.0, confidence + margin_of_error)
        
        return (lower_bound, upper_bound)
    
    def _categorize_confidence_level(self, confidence: float) -> ConfidenceLevel:
        """Confidence seviyesini kategorize et"""
        if confidence < 0.2:
            return ConfidenceLevel.VERY_LOW
        elif confidence < 0.4:
            return ConfidenceLevel.LOW
        elif confidence < 0.6:
            return ConfidenceLevel.MODERATE
        elif confidence < 0.8:
            return ConfidenceLevel.HIGH
        else:
            return ConfidenceLevel.VERY_HIGH
    
    def _calculate_calibration_score(self, signal_data: Dict[str, Any], 
                                   predicted_confidence: float) -> float:
        """Calibration score hesapla"""
        signal_id = signal_data.get('signal_id', 'unknown')
        
        # Historical accuracy data
        if signal_id in self.performance_history:
            historical_performance = np.mean(self.performance_history[signal_id])
            
            # Calibration: how well predicted confidence matches actual performance
            calibration_error = abs(predicted_confidence - historical_performance)
            calibration_score = max(0.0, 1.0 - calibration_error)
            
            return calibration_score
        
        return 0.5  # Default calibration score
    
    def update_performance_history(self, signal_id: str, 
                                 predicted_confidence: float, 
                                 actual_performance: float):
        """
        Performance history'sini güncelle
        
        Args:
            signal_id: Signal ID
            predicted_confidence: Tahmin edilen confidence
            actual_performance: Gerçekleşen performans
        """
        if signal_id not in self.performance_history:
            self.performance_history[signal_id] = []
            self.confidence_history[signal_id] = []
        
        self.performance_history[signal_id].append(actual_performance)
        self.confidence_history[signal_id].append(predicted_confidence)
        
        # Calibration data
        if signal_id not in self.calibration_data:
            self.calibration_data[signal_id] = []
        
        self.calibration_data[signal_id].append((predicted_confidence, actual_performance))
        
        # Limit history size
        max_history = 100
        for key in [signal_id]:
            if len(self.performance_history[key]) > max_history:
                self.performance_history[key] = self.performance_history[key][-max_history:]
                self.confidence_history[key] = self.confidence_history[key][-max_history:]
    
    def calculate_confidence_adjusted_position_size(self, 
                                                  base_position_size: float,
                                                  confidence_metrics: ConfidenceMetrics,
                                                  max_leverage: float = 3.0) -> float:
        """
        Confidence-adjusted pozisyon boyutu hesapla
        
        Args:
            base_position_size: Temel pozisyon boyutu
            confidence_metrics: Confidence metrikleri
            max_leverage: Maksimum kaldıraç
        
        Returns:
            float: Confidence-adjusted pozisyon boyutu
        """
        overall_confidence = confidence_metrics.overall_confidence
        
        # Kelly Criterion style adjustment
        # Position size = Base size * (2 * confidence - 1)
        # This ensures confidence < 0.5 reduces position size
        
        confidence_multiplier = max(0.0, 2 * overall_confidence - 1.0)
        
        # Additional adjustments
        uncertainty_penalty = confidence_metrics.uncertainty_score * 0.5
        calibration_adjustment = confidence_metrics.calibration_score
        
        # Final position size
        adjusted_size = (
            base_position_size * 
            confidence_multiplier * 
            (1 - uncertainty_penalty) * 
            calibration_adjustment
        )
        
        # Apply leverage limits
        adjusted_size = min(adjusted_size, base_position_size * max_leverage)
        adjusted_size = max(adjusted_size, 0.0)  # No short positions in this model
        
        return adjusted_size
    
    def batch_calculate_confidence(self, signals_data: List[Dict[str, Any]]) -> Dict[str, ConfidenceMetrics]:
        """
        Birden fazla signal için confidence hesapla
        
        Args:
            signals_data: Sinyal verileri listesi
        
        Returns:
            Dict[str, ConfidenceMetrics]: Signal ID -> Confidence metrics mapping
        """
        confidence_results = {}
        
        for signal_data in signals_data:
            signal_id = signal_data.get('signal_id', f'signal_{len(confidence_results)}')
            
            try:
                confidence_metrics = self.calculate_signal_confidence(signal_data)
                confidence_results[signal_id] = confidence_metrics
                
            except Exception as e:
                print(f"Signal {signal_id} confidence hesaplama hatası: {e}")
                
                # Default confidence metrics
                confidence_results[signal_id] = ConfidenceMetrics(
                    overall_confidence=0.5,
                    signal_confidence=0.5,
                    model_confidence=0.5,
                    regime_confidence=0.5,
                    performance_confidence=0.5,
                    volatility_confidence=0.5,
                    correlation_confidence=0.5,
                    confidence_level=ConfidenceLevel.MODERATE,
                    uncertainty_score=0.5,
                    confidence_interval=(0.25, 0.75),
                    calibration_score=0.5
                )
        
        return confidence_results
    
    def generate_confidence_report(self, signals_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Kapsamlı confidence raporu oluştur
        
        Args:
            signals_data: Sinyal verileri
        
        Returns:
            Dict[str, Any]: Confidence raporu
        """
        # Batch confidence calculation
        confidence_results = self.batch_calculate_confidence(signals_data)
        
        # Portfolio confidence metrics
        portfolio_confidence = self._calculate_portfolio_confidence(confidence_results)
        
        # Risk assessment
        risk_assessment = self._assess_confidence_risks(confidence_results)
        
        # Recommendations
        recommendations = self._generate_confidence_recommendations(confidence_results)
        
        # Calibration analysis
        calibration_analysis = self._analyze_calibration(confidence_results)
        
        return {
            'timestamp': pd.Timestamp.now().isoformat(),
            'total_signals': len(signals_data),
            'confidence_summary': {
                'average_confidence': np.mean([m.overall_confidence for m in confidence_results.values()]),
                'confidence_std': np.std([m.overall_confidence for m in confidence_results.values()]),
                'high_confidence_signals': len([m for m in confidence_results.values() if m.overall_confidence > 0.7]),
                'low_confidence_signals': len([m for m in confidence_results.values() if m.overall_confidence < 0.3]),
                'confidence_distribution': {
                    level.value: len([m for m in confidence_results.values() if m.confidence_level == level])
                    for level in ConfidenceLevel
                }
            },
            'portfolio_confidence': portfolio_confidence,
            'signal_details': {
                signal_id: {
                    'overall_confidence': metrics.overall_confidence,
                    'confidence_level': metrics.confidence_level.value,
                    'uncertainty_score': metrics.uncertainty_score,
                    'confidence_interval': metrics.confidence_interval,
                    'calibration_score': metrics.calibration_score,
                    'component_scores': {
                        'signal_confidence': metrics.signal_confidence,
                        'model_confidence': metrics.model_confidence,
                        'regime_confidence': metrics.regime_confidence,
                        'performance_confidence': metrics.performance_confidence,
                        'volatility_confidence': metrics.volatility_confidence,
                        'correlation_confidence': metrics.correlation_confidence
                    }
                }
                for signal_id, metrics in confidence_results.items()
            },
            'risk_assessment': risk_assessment,
            'recommendations': recommendations,
            'calibration_analysis': calibration_analysis
        }
    
    def _calculate_portfolio_confidence(self, 
                                      confidence_results: Dict[str, ConfidenceMetrics]) -> Dict[str, float]:
        """Portföy confidence metriklerini hesapla"""
        if not confidence_results:
            return {}
        
        confidences = [m.overall_confidence for m in confidence_results.values()]
        
        return {
            'weighted_avg_confidence': np.average(confidences),
            'min_confidence': np.min(confidences),
            'max_confidence': np.max(confidences),
            'confidence_coefficient_of_variation': np.std(confidences) / (np.mean(confidences) + 1e-8),
            'high_confidence_coverage': np.mean([1 if c > 0.6 else 0 for c in confidences])
        }
    
    def _assess_confidence_risks(self, 
                               confidence_results: Dict[str, ConfidenceMetrics]) -> Dict[str, Any]:
        """Confidence risklerini değerlendir"""
        confidences = [m.overall_confidence for m in confidence_results.values()]
        
        return {
            'low_confidence_risk': np.mean([1 if c < 0.3 else 0 for c in confidences]),
            'high_uncertainty_risk': np.mean([1 if m.uncertainty_score > 0.7 else 0 for m in confidence_results.values()]),
            'calibration_risk': np.mean([1 if m.calibration_score < 0.5 else 0 for m in confidence_results.values()]),
            'confidence_concentration_risk': np.std(confidences) > 0.3,
            'overall_risk_score': np.mean([m.uncertainty_score for m in confidence_results.values()])
        }
    
    def _generate_confidence_recommendations(self, 
                                           confidence_results: Dict[str, ConfidenceMetrics]) -> List[str]:
        """Confidence-based öneriler oluştur"""
        recommendations = []
        
        # Low confidence signals
        low_conf_signals = [sid for sid, m in confidence_results.items() if m.overall_confidence < 0.3]
        if low_conf_signals:
            recommendations.append(
                f"Düşük confidence sinyaller: {', '.join(low_conf_signals[:5])} - pozisyon boyutlarını küçültün"
            )
        
        # High uncertainty signals
        high_uncertainty = [sid for sid, m in confidence_results.items() if m.uncertainty_score > 0.7]
        if high_uncertainty:
            recommendations.append(
                f"Yüksek belirsizlik: {', '.join(high_uncertainty[:5])} - ek doğrulama gerekli"
            )
        
        # Calibration issues
        poor_calibration = [sid for sid, m in confidence_results.items() if m.calibration_score < 0.5]
        if poor_calibration:
            recommendations.append(
                f"Kalibrasyon sorunu: {', '.join(poor_calibration[:5])} - model ayarlaması gerekli"
            )
        
        # Portfolio concentration
        confidences = [m.overall_confidence for m in confidence_results.values()]
        if len(confidences) > 0 and np.std(confidences) > 0.3:
            recommendations.append(
                "Portföy confidence dağılımı dengesiz - çeşitlendirme düşünün"
            )
        
        if not recommendations:
            recommendations.append("Confidence seviyeleri genel olarak dengeli")
        
        return recommendations
    
    def _analyze_calibration(self, 
                           confidence_results: Dict[str, ConfidenceMetrics]) -> Dict[str, Any]:
        """Kalibrasyon analizi yap"""
        calibration_scores = [m.calibration_score for m in confidence_results.values()]
        
        return {
            'average_calibration_score': np.mean(calibration_scores),
            'calibration_std': np.std(calibration_scores),
            'well_calibrated_signals': len([s for s in calibration_scores if s > 0.6]),
            'poorly_calibrated_signals': len([s for s in calibration_scores if s < 0.4]),
            'calibration_trend': "İyileşiyor" if len(calibration_scores) > 10 and 
                                np.mean(calibration_scores[-10:]) > np.mean(calibration_scores[:-10]) else "Dengeli"
        }
    
    def update_confidence_weights(self, new_weights: Dict[str, float]):
        """
        Confidence weight'ları güncelle
        
        Args:
            new_weights: Yeni ağırlıklar
        """
        total_weight = sum(new_weights.values())
        if abs(total_weight - 1.0) > 1e-6:
            print(f"Uyarı: Ağırlıklar toplamı {total_weight:.3f} - normalize ediliyor")
            new_weights = {k: v/total_weight for k, v in new_weights.items()}
        
        self.confidence_weights.update(new_weights)
        print(f"Confidence ağırlıkları güncellendi: {new_weights}")


# Test fonksiyonu
def test_signal_confidence_integrator():
    """Test signal confidence integrator"""
    
    # Synthetic signal data oluştur
    signals_data = []
    
    for i in range(10):
        signal_data = {
            'signal_id': f'signal_{i:03d}',
            'signal_type': 'momentum',
            'asset': f'ASSET_{i % 5}',
            'signal_score': np.random.uniform(0.3, 0.9),
            'model_outputs': {
                'model1': np.random.uniform(0.4, 0.8),
                'model2': np.random.uniform(0.3, 0.7),
                'model3': np.random.uniform(0.5, 0.9)
            },
            'market_regime': np.random.choice(['trending_bull', 'sideways', 'high_volatility']),
            'historical_returns': np.random.normal(0.001, 0.02, 50),
            'position_size': np.random.uniform(0.05, 0.15),
            'score_variance': np.random.uniform(0, 0.2),
            'model_quality_score': np.random.uniform(0.6, 0.9),
            'regime_stability': np.random.uniform(0.5, 0.8)
        }
        signals_data.append(signal_data)
    
    # Signal confidence integrator test et
    integrator = SignalConfidenceIntegrator()
    
    # Individual signal confidence test
    test_signal = signals_data[0]
    confidence_metrics = integrator.calculate_signal_confidence(test_signal)
    
    print(f"Signal {test_signal['signal_id']} Confidence Analysis:")
    print(f"Overall Confidence: {confidence_metrics.overall_confidence:.3f}")
    print(f"Confidence Level: {confidence_metrics.confidence_level.value}")
    print(f"Uncertainty Score: {confidence_metrics.uncertainty_score:.3f}")
    print(f"Confidence Interval: {confidence_metrics.confidence_interval}")
    print(f"Calibration Score: {confidence_metrics.calibration_score:.3f}")
    
    # Component scores
    print("\nComponent Scores:")
    print(f"Signal Confidence: {confidence_metrics.signal_confidence:.3f}")
    print(f"Model Confidence: {confidence_metrics.model_confidence:.3f}")
    print(f"Regime Confidence: {confidence_metrics.regime_confidence:.3f}")
    print(f"Performance Confidence: {confidence_metrics.performance_confidence:.3f}")
    
    # Position sizing adjustment
    base_size = 10000
    adjusted_size = integrator.calculate_confidence_adjusted_position_size(
        base_size, confidence_metrics
    )
    
    print(f"\nPosition Sizing:")
    print(f"Base Size: ${base_size:,.0f}")
    print(f"Adjusted Size: ${adjusted_size:,.0f}")
    print(f"Adjustment Ratio: {adjusted_size/base_size:.3f}")
    
    # Batch processing
    confidence_results = integrator.batch_calculate_confidence(signals_data)
    
    print(f"\nBatch Processing Results:")
    print(f"Processed {len(confidence_results)} signals")
    print(f"Average Confidence: {np.mean([m.overall_confidence for m in confidence_results.values()]):.3f}")
    
    # Comprehensive report
    report = integrator.generate_confidence_report(signals_data)
    
    print("\nConfidence Summary:")
    summary = report['confidence_summary']
    print(f"Average Confidence: {summary['average_confidence']:.3f}")
    print(f"High Confidence Signals: {summary['high_confidence_signals']}")
    print(f"Low Confidence Signals: {summary['low_confidence_signals']}")
    
    print("\nRecommendations:")
    for rec in report['recommendations']:
        print(f"- {rec}")
    
    return integrator, report


if __name__ == "__main__":
    test_signal_confidence_integrator()