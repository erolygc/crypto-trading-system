"""
Dinamik Pozisyon Boyutlandırma Coordinator Modülü
===============================================

Tüm risk yönetimi bileşenlerini entegre eden ana koordinatör sistem.

Dynamic Position Sizing Coordinator:
- Tüm alt sistemleri koordine eder
- Centralized configuration yönetimi sağlar
- Comprehensive reporting sunar
- Real-time monitoring ve alerting yapar
- Performance tracking ve analytics sağlar
- Backward compatibility ensures
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Union, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import json
import warnings

# Import all risk management modules
from .atr_volatility import ATRVolatilityTargeter, ATRConfig
from .risk_parity import RiskParityModel, RiskParityConfig
from .signal_confidence import SignalConfidenceIntegrator
from .dynamic_sizer import DynamicPositionSizer, PositionSizingConfig, PositionSizingMethod
from .portfolio_constraints import PortfolioRiskConstraints, PortfolioConstraints
from .real_time_adjuster import RealTimeAdjuster
from .kelly_criterion import KellyCriterionOptimizer, KellyConfig, KellyMethod
from .backward_compatibility import BackwardCompatibilityManager, LegacyAccountConfig, LegacySignal

warnings.filterwarnings('ignore')


class SystemMode(Enum):
    """Sistem modları"""
    BACKWARD_COMPATIBLE = "backward_compatible"
    HYBRID_ADAPTIVE = "hybrid_adaptive"
    FULLY_DYNAMIC = "fully_dynamic"
    KELLY_OPTIMIZED = "kelly_optimized"
    CONSERVATIVE = "conservative"
    TESTING = "testing"


class AlertLevel(Enum):
    """Alert seviyeleri"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


@dataclass
class SystemConfig:
    """Ana sistem konfigürasyonu"""
    # System mode
    system_mode: SystemMode = SystemMode.HYBRID_ADAPTIVE
    
    # Component configurations
    atr_config: ATRConfig = field(default_factory=ATRConfig)
    risk_parity_config: RiskParityConfig = field(default_factory=RiskParityConfig)
    sizing_config: PositionSizingConfig = field(default_factory=PositionSizingConfig)
    portfolio_config: PortfolioConstraints = field(default_factory=PortfolioConstraints)
    kelly_config: KellyConfig = field(default_factory=KellyConfig)
    
    # Real-time settings
    real_time_monitoring: bool = True
    update_frequency: float = 1.0  # seconds
    alert_threshold: float = 0.8
    
    # Performance settings
    enable_backtesting: bool = True
    enable_performance_tracking: bool = True
    enable_risk_monitoring: bool = True
    
    # Legacy settings
    legacy_mode: bool = False
    maintain_backward_compatibility: bool = True
    
    # Integration settings
    signal_source: str = "internal"  # internal, external, mixed
    market_data_source: str = "live"  # live, historical, simulated
    
    # Logging and monitoring
    log_level: str = "INFO"
    enable_detailed_logging: bool = False
    performance_monitoring_interval: int = 60  # seconds


@dataclass
class SystemStatus:
    """Sistem durumu"""
    is_running: bool
    start_time: datetime
    last_update: datetime
    total_operations: int
    active_components: List[str]
    system_health: str
    performance_metrics: Dict[str, Any]
    error_count: int
    warning_count: int


@dataclass
class IntegrationResult:
    """Entegrasyon sonucu"""
    signal_id: str
    timestamp: datetime
    processing_time_ms: float
    position_size_result: Any
    risk_analysis: Dict[str, Any]
    compliance_check: Dict[str, Any]
    recommendations: List[str]
    warnings: List[str]
    success: bool
    error_message: Optional[str] = None


class DynamicPositionSizingCoordinator:
    """
    Dynamic Position Sizing Coordinator
    
    Tüm risk yönetimi bileşenlerini koordine eden ana sistem.
    """
    
    def __init__(self, config: Optional[SystemConfig] = None):
        """
        Coordinator başlat
        
        Args:
            config: Sistem konfigürasyonu
        """
        self.config = config or SystemConfig()
        
        # Initialize components
        self.atr_targeter = ATRVolatilityTargeter(self.config.atr_config)
        self.risk_parity_model = RiskParityModel(self.config.risk_parity_config)
        self.confidence_integrator = SignalConfidenceIntegrator()
        self.dynamic_sizer = DynamicPositionSizer(self.config.sizing_config)
        self.portfolio_constraints = PortfolioRiskConstraints(self.config.portfolio_config)
        self.kelly_optimizer = KellyCriterionOptimizer(self.config.kelly_config)
        self.backward_compatibility = BackwardCompatibilityManager()
        
        # Real-time components
        if self.config.real_time_monitoring:
            self.real_time_adjuster = RealTimeAdjuster(
                update_frequency=self.config.update_frequency
            )
        else:
            self.real_time_adjuster = None
        
        # State tracking
        self.system_status = SystemStatus(
            is_running=False,
            start_time=datetime.now(),
            last_update=datetime.now(),
            total_operations=0,
            active_components=[],
            system_health="unknown",
            performance_metrics={},
            error_count=0,
            warning_count=0
        )
        
        # Processing history
        self.processing_history: List[IntegrationResult] = []
        self.performance_history: List[Dict[str, Any]] = []
        
        # Integration callbacks
        self.signal_processors: List[Callable] = []
        self.position_size_handlers: List[Callable] = []
        self.risk_monitors: List[Callable] = []
        self.alert_handlers: List[Callable] = []
        
        # Market data cache
        self.market_data_cache: Dict[str, pd.DataFrame] = {}
        self.last_data_update = datetime.now()
        
        # Setup system based on mode
        self._setup_system_mode()
    
    def _setup_system_mode(self):
        """Sistem moduna göre setup yap"""
        if self.config.system_mode == SystemMode.BACKWARD_COMPATIBLE:
            self.config.legacy_mode = True
            self.config.maintain_backward_compatibility = True
            self.dynamic_sizer.config.legacy_mode = True
            self.kelly_config.legacy_mode = True
            
        elif self.config.system_mode == SystemMode.KELLY_OPTIMIZED:
            self.dynamic_sizer.config.sizing_method = PositionSizingMethod.KELLY_CRITERION
            self.config.sizing_config.sizing_method = PositionSizingMethod.KELLY_CRITERION
            
        elif self.config.system_mode == SystemMode.CONSERVATIVE:
            self.config.sizing_config.fractional_multiplier = 0.15  # More conservative
            self.config.portfolio_config.max_position_size = 0.10  # Smaller positions
            self.kelly_config.fractional_multiplier = 0.15
            
        elif self.config.system_mode == SystemMode.FULLY_DYNAMIC:
            self.dynamic_sizer.config.sizing_method = PositionSizingMethod.HYBRID_ADAPTIVE
            self.config.real_time_monitoring = True
        
        print(f"System initialized in {self.config.system_mode.value} mode")
    
    def start_system(self):
        """Sistemi başlat"""
        if self.system_status.is_running:
            print("System already running")
            return
        
        self.system_status.is_running = True
        self.system_status.start_time = datetime.now()
        self.system_status.active_components = [
            'atr_targeter', 'risk_parity_model', 'confidence_integrator',
            'dynamic_sizer', 'portfolio_constraints', 'kelly_optimizer'
        ]
        
        if self.real_time_adjuster:
            self.real_time_adjuster.start_monitoring()
            self.system_status.active_components.append('real_time_adjuster')
        
        print("Dynamic Position Sizing System started successfully")
        print(f"Active components: {', '.join(self.system_status.active_components)}")
    
    def stop_system(self):
        """Sistemi durdur"""
        if not self.system_status.is_running:
            print("System not running")
            return
        
        self.system_status.is_running = False
        
        if self.real_time_adjuster:
            self.real_time_adjuster.stop_monitoring()
        
        print("Dynamic Position Sizing System stopped")
    
    def process_signal_comprehensive(self,
                                   signal_data: Dict[str, Any],
                                   portfolio_context: Dict[str, Any],
                                   market_data: Dict[str, pd.DataFrame]) -> IntegrationResult:
        """
        Sinyali kapsamlı şekilde işle
        
        Args:
            signal_data: Sinyal verisi
            portfolio_context: Portföy bağlamı
            market_data: Piyasa verisi
        
        Returns:
            IntegrationResult: Kapsamlı işleme sonucu
        """
        start_time = datetime.now()
        signal_id = signal_data.get('signal_id', 'unknown')
        
        try:
            # Update system metrics
            self.system_status.total_operations += 1
            self.system_status.last_update = datetime.now()
            
            # Process through backward compatibility if needed
            if self.config.legacy_mode:
                signal_data = self._ensure_legacy_compatibility(signal_data)
            
            # Update market data cache
            self._update_market_data_cache(market_data)
            
            # 1. Signal Confidence Analysis
            confidence_metrics = self.confidence_integrator.calculate_signal_confidence(signal_data)
            
            # 2. ATR Volatility Analysis
            atr_metrics = None
            asset = signal_data.get('asset', '')
            if asset in market_data:
                try:
                    atr_metrics = self.atr_targeter.analyze_asset_volatility(market_data[asset], asset)
                except Exception as e:
                    print(f"ATR analysis failed for {asset}: {e}")
            
            # 3. Kelly Criterion Optimization
            kelly_result = self.kelly_optimizer.calculate_kelly_for_signal(signal_data)
            
            # 4. Dynamic Position Sizing
            position_result = self.dynamic_sizer.calculate_position_size(
                signal_data, portfolio_context, market_data
            )
            
            # 5. Risk Parity Analysis
            risk_parity_weights = None
            try:
                if 'returns_data' in signal_data:
                    returns_df = pd.DataFrame(signal_data['returns_data'])
                    self.risk_parity_model.optimize_risk_parity_weights(returns_df)
                    risk_parity_weights = dict(zip(
                        self.risk_parity_model.assets,
                        self.risk_parity_model.optimal_weights
                    ))
            except Exception as e:
                print(f"Risk parity analysis failed: {e}")
            
            # 6. Portfolio Constraints Check
            constraints_violation = self._check_portfolio_constraints(
                position_result, portfolio_context
            )
            
            # 7. Real-time Adjustment (if enabled)
            real_time_adjustment = None
            if self.real_time_adjuster:
                real_time_adjustment = self._apply_real_time_adjustments(
                    signal_data, position_result
                )
            
            # Combine all analyses
            risk_analysis = self._combine_risk_analysis(
                confidence_metrics, atr_metrics, kelly_result, risk_parity_weights
            )
            
            # Compliance check
            compliance_check = self._perform_compliance_check(
                position_result, constraints_violation
            )
            
            # Generate recommendations
            recommendations = self._generate_comprehensive_recommendations(
                signal_data, position_result, risk_analysis, compliance_check
            )
            
            # Create integration result
            processing_time = (datetime.now() - start_time).total_seconds() * 1000
            
            result = IntegrationResult(
                signal_id=signal_id,
                timestamp=datetime.now(),
                processing_time_ms=processing_time,
                position_size_result=position_result,
                risk_analysis=risk_analysis,
                compliance_check=compliance_check,
                recommendations=recommendations,
                warnings=[],
                success=True
            )
            
            # Store in history
            self.processing_history.append(result)
            
            # Trigger callbacks
            self._trigger_processing_callbacks(result)
            
            return result
            
        except Exception as e:
            error_msg = f"Comprehensive signal processing failed for {signal_id}: {str(e)}"
            print(error_msg)
            
            self.system_status.error_count += 1
            
            return IntegrationResult(
                signal_id=signal_id,
                timestamp=datetime.now(),
                processing_time_ms=(datetime.now() - start_time).total_seconds() * 1000,
                position_size_result=None,
                risk_analysis={},
                compliance_check={},
                recommendations=["Processing error - manual review required"],
                warnings=[],
                success=False,
                error_message=str(e)
            )
    
    def _ensure_legacy_compatibility(self, signal_data: Dict[str, Any]) -> Dict[str, Any]:
        """Legacy uyumluluk sağla"""
        # Ensure required legacy fields exist
        if 'hedge_mode' not in signal_data:
            signal_data['hedge_mode'] = signal_data.get('legacy_hedge_mode', False)
        
        if 'quantity_multiplier' not in signal_data:
            signal_data['quantity_multiplier'] = signal_data.get('legacy_multiplier', 1.0)
        
        # Ensure model signal fields exist
        for i in range(1, 5):
            model_key = f'model_{i}_signal'
            if model_key not in signal_data:
                signal_data[model_key] = signal_data.get(f'model_{i}_output', 0.5)
        
        return signal_data
    
    def _update_market_data_cache(self, market_data: Dict[str, pd.DataFrame]):
        """Market data cache'ini güncelle"""
        current_time = datetime.now()
        
        for symbol, data in market_data.items():
            if symbol not in self.market_data_cache:
                self.market_data_cache[symbol] = pd.DataFrame()
            
            # Update cache with new data
            self.market_data_cache[symbol] = pd.concat([
                self.market_data_cache[symbol],
                data
            ]).drop_duplicates()
            
            # Keep only recent data (last 1000 rows)
            if len(self.market_data_cache[symbol]) > 1000:
                self.market_data_cache[symbol] = self.market_data_cache[symbol].tail(1000)
        
        self.last_data_update = current_time
    
    def _combine_risk_analysis(self,
                             confidence_metrics,
                             atr_metrics,
                             kelly_result,
                             risk_parity_weights) -> Dict[str, Any]:
        """Risk analizlerini combine et"""
        risk_analysis = {
            'confidence_analysis': {
                'overall_confidence': confidence_metrics.overall_confidence,
                'confidence_level': confidence_metrics.confidence_level.value,
                'uncertainty_score': confidence_metrics.uncertainty_score
            },
            'volatility_analysis': {},
            'kelly_analysis': {
                'kelly_fraction': kelly_result.kelly_fraction,
                'final_allocation': kelly_result.final_allocation,
                'expected_return': kelly_result.expected_return,
                'sharpe_kelly': kelly_result.sharpe_kelly
            },
            'risk_parity_analysis': {},
            'combined_risk_score': 0.0
        }
        
        # ATR analysis
        if atr_metrics:
            risk_analysis['volatility_analysis'] = {
                'current_atr': atr_metrics.current_atr,
                'normalized_atr': atr_metrics.normalized_atr,
                'volatility_ratio': atr_metrics.volatility_ratio,
                'market_regime': atr_metrics.regime.value,
                'position_multiplier': atr_metrics.position_multiplier,
                'risk_level': atr_metrics.risk_level
            }
        
        # Risk parity analysis
        if risk_parity_weights:
            risk_analysis['risk_parity_analysis'] = {
                'optimal_weights': risk_parity_weights,
                'num_assets': len(risk_parity_weights)
            }
        
        # Combined risk score (weighted average)
        confidence_score = confidence_metrics.overall_confidence
        volatility_score = 1.0 - (atr_metrics.volatility_ratio if atr_metrics else 1.0)
        kelly_score = min(kelly_result.final_allocation * 5, 1.0)  # Scale Kelly allocation
        
        risk_analysis['combined_risk_score'] = np.mean([
            confidence_score * 0.4,
            volatility_score * 0.3,
            kelly_score * 0.3
        ])
        
        return risk_analysis
    
    def _check_portfolio_constraints(self,
                                   position_result,
                                   portfolio_context: Dict[str, Any]) -> Dict[str, Any]:
        """Portföy kısıtlamalarını kontrol et"""
        try:
            # Update portfolio state for constraints
            current_positions = portfolio_context.get('current_positions', {})
            current_positions[position_result.asset] = position_result.final_size
            
            prices = portfolio_context.get('current_prices', {})
            if position_result.asset not in prices:
                prices[position_result.asset] = position_result.position_size_result.final_size / max(position_result.final_size, 1) * 100
            
            sectors = portfolio_context.get('asset_sectors', {position_result.asset: 'Unknown'})
            
            self.portfolio_constraints.update_portfolio_state(
                current_positions, prices, sectors
            )
            
            # Evaluate constraints
            constraints = self.portfolio_constraints.evaluate_constraints()
            
            violations = [c for c in constraints if c.status.value in ['breach', 'critical']]
            
            return {
                'total_constraints': len(constraints),
                'constraint_violations': len(violations),
                'violation_details': [
                    {
                        'name': c.name,
                        'current_value': c.current_value,
                        'limit_value': c.limit_value,
                        'severity': c.breach_severity
                    }
                    for c in violations
                ],
                'rebalancing_needed': len(violations) > 0
            }
            
        except Exception as e:
            return {
                'error': str(e),
                'constraint_violations': 0,
                'rebalancing_needed': False
            }
    
    def _apply_real_time_adjustments(self,
                                   signal_data: Dict[str, Any],
                                   position_result) -> Dict[str, Any]:
        """Real-time ayarlamaları uygula"""
        if not self.real_time_adjuster:
            return {}
        
        try:
            # Add position to real-time tracker
            self.real_time_adjuster.add_position(
                position_result.asset,
                position_result.final_size
            )
            
            # Check for immediate adjustments
            adjustments = self.real_time_adjuster.get_position_adjustments("pending")
            
            return {
                'pending_adjustments': len(adjustments),
                'adjustment_details': [
                    {
                        'asset': adj.asset,
                        'type': adj.adjustment_type.value,
                        'current': adj.current_position,
                        'target': adj.target_position,
                        'reason': adj.reason
                    }
                    for adj in adjustments
                ]
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def _perform_compliance_check(self,
                                position_result,
                                constraints_violation: Dict[str, Any]) -> Dict[str, Any]:
        """Compliance kontrolü yap"""
        compliance_score = 1.0
        
        # Reduce score for constraint violations
        if constraints_violation.get('constraint_violations', 0) > 0:
            violation_count = constraints_violation['constraint_violations']
            compliance_score = max(0.0, 1.0 - (violation_count * 0.2))
        
        # Check position size limits
        position_size_ok = position_result.final_size <= position_result.risk_adjusted_size
        
        return {
            'compliance_score': compliance_score,
            'position_size_compliant': position_size_ok,
            'constraints_compliant': constraints_violation.get('constraint_violations', 0) == 0,
            'overall_compliant': compliance_score > 0.8 and position_size_ok,
            'violation_count': constraints_violation.get('constraint_violations', 0)
        }
    
    def _generate_comprehensive_recommendations(self,
                                              signal_data: Dict[str, Any],
                                              position_result,
                                              risk_analysis: Dict[str, Any],
                                              compliance_check: Dict[str, Any]) -> List[str]:
        """Kapsamlı öneriler oluştur"""
        recommendations = []
        
        # Position size recommendations
        if position_result.final_size == 0:
            recommendations.append("Position size sıfır - sinyal kalitesi düşük olabilir")
        elif position_result.final_size > position_result.risk_adjusted_size:
            recommendations.append("Risk limitlerine yakın pozisyon boyutu - dikkatli monitoring gerekli")
        
        # Confidence-based recommendations
        confidence_score = risk_analysis['confidence_analysis']['overall_confidence']
        if confidence_score < 0.6:
            recommendations.append("Düşük confidence seviyesi - ek doğrulama gerekebilir")
        elif confidence_score > 0.8:
            recommendations.append("Yüksek confidence seviyesi - pozisyon artırımı değerlendirilebilir")
        
        # Volatility recommendations
        vol_analysis = risk_analysis.get('volatility_analysis', {})
        if vol_analysis.get('risk_level') == 'Çok Yüksek Risk':
            recommendations.append("Yüksek volatilite - pozisyon boyutunu küçültün")
        
        # Kelly recommendations
        kelly_analysis = risk_analysis.get('kelly_analysis', {})
        kelly_fraction = kelly_analysis.get('kelly_fraction', 0)
        if kelly_fraction > 0.4:
            recommendations.append("Yüksek Kelly fraction - risk yönetimi kritik")
        
        # Compliance recommendations
        if not compliance_check['overall_compliant']:
            recommendations.append("Compliance sorunları tespit edildi - pozisyon ayarlaması gerekli")
        
        # Real-time monitoring recommendations
        if self.real_time_adjuster:
            recommendations.append("Real-time monitoring aktif - sürekli risk takibi yapılıyor")
        
        if not recommendations:
            recommendations.append("Tüm analizler başarılı - mevcut pozisyon korunabilir")
        
        return recommendations
    
    def _trigger_processing_callbacks(self, result: IntegrationResult):
        """Processing callback'leri tetikle"""
        # Signal processors
        for processor in self.signal_processors:
            try:
                processor(result)
            except Exception as e:
                print(f"Signal processor callback error: {e}")
        
        # Position size handlers
        for handler in self.position_size_handlers:
            try:
                handler(result.position_size_result)
            except Exception as e:
                print(f"Position size handler callback error: {e}")
        
        # Risk monitors
        for monitor in self.risk_monitors:
            try:
                monitor(result.risk_analysis)
            except Exception as e:
                print(f"Risk monitor callback error: {e}")
    
    def batch_process_signals(self,
                            signals_data: List[Dict[str, Any]],
                            portfolio_context: Dict[str, Any],
                            market_data: Dict[str, pd.DataFrame]) -> List[IntegrationResult]:
        """
        Birden fazla signal'i batch process et
        
        Args:
            signals_data: Sinyal verileri
            portfolio_context: Portföy bağlamı
            market_data: Piyasa verisi
        
        Returns:
            List[IntegrationResult]: Processing sonuçları
        """
        results = []
        
        print(f"Processing {len(signals_data)} signals in batch...")
        
        for i, signal_data in enumerate(signals_data):
            try:
                result = self.process_signal_comprehensive(signal_data, portfolio_context, market_data)
                results.append(result)
                
                if (i + 1) % 10 == 0:
                    print(f"Processed {i + 1}/{len(signals_data)} signals")
                
            except Exception as e:
                print(f"Batch processing error for signal {i}: {e}")
                results.append(IntegrationResult(
                    signal_id=signal_data.get('signal_id', f'signal_{i}'),
                    timestamp=datetime.now(),
                    processing_time_ms=0,
                    position_size_result=None,
                    risk_analysis={},
                    compliance_check={},
                    recommendations=["Batch processing error"],
                    warnings=[],
                    success=False,
                    error_message=str(e)
                ))
        
        print(f"Batch processing completed: {len(results)} results")
        return results
    
    def generate_comprehensive_report(self,
                                    signals_data: List[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Kapsamlı sistem raporu oluştur
        
        Args:
            signals_data: İşlenen signal'lar (opsiyonel)
        
        Returns:
            Dict[str, Any]: Kapsamlı rapor
        """
        # System status
        uptime = datetime.now() - self.system_status.start_time
        
        # Component health
        component_health = self._assess_component_health()
        
        # Performance metrics
        performance_metrics = self._calculate_performance_metrics()
        
        # Risk summary
        risk_summary = self._generate_risk_summary()
        
        # Compliance summary
        compliance_summary = self._generate_compliance_summary()
        
        # Real-time status
        real_time_status = {}
        if self.real_time_adjuster:
            real_time_status = self.real_time_adjuster.get_real_time_status()
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'system_info': {
                'system_mode': self.config.system_mode.value,
                'uptime_hours': uptime.total_seconds() / 3600,
                'total_operations': self.system_status.total_operations,
                'is_running': self.system_status.is_running,
                'active_components': self.system_status.active_components
            },
            'system_health': {
                'overall_health': self.system_status.system_health,
                'component_health': component_health,
                'error_count': self.system_status.error_count,
                'warning_count': self.system_status.warning_count
            },
            'performance_metrics': performance_metrics,
            'risk_summary': risk_summary,
            'compliance_summary': compliance_summary,
            'real_time_status': real_time_status,
            'configuration': {
                'system_mode': self.config.system_mode.value,
                'legacy_mode': self.config.legacy_mode,
                'real_time_monitoring': self.config.real_time_monitoring,
                'sizing_method': self.config.sizing_config.sizing_method.value
            },
            'processing_statistics': {
                'total_processed': len(self.processing_history),
                'success_rate': len([r for r in self.processing_history if r.success]) / max(len(self.processing_history), 1),
                'avg_processing_time_ms': np.mean([r.processing_time_ms for r in self.processing_history[-100:]]) if self.processing_history else 0,
                'recent_results': [
                    {
                        'signal_id': r.signal_id,
                        'success': r.success,
                        'processing_time_ms': r.processing_time_ms,
                        'timestamp': r.timestamp.isoformat()
                    }
                    for r in self.processing_history[-10:]
                ]
            }
        }
        
        # Add signals data if provided
        if signals_data:
            report['signal_analysis'] = self._analyze_signals_data(signals_data)
        
        return report
    
    def _assess_component_health(self) -> Dict[str, str]:
        """Component sağlık durumunu değerlendir"""
        health_status = {}
        
        components = {
            'atr_targeter': self.atr_targeter,
            'risk_parity_model': self.risk_parity_model,
            'confidence_integrator': self.confidence_integrator,
            'dynamic_sizer': self.dynamic_sizer,
            'portfolio_constraints': self.portfolio_constraints,
            'kelly_optimizer': self.kelly_optimizer
        }
        
        for name, component in components.items():
            try:
                # Simple health check
                if component is not None:
                    health_status[name] = "healthy"
                else:
                    health_status[name] = "inactive"
            except Exception:
                health_status[name] = "error"
        
        if self.real_time_adjuster:
            health_status['real_time_adjuster'] = "healthy" if self.real_time_adjuster.is_running else "inactive"
        
        return health_status
    
    def _calculate_performance_metrics(self) -> Dict[str, Any]:
        """Performans metriklerini hesapla"""
        if not self.processing_history:
            return {}
        
        recent_results = self.processing_history[-100:]  # Last 100 operations
        
        processing_times = [r.processing_time_ms for r in recent_results]
        success_rate = len([r for r in recent_results if r.success]) / len(recent_results)
        
        return {
            'avg_processing_time_ms': np.mean(processing_times),
            'processing_time_std_ms': np.std(processing_times),
            'success_rate': success_rate,
            'error_rate': 1 - success_rate,
            'total_operations': len(self.processing_history),
            'recent_operations': len(recent_results)
        }
    
    def _generate_risk_summary(self) -> Dict[str, Any]:
        """Risk özeti oluştur"""
        if not self.processing_history:
            return {'message': 'No processing history available'}
        
        recent_results = self.processing_history[-50:]
        successful_results = [r for r in recent_results if r.success and r.risk_analysis]
        
        if not successful_results:
            return {'message': 'No successful risk analyses available'}
        
        # Aggregate risk metrics
        confidence_scores = []
        kelly_fractions = []
        combined_risk_scores = []
        
        for result in successful_results:
            risk_analysis = result.risk_analysis
            
            if 'confidence_analysis' in risk_analysis:
                confidence_scores.append(risk_analysis['confidence_analysis']['overall_confidence'])
            
            if 'kelly_analysis' in risk_analysis:
                kelly_fractions.append(risk_analysis['kelly_analysis']['kelly_fraction'])
            
            if 'combined_risk_score' in risk_analysis:
                combined_risk_scores.append(risk_analysis['combined_risk_score'])
        
        return {
            'avg_confidence_score': np.mean(confidence_scores) if confidence_scores else 0,
            'avg_kelly_fraction': np.mean(kelly_fractions) if kelly_fractions else 0,
            'avg_combined_risk_score': np.mean(combined_risk_scores) if combined_risk_scores else 0,
            'high_risk_signals': len([score for score in confidence_scores if score < 0.5]),
            'risk_analysis_count': len(successful_results)
        }
    
    def _generate_compliance_summary(self) -> Dict[str, Any]:
        """Compliance özeti oluştur"""
        if not self.processing_history:
            return {'message': 'No compliance data available'}
        
        recent_results = self.processing_history[-50:]
        compliant_results = [r for r in recent_results if r.compliance_check.get('overall_compliant', False)]
        
        return {
            'compliance_rate': len(compliant_results) / len(recent_results),
            'total_violations': sum(r.compliance_check.get('violation_count', 0) for r in recent_results),
            'avg_compliance_score': np.mean([r.compliance_check.get('compliance_score', 0) for r in recent_results]),
            'non_compliant_signals': len([r for r in recent_results if not r.compliance_check.get('overall_compliant', True)])
        }
    
    def _analyze_signals_data(self, signals_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Signals data analizi yap"""
        if not signals_data:
            return {}
        
        # Basic statistics
        signal_assets = [s.get('asset', 'Unknown') for s in signals_data]
        signal_scores = [s.get('signal_score', 0.5) for s in signals_data]
        hedge_mode_count = len([s for s in signals_data if s.get('hedge_mode', False)])
        
        return {
            'total_signals': len(signals_data),
            'unique_assets': len(set(signal_assets)),
            'avg_signal_score': np.mean(signal_scores),
            'signal_score_std': np.std(signal_scores),
            'hedge_mode_signals': hedge_mode_count,
            'hedge_mode_percentage': hedge_mode_count / len(signals_data) * 100,
            'asset_distribution': {asset: signal_assets.count(asset) for asset in set(signal_assets)}
        }
    
    def register_callback(self, callback_type: str, callback: Callable):
        """Callback kaydet"""
        if callback_type == 'signal_processor':
            self.signal_processors.append(callback)
        elif callback_type == 'position_size_handler':
            self.position_size_handlers.append(callback)
        elif callback_type == 'risk_monitor':
            self.risk_monitors.append(callback)
        elif callback_type == 'alert_handler':
            self.alert_handlers.append(callback)
        else:
            print(f"Unknown callback type: {callback_type}")
    
    def get_system_status(self) -> SystemStatus:
        """Sistem durumunu getir"""
        return self.system_status
    
    def update_configuration(self, new_config: SystemConfig):
        """Konfigürasyonu güncelle"""
        self.config = new_config
        
        # Update component configurations
        self.atr_targeter = ATRVolatilityTargeter(new_config.atr_config)
        self.risk_parity_model = RiskParityModel(new_config.risk_parity_config)
        self.dynamic_sizer = DynamicPositionSizer(new_config.sizing_config)
        self.portfolio_constraints = PortfolioRiskConstraints(new_config.portfolio_config)
        self.kelly_optimizer = KellyCriterionOptimizer(new_config.kelly_config)
        
        print("System configuration updated")
    
    def export_configuration(self, filepath: str):
        """Konfigürasyonu dosyaya export et"""
        config_dict = {
            'system_mode': self.config.system_mode.value,
            'real_time_monitoring': self.config.real_time_monitoring,
            'update_frequency': self.config.update_frequency,
            'legacy_mode': self.config.legacy_mode,
            'enable_backtesting': self.config.enable_backtesting,
            'enable_performance_tracking': self.config.enable_performance_tracking
        }
        
        with open(filepath, 'w') as f:
            json.dump(config_dict, f, indent=2)
        
        print(f"Configuration exported to {filepath}")


# Test fonksiyonu
def test_dynamic_position_sizing_coordinator():
    """Dynamic Position Sizing Coordinator test fonksiyonu"""
    
    # Test configuration
    config = SystemConfig(
        system_mode=SystemMode.HYBRID_ADAPTIVE,
        real_time_monitoring=True,
        update_frequency=0.1,  # Fast for testing
        legacy_mode=True
    )
    
    coordinator = DynamicPositionSizingCoordinator(config)
    
    # Start system
    coordinator.start_system()
    
    # Test data
    signal_data = {
        'signal_id': 'test_signal_001',
        'asset': 'AAPL',
        'signal_score': 0.75,
        'hedge_mode': True,
        'quantity_multiplier': 2.0,
        'historical_returns': np.random.normal(0.001, 0.02, 50),
        'model_1_signal': 0.7,
        'model_2_signal': 0.8,
        'model_3_signal': 0.6,
        'model_4_signal': 0.9
    }
    
    portfolio_context = {
        'account_value': 100000,
        'available_cash': 20000,
        'current_positions': {'AAPL': 5000},
        'asset_sectors': {'AAPL': 'Technology'}
    }
    
    # Create market data
    dates = pd.date_range(start='2023-01-01', periods=100, freq='D')
    market_data = {
        'AAPL': pd.DataFrame({
            'high': np.random.uniform(145, 155, 100),
            'low': np.random.uniform(140, 150, 100),
            'close': np.random.uniform(142, 152, 100),
            'volume': np.random.randint(1000000, 5000000, 100)
        }, index=dates)
    }
    
    # Test comprehensive processing
    print("=== Comprehensive Signal Processing ===")
    result = coordinator.process_signal_comprehensive(signal_data, portfolio_context, market_data)
    
    print(f"Signal ID: {result.signal_id}")
    print(f"Success: {result.success}")
    print(f"Processing Time: {result.processing_time_ms:.2f}ms")
    
    if result.success:
        position_result = result.position_size_result
        print(f"Final Position Size: ${position_result.final_size:,.0f}")
        print(f"Method Used: {position_result.method_used.value}")
        print(f"Action: {position_result.action.value}")
        
        print("\nRisk Analysis:")
        risk_analysis = result.risk_analysis
        for key, value in risk_analysis.items():
            if isinstance(value, dict):
                print(f"  {key}: {value}")
            else:
                print(f"  {key}: {value}")
        
        print("\nRecommendations:")
        for rec in result.recommendations:
            print(f"  - {rec}")
    
    # Test batch processing
    print("\n=== Batch Processing Test ===")
    signals_data = [signal_data] * 5
    batch_results = coordinator.batch_process_signals(signals_data, portfolio_context, market_data)
    
    successful_results = [r for r in batch_results if r.success]
    print(f"Batch Results: {len(batch_results)} total, {len(successful_results)} successful")
    
    # Generate comprehensive report
    print("\n=== Comprehensive Report ===")
    report = coordinator.generate_comprehensive_report(signals_data)
    
    print(f"System Uptime: {report['system_info']['uptime_hours']:.2f} hours")
    print(f"Total Operations: {report['system_info']['total_operations']}")
    print(f"Success Rate: {report['processing_statistics']['success_rate']:.1%}")
    print(f"Avg Processing Time: {report['performance_metrics']['avg_processing_time_ms']:.2f}ms")
    
    print("\nSystem Health:")
    for component, health in report['system_health']['component_health'].items():
        print(f"  {component}: {health}")
    
    # Stop system
    coordinator.stop_system()
    
    return coordinator, report


if __name__ == "__main__":
    test_dynamic_position_sizing_coordinator()