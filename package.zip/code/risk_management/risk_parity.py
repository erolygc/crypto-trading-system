"""
Risk-Paritesi Modeli
===================

Risk-paritesi (Risk Parity) modeli, portföy yönetiminde riskin eşit 
dağılımını hedefleyen gelişmiş portföy optimizasyon yaklaşımı.

Risk-paritesi prensibi:
- Her varlığın portföydeki risk katkısı eşitlenir
- Sermaye tahsisi yerine risk tahsisi yapılır
- Volatilite ve korelasyon matrisini optimize eder
- Daha stabil ve risk-ayarlı getiri profili sağlar
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from scipy.optimize import minimize
from scipy.stats import norm
import warnings

warnings.filterwarnings('ignore')


@dataclass
class RiskParityConfig:
    """Risk-paritesi konfigürasyonu"""
    target_risk_contribution: float = 0.1  # Her varlık için %10 risk katkısı
    max_iterations: int = 1000
    risk_tolerance: float = 1e-6
    leverage_limit: float = 3.0
    min_weight: float = 0.01  # Minimum pozisyon boyutu
    max_weight: float = 0.5   # Maximum pozisyon boyutu
    correlation_threshold: float = 0.7  # Yüksek korelasyon eşiği


@dataclass
class RiskContribution:
    """Risk katkısı bilgisi"""
    asset: str
    weight: float
    volatility: float
    marginal_contribution: float
    percentage_contribution: float
    is_target: bool
    adjustment_needed: float


class RiskParityModel:
    """
    Risk-Paritesi Modeli
    
    Risk-paritesi prensipleriyle portföy optimizasyonu yapan sınıf.
    """
    
    def __init__(self, config: Optional[RiskParityConfig] = None):
        """
        Risk-Paritesi modeli başlat
        
        Args:
            config: Risk-paritesi konfigürasyonu
        """
        self.config = config or RiskParityConfig()
        self.assets: List[str] = []
        self.covariance_matrix: Optional[np.ndarray] = None
        self.correlation_matrix: Optional[np.ndarray] = None
        self.optimal_weights: Optional[np.ndarray] = None
        self.risk_contributions: List[RiskContribution] = []
        
    def calculate_covariance_matrix(self, returns: pd.DataFrame) -> np.ndarray:
        """
        Kovaryans matrisi hesapla
        
        Args:
            returns: Getiri serileri (varlık bazında)
        
        Returns:
            np.ndarray: Kovaryans matrisi
        """
        return returns.cov().values
    
    def calculate_correlation_matrix(self, returns: pd.DataFrame) -> np.ndarray:
        """
        Korelasyon matrisi hesapla
        
        Args:
            returns: Getiri serileri
        
        Returns:
            np.ndarray: Korelasyon matrisi
        """
        return returns.corr().values
    
    def calculate_portfolio_volatility(self, weights: np.ndarray, 
                                     cov_matrix: np.ndarray) -> float:
        """
        Portföy volatilitesini hesapla
        
        Args:
            weights: Ağırlıklar
            cov_matrix: Kovaryans matrisi
        
        Returns:
            float: Portföy volatilitesi
        """
        return np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
    
    def calculate_risk_contributions(self, weights: np.ndarray, 
                                   cov_matrix: np.ndarray) -> np.ndarray:
        """
        Risk katkılarını hesapla
        
        Args:
            weights: Ağırlıklar
            cov_matrix: Kovaryans matrisi
        
        Returns:
            np.ndarray: Her varlığın risk katkısı
        """
        portfolio_vol = self.calculate_portfolio_volatility(weights, cov_matrix)
        if portfolio_vol == 0:
            return np.zeros(len(weights))
        
        # Marginal risk contribution
        marginal_contrib = np.dot(cov_matrix, weights) / portfolio_vol
        
        # Risk contributions (weights * marginal_contrib)
        risk_contrib = weights * marginal_contrib
        
        return risk_contrib
    
    def calculate_risk_parity_objective(self, weights: np.ndarray, 
                                      cov_matrix: np.ndarray,
                                      target_contribution: float) -> float:
        """
        Risk-paritesi objektif fonksiyonu
        
        Args:
            weights: Ağırlıklar
            cov_matrix: Kovaryans matrisi
            target_contribution: Hedef risk katkısı
        
        Returns:
            float: Objektif fonksiyon değeri
        """
        n_assets = len(weights)
        risk_contrib = self.calculate_risk_contributions(weights, cov_matrix)
        
        # Risk-paritesi hatası: her varlığın risk katkısı hedef katkıya ne kadar uzak
        target_vector = np.full(n_assets, target_contribution)
        return np.sum((risk_contrib - target_vector) ** 2)
    
    def optimize_risk_parity_weights(self, returns: pd.DataFrame) -> np.ndarray:
        """
        Risk-paritesi ağırlıklarını optimize et
        
        Args:
            returns: Getiri serileri
        
        Returns:
            np.ndarray: Optimal ağırlıklar
        """
        self.assets = list(returns.columns)
        n_assets = len(self.assets)
        
        # Kovaryans matrisi
        self.covariance_matrix = self.calculate_covariance_matrix(returns)
        self.correlation_matrix = self.calculate_correlation_matrix(returns)
        
        # Başlangıç ağırlıkları (eşit ağırlıklı)
        initial_weights = np.full(n_assets, 1.0 / n_assets)
        
        # Constraints
        constraints = [
            {'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0}  # Ağırlıklar toplamı = 1
        ]
        
        # Bounds (minimum ve maksimum ağırlıklar)
        bounds = tuple((self.config.min_weight, self.config.max_weight) 
                      for _ in range(n_assets))
        
        # Optimization
        result = minimize(
            fun=self.calculate_risk_parity_objective,
            x0=initial_weights,
            args=(self.covariance_matrix, self.config.target_risk_contribution),
            method='SLSQP',
            bounds=bounds,
            constraints=constraints,
            options={'maxiter': self.config.max_iterations}
        )
        
        if result.success:
            self.optimal_weights = result.x
        else:
            # Optimization başarısız olursa eşit ağırlıklar kullan
            self.optimal_weights = initial_weights
            print(f"Risk-paritesi optimizasyonu başarısız: {result.message}")
        
        return self.optimal_weights
    
    def analyze_risk_contributions(self, weights: Optional[np.ndarray] = None) -> List[RiskContribution]:
        """
        Risk katkılarını analiz et
        
        Args:
            weights: Kullanılacak ağırlıklar (eğer None ise optimal weights kullan)
        
        Returns:
            List[RiskContribution]: Risk katkı analizi
        """
        if weights is None:
            weights = self.optimal_weights
            
        if weights is None or self.covariance_matrix is None:
            raise ValueError("Önce optimal ağırlıkları hesaplayın")
        
        # Risk katkılarını hesapla
        risk_contrib_values = self.calculate_risk_contributions(weights, self.covariance_matrix)
        portfolio_vol = self.calculate_portfolio_volatility(weights, self.covariance_matrix)
        
        # Risk katkı yüzdeleri
        risk_contrib_percentages = risk_contrib_values / portfolio_vol if portfolio_vol > 0 else np.zeros(len(risk_contrib_values))
        
        self.risk_contributions = []
        
        for i, asset in enumerate(self.assets):
            contribution = RiskContribution(
                asset=asset,
                weight=weights[i],
                volatility=np.sqrt(self.covariance_matrix[i, i]),
                marginal_contribution=risk_contrib_values[i],
                percentage_contribution=risk_contrib_percentages[i],
                is_target=abs(risk_contrib_percentages[i] - self.config.target_risk_contribution) < 0.05,
                adjustment_needed=risk_contrib_percentages[i] - self.config.target_risk_contribution
            )
            self.risk_contributions.append(contribution)
        
        return self.risk_contributions
    
    def calculate_portfolio_metrics(self, returns: pd.DataFrame, 
                                  weights: Optional[np.ndarray] = None) -> Dict[str, float]:
        """
        Portföy metriklerini hesapla
        
        Args:
            returns: Getiri serileri
            weights: Portföy ağırlıkları
        
        Returns:
            Dict[str, float]: Portföy metrikleri
        """
        if weights is None:
            weights = self.optimal_weights
            
        if weights is None:
            raise ValueError("Ağırlıklar belirtilmedi")
        
        # Portföy getirileri
        portfolio_returns = (returns * weights).sum(axis=1)
        
        # Metrikler
        metrics = {
            'annual_return': portfolio_returns.mean() * 252,
            'annual_volatility': portfolio_returns.std() * np.sqrt(252),
            'sharpe_ratio': (portfolio_returns.mean() * 252) / (portfolio_returns.std() * np.sqrt(252)) if portfolio_returns.std() > 0 else 0,
            'max_drawdown': self._calculate_max_drawdown(portfolio_returns),
            'win_rate': (portfolio_returns > 0).mean(),
            'value_at_risk_95': np.percentile(portfolio_returns, 5),
            'conditional_var_95': np.mean(portfolio_returns[portfolio_returns <= np.percentile(portfolio_returns, 5)])
        }
        
        return metrics
    
    def _calculate_max_drawdown(self, returns: pd.Series) -> float:
        """Maximum drawdown hesapla"""
        cumulative = (1 + returns).cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        return drawdown.min()
    
    def identify_risk_concentrations(self) -> Dict[str, Any]:
        """
        Risk yoğunlaşmalarını tespit et
        
        Returns:
            Dict[str, Any]: Risk konsantrasyon analizi
        """
        if not self.risk_contributions:
            raise ValueError("Önce risk katkılarını analiz edin")
        
        # Yüksek risk katkısı
        high_risk_contrib = [c for c in self.risk_contributions if c.percentage_contribution > self.config.target_risk_contribution * 1.5]
        
        # Düşük risk katkısı  
        low_risk_contrib = [c for c in self.risk_contributions if c.percentage_contribution < self.config.target_risk_contribution * 0.5]
        
        # Ağırlık konsantrasyonu
        weight_concentrations = [c for c in self.risk_contributions if c.weight > 0.3]
        
        # Korelasyon analizi
        high_correlations = self._find_high_correlations()
        
        return {
            'high_risk_contributions': [c.asset for c in high_risk_contrib],
            'low_risk_contributions': [c.asset for c in low_risk_contrib],
            'weight_concentrations': [c.asset for c in weight_concentrations],
            'high_correlations': high_correlations,
            'total_concentration_risk': len(high_risk_contrib) + len(low_risk_contrib) + len(weight_concentrations),
            'needs_rebalancing': len(high_risk_contrib) + len(low_risk_contrib) > len(self.assets) * 0.3
        }
    
    def _find_high_correlations(self) -> List[Tuple[str, str, float]]:
        """Yüksek korelasyonları bul"""
        if self.correlation_matrix is None:
            return []
        
        high_corr_pairs = []
        n_assets = len(self.assets)
        
        for i in range(n_assets):
            for j in range(i + 1, n_assets):
                corr = self.correlation_matrix[i, j]
                if corr > self.config.correlation_threshold:
                    high_corr_pairs.append((self.assets[i], self.assets[j], corr))
        
        return high_corr_pairs
    
    def generate_rebalancing_recommendations(self) -> List[str]:
        """
        Rebalancing önerileri oluştur
        
        Returns:
            List[str]: Rebalancing önerileri
        """
        if not self.risk_contributions:
            return ["Risk katkı analizi henüz yapılmadı"]
        
        recommendations = []
        
        # Risk konsantrasyon analizi
        risk_analysis = self.identify_risk_concentrations()
        
        # Yüksek risk katkısı önerileri
        for asset in risk_analysis['high_risk_contributions']:
            recommendations.append(
                f"Risk katkısı yüksek: {asset} pozisyonunu azaltın"
            )
        
        # Düşük risk katkısı önerileri
        for asset in risk_analysis['low_risk_contributions']:
            recommendations.append(
                f"Risk katkısı düşük: {asset} pozisyonunu artırın"
            )
        
        # Ağırlık konsantrasyonu önerileri
        for asset in risk_analysis['weight_concentrations']:
            recommendations.append(
                f"Ağırlık konsantrasyonu: {asset} pozisyonunu çeşitlendirin"
            )
        
        # Korelasyon önerileri
        for asset1, asset2, corr in risk_analysis['high_correlations']:
            recommendations.append(
                f"Yüksek korelasyon ({corr:.2f}): {asset1} ve {asset2} pozisyonlarını gözden geçirin"
            )
        
        # Rebalancing gerekliliği
        if risk_analysis['needs_rebalancing']:
            recommendations.append(
                "Genel portföy rebalancing gereklidir - risk dağılımı dengesiz"
            )
        
        if not recommendations:
            recommendations.append("Portföy dengeli görünüyor - mevcut ağırlıkları koruyabilirsiniz")
        
        return recommendations
    
    def backtest_risk_parity_strategy(self, 
                                    returns: pd.DataFrame,
                                    rebalance_frequency: str = 'monthly') -> Dict[str, Any]:
        """
        Risk-paritesi stratejisini backtest et
        
        Args:
            returns: Getiri serileri
            rebalance_frequency: Rebalancing sıklığı
        
        Returns:
            Dict[str, Any]: Backtest sonuçları
        """
        if not self.optimal_weights is not None:
            self.optimize_risk_parity_weights(returns)
        
        # Rebalancing tarihlerini belirle
        rebalance_dates = self._get_rebalance_dates(returns.index, rebalance_frequency)
        
        portfolio_returns = []
        weights_history = []
        
        current_weights = None
        for date in returns.index:
            # Rebalancing günü mü?
            if date in rebalance_dates:
                # Optimal weights hesapla
                data_until_date = returns.loc[:date]
                if len(data_until_date) >= 50:  # Minimum veri gereksinimi
                    self.optimize_risk_parity_weights(data_until_date)
                    current_weights = self.optimal_weights.copy()
            
            # Eğer weights varsa getiri hesapla
            if current_weights is not None:
                daily_return = (returns.loc[date] * current_weights).sum()
                portfolio_returns.append(daily_return)
                weights_history.append(current_weights.copy())
            else:
                portfolio_returns.append(0.0)
                weights_history.append(np.zeros(len(returns.columns)))
        
        # Backtest metrikleri
        portfolio_series = pd.Series(portfolio_returns, index=returns.index)
        
        results = {
            'portfolio_returns': portfolio_series,
            'weights_history': weights_history,
            'total_return': (1 + portfolio_series).prod() - 1,
            'annualized_return': portfolio_series.mean() * 252,
            'annualized_volatility': portfolio_series.std() * np.sqrt(252),
            'sharpe_ratio': (portfolio_series.mean() * 252) / (portfolio_series.std() * np.sqrt(252)) if portfolio_series.std() > 0 else 0,
            'max_drawdown': self._calculate_max_drawdown(portfolio_series),
            'win_rate': (portfolio_series > 0).mean(),
            'num_rebalances': len(rebalance_dates),
            'avg_holdings': np.mean([np.sum(np.abs(w)) for w in weights_history])
        }
        
        return results
    
    def _get_rebalance_dates(self, dates: pd.DatetimeIndex, 
                           frequency: str) -> pd.DatetimeIndex:
        """Rebalancing tarihlerini belirle"""
        if frequency == 'monthly':
            return dates[dates.day <= 5]  # Ay başında
        elif frequency == 'quarterly':
            return dates[dates.day <= 5] & dates.month.isin([1, 4, 7, 10])
        elif frequency == 'yearly':
            return dates[dates.day <= 5] & dates.month.isin([1])
        else:
            return dates  # Günlük (no filtering)
    
    def get_risk_parity_summary(self, returns: pd.DataFrame) -> Dict[str, Any]:
        """
        Risk-paritesi özet raporu oluştur
        
        Args:
            returns: Getiri serileri
        
        Returns:
            Dict[str, Any]: Kapsamlı risk-paritesi raporu
        """
        # Optimizasyon
        self.optimize_risk_parity_weights(returns)
        
        # Risk katkı analizi
        risk_contrib = self.analyze_risk_contributions()
        
        # Portföy metrikleri
        portfolio_metrics = self.calculate_portfolio_metrics(returns)
        
        # Risk konsantrasyon analizi
        risk_analysis = self.identify_risk_concentrations()
        
        # Öneriler
        recommendations = self.generate_rebalancing_recommendations()
        
        return {
            'timestamp': pd.Timestamp.now().isoformat(),
            'optimal_weights': {
                asset: weight for asset, weight in zip(self.assets, self.optimal_weights)
            },
            'risk_contributions': {
                contrib.asset: {
                    'weight': contrib.weight,
                    'risk_contribution': contrib.percentage_contribution,
                    'volatility': contrib.volatility,
                    'meets_target': contrib.is_target,
                    'adjustment_needed': contrib.adjustment_needed
                } for contrib in risk_contrib
            },
            'portfolio_metrics': portfolio_metrics,
            'risk_analysis': risk_analysis,
            'recommendations': recommendations,
            'configuration': {
                'target_risk_contribution': self.config.target_risk_contribution,
                'leverage_limit': self.config.leverage_limit,
                'correlation_threshold': self.config.correlation_threshold
            }
        }


# Test fonksiyonu
def test_risk_parity_model():
    """Risk-paritesi modeli test fonksiyonu"""
    np.random.seed(42)
    
    # Synthetic return data oluştur
    dates = pd.date_range(start='2023-01-01', periods=252, freq='D')
    n_assets = 5
    
    # Farklı volatilite ve korelasyon seviyelerinde asset returns
    returns_data = {}
    base_returns = np.random.normal(0.001, 0.02, 252)
    
    for i in range(n_assets):
        # Her asset için farklı volatilite
        asset_vol = 0.01 + i * 0.005  # 1% to 3% volatility range
        asset_returns = np.random.normal(0.001, asset_vol, 252)
        
        # Korelasyon ekle (ilk asset ile diğerleri arasında)
        if i > 0:
            correlation = 0.3 + i * 0.1  # 0.4 to 0.7 correlation
            asset_returns = (1 - correlation) * asset_returns + correlation * base_returns
        
        returns_data[f'ASSET_{i+1}'] = asset_returns
    
    returns_df = pd.DataFrame(returns_data, index=dates)
    
    # Risk-paritesi modeli test et
    model = RiskParityModel()
    
    # Optimal weights hesapla
    optimal_weights = model.optimize_risk_parity_weights(returns_df)
    
    print("Optimal Weights:")
    for asset, weight in zip(model.assets, optimal_weights):
        print(f"{asset}: {weight:.3f}")
    
    # Risk katkılarını analiz et
    risk_contrib = model.analyze_risk_contributions()
    
    print("\nRisk Contributions:")
    for contrib in risk_contrib:
        print(f"{contrib.asset}: {contrib.percentage_contribution:.3f} (Target: {model.config.target_risk_contribution:.3f})")
        print(f"  Weight: {contrib.weight:.3f}, Volatility: {contrib.volatility:.3f}")
        print(f"  Meets Target: {contrib.is_target}, Adjustment: {contrib.adjustment_needed:.3f}")
    
    # Portföy metrikleri
    portfolio_metrics = model.calculate_portfolio_metrics(returns_df)
    
    print("\nPortfolio Metrics:")
    for metric, value in portfolio_metrics.items():
        print(f"{metric}: {value:.4f}")
    
    # Öneriler
    recommendations = model.generate_rebalancing_recommendations()
    
    print("\nRebalancing Recommendations:")
    for rec in recommendations:
        print(f"- {rec}")
    
    # Backtest
    backtest_results = model.backtest_risk_parity_strategy(returns_df)
    
    print("\nBacktest Results:")
    for metric, value in backtest_results.items():
        if isinstance(value, (int, float)):
            print(f"{metric}: {value:.4f}")
    
    return model, backtest_results


if __name__ == "__main__":
    test_risk_parity_model()