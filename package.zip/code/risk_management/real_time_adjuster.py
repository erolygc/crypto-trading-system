"""
Real-Time Adjuster Modülü
=========================

Portföy pozisyonlarını real-time olarak izleyen, analiz eden ve 
gerekli adjustment'ları otomatik olarak uygulayan sistem.

Real-Time Adjuster şu özellikleri sağlar:
- Live position monitoring
- Real-time risk calculation
- Automatic position adjustments
- Market event detection
- Performance attribution in real-time
- Alert generation for risk breaches
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Union, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import threading
import time
import queue
import warnings

warnings.filterwarnings('ignore')


class AdjustmentType(Enum):
    """Ayar türleri"""
    POSITION_SIZE = "position_size"
    STOP_LOSS = "stop_loss"
    TAKE_PROFIT = "take_profit"
    LEVERAGE = "leverage"
    HEDGE = "hedge"
    REBALANCE = "rebalance"
    EMERGENCY_EXIT = "emergency_exit"


class MarketEvent(Enum):
    """Piyasa olayları"""
    HIGH_VOLATILITY = "high_volatility"
    MARKET_CRASH = "market_crash"
    CORRELATION_SPIKE = "correlation_spike"
    LIQUIDITY_CRUNCH = "liquidity_crunch"
    REGIME_CHANGE = "regime_change"
    NEWS_EVENT = "news_event"
    EARNINGS_ANNOUNCEMENT = "earnings_announcement"
    CENTRAL_BANK_DECISION = "central_bank_decision"


@dataclass
class RealTimeAlert:
    """Real-time alert"""
    alert_id: str
    timestamp: datetime
    alert_type: str
    severity: str  # LOW, MEDIUM, HIGH, CRITICAL
    title: str
    message: str
    affected_assets: List[str]
    recommended_actions: List[str]
    auto_executable: bool = False
    acknowledged: bool = False


@dataclass
class PositionAdjustment:
    """Pozisyon ayarı"""
    adjustment_id: str
    timestamp: datetime
    asset: str
    adjustment_type: AdjustmentType
    current_position: float
    target_position: float
    adjustment_size: float
    reason: str
    urgency: str  # LOW, MEDIUM, HIGH
    risk_impact: float
    estimated_cost: float
    executed: bool = False


@dataclass
class MarketDataPoint:
    """Piyasa veri noktası"""
    timestamp: datetime
    symbol: str
    price: float
    volume: float
    bid: float
    ask: float
    spread: float
    volatility: float
    additional_data: Dict[str, Any] = field(default_factory=dict)


class RealTimeAdjuster:
    """
    Real-Time Portfolio Adjuster
    
    Real-time piyasa verilerini izler, pozisyon ayarları yapar ve
    risk yönetimi uygular.
    """
    
    def __init__(self, 
                 update_frequency: float = 1.0,  # seconds
                 alert_thresholds: Optional[Dict[str, float]] = None):
        """
        Real-Time Adjuster başlat
        
        Args:
            update_frequency: Güncelleme sıklığı (saniye)
            alert_thresholds: Alert eşikleri
        """
        self.update_frequency = update_frequency
        self.alert_thresholds = alert_thresholds or self._default_alert_thresholds()
        
        # State tracking
        self.is_running = False
        self.monitoring_thread: Optional[threading.Thread] = None
        self.data_queue = queue.Queue()
        self.alert_queue = queue.Queue()
        
        # Market data storage
        self.market_data: Dict[str, List[MarketDataPoint]] = {}
        self.current_positions: Dict[str, float] = {}
        self.position_history: Dict[str, List[Tuple[datetime, float]]] = {}
        
        # Real-time metrics
        self.real_time_metrics: Dict[str, Any] = {}
        self.risk_metrics: Dict[str, float] = {}
        self.performance_metrics: Dict[str, float] = {}
        
        # Alerts and adjustments
        self.active_alerts: List[RealTimeAlert] = []
        self.pending_adjustments: List[PositionAdjustment] = []
        self.executed_adjustments: List[PositionAdjustment] = []
        
        # Event handlers
        self.event_handlers: Dict[str, List[Callable]] = {}
        self.adjustment_callbacks: List[Callable] = []
        self.alert_callbacks: List[Callable] = []
        
        # Performance tracking
        self.start_time = datetime.now()
        self.total_updates = 0
        self.last_update_time = datetime.now()
        
    def _default_alert_thresholds(self) -> Dict[str, float]:
        """Varsayılan alert eşikleri"""
        return {
            'volatility_spike': 2.0,  # 2x normal volatility
            'price_change': 0.05,     # 5% price change
            'volume_spike': 3.0,      # 3x normal volume
            'correlation_change': 0.2, # 20% correlation change
            'drawdown_threshold': 0.03, # 3% drawdown
            'position_drift': 0.1,     # 10% position drift
            'risk_limit_breach': 1.0   # Risk limit breach
        }
    
    def start_monitoring(self):
        """Real-time monitoring'i başlat"""
        if self.is_running:
            print("Real-time monitoring zaten çalışıyor")
            return
        
        self.is_running = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        
        print(f"Real-time monitoring başlatıldı (sıklık: {self.update_frequency}s)")
    
    def stop_monitoring(self):
        """Real-time monitoring'i durdur"""
        self.is_running = False
        
        if self.monitoring_thread:
            self.monitoring_thread.join(timeout=5.0)
        
        print("Real-time monitoring durduruldu")
    
    def _monitoring_loop(self):
        """Ana monitoring döngüsü"""
        while self.is_running:
            try:
                start_time = time.time()
                
                # Process incoming market data
                self._process_market_data()
                
                # Calculate real-time metrics
                self._calculate_real_time_metrics()
                
                # Check for alerts
                self._check_alert_conditions()
                
                # Generate position adjustments if needed
                self._evaluate_position_adjustments()
                
                # Update performance metrics
                self._update_performance_metrics()
                
                # Process any pending adjustments
                self._process_pending_adjustments()
                
                # Update timestamp
                self.last_update_time = datetime.now()
                self.total_updates += 1
                
                # Sleep for remaining time
                elapsed = time.time() - start_time
                sleep_time = max(0, self.update_frequency - elapsed)
                
                if sleep_time > 0:
                    time.sleep(sleep_time)
                
            except Exception as e:
                print(f"Monitoring loop error: {e}")
                time.sleep(1)  # Brief pause on error
    
    def update_market_data(self, market_data: Dict[str, MarketDataPoint]):
        """
        Piyasa verilerini güncelle
        
        Args:
            market_data: {symbol: MarketDataPoint} mapping
        """
        current_time = datetime.now()
        
        for symbol, data_point in market_data.items():
            data_point.timestamp = current_time
            
            if symbol not in self.market_data:
                self.market_data[symbol] = []
            
            # Keep last 1000 data points
            self.market_data[symbol].append(data_point)
            if len(self.market_data[symbol]) > 1000:
                self.market_data[symbol] = self.market_data[symbol][-1000:]
    
    def _process_market_data(self):
        """İşlenmemiş piyasa verilerini işle"""
        processed_count = 0
        
        # Process any data from the queue (if being used)
        while not self.data_queue.empty():
            try:
                market_data = self.data_queue.get_nowait()
                self.update_market_data(market_data)
                processed_count += 1
            except queue.Empty:
                break
        
        # If no queued data, use stored market data for calculations
        if processed_count == 0:
            # Ensure we have current data for position calculations
            self._ensure_current_position_data()
    
    def _ensure_current_position_data(self):
        """Pozisyon hesaplamaları için güncel veri sağla"""
        for symbol in self.current_positions.keys():
            if symbol in self.market_data and self.market_data[symbol]:
                # Use the latest available data point
                latest_data = self.market_data[symbol][-1]
                
                # Update position history if price changed significantly
                if symbol not in self.position_history:
                    self.position_history[symbol] = []
                
                last_recorded = self.position_history[symbol][-1] if self.position_history[symbol] else None
                
                if (not last_recorded or 
                    abs(latest_data.price - last_recorded[1]) / last_recorded[1] > 0.001):  # 0.1% change
                    
                    self.position_history[symbol].append((latest_data.timestamp, latest_data.price))
                    
                    # Keep history reasonable size
                    if len(self.position_history[symbol]) > 100:
                        self.position_history[symbol] = self.position_history[symbol][-100:]
    
    def _calculate_real_time_metrics(self):
        """Real-time metrikleri hesapla"""
        if not self.current_positions:
            return
        
        # Calculate current portfolio value
        total_value = 0.0
        position_values = {}
        
        for symbol, position in self.current_positions.items():
            if symbol in self.market_data and self.market_data[symbol]:
                latest_price = self.market_data[symbol][-1].price
                position_value = position * latest_price
                position_values[symbol] = position_value
                total_value += position_value
        
        # Calculate real-time P&L
        unrealized_pnl = 0.0
        daily_pnl = 0.0
        
        for symbol in self.current_positions:
            if symbol in self.market_data and len(self.market_data[symbol]) >= 2:
                current_price = self.market_data[symbol][-1].price
                previous_price = self.market_data[symbol][-2].price
                
                # Daily P&L calculation
                daily_change = (current_price - previous_price) / previous_price
                daily_pnl += self.current_positions[symbol] * current_price * daily_change
                
                # Unrealized P&L (from entry - simplified)
                if symbol in self.position_history and self.position_history[symbol]:
                    entry_price = self.position_history[symbol][0][1]  # First recorded price
                    unrealized_change = (current_price - entry_price) / entry_price
                    unrealized_pnl += self.current_positions[symbol] * current_price * unrealized_change
        
        # Calculate portfolio-level metrics
        portfolio_volatility = self._calculate_portfolio_volatility()
        max_drawdown = self._calculate_max_drawdown()
        
        # Update metrics
        self.real_time_metrics = {
            'total_portfolio_value': total_value,
            'unrealized_pnl': unrealized_pnl,
            'daily_pnl': daily_pnl,
            'daily_return': daily_pnl / (total_value + 1e-8),
            'portfolio_volatility': portfolio_volatility,
            'max_drawdown': max_drawdown,
            'num_positions': len(self.current_positions),
            'last_update': self.last_update_time.isoformat(),
            'uptime_hours': (datetime.now() - self.start_time).total_seconds() / 3600
        }
        
        # Update risk metrics
        self.risk_metrics = self._calculate_risk_metrics()
    
    def _calculate_portfolio_volatility(self) -> float:
        """Portföy volatilitesini hesapla (simplified)"""
        if not self.current_positions:
            return 0.0
        
        # Simplified volatility calculation based on recent price movements
        weighted_volatility = 0.0
        total_weight = 0.0
        
        for symbol, position in self.current_positions.items():
            if (symbol in self.market_data and 
                len(self.market_data[symbol]) >= 20):
                
                recent_prices = [dp.price for dp in self.market_data[symbol][-20:]]
                returns = np.diff(recent_prices) / recent_prices[:-1]
                vol = np.std(returns) * np.sqrt(252)  # Annualized
                
                position_weight = abs(position * recent_prices[-1])
                weighted_volatility += vol * position_weight
                total_weight += position_weight
        
        return weighted_volatility / (total_weight + 1e-8) if total_weight > 0 else 0.0
    
    def _calculate_max_drawdown(self) -> float:
        """Maksimum drawdown hesapla"""
        if not self.real_time_metrics:
            return 0.0
        
        # Simplified drawdown calculation
        current_value = self.real_time_metrics.get('total_portfolio_value', 0)
        
        if not self.real_time_metrics.get('peak_value'):
            self.real_time_metrics['peak_value'] = current_value
        
        # Update peak if current value is higher
        if current_value > self.real_time_metrics['peak_value']:
            self.real_time_metrics['peak_value'] = current_value
        
        # Calculate current drawdown
        peak = self.real_time_metrics['peak_value']
        drawdown = (peak - current_value) / (peak + 1e-8)
        
        return max(0.0, drawdown)
    
    def _calculate_risk_metrics(self) -> Dict[str, float]:
        """Risk metriklerini hesapla"""
        metrics = {
            'var_1d_95': 0.0,  # 1-day VaR at 95%
            'expected_shortfall': 0.0,
            'correlation_risk': 0.0,
            'concentration_risk': 0.0,
            'leverage_risk': 0.0
        }
        
        # VaR calculation (simplified)
        portfolio_vol = self.real_time_metrics.get('portfolio_volatility', 0)
        portfolio_value = self.real_time_metrics.get('total_portfolio_value', 0)
        
        if portfolio_vol > 0 and portfolio_value > 0:
            # 1-day VaR at 95% confidence
            metrics['var_1d_95'] = portfolio_value * portfolio_vol * 1.645 * 0.01
        
        # Concentration risk (HHI)
        if self.current_positions and portfolio_value > 0:
            total_abs_value = sum(abs(pos) * self.market_data.get(symbol, [MarketDataPoint(datetime.now(), symbol, 0, 0, 0, 0, 0, 0)])[-1].price 
                                for symbol, pos in self.current_positions.items())
            
            if total_abs_value > 0:
                hhi = sum((abs(pos) * self.market_data.get(symbol, [MarketDataPoint(datetime.now(), symbol, 0, 0, 0, 0, 0, 0)])[-1].price / total_abs_value)**2 
                         for symbol, pos in self.current_positions.items())
                metrics['concentration_risk'] = hhi
        
        return metrics
    
    def _check_alert_conditions(self):
        """Alert koşullarını kontrol et"""
        current_time = datetime.now()
        
        # Volatility spike alert
        if self.real_time_metrics.get('portfolio_volatility', 0) > 0.25:  # 25% volatility
            self._create_alert(
                alert_type="VOLATILITY_SPIKE",
                severity="HIGH",
                title="High Portfolio Volatility",
                message=f"Portfolio volatility reached {self.real_time_metrics['portfolio_volatility']:.1%}",
                affected_assets=list(self.current_positions.keys()),
                recommended_actions=["Consider reducing position sizes", "Add defensive positions"]
            )
        
        # Drawdown alert
        current_drawdown = self.real_time_metrics.get('max_drawdown', 0)
        if current_drawdown > self.alert_thresholds['drawdown_threshold']:
            self._create_alert(
                alert_type="DRAWDOWN",
                severity="HIGH",
                title="Significant Drawdown Detected",
                message=f"Portfolio drawdown: {current_drawdown:.1%}",
                affected_assets=list(self.current_positions.keys()),
                recommended_actions=["Review stop-loss levels", "Consider position reduction"]
            )
        
        # Individual position alerts
        for symbol, position in self.current_positions.items():
            if symbol in self.market_data and len(self.market_data[symbol]) >= 2:
                current_price = self.market_data[symbol][-1].price
                previous_price = self.market_data[symbol][-2].price
                price_change = abs(current_price - previous_price) / previous_price
                
                if price_change > self.alert_thresholds['price_change']:
                    self._create_alert(
                        alert_type="PRICE_MOVEMENT",
                        severity="MEDIUM",
                        title=f"Large Price Movement: {symbol}",
                        message=f"{symbol} price changed {price_change:.1%}",
                        affected_assets=[symbol],
                        recommended_actions=[f"Review {symbol} position"]
                    )
    
    def _evaluate_position_adjustments(self):
        """Pozisyon ayarlama gereksinimlerini değerlendir"""
        # Risk-based adjustments
        portfolio_vol = self.real_time_metrics.get('portfolio_volatility', 0)
        max_position_size = 0.15  # 15% max position
        
        if portfolio_vol > 0.20:  # High volatility threshold
            # Reduce position sizes
            for symbol, position in self.current_positions.items():
                if symbol in self.market_data and self.market_data[symbol]:
                    current_price = self.market_data[symbol][-1].price
                    position_value = abs(position * current_price)
                    total_value = self.real_time_metrics.get('total_portfolio_value', 0)
                    
                    if total_value > 0:
                        position_weight = position_value / total_value
                        
                        if position_weight > max_position_size:
                            # Recommend position reduction
                            target_size = position * max_position_size / position_weight
                            
                            adjustment = PositionAdjustment(
                                adjustment_id=f"vol_adj_{symbol}_{int(time.time())}",
                                timestamp=datetime.now(),
                                asset=symbol,
                                adjustment_type=AdjustmentType.POSITION_SIZE,
                                current_position=position,
                                target_position=target_size,
                                adjustment_size=position - target_size,
                                reason="High portfolio volatility",
                                urgency="HIGH",
                                risk_impact=0.3,
                                estimated_cost=0.002
                            )
                            
                            self.pending_adjustments.append(adjustment)
        
        # Drift-based adjustments
        self._check_position_drift()
    
    def _check_position_drift(self):
        """Pozisyon drift'ini kontrol et"""
        for symbol, position in self.current_positions.items():
            if symbol in self.position_history and len(self.position_history[symbol]) > 10:
                recent_positions = self.position_history[symbol][-10:]
                
                # Check for position drift (simplified)
                position_volatility = np.std([p[1] for p in recent_positions])
                
                if position_volatility > 0.1:  # High drift threshold
                    adjustment = PositionAdjustment(
                        adjustment_id=f"drift_{symbol}_{int(time.time())}",
                        timestamp=datetime.now(),
                        asset=symbol,
                        adjustment_type=AdjustmentType.POSITION_SIZE,
                        current_position=position,
                        target_position=position * 0.95,  # Reduce by 5%
                        adjustment_size=position * 0.05,
                        reason="Position drift detected",
                        urgency="MEDIUM",
                        risk_impact=0.1,
                        estimated_cost=0.001
                    )
                    
                    self.pending_adjustments.append(adjustment)
    
    def _process_pending_adjustments(self):
        """Bekleyen ayarları işle"""
        for adjustment in self.pending_adjustments[:]:
            # Check if adjustment should be executed automatically
            if adjustment.auto_executable:
                self._execute_adjustment(adjustment)
                self.pending_adjustments.remove(adjustment)
            else:
                # Manual approval required - just move to executed list for tracking
                self.executed_adjustments.append(adjustment)
                self.pending_adjustments.remove(adjustment)
    
    def _execute_adjustment(self, adjustment: PositionAdjustment):
        """Pozisyon ayarını uygula"""
        try:
            # Update current position
            if adjustment.asset in self.current_positions:
                self.current_positions[adjustment.adjustment] = adjustment.target_position
                adjustment.executed = True
                
                print(f"Position adjustment executed: {adjustment.asset} -> {adjustment.target_position}")
                
                # Execute callbacks
                for callback in self.adjustment_callbacks:
                    try:
                        callback(adjustment)
                    except Exception as e:
                        print(f"Adjustment callback error: {e}")
            
        except Exception as e:
            print(f"Adjustment execution error: {e}")
    
    def _create_alert(self, 
                     alert_type: str,
                     severity: str,
                     title: str,
                     message: str,
                     affected_assets: List[str],
                     recommended_actions: List[str],
                     auto_executable: bool = False):
        """Alert oluştur"""
        alert = RealTimeAlert(
            alert_id=f"alert_{alert_type}_{int(time.time())}",
            timestamp=datetime.now(),
            alert_type=alert_type,
            severity=severity,
            title=title,
            message=message,
            affected_assets=affected_assets,
            recommended_actions=recommended_actions,
            auto_executable=auto_executable
        )
        
        self.active_alerts.append(alert)
        
        # Trigger callbacks
        for callback in self.alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                print(f"Alert callback error: {e}")
    
    def _update_performance_metrics(self):
        """Performans metriklerini güncelle"""
        if not self.real_time_metrics:
            return
        
        # Calculate performance metrics based on current data
        total_return = (self.real_time_metrics.get('total_portfolio_value', 0) / 
                       (self.real_time_metrics.get('initial_value', 100000) + 1e-8) - 1)
        
        self.performance_metrics = {
            'total_return': total_return,
            'daily_return': self.real_time_metrics.get('daily_return', 0),
            'sharpe_ratio': self._calculate_sharpe_ratio(),
            'win_rate': self._calculate_win_rate(),
            'profit_factor': self._calculate_profit_factor()
        }
    
    def _calculate_sharpe_ratio(self) -> float:
        """Sharpe ratio hesapla"""
        # Simplified Sharpe ratio calculation
        daily_return = self.real_time_metrics.get('daily_return', 0)
        portfolio_vol = self.real_time_metrics.get('portfolio_volatility', 0)
        
        if portfolio_vol > 0:
            annual_return = daily_return * 252
            annual_vol = portfolio_vol
            risk_free_rate = 0.02  # 2% risk-free rate
            
            return (annual_return - risk_free_rate) / annual_vol
        
        return 0.0
    
    def _calculate_win_rate(self) -> float:
        """Win rate hesapla"""
        # Simplified win rate based on daily returns
        # In real implementation, would track individual trade outcomes
        daily_return = self.real_time_metrics.get('daily_return', 0)
        return 1.0 if daily_return > 0 else 0.0
    
    def _calculate_profit_factor(self) -> float:
        """Profit factor hesapla"""
        # Simplified profit factor
        # Real implementation would track gross profits and gross losses
        unrealized_pnl = self.real_time_metrics.get('unrealized_pnl', 0)
        return 1.0 + (unrealized_pnl / 1000)  # Simplified
    
    def add_position(self, symbol: str, position_size: float):
        """Pozisyon ekle"""
        self.current_positions[symbol] = position_size
        
        # Initialize position history
        if symbol not in self.position_history:
            self.position_history[symbol] = []
        
        print(f"Position added: {symbol} = {position_size}")
    
    def remove_position(self, symbol: str):
        """Pozisyon kaldır"""
        if symbol in self.current_positions:
            del self.current_positions[symbol]
        
        if symbol in self.position_history:
            del self.position_history[symbol]
        
        if symbol in self.market_data:
            del self.market_data[symbol]
        
        print(f"Position removed: {symbol}")
    
    def update_position(self, symbol: str, new_size: float):
        """Pozisyon güncelle"""
        self.current_positions[symbol] = new_size
        print(f"Position updated: {symbol} = {new_size}")
    
    def register_event_handler(self, event_type: str, handler: Callable):
        """Event handler kaydet"""
        if event_type not in self.event_handlers:
            self.event_handlers[event_type] = []
        self.event_handlers[event_type].append(handler)
    
    def register_adjustment_callback(self, callback: Callable):
        """Position adjustment callback kaydet"""
        self.adjustment_callbacks.append(callback)
    
    def register_alert_callback(self, callback: Callable):
        """Alert callback kaydet"""
        self.alert_callbacks.append(callback)
    
    def get_real_time_status(self) -> Dict[str, Any]:
        """Real-time durum bilgisini getir"""
        return {
            'is_running': self.is_running,
            'last_update': self.last_update_time.isoformat(),
            'total_updates': self.total_updates,
            'uptime_hours': (datetime.now() - self.start_time).total_seconds() / 3600,
            'active_alerts': len(self.active_alerts),
            'pending_adjustments': len(self.pending_adjustments),
            'executed_adjustments': len(self.executed_adjustments),
            'current_positions': len(self.current_positions),
            'monitored_assets': list(self.market_data.keys())
        }
    
    def get_alerts(self, severity_filter: Optional[str] = None) -> List[RealTimeAlert]:
        """Alert'leri getir"""
        if severity_filter:
            return [alert for alert in self.active_alerts if alert.severity == severity_filter]
        return self.active_alerts.copy()
    
    def acknowledge_alert(self, alert_id: str):
        """Alert'i acknowledge et"""
        for alert in self.active_alerts:
            if alert.alert_id == alert_id:
                alert.acknowledged = True
                print(f"Alert acknowledged: {alert_id}")
                break
    
    def get_position_adjustments(self, status_filter: str = "pending") -> List[PositionAdjustment]:
        """Position ayarlarını getir"""
        if status_filter == "pending":
            return self.pending_adjustments.copy()
        elif status_filter == "executed":
            return self.executed_adjustments.copy()
        else:
            return (self.pending_adjustments + self.executed_adjustments).copy()


# Test fonksiyonu
def test_real_time_adjuster():
    """Real-Time Adjuster test fonksiyonu"""
    
    adjuster = RealTimeAdjuster(update_frequency=0.1)  # 100ms for testing
    
    # Add some test positions
    adjuster.add_position("AAPL", 100)
    adjuster.add_position("GOOGL", 50)
    adjuster.add_position("MSFT", 75)
    
    # Start monitoring
    adjuster.start_monitoring()
    
    # Simulate some market data updates
    base_prices = {"AAPL": 150, "GOOGL": 2500, "MSFT": 300}
    
    for i in range(10):  # 10 updates
        market_data = {}
        
        for symbol in ["AAPL", "GOOGL", "MSFT"]:
            # Simulate price movement
            price_change = np.random.normal(0, 0.01)  # 1% volatility
            new_price = base_prices[symbol] * (1 + price_change * i/10)
            base_prices[symbol] = new_price
            
            market_data[symbol] = MarketDataPoint(
                timestamp=datetime.now(),
                symbol=symbol,
                price=new_price,
                volume=np.random.randint(1000, 10000),
                bid=new_price * 0.999,
                ask=new_price * 1.001,
                spread=new_price * 0.002,
                volatility=0.02
            )
        
        adjuster.update_market_data(market_data)
        time.sleep(0.2)  # Wait between updates
    
    # Get status
    status = adjuster.get_real_time_status()
    print("\nReal-Time Status:")
    for key, value in status.items():
        print(f"  {key}: {value}")
    
    # Get alerts
    alerts = adjuster.get_alerts()
    print(f"\nActive Alerts: {len(alerts)}")
    for alert in alerts:
        print(f"  {alert.severity}: {alert.title}")
    
    # Get adjustments
    adjustments = adjuster.get_position_adjustments("pending")
    print(f"\nPending Adjustments: {len(adjustments)}")
    for adj in adjustments:
        print(f"  {adj.asset}: {adj.reason}")
    
    # Stop monitoring
    adjuster.stop_monitoring()
    
    return adjuster


if __name__ == "__main__":
    test_real_time_adjuster()