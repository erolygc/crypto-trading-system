"""
Dynamic Position Sizer Modülü
============================

Tüm risk yönetimi bileşenlerini entegre eden ana pozisyon boyutlandırma sistemi.

Dynamic Position Sizer şu özellikleri sağlar:
- Multi-factor position sizing (volatility, confidence, risk-parity)
- Real-time adjustment capabilities
- Portfolio-level constraints enforcement
- Kelly Criterion optimization
- Backward compatibility with existing systems
- Advanced risk management integration
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import warnings

# Import risk management modules
from .atr_volatility import ATRVolatilityTargeter, ATRConfig, ATRMetrics
from .risk_parity import RiskParityModel, RiskParityConfig
from .signal_confidence import SignalConfidenceIntegrator, ConfidenceMetrics

warnings.filterwarnings('ignore')


class PositionSizingMethod(Enum):
    """Pozisyon boyutlandırma yöntemleri"""
    VOLATILITY_TARGETED = "volatility_targeted"
    RISK_PARITY = "risk_parity"
    KELLY_CRITERION = "kelly_criterion"
    CONFIDENCE_WEIGHTED = "confidence_weighted"
    HYBRID_ADAPTIVE = "hybrid_adaptive"
    LEGACY_COMPATIBLE = "legacy_compatible"


class PositionAction(Enum):
    """Pozisyon aksiyonları"""
    INCREASE = "increase"
    DECREASE = "decrease"
    HOLD = "hold"
    CLOSE = "close"
    NEW_POSITION = "new_position"


@dataclass
class PositionSizingConfig:
    """Pozisyon boyutlandırma konfigürasyonu"""
    # Method selection
    sizing_method: PositionSizingMethod = PositionSizingMethod.HYBRID_ADAPTIVE
    
    # Account constraints
    max_position_size: float = 0.15  # %15 max single position
    max_sector_exposure: float = 0.30  # %30 max sector exposure
    max_portfolio_risk: float = 0.20  # %20 max portfolio risk
    min_cash_reserve: float = 0.05  # %5 min cash reserve
    max_leverage: float = 3.0  # 3x max leverage
    
    # Risk management parameters
    volatility_target: float = 0.15  # %15 annual volatility target
    risk_free_rate: float = 0.02  # %2 risk-free rate
    confidence_threshold: float = 0.6  # Min confidence for positions
    
    # Kelly Criterion parameters
    kelly_fraction: float = 0.25  # Conservative Kelly (25% of optimal)
    kelly_max_position: float = 0.20  # Max 20% Kelly-based position
    
    # Rebalancing parameters
    rebalance_threshold: float = 0.05  # %5 rebalance threshold
    min_holding_period: int = 1  # Min 1 day holding
    
    # Legacy system compatibility
    legacy_mode: bool = False
    legacy_multiplier: float = 2.0  # 2x quantity for HEDGE MODE
    model_weights: Dict[str, float] = field(default_factory=lambda: {
        'Model_1': 0.3,
        'Model_2': 0.25, 
        'Model_3': 0.25,
        'Model_4': 0.20
    })


@dataclass
class PositionSize:
    """Pozisyon boyutu sonucu"""
    signal_id: str
    asset: str
    recommended_size: float
    method_used: PositionSizingMethod
    confidence_adjusted_size: float
    risk_adjusted_size: float
    kelly_size: float
    volatility_adjusted_size: float
    final_size: float
    action: PositionAction
    reasoning: List[str]
    risk_metrics: Dict[str, float]
    metadata: Dict[str, Any]


@dataclass
class PortfolioPosition:
    """Portföy pozisyonu"""
    asset: str
    symbol: str
    current_size: float
    current_value: float
    unrealized_pnl: float
    entry_price: float
    current_price: float
    position_date: datetime
    confidence_score: float
    risk_contribution: float
    last_rebalanced: Optional[datetime] = None


class DynamicPositionSizer:
    """
    Dynamic Position Sizer
    
    Gelişmiş pozisyon boyutlandırma algoritması. Çoklu risk faktörünü
    entegre eder ve real-time adjustment imkanı sağlar.
    """
    
    def __init__(self, config: Optional[PositionSizingConfig] = None):
        """
        Dynamic Position Sizer başlat
        
        Args:
            config: Konfigürasyon parametreleri
        """
        self.config = config or PositionSizingConfig()
        
        # Initialize components
        self.atr_targeter = ATRVolatilityTargeter()
        self.risk_parity_model = RiskParityModel()
        self.confidence_integrator = SignalConfidenceIntegrator()
        
        # State tracking
        self.current_positions: Dict[str, PortfolioPosition] = {}
        self.position_history: List[PositionSize] = []
        self.risk_metrics_history: List[Dict[str, float]] = []
        
        # Portfolio tracking
        self.total_portfolio_value = 0.0
        self.available_cash = 0.0
        self.allocated_capital = 0.0
        
    def calculate_position_size(self, 
                              signal_data: Dict[str, Any],
                              portfolio_context: Dict[str, Any],
                              market_data: Dict[str, pd.DataFrame]) -> PositionSize:
        """
        Ana pozisyon boyutlandırma fonksiyonu
        
        Args:
            signal_data: Sinyal verisi
            portfolio_context: Portföy bağlamı
            market_data: Piyasa verisi
        
        Returns:
            PositionSize: Pozisyon boyutlandırma sonucu
        """
        signal_id = signal_data.get('signal_id', 'unknown')
        asset = signal_data.get('asset', 'UNKNOWN')
        
        # Different sizing methods
        if self.config.sizing_method == PositionSizingMethod.VOLATILITY_TARGETED:
            return self._volatility_targeted_sizing(signal_data, portfolio_context, market_data)
        elif self.config.sizing_method == PositionSizingMethod.RISK_PARITY:
            return self._risk_parity_sizing(signal_data, portfolio_context, market_data)
        elif self.config.sizing_method == PositionSizingMethod.KELLY_CRITERION:
            return self._kelly_criterion_sizing(signal_data, portfolio_context, market_data)
        elif self.config.sizing_method == PositionSizingMethod.CONFIDENCE_WEIGHTED:
            return self._confidence_weighted_sizing(signal_data, portfolio_context, market_data)
        elif self.config.sizing_method == PositionSizingMethod.LEGACY_COMPATIBLE:
            return self._legacy_compatible_sizing(signal_data, portfolio_context, market_data)
        else:  # HYBRID_ADAPTIVE
            return self._hybrid_adaptive_sizing(signal_data, portfolio_context, market_data)
    
    def _volatility_targeted_sizing(self, 
                                   signal_data: Dict[str, Any],
                                   portfolio_context: Dict[str, Any],
                                   market_data: Dict[str, pd.DataFrame]) -> PositionSize:
        """Volatilite hedefli pozisyon boyutlandırma"""
        asset = signal_data.get('asset', '')
        
        # ATR analysis
        if asset in market_data and len(market_data[asset]) >= 14:
            atr_metrics = self.atr_targeter.analyze_asset_volatility(market_data[asset], asset)
            volatility_adjustment = self.atr_targeter.calculate_target_position_size(
                portfolio_context.get('account_value', 100000),
                atr_metrics.normalized_atr,
                atr_metrics.position_multiplier
            )
        else:
            volatility_adjustment = portfolio_context.get('account_value', 100000) * 0.1
        
        # Confidence adjustment
        confidence_metrics = self.confidence_integrator.calculate_signal_confidence(signal_data)
        confidence_multiplier = confidence_metrics.overall_confidence
        
        # Calculate position size
        base_position = volatility_adjustment
        confidence_adjusted = base_position * confidence_multiplier
        
        # Portfolio constraints
        max_position = portfolio_context.get('account_value', 100000) * self.config.max_position_size
        final_size = min(confidence_adjusted, max_position)
        
        reasoning = [
            f"ATR volatilite analizi: {atr_metrics.risk_level if 'atr_metrics' in locals() else 'Default'}",
            f"Confidence seviyesi: {confidence_multiplier:.3f}",
            f"Maksimum pozisyon limiti: {self.config.max_position_size:.1%}"
        ]
        
        return PositionSize(
            signal_id=signal_data.get('signal_id', ''),
            asset=asset,
            recommended_size=base_position,
            method_used=PositionSizingMethod.VOLATILITY_TARGETED,
            confidence_adjusted_size=confidence_adjusted,
            risk_adjusted_size=final_size,
            kelly_size=0.0,
            volatility_adjusted_size=volatility_adjustment,
            final_size=final_size,
            action=self._determine_action(final_size, signal_data),
            reasoning=reasoning,
            risk_metrics={
                'volatility_ratio': atr_metrics.volatility_ratio if 'atr_metrics' in locals() else 1.0,
                'confidence_score': confidence_multiplier,
                'position_pct_of_portfolio': final_size / portfolio_context.get('account_value', 100000)
            },
            metadata={
                'atr_metrics': atr_metrics.__dict__ if 'atr_metrics' in locals() else None,
                'confidence_metrics': confidence_metrics.__dict__
            }
        )
    
    def _risk_parity_sizing(self, 
                          signal_data: Dict[str, Any],
                          portfolio_context: Dict[str, Any],
                          market_data: Dict[str, pd.DataFrame]) -> PositionSize:
        """Risk-paritesi bazlı pozisyon boyutlandırma"""
        # Risk-paritesi modelini kullan
        # Bu örnekte simplified implementation
        
        signal_id = signal_data.get('signal_id', '')
        asset = signal_data.get('asset', '')
        
        # Portfolio analysis
        current_portfolio_risk = portfolio_context.get('portfolio_risk', 0.15)
        target_risk_contribution = self.config.volatility_target / len(portfolio_context.get('assets', [asset]))
        
        # Risk contribution calculation
        asset_risk = self._estimate_asset_risk(signal_data, market_data.get(asset))
        risk_contribution = (asset_risk * portfolio_context.get('account_value', 100000) * 0.1) / current_portfolio_risk
        
        # Risk-paritesi adjustment
        risk_parity_multiplier = min(target_risk_contribution / (risk_contribution + 1e-8), 2.0)
        
        # Base position size
        base_position = portfolio_context.get('account_value', 100000) * 0.1
        risk_parity_adjusted = base_position * risk_parity_multiplier
        
        # Apply constraints
        max_position = portfolio_context.get('account_value', 100000) * self.config.max_position_size
        final_size = min(risk_parity_adjusted, max_position)
        
        reasoning = [
            f"Risk katkısı: {risk_contribution:.3f}",
            f"Risk-paritesi çarpanı: {risk_parity_multiplier:.3f}",
            f"Hedef risk katkısı: {target_risk_contribution:.3f}"
        ]
        
        return PositionSize(
            signal_id=signal_id,
            asset=asset,
            recommended_size=base_position,
            method_used=PositionSizingMethod.RISK_PARITY,
            confidence_adjusted_size=risk_parity_adjusted,
            risk_adjusted_size=final_size,
            kelly_size=0.0,
            volatility_adjusted_size=0.0,
            final_size=final_size,
            action=self._determine_action(final_size, signal_data),
            reasoning=reasoning,
            risk_metrics={
                'risk_contribution': risk_contribution,
                'risk_parity_multiplier': risk_parity_multiplier,
                'position_pct_of_portfolio': final_size / portfolio_context.get('account_value', 100000)
            },
            metadata={'target_risk_contribution': target_risk_contribution}
        )
    
    def _kelly_criterion_sizing(self, 
                              signal_data: Dict[str, Any],
                              portfolio_context: Dict[str, Any],
                              market_data: Dict[str, pd.DataFrame]) -> PositionSize:
        """Kelly Criterion bazlı pozisyon boyutlandırma"""
        asset = signal_data.get('asset', '')
        
        # Historical performance analysis
        historical_returns = signal_data.get('historical_returns', np.array([]))
        
        if len(historical_returns) < 10:
            # Insufficient data, use default
            kelly_size = portfolio_context.get('account_value', 100000) * 0.05
        else:
            # Kelly Criterion: f = (bp - q) / b
            # where b = odds received, p = win probability, q = lose probability
            
            returns = pd.Series(historical_returns)
            wins = returns > 0
            win_rate = wins.mean()
            loss_rate = 1 - win_rate
            
            avg_win = returns[wins].mean() if wins.any() else 0.01
            avg_loss = returns[~wins].mean() if (~wins).any() else -0.01
            
            # Kelly fraction calculation
            if avg_loss != 0:
                b = avg_win / abs(avg_loss)  # odds ratio
                kelly_fraction = (b * win_rate - loss_rate) / b
            else:
                kelly_fraction = win_rate * 0.5  # conservative estimate
            
            # Apply conservative Kelly
            kelly_fraction = max(0, min(kelly_fraction, self.config.kelly_max_position))
            conservative_kelly = kelly_fraction * self.config.kelly_fraction
            
            kelly_size = portfolio_context.get('account_value', 100000) * conservative_kelly
        
        # Confidence adjustment
        confidence_metrics = self.confidence_integrator.calculate_signal_confidence(signal_data)
        confidence_multiplier = confidence_metrics.overall_confidence
        
        # Apply confidence adjustment
        confidence_adjusted_kelly = kelly_size * confidence_multiplier
        
        # Portfolio constraints
        max_position = portfolio_context.get('account_value', 100000) * self.config.max_position_size
        final_size = min(confidence_adjusted_kelly, max_position)
        
        reasoning = [
            f"Kelly fraction: {kelly_size / portfolio_context.get('account_value', 100000):.3f}",
            f"Confidence adjustment: {confidence_multiplier:.3f}",
            f"Conservative factor: {self.config.kelly_fraction:.3f}"
        ]
        
        return PositionSize(
            signal_id=signal_data.get('signal_id', ''),
            asset=asset,
            recommended_size=kelly_size,
            method_used=PositionSizingMethod.KELLY_CRITERION,
            confidence_adjusted_size=confidence_adjusted_kelly,
            risk_adjusted_size=final_size,
            kelly_size=kelly_size,
            volatility_adjusted_size=0.0,
            final_size=final_size,
            action=self._determine_action(final_size, signal_data),
            reasoning=reasoning,
            risk_metrics={
                'kelly_fraction': kelly_size / portfolio_context.get('account_value', 100000),
                'confidence_score': confidence_multiplier,
                'position_pct_of_portfolio': final_size / portfolio_context.get('account_value', 100000)
            },
            metadata={'confidence_metrics': confidence_metrics.__dict__}
        )
    
    def _confidence_weighted_sizing(self, 
                                  signal_data: Dict[str, Any],
                                  portfolio_context: Dict[str, Any],
                                  market_data: Dict[str, pd.DataFrame]) -> PositionSize:
        """Confidence ağırlıklı pozisyon boyutlandırma"""
        asset = signal_data.get('asset', '')
        
        # Calculate confidence metrics
        confidence_metrics = self.confidence_integrator.calculate_signal_confidence(signal_data)
        confidence_score = confidence_metrics.overall_confidence
        
        # Base position size
        base_position = portfolio_context.get('account_value', 100000) * 0.1
        
        # Confidence-weighted sizing
        # Higher confidence = larger position (within limits)
        if confidence_score < self.config.confidence_threshold:
            confidence_multiplier = confidence_score / self.config.confidence_threshold
        else:
            confidence_multiplier = 0.5 + 0.5 * (confidence_score - self.config.confidence_threshold) / (1 - self.config.confidence_threshold)
        
        confidence_adjusted_size = base_position * confidence_multiplier
        
        # Apply uncertainty penalty
        uncertainty_penalty = 1.0 - confidence_metrics.uncertainty_score * 0.5
        final_size = confidence_adjusted_size * uncertainty_penalty
        
        # Portfolio constraints
        max_position = portfolio_context.get('account_value', 100000) * self.config.max_position_size
        final_size = min(final_size, max_position)
        
        reasoning = [
            f"Confidence score: {confidence_score:.3f}",
            f"Confidence threshold: {self.config.confidence_threshold:.3f}",
            f"Uncertainty penalty: {uncertainty_penalty:.3f}"
        ]
        
        return PositionSize(
            signal_id=signal_data.get('signal_id', ''),
            asset=asset,
            recommended_size=base_position,
            method_used=PositionSizingMethod.CONFIDENCE_WEIGHTED,
            confidence_adjusted_size=confidence_adjusted_size,
            risk_adjusted_size=final_size,
            kelly_size=0.0,
            volatility_adjusted_size=0.0,
            final_size=final_size,
            action=self._determine_action(final_size, signal_data),
            reasoning=reasoning,
            risk_metrics={
                'confidence_score': confidence_score,
                'uncertainty_score': confidence_metrics.uncertainty_score,
                'position_pct_of_portfolio': final_size / portfolio_context.get('account_value', 100000)
            },
            metadata={'confidence_metrics': confidence_metrics.__dict__}
        )
    
    def _legacy_compatible_sizing(self, 
                                signal_data: Dict[str, Any],
                                portfolio_context: Dict[str, Any],
                                market_data: Dict[str, pd.DataFrame]) -> PositionSize:
        """Legacy sistem uyumlu pozisyon boyutlandırma"""
        asset = signal_data.get('asset', '')
        
        # Legacy Mode: HEDGE MODE, 2x Quantity, Model 1-4
        base_position = portfolio_context.get('account_value', 100000) * 0.1
        
        # Model weights from configuration
        model_score = 0.0
        total_weight = 0.0
        
        for model_name, weight in self.config.model_weights.items():
            model_signal_key = f"{model_name.lower()}_signal"
            if model_signal_key in signal_data:
                model_score += signal_data[model_signal_key] * weight
                total_weight += weight
        
        if total_weight > 0:
            model_score = model_score / total_weight
        
        # HEDGE MODE multiplier
        hedge_multiplier = self.config.legacy_multiplier if signal_data.get('hedge_mode', False) else 1.0
        
        # Calculate position size
        legacy_size = base_position * model_score * hedge_multiplier
        
        # Apply confidence adjustment (new feature in legacy mode)
        confidence_metrics = self.confidence_integrator.calculate_signal_confidence(signal_data)
        confidence_adjustment = confidence_metrics.overall_confidence
        
        final_size = legacy_size * confidence_adjustment
        
        # Portfolio constraints
        max_position = portfolio_context.get('account_value', 100000) * self.config.max_position_size
        final_size = min(final_size, max_position)
        
        reasoning = [
            f"Legacy model score: {model_score:.3f}",
            f"HEDGE MODE multiplier: {hedge_multiplier:.1f}x",
            f"Confidence adjustment: {confidence_adjustment:.3f}"
        ]
        
        return PositionSize(
            signal_id=signal_data.get('signal_id', ''),
            asset=asset,
            recommended_size=legacy_size,
            method_used=PositionSizingMethod.LEGACY_COMPATIBLE,
            confidence_adjusted_size=legacy_size * confidence_adjustment,
            risk_adjusted_size=final_size,
            kelly_size=0.0,
            volatility_adjusted_size=0.0,
            final_size=final_size,
            action=self._determine_action(final_size, signal_data),
            reasoning=reasoning,
            risk_metrics={
                'model_score': model_score,
                'hedge_multiplier': hedge_multiplier,
                'confidence_score': confidence_adjustment,
                'position_pct_of_portfolio': final_size / portfolio_context.get('account_value', 100000)
            },
            metadata={
                'legacy_mode': True,
                'model_weights': self.config.model_weights,
                'confidence_metrics': confidence_metrics.__dict__
            }
        )
    
    def _hybrid_adaptive_sizing(self, 
                              signal_data: Dict[str, Any],
                              portfolio_context: Dict[str, Any],
                              market_data: Dict[str, pd.DataFrame]) -> PositionSize:
        """Hibrit uyarlanabilir pozisyon boyutlandırma"""
        # Tüm yöntemleri birleştir ve optimal kombinasyonu bul
        asset = signal_data.get('asset', '')
        
        # Get all individual sizing results
        volatility_result = self._volatility_targeted_sizing(signal_data, portfolio_context, market_data)
        kelly_result = self._kelly_criterion_sizing(signal_data, portfolio_context, market_data)
        confidence_result = self._confidence_weighted_sizing(signal_data, portfolio_context, market_data)
        risk_parity_result = self._risk_parity_sizing(signal_data, portfolio_context, market_data)
        
        # Weight each method based on market conditions and signal characteristics
        signal_quality = signal_data.get('signal_score', 0.5)
        confidence_metrics = self.confidence_integrator.calculate_signal_confidence(signal_data)
        confidence_score = confidence_metrics.overall_confidence
        
        # Dynamic weighting
        if confidence_score > 0.8:
            # High confidence: Weight confidence and Kelly higher
            weights = {
                'volatility': 0.2,
                'kelly': 0.4,
                'confidence': 0.3,
                'risk_parity': 0.1
            }
        elif signal_quality > 0.7:
            # High signal quality: Balanced weighting
            weights = {
                'volatility': 0.3,
                'kelly': 0.25,
                'confidence': 0.25,
                'risk_parity': 0.2
            }
        else:
            # Lower quality: Conservative approach
            weights = {
                'volatility': 0.4,
                'kelly': 0.1,
                'confidence': 0.3,
                'risk_parity': 0.2
            }
        
        # Weighted combination
        combined_size = (
            weights['volatility'] * volatility_result.volatility_adjusted_size +
            weights['kelly'] * kelly_result.kelly_size +
            weights['confidence'] * confidence_result.confidence_adjusted_size +
            weights['risk_parity'] * risk_parity_result.confidence_adjusted_size
        )
        
        # Apply portfolio constraints
        max_position = portfolio_context.get('account_value', 100000) * self.config.max_position_size
        final_size = min(combined_size, max_position)
        
        reasoning = [
            f"Volatility weight: {weights['volatility']:.3f} -> {volatility_result.volatility_adjusted_size:.0f}",
            f"Kelly weight: {weights['kelly']:.3f} -> {kelly_result.kelly_size:.0f}",
            f"Confidence weight: {weights['confidence']:.3f} -> {confidence_result.confidence_adjusted_size:.0f}",
            f"Risk-parity weight: {weights['risk_parity']:.3f} -> {risk_parity_result.confidence_adjusted_size:.0f}",
            f"Combined size: {combined_size:.0f}",
            f"Final size (after constraints): {final_size:.0f}"
        ]
        
        return PositionSize(
            signal_id=signal_data.get('signal_id', ''),
            asset=asset,
            recommended_size=combined_size,
            method_used=PositionSizingMethod.HYBRID_ADAPTIVE,
            confidence_adjusted_size=combined_size,
            risk_adjusted_size=final_size,
            kelly_size=kelly_result.kelly_size,
            volatility_adjusted_size=volatility_result.volatility_adjusted_size,
            final_size=final_size,
            action=self._determine_action(final_size, signal_data),
            reasoning=reasoning,
            risk_metrics={
                'combined_weight': sum(weights.values()),
                'confidence_score': confidence_score,
                'signal_quality': signal_quality,
                'position_pct_of_portfolio': final_size / portfolio_context.get('account_value', 100000),
                'component_contributions': weights
            },
            metadata={
                'volatility_result': volatility_result.__dict__,
                'kelly_result': kelly_result.__dict__,
                'confidence_result': confidence_result.__dict__,
                'risk_parity_result': risk_parity_result.__dict__,
                'method_weights': weights
            }
        )
    
    def _estimate_asset_risk(self, signal_data: Dict[str, Any], 
                           market_data: Optional[pd.DataFrame] = None) -> float:
        """Varlık riskini tahmin et"""
        if market_data is not None and len(market_data) >= 20:
            returns = market_data['close'].pct_change().dropna()
            return returns.std() * np.sqrt(252)  # Annualized volatility
        else:
            # Default risk estimate based on historical returns in signal data
            historical_returns = signal_data.get('historical_returns', np.array([]))
            if len(historical_returns) > 0:
                return np.std(historical_returns) * np.sqrt(252)
            else:
                return 0.15  # Default 15% volatility
    
    def _determine_action(self, position_size: float, signal_data: Dict[str, Any]) -> PositionAction:
        """Pozisyon aksiyonunu belirle"""
        current_position = signal_data.get('current_position_size', 0.0)
        
        if position_size == 0:
            return PositionAction.CLOSE
        elif current_position == 0:
            return PositionAction.NEW_POSITION
        elif position_size > current_position * 1.05:  # 5% increase threshold
            return PositionAction.INCREASE
        elif position_size < current_position * 0.95:  # 5% decrease threshold
            return PositionAction.DECREASE
        else:
            return PositionAction.HOLD
    
    def batch_calculate_position_sizes(self, 
                                     signals_data: List[Dict[str, Any]],
                                     portfolio_context: Dict[str, Any],
                                     market_data: Dict[str, pd.DataFrame]) -> Dict[str, PositionSize]:
        """
        Birden fazla signal için pozisyon boyutları hesapla
        
        Args:
            signals_data: Sinyal verileri listesi
            portfolio_context: Portföy bağlamı
            market_data: Piyasa verisi
        
        Returns:
            Dict[str, PositionSize]: Signal ID -> Position size mapping
        """
        position_results = {}
        
        for signal_data in signals_data:
            signal_id = signal_data.get('signal_id', f'signal_{len(position_results)}')
            
            try:
                position_size = self.calculate_position_size(signal_data, portfolio_context, market_data)
                position_results[signal_id] = position_size
                
                # Add to history
                self.position_history.append(position_size)
                
            except Exception as e:
                print(f"Signal {signal_id} position sizing hatası: {e}")
                
                # Create error position size
                position_results[signal_id] = PositionSize(
                    signal_id=signal_id,
                    asset=signal_data.get('asset', 'UNKNOWN'),
                    recommended_size=0.0,
                    method_used=self.config.sizing_method,
                    confidence_adjusted_size=0.0,
                    risk_adjusted_size=0.0,
                    kelly_size=0.0,
                    volatility_adjusted_size=0.0,
                    final_size=0.0,
                    action=PositionAction.HOLD,
                    reasoning=[f"Position sizing error: {str(e)}"],
                    risk_metrics={'error': 1.0},
                    metadata={'error': str(e)}
                )
        
        return position_results
    
    def enforce_portfolio_constraints(self, 
                                    position_results: Dict[str, PositionSize],
                                    portfolio_context: Dict[str, Any]) -> Dict[str, PositionSize]:
        """
        Portföy seviyesinde kısıtlamaları uygula
        
        Args:
            position_results: Pozisyon boyutlandırma sonuçları
            portfolio_context: Portföy bağlamı
        
        Returns:
            Dict[str, PositionSize]: Constraint-adjusted position sizes
        """
        adjusted_results = position_results.copy()
        account_value = portfolio_context.get('account_value', 100000)
        
        # Calculate current portfolio metrics
        current_total_exposure = sum(pos.final_size for pos in self.current_positions.values())
        current_cash = portfolio_context.get('available_cash', account_value * 0.1)
        
        # Apply constraints
        constrained_results = self._apply_position_limits(adjusted_results, account_value)
        constrained_results = self._apply_sector_limits(constrained_results, portfolio_context)
        constrained_results = self._apply_cash_limits(constrained_results, current_cash, account_value)
        
        return constrained_results
    
    def _apply_position_limits(self, 
                             position_results: Dict[str, PositionSize],
                             account_value: float) -> Dict[str, PositionSize]:
        """Pozisyon limitlerini uygula"""
        max_position = account_value * self.config.max_position_size
        
        for signal_id, position in position_results.items():
            if position.final_size > max_position:
                position.final_size = max_position
                position.reasoning.append(f"Position limit uygulandı: {max_position:.0f}")
                position.risk_metrics['position_limit_applied'] = True
        
        return position_results
    
    def _apply_sector_limits(self, 
                           position_results: Dict[str, PositionSize],
                           portfolio_context: Dict[str, Any]) -> Dict[str, PositionSize]:
        """Sektör limitlerini uygula"""
        # Simplified sector exposure calculation
        sector_allocations = portfolio_context.get('sector_allocations', {})
        
        for signal_id, position in position_results.items():
            asset = position.asset
            # Bu implementasyonda simplified - gerçek uygulamada asset->sector mapping gerekli
            # sector = get_sector_for_asset(asset)
            
            # Şimdilik skip ediyoruz
            pass
        
        return position_results
    
    def _apply_cash_limits(self, 
                         position_results: Dict[str, PositionSize],
                         available_cash: float,
                         account_value: float) -> Dict[str, PositionSize]:
        """Nakit limitlerini uygula"""
        total_requested = sum(pos.final_size for pos in position_results.values())
        
        if total_requested > available_cash:
            # Scale down proportionally
            scale_factor = available_cash / total_requested
            
            for position in position_results.values():
                original_size = position.final_size
                position.final_size = original_size * scale_factor
                position.reasoning.append(f"Nakit limit uygulandı: {scale_factor:.3f} scaling")
                position.risk_metrics['cash_limit_applied'] = True
        
        return position_results
    
    def generate_position_sizing_report(self, 
                                      signals_data: List[Dict[str, Any]],
                                      portfolio_context: Dict[str, Any],
                                      market_data: Dict[str, pd.DataFrame]) -> Dict[str, Any]:
        """
        Kapsamlı pozisyon boyutlandırma raporu oluştur
        
        Args:
            signals_data: Sinyal verileri
            portfolio_context: Portföy bağlamı
            market_data: Piyasa verisi
        
        Returns:
            Dict[str, Any]: Position sizing report
        """
        # Calculate position sizes
        position_results = self.batch_calculate_position_sizes(
            signals_data, portfolio_context, market_data
        )
        
        # Apply constraints
        constrained_results = self.enforce_portfolio_constraints(
            position_results, portfolio_context
        )
        
        # Portfolio risk analysis
        portfolio_risk = self._analyze_portfolio_risk(constrained_results, portfolio_context)
        
        # Method effectiveness analysis
        method_analysis = self._analyze_method_performance()
        
        # Generate recommendations
        recommendations = self._generate_position_recommendations(constrained_results, portfolio_context)
        
        return {
            'timestamp': datetime.now().isoformat(),
            'configuration': {
                'sizing_method': self.config.sizing_method.value,
                'max_position_size': self.config.max_position_size,
                'volatility_target': self.config.volatility_target,
                'confidence_threshold': self.config.confidence_threshold,
                'legacy_mode': self.config.legacy_mode
            },
            'position_results': {
                signal_id: {
                    'asset': position.asset,
                    'final_size': position.final_size,
                    'method_used': position.method_used.value,
                    'action': position.action.value,
                    'reasoning': position.reasoning,
                    'risk_metrics': position.risk_metrics
                }
                for signal_id, position in constrained_results.items()
            },
            'portfolio_analysis': portfolio_risk,
            'method_analysis': method_analysis,
            'recommendations': recommendations,
            'summary_stats': {
                'total_positions': len(constrained_results),
                'total_allocated_value': sum(pos.final_size for pos in constrained_results.values()),
                'average_position_size': np.mean([pos.final_size for pos in constrained_results.values()]),
                'largest_position': max([pos.final_size for pos in constrained_results.values()]) if constrained_results else 0,
                'method_distribution': self._get_method_distribution(constrained_results)
            }
        }
    
    def _analyze_portfolio_risk(self, 
                              position_results: Dict[str, PositionSize],
                              portfolio_context: Dict[str, Any]) -> Dict[str, Any]:
        """Portföy risk analizi"""
        account_value = portfolio_context.get('account_value', 100000)
        positions = list(position_results.values())
        
        if not positions:
            return {'message': 'Pozisyon analizi yapılamadı'}
        
        # Risk metrics
        total_allocation = sum(pos.final_size for pos in positions)
        allocation_percentages = [pos.final_size / account_value for pos in positions]
        
        concentration_risk = max(allocation_percentages) if allocation_percentages else 0
        diversification_ratio = len(positions) / (sum(p**2 for p in allocation_percentages) + 1e-8)
        
        return {
            'total_allocation': total_allocation,
            'allocation_percentage': total_allocation / account_value,
            'concentration_risk': concentration_risk,
            'diversification_ratio': diversification_ratio,
            'number_of_positions': len(positions),
            'average_position_size': np.mean([pos.final_size for pos in positions]),
            'position_size_std': np.std([pos.final_size for pos in positions]),
            'risk_contribution_distribution': {
                'max_risk_contrib': max([pos.risk_metrics.get('position_pct_of_portfolio', 0) for pos in positions]),
                'min_risk_contrib': min([pos.risk_metrics.get('position_pct_of_portfolio', 1) for pos in positions]),
                'avg_risk_contrib': np.mean([pos.risk_metrics.get('position_pct_of_portfolio', 0) for pos in positions])
            }
        }
    
    def _analyze_method_performance(self) -> Dict[str, Any]:
        """Yöntem performans analizi"""
        if not self.position_history:
            return {'message': 'Pozisyon geçmişi bulunamadı'}
        
        # Method usage statistics
        method_counts = {}
        method_avg_sizes = {}
        
        for position in self.position_history[-100:]:  # Last 100 positions
            method = position.method_used.value
            method_counts[method] = method_counts.get(method, 0) + 1
            
            if method not in method_avg_sizes:
                method_avg_sizes[method] = []
            method_avg_sizes[method].append(position.final_size)
        
        return {
            'method_usage': method_counts,
            'method_avg_position_sizes': {
                method: np.mean(sizes) for method, sizes in method_avg_sizes.items()
            },
            'most_used_method': max(method_counts, key=method_counts.get) if method_counts else 'unknown'
        }
    
    def _generate_position_recommendations(self, 
                                         position_results: Dict[str, PositionSize],
                                         portfolio_context: Dict[str, Any]) -> List[str]:
        """Pozisyon önerileri oluştur"""
        recommendations = []
        
        # Concentration analysis
        positions = list(position_results.values())
        if positions:
            total_value = sum(pos.final_size for pos in positions)
            max_position_value = max(pos.final_size for pos in positions)
            concentration_ratio = max_position_value / (total_value + 1e-8)
            
            if concentration_ratio > 0.3:
                recommendations.append(
                    f"Yüksek konsantrasyon riski: En büyük pozisyon portföyün %{concentration_ratio*100:.1f}'i"
                )
        
        # Cash utilization
        allocated_value = sum(pos.final_size for pos in positions)
        account_value = portfolio_context.get('account_value', 100000)
        cash_utilization = allocated_value / account_value
        
        if cash_utilization < 0.6:
            recommendations.append(
                f"Düşük nakit kullanımı: %{cash_utilization*100:.1f} - daha fazla pozisyon değerlendirin"
            )
        elif cash_utilization > 0.95:
            recommendations.append(
                f"Yüksek nakit kullanımı: %{cash_utilization*100:.1f} - nakit rezervi koruyun"
            )
        
        # Method diversity
        methods_used = set(pos.method_used.value for pos in positions)
        if len(methods_used) == 1:
            recommendations.append(
                "Tek yöntem kullanımı: Farklı yöntemleri deneyerek risk dağılımını artırın"
            )
        
        if not recommendations:
            recommendations.append("Pozisyon dağılımı dengeli görünüyor")
        
        return recommendations
    
    def _get_method_distribution(self, position_results: Dict[str, PositionSize]) -> Dict[str, int]:
        """Yöntem dağılımını getir"""
        distribution = {}
        for position in position_results.values():
            method = position.method_used.value
            distribution[method] = distribution.get(method, 0) + 1
        return distribution


# Test fonksiyonu
def test_dynamic_position_sizer():
    """Dynamic Position Sizer test fonksiyonu"""
    
    # Test configuration
    config = PositionSizingConfig(
        sizing_method=PositionSizingMethod.HYBRID_ADAPTIVE,
        max_position_size=0.15,
        volatility_target=0.15,
        confidence_threshold=0.6
    )
    
    sizer = DynamicPositionSizer(config)
    
    # Test signals
    signals_data = [
        {
            'signal_id': 'signal_001',
            'asset': 'AAPL',
            'signal_score': 0.75,
            'historical_returns': np.random.normal(0.001, 0.02, 50),
            'current_position_size': 5000,
            'hedge_mode': True,
            'model_1_signal': 0.7,
            'model_2_signal': 0.8,
            'model_3_signal': 0.6,
            'model_4_signal': 0.9
        },
        {
            'signal_id': 'signal_002', 
            'asset': 'GOOGL',
            'signal_score': 0.55,
            'historical_returns': np.random.normal(0.0005, 0.025, 30),
            'current_position_size': 0
        },
        {
            'signal_id': 'signal_003',
            'asset': 'MSFT',
            'signal_score': 0.85,
            'historical_returns': np.random.normal(0.002, 0.015, 60),
            'current_position_size': 8000
        }
    ]
    
    # Portfolio context
    portfolio_context = {
        'account_value': 100000,
        'available_cash': 15000,
        'portfolio_risk': 0.18,
        'sector_allocations': {'Technology': 0.6},
        'assets': ['AAPL', 'GOOGL', 'MSFT']
    }
    
    # Market data (simplified)
    market_data = {}
    np.random.seed(42)
    for asset in ['AAPL', 'GOOGL', 'MSFT']:
        dates = pd.date_range(start='2023-01-01', periods=100, freq='D')
        base_price = np.random.uniform(100, 300)
        returns = np.random.normal(0.001, 0.02, 100)
        prices = base_price * np.cumprod(1 + returns)
        
        market_data[asset] = pd.DataFrame({
            'high': prices * 1.02,
            'low': prices * 0.98,
            'close': prices
        }, index=dates)
    
    # Test individual position sizing
    print("=== Individual Position Sizing Test ===")
    for signal_data in signals_data:
        try:
            position_size = sizer.calculate_position_size(signal_data, portfolio_context, market_data)
            
            print(f"\nSignal: {position_size.signal_id}")
            print(f"Asset: {position_size.asset}")
            print(f"Method: {position_size.method_used.value}")
            print(f"Final Size: ${position_size.final_size:,.0f}")
            print(f"Action: {position_size.action.value}")
            print(f"Reasoning: {position_size.reasoning}")
            
        except Exception as e:
            print(f"Error processing signal {signal_data.get('signal_id', 'unknown')}: {e}")
    
    # Test batch processing
    print("\n=== Batch Processing Test ===")
    try:
        report = sizer.generate_position_sizing_report(signals_data, portfolio_context, market_data)
        
        print(f"Total Positions: {report['summary_stats']['total_positions']}")
        print(f"Total Allocated: ${report['summary_stats']['total_allocated_value']:,.0f}")
        print(f"Average Position: ${report['summary_stats']['average_position_size']:,.0f}")
        
        print("\nPortfolio Analysis:")
        portfolio_analysis = report['portfolio_analysis']
        for key, value in portfolio_analysis.items():
            if isinstance(value, (int, float)):
                print(f"  {key}: {value:.3f}")
        
        print("\nRecommendations:")
        for rec in report['recommendations']:
            print(f"  - {rec}")
            
    except Exception as e:
        print(f"Batch processing error: {e}")
    
    return sizer


if __name__ == "__main__":
    test_dynamic_position_sizer()