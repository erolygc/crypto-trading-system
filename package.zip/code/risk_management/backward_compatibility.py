"""
Backward Compatibility Manager Modülü
====================================

Mevcut Bitwisers Account Managers ve Position Models sistemi ile 
tam uyumluluk sağlayan adaptör sistemi.

Bu modül:
- Mevcut Account Manager interface'lerini destekler
- Legacy Position Models (Model 1-4) ile çalışır
- HEDGE MODE ve 2x Quantity multiplier'ları handle eder
- Eski signal format'larını yeni sisteme dönüştürür
- Gradual migration desteği sağlar
- Test ve validation framework'ü içerir
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Union, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import json
import warnings

warnings.filterwarnings('ignore')


class LegacyAccountType(Enum):
    """Legacy account tipleri"""
    INDIVIDUAL = "individual"
    INSTITUTIONAL = "institutional"
    HEDGE_FUND = "hedge_fund"
    FAMILY_OFFICE = "family_office"
    ADVISORY = "advisory"


class LegacyPositionModel(Enum):
    """Legacy position modelleri"""
    MODEL_1 = "Model_1"
    MODEL_2 = "Model_2" 
    MODEL_3 = "Model_3"
    MODEL_4 = "Model_4"


class LegacySignalType(Enum):
    """Legacy signal tipleri"""
    TECHNICAL = "technical"
    FUNDAMENTAL = "fundamental"
    SENTIMENT = "sentiment"
    QUANTITATIVE = "quantitative"
    EVENT_DRIVEN = "event_driven"
    MACRO_ECONOMIC = "macro_economic"


@dataclass
class LegacyAccountConfig:
    """Legacy account konfigürasyonu"""
    account_id: str
    account_type: LegacyAccountType
    account_value: float
    max_position_size: float = 0.15
    hedge_mode: bool = False
    quantity_multiplier: float = 1.0
    risk_tolerance: str = "moderate"  # conservative, moderate, aggressive
    max_leverage: float = 2.0
    min_cash_reserve: float = 0.10
    model_weights: Dict[LegacyPositionModel, float] = field(default_factory=lambda: {
        LegacyPositionModel.MODEL_1: 0.3,
        LegacyPositionModel.MODEL_2: 0.25,
        LegacyPositionModel.MODEL_3: 0.25,
        LegacyPositionModel.MODEL_4: 0.20
    })
    custom_constraints: Dict[str, Any] = field(default_factory=dict)


@dataclass
class LegacySignal:
    """Legacy signal format"""
    signal_id: str
    signal_type: LegacySignalType
    asset: str
    timestamp: datetime
    signal_strength: float  # 0-1
    confidence: float  # 0-1
    
    # Model-specific outputs
    model_1_output: Optional[float] = None
    model_2_output: Optional[float] = None
    model_3_output: Optional[float] = None
    model_4_output: Optional[float] = None
    
    # Additional legacy fields
    sector: str = "Unknown"
    expiry_date: Optional[datetime] = None
    hedge_mode: bool = False
    quantity_multiplier: float = 1.0
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    max_position_size: float = 0.15
    
    # Metadata
    strategy_name: str = "legacy"
    source: str = "legacy_system"
    additional_data: Dict[str, Any] = field(default_factory=dict)


@dataclass
class LegacyPosition:
    """Legacy position format"""
    position_id: str
    account_id: str
    asset: str
    quantity: float
    entry_price: float
    current_price: float
    entry_date: datetime
    position_type: str = "long"  # long, short
    model_used: LegacyPositionModel = LegacyPositionModel.MODEL_1
    hedge_position: bool = False
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None
    notes: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CompatibilityMapping:
    """Uyumluluk mapping'i"""
    legacy_to_new_field: Dict[str, str]
    new_to_legacy_field: Dict[str, str]
    conversion_functions: Dict[str, Callable]
    validation_rules: Dict[str, Any]


class BackwardCompatibilityManager:
    """
    Backward Compatibility Manager
    
    Mevcut sistem ile yeni dinamik pozisyon boyutlandırma sistemi arasında
    tam uyumluluk sağlayan adaptör.
    """
    
    def __init__(self):
        """Backward Compatibility Manager başlat"""
        self.legacy_accounts: Dict[str, LegacyAccountConfig] = {}
        self.legacy_positions: Dict[str, LegacyPosition] = {}
        self.legacy_signals: Dict[str, LegacySignal] = {}
        
        # Mapping configurations
        self.field_mappings = self._initialize_field_mappings()
        self.conversion_functions = self._initialize_conversion_functions()
        self.validation_rules = self._initialize_validation_rules()
        
        # Migration tracking
        self.migration_log: List[Dict[str, Any]] = []
        self.compatibility_issues: List[str] = []
        
        # Statistics
        self.conversion_stats = {
            'accounts_migrated': 0,
            'signals_converted': 0,
            'positions_migrated': 0,
            'conversion_errors': 0,
            'compatibility_score': 0.0
        }
    
    def _initialize_field_mappings(self) -> Dict[str, CompatibilityMapping]:
        """Field mapping'leri başlat"""
        # Signal field mappings
        signal_mappings = CompatibilityMapping(
            legacy_to_new_field={
                'signal_strength': 'signal_score',
                'confidence': 'overall_confidence',
                'model_1_output': 'model_1_signal',
                'model_2_output': 'model_2_signal',
                'model_3_output': 'model_3_signal',
                'model_4_output': 'model_4_signal',
                'quantity_multiplier': 'legacy_quantity_multiplier',
                'max_position_size': 'legacy_max_position_size'
            },
            new_to_legacy_field={
                'signal_score': 'signal_strength',
                'overall_confidence': 'confidence',
                'model_1_signal': 'model_1_output',
                'model_2_signal': 'model_2_output',
                'model_3_signal': 'model_3_output',
                'model_4_signal': 'model_4_output'
            },
            conversion_functions={},
            validation_rules={}
        )
        
        # Account field mappings
        account_mappings = CompatibilityMapping(
            legacy_to_new_field={
                'account_value': 'account_value',
                'max_position_size': 'max_position_size',
                'hedge_mode': 'hedge_mode',
                'quantity_multiplier': 'legacy_multiplier'
            },
            new_to_legacy_field={
                'account_value': 'account_value',
                'max_position_size': 'max_position_size',
                'hedge_mode': 'hedge_mode',
                'legacy_multiplier': 'quantity_multiplier'
            },
            conversion_functions={},
            validation_rules={}
        )
        
        return {
            'signal': signal_mappings,
            'account': account_mappings
        }
    
    def _initialize_conversion_functions(self) -> Dict[str, Callable]:
        """Conversion fonksiyonlarını başlat"""
        return {
            # Signal type conversion
            'legacy_signal_type_to_new': self._convert_legacy_signal_type,
            'new_signal_type_to_legacy': self._convert_new_signal_type,
            
            # Account type conversion
            'legacy_account_type_to_new': self._convert_legacy_account_type,
            'new_account_type_to_legacy': self._convert_new_account_type,
            
            # Model conversion
            'legacy_model_to_new': self._convert_legacy_model,
            'new_model_to_legacy': self._convert_new_model,
            
            # Position type conversion
            'legacy_position_type_to_new': self._convert_legacy_position_type,
            'new_position_type_to_legacy': self._convert_new_position_type
        }
    
    def _initialize_validation_rules(self) -> Dict[str, Any]:
        """Validation kurallarını başlat"""
        return {
            'signal': {
                'signal_strength': {'min': 0.0, 'max': 1.0},
                'confidence': {'min': 0.0, 'max': 1.0},
                'model_outputs': {'min': -1.0, 'max': 2.0}
            },
            'account': {
                'account_value': {'min': 0.0},
                'max_position_size': {'min': 0.01, 'max': 1.0},
                'hedge_mode': {'type': bool},
                'quantity_multiplier': {'min': 0.1, 'max': 10.0}
            },
            'position': {
                'quantity': {'min': -1000000, 'max': 1000000},
                'entry_price': {'min': 0.01},
                'current_price': {'min': 0.01}
            }
        }
    
    def register_legacy_account(self, legacy_config: LegacyAccountConfig):
        """Legacy account'ı kaydet"""
        self.legacy_accounts[legacy_config.account_id] = legacy_config
        print(f"Legacy account registered: {legacy_config.account_id}")
    
    def register_legacy_position(self, legacy_position: LegacyPosition):
        """Legacy position'ı kaydet"""
        self.legacy_positions[legacy_position.position_id] = legacy_position
        print(f"Legacy position registered: {legacy_position.position_id}")
    
    def register_legacy_signal(self, legacy_signal: LegacySignal):
        """Legacy signal'ı kaydet"""
        self.legacy_signals[legacy_signal.signal_id] = legacy_signal
        print(f"Legacy signal registered: {legacy_signal.signal_id}")
    
    def convert_legacy_signal_to_new_format(self, legacy_signal: LegacySignal) -> Dict[str, Any]:
        """
        Legacy signal'i yeni formata dönüştür
        
        Args:
            legacy_signal: Legacy signal
        
        Returns:
            Dict[str, Any]: Yeni format signal
        """
        try:
            # Base conversion
            new_signal = {
                'signal_id': legacy_signal.signal_id,
                'signal_type': self.conversion_functions['legacy_signal_type_to_new'](legacy_signal.signal_type.value),
                'asset': legacy_signal.asset,
                'timestamp': legacy_signal.timestamp.isoformat(),
                'signal_score': legacy_signal.signal_strength,
                'overall_confidence': legacy_signal.confidence,
                'strategy_name': legacy_signal.strategy_name,
                'source': legacy_signal.source,
                'hedge_mode': legacy_signal.hedge_mode,
                'legacy_quantity_multiplier': legacy_signal.quantity_multiplier,
                'legacy_max_position_size': legacy_signal.max_position_size,
                'sector': legacy_signal.sector,
                'model_weights': {
                    'Model_1': legacy_signal.model_1_output or 0.0,
                    'Model_2': legacy_signal.model_2_output or 0.0,
                    'Model_3': legacy_signal.model_3_output or 0.0,
                    'Model_4': legacy_signal.model_4_output or 0.0
                }
            }
            
            # Add stop loss and take profit if available
            if legacy_signal.stop_loss:
                new_signal['stop_loss'] = legacy_signal.stop_loss
            
            if legacy_signal.take_profit:
                new_signal['take_profit'] = legacy_signal.take_profit
            
            # Add expiry date if available
            if legacy_signal.expiry_date:
                new_signal['expiry_date'] = legacy_signal.expiry_date.isoformat()
            
            # Add additional data
            new_signal['additional_data'] = legacy_signal.additional_data
            
            # Validation
            self._validate_converted_signal(new_signal)
            
            # Log migration
            self._log_migration('signal', legacy_signal.signal_id, 'success')
            
            return new_signal
            
        except Exception as e:
            error_msg = f"Signal conversion error for {legacy_signal.signal_id}: {str(e)}"
            print(error_msg)
            self.compatibility_issues.append(error_msg)
            self._log_migration('signal', legacy_signal.signal_id, 'error', str(e))
            
            # Return minimal valid signal
            return self._create_fallback_signal(legacy_signal)
    
    def convert_legacy_account_to_new_format(self, legacy_config: LegacyAccountConfig) -> Dict[str, Any]:
        """
        Legacy account'ı yeni formata dönüştür
        
        Args:
            legacy_config: Legacy account config
        
        Returns:
            Dict[str, Any]: Yeni format account config
        """
        try:
            new_config = {
                'account_id': legacy_config.account_id,
                'account_type': self.conversion_functions['legacy_account_type_to_new'](legacy_config.account_type.value),
                'account_value': legacy_config.account_value,
                'max_position_size': legacy_config.max_position_size,
                'hedge_mode': legacy_config.hedge_mode,
                'legacy_multiplier': legacy_config.quantity_multiplier,
                'risk_tolerance': legacy_config.risk_tolerance,
                'max_leverage': legacy_config.max_leverage,
                'min_cash_reserve': legacy_config.min_cash_reserve,
                'model_weights': {
                    'Model_1': legacy_config.model_weights[LegacyPositionModel.MODEL_1],
                    'Model_2': legacy_config.model_weights[LegacyPositionModel.MODEL_2],
                    'Model_3': legacy_config.model_weights[LegacyPositionModel.MODEL_3],
                    'Model_4': legacy_config.model_weights[LegacyPositionModel.MODEL_4]
                }
            }
            
            # Add custom constraints
            new_config['custom_constraints'] = legacy_config.custom_constraints
            
            # Validation
            self._validate_converted_account(new_config)
            
            # Log migration
            self._log_migration('account', legacy_config.account_id, 'success')
            
            return new_config
            
        except Exception as e:
            error_msg = f"Account conversion error for {legacy_config.account_id}: {str(e)}"
            print(error_msg)
            self.compatibility_issues.append(error_msg)
            self._log_migration('account', legacy_config.account_id, 'error', str(e))
            
            # Return minimal valid account
            return self._create_fallback_account(legacy_config)
    
    def batch_convert_signals(self, legacy_signals: List[LegacySignal]) -> List[Dict[str, Any]]:
        """
        Birden fazla legacy signal'i dönüştür
        
        Args:
            legacy_signals: Legacy signal listesi
        
        Returns:
            List[Dict[str, Any]]: Yeni format signal listesi
        """
        converted_signals = []
        
        for legacy_signal in legacy_signals:
            try:
                new_signal = self.convert_legacy_signal_to_new_format(legacy_signal)
                converted_signals.append(new_signal)
                
            except Exception as e:
                print(f"Batch conversion error for signal {legacy_signal.signal_id}: {e}")
                self.conversion_stats['conversion_errors'] += 1
        
        self.conversion_stats['signals_converted'] = len(converted_signals)
        return converted_signals
    
    def process_legacy_account_management(self, 
                                        legacy_account_configs: List[LegacyAccountConfig],
                                        legacy_signals: List[LegacySignal]) -> Dict[str, Any]:
        """
        Legacy account management işlemini gerçekleştir
        
        Args:
            legacy_account_configs: Legacy account konfigürasyonları
            legacy_signals: Legacy signal'lar
        
        Returns:
            Dict[str, Any]: Processing sonuçları
        """
        results = {
            'converted_accounts': [],
            'processed_signals': [],
            'account_recommendations': {},
            'signal_recommendations': {},
            'migration_summary': {},
            'compatibility_issues': self.compatibility_issues.copy()
        }
        
        # Convert accounts
        for legacy_account in legacy_account_configs:
            try:
                new_account_config = self.convert_legacy_account_to_new_format(legacy_account)
                results['converted_accounts'].append(new_account_config)
                
                # Generate recommendations for account
                recommendations = self._generate_legacy_account_recommendations(legacy_account)
                results['account_recommendations'][legacy_account.account_id] = recommendations
                
            except Exception as e:
                print(f"Account processing error: {e}")
        
        # Convert signals
        converted_signals = self.batch_convert_signals(legacy_signals)
        results['processed_signals'] = converted_signals
        
        # Generate signal recommendations
        for legacy_signal in legacy_signals:
            recommendations = self._generate_legacy_signal_recommendations(legacy_signal)
            results['signal_recommendations'][legacy_signal.signal_id] = recommendations
        
        # Update statistics
        self.conversion_stats['accounts_migrated'] = len(results['converted_accounts'])
        self.conversion_stats['positions_migrated'] = len(self.legacy_positions)
        
        # Calculate compatibility score
        self.conversion_stats['compatibility_score'] = self._calculate_compatibility_score()
        
        # Create migration summary
        results['migration_summary'] = self.conversion_stats.copy()
        
        return results
    
    def _convert_legacy_signal_type(self, legacy_type: str) -> str:
        """Legacy signal type'ı yeni formata dönüştür"""
        mapping = {
            'technical': 'momentum',
            'fundamental': 'value',
            'sentiment': 'sentiment',
            'quantitative': 'statistical',
            'event_driven': 'event',
            'macro_economic': 'macro'
        }
        return mapping.get(legacy_type, 'unknown')
    
    def _convert_new_signal_type(self, new_type: str) -> str:
        """Yeni signal type'ı legacy formata dönüştür"""
        mapping = {
            'momentum': 'technical',
            'value': 'fundamental',
            'sentiment': 'sentiment',
            'statistical': 'quantitative',
            'event': 'event_driven',
            'macro': 'macro_economic'
        }
        return mapping.get(new_type, 'unknown')
    
    def _convert_legacy_account_type(self, legacy_type: str) -> str:
        """Legacy account type'ı yeni formata dönüştür"""
        mapping = {
            'individual': 'retail',
            'institutional': 'institutional',
            'hedge_fund': 'hedge_fund',
            'family_office': 'family_office',
            'advisory': 'advisory'
        }
        return mapping.get(legacy_type, 'unknown')
    
    def _convert_new_account_type(self, new_type: str) -> str:
        """Yeni account type'ı legacy formata dönüştür"""
        mapping = {
            'retail': 'individual',
            'institutional': 'institutional',
            'hedge_fund': 'hedge_fund',
            'family_office': 'family_office',
            'advisory': 'advisory'
        }
        return mapping.get(new_type, 'unknown')
    
    def _convert_legacy_model(self, model: str) -> str:
        """Legacy model'i yeni formata dönüştür"""
        return f"model_{model.lower().replace('_', '_')}"
    
    def _convert_new_model(self, model: str) -> str:
        """Yeni model'i legacy formata dönüştür"""
        return model.replace('model_', 'Model_')
    
    def _convert_legacy_position_type(self, pos_type: str) -> str:
        """Legacy position type'ı yeni formata dönüştür"""
        return pos_type  # Same in both formats
    
    def _convert_new_position_type(self, pos_type: str) -> str:
        """Yeni position type'ı legacy formata dönüştür"""
        return pos_type  # Same in both formats
    
    def _validate_converted_signal(self, signal: Dict[str, Any]):
        """Dönüştürülmüş signal'i validate et"""
        rules = self.validation_rules['signal']
        
        for field, rule in rules.items():
            if field in signal:
                value = signal[field]
                
                if 'min' in rule and value < rule['min']:
                    raise ValueError(f"{field} below minimum: {value} < {rule['min']}")
                
                if 'max' in rule and value > rule['max']:
                    raise ValueError(f"{field} above maximum: {value} > {rule['max']}")
    
    def _validate_converted_account(self, account: Dict[str, Any]):
        """Dönüştürülmüş account'u validate et"""
        rules = self.validation_rules['account']
        
        for field, rule in rules.items():
            if field in account:
                value = account[field]
                
                if 'min' in rule and value < rule['min']:
                    raise ValueError(f"{field} below minimum: {value} < {rule['min']}")
                
                if 'max' in rule and value > rule['max']:
                    raise ValueError(f"{field} above maximum: {value} > {rule['max']}")
                
                if 'type' in rule and type(value) != rule['type']:
                    raise ValueError(f"{field} type mismatch: expected {rule['type']}, got {type(value)}")
    
    def _create_fallback_signal(self, legacy_signal: LegacySignal) -> Dict[str, Any]:
        """Conversion hatası durumunda fallback signal oluştur"""
        return {
            'signal_id': legacy_signal.signal_id,
            'signal_type': 'unknown',
            'asset': legacy_signal.asset,
            'timestamp': legacy_signal.timestamp.isoformat(),
            'signal_score': 0.5,  # Default neutral score
            'overall_confidence': 0.5,
            'strategy_name': 'legacy_fallback',
            'source': 'conversion_error',
            'hedge_mode': legacy_signal.hedge_mode,
            'legacy_quantity_multiplier': 1.0,
            'legacy_max_position_size': 0.15,
            'sector': 'Unknown',
            'model_weights': {'Model_1': 0.25, 'Model_2': 0.25, 'Model_3': 0.25, 'Model_4': 0.25},
            'additional_data': {'conversion_error': True},
            'conversion_warnings': [f'Original signal conversion failed for {legacy_signal.signal_id}']
        }
    
    def _create_fallback_account(self, legacy_config: LegacyAccountConfig) -> Dict[str, Any]:
        """Conversion hatası durumunda fallback account oluştur"""
        return {
            'account_id': legacy_config.account_id,
            'account_type': 'unknown',
            'account_value': 100000,  # Default value
            'max_position_size': 0.15,
            'hedge_mode': False,
            'legacy_multiplier': 1.0,
            'risk_tolerance': 'moderate',
            'max_leverage': 2.0,
            'min_cash_reserve': 0.10,
            'model_weights': {'Model_1': 0.25, 'Model_2': 0.25, 'Model_3': 0.25, 'Model_4': 0.25},
            'custom_constraints': {},
            'conversion_error': True
        }
    
    def _generate_legacy_account_recommendations(self, legacy_config: LegacyAccountConfig) -> List[str]:
        """Legacy account için öneriler oluştur"""
        recommendations = []
        
        # HEDGE MODE recommendations
        if legacy_config.hedge_mode:
            recommendations.append("HEDGE MODE aktif - pozisyon boyutları 2x multiplier ile ayarlanacak")
        
        # Risk tolerance recommendations
        if legacy_config.risk_tolerance == 'conservative':
            recommendations.append("Muhafazakar risk toleransı - daha düşük position sizing önerilir")
        elif legacy_config.risk_tolerance == 'aggressive':
            recommendations.append("Agresif risk toleransı - higher leverage ve position size uygulanabilir")
        
        # Model weight recommendations
        total_weight = sum(legacy_config.model_weights.values())
        if abs(total_weight - 1.0) > 0.01:
            recommendations.append(f"Model ağırlıkları normalizasyon gerekli: toplam {total_weight:.3f}")
        
        # Leverage recommendations
        if legacy_config.max_leverage > 3.0:
            recommendations.append("Yüksek leverage tespit edildi - risk yönetimi kritik")
        
        return recommendations
    
    def _generate_legacy_signal_recommendations(self, legacy_signal: LegacySignal) -> List[str]:
        """Legacy signal için öneriler oluştur"""
        recommendations = []
        
        # Signal strength recommendations
        if legacy_signal.signal_strength > 0.8:
            recommendations.append("Yüksek sinyal gücü - büyük pozisyon boyutu önerilir")
        elif legacy_signal.signal_strength < 0.3:
            recommendations.append("Düşük sinyal gücü - küçük pozisyon boyutu veya pozisyon alma")
        
        # Confidence recommendations
        if legacy_signal.confidence < 0.6:
            recommendations.append("Düşük confidence - ek doğrulama gerekebilir")
        
        # Model output recommendations
        model_outputs = [
            legacy_signal.model_1_output,
            legacy_signal.model_2_output,
            legacy_signal.model_3_output,
            legacy_signal.model_4_output
        ]
        
        non_zero_outputs = [x for x in model_outputs if x is not None]
        if len(non_zero_outputs) > 0:
            avg_output = np.mean(non_zero_outputs)
            if avg_output > 0.7:
                recommendations.append("Güçlü model consensus - pozisyon artırımı değerlendir")
            elif avg_output < 0.3:
                recommendations.append("Zayıf model consensus - pozisyon azaltımı değerlendir")
        
        return recommendations
    
    def _log_migration(self, item_type: str, item_id: str, status: str, error: str = None):
        """Migration log'u güncelle"""
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'type': item_type,
            'id': item_id,
            'status': status,
            'error': error
        }
        
        self.migration_log.append(log_entry)
        
        # Keep log size reasonable
        if len(self.migration_log) > 1000:
            self.migration_log = self.migration_log[-500:]
    
    def _calculate_compatibility_score(self) -> float:
        """Compatibility score hesapla"""
        if not self.migration_log:
            return 0.0
        
        successful_migrations = len([log for log in self.migration_log if log['status'] == 'success'])
        total_migrations = len(self.migration_log)
        
        if total_migrations == 0:
            return 0.0
        
        base_score = successful_migrations / total_migrations
        
        # Penalize for errors
        error_count = len([log for log in self.migration_log if log['status'] == 'error'])
        error_penalty = min(error_count / total_migrations, 0.3)
        
        # Penalty for compatibility issues
        issue_penalty = min(len(self.compatibility_issues) / 10, 0.2)
        
        final_score = max(0.0, base_score - error_penalty - issue_penalty)
        
        return final_score
    
    def get_compatibility_report(self) -> Dict[str, Any]:
        """
        Compatibility raporu oluştur
        
        Returns:
            Dict[str, Any]: Kapsamlı compatibility raporu
        """
        return {
            'timestamp': datetime.now().isoformat(),
            'conversion_statistics': self.conversion_stats,
            'compatibility_score': self._calculate_compatibility_score(),
            'registered_accounts': len(self.legacy_accounts),
            'registered_positions': len(self.legacy_positions),
            'registered_signals': len(self.legacy_signals),
            'migration_log_summary': {
                'total_migrations': len(self.migration_log),
                'successful_migrations': len([log for log in self.migration_log if log['status'] == 'success']),
                'failed_migrations': len([log for log in self.migration_log if log['status'] == 'error']),
                'recent_migrations': self.migration_log[-10:] if len(self.migration_log) >= 10 else self.migration_log
            },
            'compatibility_issues': self.compatibility_issues,
            'field_mappings': {
                mapping_type: {
                    'legacy_to_new': mapping.legacy_to_new_field,
                    'new_to_legacy': mapping.new_to_legacy_field
                }
                for mapping_type, mapping in self.field_mappings.items()
            },
            'validation_rules': self.validation_rules,
            'recommendations': self._generate_compatibility_recommendations()
        }
    
    def _generate_compatibility_recommendations(self) -> List[str]:
        """Compatibility önerilerini oluştur"""
        recommendations = []
        
        # High error rate
        if self.conversion_stats['conversion_errors'] > 0:
            error_rate = self.conversion_stats['conversion_errors'] / max(self.conversion_stats['signals_converted'], 1)
            if error_rate > 0.1:
                recommendations.append(
                    f"Yüksek conversion error rate: %{error_rate:.1%} - field mapping'leri gözden geçirin"
                )
        
        # Low compatibility score
        if self._calculate_compatibility_score() < 0.8:
            recommendations.append(
                "Düşük compatibility score - daha fazla testing gerekli"
            )
        
        # Many compatibility issues
        if len(self.compatibility_issues) > 5:
            recommendations.append(
                f"Çok sayıda compatibility issue: {len(self.compatibility_issues)} - systematic review gerekli"
            )
        
        # Missing legacy data
        if len(self.legacy_accounts) == 0:
            recommendations.append("Kayıtlı legacy account bulunamadı - migration test edilmeli")
        
        if len(self.legacy_signals) == 0:
            recommendations.append("Kayıtlı legacy signal bulunamadı - signal conversion test edilmeli")
        
        if not recommendations:
            recommendations.append("Compatibility durumu iyi - production'a hazır")
        
        return recommendations
    
    def export_legacy_data(self, filepath: str):
        """Legacy data'yı dosyaya export et"""
        export_data = {
            'legacy_accounts': {
                account_id: {
                    'account_id': config.account_id,
                    'account_type': config.account_type.value,
                    'account_value': config.account_value,
                    'max_position_size': config.max_position_size,
                    'hedge_mode': config.hedge_mode,
                    'quantity_multiplier': config.quantity_multiplier,
                    'risk_tolerance': config.risk_tolerance,
                    'max_leverage': config.max_leverage,
                    'min_cash_reserve': config.min_cash_reserve,
                    'model_weights': {model.value: weight for model, weight in config.model_weights.items()},
                    'custom_constraints': config.custom_constraints
                }
                for account_id, config in self.legacy_accounts.items()
            },
            'legacy_positions': {
                position_id: {
                    'position_id': position.position_id,
                    'account_id': position.account_id,
                    'asset': position.asset,
                    'quantity': position.quantity,
                    'entry_price': position.entry_price,
                    'current_price': position.current_price,
                    'entry_date': position.entry_date.isoformat(),
                    'position_type': position.position_type,
                    'model_used': position.model_used.value,
                    'hedge_position': position.hedge_position,
                    'stop_loss': position.stop_loss,
                    'take_profit': position.take_profit,
                    'notes': position.notes,
                    'metadata': position.metadata
                }
                for position_id, position in self.legacy_positions.items()
            },
            'legacy_signals': {
                signal_id: {
                    'signal_id': signal.signal_id,
                    'signal_type': signal.signal_type.value,
                    'asset': signal.asset,
                    'timestamp': signal.timestamp.isoformat(),
                    'signal_strength': signal.signal_strength,
                    'confidence': signal.confidence,
                    'model_1_output': signal.model_1_output,
                    'model_2_output': signal.model_2_output,
                    'model_3_output': signal.model_3_output,
                    'model_4_output': signal.model_4_output,
                    'sector': signal.sector,
                    'expiry_date': signal.expiry_date.isoformat() if signal.expiry_date else None,
                    'hedge_mode': signal.hedge_mode,
                    'quantity_multiplier': signal.quantity_multiplier,
                    'stop_loss': signal.stop_loss,
                    'take_profit': signal.take_profit,
                    'max_position_size': signal.max_position_size,
                    'strategy_name': signal.strategy_name,
                    'source': signal.source,
                    'additional_data': signal.additional_data
                }
                for signal_id, signal in self.legacy_signals.items()
            }
        }
        
        with open(filepath, 'w') as f:
            json.dump(export_data, f, indent=2, default=str)
        
        print(f"Legacy data exported to {filepath}")


# Test fonksiyonu
def test_backward_compatibility_manager():
    """Backward Compatibility Manager test fonksiyonu"""
    
    compat_manager = BackwardCompatibilityManager()
    
    # Create legacy test data
    legacy_account = LegacyAccountConfig(
        account_id="test_account_001",
        account_type=LegacyAccountType.HEDGE_FUND,
        account_value=1000000,
        max_position_size=0.20,
        hedge_mode=True,
        quantity_multiplier=2.0,
        risk_tolerance="aggressive",
        max_leverage=3.0
    )
    
    legacy_signal = LegacySignal(
        signal_id="legacy_signal_001",
        signal_type=LegacySignalType.QUANTITATIVE,
        asset="AAPL",
        timestamp=datetime.now(),
        signal_strength=0.75,
        confidence=0.85,
        model_1_output=0.7,
        model_2_output=0.8,
        model_3_output=0.6,
        model_4_output=0.9,
        sector="Technology",
        hedge_mode=True,
        quantity_multiplier=2.0,
        strategy_name="legacy_momentum"
    )
    
    legacy_position = LegacyPosition(
        position_id="position_001",
        account_id="test_account_001",
        asset="AAPL",
        quantity=1000,
        entry_price=150.0,
        current_price=155.0,
        entry_date=datetime.now() - timedelta(days=30),
        model_used=LegacyPositionModel.MODEL_1,
        hedge_position=True
    )
    
    # Register legacy data
    compat_manager.register_legacy_account(legacy_account)
    compat_manager.register_legacy_signal(legacy_signal)
    compat_manager.register_legacy_position(legacy_position)
    
    # Test individual conversions
    print("=== Individual Conversions ===")
    
    # Account conversion
    new_account = compat_manager.convert_legacy_account_to_new_format(legacy_account)
    print(f"Account converted: {new_account['account_id']}")
    print(f"HEDGE MODE: {new_account['hedge_mode']}")
    print(f"Legacy Multiplier: {new_account['legacy_multiplier']}")
    
    # Signal conversion
    new_signal = compat_manager.convert_legacy_signal_to_new_format(legacy_signal)
    print(f"\nSignal converted: {new_signal['signal_id']}")
    print(f"Asset: {new_signal['asset']}")
    print(f"HEDGE MODE: {new_signal['hedge_mode']}")
    print(f"Signal Score: {new_signal['signal_score']}")
    print(f"Model Weights: {new_signal['model_weights']}")
    
    # Test batch processing
    print("\n=== Batch Processing ===")
    results = compat_manager.process_legacy_account_management(
        [legacy_account], [legacy_signal]
    )
    
    print(f"Converted Accounts: {len(results['converted_accounts'])}")
    print(f"Processed Signals: {len(results['processed_signals'])}")
    
    print("\nAccount Recommendations:")
    for account_id, recommendations in results['account_recommendations'].items():
        print(f"  {account_id}:")
        for rec in recommendations:
            print(f"    - {rec}")
    
    print("\nSignal Recommendations:")
    for signal_id, recommendations in results['signal_recommendations'].items():
        print(f"  {signal_id}:")
        for rec in recommendations:
            print(f"    - {rec}")
    
    # Get compatibility report
    print("\n=== Compatibility Report ===")
    report = compat_manager.get_compatibility_report()
    
    print(f"Compatibility Score: {report['compatibility_score']:.3f}")
    print(f"Total Migrations: {report['migration_log_summary']['total_migrations']}")
    print(f"Successful Migrations: {report['migration_log_summary']['successful_migrations']}")
    print(f"Failed Migrations: {report['migration_log_summary']['failed_migrations']}")
    
    print("\nRecommendations:")
    for rec in report['recommendations']:
        print(f"  - {rec}")
    
    # Test export
    print("\n=== Export Test ===")
    try:
        compat_manager.export_legacy_data("/tmp/legacy_data_export.json")
        print("Legacy data export successful")
    except Exception as e:
        print(f"Export failed: {e}")
    
    return compat_manager, report


if __name__ == "__main__":
    test_backward_compatibility_manager()