"""
Kelly Criterion Optimizer Modülü
================================

Kelly Criterion kullanarak optimal pozisyon boyutlandırması yapan 
gelişmiş optimizasyon sistemi.

Kelly Criterion finansal portföy yönetiminde optimal bahis boyutunu 
belirlemek için kullanılan matematiksel formüldür. Bu modül:

- Kelly Criterion hesaplamaları yapar
- Fractional Kelly implementation sağlar
- Multi-outcome Kelly scenarios handle eder
- Risk-adjusted Kelly optimizations yapar
- Portfolio-level Kelly allocation yapar
- Backward compatibility sağlar
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
from scipy.optimize import minimize_scalar, minimize
import warnings

warnings.filterwarnings('ignore')


class KellyMethod(Enum):
    """Kelly method tipleri"""
    CLASSIC_KELLY = "classic_kelly"
    FRACTIONAL_KELLY = "fractional_kelly"
    RISK_ADJUSTED_KELLY = "risk_adjusted_kelly"
    MULTI_OUTCOME_KELLY = "multi_outcome_kelly"
    DYNAMIC_KELLY = "dynamic_kelly"
    PORTFOLIO_KELLY = "portfolio_kelly"


class OutcomeType(Enum):
    """Sonuç tipleri"""
    WIN = "win"
    LOSS = "loss"
    TIE = "tie"
    PARTIAL_LOSS = "partial_loss"
    PARTIAL_WIN = "partial_win"


@dataclass
class Outcome:
    """Kelly outcome"""
    outcome_type: OutcomeType
    probability: float
    return_multiple: float  # e.g., 2.0 for double your money
    description: str = ""


@dataclass
class KellyCalculation:
    """Kelly hesaplama sonucu"""
    signal_id: str
    asset: str
    kelly_fraction: float
    fractional_kelly: float
    risk_adjusted_kelly: float
    confidence_multiplier: float
    final_allocation: float
    expected_return: float
    expected_variance: float
    sharpe_kelly: float
    utility_score: float
    calculation_details: Dict[str, Any]
    warnings: List[str]


@dataclass
class KellyConfig:
    """Kelly optimization konfigürasyonu"""
    # Kelly parameters
    method: KellyMethod = KellyMethod.RISK_ADJUSTED_KELLY
    fractional_multiplier: float = 0.25  # Conservative 25% of optimal Kelly
    risk_aversion: float = 2.0  # CRRA utility parameter
    max_position_size: float = 0.20  # Max 20% allocation per asset
    max_portfolio_risk: float = 0.25  # Max 25% portfolio risk
    
    # Backward compatibility
    legacy_mode: bool = False
    legacy_boost_factor: float = 2.0  # 2x for HEDGE MODE
    
    # Constraints
    min_kelly_fraction: float = 0.0
    max_kelly_fraction: float = 1.0
    max_leverage: float = 3.0
    
    # Utility function parameters
    utility_function: str = "crra"  # CRRA, CARA, or quadratic
    confidence_threshold: float = 0.6
    
    # Multi-asset optimization
    correlation_adjustment: bool = True
    diversification_bonus: float = 0.1  # 10% bonus for diversification


class KellyCriterionOptimizer:
    """
    Kelly Criterion Optimizer
    
    Kelly Criterion prensiplerini kullanarak optimal pozisyon boyutlandırması
    yapan gelişmiş optimizasyon sistemi.
    """
    
    def __init__(self, config: Optional[KellyConfig] = None):
        """
        Kelly Criterion Optimizer başlat
        
        Args:
            config: Kelly optimization konfigürasyonu
        """
        self.config = config or KellyConfig()
        
        # State tracking
        self.kelly_history: List[KellyCalculation] = []
        self.performance_tracking: Dict[str, List[float]] = {}
        self.calibration_data: Dict[str, Tuple[float, float]] = {}
        
        # Market data for calculations
        self.risk_free_rate = 0.02  # 2% risk-free rate
        self.correlation_matrix: Optional[np.ndarray] = None
        self.assets: List[str] = []
    
    def calculate_kelly_fraction(self, 
                               win_rate: float,
                               avg_win: float,
                               avg_loss: float) -> float:
        """
        Temel Kelly fraction hesapla
        
        Args:
            win_rate: Kazanma oranı (0-1)
            avg_win: Ortalama kazanç (positive)
            avg_loss: Ortalama kayıp (positive)
        
        Returns:
            float: Kelly fraction
        """
        if avg_loss <= 0:
            return 0.0
        
        # Classic Kelly formula: f = (bp - q) / b
        # where b = odds received, p = win probability, q = lose probability
        b = avg_win / avg_loss  # Odds ratio
        p = win_rate
        q = 1 - win_rate
        
        kelly_fraction = (b * p - q) / b
        
        # Ensure Kelly fraction is within reasonable bounds
        return max(0.0, min(kelly_fraction, 1.0))
    
    def calculate_risk_adjusted_kelly(self,
                                    kelly_fraction: float,
                                    volatility: float,
                                    confidence_level: float = 0.8) -> float:
        """
        Risk-adjusted Kelly hesapla
        
        Args:
            kelly_fraction: Temel Kelly fraction
            volatility: Asset volatilitesi
            confidence_level: Confidence level (0-1)
        
        Returns:
            float: Risk-adjusted Kelly fraction
        """
        # Risk adjustment based on volatility
        volatility_penalty = 1.0 / (1.0 + volatility)
        
        # Confidence adjustment
        confidence_penalty = confidence_level
        
        # Combine adjustments
        risk_adjusted_kelly = (
            kelly_fraction * 
            volatility_penalty * 
            confidence_penalty
        )
        
        return max(0.0, min(risk_adjusted_kelly, self.config.max_kelly_fraction))
    
    def calculate_multi_outcome_kelly(self, outcomes: List[Outcome]) -> float:
        """
        Multi-outcome Kelly hesapla
        
        Args:
            outcomes: Outcome listesi
        
        Returns:
            float: Multi-outcome Kelly fraction
        """
        if not outcomes:
            return 0.0
        
        # Calculate expected value and variance
        expected_return = sum(o.probability * o.return_multiple for o in outcomes)
        expected_variance = sum(o.probability * (o.return_multiple - expected_return)**2 for o in outcomes)
        
        # Kelly fraction for multi-outcome case
        if expected_variance <= 0:
            return 0.0
        
        # Extended Kelly formula for multiple outcomes
        kelly_fraction = expected_return / expected_variance
        
        return max(0.0, min(kelly_fraction, self.config.max_kelly_fraction))
    
    def optimize_with_utility_function(self,
                                     kelly_fraction: float,
                                     expected_return: float,
                                     volatility: float,
                                     risk_aversion: float = None) -> float:
        """
        Utility function ile Kelly optimizasyonu
        
        Args:
            kelly_fraction: Base Kelly fraction
            expected_return: Beklenen getiri
            volatility: Volatilite
            risk_aversion: Risk aversion parameter
        
        Returns:
            float: Utility-maximizing fraction
        """
        if risk_aversion is None:
            risk_aversion = self.config.risk_aversion
        
        # Utility function: U(w) = E[r] - (γ/2) * Var[r] * w²
        # where γ is risk aversion and w is the weight (Kelly fraction)
        
        def utility(weight):
            portfolio_return = expected_return * weight
            portfolio_variance = (volatility * weight) ** 2
            
            if self.config.utility_function == "crra":
                # CRRA utility
                utility_value = portfolio_return - (risk_aversion / 2) * portfolio_variance
            elif self.config.utility_function == "cara":
                # CARA utility
                utility_value = portfolio_return - risk_aversion * portfolio_variance
            else:  # quadratic
                utility_value = portfolio_return - (risk_aversion / 2) * portfolio_variance
            
            return -utility_value  # Minimize negative utility (maximize utility)
        
        # Optimize over feasible range
        result = minimize_scalar(
            utility,
            bounds=(0, self.config.max_kelly_fraction),
            method='bounded'
        )
        
        if result.success:
            return result.x
        else:
            return kelly_fraction  # Fallback to base Kelly
    
    def calculate_portfolio_kelly(self,
                                kelly_fractions: Dict[str, float],
                                correlation_matrix: Optional[np.ndarray] = None,
                                target_correlation: float = 0.3) -> Dict[str, float]:
        """
        Portföy seviyesinde Kelly optimizasyonu
        
        Args:
            kelly_fractions: Asset bazlı Kelly fractions
            correlation_matrix: Korelasyon matrisi
            target_correlation: Hedef ortalama korelasyon
        
        Returns:
            Dict[str, float]: Portfolio-adjusted Kelly fractions
        """
        if not kelly_fractions:
            return {}
        
        assets = list(kelly_fractions.keys())
        n_assets = len(assets)
        
        # If no correlation matrix, assume independence
        if correlation_matrix is None:
            correlation_matrix = np.eye(n_assets)
        
        # Objective function: maximize utility while constraining correlation
        def portfolio_objective(weights):
            portfolio_kelly = np.dot(weights, list(kelly_fractions.values()))
            
            # Utility from Kelly allocation
            base_utility = portfolio_kelly
            
            # Correlation penalty
            if n_assets > 1:
                portfolio_variance = np.dot(weights, np.dot(correlation_matrix, weights))
                correlation_penalty = portfolio_variance ** 0.5
            else:
                correlation_penalty = 0
            
            # Diversification bonus
            diversification_bonus = self.config.diversification_bonus * (1 - np.sum(weights**2))
            
            # Final utility
            utility = base_utility - correlation_penalty + diversification_bonus
            
            return -utility  # Minimize negative utility
        
        # Constraints
        constraints = [
            {'type': 'eq', 'fun': lambda w: np.sum(w) - 1.0},  # Weights sum to 1
        ]
        
        # Bounds: individual Kelly fractions as upper bounds
        kelly_values = list(kelly_fractions.values())
        bounds = [(0, min(kelly, self.config.max_kelly_fraction)) for kelly in kelly_values]
        
        # Initial guess: equal weights
        initial_weights = np.full(n_assets, 1.0 / n_assets)
        
        # Optimize
        result = minimize(
            portfolio_objective,
            initial_weights,
            method='SLSQP',
            bounds=bounds,
            constraints=constraints
        )
        
        if result.success:
            optimized_weights = result.x
        else:
            # Fallback: proportional allocation
            total_kelly = sum(kelly_fractions.values())
            if total_kelly > 0:
                optimized_weights = np.array([kelly / total_kelly for kelly in kelly_fractions.values()])
            else:
                optimized_weights = initial_weights
        
        # Convert back to asset-level allocations
        portfolio_kelly = {}
        total_portfolio_allocation = sum(kelly_fractions.values())
        
        for i, asset in enumerate(assets):
            if total_portfolio_allocation > 0:
                # Scale to original total Kelly
                portfolio_kelly[asset] = optimized_weights[i] * total_portfolio_allocation
            else:
                portfolio_kelly[asset] = 0.0
        
        return portfolio_kelly
    
    def calculate_kelly_for_signal(self,
                                 signal_data: Dict[str, Any],
                                 historical_returns: Optional[np.ndarray] = None) -> KellyCalculation:
        """
        Signal için Kelly hesaplaması yap
        
        Args:
            signal_data: Sinyal verisi
            historical_returns: Geçmiş getiriler
        
        Returns:
            KellyCalculation: Kelly hesaplama sonucu
        """
        signal_id = signal_data.get('signal_id', 'unknown')
        asset = signal_data.get('asset', 'unknown')
        
        # Calculate basic statistics
        if historical_returns is None:
            historical_returns = signal_data.get('historical_returns', np.array([]))
        
        if len(historical_returns) < 10:
            # Insufficient data - return conservative estimate
            return KellyCalculation(
                signal_id=signal_id,
                asset=asset,
                kelly_fraction=0.05,  # Conservative 5%
                fractional_kelly=0.0125,  # 25% of Kelly
                risk_adjusted_kelly=0.01,
                confidence_multiplier=0.5,
                final_allocation=0.01,
                expected_return=0.001,
                expected_variance=0.0004,
                sharpe_kelly=0.5,
                utility_score=0.001,
                calculation_details={'error': 'Insufficient historical data'},
                warnings=['Insufficient data for accurate Kelly calculation']
            )
        
        # Calculate return statistics
        returns = pd.Series(historical_returns)
        win_rate = (returns > 0).mean()
        avg_win = returns[returns > 0].mean() if (returns > 0).any() else 0.001
        avg_loss = abs(returns[returns < 0].mean()) if (returns < 0).any() else 0.001
        
        # Calculate volatility
        volatility = returns.std() * np.sqrt(252)  # Annualized
        
        # Base Kelly calculation
        kelly_fraction = self.calculate_kelly_fraction(win_rate, avg_win, avg_loss)
        
        # Apply method-specific adjustments
        if self.config.method == KellyMethod.CLASSIC_KELLY:
            final_kelly = kelly_fraction
        
        elif self.config.method == KellyMethod.FRACTIONAL_KELLY:
            final_kelly = kelly_fraction * self.config.fractional_multiplier
        
        elif self.config.method == KellyMethod.RISK_ADJUSTED_KELLY:
            confidence_score = signal_data.get('signal_score', 0.5)
            final_kelly = self.calculate_risk_adjusted_kelly(kelly_fraction, volatility, confidence_score)
        
        elif self.config.method == KellyMethod.MULTI_OUTCOME_KELLY:
            # Create outcomes from return distribution
            outcomes = self._create_outcomes_from_returns(returns)
            final_kelly = self.calculate_multi_outcome_kelly(outcomes)
        
        elif self.config.method == KellyMethod.DYNAMIC_KELLY:
            # Dynamic Kelly based on recent performance
            recent_returns = returns.tail(20)  # Last 20 observations
            recent_win_rate = (recent_returns > 0).mean()
            recent_avg_win = recent_returns[recent_returns > 0].mean() if (recent_returns > 0).any() else 0.001
            recent_avg_loss = abs(recent_returns[recent_returns < 0].mean()) if (recent_returns < 0).any() else 0.001
            
            dynamic_kelly = self.calculate_kelly_fraction(recent_win_rate, recent_avg_win, recent_avg_loss)
            
            # Blend with full-sample Kelly
            final_kelly = 0.6 * kelly_fraction + 0.4 * dynamic_kelly
        
        else:  # Default to risk-adjusted
            confidence_score = signal_data.get('signal_score', 0.5)
            final_kelly = self.calculate_risk_adjusted_kelly(kelly_fraction, volatility, confidence_score)
        
        # Apply utility optimization
        expected_return = returns.mean() * 252  # Annualized
        optimized_kelly = self.optimize_with_utility_function(
            final_kelly, expected_return, volatility
        )
        
        # Calculate performance metrics
        sharpe_kelly = expected_return / (volatility + 1e-8) if volatility > 0 else 0
        
        # Utility score
        utility_score = expected_return * optimized_kelly - (self.config.risk_aversion / 2) * (volatility * optimized_kelly) ** 2
        
        # Confidence multiplier
        signal_score = signal_data.get('signal_score', 0.5)
        model_quality = signal_data.get('model_quality_score', 0.5)
        confidence_multiplier = (signal_score + model_quality) / 2
        
        # Final allocation
        final_allocation = optimized_kelly * confidence_multiplier
        
        # Apply constraints
        final_allocation = min(final_allocation, self.config.max_position_size)
        
        # Legacy mode adjustment
        if self.config.legacy_mode and signal_data.get('hedge_mode', False):
            final_allocation *= self.config.legacy_boost_factor
        
        # Gather calculation details
        calculation_details = {
            'method': self.config.method.value,
            'win_rate': win_rate,
            'avg_win': avg_win,
            'avg_loss': avg_loss,
            'volatility': volatility,
            'expected_return': expected_return,
            'confidence_multiplier': confidence_multiplier,
            'utility_function': self.config.utility_function,
            'risk_aversion': self.config.risk_aversion
        }
        
        # Generate warnings if needed
        warnings = []
        if kelly_fraction > 0.5:
            warnings.append('High Kelly fraction detected - consider risk management')
        if volatility > 0.3:
            warnings.append('High volatility - position size may be too aggressive')
        if len(historical_returns) < 50:
            warnings.append('Limited historical data - results may be unreliable')
        
        # Create result
        result = KellyCalculation(
            signal_id=signal_id,
            asset=asset,
            kelly_fraction=kelly_fraction,
            fractional_kelly=kelly_fraction * self.config.fractional_multiplier,
            risk_adjusted_kelly=final_kelly,
            confidence_multiplier=confidence_multiplier,
            final_allocation=final_allocation,
            expected_return=expected_return,
            expected_variance=volatility ** 2,
            sharpe_kelly=sharpe_kelly,
            utility_score=utility_score,
            calculation_details=calculation_details,
            warnings=warnings
        )
        
        # Store in history
        self.kelly_history.append(result)
        
        return result
    
    def _create_outcomes_from_returns(self, returns: pd.Series) -> List[Outcome]:
        """Return dağılımından outcome'lar oluştur"""
        outcomes = []
        
        # Define outcome thresholds
        large_win_threshold = returns.quantile(0.8)
        small_win_threshold = returns.quantile(0.6)
        break_even_threshold = returns.quantile(0.4)
        small_loss_threshold = returns.quantile(0.2)
        
        # Count outcomes
        large_wins = (returns > large_win_threshold).sum()
        small_wins = ((returns > small_win_threshold) & (returns <= large_win_threshold)).sum()
        break_even = ((returns > break_even_threshold) & (returns <= small_win_threshold)).sum()
        small_losses = ((returns > small_loss_threshold) & (returns <= break_even_threshold)).sum()
        large_losses = (returns <= small_loss_threshold).sum()
        
        total_outcomes = len(returns)
        
        if total_outcomes > 0:
            # Create outcome objects
            if large_wins > 0:
                avg_large_win = returns[returns > large_win_threshold].mean()
                outcomes.append(Outcome(
                    OutcomeType.WIN, 
                    large_wins / total_outcomes, 
                    1 + avg_large_win,
                    f"Large win: {avg_large_win:.2%}"
                ))
            
            if small_wins > 0:
                avg_small_win = returns[(returns > small_win_threshold) & (returns <= large_win_threshold)].mean()
                outcomes.append(Outcome(
                    OutcomeType.PARTIAL_WIN,
                    small_wins / total_outcomes,
                    1 + avg_small_win,
                    f"Small win: {avg_small_win:.2%}"
                ))
            
            if break_even > 0:
                outcomes.append(Outcome(
                    OutcomeType.TIE,
                    break_even / total_outcomes,
                    1.0,
                    "Break even"
                ))
            
            if small_losses > 0:
                avg_small_loss = returns[(returns > small_loss_threshold) & (returns <= break_even_threshold)].mean()
                outcomes.append(Outcome(
                    OutcomeType.PARTIAL_LOSS,
                    small_losses / total_outcomes,
                    1 + avg_small_loss,
                    f"Small loss: {avg_small_loss:.2%}"
                ))
            
            if large_losses > 0:
                avg_large_loss = returns[returns <= small_loss_threshold].mean()
                outcomes.append(Outcome(
                    OutcomeType.LOSS,
                    large_losses / total_outcomes,
                    1 + avg_large_loss,
                    f"Large loss: {avg_large_loss:.2%}"
                ))
        
        return outcomes
    
    def batch_calculate_kelly(self, 
                            signals_data: List[Dict[str, Any]],
                            historical_data: Optional[Dict[str, np.ndarray]] = None) -> Dict[str, KellyCalculation]:
        """
        Birden fazla signal için Kelly hesapla
        
        Args:
            signals_data: Sinyal verileri
            historical_data: Geçmiş veriler
        
        Returns:
            Dict[str, KellyCalculation]: Signal ID -> Kelly calculation mapping
        """
        kelly_results = {}
        
        for signal_data in signals_data:
            signal_id = signal_data.get('signal_id', f'signal_{len(kelly_results)}')
            
            try:
                # Get historical returns for this signal
                historical_returns = None
                if historical_data and signal_id in historical_data:
                    historical_returns = historical_data[signal_id]
                
                kelly_calc = self.calculate_kelly_for_signal(signal_data, historical_returns)
                kelly_results[signal_id] = kelly_calc
                
            except Exception as e:
                print(f"Kelly calculation error for signal {signal_id}: {e}")
                
                # Create error result
                kelly_results[signal_id] = KellyCalculation(
                    signal_id=signal_id,
                    asset=signal_data.get('asset', 'UNKNOWN'),
                    kelly_fraction=0.0,
                    fractional_kelly=0.0,
                    risk_adjusted_kelly=0.0,
                    confidence_multiplier=0.0,
                    final_allocation=0.0,
                    expected_return=0.0,
                    expected_variance=0.0,
                    sharpe_kelly=0.0,
                    utility_score=0.0,
                    calculation_details={'error': str(e)},
                    warnings=[f'Calculation failed: {str(e)}']
                )
        
        return kelly_results
    
    def optimize_portfolio_kelly(self, 
                               kelly_results: Dict[str, KellyCalculation],
                               correlation_data: Optional[Dict[Tuple[str, str], float]] = None) -> Dict[str, float]:
        """
        Portföy seviyesinde Kelly optimizasyonu
        
        Args:
            kelly_results: Kelly hesaplama sonuçları
            correlation_data: Korelasyon verisi
        
        Returns:
            Dict[str, float]: Portfolio-optimized allocations
        """
        # Extract individual Kelly fractions
        kelly_fractions = {
            result.asset: result.final_allocation 
            for result in kelly_results.values() 
            if result.final_allocation > 0
        }
        
        # Create correlation matrix if data provided
        correlation_matrix = None
        if correlation_data:
            assets = list(kelly_fractions.keys())
            n_assets = len(assets)
            correlation_matrix = np.eye(n_assets)
            
            asset_to_index = {asset: i for i, asset in enumerate(assets)}
            
            for (asset1, asset2), corr in correlation_data.items():
                if asset1 in asset_to_index and asset2 in asset_to_index:
                    i, j = asset_to_index[asset1], asset_to_index[asset2]
                    correlation_matrix[i, j] = corr
                    correlation_matrix[j, i] = corr
        
        # Optimize portfolio Kelly
        portfolio_kelly = self.calculate_portfolio_kelly(kelly_fractions, correlation_matrix)
        
        return portfolio_kelly
    
    def generate_kelly_report(self, 
                            signals_data: List[Dict[str, Any]],
                            historical_data: Optional[Dict[str, np.ndarray]] = None) -> Dict[str, Any]:
        """
        Kapsamlı Kelly raporu oluştur
        
        Args:
            signals_data: Sinyal verileri
            historical_data: Geçmiş veriler
        
        Returns:
            Dict[str, Any]: Kelly optimization report
        """
        # Calculate Kelly for all signals
        kelly_results = self.batch_calculate_kelly(signals_data, historical_data)
        
        # Portfolio optimization
        portfolio_allocation = self.optimize_portfolio_kelly(kelly_results)
        
        # Performance analysis
        performance_analysis = self._analyze_kelly_performance()
        
        # Calibration analysis
        calibration_analysis = self._analyze_kelly_calibration()
        
        # Risk analysis
        risk_analysis = self._analyze_kelly_risk(kelly_results)
        
        # Generate recommendations
        recommendations = self._generate_kelly_recommendations(kelly_results)
        
        return {
            'timestamp': datetime.now().isoformat(),
            'configuration': {
                'method': self.config.method.value,
                'fractional_multiplier': self.config.fractional_multiplier,
                'risk_aversion': self.config.risk_aversion,
                'max_position_size': self.config.max_position_size,
                'utility_function': self.config.utility_function,
                'legacy_mode': self.config.legacy_mode
            },
            'kelly_results': {
                signal_id: {
                    'asset': result.asset,
                    'kelly_fraction': result.kelly_fraction,
                    'risk_adjusted_kelly': result.risk_adjusted_kelly,
                    'final_allocation': result.final_allocation,
                    'expected_return': result.expected_return,
                    'sharpe_kelly': result.sharpe_kelly,
                    'utility_score': result.utility_score,
                    'warnings': result.warnings
                }
                for signal_id, result in kelly_results.items()
            },
            'portfolio_optimization': {
                'total_allocation': sum(portfolio_allocation.values()),
                'optimal_allocations': portfolio_allocation,
                'num_assets': len(portfolio_allocation),
                'concentration_risk': self._calculate_portfolio_concentration(portfolio_allocation)
            },
            'performance_analysis': performance_analysis,
            'calibration_analysis': calibration_analysis,
            'risk_analysis': risk_analysis,
            'recommendations': recommendations,
            'summary_stats': {
                'total_signals': len(signals_data),
                'positive_kelly_count': len([r for r in kelly_results.values() if r.kelly_fraction > 0]),
                'average_kelly_fraction': np.mean([r.kelly_fraction for r in kelly_results.values()]),
                'max_kelly_fraction': max([r.kelly_fraction for r in kelly_results.values()]) if kelly_results else 0,
                'total_warnings': sum(len(r.warnings) for r in kelly_results.values())
            }
        }
    
    def _analyze_kelly_performance(self) -> Dict[str, Any]:
        """Kelly performance analizi"""
        if not self.kelly_history:
            return {'message': 'Kelly history bulunamadı'}
        
        kelly_fractions = [r.kelly_fraction for r in self.kelly_history[-50:]]  # Last 50
        utility_scores = [r.utility_score for r in self.kelly_history[-50:]]
        
        return {
            'avg_kelly_fraction': np.mean(kelly_fractions),
            'kelly_std': np.std(kelly_fractions),
            'avg_utility_score': np.mean(utility_scores),
            'utility_std': np.std(utility_scores),
            'conservative_kelly_ratio': np.mean([r.fractional_kelly / (r.kelly_fraction + 1e-8) for r in self.kelly_history[-50:]]),
            'high_kelly_frequency': len([k for k in kelly_fractions if k > 0.3]) / len(kelly_fractions)
        }
    
    def _analyze_kelly_calibration(self) -> Dict[str, Any]:
        """Kelly calibration analizi"""
        return {
            'calibration_data_points': len(self.calibration_data),
            'average_predicted_kelly': np.mean([pred for pred, actual in self.calibration_data.values()]) if self.calibration_data else 0,
            'average_actual_performance': np.mean([actual for pred, actual in self.calibration_data.values()]) if self.calibration_data else 0,
            'calibration_accuracy': self._calculate_calibration_accuracy()
        }
    
    def _calculate_calibration_accuracy(self) -> float:
        """Calibration doğruluğunu hesapla"""
        if len(self.calibration_data) < 5:
            return 0.0
        
        total_error = 0
        for predicted, actual in self.calibration_data.values():
            total_error += abs(predicted - actual)
        
        return 1.0 - (total_error / len(self.calibration_data))
    
    def _analyze_kelly_risk(self, kelly_results: Dict[str, KellyCalculation]) -> Dict[str, Any]:
        """Kelly risk analizi"""
        fractions = [r.final_allocation for r in kelly_results.values()]
        expected_returns = [r.expected_return for r in kelly_results.values()]
        
        return {
            'max_allocation': max(fractions) if fractions else 0,
            'min_allocation': min(fractions) if fractions else 0,
            'allocation_std': np.std(fractions) if fractions else 0,
            'avg_expected_return': np.mean(expected_returns) if expected_returns else 0,
            'return_std': np.std(expected_returns) if expected_returns else 0,
            'high_risk_signals': len([r for r in kelly_results.values() if r.expected_variance > 0.01]),
            'concentration_risk': max(fractions) / (sum(fractions) + 1e-8) if fractions else 0
        }
    
    def _generate_kelly_recommendations(self, kelly_results: Dict[str, KellyCalculation]) -> List[str]:
        """Kelly önerilerini oluştur"""
        recommendations = []
        
        # High Kelly fraction warnings
        high_kelly = [r for r in kelly_results.values() if r.kelly_fraction > 0.4]
        if high_kelly:
            recommendations.append(
                f"Yüksek Kelly fractions tespit edildi: {len(high_kelly)} signal - risk yönetimi uygulayın"
            )
        
        # Conservative approach recommendation
        avg_fractional_kelly = np.mean([r.fractional_kelly for r in kelly_results.values()])
        if avg_fractional_kelly > 0.2:
            recommendations.append(
                "Fractional Kelly kullanımını artırın - daha muhafazakar yaklaşım için"
            )
        
        # Calibration issues
        if len(self.calibration_data) < 10:
            recommendations.append(
                "Kelly calibration verisi artırın - daha doğru tahminler için geçmiş performans verisi toplayın"
            )
        
        # Portfolio concentration
        max_allocation = max([r.final_allocation for r in kelly_results.values()]) if kelly_results else 0
        if max_allocation > 0.3:
            recommendations.append(
                "Portföy konsantrasyonu yüksek - pozisyonları çeşitlendirin"
            )
        
        if not recommendations:
            recommendations.append("Kelly allocation'ları dengeli görünüyor")
        
        return recommendations
    
    def _calculate_portfolio_concentration(self, allocations: Dict[str, float]) -> float:
        """Portföy konsantrasyon riskini hesapla"""
        if not allocations:
            return 0.0
        
        total_allocation = sum(allocations.values())
        if total_allocation == 0:
            return 0.0
        
        # Normalize allocations
        normalized_allocations = {k: v/total_allocation for k, v in allocations.items()}
        
        # Herfindahl-Hirschman Index
        hhi = sum(v**2 for v in normalized_allocations.values())
        
        return hhi
    
    def update_performance_tracking(self, signal_id: str, 
                                  predicted_kelly: float, 
                                  actual_performance: float):
        """
        Performance tracking güncelle
        
        Args:
            signal_id: Signal ID
            predicted_kelly: Tahmin edilen Kelly
            actual_performance: Gerçekleşen performans
        """
        if signal_id not in self.performance_tracking:
            self.performance_tracking[signal_id] = []
        
        self.performance_tracking[signal_id].append(actual_performance)
        
        # Update calibration data
        self.calibration_data[signal_id] = (predicted_kelly, actual_performance)
        
        # Limit data size
        if len(self.performance_tracking[signal_id]) > 100:
            self.performance_tracking[signal_id] = self.performance_tracking[signal_id][-100:]


# Test fonksiyonu
def test_kelly_criterion_optimizer():
    """Kelly Criterion Optimizer test fonksiyonu"""
    
    # Test configuration
    config = KellyConfig(
        method=KellyMethod.RISK_ADJUSTED_KELLY,
        fractional_multiplier=0.25,
        risk_aversion=2.0,
        max_position_size=0.20,
        legacy_mode=True
    )
    
    optimizer = KellyCriterionOptimizer(config)
    
    # Test signals
    np.random.seed(42)
    signals_data = []
    
    for i in range(5):
        signal_data = {
            'signal_id': f'kelly_signal_{i:03d}',
            'asset': f'ASSET_{i}',
            'signal_score': np.random.uniform(0.4, 0.9),
            'model_quality_score': np.random.uniform(0.6, 0.9),
            'hedge_mode': i % 2 == 0,  # Half with hedge mode
            'historical_returns': np.random.normal(0.001, 0.02, 100)
        }
        signals_data.append(signal_data)
    
    # Test individual Kelly calculation
    print("=== Individual Kelly Calculations ===")
    for signal_data in signals_data[:3]:  # Test first 3
        kelly_result = optimizer.calculate_kelly_for_signal(signal_data)
        
        print(f"\nSignal: {kelly_result.signal_id}")
        print(f"Asset: {kelly_result.asset}")
        print(f"Kelly Fraction: {kelly_result.kelly_fraction:.3f}")
        print(f"Risk-Adjusted Kelly: {kelly_result.risk_adjusted_kelly:.3f}")
        print(f"Final Allocation: {kelly_result.final_allocation:.3f}")
        print(f"Expected Return: {kelly_result.expected_return:.2%}")
        print(f"Sharpe Kelly: {kelly_result.sharpe_kelly:.3f}")
        print(f"Utility Score: {kelly_result.utility_score:.6f}")
        
        if kelly_result.warnings:
            print("Warnings:")
            for warning in kelly_result.warnings:
                print(f"  - {warning}")
    
    # Test batch processing
    print("\n=== Batch Kelly Optimization ===")
    kelly_results = optimizer.batch_calculate_kelly(signals_data)
    
    print(f"Processed {len(kelly_results)} signals")
    
    # Test portfolio optimization
    print("\n=== Portfolio Kelly Optimization ===")
    portfolio_allocation = optimizer.optimize_portfolio_kelly(kelly_results)
    
    for asset, allocation in portfolio_allocation.items():
        print(f"{asset}: {allocation:.3f}")
    
    total_allocation = sum(portfolio_allocation.values())
    print(f"Total Portfolio Allocation: {total_allocation:.3f}")
    
    # Comprehensive report
    print("\n=== Comprehensive Kelly Report ===")
    report = optimizer.generate_kelly_report(signals_data)
    
    print("Summary Stats:")
    stats = report['summary_stats']
    for key, value in stats.items():
        print(f"  {key}: {value}")
    
    print("\nRecommendations:")
    for rec in report['recommendations']:
        print(f"  - {rec}")
    
    return optimizer, report


if __name__ == "__main__":
    test_kelly_criterion_optimizer()