"""
Portfolio Risk Constraints Modülü
=================================

Portföy seviyesinde risk kısıtlamalarını yöneten ve uygulayan sistem.

Bu modül:
- Portfolio-level risk limits'i izler ve uygular
- Sector ve asset allocation constraints'leri yönetir
- Real-time risk monitoring sağlar
- Risk breach alert'leri üretir
- Rebalancing gerekliliklerini tespit eder
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any, Union
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import warnings

warnings.filterwarnings('ignore')


class ConstraintType(Enum):
    """Kısıtlama tipleri"""
    MAX_POSITION_SIZE = "max_position_size"
    MAX_SECTOR_EXPOSURE = "max_sector_exposure"
    MAX_PORTFOLIO_RISK = "max_portfolio_risk"
    MAX_CORRELATION_EXPOSURE = "max_correlation_exposure"
    MIN_CASH_RESERVE = "min_cash_reserve"
    MAX_LEVERAGE = "max_leverage"
    MAX_DAILY_LOSS = "max_daily_loss"
    MAX_CONCENTRATION_RISK = "max_concentration_risk"
    MAX_VAEXPOSURE = "max_va_exposure"  # Value-at-Risk exposure
    MAX_SECTOR_CORRELATION = "max_sector_correlation"


class ConstraintStatus(Enum):
    """Kısıtlama durumu"""
    COMPLIANT = "compliant"
    WARNING = "warning"
    BREACH = "breach"
    CRITICAL = "critical"


class RebalanceTrigger(Enum):
    """Rebalancing tetikleyicileri"""
    RISK_BREACH = "risk_breach"
    DRIFT_THRESHOLD = "drift_threshold"
    CORRELATION_INCREASE = "correlation_increase"
    VOLATILITY_SPIKE = "volatility_spike"
    MANUAL_TRIGGER = "manual_trigger"
    TIME_BASED = "time_based"


@dataclass
class Constraint:
    """Risk kısıtlaması"""
    name: str
    constraint_type: ConstraintType
    limit_value: float
    current_value: float
    status: ConstraintStatus
    breach_severity: float = 0.0  # 0-1, breach'in ne kadar ciddi olduğu
    description: str = ""
    action_required: str = ""
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class RebalanceRecommendation:
    """Rebalancing önerisi"""
    trigger: RebalanceTrigger
    priority: int  # 1-5, 5 = highest priority
    description: str
    recommended_actions: List[str]
    expected_risk_reduction: float
    estimated_transaction_cost: float
    urgency_score: float  # 0-1
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class PortfolioConstraints:
    """Portföy kısıtlamaları konfigürasyonu"""
    # Position limits
    max_single_position: float = 0.15  # %15 max single position
    max_sector_exposure: float = 0.30  # %30 max sector exposure
    max_technology_exposure: float = 0.50  # Technology sector limit
    max_financial_exposure: float = 0.25  # Financial sector limit
    max_energy_exposure: float = 0.20  # Energy sector limit
    
    # Risk limits
    max_portfolio_volatility: float = 0.20  # %20 max portfolio volatility
    max_portfolio_var: float = 0.05  # %5 max Value-at-Risk
    max_correlation_exposure: float = 0.40  # %40 max correlation exposure
    max_concentration_risk: float = 0.60  # %60 max concentration risk index
    
    # Cash and leverage
    min_cash_reserve: float = 0.05  # %5 min cash reserve
    max_leverage: float = 3.0  # 3x max leverage
    max_total_exposure: float = 1.50  # 150% max total exposure
    
    # Risk management
    max_daily_loss: float = 0.03  # %3 max daily loss
    max_drawdown: float = 0.15  # %15 max drawdown
    max_sector_correlation: float = 0.70  # Max sector correlation
    
    # Rebalancing
    rebalance_threshold: float = 0.05  # %5 rebalance threshold
    max_tracking_error: float = 0.02  # %2 max tracking error
    rebalance_frequency_days: int = 30  # 30 days max between rebalancing
    
    # Compliance
    regulatory_limits: Dict[str, float] = field(default_factory=dict)
    client_mandates: Dict[str, Any] = field(default_factory=dict)


class PortfolioRiskConstraints:
    """
    Portfolio Risk Constraints Manager
    
    Portföy seviyesinde risk kısıtlamalarını izler, uygular ve 
    rebalancing önerileri üretir.
    """
    
    def __init__(self, config: Optional[PortfolioConstraints] = None):
        """
        Portfolio Risk Constraints Manager başlat
        
        Args:
            config: Portföy kısıtlamaları konfigürasyonu
        """
        self.config = config or PortfolioConstraints()
        
        # State tracking
        self.active_constraints: List[Constraint] = []
        self.breach_history: List[Constraint] = []
        self.rebalance_recommendations: List[RebalanceRecommendation] = []
        self.constraint_violations: List[Dict[str, Any]] = []
        
        # Portfolio state
        self.current_positions: Dict[str, float] = {}
        self.current_weights: Dict[str, float] = {}
        self.sector_allocations: Dict[str, float] = {}
        self.correlation_matrix: Optional[np.ndarray] = None
        self.risk_metrics: Dict[str, float] = {}
        
        # Alert system
        self.alert_thresholds = {
            'warning': 0.8,  # %80 of limit triggers warning
            'breach': 1.0,   # %100 of limit triggers breach
            'critical': 1.2  # %120 of limit triggers critical
        }
    
    def update_portfolio_state(self, 
                             positions: Dict[str, float],
                             prices: Dict[str, float],
                             sectors: Dict[str, str],
                             correlation_data: Optional[Dict[Tuple[str, str], float]] = None):
        """
        Portföy durumunu güncelle
        
        Args:
            positions: {symbol: quantity} mapping
            prices: {symbol: price} mapping
            sectors: {symbol: sector} mapping
            correlation_data: Korelasyon verisi
        """
        self.current_positions = positions.copy()
        
        # Calculate current values
        total_value = sum(pos * prices.get(symbol, 0) for symbol, pos in positions.items())
        self.current_weights = {
            symbol: (pos * prices.get(symbol, 0)) / (total_value + 1e-8)
            for symbol, pos in positions.items()
        }
        
        # Calculate sector allocations
        self.sector_allocations = {}
        for symbol, pos in positions.items():
            value = pos * prices.get(symbol, 0)
            sector = sectors.get(symbol, 'Other')
            
            if sector not in self.sector_allocations:
                self.sector_allocations[sector] = 0
            self.sector_allocations[sector] += value / (total_value + 1e-8)
        
        # Update correlation matrix
        if correlation_data:
            self._update_correlation_matrix(correlation_data, list(positions.keys()))
        
        # Update risk metrics
        self._update_risk_metrics()
    
    def _update_correlation_matrix(self, 
                                 correlation_data: Dict[Tuple[str, str], float],
                                 symbols: List[str]):
        """Korelasyon matrisini güncelle"""
        n_assets = len(symbols)
        self.correlation_matrix = np.eye(n_assets)
        
        symbol_to_index = {symbol: i for i, symbol in enumerate(symbols)}
        
        for (symbol1, symbol2), corr in correlation_data.items():
            if symbol1 in symbol_to_index and symbol2 in symbol_to_index:
                i, j = symbol_to_index[symbol1], symbol_to_index[symbol2]
                self.correlation_matrix[i, j] = corr
                self.correlation_matrix[j, i] = corr  # Symmetric
    
    def _update_risk_metrics(self):
        """Risk metriklerini güncelle"""
        total_value = sum(self.current_weights.values())
        
        if total_value == 0:
            self.risk_metrics = {
                'total_exposure': 0.0,
                'portfolio_volatility': 0.0,
                'concentration_risk': 0.0,
                'sector_concentration': 0.0,
                'max_single_position': 0.0,
                'avg_correlation': 0.0
            }
            return
        
        # Normalize weights
        normalized_weights = {k: v/total_value for k, v in self.current_weights.items()}
        
        # Concentration risk (Herfindahl-Hirschman Index)
        concentration_risk = sum(w**2 for w in normalized_weights.values())
        
        # Sector concentration
        sector_concentration = max(self.sector_allocations.values()) if self.sector_allocations else 0
        
        # Maximum single position
        max_position = max(normalized_weights.values()) if normalized_weights else 0
        
        # Portfolio volatility (simplified)
        portfolio_vol = self._calculate_portfolio_volatility(normalized_weights)
        
        # Average correlation
        avg_correlation = self._calculate_average_correlation(normalized_weights)
        
        self.risk_metrics = {
            'total_exposure': total_value,
            'portfolio_volatility': portfolio_vol,
            'concentration_risk': concentration_risk,
            'sector_concentration': sector_concentration,
            'max_single_position': max_position,
            'avg_correlation': avg_correlation,
            'num_positions': len(normalized_weights),
            'cash_percentage': 1.0 - total_value
        }
    
    def _calculate_portfolio_volatility(self, weights: Dict[str, float]) -> float:
        """Portföy volatilitesini hesapla"""
        if not weights or self.correlation_matrix is None:
            return 0.15  # Default volatility
        
        # Individual volatilities (simplified - would need historical data)
        individual_vols = {symbol: 0.20 for symbol in weights.keys()}  # 20% default
        
        # Portfolio variance calculation
        portfolio_variance = 0.0
        symbols = list(weights.keys())
        n = len(symbols)
        
        for i in range(n):
            for j in range(n):
                weight_i = weights[symbols[i]]
                weight_j = weights[symbols[j]]
                vol_i = individual_vols[symbols[i]]
                vol_j = individual_vols[symbols[j]]
                correlation = self.correlation_matrix[i, j] if i < n and j < n else 0
                
                portfolio_variance += weight_i * weight_j * vol_i * vol_j * correlation
        
        return np.sqrt(portfolio_variance)
    
    def _calculate_average_correlation(self, weights: Dict[str, float]) -> float:
        """Ortalama korelasyonu hesapla"""
        if not weights or self.correlation_matrix is None:
            return 0.0
        
        symbols = list(weights.keys())
        n = len(symbols)
        
        if n <= 1:
            return 0.0
        
        # Weighted average correlation
        total_weight = sum(weights.values())
        weighted_correlation = 0.0
        
        for i in range(n):
            for j in range(i + 1, n):
                weight_prod = weights[symbols[i]] * weights[symbols[j]]
                correlation = self.correlation_matrix[i, j]
                weighted_correlation += weight_prod * correlation
        
        if total_weight > 0:
            # Normalize by total possible pairs
            max_pairs = n * (n - 1) / 2
            avg_correlation = weighted_correlation / (total_weight**2 / (2 * max_pairs) if max_pairs > 0 else 1)
        else:
            avg_correlation = 0.0
        
        return avg_correlation
    
    def evaluate_constraints(self) -> List[Constraint]:
        """
        Tüm kısıtlamaları değerlendir
        
        Returns:
            List[Constraint]: Kısıtlama değerlendirme sonuçları
        """
        self.active_constraints = []
        
        # Position size constraints
        self._evaluate_position_constraints()
        
        # Sector exposure constraints
        self._evaluate_sector_constraints()
        
        # Risk constraints
        self._evaluate_risk_constraints()
        
        # Correlation constraints
        self._evaluate_correlation_constraints()
        
        # Cash and leverage constraints
        self._evaluate_cash_leverage_constraints()
        
        return self.active_constraints
    
    def _evaluate_position_constraints(self):
        """Pozisyon kısıtlamalarını değerlendir"""
        max_single_position = self.risk_metrics.get('max_single_position', 0)
        
        constraint = Constraint(
            name="Max Single Position",
            constraint_type=ConstraintType.MAX_POSITION_SIZE,
            limit_value=self.config.max_single_position,
            current_value=max_single_position,
            status=self._determine_constraint_status(max_single_position, self.config.max_single_position),
            breach_severity=max(0, (max_single_position - self.config.max_single_position) / self.config.max_single_position),
            description=f"Maximum single position size limit: {self.config.max_single_position:.1%}",
            action_required=self._get_action_for_constraint(ConstraintType.MAX_POSITION_SIZE, max_single_position, self.config.max_single_position)
        )
        
        self.active_constraints.append(constraint)
    
    def _evaluate_sector_constraints(self):
        """Sektör kısıtlamalarını değerlendir"""
        # Overall sector exposure
        for sector, allocation in self.sector_allocations.items():
            if sector.lower() == 'technology':
                limit = self.config.max_technology_exposure
            elif sector.lower() == 'financial':
                limit = self.config.max_financial_exposure
            elif sector.lower() == 'energy':
                limit = self.config.max_energy_exposure
            else:
                limit = self.config.max_sector_exposure
            
            constraint = Constraint(
                name=f"Sector Exposure - {sector}",
                constraint_type=ConstraintType.MAX_SECTOR_EXPOSURE,
                limit_value=limit,
                current_value=allocation,
                status=self._determine_constraint_status(allocation, limit),
                breach_severity=max(0, (allocation - limit) / limit),
                description=f"Maximum {sector} sector exposure: {limit:.1%}",
                action_required=self._get_action_for_constraint(ConstraintType.MAX_SECTOR_EXPOSURE, allocation, limit)
            )
            
            self.active_constraints.append(constraint)
    
    def _evaluate_risk_constraints(self):
        """Risk kısıtlamalarını değerlendir"""
        # Portfolio volatility
        portfolio_vol = self.risk_metrics.get('portfolio_volatility', 0)
        constraint = Constraint(
            name="Portfolio Volatility",
            constraint_type=ConstraintType.MAX_PORTFOLIO_RISK,
            limit_value=self.config.max_portfolio_volatility,
            current_value=portfolio_vol,
            status=self._determine_constraint_status(portfolio_vol, self.config.max_portfolio_volatility),
            breach_severity=max(0, (portfolio_vol - self.config.max_portfolio_volatility) / self.config.max_portfolio_volatility),
            description=f"Maximum portfolio volatility: {self.config.max_portfolio_volatility:.1%}",
            action_required=self._get_action_for_constraint(ConstraintType.MAX_PORTFOLIO_RISK, portfolio_vol, self.config.max_portfolio_volatility)
        )
        self.active_constraints.append(constraint)
        
        # Concentration risk
        concentration_risk = self.risk_metrics.get('concentration_risk', 0)
        constraint = Constraint(
            name="Concentration Risk",
            constraint_type=ConstraintType.MAX_CONCENTRATION_RISK,
            limit_value=self.config.max_concentration_risk,
            current_value=concentration_risk,
            status=self._determine_constraint_status(concentration_risk, self.config.max_concentration_risk),
            breach_severity=max(0, (concentration_risk - self.config.max_concentration_risk) / self.config.max_concentration_risk),
            description=f"Maximum concentration risk (HHI): {self.config.max_concentration_risk:.3f}",
            action_required=self._get_action_for_constraint(ConstraintType.MAX_CONCENTRATION_RISK, concentration_risk, self.config.max_concentration_risk)
        )
        self.active_constraints.append(constraint)
        
        # VaR (simplified)
        var_estimate = self._estimate_value_at_risk()
        constraint = Constraint(
            name="Value-at-Risk",
            constraint_type=ConstraintType.MAX_VAEXPOSURE,
            limit_value=self.config.max_portfolio_var,
            current_value=var_estimate,
            status=self._determine_constraint_status(var_estimate, self.config.max_portfolio_var),
            breach_severity=max(0, (var_estimate - self.config.max_portfolio_var) / self.config.max_portfolio_var),
            description=f"Maximum portfolio VaR: {self.config.max_portfolio_var:.1%}",
            action_required=self._get_action_for_constraint(ConstraintType.MAX_VAEXPOSURE, var_estimate, self.config.max_portfolio_var)
        )
        self.active_constraints.append(constraint)
    
    def _evaluate_correlation_constraints(self):
        """Korelasyon kısıtlamalarını değerlendir"""
        avg_correlation = self.risk_metrics.get('avg_correlation', 0)
        
        constraint = Constraint(
            name="Correlation Exposure",
            constraint_type=ConstraintType.MAX_CORRELATION_EXPOSURE,
            limit_value=self.config.max_correlation_exposure,
            current_value=avg_correlation,
            status=self._determine_constraint_status(avg_correlation, self.config.max_correlation_exposure),
            breach_severity=max(0, (avg_correlation - self.config.max_correlation_exposure) / self.config.max_correlation_exposure),
            description=f"Maximum average correlation: {self.config.max_correlation_exposure:.2f}",
            action_required=self._get_action_for_constraint(ConstraintType.MAX_CORRELATION_EXPOSURE, avg_correlation, self.config.max_correlation_exposure)
        )
        
        self.active_constraints.append(constraint)
    
    def _evaluate_cash_leverage_constraints(self):
        """Nakit ve kaldıraç kısıtlamalarını değerlendir"""
        # Cash reserve
        cash_percentage = self.risk_metrics.get('cash_percentage', 1.0)
        constraint = Constraint(
            name="Cash Reserve",
            constraint_type=ConstraintType.MIN_CASH_RESERVE,
            limit_value=self.config.min_cash_reserve,
            current_value=cash_percentage,
            status=self._determine_constraint_status_reverse(cash_percentage, self.config.min_cash_reserve),  # Reverse: higher is better
            breach_severity=max(0, (self.config.min_cash_reserve - cash_percentage) / self.config.min_cash_reserve),
            description=f"Minimum cash reserve: {self.config.min_cash_reserve:.1%}",
            action_required="Increase cash holdings" if cash_percentage < self.config.min_cash_reserve else "No action required"
        )
        self.active_constraints.append(constraint)
    
    def _estimate_value_at_risk(self) -> float:
        """Value-at-Risk tahmini (simplified)"""
        portfolio_vol = self.risk_metrics.get('portfolio_volatility', 0.15)
        # Simplified VaR: 1-day VaR at 95% confidence
        return portfolio_vol * 1.645 * 0.01  # 1.645 * daily volatility
    
    def _determine_constraint_status(self, current: float, limit: float) -> ConstraintStatus:
        """Kısıtlama durumunu belirle"""
        if current > limit * self.alert_thresholds['critical']:
            return ConstraintStatus.CRITICAL
        elif current > limit * self.alert_thresholds['breach']:
            return ConstraintStatus.BREACH
        elif current > limit * self.alert_thresholds['warning']:
            return ConstraintStatus.WARNING
        else:
            return ConstraintStatus.COMPLIANT
    
    def _determine_constraint_status_reverse(self, current: float, minimum: float) -> ConstraintStatus:
        """Reverse constraint durumunu belirle (düşük değer kötü)"""
        if current < minimum / self.alert_thresholds['critical']:
            return ConstraintStatus.CRITICAL
        elif current < minimum / self.alert_thresholds['breach']:
            return ConstraintStatus.BREACH
        elif current < minimum / self.alert_thresholds['warning']:
            return ConstraintStatus.WARNING
        else:
            return ConstraintStatus.COMPLIANT
    
    def _get_action_for_constraint(self, constraint_type: ConstraintType, 
                                 current: float, limit: float) -> str:
        """Kısıtlama için gerekli aksiyonu belirle"""
        if current > limit:
            if constraint_type == ConstraintType.MAX_POSITION_SIZE:
                return "Reduce position size or add diversification"
            elif constraint_type == ConstraintType.MAX_SECTOR_EXPOSURE:
                return "Reduce sector exposure or rebalance across sectors"
            elif constraint_type == ConstraintType.MAX_PORTFOLIO_RISK:
                return "Reduce portfolio volatility through diversification"
            elif constraint_type == ConstraintType.MAX_CONCENTRATION_RISK:
                return "Reduce concentration by adding more positions"
            elif constraint_type == ConstraintType.MAX_CORRELATION_EXPOSURE:
                return "Add low-correlation assets to portfolio"
            else:
                return "Review and adjust portfolio allocation"
        else:
            return "No action required"
    
    def generate_rebalancing_recommendations(self) -> List[RebalanceRecommendation]:
        """
        Rebalancing önerilerini oluştur
        
        Returns:
            List[RebalanceRecommendation]: Rebalancing önerileri
        """
        self.rebalance_recommendations = []
        
        # Evaluate all constraints first
        constraints = self.evaluate_constraints()
        
        # Risk breach triggers
        breach_constraints = [c for c in constraints if c.status in [ConstraintStatus.BREACH, ConstraintStatus.CRITICAL]]
        if breach_constraints:
            self._generate_risk_breach_recommendations(breach_constraints)
        
        # Drift threshold triggers
        self._generate_drift_threshold_recommendations()
        
        # Correlation increase triggers
        self._generate_correlation_recommendations()
        
        # Volatility spike triggers
        self._generate_volatility_recommendations()
        
        # Time-based rebalancing
        self._generate_time_based_recommendations()
        
        return self.rebalance_recommendations
    
    def _generate_risk_breach_recommendations(self, breach_constraints: List[Constraint]):
        """Risk breach önerilerini oluştur"""
        total_breach_severity = sum(c.breach_severity for c in breach_constraints)
        
        recommendation = RebalanceRecommendation(
            trigger=RebalanceTrigger.RISK_BREACH,
            priority=5,  # Highest priority
            description=f"Critical risk breaches detected: {len(breach_constraints)} constraints violated",
            recommended_actions=[
                "Immediate portfolio rebalancing required",
                "Reduce oversized positions",
                "Increase cash reserves if needed",
                "Review risk tolerance and constraints"
            ],
            expected_risk_reduction=min(total_breach_severity, 0.8),
            estimated_transaction_cost=0.005,  # 0.5% estimated cost
            urgency_score=1.0
        )
        
        self.rebalance_recommendations.append(recommendation)
    
    def _generate_drift_threshold_recommendations(self):
        """Drift threshold önerilerini oluştur"""
        # Check if positions have drifted from target weights
        for symbol, current_weight in self.current_weights.items():
            # Assuming target weights - in practice would come from strategic allocation
            target_weight = 1.0 / len(self.current_weights)  # Equal weight assumption
            
            drift = abs(current_weight - target_weight)
            
            if drift > self.config.rebalance_threshold:
                recommendation = RebalanceRecommendation(
                    trigger=RebalanceTrigger.DRIFT_THRESHOLD,
                    priority=3,
                    description=f"Position {symbol} has drifted {drift:.1%} from target",
                    recommended_actions=[
                        f"Rebalance {symbol} position from {current_weight:.1%} to {target_weight:.1%}",
                        "Consider proportional rebalancing across all positions"
                    ],
                    expected_risk_reduction=drift * 0.5,
                    estimated_transaction_cost=0.002,
                    urgency_score=min(drift / 0.1, 1.0)  # Scale urgency by drift magnitude
                )
                
                self.rebalance_recommendations.append(recommendation)
    
    def _generate_correlation_recommendations(self):
        """Korelasyon önerilerini oluştur"""
        avg_correlation = self.risk_metrics.get('avg_correlation', 0)
        
        if avg_correlation > self.config.max_correlation_exposure * 0.8:  # 80% of limit
            recommendation = RebalanceRecommendation(
                trigger=RebalanceTrigger.CORRELATION_INCREASE,
                priority=2,
                description=f"High average correlation detected: {avg_correlation:.2f}",
                recommended_actions=[
                    "Add uncorrelated assets to portfolio",
                    "Consider international or alternative investments",
                    "Review sector diversification"
                ],
                expected_risk_reduction=0.3,
                estimated_transaction_cost=0.003,
                urgency_score=min(avg_correlation / self.config.max_correlation_exposure, 1.0)
            )
            
            self.rebalance_recommendations.append(recommendation)
    
    def _generate_volatility_recommendations(self):
        """Volatilite önerilerini oluştur"""
        portfolio_vol = self.risk_metrics.get('portfolio_volatility', 0)
        
        if portfolio_vol > self.config.max_portfolio_volatility * 0.9:  # 90% of limit
            recommendation = RebalanceRecommendation(
                trigger=RebalanceTrigger.VOLATILITY_SPIKE,
                priority=3,
                description=f"High portfolio volatility: {portfolio_vol:.1%}",
                recommended_actions=[
                    "Reduce high-volatility positions",
                    "Add lower-volatility assets",
                    "Consider defensive sectors or strategies"
                ],
                expected_risk_reduction=0.4,
                estimated_transaction_cost=0.004,
                urgency_score=min(portfolio_vol / self.config.max_portfolio_volatility, 1.0)
            )
            
            self.rebalance_recommendations.append(recommendation)
    
    def _generate_time_based_recommendations(self):
        """Zaman bazlı rebalancing önerilerini oluştur"""
        # Check if rebalancing is overdue based on time
        last_rebalance = getattr(self, 'last_rebalance_date', None)
        
        if last_rebalance:
            days_since_rebalance = (datetime.now() - last_rebalance).days
        else:
            days_since_rebalance = self.config.rebalance_frequency_days + 1  # Assume overdue
        
        if days_since_rebalance >= self.config.rebalance_frequency_days:
            recommendation = RebalanceRecommendation(
                trigger=RebalanceTrigger.TIME_BASED,
                priority=1,
                description=f"Scheduled rebalancing due: {days_since_rebalance} days since last rebalance",
                recommended_actions=[
                    "Review current portfolio allocation",
                    "Rebalance to target weights",
                    "Update risk metrics and constraints"
                ],
                expected_risk_reduction=0.2,
                estimated_transaction_cost=0.001,
                urgency_score=min(days_since_rebalance / (self.config.rebalance_frequency_days * 2), 1.0)
            )
            
            self.rebalance_recommendations.append(recommendation)
    
    def get_constraint_summary(self) -> Dict[str, Any]:
        """
        Kısıtlama özetini getir
        
        Returns:
            Dict[str, Any]: Constraint summary
        """
        if not self.active_constraints:
            self.evaluate_constraints()
        
        # Summary statistics
        total_constraints = len(self.active_constraints)
        compliant = len([c for c in self.active_constraints if c.status == ConstraintStatus.COMPLIANT])
        warnings = len([c for c in self.active_constraints if c.status == ConstraintStatus.WARNING])
        breaches = len([c for c in self.active_constraints if c.status == ConstraintStatus.BREACH])
        critical = len([c for c in self.active_constraints if c.status == ConstraintStatus.CRITICAL])
        
        # Risk score calculation
        risk_score = 0.0
        for constraint in self.active_constraints:
            if constraint.status == ConstraintStatus.WARNING:
                risk_score += 0.1
            elif constraint.status == ConstraintStatus.BREACH:
                risk_score += 0.3
            elif constraint.status == ConstraintStatus.CRITICAL:
                risk_score += 0.5
        
        risk_score = min(risk_score, 1.0)  # Cap at 1.0
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_constraints': total_constraints,
            'status_distribution': {
                'compliant': compliant,
                'warning': warnings,
                'breach': breaches,
                'critical': critical
            },
            'compliance_rate': compliant / total_constraints if total_constraints > 0 else 1.0,
            'overall_risk_score': risk_score,
            'risk_level': self._categorize_risk_level(risk_score),
            'immediate_action_required': critical > 0 or breaches > 2,
            'constraints_summary': {
                c.name: {
                    'current_value': c.current_value,
                    'limit_value': c.limit_value,
                    'status': c.status.value,
                    'breach_severity': c.breach_severity,
                    'action_required': c.action_required
                }
                for c in self.active_constraints
            },
            'portfolio_metrics': self.risk_metrics,
            'rebalancing_needed': len(self.rebalance_recommendations) > 0,
            'num_rebalancing_recommendations': len(self.rebalance_recommendations)
        }
    
    def _categorize_risk_level(self, risk_score: float) -> str:
        """Risk seviyesini kategorize et"""
        if risk_score >= 0.8:
            return "Critical"
        elif risk_score >= 0.6:
            return "High"
        elif risk_score >= 0.4:
            return "Medium"
        elif risk_score >= 0.2:
            return "Low"
        else:
            return "Minimal"
    
    def update_last_rebalance_date(self, date: Optional[datetime] = None):
        """Son rebalancing tarihini güncelle"""
        self.last_rebalance_date = date or datetime.now()


# Test fonksiyonu
def test_portfolio_risk_constraints():
    """Portfolio Risk Constraints test fonksiyonu"""
    
    # Test configuration
    config = PortfolioConstraints(
        max_single_position=0.15,
        max_technology_exposure=0.50,
        max_portfolio_volatility=0.20,
        min_cash_reserve=0.05,
        rebalance_threshold=0.05
    )
    
    constraint_manager = PortfolioRiskConstraints(config)
    
    # Test portfolio state
    positions = {
        'AAPL': 1000,  # Technology
        'GOOGL': 800,  # Technology
        'MSFT': 600,   # Technology
        'JNJ': 400,    # Healthcare
        'PG': 300      # Consumer Goods
    }
    
    prices = {
        'AAPL': 150,
        'GOOGL': 2500,
        'MSFT': 300,
        'JNJ': 160,
        'PG': 140
    }
    
    sectors = {
        'AAPL': 'Technology',
        'GOOGL': 'Technology',
        'MSFT': 'Technology',
        'JNJ': 'Healthcare',
        'PG': 'Consumer Goods'
    }
    
    # Correlation data (simplified)
    correlation_data = {
        ('AAPL', 'GOOGL'): 0.7,
        ('AAPL', 'MSFT'): 0.6,
        ('GOOGL', 'MSFT'): 0.65,
        ('AAPL', 'JNJ'): 0.3,
        ('AAPL', 'PG'): 0.2
    }
    
    # Update portfolio state
    constraint_manager.update_portfolio_state(positions, prices, sectors, correlation_data)
    
    # Evaluate constraints
    print("=== Constraint Evaluation ===")
    constraints = constraint_manager.evaluate_constraints()
    
    for constraint in constraints:
        print(f"\n{constraint.name}:")
        print(f"  Current: {constraint.current_value:.3f}")
        print(f"  Limit: {constraint.limit_value:.3f}")
        print(f"  Status: {constraint.status.value}")
        print(f"  Severity: {constraint.breach_severity:.3f}")
        print(f"  Action: {constraint.action_required}")
    
    # Generate rebalancing recommendations
    print("\n=== Rebalancing Recommendations ===")
    recommendations = constraint_manager.generate_rebalancing_recommendations()
    
    if recommendations:
        for rec in recommendations:
            print(f"\n{rec.trigger.value} (Priority: {rec.priority}):")
            print(f"  Description: {rec.description}")
            print(f"  Urgency: {rec.urgency_score:.3f}")
            print(f"  Actions:")
            for action in rec.recommended_actions:
                print(f"    - {action}")
            print(f"  Expected Risk Reduction: {rec.expected_risk_reduction:.1%}")
            print(f"  Transaction Cost: {rec.estimated_transaction_cost:.1%}")
    else:
        print("No rebalancing recommendations at this time.")
    
    # Get constraint summary
    print("\n=== Constraint Summary ===")
    summary = constraint_manager.get_constraint_summary()
    
    print(f"Total Constraints: {summary['total_constraints']}")
    print(f"Compliance Rate: {summary['compliance_rate']:.1%}")
    print(f"Overall Risk Score: {summary['overall_risk_score']:.3f}")
    print(f"Risk Level: {summary['risk_level']}")
    print(f"Immediate Action Required: {summary['immediate_action_required']}")
    
    print("\nStatus Distribution:")
    for status, count in summary['status_distribution'].items():
        print(f"  {status}: {count}")
    
    print("\nPortfolio Metrics:")
    for metric, value in summary['portfolio_metrics'].items():
        if isinstance(value, float):
            print(f"  {metric}: {value:.3f}")
    
    return constraint_manager, summary


if __name__ == "__main__":
    test_portfolio_risk_constraints()