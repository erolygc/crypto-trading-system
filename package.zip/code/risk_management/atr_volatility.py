"""
ATR-Based Volatilite Hedefleme Modülü
====================================

Average True Range (ATR) kullanarak volatilite hedefleme ve pozisyon 
boyutlandırma algoritması.

ATR (Average True Range) finansal piyasalarda volatilite ölçümü için 
kullanılan teknik indikatör. Bu modül ATR'yi kullanarak:
- Hedef volatilite seviyesini hesaplar
- Pozisyon boyutunu volatiliteye göre ayarlar
- Piyasa koşullarına göre dinamik adjustment yapar
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from enum import Enum
import warnings

warnings.filterwarnings('ignore')


class MarketRegime(Enum):
    """Piyasa rejimleri"""
    LOW_VOLATILITY = "low_volatility"
    NORMAL_VOLATILITY = "normal_volatility"
    HIGH_VOLATILITY = "high_volatility"
    EXTREME_VOLATILITY = "extreme_volatility"


@dataclass
class ATRConfig:
    """ATR konfigürasyonu"""
    atr_period: int = 14
    target_volatility: float = 0.15  # %15 yıllık volatilite hedefi
    max_volatility_multiplier: float = 2.5
    min_volatility_multiplier: float = 0.3
    regime_thresholds: Dict[str, float] = None
    
    def __post_init__(self):
        if self.regime_thresholds is None:
            self.regime_thresholds = {
                'low_vol': 0.8,
                'high_vol': 1.5
            }


@dataclass
class ATRMetrics:
    """ATR metrikleri"""
    current_atr: float
    normalized_atr: float
    volatility_ratio: float
    regime: MarketRegime
    position_multiplier: float
    target_position_size: float
    risk_level: str
    confidence_level: float


class ATRVolatilityTargeter:
    """
    ATR-Based Volatilite Hedefleyici
    
    Average True Range kullanarak volatilite hedefleme yapan ve
    pozisyon boyutlandırmasını ayarlayan sınıf.
    """
    
    def __init__(self, config: Optional[ATRConfig] = None):
        """
        ATR Volatility Targeter'ı başlat
        
        Args:
            config: ATR konfigürasyonu
        """
        self.config = config or ATRConfig()
        self.atr_history: List[float] = []
        self.regime_history: List[MarketRegime] = []
        
    def calculate_atr(self, high: pd.Series, low: pd.Series, 
                     close: pd.Series, period: Optional[int] = None) -> pd.Series:
        """
        Average True Range hesapla
        
        Args:
            high: Yüksek fiyat serisi
            low: Düşük fiyat serisi
            close: Kapanış fiyat serisi
            period: ATR periyodu
        
        Returns:
            pd.Series: ATR değerleri
        """
        period = period or self.config.atr_period
        
        # True Range hesapla
        high_low = high - low
        high_close = np.abs(high - close.shift(1))
        low_close = np.abs(low - close.shift(1))
        
        true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        
        # ATR hesapla (Wilder's smoothing)
        atr = true_range.rolling(window=period).mean()
        
        return atr
    
    def detect_market_regime(self, current_atr: float, 
                           atr_history: List[float]) -> MarketRegime:
        """
        Mevcut piyasa rejimini tespit et
        
        Args:
            current_atr: Mevcut ATR değeri
            atr_history: ATR geçmişi
        
        Returns:
            MarketRegime: Tespit edilen rejim
        """
        if len(atr_history) < self.config.atr_period:
            return MarketRegime.NORMAL_VOLATILITY
        
        # Son 20 ATR değerinin ortalamasını kullan
        recent_atrs = atr_history[-20:] if len(atr_history) >= 20 else atr_history
        avg_atr = np.mean(recent_atrs)
        
        if current_atr < avg_atr * self.config.regime_thresholds['low_vol']:
            return MarketRegime.LOW_VOLATILITY
        elif current_atr > avg_atr * self.config.regime_thresholds['high_vol']:
            return MarketRegime.EXTREME_VOLATILITY
        elif current_atr > avg_atr * 1.2:
            return MarketRegime.HIGH_VOLATILITY
        else:
            return MarketRegime.NORMAL_VOLATILITY
    
    def calculate_position_multiplier(self, regime: MarketRegime, 
                                    volatility_ratio: float) -> float:
        """
        Pozisyon çarpanını hesapla
        
        Args:
            regime: Piyasa rejimi
            volatility_ratio: Volatilite oranı
        
        Returns:
            float: Pozisyon çarpanı
        """
        base_multipliers = {
            MarketRegime.LOW_VOLATILITY: 1.5,
            MarketRegime.NORMAL_VOLATILITY: 1.0,
            MarketRegime.HIGH_VOLATILITY: 0.6,
            MarketRegime.EXTREME_VOLATILITY: 0.3
        }
        
        base_multiplier = base_multipliers[regime]
        
        # Volatilite oranına göre adjustment
        if volatility_ratio > 1.0:
            adjustment = 1.0 / volatility_ratio
        else:
            adjustment = volatility_ratio
        
        # Limitler içinde tut
        multiplier = base_multiplier * adjustment
        multiplier = np.clip(
            multiplier,
            self.config.min_volatility_multiplier,
            self.config.max_volatility_multiplier
        )
        
        return multiplier
    
    def calculate_target_position_size(self, 
                                     account_value: float,
                                     atr_normalized: float,
                                     position_multiplier: float,
                                     max_position_pct: float = 0.2) -> float:
        """
        Hedef pozisyon boyutunu hesapla
        
        Args:
            account_value: Hesap değeri
            atr_normalized: Normalize edilmiş ATR
            position_multiplier: Pozisyon çarpanı
            max_position_pct: Maksimum pozisyon yüzdesi
        
        Returns:
            float: Hedef pozisyon boyutu
        """
        # Volatilite hedefine göre pozisyon boyutu
        # ATR yüksekse pozisyon küçült, düşükse büyüt
        volatility_adjustment = min(1.0 / atr_normalized, 2.0)
        
        # Temel pozisyon boyutu
        base_position = account_value * self.config.target_volatility * 0.01
        
        # Çarpanlarla ayarla
        target_size = base_position * position_multiplier * volatility_adjustment
        
        # Maksimum limit uygula
        max_size = account_value * max_position_pct
        target_size = min(target_size, max_size)
        
        return max(target_size, 0)
    
    def analyze_asset_volatility(self, 
                               price_data: pd.DataFrame,
                               asset_symbol: str) -> ATRMetrics:
        """
        Varlık volatilitesini analiz et
        
        Args:
            price_data: Fiyat verisi
            asset_symbol: Varlık sembolu
        
        Returns:
            ATRMetrics: Volatilite analizi sonucu
        """
        if len(price_data) < self.config.atr_period + 1:
            raise ValueError(f"Yetersiz veri: en az {self.config.atr_period + 1} gün gerekli")
        
        # ATR hesapla
        atr = self.calculate_atr(
            price_data['high'],
            price_data['low'], 
            price_data['close']
        )
        
        current_atr = atr.iloc[-1]
        self.atr_history.append(current_atr)
        
        # Normalize et
        current_price = price_data['close'].iloc[-1]
        normalized_atr = current_atr / current_price
        
        # Volatilite oranı hesapla
        recent_atrs = self.atr_history[-20:] if len(self.atr_history) >= 20 else self.atr_history
        avg_atr = np.mean(recent_atrs) / current_price
        volatility_ratio = normalized_atr / avg_atr if avg_atr > 0 else 1.0
        
        # Piyasa rejimi tespit et
        regime = self.detect_market_regime(normalized_atr, [a/current_price for a in self.atr_history])
        self.regime_history.append(regime)
        
        # Pozisyon çarpanı hesapla
        position_multiplier = self.calculate_position_multiplier(regime, volatility_ratio)
        
        # Risk seviyesi belirle
        if volatility_ratio < 0.8:
            risk_level = "Düşük Risk"
        elif volatility_ratio < 1.2:
            risk_level = "Normal Risk"
        elif volatility_ratio < 1.8:
            risk_level = "Yüksek Risk"
        else:
            risk_level = "Çok Yüksek Risk"
        
        # Güven seviyesi hesapla
        confidence = self._calculate_confidence_level(regime, volatility_ratio)
        
        return ATRMetrics(
            current_atr=current_atr,
            normalized_atr=normalized_atr,
            volatility_ratio=volatility_ratio,
            regime=regime,
            position_multiplier=position_multiplier,
            target_position_size=0.0,  # Hesap değeri bilinmediği için 0
            risk_level=risk_level,
            confidence_level=confidence
        )
    
    def _calculate_confidence_level(self, regime: MarketRegime, 
                                  volatility_ratio: float) -> float:
        """
        Güven seviyesini hesapla
        
        Args:
            regime: Piyasa rejimi
            volatility_ratio: Volatilite oranı
        
        Returns:
            float: Güven seviyesi (0-1)
        """
        base_confidence = {
            MarketRegime.LOW_VOLATILITY: 0.9,
            MarketRegime.NORMAL_VOLATILITY: 0.8,
            MarketRegime.HIGH_VOLATILITY: 0.6,
            MarketRegime.EXTREME_VOLATILITY: 0.4
        }
        
        confidence = base_confidence[regime]
        
        # Volatilite oranına göre adjustment
        if volatility_ratio > 1.0:
            confidence *= (1.0 / volatility_ratio)
        
        return np.clip(confidence, 0.1, 1.0)
    
    def batch_analyze_assets(self, 
                           asset_data: Dict[str, pd.DataFrame],
                           account_value: Optional[float] = None) -> Dict[str, ATRMetrics]:
        """
        Birden fazla varlığı toplu analiz et
        
        Args:
            asset_data: {sembol: price_data} mapping
            account_value: Toplam hesap değeri
        
        Returns:
            Dict[str, ATRMetrics]: Varlık bazlı ATR analizi sonuçları
        """
        results = {}
        
        for symbol, price_data in asset_data.items():
            try:
                metrics = self.analyze_asset_volatility(price_data, symbol)
                
                # Eğer hesap değeri verildiyse pozisyon boyutunu hesapla
                if account_value:
                    metrics.target_position_size = self.calculate_target_position_size(
                        account_value,
                        metrics.normalized_atr,
                        metrics.position_multiplier
                    )
                
                results[symbol] = metrics
                
            except Exception as e:
                print(f"Varlık {symbol} analizi başarısız: {e}")
                # Hata durumunda default metrics oluştur
                results[symbol] = ATRMetrics(
                    current_atr=0.0,
                    normalized_atr=0.0,
                    volatility_ratio=1.0,
                    regime=MarketRegime.NORMAL_VOLATILITY,
                    position_multiplier=1.0,
                    target_position_size=0.0,
                    risk_level="Analiz Hatası",
                    confidence_level=0.0
                )
        
        return results
    
    def get_regime_summary(self) -> Dict[str, Any]:
        """
        Piyasa rejimi özetini getir
        
        Returns:
            Dict[str, Any]: Rejim özeti
        """
        if not self.regime_history:
            return {"message": "Henüz rejim analizi yapılmadı"}
        
        regime_counts = {}
        for regime in self.regime_history:
            regime_counts[regime.value] = regime_counts.get(regime.value, 0) + 1
        
        current_regime = self.regime_history[-1] if self.regime_history else MarketRegime.NORMAL_VOLATILITY
        dominant_regime = max(regime_counts, key=regime_counts.get)
        
        return {
            "current_regime": current_regime.value,
            "dominant_regime": dominant_regime,
            "regime_distribution": regime_counts,
            "total_observations": len(self.regime_history),
            "recent_trend": "Güçlendiriliyor" if len(self.regime_history) > 5 and 
                           self.regime_history[-1] == self.regime_history[-2] else "Değişken"
        }
    
    def generate_volatility_report(self, 
                                 asset_data: Dict[str, pd.DataFrame],
                                 account_value: float = 100000) -> Dict[str, Any]:
        """
        Volatilite raporu oluştur
        
        Args:
            asset_data: Varlık fiyat verileri
            account_value: Hesap değeri
        
        Returns:
            Dict[str, Any]: Kapsamlı volatilite raporu
        """
        # Tüm varlıkları analiz et
        analysis_results = self.batch_analyze_assets(asset_data, account_value)
        
        # Portföy volatilitesi hesapla
        portfolio_volatility = self._calculate_portfolio_volatility(analysis_results)
        
        # Risk özeti
        risk_summary = self._generate_risk_summary(analysis_results)
        
        # Öneriler
        recommendations = self._generate_recommendations(analysis_results)
        
        return {
            "timestamp": pd.Timestamp.now().isoformat(),
            "account_value": account_value,
            "asset_analysis": {
                symbol: {
                    "current_atr": metrics.current_atr,
                    "normalized_atr": metrics.normalized_atr,
                    "volatility_ratio": metrics.volatility_ratio,
                    "regime": metrics.regime.value,
                    "position_multiplier": metrics.position_multiplier,
                    "target_position_size": metrics.target_position_size,
                    "risk_level": metrics.risk_level,
                    "confidence_level": metrics.confidence_level
                }
                for symbol, metrics in analysis_results.items()
            },
            "portfolio_volatility": portfolio_volatility,
            "risk_summary": risk_summary,
            "recommendations": recommendations,
            "regime_summary": self.get_regime_summary()
        }
    
    def _calculate_portfolio_volatility(self, 
                                      analysis_results: Dict[str, ATRMetrics]) -> Dict[str, float]:
        """Portföy volatilitesini hesapla"""
        if not analysis_results:
            return {"overall": 0.0}
        
        # Ağırlıklı ortalama volatilite
        total_weight = 0.0
        weighted_volatility = 0.0
        
        for metrics in analysis_results.values():
            weight = metrics.position_multiplier
            total_weight += weight
            weighted_volatility += metrics.normalized_atr * weight
        
        if total_weight > 0:
            portfolio_vol = weighted_volatility / total_weight
        else:
            portfolio_vol = 0.0
        
        return {
            "overall": portfolio_vol,
            "average_normalized_atr": np.mean([m.normalized_atr for m in analysis_results.values()]),
            "max_volatility_ratio": max([m.volatility_ratio for m in analysis_results.values()]),
            "min_volatility_ratio": min([m.volatility_ratio for m in analysis_results.values()])
        }
    
    def _generate_risk_summary(self, 
                             analysis_results: Dict[str, ATRMetrics]) -> Dict[str, Any]:
        """Risk özeti oluştur"""
        if not analysis_results:
            return {"message": "Analiz edilecek varlık bulunamadı"}
        
        risk_levels = [m.risk_level for m in analysis_results.values()]
        regimes = [m.regime.value for m in analysis_results.values()]
        
        return {
            "total_assets": len(analysis_results),
            "risk_distribution": {
                level: risk_levels.count(level) 
                for level in set(risk_levels)
            },
            "regime_distribution": {
                regime: regimes.count(regime)
                for regime in set(regimes)
            },
            "high_risk_assets": [
                symbol for symbol, m in analysis_results.items() 
                if m.risk_level in ["Yüksek Risk", "Çok Yüksek Risk"]
            ],
            "average_confidence": np.mean([m.confidence_level for m in analysis_results.values()])
        }
    
    def _generate_recommendations(self, 
                                analysis_results: Dict[str, ATRMetrics]) -> List[str]:
        """Pozisyon boyutlandırma önerileri oluştur"""
        recommendations = []
        
        if not analysis_results:
            return ["Varlık analizi yapılamadı - veri kontrolü gerekli"]
        
        # Yüksek volatilite önerisi
        high_vol_assets = [
            symbol for symbol, m in analysis_results.items()
            if m.volatility_ratio > 1.5
        ]
        
        if high_vol_assets:
            recommendations.append(
                f"Yüksek volatilite: {', '.join(high_vol_assets)} için pozisyon boyutunu küçültün"
            )
        
        # Düşük volatilite fırsatı
        low_vol_assets = [
            symbol for symbol, m in analysis_results.items()
            if m.volatility_ratio < 0.8 and m.confidence_level > 0.7
        ]
        
        if low_vol_assets:
            recommendations.append(
                f"Düşük volatilite fırsatı: {', '.join(low_vol_assets)} için pozisyon boyutunu artırabilirsiniz"
            )
        
        # Portföy dengeleme
        extreme_regimes = [
            symbol for symbol, m in analysis_results.items()
            if m.regime in [MarketRegime.EXTREME_VOLATILITY]
        ]
        
        if extreme_regimes:
            recommendations.append(
                f"Extreme volatilite rejimi: {', '.join(extreme_regimes)} için pozisyonları gözden geçirin"
            )
        
        if not recommendations:
            recommendations.append("Mevcut volatilite seviyeleri normal aralıkta")
        
        return recommendations


# Test fonksiyonu
def test_atr_volatility_targeter():
    """Test fonksiyonu"""
    import matplotlib.pyplot as plt
    
    # Synthetic price data oluştur
    np.random.seed(42)
    dates = pd.date_range(start='2023-01-01', periods=100, freq='D')
    
    # Random walk price data
    returns = np.random.normal(0.001, 0.02, 100)
    prices = 100 * np.cumprod(1 + returns)
    
    # OHLC data oluştur
    high = prices * (1 + np.abs(np.random.normal(0, 0.005, 100)))
    low = prices * (1 - np.abs(np.random.normal(0, 0.005, 100)))
    
    price_data = pd.DataFrame({
        'high': high,
        'low': low,
        'close': prices
    }, index=dates)
    
    # ATR analyzer başlat
    targeter = ATRVolatilityTargeter()
    
    # Test
    metrics = targeter.analyze_asset_volatility(price_data, 'TEST')
    
    print(f"Current ATR: {metrics.current_atr:.4f}")
    print(f"Normalized ATR: {metrics.normalized_atr:.4f}")
    print(f"Volatility Ratio: {metrics.volatility_ratio:.2f}")
    print(f"Market Regime: {metrics.regime.value}")
    print(f"Position Multiplier: {metrics.position_multiplier:.2f}")
    print(f"Risk Level: {metrics.risk_level}")
    print(f"Confidence Level: {metrics.confidence_level:.2f}")
    
    # Toplu test
    asset_data = {
        'ASSET1': price_data,
        'ASSET2': price_data * 1.1,
        'ASSET3': price_data * 0.9
    }
    
    report = targeter.generate_volatility_report(asset_data, 100000)
    
    print("\nPortfolio Report:")
    print(f"Overall Portfolio Volatility: {report['portfolio_volatility']['overall']:.4f}")
    print("Recommendations:")
    for rec in report['recommendations']:
        print(f"- {rec}")
    
    return targeter, report


if __name__ == "__main__":
    test_atr_volatility_targeter()