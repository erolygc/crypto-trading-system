#!/usr/bin/env python3
"""
Iceberg Detection System - Örnek Kullanım

Bu script, iceberg detection sisteminin temel kullanımını gösterir.
Farklı market senaryoları ile sistem test edilir.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from iceberg_detection import (
    IcebergDetectionSystem, 
    SystemConfiguration,
    IcebergMonitor
)

def generate_sample_market_data():
    """Örnek market verisi oluşturur"""
    
    # Normal market conditions
    normal_bids = [
        (100.00, 500), (99.95, 300), (99.90, 800),
        (99.85, 600), (99.80, 400)
    ]
    
    normal_asks = [
        (100.05, 450), (100.10, 550), (100.15, 700),
        (100.20, 350), (100.25, 600)
    ]
    
    normal_trades = [
        (100.02, 200, datetime.now() - timedelta(minutes=10)),
        (100.03, 150, datetime.now() - timedelta(minutes=9)),
        (100.01, 300, datetime.now() - timedelta(minutes=8)),
        (100.04, 100, datetime.now() - timedelta(minutes=7)),
        (100.02, 250, datetime.now() - timedelta(minutes=6))
    ]
    
    # Large iceberg scenario
    iceberg_bids = [
        (100.00, 5000), (99.95, 300), (99.90, 800),  # Large bid at 100.00
        (99.85, 600), (99.80, 400)
    ]
    
    iceberg_asks = [
        (100.05, 450), (100.10, 550), (100.15, 700),
        (100.20, 350), (100.25, 600)
    ]
    
    iceberg_trades = [
        (100.00, 200, datetime.now() - timedelta(minutes=10)),  # Execution at large bid
        (100.00, 300, datetime.now() - timedelta(minutes=9)),   # More execution
        (100.00, 150, datetime.now() - timedelta(minutes=8)),   # Consistent execution
        (100.00, 400, datetime.now() - timedelta(minutes=7)),   # Larger execution
        (100.00, 250, datetime.now() - timedelta(minutes=6))    # More execution
    ]
    
    return {
        'normal': (normal_bids, normal_asks, normal_trades),
        'iceberg': (iceberg_bids, iceberg_asks, iceberg_trades)
    }

def demo_basic_analysis():
    """Temel analiz demo'su"""
    print("=" * 60)
    print("🧊 ICEBERG DETECTION SYSTEM - BASIC ANALYSIS DEMO")
    print("=" * 60)
    
    # Market data
    data = generate_sample_market_data()
    
    # Sistem konfigürasyonu
    config = SystemConfiguration(
        detection_sensitivity=0.7,
        min_iceberg_size=1000,
        enable_real_time_monitoring=False,  # Demo için kapatıldı
        enable_adversarial_detection=True
    )
    
    # Sistem başlatma
    system = IcebergDetectionSystem(config)
    
    print("\n📊 TEST 1: NORMAL MARKET CONDITIONS")
    print("-" * 40)
    
    normal_bids, normal_asks, normal_trades = data['normal']
    results = system.analyze_market_data(normal_bids, normal_asks, normal_trades)
    
    print(f"✅ Analysis completed")
    print(f"📈 Overall Confidence: {results.overall_confidence:.3f}")
    print(f"⚠️  Risk Level: {results.risk_level}")
    print(f"🔍 Hidden Orders Detected: {len(results.hidden_orders)}")
    print(f"🧊 Iceberg Estimates: {len(results.iceberg_estimates)}")
    print(f"🚨 Adversarial Signals: {len(results.adversarial_signals)}")
    
    if results.liquidity_metrics:
        print(f"💧 Liquidity Score: {results.liquidity_metrics.liquidity_score:.3f}")
        print(f"📏 Bid-Ask Spread: {results.liquidity_metrics.bid_ask_spread:.4f}")
    
    print(f"💡 Recommendations ({len(results.recommendations)}):")
    for i, rec in enumerate(results.recommendations[:3], 1):
        print(f"   {i}. {rec}")
    
    print("\n📊 TEST 2: ICEBERG DETECTION")
    print("-" * 40)
    
    iceberg_bids, iceberg_asks, iceberg_trades = data['iceberg']
    iceberg_results = system.analyze_market_data(iceberg_bids, iceberg_asks, iceberg_trades)
    
    print(f"✅ Analysis completed")
    print(f"📈 Overall Confidence: {iceberg_results.overall_confidence:.3f}")
    print(f"⚠️  Risk Level: {iceberg_results.risk_level}")
    print(f"🔍 Hidden Orders Detected: {len(iceberg_results.hidden_orders)}")
    print(f"🧊 Iceberg Estimates: {len(iceberg_results.iceberg_estimates)}")
    
    for i, estimate in enumerate(iceberg_results.iceberg_estimates, 1):
        print(f"\n🧊 Iceberg #{i}:")
        print(f"   📏 Estimated Size: {estimate.estimated_size:.0f} units")
        print(f"   🎯 Confidence Score: {estimate.confidence_score:.3f}")
        print(f"   📊 Execution Progress: {estimate.execution_progress:.1%}")
        print(f"   ⏳ Remaining Size: {estimate.remaining_size:.0f} units")
        print(f"   📈 Confidence Interval: ({estimate.confidence_interval[0]:.0f}, {estimate.confidence_interval[1]:.0f})")
        
        # Execution plan oluşturma
        if estimate.estimated_size > 0:
            print(f"\n💼 Creating Execution Plan...")
            execution_plan = system.create_execution_plan(
                estimate, current_price=100.00, urgency_level=0.3
            )
            print(f"   🎯 Strategy: {execution_plan.strategy_type.value}")
            print(f"   ✂️  Split Count: {execution_plan.split_count}")
            print(f"   🥷 Stealth Factor: {execution_plan.stealth_factor:.3f}")
            print(f"   💸 Estimated Slippage: {execution_plan.estimated_slippage:.3%}")
            print(f"   ⚠️  Front-run Risk: {execution_plan.front_run_risk:.3f}")
    
    print(f"\n💡 Recommendations ({len(iceberg_results.recommendations)}):")
    for i, rec in enumerate(iceberg_results.recommendations[:5], 1):
        print(f"   {i}. {rec}")
    
    return system

def demo_real_time_monitoring(system):
    """Real-time monitoring demo'su"""
    print("\n" + "=" * 60)
    print("📡 REAL-TIME MONITORING DEMO")
    print("=" * 60)
    
    # Monitoring başlatma
    session_id = system.start_real_time_monitoring("demo_session")
    
    if not session_id:
        print("❌ Real-time monitoring could not be started")
        return
    
    print(f"✅ Monitoring started - Session ID: {session_id}")
    
    # Simulated real-time data stream
    print("\n📨 Simulating real-time data stream...")
    
    for i in range(10):
        # Simulate order
        order = {
            'order_id': f'order_{i:03d}',
            'side': 'buy' if i % 2 == 0 else 'sell',
            'size': 1000 + (i * 200),  # Varying sizes
            'price': 100.00 + (i * 0.01),
            'trader_id': f'trader_{i % 3:03d}'
        }
        system.monitor.add_order_data(order)
        
        # Simulate trade
        trade = {
            'price': 100.00 + (i * 0.005),
            'size': 100 + (i * 50),
            'timestamp': datetime.now(),
            'side': 'buy'
        }
        system.monitor.add_trade_data(trade)
        
        # Simulate quote
        quote = {
            'bid_price': 100.00 - (i * 0.002),
            'ask_price': 100.00 + (i * 0.002),
            'bid_size': 500 + (i * 100),
            'ask_size': 450 + (i * 75),
            'maker_id': f'maker_{i % 2:03d}'
        }
        system.monitor.add_quote_data(quote)
        
        print(f"   📊 Data point {i+1}/10: Order {order['order_id']}, Trade {trade['size']:.0f}")
        
        # Small delay to simulate real-time
        import time
        time.sleep(0.1)
    
    # Get real-time metrics
    print("\n📈 Real-time Metrics:")
    metrics = system.monitor.get_real_time_metrics(session_id)
    print(f"   🧊 Current Iceberg Count: {metrics.current_iceberg_count}")
    print(f"   📊 Total Hidden Volume: {metrics.total_hidden_volume:.0f}")
    print(f"   ⚡ Execution Intensity: {metrics.execution_intensity:.2f}")
    print(f"   📉 Market Impact Score: {metrics.market_impact_score:.3f}")
    print(f"   🎯 Detection Accuracy: {metrics.detection_accuracy:.3f}")
    print(f"   📢 Alert Frequency: {metrics.alert_frequency:.2f} per minute")
    
    # Get monitoring summary
    print("\n📋 Monitoring Summary:")
    summary = system.monitor.get_monitoring_summary(session_id)
    if summary:
        print(f"   ⏱️  Session Duration: {summary['session_info']['duration_minutes']:.1f} minutes")
        print(f"   🧊 Active Icebergs: {summary['iceberg_statistics']['active_icebergs']}")
        print(f"   ✅ Completed Icebergs: {summary['iceberg_statistics']['completed_icebergs']}")
        print(f"   🚨 Total Alerts: {summary['alert_statistics']['total_alerts']}")
        print(f"   ⚠️  Critical Alerts: {summary['alert_statistics']['critical_alerts']}")
    
    # Stop monitoring
    print("\n🛑 Stopping real-time monitoring...")
    success = system.stop_real_time_monitoring()
    print(f"✅ Monitoring stopped successfully" if success else "❌ Failed to stop monitoring")

def demo_system_statistics(system):
    """Sistem istatistikleri demo'su"""
    print("\n" + "=" * 60)
    print("📊 SYSTEM STATISTICS DEMO")
    print("=" * 60)
    
    stats = system.get_system_statistics()
    
    print("\n🔧 System Configuration:")
    config = stats['system_info']['config']
    print(f"   🎯 Detection Sensitivity: {config['detection_sensitivity']:.2f}")
    print(f"   📏 Min Iceberg Size: {config['min_iceberg_size']:.0f}")
    print(f"   📡 Real-time Monitoring: {config['real_time_monitoring']}")
    print(f"   🚨 Adversarial Detection: {config['adversarial_detection']}")
    
    print("\n⚡ Performance Metrics:")
    perf = stats['performance']
    print(f"   🔍 Total Detections: {perf['total_detections']}")
    print(f"   ❌ False Positives: {perf['false_positives']}")
    print(f"   🎯 Accuracy Rate: {perf['accuracy_rate']:.3f}")
    print(f"   ⏱️  Avg Processing Time: {perf['avg_processing_time']:.3f}s")
    
    print("\n🔧 Component Status:")
    for component, status in stats['component_status'].items():
        status_icon = "✅" if status == "active" else "❌"
        print(f"   {status_icon} {component}: {status}")
    
    # Export demo
    print("\n💾 Exporting Detection Results...")
    export_data = system.export_detection_results("json", "1h")
    if export_data:
        import json
        export_dict = json.loads(export_data)
        print(f"   📊 Exported {len(export_dict)} detection records")
        if export_dict:
            print(f"   📈 Sample record: {export_dict[0]}")
    
    return stats

def demo_risk_analysis():
    """Risk analizi demo'su"""
    print("\n" + "=" * 60)
    print("⚠️  RISK ANALYSIS DEMO")
    print("=" * 60)
    
    # Yüksek risk senaryosu
    high_risk_bids = [
        (100.00, 15000),  # Çok büyük bid
        (99.95, 300), (99.90, 800),
        (99.85, 600), (99.80, 400)
    ]
    
    high_risk_asks = [
        (100.05, 450), (100.10, 20000),  # Büyük ask duvarı
        (100.15, 700), (100.20, 350), (100.25, 600)
    ]
    
    suspicious_trades = [
        (100.00, 500, datetime.now() - timedelta(minutes=5)),
        (100.00, 800, datetime.now() - timedelta(minutes=4)),
        (100.00, 300, datetime.now() - timedelta(minutes=3)),
        (99.90, 1200, datetime.now() - timedelta(minutes=2)),  # Anormal trade
        (100.10, 900, datetime.now() - timedelta(minutes=1))   # Anormal trade
    ]
    
    # Adversarial trades
    adversarial_orders = [
        {'order_id': 'adv_001', 'side': 'buy', 'size': 5000, 'price': 100.00, 'trader_id': 'suspicious_001'},
        {'order_id': 'adv_002', 'side': 'buy', 'size': 4000, 'price': 99.95, 'trader_id': 'suspicious_001'},
        {'order_id': 'adv_003', 'side': 'buy', 'size': 3000, 'price': 99.90, 'trader_id': 'suspicious_001'},
    ]
    
    adversarial_quotes = [
        {'bid_price': 100.00, 'ask_price': 100.05, 'bid_size': 5000, 'ask_size': 450, 'maker_id': 'suspicious_mm'},
        {'bid_price': 99.95, 'ask_price': 100.10, 'bid_size': 4000, 'ask_size': 550, 'maker_id': 'suspicious_mm'},
    ]
    
    config = SystemConfiguration(
        detection_sensitivity=0.8,  # Daha hassas
        min_iceberg_size=2000,      # Daha büyük threshold
        enable_adversarial_detection=True
    )
    
    system = IcebergDetectionSystem(config)
    
    risk_results = system.analyze_market_data(
        high_risk_bids, high_risk_asks, suspicious_trades,
        orders=adversarial_orders, quotes=adversarial_quotes
    )
    
    print(f"🚨 HIGH RISK ANALYSIS RESULTS:")
    print(f"   ⚠️  Risk Level: {risk_results.risk_level.upper()}")
    print(f"   📈 Confidence: {risk_results.overall_confidence:.3f}")
    print(f"   🧊 Icebergs Detected: {len(risk_results.iceberg_estimates)}")
    print(f"   🚨 Adversarial Signals: {len(risk_results.adversarial_signals)}")
    print(f"   📊 Market Making Patterns: {len(risk_results.market_making_patterns)}")
    
    # Adversarial signals detayı
    print(f"\n🚨 ADVERSARIAL SIGNALS:")
    for signal in risk_results.adversarial_signals:
        print(f"   🔍 Type: {signal.signal_type}")
        print(f"   🎯 Confidence: {signal.confidence:.3f}")
        print(f"   ⚠️  Severity: {signal.severity.upper()}")
        print(f"   📊 Evidence Count: {signal.evidence_count}")
        print(f"   💰 Price Impact: {signal.price_impact:.4f}")
        print()
    
    # Market making patterns
    print(f"📊 MARKET MAKING PATTERNS:")
    for pattern in risk_results.market_making_patterns:
        print(f"   🎭 Type: {pattern.pattern_type}")
        print(f"   🎯 Confidence: {pattern.confidence:.3f}")
        print(f"   📈 Renewal Frequency: {pattern.renewal_frequency:.3f}")
        print()
    
    # Risk azaltma önerileri
    print(f"💡 RISK MITIGATION RECOMMENDATIONS:")
    for i, rec in enumerate(risk_results.recommendations, 1):
        print(f"   {i}. {rec}")
    
    return risk_results

def main():
    """Ana demo fonksiyonu"""
    print("🧊 ICEBERG DETECTION SYSTEM - COMPREHENSIVE DEMO")
    print("🔬 Testing all major components and features")
    print("⏰ Starting comprehensive demonstration...\n")
    
    try:
        # 1. Basic Analysis Demo
        system = demo_basic_analysis()
        
        # 2. Real-time Monitoring Demo (optional)
        if system.monitor:
            demo_real_time_monitoring(system)
        
        # 3. System Statistics Demo
        demo_system_statistics(system)
        
        # 4. Risk Analysis Demo
        demo_risk_analysis()
        
        print("\n" + "=" * 60)
        print("✅ DEMO COMPLETED SUCCESSFULLY")
        print("🎉 All major features tested and working!")
        print("📚 Check docs/iceberg_detection.md for detailed documentation")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ DEMO ERROR: {e}")
        print("🔧 Please check the error and try again")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()