"""
Iceberg Detection Sistemi

Bu modül büyük alım/satım duvarlarını tespit etmek için kapsamlı algoritmalar içerir.
Tespit edilen iceberg'lar için boyut tahmini, market impact analizi ve adversarial
trading tespiti yapar.

Bileşenler:
- Order book pattern analysis
- Hidden order detection algorithms
- Iceberg size estimation
- Front-running avoidance strategies
- Market impact prediction
- Liquidity analysis
- VWAP benchmark calculation
- Market making behavior detection
- Adversarial trading detection
- Real-time iceberg monitoring
"""

from .order_book_analyzer import OrderBookAnalyzer
from .hidden_order_detector import HiddenOrderDetector
from .iceberg_estimator import IcebergEstimator
from .front_running_avoidance import FrontRunningAvoidance, ExecutionPlan, MarketConditions
from .market_impact_predictor import MarketImpactPredictor
from .liquidity_analyzer import LiquidityAnalyzer
from .vwap_calculator import VWAPCalculator
from .market_making_detector import MarketMakingDetector
from .adversarial_detector import AdversarialDetector
from .iceberg_monitor import IcebergMonitor, IcebergAlert
from .iceberg_system import IcebergDetectionSystem, SystemConfiguration, DetectionResults

__version__ = "1.0.0"
__author__ = "Iceberg Detection System"

__all__ = [
    "OrderBookAnalyzer",
    "HiddenOrderDetector", 
    "IcebergEstimator",
    "FrontRunningAvoidance",
    "ExecutionPlan",
    "MarketConditions",
    "MarketImpactPredictor",
    "LiquidityAnalyzer",
    "VWAPCalculator",
    "MarketMakingDetector",
    "AdversarialDetector",
    "IcebergMonitor",
    "IcebergAlert",
    "IcebergDetectionSystem",
    "SystemConfiguration",
    "DetectionResults"
]