"""
Order Book Pattern Analyzer

Order book'taki deseni analiz ederek gizli büyük emirleri tespit eder.
Depth analizi, volume profiling ve momentum detection algoritmaları içerir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
import warnings
warnings.filterwarnings('ignore')


@dataclass
class OrderBookLevel:
    """Order book seviyesi bilgisi"""
    price: float
    size: float
    cumulative_size: float
    level_id: int


@dataclass
class BookPattern:
    """Tespit edilen pattern bilgisi"""
    pattern_type: str
    confidence: float
    strength: float
    volume_imbalance: float
    pressure_direction: str
    price_level: float


class OrderBookAnalyzer:
    """
    Order book pattern analizi yaparak gizli büyük emirleri tespit eder
    """
    
    def __init__(self, min_depth: int = 10, volume_threshold: float = 0.05):
        """
        Args:
            min_depth: Minimum incelenecek seviye sayısı
            volume_threshold: Volume imbalanced eşik değeri
        """
        self.min_depth = min_depth
        self.volume_threshold = volume_threshold
        self.book_history = []
        
    def analyze_order_book(self, bids: List[Tuple[float, float]], 
                          asks: List[Tuple[float, float]]) -> Dict:
        """
        Order book'u detaylı analiz eder
        
        Args:
            bids: [(price, size), ...] alış emirleri
            asks: [(price, size), ...] satış emirleri
            
        Returns:
            Analiz sonuçları
        """
        try:
            # Temel book bilgilerini çıkar
            mid_price = (bids[0][0] + asks[0][0]) / 2
            spread = asks[0][0] - bids[0][0]
            
            # Volume profilling
            bid_volume = np.sum([size for _, size in bids[:self.min_depth]])
            ask_volume = np.sum([size for _, size in asks[:self.min_depth]])
            
            # Volume imbalance analizi
            total_volume = bid_volume + ask_volume
            volume_imbalance = (bid_volume - ask_volume) / total_volume if total_volume > 0 else 0
            
            # Level-by-level analiz
            bid_levels = self._analyze_levels(bids, 'bid')
            ask_levels = self._analyze_levels(asks, 'ask')
            
            # Pattern tespiti
            patterns = self._detect_patterns(bid_levels, ask_levels, mid_price)
            
            # Momentum hesaplama
            momentum = self._calculate_momentum(bid_levels, ask_levels)
            
            # Market depth assessment
            depth_quality = self._assess_depth_quality(bid_levels, ask_levels)
            
            return {
                'mid_price': mid_price,
                'spread': spread,
                'spread_percentage': spread / mid_price,
                'bid_volume': bid_volume,
                'ask_volume': ask_volume,
                'volume_imbalance': volume_imbalance,
                'total_volume': total_volume,
                'bid_levels': bid_levels,
                'ask_levels': ask_levels,
                'patterns': patterns,
                'momentum': momentum,
                'depth_quality': depth_quality,
                'timestamp': pd.Timestamp.now()
            }
            
        except Exception as e:
            print(f"Order book analiz hatası: {e}")
            return {}
    
    def _analyze_levels(self, levels: List[Tuple[float, float]], 
                       side: str) -> List[OrderBookLevel]:
        """Her seviyeyi detaylı analiz eder"""
        analyzed_levels = []
        cumulative_size = 0
        
        for i, (price, size) in enumerate(levels[:self.min_depth]):
            cumulative_size += size
            analyzed_levels.append(OrderBookLevel(
                price=price,
                size=size,
                cumulative_size=cumulative_size,
                level_id=i
            ))
            
        return analyzed_levels
    
    def _detect_patterns(self, bid_levels: List[OrderBookLevel], 
                        ask_levels: List[OrderBookLevel], 
                        mid_price: float) -> List[BookPattern]:
        """Order book'ta pattern tespiti yapar"""
        patterns = []
        
        # Wall detection (büyük emir duvarı)
        wall_patterns = self._detect_walls(bid_levels, ask_levels, mid_price)
        patterns.extend(wall_patterns)
        
        # Depth clustering
        clustering_patterns = self._detect_clustering(bid_levels, ask_levels)
        patterns.extend(clustering_patterns)
        
        # Iceberg indicator
        iceberg_patterns = self._detect_iceberg_indicators(bid_levels, ask_levels)
        patterns.extend(iceberg_patterns)
        
        return patterns
    
    def _detect_walls(self, bid_levels: List[OrderBookLevel], 
                     ask_levels: List[OrderBookLevel], 
                     mid_price: float) -> List[BookPattern]:
        """Büyük emir duvarlarını tespit eder"""
        patterns = []
        
        # Bid wall detection
        for i in range(1, len(bid_levels)):
            current_size = bid_levels[i].size
            prev_sizes = [level.size for level in bid_levels[:i]]
            
            if len(prev_sizes) > 0:
                avg_size = np.mean(prev_sizes)
                if current_size > avg_size * 3:  # 3x ortalama
                    patterns.append(BookPattern(
                        pattern_type="bid_wall",
                        confidence=min(current_size / avg_size * 0.3, 1.0),
                        strength=current_size / avg_size,
                        volume_imbalance=current_size,
                        pressure_direction="bullish",
                        price_level=bid_levels[i].price
                    ))
        
        # Ask wall detection
        for i in range(1, len(ask_levels)):
            current_size = ask_levels[i].size
            prev_sizes = [level.size for level in ask_levels[:i]]
            
            if len(prev_sizes) > 0:
                avg_size = np.mean(prev_sizes)
                if current_size > avg_size * 3:
                    patterns.append(BookPattern(
                        pattern_type="ask_wall",
                        confidence=min(current_size / avg_size * 0.3, 1.0),
                        strength=current_size / avg_size,
                        volume_imbalance=current_size,
                        pressure_direction="bearish",
                        price_level=ask_levels[i].price
                    ))
        
        return patterns
    
    def _detect_clustering(self, bid_levels: List[OrderBookLevel], 
                          ask_levels: List[OrderBookLevel]) -> List[BookPattern]:
        """Volume clustering pattern'lerini tespit eder"""
        patterns = []
        
        # Her iki taraf için clustering kontrolü
        for levels, side in [(bid_levels, 'bid'), (ask_levels, 'ask')]:
            if len(levels) < 3:
                continue
                
            # Consecutive levels analysis
            consecutive_large = 0
            for i in range(1, len(levels)):
                if levels[i].size > levels[i-1].size * 1.5:
                    consecutive_large += 1
                else:
                    consecutive_large = 0
                
                if consecutive_large >= 2:  # 2 ardışık büyük emir
                    patterns.append(BookPattern(
                        pattern_type=f"{side}_clustering",
                        confidence=0.7,
                        strength=consecutive_large,
                        volume_imbalance=levels[i].size,
                        pressure_direction="bullish" if side == "bid" else "bearish",
                        price_level=levels[i].price
                    ))
                    break
        
        return patterns
    
    def _detect_iceberg_indicators(self, bid_levels: List[OrderBookLevel], 
                                  ask_levels: List[OrderBookLevel]) -> List[BookPattern]:
        """Iceberg göstergelerini tespit eder"""
        patterns = []
        
        # Regular patterns that suggest hidden orders
        for levels, side in [(bid_levels, 'bid'), (ask_levels, 'ask')]:
            if len(levels) < 4:
                continue
            
            # Very similar sizes (iceberg indicator)
            sizes = [level.size for level in levels[:4]]
            size_variance = np.var(sizes)
            size_mean = np.mean(sizes)
            
            if size_variance < (size_mean * 0.1) and size_mean > 0:
                patterns.append(BookPattern(
                    pattern_type=f"{side}_iceberg_indicator",
                    confidence=0.6,
                    strength=1.0,
                    volume_imbalance=size_mean * len(levels),
                    pressure_direction="bullish" if side == "bid" else "bearish",
                    price_level=levels[0].price
                ))
        
        return patterns
    
    def _calculate_momentum(self, bid_levels: List[OrderBookLevel], 
                           ask_levels: List[OrderBookLevel]) -> Dict:
        """Order book momentum'unu hesaplar"""
        try:
            # Depth-weighted momentum
            bid_momentum = sum(level.size * (1 / (level.level_id + 1)) 
                             for level in bid_levels)
            ask_momentum = sum(level.size * (1 / (level.level_id + 1)) 
                             for level in ask_levels)
            
            total_momentum = bid_momentum + ask_momentum
            
            return {
                'bid_momentum': bid_momentum,
                'ask_momentum': ask_momentum,
                'net_momentum': (bid_momentum - ask_momentum) / total_momentum if total_momentum > 0 else 0,
                'momentum_intensity': total_momentum
            }
        except Exception:
            return {'bid_momentum': 0, 'ask_momentum': 0, 'net_momentum': 0, 'momentum_intensity': 0}
    
    def _assess_depth_quality(self, bid_levels: List[OrderBookLevel], 
                             ask_levels: List[OrderBookLevel]) -> Dict:
        """Market depth kalitesini değerlendirir"""
        try:
            # Depth consistency
            bid_consistency = np.mean([level.size for level in bid_levels])
            ask_consistency = np.mean([level.size for level in ask_levels])
            
            # Depth distribution
            bid_skew = self._calculate_skew([level.size for level in bid_levels])
            ask_skew = self._calculate_skew([level.size for level in ask_levels])
            
            # Overall quality score
            quality_score = 1.0 - min(abs(bid_skew) + abs(ask_skew), 1.0)
            
            return {
                'bid_consistency': bid_consistency,
                'ask_consistency': ask_consistency,
                'bid_skew': bid_skew,
                'ask_skew': ask_skew,
                'quality_score': quality_score,
                'depth_score': (bid_consistency + ask_consistency) / 2
            }
        except Exception:
            return {'bid_consistency': 0, 'ask_consistency': 0, 'bid_skew': 0, 'ask_skew': 0, 'quality_score': 0, 'depth_score': 0}
    
    def _calculate_skew(self, data: List[float]) -> float:
        """Distribution skewness hesaplar"""
        try:
            if len(data) < 2:
                return 0
            
            mean_val = np.mean(data)
            std_val = np.std(data)
            
            if std_val == 0:
                return 0
            
            skew = np.mean([(x - mean_val) ** 3 for x in data]) / (std_val ** 3)
            return skew
        except Exception:
            return 0
    
    def get_historical_analysis(self) -> Dict:
        """Geçmiş analiz sonuçlarını getirir"""
        return {
            'total_analyses': len(self.book_history),
            'patterns_detected': sum(len(analysis.get('patterns', [])) 
                                   for analysis in self.book_history),
            'avg_volume_imbalance': np.mean([analysis.get('volume_imbalance', 0) 
                                           for analysis in self.book_history]) if self.book_history else 0
        }
    
    def clear_history(self):
        """Analiz geçmişini temizler"""
        self.book_history = []