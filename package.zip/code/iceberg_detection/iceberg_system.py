"""
Iceberg Detection System

Tüm iceberg detection bileşenlerini birleştiren ana sistem.
Order book analysis, hidden order detection, size estimation ve real-time monitoring.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass, field
from collections import deque
import logging
import json
from datetime import datetime, timedelta

# Import all components
from .order_book_analyzer import OrderBookAnalyzer, OrderBookLevel, BookPattern
from .hidden_order_detector import HiddenOrderDetector, HiddenOrderSignal, OrderFlowAnalysis
from .iceberg_estimator import IcebergEstimator, IcebergEstimation
from .front_running_avoidance import FrontRunningAvoidance, ExecutionPlan, MarketConditions
from .market_impact_predictor import MarketImpactPredictor, ImpactPrediction, MarketState
from .liquidity_analyzer import LiquidityAnalyzer, LiquidityMetrics, LiquidityProfile
from .vwap_calculator import VWAPCalculator, VWAPCalculation, ExecutionBenchmark
from .market_making_detector import MarketMakingDetector, MarketMakingPattern
from .adversarial_detector import AdversarialDetector, AdversarialSignal
from .iceberg_monitor import IcebergMonitor, IcebergAlert, RealTimeMetrics

import warnings
warnings.filterwarnings('ignore')


@dataclass
class SystemConfiguration:
    """Sistem konfigürasyonu"""
    detection_sensitivity: float = 0.7  # 0-1, higher = more sensitive
    min_iceberg_size: float = 1000  # Minimum iceberg size to detect
    max_processing_time: float = 5.0  # Maximum processing time per cycle (seconds)
    enable_real_time_monitoring: bool = True
    enable_adversarial_detection: bool = True
    enable_market_impact_prediction: bool = True
    alert_channels: List[str] = field(default_factory=lambda: ["console", "file"])
    data_retention_hours: int = 24
    benchmark_window: int = 100


@dataclass
class DetectionResults:
    """Tespit sonuçları"""
    timestamp: pd.Timestamp
    order_book_analysis: Dict
    hidden_orders: List[HiddenOrderSignal]
    iceberg_estimates: List[IcebergEstimation]
    market_impact_predictions: List[ImpactPrediction]
    adversarial_signals: List[AdversarialSignal]
    market_making_patterns: List[MarketMakingPattern]
    vwap_analysis: Optional[VWAPCalculation]
    liquidity_metrics: LiquidityMetrics
    overall_confidence: float
    risk_level: str
    recommendations: List[str]


class IcebergDetectionSystem:
    """
    Ana iceberg detection sistemi
    """
    
    def __init__(self, config: SystemConfiguration = None):
        """
        Args:
            config: Sistem konfigürasyonu
        """
        self.config = config or SystemConfiguration()
        
        # Initialize all components
        self.order_book_analyzer = OrderBookAnalyzer()
        self.hidden_order_detector = HiddenOrderDetector()
        self.iceberg_estimator = IcebergEstimator()
        self.front_running_avoidance = FrontRunningAvoidance()
        self.market_impact_predictor = MarketImpactPredictor()
        self.liquidity_analyzer = LiquidityAnalyzer()
        self.vwap_calculator = VWAPCalculator()
        self.market_making_detector = MarketMakingDetector()
        self.adversarial_detector = AdversarialDetector()
        
        # Real-time monitoring
        if self.config.enable_real_time_monitoring:
            self.monitor = IcebergMonitor(alert_callback=self._handle_alert)
        else:
            self.monitor = None
        
        # Data storage
        self.detection_history = deque(maxlen=1000)
        self.current_session_id = None
        
        # Logging
        self.logger = self._setup_logging()
        
        # Performance tracking
        self.performance_metrics = {
            'total_detections': 0,
            'false_positives': 0,
            'processing_times': deque(maxlen=100),
            'accuracy_rate': 0.0
        }
        
        self.logger.info("Iceberg Detection System initialized")
    
    def analyze_market_data(self, 
                          bids: List[Tuple[float, float]],
                          asks: List[Tuple[float, float]], 
                          trades: List[Tuple[float, float, pd.Timestamp]],
                          orders: List[Dict] = None,
                          quotes: List[Dict] = None) -> DetectionResults:
        """
        Market verilerini analiz eder ve iceberg'ları tespit eder
        
        Args:
            bids: Alış emirleri [(price, size), ...]
            asks: Satış emirleri [(price, size), ...]
            trades: İşlemler [(price, size, timestamp), ...]
            orders: Emirler (optional)
            quotes: Kotasyonlar (optional)
            
        Returns:
            Detaylı tespit sonuçları
        """
        start_time = datetime.now()
        
        try:
            self.logger.info("Starting market data analysis")
            
            # Step 1: Order book analysis
            book_analysis = self.order_book_analyzer.analyze_order_book(bids, asks)
            
            # Step 2: Hidden order detection
            if trades:
                current_price = trades[-1][0] if trades else (bids[0][0] + asks[0][0]) / 2
                volume = sum(size for _, size, _ in trades[-10:])  # Last 10 trades
                
                hidden_orders = self.hidden_order_detector.detect_hidden_orders(
                    current_price, volume, trades
                )
            else:
                hidden_orders = []
            
            # Step 3: Iceberg size estimation
            iceberg_estimates = []
            for hidden_order in hidden_orders:
                if hidden_order.estimated_size >= self.config.min_iceberg_size:
                    estimation = self.iceberg_estimator.estimate_iceberg_size(
                        [(current_price, hidden_order.estimated_size)],
                        book_analysis,
                        [(trade[0], trade[1], trade[2]) for trade in trades[-20:]]
                    )
                    iceberg_estimates.append(estimation)
            
            # Step 4: Market impact prediction
            market_impact_predictions = []
            if self.config.enable_market_impact_prediction and iceberg_estimates:
                for estimate in iceberg_estimates:
                    if estimate.confidence_score >= self.config.detection_sensitivity:
                        market_state = self._create_market_state(book_analysis, trades)
                        
                        impact_prediction = self.market_impact_predictor.predict_market_impact(
                            estimate.estimated_size,
                            current_price,
                            market_state,
                            [0.2, 0.4, 0.6, 0.8, 1.0]  # Execution timeline
                        )
                        market_impact_predictions.append(impact_prediction)
            
            # Step 5: Liquidity analysis
            liquidity_metrics = self.liquidity_analyzer.analyze_liquidity(bids, asks)
            
            # Step 6: VWAP analysis
            vwap_analysis = None
            if trades:
                vwap_analysis = self.vwap_calculator.calculate_vwap(trades, "session")
            
            # Step 7: Market making detection
            market_making_patterns = []
            if quotes:
                market_making_patterns = self.market_making_detector.detect_market_making_behavior(
                    quotes, trades
                )
            
            # Step 8: Adversarial trading detection
            adversarial_signals = []
            if self.config.enable_adversarial_detection and orders:
                adversarial_signals = self.adversarial_detector.detect_adversarial_patterns(
                    orders, quotes or [], trades
                )
            
            # Step 9: Overall confidence calculation
            overall_confidence = self._calculate_overall_confidence(
                book_analysis, hidden_orders, iceberg_estimates, 
                market_impact_predictions, adversarial_signals
            )
            
            # Step 10: Risk level assessment
            risk_level = self._assess_risk_level(
                overall_confidence, iceberg_estimates, adversarial_signals
            )
            
            # Step 11: Generate recommendations
            recommendations = self._generate_recommendations(
                iceberg_estimates, market_impact_predictions, 
                adversarial_signals, liquidity_metrics
            )
            
            # Create detection results
            results = DetectionResults(
                timestamp=pd.Timestamp.now(),
                order_book_analysis=book_analysis,
                hidden_orders=hidden_orders,
                iceberg_estimates=iceberg_estimates,
                market_impact_predictions=market_impact_predictions,
                adversarial_signals=adversarial_signals,
                market_making_patterns=market_making_patterns,
                vwap_analysis=vwap_analysis,
                liquidity_metrics=liquidity_metrics,
                overall_confidence=overall_confidence,
                risk_level=risk_level,
                recommendations=recommendations
            )
            
            # Store in history
            self.detection_history.append(results)
            
            # Update performance metrics
            processing_time = (datetime.now() - start_time).total_seconds()
            self.performance_metrics['processing_times'].append(processing_time)
            self.performance_metrics['total_detections'] += 1
            
            # Update monitor if enabled
            if self.monitor:
                self._update_monitoring_data(
                    bids, asks, trades, orders or [], 
                    quotes or [], iceberg_estimates
                )
            
            self.logger.info(f"Analysis completed in {processing_time:.2f}s, confidence: {overall_confidence:.3f}")
            
            return results
            
        except Exception as e:
            self.logger.error(f"Analysis error: {e}")
            return self._create_error_results(str(e))
    
    def create_execution_plan(self, 
                            iceberg_estimate: IcebergEstimation,
                            current_price: float,
                            urgency_level: float = 0.5) -> ExecutionPlan:
        """
        Iceberg için optimal execution planı oluşturur
        
        Args:
            iceberg_estimate: Iceberg boyut tahmini
            current_price: Mevcut fiyat
            urgency_level: Aciliyet seviyesi (0-1)
            
        Returns:
            Execution planı
        """
        try:
            # Create market conditions
            recent_analysis = self.detection_history[-1] if self.detection_history else None
            
            if recent_analysis:
                market_conditions = MarketConditions(
                    volatility=0.02,  # Default values
                    volume_profile={"high": 0.7, "medium": 0.3, "low": 0.1},
                    order_book_depth={"bid": recent_analysis.liquidity_metrics.bid_depth,
                                    "ask": recent_analysis.liquidity_metrics.ask_depth},
                    volatility_regime="medium",
                    liquidity_conditions="medium" if recent_analysis.liquidity_metrics.liquidity_score > 0.5 else "low",
                    risk_level=0.3
                )
            else:
                # Default market conditions
                market_conditions = MarketConditions(
                    volatility=0.02,
                    volume_profile={"high": 0.6, "medium": 0.3, "low": 0.1},
                    order_book_depth={"bid": 10000, "ask": 10000},
                    volatility_regime="medium",
                    liquidity_conditions="medium",
                    risk_level=0.3
                )
            
            # Create execution plan
            execution_plan = self.front_running_avoidance.create_stealth_execution_plan(
                order_size=iceberg_estimate.estimated_size,
                current_price=current_price,
                market_conditions=market_conditions,
                urgency_level=urgency_level
            )
            
            return execution_plan
            
        except Exception as e:
            self.logger.error(f"Execution plan creation error: {e}")
            return self._create_fallback_execution_plan(iceberg_estimate.estimated_size, current_price)
    
    def start_real_time_monitoring(self, session_name: str = "iceberg_detection") -> str:
        """Real-time monitoring'i başlatır"""
        try:
            if not self.monitor:
                self.logger.warning("Real-time monitoring is disabled in configuration")
                return ""
            
            self.current_session_id = self.monitor.start_monitoring(session_name)
            self.logger.info(f"Real-time monitoring started: {self.current_session_id}")
            
            return self.current_session_id
            
        except Exception as e:
            self.logger.error(f"Real-time monitoring start error: {e}")
            return ""
    
    def stop_real_time_monitoring(self) -> bool:
        """Real-time monitoring'i durdurur"""
        try:
            if not self.monitor or not self.current_session_id:
                return False
            
            success = self.monitor.stop_monitoring(self.current_session_id)
            if success:
                self.logger.info("Real-time monitoring stopped")
                self.current_session_id = None
            
            return success
            
        except Exception as e:
            self.logger.error(f"Real-time monitoring stop error: {e}")
            return False
    
    def get_system_statistics(self) -> Dict:
        """Sistem istatistiklerini getirir"""
        try:
            stats = {
                'system_info': {
                    'config': {
                        'detection_sensitivity': self.config.detection_sensitivity,
                        'min_iceberg_size': self.config.min_iceberg_size,
                        'real_time_monitoring': self.config.enable_real_time_monitoring,
                        'adversarial_detection': self.config.enable_adversarial_detection
                    },
                    'status': {
                        'monitoring_active': self.monitor and self.current_session_id is not None,
                        'detection_history_size': len(self.detection_history),
                        'session_id': self.current_session_id
                    }
                },
                'performance': {
                    'total_detections': self.performance_metrics['total_detections'],
                    'false_positives': self.performance_metrics['false_positives'],
                    'accuracy_rate': self.performance_metrics['accuracy_rate'],
                    'avg_processing_time': np.mean(self.performance_metrics['processing_times']) if self.performance_metrics['processing_times'] else 0,
                    'processing_time_std': np.std(self.performance_metrics['processing_times']) if self.performance_metrics['processing_times'] else 0
                },
                'detection_summary': self._get_detection_summary(),
                'component_status': self._get_component_status()
            }
            
            return stats
            
        except Exception as e:
            self.logger.error(f"System statistics error: {e}")
            return {}
    
    def export_detection_results(self, format_type: str = "json", 
                               time_range: str = "1h") -> str:
        """Tespit sonuçlarını export eder"""
        try:
            # Filter by time range
            end_time = pd.Timestamp.now()
            if time_range == "1h":
                start_time = end_time - timedelta(hours=1)
            elif time_range == "24h":
                start_time = end_time - timedelta(days=1)
            else:
                start_time = end_time - timedelta(hours=1)
            
            filtered_results = [
                result for result in self.detection_history
                if result.timestamp >= start_time
            ]
            
            # Convert to exportable format
            export_data = []
            for result in filtered_results:
                result_dict = {
                    'timestamp': result.timestamp.isoformat(),
                    'overall_confidence': result.overall_confidence,
                    'risk_level': result.risk_level,
                    'hidden_orders_count': len(result.hidden_orders),
                    'iceberg_estimates_count': len(result.iceberg_estimates),
                    'adversarial_signals_count': len(result.adversarial_signals),
                    'liquidity_score': result.liquidity_metrics.liquidity_score,
                    'spread': result.liquidity_metrics.bid_ask_spread,
                    'recommendations_count': len(result.recommendations)
                }
                export_data.append(result_dict)
            
            if format_type.lower() == "json":
                return json.dumps(export_data, indent=2, default=str)
            else:
                # Could add other formats like CSV
                return json.dumps(export_data, indent=2, default=str)
                
        except Exception as e:
            self.logger.error(f"Export error: {e}")
            return ""
    
    def update_configuration(self, new_config: Dict) -> bool:
        """Sistem konfigürasyonunu günceller"""
        try:
            for key, value in new_config.items():
                if hasattr(self.config, key):
                    setattr(self.config, key, value)
                    self.logger.info(f"Updated configuration: {key} = {value}")
                else:
                    self.logger.warning(f"Unknown configuration key: {key}")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Configuration update error: {e}")
            return False
    
    def _setup_logging(self) -> logging.Logger:
        """Logging sistemi kurulumu"""
        logger = logging.getLogger("IcebergDetectionSystem")
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        return logger
    
    def _create_market_state(self, book_analysis: Dict, trades: List) -> MarketState:
        """Market state oluşturur"""
        try:
            liquidity_score = book_analysis.get('liquidity_metrics', LiquidityMetrics(
                0, 0, 0, 0, 0, 0, 0, 0
            )).liquidity_score
            
            return MarketState(
                volatility=0.02,  # Simplified
                liquidity_score=liquidity_score,
                volume_profile={"high": 0.6, "medium": 0.3, "low": 0.1},
                order_flow_imbalance=book_analysis.get('volume_imbalance', 0),
                momentum=book_analysis.get('momentum', {}).get('net_momentum', 0),
                mean_reversion_strength=0.3
            )
            
        except Exception:
            return MarketState(0.02, 0.5, {}, 0, 0, 0.3)
    
    def _calculate_overall_confidence(self, book_analysis: Dict, 
                                    hidden_orders: List[HiddenOrderSignal],
                                    iceberg_estimates: List[IcebergEstimation],
                                    market_impact_predictions: List[ImpactPrediction],
                                    adversarial_signals: List[AdversarialSignal]) -> float:
        """Genel güven skorunu hesaplar"""
        try:
            confidence_components = []
            
            # Order book confidence
            if book_analysis:
                book_confidence = min(book_analysis.get('liquidity_metrics', LiquidityMetrics(0, 0, 0, 0, 0, 0, 0, 0)).liquidity_score, 1.0)
                confidence_components.append(book_confidence)
            
            # Hidden order confidence
            if hidden_orders:
                avg_hidden_order_confidence = np.mean([order.confidence for order in hidden_orders])
                confidence_components.append(avg_hidden_order_confidence)
            
            # Iceberg estimate confidence
            if iceberg_estimates:
                avg_iceberg_confidence = np.mean([est.confidence_score for est in iceberg_estimates])
                confidence_components.append(avg_iceberg_confidence)
            
            # Market impact confidence
            if market_impact_predictions:
                avg_impact_confidence = np.mean([pred.confidence_score for pred in market_impact_predictions])
                confidence_components.append(avg_impact_confidence)
            
            # Adversarial signal confidence (negative impact on confidence)
            if adversarial_signals:
                adversarial_penalty = len(adversarial_signals) * 0.1
                confidence_components.append(max(0, 0.5 - adversarial_penalty))
            
            # Calculate overall confidence
            if confidence_components:
                overall_confidence = np.mean(confidence_components)
            else:
                overall_confidence = 0.0
            
            return min(overall_confidence, 1.0)
            
        except Exception:
            return 0.0
    
    def _assess_risk_level(self, overall_confidence: float,
                         iceberg_estimates: List[IcebergEstimation],
                         adversarial_signals: List[AdversarialSignal]) -> str:
        """Risk seviyesini değerlendirir"""
        try:
            # High risk factors
            high_risk_count = 0
            
            if overall_confidence > 0.8:
                high_risk_count += 1
            
            if iceberg_estimates:
                large_icebergs = [est for est in iceberg_estimates if est.estimated_size > 5000]
                if large_icebergs:
                    high_risk_count += 1
            
            if adversarial_signals:
                high_confidence_adversarial = [sig for sig in adversarial_signals if sig.confidence > 0.7]
                if high_confidence_adversarial:
                    high_risk_count += 1
            
            # Risk classification
            if high_risk_count >= 3:
                return "critical"
            elif high_risk_count >= 2:
                return "high"
            elif high_risk_count >= 1:
                return "medium"
            else:
                return "low"
                
        except Exception:
            return "unknown"
    
    def _generate_recommendations(self, iceberg_estimates: List[IcebergEstimation],
                                market_impact_predictions: List[ImpactPrediction],
                                adversarial_signals: List[AdversarialSignal],
                                liquidity_metrics: LiquidityMetrics) -> List[str]:
        """Öneriler oluşturur"""
        recommendations = []
        
        try:
            # Iceberg recommendations
            if iceberg_estimates:
                largest_iceberg = max(iceberg_estimates, key=lambda x: x.estimated_size)
                if largest_iceberg.estimated_size > 10000:
                    recommendations.append(f"Large iceberg detected: {largest_iceberg.estimated_size:.0f} units - Consider position adjustment")
                
                if largest_iceberg.confidence_score > 0.8:
                    recommendations.append("High confidence iceberg detection - Monitor execution closely")
            
            # Market impact recommendations
            if market_impact_predictions:
                significant_impacts = [pred for pred in market_impact_predictions if pred.immediate_impact > 0.02]
                if significant_impacts:
                    recommendations.append("Significant market impact predicted - Consider timing adjustments")
            
            # Adversarial trading recommendations
            if adversarial_signals:
                front_running_signals = [sig for sig in adversarial_signals if 'front_run' in sig.signal_type]
                if front_running_signals:
                    recommendations.append("Front-running detected - Implement order protection measures")
            
            # Liquidity recommendations
            if liquidity_metrics.liquidity_score < 0.3:
                recommendations.append("Low liquidity conditions - Reduce position sizes")
            
            # Default recommendations if none generated
            if not recommendations:
                recommendations.append("Monitor market conditions for iceberg activity")
                recommendations.append("Maintain standard risk management protocols")
            
            return recommendations
            
        except Exception:
            return ["Error generating recommendations"]
    
    def _create_error_results(self, error_message: str) -> DetectionResults:
        """Hata durumu için default results oluşturur"""
        return DetectionResults(
            timestamp=pd.Timestamp.now(),
            order_book_analysis={},
            hidden_orders=[],
            iceberg_estimates=[],
            market_impact_predictions=[],
            adversarial_signals=[],
            market_making_patterns=[],
            vwap_analysis=None,
            liquidity_metrics=LiquidityMetrics(0, 0, 0, 0, 0, 0, 0, 0),
            overall_confidence=0.0,
            risk_level="unknown",
            recommendations=[f"System error occurred: {error_message}"]
        )
    
    def _create_fallback_execution_plan(self, order_size: float, current_price: float) -> ExecutionPlan:
        """Hata durumu için fallback execution plan"""
        from .front_running_avoidance import OrderType
        
        return ExecutionPlan(
            strategy_type=OrderType.MARKET,
            total_size=order_size,
            split_count=1,
            timing_intervals=[0],
            price_levels=[current_price],
            stealth_factor=0.3,
            estimated_slippage=0.01,
            front_run_risk=0.9
        )
    
    def _handle_alert(self, alert: IcebergAlert):
        """Alert handling callback"""
        try:
            self.logger.warning(f"ICEBERG ALERT [{alert.priority.upper()}]: {alert.message}")
            
            # Could add additional alert handling here
            # e.g., send to external systems, trigger webhooks, etc.
            
        except Exception as e:
            self.logger.error(f"Alert handling error: {e}")
    
    def _update_monitoring_data(self, bids: List, asks: List, trades: List,
                              orders: List, quotes: List, iceberg_estimates: List):
        """Monitoring verilerini günceller"""
        try:
            if not self.monitor:
                return
            
            # Update order data
            for order in orders:
                self.monitor.add_order_data(order)
            
            # Update trade data
            for trade in trades:
                trade_dict = {
                    'price': trade[0],
                    'size': trade[1],
                    'timestamp': trade[2] if len(trade) > 2 else pd.Timestamp.now(),
                    'side': 'buy' if trade[1] > 0 else 'sell'
                }
                self.monitor.add_trade_data(trade_dict)
            
            # Update quote data
            for quote in quotes:
                self.monitor.add_quote_data(quote)
                
        except Exception as e:
            self.logger.error(f"Monitoring data update error: {e}")
    
    def _get_detection_summary(self) -> Dict:
        """Tespit özetini getirir"""
        try:
            if not self.detection_history:
                return {}
            
            recent_results = list(self.detection_history)[-20:]  # Last 20 results
            
            return {
                'avg_confidence': np.mean([r.overall_confidence for r in recent_results]),
                'avg_icebergs_per_analysis': np.mean([len(r.iceberg_estimates) for r in recent_results]),
                'avg_adversarial_signals': np.mean([len(r.adversarial_signals) for r in recent_results]),
                'risk_distribution': self._calculate_risk_distribution(recent_results),
                'detection_trend': self._calculate_detection_trend(recent_results)
            }
            
        except Exception as e:
            self.logger.error(f"Detection summary error: {e}")
            return {}
    
    def _calculate_risk_distribution(self, results: List[DetectionResults]) -> Dict:
        """Risk dağılımını hesaplar"""
        risk_counts = {"low": 0, "medium": 0, "high": 0, "critical": 0, "unknown": 0}
        for result in results:
            risk_counts[result.risk_level] = risk_counts.get(result.risk_level, 0) + 1
        
        total = len(results)
        return {risk: count/total for risk, count in risk_counts.items() if count > 0}
    
    def _calculate_detection_trend(self, results: List[DetectionResults]) -> str:
        """Tespit trendini hesaplar"""
        try:
            if len(results) < 10:
                return "insufficient_data"
            
            first_half = results[:len(results)//2]
            second_half = results[len(results)//2:]
            
            first_avg_confidence = np.mean([r.overall_confidence for r in first_half])
            second_avg_confidence = np.mean([r.overall_confidence for r in second_half])
            
            if second_avg_confidence > first_avg_confidence * 1.1:
                return "increasing"
            elif second_avg_confidence < first_avg_confidence * 0.9:
                return "decreasing"
            else:
                return "stable"
                
        except Exception:
            return "unknown"
    
    def _get_component_status(self) -> Dict:
        """Bileşen durumunu getirir"""
        try:
            return {
                'order_book_analyzer': 'active',
                'hidden_order_detector': 'active',
                'iceberg_estimator': 'active',
                'front_running_avoidance': 'active',
                'market_impact_predictor': 'active' if self.config.enable_market_impact_prediction else 'disabled',
                'liquidity_analyzer': 'active',
                'vwap_calculator': 'active',
                'market_making_detector': 'active',
                'adversarial_detector': 'active' if self.config.enable_adversarial_detection else 'disabled',
                'iceberg_monitor': 'active' if self.monitor and self.current_session_id else 'inactive'
            }
            
        except Exception as e:
            self.logger.error(f"Component status error: {e}")
            return {}
    
    def shutdown(self):
        """Sistem kapatma"""
        try:
            self.logger.info("Shutting down Iceberg Detection System")
            
            # Stop monitoring if active
            if self.current_session_id:
                self.stop_real_time_monitoring()
            
            # Log final statistics
            final_stats = self.get_system_statistics()
            self.logger.info(f"Final statistics: {final_stats}")
            
        except Exception as e:
            self.logger.error(f"Shutdown error: {e}")