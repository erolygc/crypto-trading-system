"""
Market Making Detector

Market making davranışını tespit eden sistem.
Bid-ask spread patterns, quote stability ve inventory management analizi içerir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import deque, defaultdict
import math
from scipy import stats
import warnings
warnings.filterwarnings('ignore')


@dataclass
class MarketMakerProfile:
    """Market maker profil bilgisi"""
    maker_id: str
    avg_spread: float
    spread_consistency: float
    inventory_management_score: float
    quote_renewal_rate: float
    profitability_estimate: float
    activity_level: str
    risk_tolerance: str


@dataclass
class MarketMakingPattern:
    """Market making pattern tespiti"""
    pattern_type: str  # "aggressive", "passive", "inventory_based"
    confidence: float
    spread_patterns: List[float]
    renewal_frequency: float
    inventory_correlation: float
    market_impact_score: float


class MarketMakingDetector:
    """
    Market making davranış tespit sistemi
    """
    
    def __init__(self, min_quote_count: int = 50, spread_window: int = 20):
        """
        Args:
            min_quote_count: Minimum quote sayısı
            spread_window: Spread analiz penceresi
        """
        self.min_quote_count = min_quote_count
        self.spread_window = spread_window
        self.quote_history = deque(maxlen=1000)
        self.spread_history = deque(maxlen=spread_window)
        self.maker_profiles = {}
        
    def detect_market_making_behavior(self, quotes: List[Dict], 
                                    trades: List[Dict]) -> List[MarketMakingPattern]:
        """
        Market making davranışını tespit eder
        
        Args:
            quotes: Quote verileri
            trades: Trade verileri
            
        Returns:
            Tespit edilen pattern'ler
        """
        try:
            patterns = []
            
            # Update quote history
            self._update_quote_history(quotes)
            
            if len(self.quote_history) < self.min_quote_count:
                return patterns
            
            # Pattern 1: Quote renewal analysis
            renewal_patterns = self._detect_quote_renewal_pattern()
            patterns.extend(renewal_patterns)
            
            # Pattern 2: Spread consistency analysis
            spread_patterns = self._detect_spread_consistency()
            patterns.extend(spread_patterns)
            
            # Pattern 3: Inventory management patterns
            inventory_patterns = self._detect_inventory_management(quotes, trades)
            patterns.extend(inventory_patterns)
            
            # Pattern 4: Passive vs Aggressive behavior
            behavior_patterns = self._detect_behavior_patterns(quotes)
            patterns.extend(behavior_patterns)
            
            # Pattern 5: Market making with iceberg interaction
            iceberg_patterns = self._detect_market_maker_iceberg_interaction(quotes)
            patterns.extend(iceberg_patterns)
            
            return patterns
            
        except Exception as e:
            print(f"Market making tespit hatası: {e}")
            return []
    
    def _update_quote_history(self, quotes: List[Dict]):
        """Quote geçmişini günceller"""
        try:
            for quote in quotes:
                quote_record = {
                    'timestamp': pd.Timestamp.now(),
                    'bid_price': quote.get('bid_price', 0),
                    'ask_price': quote.get('ask_price', 0),
                    'bid_size': quote.get('bid_size', 0),
                    'ask_size': quote.get('ask_size', 0),
                    'maker_id': quote.get('maker_id', 'unknown')
                }
                self.quote_history.append(quote_record)
                
        except Exception as e:
            print(f"Quote geçmişi güncelleme hatası: {e}")
    
    def _detect_quote_renewal_pattern(self) -> List[MarketMakingPattern]:
        """Quote yenileme pattern'lerini tespit eder"""
        patterns = []
        
        try:
            if len(self.quote_history) < 20:
                return patterns
            
            recent_quotes = list(self.quote_history)[-50:]  # Last 50 quotes
            
            # Group by maker
            maker_quotes = defaultdict(list)
            for quote in recent_quotes:
                maker_quotes[quote['maker_id']].append(quote)
            
            for maker_id, quotes in maker_quotes.items():
                if len(quotes) < 5:
                    continue
                
                # Analyze renewal frequency
                timestamps = [q['timestamp'] for q in quotes]
                time_diffs = [(timestamps[i] - timestamps[i-1]).total_seconds() 
                             for i in range(1, len(timestamps))]
                
                avg_renewal_time = np.mean(time_diffs) if time_diffs else 0
                renewal_consistency = 1 - (np.std(time_diffs) / np.mean(time_diffs)) if time_diffs and np.mean(time_diffs) > 0 else 0
                
                # High frequency renewal with consistency indicates market making
                if avg_renewal_time > 0 and avg_renewal_time < 10 and renewal_consistency > 0.7:
                    patterns.append(MarketMakingPattern(
                        pattern_type="high_frequency_renewal",
                        confidence=renewal_consistency,
                        spread_patterns=[],
                        renewal_frequency=1 / avg_renewal_time,
                        inventory_correlation=0,
                        market_impact_score=0
                    ))
        
        except Exception as e:
            print(f"Quote renewal pattern tespit hatası: {e}")
        
        return patterns
    
    def _detect_spread_consistency(self) -> List[MarketMakingPattern]:
        """Spread tutarlılığı pattern'lerini tespit eder"""
        patterns = []
        
        try:
            if len(self.quote_history) < 30:
                return patterns
            
            # Calculate spreads
            spreads = []
            for quote in self.quote_history:
                if quote['bid_price'] > 0 and quote['ask_price'] > 0:
                    spread = quote['ask_price'] - quote['bid_price']
                    spreads.append(spread)
            
            if len(spreads) < 10:
                return patterns
            
            # Analyze spread consistency
            spread_std = np.std(spreads)
            spread_mean = np.mean(spreads)
            spread_cv = spread_std / spread_mean if spread_mean > 0 else float('inf')
            
            # Low coefficient of variation indicates market making
            if spread_cv < 0.1:  # Very consistent spreads
                confidence = 1 - min(spread_cv, 0.2)
                patterns.append(MarketMakingPattern(
                    pattern_type="consistent_spreads",
                    confidence=confidence,
                    spread_patterns=spreads[-20:],
                    renewal_frequency=0,
                    inventory_correlation=0,
                    market_impact_score=0
                ))
            
            # Detect spread widening/narrowing patterns
            spread_trend = self._analyze_spread_trend(spreads)
            if abs(spread_trend) > 0.001:
                patterns.append(MarketMakingPattern(
                    pattern_type="dynamic_spread_management",
                    confidence=min(abs(spread_trend) * 100, 1.0),
                    spread_patterns=spreads[-20:],
                    renewal_frequency=0,
                    inventory_correlation=0,
                    market_impact_score=abs(spread_trend)
                ))
        
        except Exception as e:
            print(f"Spread consistency pattern tespit hatası: {e}")
        
        return patterns
    
    def _analyze_spread_trend(self, spreads: List[float]) -> float:
        """Spread trend analizi"""
        try:
            if len(spreads) < 5:
                return 0
            
            # Simple linear trend
            x = np.arange(len(spreads))
            y = np.array(spreads)
            slope = np.polyfit(x, y, 1)[0]
            
            return slope
            
        except Exception:
            return 0
    
    def _detect_inventory_management(self, quotes: List[Dict], 
                                   trades: List[Dict]) -> List[MarketMakingPattern]:
        """Envanter yönetimi pattern'lerini tespit eder"""
        patterns = []
        
        try:
            if not quotes or not trades:
                return patterns
            
            # Analyze price adjustments after large trades
            large_trades = [trade for trade in trades if abs(trade.get('size', 0)) > 1000]
            
            if not large_trades:
                return patterns
            
            # For each large trade, check for quote adjustments
            inventory_adjustments = []
            
            for trade in large_trades:
                trade_time = pd.to_datetime(trade.get('timestamp', pd.Timestamp.now()))
                trade_price = trade.get('price', 0)
                trade_size = trade.get('size', 0)
                
                # Find quotes before and after trade
                before_quotes = [q for q in quotes if pd.to_datetime(q.get('timestamp', pd.Timestamp.now())) <= trade_time]
                after_quotes = [q for q in quotes if pd.to_datetime(q.get('timestamp', pd.Timestamp.now())) >= trade_time]
                
                if before_quotes and after_quotes:
                    # Check if quotes moved in response to trade
                    last_before_quote = max(before_quotes, key=lambda x: pd.to_datetime(x.get('timestamp', pd.Timestamp.now())))
                    first_after_quote = min(after_quotes, key=lambda x: pd.to_datetime(x.get('timestamp', pd.Timestamp.now())))
                    
                    # Price adjustment indicates inventory-based quoting
                    price_adjustment = abs(first_after_quote.get('mid_price', 0) - trade_price) / trade_price if trade_price > 0 else 0
                    
                    if price_adjustment > 0.001:  # 0.1% adjustment threshold
                        inventory_adjustments.append(price_adjustment)
            
            if inventory_adjustments:
                # Pattern detected if frequent adjustments
                adjustment_frequency = len(inventory_adjustments) / len(large_trades)
                
                if adjustment_frequency > 0.5:  # More than 50% of large trades trigger adjustments
                    avg_adjustment = np.mean(inventory_adjustments)
                    patterns.append(MarketMakingPattern(
                        pattern_type="inventory_management",
                        confidence=min(adjustment_frequency, 1.0),
                        spread_patterns=[],
                        renewal_frequency=0,
                        inventory_correlation=avg_adjustment,
                        market_impact_score=avg_adjustment
                    ))
        
        except Exception as e:
            print(f"Inventory management pattern tespit hatası: {e}")
        
        return patterns
    
    def _detect_behavior_patterns(self, quotes: List[Dict]) -> List[MarketMakingPattern]:
        """Davranış pattern'lerini tespit eder"""
        patterns = []
        
        try:
            if not quotes:
                return patterns
            
            # Analyze quote aggressiveness
            aggressive_quotes = 0
            passive_quotes = 0
            
            for quote in quotes:
                bid_price = quote.get('bid_price', 0)
                ask_price = quote.get('ask_price', 0)
                
                if bid_price > 0 and ask_price > 0:
                    mid_price = (bid_price + ask_price) / 2
                    spread_percentage = (ask_price - bid_price) / mid_price
                    
                    # Classify based on spread
                    if spread_percentage < 0.0001:  # Very tight spreads
                        aggressive_quotes += 1
                    elif spread_percentage < 0.0005:  # Moderate spreads
                        pass
                    else:  # Wide spreads
                        passive_quotes += 1
            
            total_quotes = aggressive_quotes + passive_quotes
            if total_quotes > 0:
                aggressive_ratio = aggressive_quotes / total_quotes
                
                if aggressive_ratio > 0.7:
                    patterns.append(MarketMakingPattern(
                        pattern_type="aggressive_market_making",
                        confidence=aggressive_ratio,
                        spread_patterns=[],
                        renewal_frequency=0,
                        inventory_correlation=0,
                        market_impact_score=0.8
                    ))
                elif passive_quotes > 0.7:
                    patterns.append(MarketMakingPattern(
                        pattern_type="passive_market_making",
                        confidence=passive_quotes / total_quotes,
                        spread_patterns=[],
                        renewal_frequency=0,
                        inventory_correlation=0,
                        market_impact_score=0.3
                    ))
        
        except Exception as e:
            print(f"Behavior pattern tespit hatası {e}")
        
        return patterns
    
    def _detect_market_maker_iceberg_interaction(self, quotes: List[Dict]) -> List[MarketMakingPattern]:
        """Market maker - iceberg etkileşimini tespit eder"""
        patterns = []
        
        try:
            if not quotes or len(quotes) < 10:
                return patterns
            
            # Detect quote patterns that suggest iceberg interaction
            quote_sizes = []
            price_changes = []
            
            for i in range(1, len(quotes)):
                current_quote = quotes[i]
                previous_quote = quotes[i-1]
                
                # Size consistency (iceberg indicator)
                current_size = (current_quote.get('bid_size', 0) + current_quote.get('ask_size', 0)) / 2
                previous_size = (previous_quote.get('bid_size', 0) + previous_quote.get('ask_size', 0)) / 2
                
                if current_size > 0 and previous_size > 0:
                    size_ratio = min(current_size, previous_size) / max(current_size, previous_size)
                    quote_sizes.append(size_ratio)
                
                # Price stability
                current_mid = (current_quote.get('bid_price', 0) + current_quote.get('ask_price', 0)) / 2
                previous_mid = (previous_quote.get('bid_price', 0) + previous_quote.get('ask_price', 0)) / 2
                
                if current_mid > 0 and previous_mid > 0:
                    price_change = abs(current_mid - previous_mid) / previous_mid
                    price_changes.append(price_change)
            
            # Analyze patterns
            if quote_sizes:
                avg_size_consistency = np.mean(quote_sizes)
                
                # Consistent sizes suggest iceberg market making
                if avg_size_consistency > 0.8:
                    patterns.append(MarketMakingPattern(
                        pattern_type="iceberg_market_making",
                        confidence=avg_size_consistency,
                        spread_patterns=[],
                        renewal_frequency=0,
                        inventory_correlation=0,
                        market_impact_score=0.2
                    ))
            
            if price_changes:
                avg_price_stability = 1 - np.mean(price_changes)
                
                # High price stability suggests professional market making
                if avg_price_stability > 0.95:
                    patterns.append(MarketMakingPattern(
                        pattern_type="stable_market_making",
                        confidence=avg_price_stability,
                        spread_patterns=[],
                        renewal_frequency=0,
                        inventory_correlation=0,
                        market_impact_score=0.1
                    ))
        
        except Exception as e:
            print(f"Market maker-iceberg interaction tespit hatası: {e}")
        
        return patterns
    
    def analyze_market_maker_profiles(self) -> Dict[str, MarketMakerProfile]:
        """Market maker profillerini analiz eder"""
        try:
            profiles = {}
            
            if not self.quote_history:
                return profiles
            
            # Group quotes by maker
            maker_data = defaultdict(list)
            for quote in self.quote_history:
                maker_data[quote['maker_id']].append(quote)
            
            for maker_id, quotes in maker_data.items():
                if len(quotes) < 5:
                    continue
                
                # Calculate metrics
                spreads = [(q['ask_price'] - q['bid_price']) for q in quotes 
                          if q['bid_price'] > 0 and q['ask_price'] > 0]
                
                if not spreads:
                    continue
                
                avg_spread = np.mean(spreads)
                spread_consistency = 1 - (np.std(spreads) / np.mean(spreads)) if np.mean(spreads) > 0 else 0
                
                # Quote renewal rate
                renewal_rate = len(quotes) / len(self.quote_history)
                
                # Activity level
                if renewal_rate > 0.1:
                    activity_level = "high"
                elif renewal_rate > 0.05:
                    activity_level = "medium"
                else:
                    activity_level = "low"
                
                profiles[maker_id] = MarketMakerProfile(
                    maker_id=maker_id,
                    avg_spread=avg_spread,
                    spread_consistency=max(0, spread_consistency),
                    inventory_management_score=0.7,  # Placeholder
                    quote_renewal_rate=renewal_rate,
                    profitability_estimate=avg_spread * renewal_rate,
                    activity_level=activity_level,
                    risk_tolerance="medium"  # Placeholder
                )
            
            return profiles
            
        except Exception as e:
            print(f"Market maker profil analiz hatası: {e}")
            return {}
    
    def detect_adversarial_market_making(self, quotes: List[Dict], 
                                       order_book: Dict) -> List[Dict]:
        """Adversarial market making tespiti"""
        try:
            adversarial_indicators = []
            
            # Pattern 1: Quote stacking
            stacked_quotes = self._detect_quote_stacking(quotes)
            if stacked_quotes['confidence'] > 0.7:
                adversarial_indicators.append({
                    'type': 'quote_stacking',
                    'confidence': stacked_quotes['confidence'],
                    'description': 'Multiple orders at same price level'
                })
            
            # Pattern 2: Front-running indicators
            front_run_indicators = self._detect_front_running_indicators(quotes, order_book)
            if front_run_indicators['confidence'] > 0.6:
                adversarial_indicators.append({
                    'type': 'potential_front_running',
                    'confidence': front_run_indicators['confidence'],
                    'description': 'Suspicious order timing patterns'
                })
            
            # Pattern 3: Quote manipulation
            manipulation_indicators = self._detect_quote_manipulation(quotes)
            if manipulation_indicators['confidence'] > 0.5:
                adversarial_indicators.append({
                    'type': 'quote_manipulation',
                    'confidence': manipulation_indicators['confidence'],
                    'description': 'Artificial quote inflation/deflation'
                })
            
            return adversarial_indicators
            
        except Exception as e:
            print(f"Adversarial market making tespit hatası: {e}")
            return []
    
    def _detect_quote_stacking(self, quotes: List[Dict]) -> Dict:
        """Quote stacking tespiti"""
        try:
            price_levels = defaultdict(int)
            
            for quote in quotes:
                # Count quotes at similar price levels
                price = quote.get('bid_price', 0)
                if price > 0:
                    price_rounded = round(price, 2)  # Round to nearest cent
                    price_levels[price_rounded] += 1
            
            max_stacking = max(price_levels.values()) if price_levels else 0
            total_quotes = len(quotes)
            
            stacking_ratio = max_stacking / total_quotes if total_quotes > 0 else 0
            
            return {
                'confidence': min(stacking_ratio, 1.0),
                'max_stacked_quotes': max_stacking,
                'stacked_price_levels': sum(1 for count in price_levels.values() if count > 3)
            }
            
        except Exception:
            return {'confidence': 0}
    
    def _detect_front_running_indicators(self, quotes: List[Dict], order_book: Dict) -> Dict:
        """Front-running göstergelerini tespit et"""
        try:
            # Very high frequency quote updates in specific conditions
            if len(quotes) < 10:
                return {'confidence': 0}
            
            # Check for quote updates just before large orders
            suspicious_timing = 0
            
            for i in range(1, len(quotes)):
                if i >= len(quotes):
                    break
                
                time_diff = abs((quotes[i].get('timestamp', pd.Timestamp.now()) - 
                               quotes[i-1].get('timestamp', pd.Timestamp.now())).total_seconds())
                
                # Very frequent updates
                if time_diff < 0.1:  # Less than 100ms
                    suspicious_timing += 1
            
            timing_ratio = suspicious_timing / len(quotes)
            
            return {
                'confidence': min(timing_ratio * 2, 1.0),  # Scale up the confidence
                'suspicious_updates': suspicious_timing
            }
            
        except Exception:
            return {'confidence': 0}
    
    def _detect_quote_manipulation(self, quotes: List[Dict]) -> Dict:
        """Quote manipulation tespiti"""
        try:
            if len(quotes) < 5:
                return {'confidence': 0}
            
            # Look for sudden large quote changes
            price_changes = []
            
            for i in range(1, len(quotes)):
                current_mid = (quotes[i].get('bid_price', 0) + quotes[i].get('ask_price', 0)) / 2
                previous_mid = (quotes[i-1].get('bid_price', 0) + quotes[i-1].get('ask_price', 0)) / 2
                
                if current_mid > 0 and previous_mid > 0:
                    price_change = abs(current_mid - previous_mid) / previous_mid
                    price_changes.append(price_change)
            
            if price_changes:
                # Large price jumps indicate manipulation
                large_jumps = sum(1 for change in price_changes if change > 0.001)  # 0.1% jumps
                manipulation_ratio = large_jumps / len(price_changes)
                
                return {
                    'confidence': min(manipulation_ratio, 1.0),
                    'large_jumps': large_jumps,
                    'total_changes': len(price_changes)
                }
            
            return {'confidence': 0}
            
        except Exception:
            return {'confidence': 0}
    
    def get_market_making_statistics(self) -> Dict:
        """Market making istatistiklerini getirir"""
        try:
            if not self.quote_history:
                return {}
            
            total_quotes = len(self.quote_history)
            unique_makers = len(set(q['maker_id'] for q in self.quote_history))
            
            return {
                'total_quotes': total_quotes,
                'unique_makers': unique_makers,
                'avg_quotes_per_maker': total_quotes / max(unique_makers, 1),
                'detected_patterns': len(self.spread_history),
                'analysis_coverage': min(total_quotes / self.min_quote_count, 1.0)
            }
            
        except Exception as e:
            print(f"Market making istatistik hatası: {e}")
            return {}
    
    def clear_history(self):
        """Geçmişi temizler"""
        self.quote_history.clear()
        self.spread_history.clear()
        self.maker_profiles.clear()