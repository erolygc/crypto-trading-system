"""
VWAP Calculator

Volume Weighted Average Price (VWAP) hesaplaması ve benchmark analizi.
Execution performansını VWAP'a göre değerlendirir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import deque
import math
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')


@dataclass
class VWAPCalculation:
    """VWAP hesaplama sonucu"""
    vwap_price: float
    total_volume: float
    calculation_period: str
    confidence_level: float
    volume_profile: Dict[str, float]  # Volume by time periods
    price_reliability: float


@dataclass
class ExecutionBenchmark:
    """Execution benchmark sonucu"""
    execution_vwap: float
    benchmark_vwap: float
    relative_performance: float  # positive = better than benchmark
    absolute_performance: float  # price difference
    volume_weighted_alpha: float
    benchmark_timing: str


class VWAPCalculator:
    """
    VWAP hesaplama ve benchmark analiz sistemi
    """
    
    def __init__(self, calculation_window: int = 100, rebalance_frequency: int = 60):
        """
        Args:
            calculation_window: VWAP hesaplama penceresi
            rebalance_frequency: Yeniden hesaplama frekansı (saniye)
        """
        self.calculation_window = calculation_window
        self.rebalance_frequency = rebalance_frequency
        self.price_volume_data = deque(maxlen=calculation_window)
        self.vwap_history = deque(maxlen=50)
        
    def calculate_vwap(self, price_volume_pairs: List[Tuple[float, float, pd.Timestamp]], 
                      period_type: str = "session") -> VWAPCalculation:
        """
        VWAP hesaplaması yapar
        
        Args:
            price_volume_pairs: [(price, volume, timestamp), ...]
            period_type: Hesaplama periyodu ("session", "hour", "custom")
            
        Returns:
            VWAP hesaplama sonucu
        """
        try:
            if not price_volume_pairs:
                return VWAPCalculation(0, 0, period_type, 0, {}, 0)
            
            # Filter data based on period
            filtered_data = self._filter_by_period(price_volume_pairs, period_type)
            
            if not filtered_data:
                return VWAPCalculation(0, 0, period_type, 0, {}, 0)
            
            # Calculate basic VWAP
            total_volume_weighted_price = sum(price * volume for price, volume, _ in filtered_data)
            total_volume = sum(volume for _, volume, _ in filtered_data)
            
            if total_volume == 0:
                return VWAPCalculation(0, 0, period_type, 0, {}, 0)
            
            vwap_price = total_volume_weighted_price / total_volume
            
            # Calculate confidence level based on volume distribution
            confidence_level = self._calculate_confidence_level(filtered_data)
            
            # Calculate price reliability
            price_reliability = self._calculate_price_reliability(filtered_data)
            
            # Create volume profile
            volume_profile = self._create_volume_profile(filtered_data)
            
            # Store in history
            vwap_result = VWAPCalculation(
                vwap_price=vwap_price,
                total_volume=total_volume,
                calculation_period=period_type,
                confidence_level=confidence_level,
                volume_profile=volume_profile,
                price_reliability=price_reliability
            )
            
            self.vwap_history.append(vwap_result)
            
            return vwap_result
            
        except Exception as e:
            print(f"VWAP hesaplama hatası: {e}")
            return VWAPCalculation(0, 0, period_type, 0, {}, 0)
    
    def calculate_execution_benchmark(self, execution_trades: List[Tuple[float, float, pd.Timestamp]], 
                                    benchmark_trades: List[Tuple[float, float, pd.Timestamp]],
                                    benchmark_type: str = "arrival") -> ExecutionBenchmark:
        """
        Execution'ı benchmark'a göre değerlendirir
        
        Args:
            execution_trades: Execution trade'leri
            benchmark_trades: Benchmark trade'leri  
            benchmark_type: Benchmark tipi ("arrival", "twap", "vwap")
            
        Returns:
            Execution benchmark sonucu
        """
        try:
            if not execution_trades or not benchmark_trades:
                return ExecutionBenchmark(0, 0, 0, 0, 0, "insufficient_data")
            
            # Calculate execution VWAP
            execution_vwap = self._calculate_simple_vwap(execution_trades)
            
            # Calculate benchmark VWAP
            if benchmark_type == "arrival":
                benchmark_vwap = self._calculate_arrival_price(execution_trades, benchmark_trades)
            elif benchmark_type == "twap":
                benchmark_vwap = self._calculate_twap_benchmark(benchmark_trades)
            else:  # vwap
                benchmark_vwap = self._calculate_simple_vwap(benchmark_trades)
            
            # Calculate performance metrics
            relative_performance = (benchmark_vwap - execution_vwap) / benchmark_vwap if benchmark_vwap != 0 else 0
            
            absolute_performance = execution_vwap - benchmark_vwap
            
            # Volume weighted alpha (risk-adjusted performance)
            execution_volume = sum(volume for _, volume, _ in execution_trades)
            benchmark_volume = sum(volume for _, volume, _ in benchmark_trades)
            
            volume_weighted_alpha = relative_performance * (execution_volume / benchmark_volume) if benchmark_volume > 0 else 0
            
            # Benchmark timing assessment
            benchmark_timing = self._assess_benchmark_timing(execution_trades, benchmark_trades, benchmark_type)
            
            return ExecutionBenchmark(
                execution_vwap=execution_vwap,
                benchmark_vwap=benchmark_vwap,
                relative_performance=relative_performance,
                absolute_performance=absolute_performance,
                volume_weighted_alpha=volume_weighted_alpha,
                benchmark_timing=benchmark_timing
            )
            
        except Exception as e:
            print(f"Execution benchmark hatası: {e}")
            return ExecutionBenchmark(0, 0, 0, 0, 0, "error")
    
    def _filter_by_period(self, data: List[Tuple[float, float, pd.Timestamp]], 
                         period_type: str) -> List[Tuple[float, float, pd.Timestamp]]:
        """Veriyi periyoda göre filtreler"""
        try:
            if not data:
                return data
            
            if period_type == "session":
                # Current trading session
                now = pd.Timestamp.now()
                session_start = now.replace(hour=9, minute=30, second=0, microsecond=0) if now.hour >= 9 else now - timedelta(days=1)
                return [(price, volume, ts) for price, volume, ts in data if ts >= session_start]
            
            elif period_type == "hour":
                # Last hour
                hour_ago = pd.Timestamp.now() - timedelta(hours=1)
                return [(price, volume, ts) for price, volume, ts in data if ts >= hour_ago]
            
            else:  # custom - return all data
                return data
                
        except Exception as e:
            print(f"Period filtreleme hatası: {e}")
            return data
    
    def _calculate_confidence_level(self, data: List[Tuple[float, float, pd.Timestamp]]) -> float:
        """VWAP güven seviyesini hesaplar"""
        try:
            if len(data) < 5:
                return 0.3
            
            volumes = [volume for _, volume, _ in data]
            
            # Volume concentration analysis
            total_volume = sum(volumes)
            volume_concentration = max(volumes) / total_volume if total_volume > 0 else 1
            
            # Price stability analysis
            prices = [price for price, _, _ in data]
            price_std = np.std(prices)
            price_mean = np.mean(prices)
            price_stability = 1 - (price_std / price_mean) if price_mean > 0 else 0
            
            # Data frequency analysis
            if len(data) > 1:
                timestamps = [ts for _, _, ts in data]
                time_diffs = [abs((timestamps[i] - timestamps[i-1]).total_seconds()) for i in range(1, len(timestamps))]
                avg_time_diff = np.mean(time_diffs) if time_diffs else 60
                frequency_score = min(1.0, 60 / max(avg_time_diff, 1))  # Higher score for more frequent data
            else:
                frequency_score = 0.5
            
            # Combine factors
            confidence_level = (
                (1 - volume_concentration) * 0.4 +  # Low concentration = higher confidence
                price_stability * 0.4 +              # High stability = higher confidence  
                frequency_score * 0.2               # High frequency = higher confidence
            )
            
            return max(0, min(confidence_level, 1.0))
            
        except Exception:
            return 0.5
    
    def _calculate_price_reliability(self, data: List[Tuple[float, float, pd.Timestamp]]) -> float:
        """Fiyat güvenilirliğini hesaplar"""
        try:
            if len(data) < 3:
                return 0.5
            
            # Check for outlier prices
            prices = [price for price, _, _ in data]
            mean_price = np.mean(prices)
            std_price = np.std(prices)
            
            # Count outliers (prices beyond 2 standard deviations)
            outliers = sum(1 for price in prices if abs(price - mean_price) > 2 * std_price)
            outlier_rate = outliers / len(prices)
            
            # Volume-weighted reliability (higher volume trades are more reliable)
            total_volume = sum(volume for _, volume, _ in data)
            volume_weighted_reliability = sum(
                (volume / total_volume) * (1 - min(abs(price - mean_price) / (2 * std_price), 1))
                for price, volume, _ in data
            ) if total_volume > 0 else 0.5
            
            # Combine metrics
            reliability = volume_weighted_reliability * (1 - outlier_rate)
            
            return max(0, min(reliability, 1.0))
            
        except Exception:
            return 0.5
    
    def _create_volume_profile(self, data: List[Tuple[float, float, pd.Timestamp]]) -> Dict[str, float]:
        """Volume profili oluşturur"""
        try:
            # Group volume by time periods
            volume_by_period = {
                'first_quarter': 0,
                'second_quarter': 0, 
                'third_quarter': 0,
                'fourth_quarter': 0,
                'total': 0
            }
            
            if not data:
                return volume_by_period
            
            total_volume = sum(volume for _, volume, _ in data)
            total_duration = max(ts for _, _, ts in data) - min(ts for _, _, ts in data)
            
            for price, volume, ts in data:
                # Calculate relative position in time
                start_time = min(ts for _, _, ts in data)
                relative_time = (ts - start_time).total_seconds()
                
                if total_duration.total_seconds() > 0:
                    quarter = int(4 * relative_time / total_duration.total_seconds())
                    quarter = min(quarter, 3)  # Cap at 3 (fourth quarter)
                    
                    quarter_key = ['first_quarter', 'second_quarter', 'third_quarter', 'fourth_quarter'][quarter]
                    volume_by_period[quarter_key] += volume
            
            volume_by_period['total'] = total_volume
            
            # Normalize to percentages
            if total_volume > 0:
                for key in volume_by_period:
                    if key != 'total':
                        volume_by_period[key] = volume_by_period[key] / total_volume
            
            return volume_by_period
            
        except Exception as e:
            print(f"Volume profil oluşturma hatası: {e}")
            return {'first_quarter': 0, 'second_quarter': 0, 'third_quarter': 0, 'fourth_quarter': 0, 'total': 0}
    
    def _calculate_simple_vwap(self, trades: List[Tuple[float, float, pd.Timestamp]]) -> float:
        """Basit VWAP hesaplama"""
        try:
            if not trades:
                return 0
            
            total_volume_weighted_price = sum(price * volume for price, volume, _ in trades)
            total_volume = sum(volume for _, volume, _ in trades)
            
            return total_volume_weighted_price / total_volume if total_volume > 0 else 0
            
        except Exception:
            return 0
    
    def _calculate_arrival_price(self, execution_trades: List[Tuple[float, float, pd.Timestamp]], 
                               benchmark_trades: List[Tuple[float, float, pd.Timestamp]]) -> float:
        """Arrival price benchmark hesaplama"""
        try:
            # Arrival price = first execution price (implementation shortfall benchmark)
            if execution_trades:
                return execution_trades[0][0]
            else:
                # Fallback to first available price
                return benchmark_trades[0][0] if benchmark_trades else 0
            
        except Exception:
            return 0
    
    def _calculate_twap_benchmark(self, benchmark_trades: List[Tuple[float, float, pd.Timestamp]]) -> float:
        """Time Weighted Average Price benchmark"""
        try:
            if not benchmark_trades:
                return 0
            
            # Equal weight to all periods (regardless of volume)
            total_price = sum(price for price, _, _ in benchmark_trades)
            return total_price / len(benchmark_trades)
            
        except Exception:
            return 0
    
    def _assess_benchmark_timing(self, execution_trades: List[Tuple[float, float, pd.Timestamp]], 
                               benchmark_trades: List[Tuple[float, float, pd.Timestamp]], 
                               benchmark_type: str) -> str:
        """Benchmark timing değerlendirmesi"""
        try:
            if not execution_trades or not benchmark_trades:
                return "insufficient_data"
            
            # Execution timing analysis
            exec_start = min(ts for _, _, ts in execution_trades)
            exec_end = max(ts for _, _, ts in execution_trades)
            exec_duration = (exec_end - exec_start).total_seconds()
            
            bench_start = min(ts for _, _, ts in benchmark_trades)
            bench_end = max(ts for _, _, ts in benchmark_trades)
            bench_duration = (bench_end - bench_start).total_seconds()
            
            # Timing assessment based on strategy type
            if benchmark_type == "arrival":
                # For arrival price, faster execution is better
                if exec_duration < 30:  # Less than 30 seconds
                    return "very_fast"
                elif exec_duration < 300:  # Less than 5 minutes
                    return "fast"
                elif exec_duration < 1800:  # Less than 30 minutes
                    return "moderate"
                else:
                    return "slow"
            
            else:  # TWAP/VWAP
                # For time-based benchmarks, alignment with market hours matters
                if bench_duration > 0:
                    timing_ratio = exec_duration / bench_duration
                    if 0.8 <= timing_ratio <= 1.2:
                        return "well_timed"
                    elif 0.5 <= timing_ratio <= 1.5:
                        return "appropriately_timed"
                    else:
                        return "poorly_timed"
                else:
                    return "inconsistent"
                    
        except Exception:
            return "error"
    
    def calculate_vwap_adjustments(self, base_vwap: float, 
                                 adjustment_factors: Dict[str, float]) -> Dict[str, float]:
        """
        VWAP'a adjustment factor'ları uygular
        
        Args:
            base_vwap: Temel VWAP değeri
            adjustment_factors: Adjustment factor'ları
            
        Returns:
            Adjust edilmiş VWAP değerleri
        """
        try:
            adjustments = {}
            
            # Time-based adjustments
            time_of_day_factor = adjustment_factors.get('time_of_day', 1.0)
            adjustments['time_adjusted_vwap'] = base_vwap * time_of_day_factor
            
            # Volatility adjustments
            volatility_factor = adjustment_factors.get('volatility', 1.0)
            adjustments['volatility_adjusted_vwap'] = base_vwap * volatility_factor
            
            # Liquidity adjustments
            liquidity_factor = adjustment_factors.get('liquidity', 1.0)
            adjustments['liquidity_adjusted_vwap'] = base_vwap * liquidity_factor
            
            # Market regime adjustments
            regime_factor = adjustment_factors.get('market_regime', 1.0)
            adjustments['regime_adjusted_vwap'] = base_vwap * regime_factor
            
            return adjustments
            
        except Exception as e:
            print(f"VWAP adjustment hatası: {e}")
            return {}
    
    def get_vwap_performance_metrics(self) -> Dict:
        """VWAP performans metriklerini getirir"""
        try:
            if not self.vwap_history:
                return {}
            
            recent_vwaps = list(self.vwap_history)[-20:]
            
            return {
                'avg_vwap': np.mean([v.vwap_price for v in recent_vwaps]),
                'vwap_volatility': np.std([v.vwap_price for v in recent_vwaps]),
                'avg_confidence': np.mean([v.confidence_level for v in recent_vwaps]),
                'avg_reliability': np.mean([v.price_reliability for v in recent_vwaps]),
                'calculation_count': len(self.vwap_history)
            }
            
        except Exception as e:
            print(f"VWAP performance metrik hatası: {e}")
            return {}
    
    def update_data(self, price: float, volume: float, timestamp: pd.Timestamp):
        """Veri güncellemesi"""
        self.price_volume_data.append((price, volume, timestamp))
    
    def clear_history(self):
        """Geçmişi temizler"""
        self.price_volume_data.clear()
        self.vwap_history.clear()