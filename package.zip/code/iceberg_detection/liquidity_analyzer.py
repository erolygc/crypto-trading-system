"""
Liquidity Analyzer

Market likiditesini analiz eden sistem.
Liquidity depth, quality, stability ve dynamics analizi içerir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import deque, defaultdict
import math
from scipy import stats
import warnings
warnings.filterwarnings('ignore')


@dataclass
class LiquidityMetrics:
    """Likidite metrikleri"""
    bid_depth: float  # Alış tarafı derinlik
    ask_depth: float  # Satış tarafı derinlik
    total_depth: float  # Toplam derinlik
    depth_quality: float  # Derinlik kalitesi
    liquidity_score: float  # Genel likidite skoru
    bid_ask_spread: float  # Bid-ask spread
    spread_quality: float  # Spread kalitesi
    depth_stability: float  # Derinlik kararlılığı


@dataclass
class LiquidityProfile:
    """Likidite profili"""
    shallow_levels: List[float]  # Sığ seviyeler (ilk 5)
    medium_levels: List[float]  # Orta seviyeler (6-15)
    deep_levels: List[float]  # Derin seviyeler (16+)
    liquidity_curve: List[Tuple[float, float]]  # (price_distance, cumulative_volume)
    depth_concentration: float  # Derinlik konsantrasyonu


class LiquidityAnalyzer:
    """
    Market likidite analiz sistemi
    """
    
    def __init__(self, depth_levels: int = 20, stability_window: int = 50):
        """
        Args:
            depth_levels: İncelenecek seviye sayısı
            stability_window: Stabilite analiz penceresi
        """
        self.depth_levels = depth_levels
        self.stability_window = stability_window
        self.depth_history = deque(maxlen=stability_window)
        self.spread_history = deque(maxlen=stability_window)
        self.liquidity_history = deque(maxlen=stability_window)
        
    def analyze_liquidity(self, bid_levels: List[Tuple[float, float]], 
                         ask_levels: List[Tuple[float, float]]) -> LiquidityMetrics:
        """
        Likiditeyi detaylı analiz eder
        
        Args:
            bid_levels: Alış seviyeleri [(price, size), ...]
            ask_levels: Satış seviyeleri [(price, size), ...]
            
        Returns:
            Likidite metrikleri
        """
        try:
            # Temel metrikleri hesapla
            bid_depth = self._calculate_depth(bid_levels)
            ask_depth = self._calculate_depth(ask_levels)
            total_depth = bid_depth + ask_depth
            
            # Spread analizi
            mid_price = (bid_levels[0][0] + ask_levels[0][0]) / 2
            bid_ask_spread = ask_levels[0][0] - bid_levels[0][0]
            
            # Derinlik kalitesi
            depth_quality = self._assess_depth_quality(bid_levels, ask_levels)
            
            # Likidite skoru
            liquidity_score = self._calculate_liquidity_score(bid_depth, ask_depth, bid_ask_spread, mid_price)
            
            # Spread kalitesi
            spread_quality = self._assess_spread_quality(bid_levels, ask_levels)
            
            # Derinlik kararlılığı
            depth_stability = self._assess_depth_stability(bid_depth, ask_depth)
            
            metrics = LiquidityMetrics(
                bid_depth=bid_depth,
                ask_depth=ask_depth,
                total_depth=total_depth,
                depth_quality=depth_quality,
                liquidity_score=liquidity_score,
                bid_ask_spread=bid_ask_spread,
                spread_quality=spread_quality,
                depth_stability=depth_stability
            )
            
            # Geçmişi güncelle
            self._update_liquidity_history(metrics)
            
            return metrics
            
        except Exception as e:
            print(f"Likidite analiz hatası: {e}")
            return LiquidityMetrics(0, 0, 0, 0, 0, 0, 0, 0)
    
    def create_liquidity_profile(self, bid_levels: List[Tuple[float, float]], 
                               ask_levels: List[Tuple[float, float]]) -> LiquidityProfile:
        """
        Detaylı likidite profili oluşturur
        
        Args:
            bid_levels: Alış seviyeleri
            ask_levels: Satış seviyeleri
            
        Returns:
            Likidite profili
        """
        try:
            # Seviyelere göre kategorize et
            shallow_levels = self._extract_level_range(bid_levels, ask_levels, 0, 5)
            medium_levels = self._extract_level_range(bid_levels, ask_levels, 5, 15)
            deep_levels = self._extract_level_range(bid_levels, ask_levels, 15, self.depth_levels)
            
            # Likidite eğrisi oluştur
            liquidity_curve = self._create_liquidity_curve(bid_levels, ask_levels)
            
            # Derinlik konsantrasyonu
            depth_concentration = self._calculate_depth_concentration(bid_levels, ask_levels)
            
            return LiquidityProfile(
                shallow_levels=shallow_levels,
                medium_levels=medium_levels,
                deep_levels=deep_levels,
                liquidity_curve=liquidity_curve,
                depth_concentration=depth_concentration
            )
            
        except Exception as e:
            print(f"Likidite profili oluşturma hatası: {e}")
            return LiquidityProfile([], [], [], [], 0)
    
    def _calculate_depth(self, levels: List[Tuple[float, float]]) -> float:
        """Belirtilen seviyelerin derinliğini hesaplar"""
        try:
            total_depth = 0
            for i, (_, size) in enumerate(levels[:self.depth_levels]):
                # Daha derin seviyeler daha az ağırlık
                weight = 1 / (1 + i * 0.1)
                total_depth += size * weight
            
            return total_depth
        except Exception:
            return 0
    
    def _assess_depth_quality(self, bid_levels: List[Tuple[float, float]], 
                            ask_levels: List[Tuple[float, float]]) -> float:
        """Derinlik kalitesini değerlendirir"""
        try:
            # Depth distribution analysis
            bid_sizes = [size for _, size in bid_levels[:10]]
            ask_sizes = [size for _, size in ask_levels[:10]]
            
            all_sizes = bid_sizes + ask_sizes
            if len(all_sizes) < 4:
                return 0
            
            # Consistency: düşük coefficient of variation = yüksek kalite
            mean_size = np.mean(all_sizes)
            std_size = np.std(all_sizes)
            
            if mean_size == 0:
                return 0
            
            cv = std_size / mean_size
            consistency_score = max(0, 1 - cv)
            
            # Distribution: Even distribution across levels
            first_level_ratio = all_sizes[0] / sum(all_sizes)
            distribution_score = max(0, 1 - first_level_ratio)
            
            # Combine scores
            depth_quality = (consistency_score + distribution_score) / 2
            
            return min(depth_quality, 1.0)
            
        except Exception:
            return 0
    
    def _calculate_liquidity_score(self, bid_depth: float, ask_depth: float, 
                                 spread: float, mid_price: float) -> float:
        """Genel likidite skorunu hesaplar"""
        try:
            if mid_price == 0:
                return 0
            
            # Normalize components
            depth_component = (bid_depth + ask_depth) / 2  # Average depth
            spread_component = 1 / max(spread / mid_price, 0.0001)  # Inverse of spread percentage
            balance_component = 1 - abs(bid_depth - ask_depth) / max(bid_depth + ask_depth, 1)
            
            # Weighted combination
            liquidity_score = (
                depth_component * 0.4 +
                spread_component * 0.3 +
                balance_component * 0.3
            )
            
            # Scale to 0-1 range
            normalized_score = min(liquidity_score / 10000, 1.0)  # Scale factor
            
            return max(0, min(normalized_score, 1.0))
            
        except Exception:
            return 0
    
    def _assess_spread_quality(self, bid_levels: List[Tuple[float, float]], 
                             ask_levels: List[Tuple[float, float]]) -> float:
        """Spread kalitesini değerlendirir"""
        try:
            if len(bid_levels) < 2 or len(ask_levels) < 2:
                return 0
            
            # Spread stability across levels
            spreads = []
            for i in range(min(5, len(bid_levels), len(ask_levels))):
                level_spread = ask_levels[i][0] - bid_levels[i][0]
                spreads.append(level_spread)
            
            if len(spreads) < 2:
                return 0
            
            # Lower spread variance = higher quality
            spread_mean = np.mean(spreads)
            spread_std = np.std(spreads)
            
            if spread_mean == 0:
                return 0
            
            spread_cv = spread_std / spread_mean
            spread_quality = max(0, 1 - spread_cv)
            
            return min(spread_quality, 1.0)
            
        except Exception:
            return 0
    
    def _assess_depth_stability(self, bid_depth: float, ask_depth: float) -> float:
        """Derinlik kararlılığını değerlendirir"""
        try:
            if len(self.depth_history) < 10:
                return 0.5  # Default for insufficient data
            
            recent_depths = [d.total_depth for d in list(self.depth_history)[-10:]]
            current_depth = bid_depth + ask_depth
            
            # Compare current depth to recent average
            avg_recent_depth = np.mean(recent_depths)
            
            if avg_recent_depth == 0:
                return 0
            
            depth_ratio = current_depth / avg_recent_depth
            
            # Stability score: closer to 1 = more stable
            if 0.8 <= depth_ratio <= 1.2:
                stability_score = 1.0
            elif 0.5 <= depth_ratio <= 2.0:
                stability_score = 0.7
            else:
                stability_score = 0.3
            
            return stability_score
            
        except Exception:
            return 0
    
    def _extract_level_range(self, bid_levels: List[Tuple[float, float]], 
                           ask_levels: List[Tuple[float, float]], 
                           start: int, end: int) -> List[float]:
        """Belirtilen seviye aralığındaki derinlikleri çıkarır"""
        try:
            levels = []
            
            # Bid levels
            for i in range(start, min(end, len(bid_levels))):
                levels.append(bid_levels[i][1])
            
            # Ask levels
            for i in range(start, min(end, len(ask_levels))):
                levels.append(ask_levels[i][1])
            
            return levels
            
        except Exception:
            return []
    
    def _create_liquidity_curve(self, bid_levels: List[Tuple[float, float]], 
                              ask_levels: List[Tuple[float, float]]) -> List[Tuple[float, float]]:
        """Likidite eğrisi oluşturur"""
        try:
            curve = []
            mid_price = (bid_levels[0][0] + ask_levels[0][0]) / 2
            
            # Cumulative volume at different price distances
            for price_distance in np.arange(0, 0.05, 0.001):  # 0% to 5% distance
                # Calculate cumulative volume at this price distance
                cumulative_volume = 0
                
                for price, size in bid_levels:
                    if price >= mid_price * (1 - price_distance):
                        cumulative_volume += size
                
                for price, size in ask_levels:
                    if price <= mid_price * (1 + price_distance):
                        cumulative_volume += size
                
                curve.append((price_distance, cumulative_volume))
            
            return curve
            
        except Exception:
            return []
    
    def _calculate_depth_concentration(self, bid_levels: List[Tuple[float, float]], 
                                     ask_levels: List[Tuple[float, float]]) -> float:
        """Derinlik konsantrasyonunu hesaplar"""
        try:
            # Combine all levels
            all_levels = []
            for price, size in bid_levels[:10]:
                all_levels.append(size)
            for price, size in ask_levels[:10]:
                all_levels.append(size)
            
            if len(all_levels) < 2:
                return 0
            
            # Calculate Herfindahl index (concentration measure)
            total_volume = sum(all_levels)
            if total_volume == 0:
                return 0
            
            # Normalize volumes
            normalized_volumes = [v / total_volume for v in all_levels]
            
            # Herfindahl index
            herfindahl = sum(v ** 2 for v in normalized_volumes)
            
            # Convert to concentration score (0 = no concentration, 1 = perfect concentration)
            concentration = herfindahl
            
            return min(concentration, 1.0)
            
        except Exception:
            return 0
    
    def _update_liquidity_history(self, metrics: LiquidityMetrics):
        """Likidite geçmişini günceller"""
        self.depth_history.append(metrics)
        self.spread_history.append(metrics.bid_ask_spread)
        self.liquidity_history.append(metrics.liquidity_score)
    
    def predict_liquidity_consumption(self, order_size: float, 
                                    liquidity_metrics: LiquidityMetrics) -> Dict:
        """
        Likidite tüketimi tahmini yapar
        
        Args:
            order_size: Emir boyutu
            liquidity_metrics: Mevcut likidite metrikleri
            
        Returns:
            Likidite tüketim tahmini
        """
        try:
            # Available liquidity
            available_liquidity = liquidity_metrics.total_depth
            
            # Consumption ratio
            consumption_ratio = order_size / available_liquidity if available_liquidity > 0 else float('inf')
            
            # Expected liquidity depletion
            depletion_percentage = min(consumption_ratio * 100, 100)
            
            # Price impact estimation
            if consumption_ratio < 0.1:
                impact_category = "minimal"
            elif consumption_ratio < 0.3:
                impact_category = "moderate"
            elif consumption_ratio < 0.7:
                impact_category = "significant"
            else:
                impact_category = "severe"
            
            # Recovery time estimate
            if impact_category == "minimal":
                recovery_time = 10  # ticks
            elif impact_category == "moderate":
                recovery_time = 30
            elif impact_category == "significant":
                recovery_time = 60
            else:
                recovery_time = 120
            
            return {
                'consumption_ratio': consumption_ratio,
                'depletion_percentage': depletion_percentage,
                'impact_category': impact_category,
                'recovery_time_ticks': recovery_time,
                'available_after_execution': max(0, available_liquidity - order_size)
            }
            
        except Exception as e:
            print(f"Likidite tüketim tahmin hatası: {e}")
            return {}
    
    def get_liquidity_trends(self) -> Dict:
        """Likidite trendlerini analiz eder"""
        try:
            if len(self.depth_history) < 10:
                return {'status': 'insufficient_data'}
            
            recent_metrics = list(self.depth_history)[-20:]
            
            # Calculate trends
            depths = [m.total_depth for m in recent_metrics]
            spreads = [m.bid_ask_spread for m in recent_metrics]
            scores = [m.liquidity_score for m in recent_metrics]
            
            # Trend slopes
            depth_trend = self._calculate_trend_slope(depths)
            spread_trend = self._calculate_trend_slope(spreads)
            score_trend = self._calculate_trend_slope(scores)
            
            # Trend classifications
            depth_direction = "improving" if depth_trend > 0 else "deteriorating"
            spread_direction = "improving" if spread_trend < 0 else "deteriorating"
            score_direction = "improving" if score_trend > 0 else "deteriorating"
            
            return {
                'depth_trend': {
                    'direction': depth_direction,
                    'slope': depth_trend,
                    'current': depths[-1],
                    'avg_recent': np.mean(depths[-5:])
                },
                'spread_trend': {
                    'direction': spread_direction,
                    'slope': spread_trend,
                    'current': spreads[-1],
                    'avg_recent': np.mean(spreads[-5:])
                },
                'liquidity_trend': {
                    'direction': score_direction,
                    'slope': score_trend,
                    'current': scores[-1],
                    'avg_recent': np.mean(scores[-5:])
                },
                'overall_trend': self._classify_overall_trend(depth_trend, spread_trend, score_trend)
            }
            
        except Exception as e:
            print(f"Likidite trend analiz hatası: {e}")
            return {'status': 'error'}
    
    def _calculate_trend_slope(self, values: List[float]) -> float:
        """Trend eğimini hesaplar"""
        try:
            if len(values) < 3:
                return 0
            
            x = np.arange(len(values))
            y = np.array(values)
            
            slope = np.polyfit(x, y, 1)[0]
            return slope
            
        except Exception:
            return 0
    
    def _classify_overall_trend(self, depth_slope: float, spread_slope: float, score_slope: float) -> str:
        """Genel trend'i sınıflandırır"""
        try:
            # Positive score for improving depth, negative for improving spread
            combined_score = depth_slope - spread_slope + score_slope
            
            if combined_score > 0.1:
                return "improving"
            elif combined_score < -0.1:
                return "deteriorating"
            else:
                return "stable"
                
        except Exception:
            return "stable"
    
    def get_liquidity_statistics(self) -> Dict:
        """Likidite istatistiklerini getirir"""
        try:
            if not self.depth_history:
                return {}
            
            recent_data = list(self.depth_history)[-50:]
            
            return {
                'avg_total_depth': np.mean([d.total_depth for d in recent_data]),
                'avg_spread': np.mean([d.bid_ask_spread for d in recent_data]),
                'avg_liquidity_score': np.mean([d.liquidity_score for d in recent_data]),
                'depth_volatility': np.std([d.total_depth for d in recent_data]),
                'spread_volatility': np.std([d.bid_ask_spread for d in recent_data]),
                'liquidity_stability': np.mean([d.depth_stability for d in recent_data])
            }
            
        except Exception as e:
            print(f"Likidite istatistik hatası: {e}")
            return {}
    
    def clear_history(self):
        """Geçmişi temizler"""
        self.depth_history.clear()
        self.spread_history.clear()
        self.liquidity_history.clear()