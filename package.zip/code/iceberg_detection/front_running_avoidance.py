"""
Front-Running Avoidance System

Büyük emirlerle front-running riskini minimize etmek için stratejiler içerir.
Order splitting, timing optimization ve stealth execution algoritmaları.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum
import random
import math
from collections import deque
import warnings
warnings.filterwarnings('ignore')


class OrderType(Enum):
    MARKET = "market"
    LIMIT = "limit"
    ICEBERG = "iceberg"
    TWAP = "twap"
    VWAP = "vwap"


@dataclass
class ExecutionPlan:
    """Execution plan bilgisi"""
    strategy_type: OrderType
    total_size: float
    split_count: int
    timing_intervals: List[int]  # seconds between orders
    price_levels: List[float]
    stealth_factor: float
    estimated_slippage: float
    front_run_risk: float


@dataclass
class MarketConditions:
    """Market durumu bilgisi"""
    volatility: float
    volume_profile: Dict[str, float]
    order_book_depth: Dict[str, float]
    volatility_regime: str
    liquidity_conditions: str
    risk_level: float


class FrontRunningAvoidance:
    """
    Front-running riskini minimize eden execution sistemi
    """
    
    def __init__(self, max_order_size: float = 1000, volatility_window: int = 100):
        """
        Args:
            max_order_size: Maksimum tek seferde işlem yapılacak boyut
            volatility_window: Volatilite hesaplama penceresi
        """
        self.max_order_size = max_order_size
        self.volatility_window = volatility_window
        self.price_history = deque(maxlen=volatility_window)
        self.volume_history = deque(maxlen=volatility_window)
        self.execution_plans = {}
        
    def create_stealth_execution_plan(self, order_size: float, 
                                    current_price: float,
                                    market_conditions: MarketConditions,
                                    urgency_level: float = 0.5) -> ExecutionPlan:
        """
        Stealth execution planı oluşturur
        
        Args:
            order_size: Toplam emir boyutu
            current_price: Mevcut fiyat
            market_conditions: Market durumu
            urgency_level: Aciliyet seviyesi (0-1)
            
        Returns:
            Execution plan
        """
        try:
            # Calculate optimal strategy based on order size and market conditions
            strategy_type = self._select_optimal_strategy(order_size, market_conditions, urgency_level)
            
            # Calculate split parameters
            split_params = self._calculate_split_parameters(order_size, strategy_type, market_conditions)
            
            # Generate timing intervals
            timing_intervals = self._generate_timing_intervals(split_params, market_conditions, urgency_level)
            
            # Calculate price levels
            price_levels = self._calculate_price_levels(current_price, strategy_type, split_params, market_conditions)
            
            # Calculate stealth factors
            stealth_factor = self._calculate_stealth_factor(strategy_type, market_conditions)
            
            # Estimate slippage
            estimated_slippage = self._estimate_slippage(order_size, strategy_type, market_conditions)
            
            # Calculate front-running risk
            front_run_risk = self._assess_front_run_risk(strategy_type, split_params, market_conditions)
            
            return ExecutionPlan(
                strategy_type=strategy_type,
                total_size=order_size,
                split_count=split_params['split_count'],
                timing_intervals=timing_intervals,
                price_levels=price_levels,
                stealth_factor=stealth_factor,
                estimated_slippage=estimated_slippage,
                front_run_risk=front_run_risk
            )
            
        except Exception as e:
            print(f"Execution plan oluşturma hatası: {e}")
            return self._create_fallback_plan(order_size, current_price)
    
    def _select_optimal_strategy(self, order_size: float, 
                               market_conditions: MarketConditions, 
                               urgency_level: float) -> OrderType:
        """Optimal execution strategy'sini seçer"""
        
        # Large orders require more sophisticated strategies
        if order_size > self.max_order_size * 5:
            return OrderType.ICEBERG if urgency_level < 0.3 else OrderType.TWAP
        
        elif order_size > self.max_order_size * 2:
            if market_conditions.volatility_regime == "high":
                return OrderType.VWAP  # Less sensitive to volatility
            else:
                return OrderType.TWAP
        
        elif order_size > self.max_order_size:
            return OrderType.LIMIT  # Use limit orders to control price impact
        
        else:
            return OrderType.MARKET  # Small orders can use market orders
    
    def _calculate_split_parameters(self, order_size: float, 
                                  strategy_type: OrderType, 
                                  market_conditions: MarketConditions) -> Dict:
        """Split parametrelerini hesaplar"""
        
        base_splits = {
            OrderType.MARKET: 1,
            OrderType.LIMIT: 3,
            OrderType.ICEBERG: 10,
            OrderType.TWAP: 20,
            OrderType.VWAP: 15
        }
        
        # Adjust splits based on order size
        size_multiplier = min(1.0, order_size / self.max_order_size)
        
        # Adjust splits based on volatility
        volatility_multiplier = 1 + (market_conditions.volatility * 2)
        
        # Adjust splits based on liquidity
        liquidity_multiplier = 1.5 if market_conditions.liquidity_conditions == "low" else 1.0
        
        base_split = base_splits[strategy_type]
        final_split = int(base_split * size_multiplier * volatility_multiplier * liquidity_multiplier)
        
        return {
            'split_count': max(1, final_split),
            'size_per_split': order_size / max(1, final_split),
            'base_split': base_split
        }
    
    def _generate_timing_intervals(self, split_params: Dict, 
                                 market_conditions: MarketConditions, 
                                 urgency_level: float) -> List[int]:
        """Timing interval'ları oluşturur"""
        
        intervals = []
        split_count = split_params['split_count']
        
        if split_count == 1:
            return [0]
        
        # Base interval calculation
        if market_conditions.liquidity_conditions == "high":
            base_interval = 30  # 30 seconds in liquid markets
        else:
            base_interval = 60  # 60 seconds in less liquid markets
        
        # Adjust for urgency (higher urgency = shorter intervals)
        urgency_factor = 1 - urgency_level
        adjusted_interval = base_interval * urgency_factor
        
        # Add randomness to avoid pattern detection
        for i in range(split_count):
            if i == 0:
                intervals.append(0)  # First order immediate
            else:
                # Randomized intervals
                random_factor = 0.7 + (random.random() * 0.6)  # 0.7 to 1.3
                interval = int(adjusted_interval * random_factor)
                intervals.append(max(10, interval))  # Minimum 10 seconds
        
        return intervals
    
    def _calculate_price_levels(self, current_price: float, 
                              strategy_type: OrderType, 
                              split_params: Dict, 
                              market_conditions: MarketConditions) -> List[float]:
        """Price level'leri hesaplar"""
        
        if strategy_type == OrderType.MARKET:
            return [current_price]
        
        # Calculate acceptable price range
        volatility_adjustment = market_conditions.volatility * 0.5
        slippage_tolerance = 0.001 + volatility_adjustment  # 0.1% + volatility
        
        price_levels = []
        
        if strategy_type == OrderType.LIMIT:
            # Create ladder of limit prices
            for i in range(split_params['split_count']):
                price_offset = slippage_tolerance * (i + 1) / split_params['split_count']
                price_levels.append(current_price * (1 - price_offset))  # Buy side
        
        elif strategy_type == OrderType.ICEBERG:
            # Similar prices with slight variations
            base_price = current_price * (1 - slippage_tolerance * 0.5)
            for i in range(split_params['split_count']):
                variation = (random.random() - 0.5) * slippage_tolerance * 0.1
                price_levels.append(base_price * (1 + variation))
        
        else:  # TWAP, VWAP
            # Central price with slight variations
            for i in range(split_params['split_count']):
                variation = (random.random() - 0.5) * slippage_tolerance * 0.2
                price_levels.append(current_price * (1 + variation))
        
        return price_levels
    
    def _calculate_stealth_factor(self, strategy_type: OrderType, 
                                market_conditions: MarketConditions) -> float:
        """Stealth factor hesaplar"""
        
        base_stealth = {
            OrderType.MARKET: 0.3,
            OrderType.LIMIT: 0.7,
            OrderType.ICEBERG: 0.9,
            OrderType.TWAP: 0.8,
            OrderType.VWAP: 0.8
        }
        
        # Market condition adjustments
        liquidity_bonus = 0.2 if market_conditions.liquidity_conditions == "high" else 0
        volatility_penalty = market_conditions.volatility * 0.3
        
        stealth_factor = base_stealth[strategy_type] + liquidity_bonus - volatility_penalty
        
        return max(0, min(1, stealth_factor))
    
    def _estimate_slippage(self, order_size: float, 
                         strategy_type: OrderType, 
                         market_conditions: MarketConditions) -> float:
        """Slippage tahmini yapar"""
        
        # Base slippage calculation
        volume_ratio = order_size / max(sum(self.volume_history), 1000) if self.volume_history else order_size / 1000
        
        # Strategy-specific slippage
        strategy_multipliers = {
            OrderType.MARKET: 1.0,
            OrderType.LIMIT: 0.7,
            OrderType.ICEBERG: 0.5,
            OrderType.TWAP: 0.6,
            OrderType.VWAP: 0.6
        }
        
        # Market impact estimation
        market_impact = math.sqrt(volume_ratio) * 0.01  # Square root model
        volatility_impact = market_conditions.volatility * 0.5
        
        estimated_slippage = (market_impact + volatility_impact) * strategy_multipliers[strategy_type]
        
        return min(estimated_slippage, 0.05)  # Cap at 5%
    
    def _assess_front_run_risk(self, strategy_type: OrderType, 
                             split_params: Dict, 
                             market_conditions: MarketConditions) -> float:
        """Front-running riskini değerlendirir"""
        
        # Base risk by strategy
        base_risk = {
            OrderType.MARKET: 0.9,  # High risk - immediate execution
            OrderType.LIMIT: 0.3,   # Lower risk - price discovery
            OrderType.ICEBERG: 0.1, # Very low risk - hidden
            OrderType.TWAP: 0.2,    # Low risk - time-sliced
            OrderType.VWAP: 0.2     # Low risk - volume-sliced
        }
        
        # Adjust for market conditions
        volatility_penalty = market_conditions.volatility * 0.4
        liquidity_penalty = -0.2 if market_conditions.liquidity_conditions == "high" else 0.3
        
        # Adjust for split count (more splits = lower risk)
        split_bonus = min(0.1 * split_params['split_count'], 0.5)
        
        front_run_risk = (base_risk[strategy_type] + volatility_penalty + liquidity_penalty - split_bonus)
        
        return max(0, min(1, front_run_risk))
    
    def _create_fallback_plan(self, order_size: float, current_price: float) -> ExecutionPlan:
        """Hata durumunda fallback plan"""
        return ExecutionPlan(
            strategy_type=OrderType.MARKET,
            total_size=order_size,
            split_count=1,
            timing_intervals=[0],
            price_levels=[current_price],
            stealth_factor=0.3,
            estimated_slippage=0.01,
            front_run_risk=0.9
        )
    
    def optimize_timing(self, base_plan: ExecutionPlan, 
                       recent_activity: List[Tuple[pd.Timestamp, str, float]]) -> List[int]:
        """Timing'i piyasa aktivitesine göre optimize eder"""
        
        try:
            if not recent_activity:
                return base_plan.timing_intervals
            
            optimized_intervals = []
            
            # Analyze recent activity patterns
            activity_hours = [ts.hour for ts, _, _ in recent_activity]
            activity_volume = [volume for _, _, volume in recent_activity]
            
            # Find low activity periods
            avg_volume = np.mean(activity_volume) if activity_volume else 0
            low_activity_indices = [i for i, vol in enumerate(activity_volume) if vol < avg_volume * 0.5]
            
            # Adjust timing to avoid high activity periods
            current_time = pd.Timestamp.now()
            for i, interval in enumerate(base_plan.timing_intervals):
                if i == 0:
                    optimized_intervals.append(0)
                else:
                    # Check if timing falls in high activity period
                    proposed_time = current_time + pd.Timedelta(seconds=sum(optimized_intervals))
                    
                    # Simple heuristic: avoid lunch hours and market close
                    if 12 <= proposed_time.hour <= 14 or proposed_time.hour >= 15:
                        optimized_intervals.append(interval * 1.5)  # Extend interval
                    else:
                        optimized_intervals.append(interval)
            
            return optimized_intervals
            
        except Exception as e:
            print(f"Timing optimizasyon hatası: {e}")
            return base_plan.timing_intervals
    
    def generate_order_sequence(self, execution_plan: ExecutionPlan) -> List[Dict]:
        """Order sequence oluşturur"""
        
        orders = []
        remaining_size = execution_plan.total_size
        
        try:
            for i in range(execution_plan.split_count):
                # Calculate order size
                if i == execution_plan.split_count - 1:
                    # Last order gets remaining size
                    order_size = remaining_size
                else:
                    # Distribute size evenly with slight randomization
                    base_size = execution_plan.total_size / execution_plan.split_count
                    random_factor = 0.8 + (random.random() * 0.4)  # 0.8 to 1.2
                    order_size = base_size * random_factor
                
                remaining_size -= order_size
                
                # Create order
                order = {
                    'sequence_id': i + 1,
                    'size': order_size,
                    'price': execution_plan.price_levels[min(i, len(execution_plan.price_levels) - 1)],
                    'timing_delay': execution_plan.timing_intervals[min(i, len(execution_plan.timing_intervals) - 1)],
                    'order_type': execution_plan.strategy_type.value,
                    'stealth_factor': execution_plan.stealth_factor
                }
                
                orders.append(order)
        
        except Exception as e:
            print(f"Order sequence oluşturma hatası: {e}")
        
        return orders
    
    def update_market_conditions(self, price: float, volume: float):
        """Market koşullarını günceller"""
        self.price_history.append(price)
        self.volume_history.append(volume)
    
    def get_strategy_performance(self, strategy_type: OrderType) -> Dict:
        """Strategy performans istatistiklerini getirir"""
        # This would track actual execution performance in real implementation
        return {
            'strategy': strategy_type.value,
            'avg_slippage': 0.005,  # Placeholder
            'success_rate': 0.95,
            'avg_execution_time': 300  # 5 minutes
        }
    
    def clear_history(self):
        """Geçmişi temizler"""
        self.price_history.clear()
        self.volume_history.clear()
        self.execution_plans.clear()