"""
Market Impact Predictor

Büyük emirlerin market impact'ini tahmin etmek için modeller içerir.
Price impact, liquidity consumption ve temporary vs permanent impact ayrımı.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import deque
from scipy import optimize
import math
import warnings
warnings.filterwarnings('ignore')


@dataclass
class ImpactPrediction:
    """Market impact tahmini"""
    immediate_impact: float  # İlk execution impact'i
    temporary_impact: float  # Geçici impact
    permanent_impact: float  # Kalıcı impact
    liquidity_consumption: float  # Liquidity tüketimi
    price_recovery_time: int  # Fiyat toparlanma süresi (ticks)
    confidence_score: float
    impact_model_used: str


@dataclass
class MarketState:
    """Market durumu"""
    volatility: float
    liquidity_score: float
    volume_profile: Dict[str, float]
    order_flow_imbalance: float
    momentum: float
    mean_reversion_strength: float


class MarketImpactPredictor:
    """
    Market impact tahmin sistemi
    """
    
    def __init__(self, lookback_window: int = 200, impact_decay_factor: float = 0.7):
        """
        Args:
            lookback_window: Geçmiş veri penceresi
            impact_decay_factor: Impact decay faktörü
        """
        self.lookback_window = lookback_window
        self.impact_decay_factor = impact_decay_factor
        self.price_history = deque(maxlen=lookback_window)
        self.volume_history = deque(maxlen=lookback_window)
        self.impact_history = deque(maxlen=100)
        self.execution_history = []
        
    def predict_market_impact(self, order_size: float, 
                            current_price: float,
                            market_state: MarketState,
                            execution_timeline: List[float]) -> ImpactPrediction:
        """
        Market impact tahmini yapar
        
        Args:
            order_size: Emir boyutu
            current_price: Mevcut fiyat
            market_state: Market durumu
            execution_timeline: Execution zaman çizelgesi (fractional execution per period)
            
        Returns:
            Market impact tahmini
        """
        try:
            # Model 1: Square Root Impact Model
            sqrt_impact = self._calculate_square_root_impact(order_size, market_state)
            
            # Model 2: Kyle's Lambda Model
            kyle_impact = self._calculate_kyle_impact(order_size, market_state)
            
            # Model 3: Volume Weighted Model
            vwap_impact = self._calculate_vwap_impact(order_size, market_state)
            
            # Model 4: Temporary vs Permanent Impact
            temp_perm_impact = self._calculate_temp_perm_impact(order_size, current_price, market_state, execution_timeline)
            
            # Combine predictions with weights
            total_weight = (sqrt_impact['weight'] + kyle_impact['weight'] + 
                          vwap_impact['weight'] + temp_perm_impact['weight'])
            
            if total_weight == 0:
                return ImpactPrediction(0, 0, 0, 0, 0, 0, "none")
            
            # Weighted combination
            combined_immediate = (
                sqrt_impact['immediate'] * sqrt_impact['weight'] +
                kyle_impact['immediate'] * kyle_impact['weight'] +
                vwap_impact['immediate'] * vwap_impact['weight'] +
                temp_perm_impact['immediate'] * temp_perm_impact['weight']
            ) / total_weight
            
            combined_temporary = (
                sqrt_impact['temporary'] * sqrt_impact['weight'] +
                temp_perm_impact['temporary'] * temp_perm_impact['weight']
            ) / (sqrt_impact['weight'] + temp_perm_impact['weight'])
            
            combined_permanent = (
                kyle_impact['permanent'] * kyle_impact['weight'] +
                vwap_impact['permanent'] * vwap_impact['weight'] +
                temp_perm_impact['permanent'] * temp_perm_impact['weight']
            ) / (kyle_impact['weight'] + vwap_impact['weight'] + temp_perm_impact['weight'])
            
            # Liquidity consumption estimation
            liquidity_consumption = self._estimate_liquidity_consumption(order_size, market_state)
            
            # Price recovery time
            recovery_time = self._estimate_recovery_time(combined_temporary, market_state)
            
            # Confidence score based on model agreement
            confidence_score = self._calculate_confidence_score([sqrt_impact, kyle_impact, vwap_impact, temp_perm_impact])
            
            return ImpactPrediction(
                immediate_impact=combined_immediate,
                temporary_impact=combined_temporary,
                permanent_impact=combined_permanent,
                liquidity_consumption=liquidity_consumption,
                price_recovery_time=recovery_time,
                confidence_score=confidence_score,
                impact_model_used="combined"
            )
            
        except Exception as e:
            print(f"Market impact tahmin hatası: {e}")
            return ImpactPrediction(0, 0, 0, 0, 0, 0, "error")
    
    def _calculate_square_root_impact(self, order_size: float, 
                                    market_state: MarketState) -> Dict:
        """Square root impact model"""
        try:
            # Estimate market depth
            avg_volume = np.mean(list(self.volume_history)) if self.volume_history else 1000
            volume_ratio = order_size / avg_volume
            
            # Square root relationship
            base_impact = math.sqrt(volume_ratio) * 0.01  # 1% base impact
            
            # Volatility adjustment
            volatility_adj = 1 + market_state.volatility * 2
            
            # Liquidity adjustment
            liquidity_adj = 1 / max(market_state.liquidity_score, 0.1)
            
            # Order flow imbalance adjustment
            flow_adj = 1 + abs(market_state.order_flow_imbalance) * 0.5
            
            immediate_impact = base_impact * volatility_adj * liquidity_adj * flow_adj
            
            # Temporary component (typically 60-80% of immediate)
            temporary_impact = immediate_impact * 0.7
            
            # Permanent component (typically 20-40% of immediate)
            permanent_impact = immediate_impact * 0.3
            
            return {
                'immediate': immediate_impact,
                'temporary': temporary_impact,
                'permanent': permanent_impact,
                'weight': 0.3  # Model weight
            }
            
        except Exception as e:
            print(f"Square root impact hesaplama hatası: {e}")
            return {'immediate': 0, 'temporary': 0, 'permanent': 0, 'weight': 0}
    
    def _calculate_kyle_impact(self, order_size: float, 
                             market_state: MarketState) -> Dict:
        """Kyle's Lambda model"""
        try:
            # Kyle's lambda: lambda = (Price impact) / (Order size / Volume)
            # Simplified version based on market microstructure
            
            # Estimate lambda from historical data
            if len(self.price_history) > 10:
                price_changes = np.diff(list(self.price_history))
                recent_volumes = list(self.volume_history)[-10:]
                avg_volume = np.mean(recent_volumes)
                
                # Approximate lambda
                price_std = np.std(price_changes)
                lambda_estimate = price_std / max(avg_volume, 1)
            else:
                lambda_estimate = 0.001  # Default
            
            # Kyle's impact formula
            volume_ratio = order_size / max(avg_volume, 1)
            immediate_impact = lambda_estimate * math.sqrt(volume_ratio)
            
            # Adjust for market conditions
            volatility_adj = 1 + market_state.volatility
            liquidity_adj = 1 / max(market_state.liquidity_score, 0.1)
            
            immediate_impact *= volatility_adj * liquidity_adj
            
            # Split into temporary and permanent
            temporary_impact = immediate_impact * 0.6
            permanent_impact = immediate_impact * 0.4
            
            return {
                'immediate': immediate_impact,
                'temporary': temporary_impact,
                'permanent': permanent_impact,
                'weight': 0.25
            }
            
        except Exception as e:
            print(f"Kyle impact hesaplama hatası: {e}")
            return {'immediate': 0, 'temporary': 0, 'permanent': 0, 'weight': 0}
    
    def _calculate_vwap_impact(self, order_size: float, 
                             market_state: MarketState) -> Dict:
        """Volume weighted average price impact model"""
        try:
            # Estimate average daily volume
            if len(self.volume_history) > 20:
                daily_volume_estimate = np.mean(list(self.volume_history)) * 24  # Assuming hourly data
            else:
                daily_volume_estimate = 10000  # Default
            
            # Volume participation rate
            participation_rate = order_size / daily_volume_estimate
            
            # VWAP impact typically linear with participation rate
            base_impact = participation_rate * 0.005  # 0.5% per 100% participation
            
            # Adjust for market conditions
            volatility_adj = 1 + market_state.volatility * 1.5
            momentum_adj = 1 + abs(market_state.momentum) * 0.3
            
            immediate_impact = base_impact * volatility_adj * momentum_adj
            
            # VWAP impact is mostly permanent
            temporary_impact = immediate_impact * 0.4
            permanent_impact = immediate_impact * 0.6
            
            return {
                'immediate': immediate_impact,
                'temporary': temporary_impact,
                'permanent': permanent_impact,
                'weight': 0.25
            }
            
        except Exception as e:
            print(f"VWAP impact hesaplama hatası: {e}")
            return {'immediate': 0, 'temporary': 0, 'permanent': 0, 'weight': 0}
    
    def _calculate_temp_perm_impact(self, order_size: float, 
                                  current_price: float, 
                                  market_state: MarketState,
                                  execution_timeline: List[float]) -> Dict:
        """Temporary vs Permanent impact ayrımı"""
        try:
            # Execution timing affects impact distribution
            total_execution_time = len(execution_timeline)
            slow_execution_bonus = min(0.1, total_execution_time / 1000)  # Bonus for slow execution
            
            # Mean reversion strength affects temporary impact recovery
            mean_reversion_adj = 1 - market_state.mean_reversion_strength * 0.3
            
            # Base impact estimation
            avg_volume = np.mean(list(self.volume_history)) if self.volume_history else 1000
            volume_ratio = order_size / avg_volume
            
            base_impact = math.sqrt(volume_ratio) * 0.008
            
            # Temporary component
            temporary_impact = base_impact * (0.6 + slow_execution_bonus) * mean_reversion_adj
            
            # Permanent component
            permanent_impact = base_impact * 0.4 * (1 + abs(market_state.order_flow_imbalance) * 0.5)
            
            # Immediate impact
            immediate_impact = temporary_impact + permanent_impact
            
            return {
                'immediate': immediate_impact,
                'temporary': temporary_impact,
                'permanent': permanent_impact,
                'weight': 0.2
            }
            
        except Exception as e:
            print(f"Temporary/Permanent impact hesaplama hatası: {e}")
            return {'immediate': 0, 'temporary': 0, 'permanent': 0, 'weight': 0}
    
    def _estimate_liquidity_consumption(self, order_size: float, 
                                      market_state: MarketState) -> float:
        """Liquidity tüketimi tahmini"""
        try:
            avg_volume = np.mean(list(self.volume_history)) if self.volume_history else 1000
            
            # Base liquidity consumption
            consumption_ratio = order_size / avg_volume
            
            # Adjust for market liquidity
            liquidity_adjustment = 1 / max(market_state.liquidity_score, 0.1)
            
            liquidity_consumption = consumption_ratio * liquidity_adjustment
            
            return min(liquidity_consumption, 2.0)  # Cap at 200%
            
        except Exception as e:
            print(f"Liquidity consumption tahmin hatası: {e}")
            return 0
    
    def _estimate_recovery_time(self, temporary_impact: float, 
                              market_state: MarketState) -> int:
        """Fiyat toparlanma süresi tahmini"""
        try:
            # Recovery time inversely related to mean reversion strength
            base_recovery = 50  # Base recovery time in ticks
            
            # Mean reversion adjustment
            if market_state.mean_reversion_strength > 0:
                recovery_adjustment = 1 / (1 + market_state.mean_reversion_strength)
            else:
                recovery_adjustment = 2  # Slower recovery in trending markets
            
            # Volatility adjustment (high volatility = faster recovery)
            volatility_adjustment = 1 / max(0.5, 1 + market_state.volatility)
            
            recovery_time = int(base_recovery * recovery_adjustment * volatility_adjustment)
            
            return max(5, min(recovery_time, 500))  # Between 5 and 500 ticks
            
        except Exception as e:
            print(f"Recovery time tahmin hatası: {e}")
            return 50
    
    def _calculate_confidence_score(self, predictions: List[Dict]) -> float:
        """Tahmin güven skorunu hesaplar"""
        try:
            if not predictions:
                return 0
            
            immediate_values = [pred['immediate'] for pred in predictions if pred['immediate'] > 0]
            
            if len(immediate_values) < 2:
                return 0.5
            
            # Calculate coefficient of variation
            mean_impact = np.mean(immediate_values)
            std_impact = np.std(immediate_values)
            
            if mean_impact == 0:
                return 0
            
            cv = std_impact / mean_impact
            
            # Lower CV = higher confidence
            confidence = max(0, 1 - cv)
            
            return min(confidence, 1.0)
            
        except Exception as e:
            print(f"Confidence score hesaplama hatası: {e}")
            return 0
    
    def update_market_data(self, price: float, volume: float):
        """Market verilerini günceller"""
        self.price_history.append(price)
        self.volume_history.append(volume)
    
    def record_actual_impact(self, predicted_impact: ImpactPrediction, 
                           actual_immediate: float, actual_temporary: float, 
                           actual_permanent: float):
        """Gerçek impact'i kaydet (model kalibrasyonu için)"""
        try:
            impact_record = {
                'predicted_immediate': predicted_impact.immediate_impact,
                'actual_immediate': actual_immediate,
                'predicted_temporary': predicted_impact.temporary_impact,
                'actual_temporary': actual_temporary,
                'predicted_permanent': predicted_impact.permanent_impact,
                'actual_permanent': actual_permanent,
                'timestamp': pd.Timestamp.now()
            }
            
            self.impact_history.append(impact_record)
            
            # Keep only recent records for model updates
            if len(self.impact_history) > 100:
                self.impact_history.popleft()
        
        except Exception as e:
            print(f"Impact kayıt hatası: {e}")
    
    def calibrate_models(self) -> Dict:
        """Model kalibrasyonu yapar"""
        try:
            if len(self.impact_history) < 10:
                return {'status': 'insufficient_data'}
            
            # Calculate model performance
            prediction_errors = []
            
            for record in self.impact_history:
                immediate_error = abs(record['predicted_immediate'] - record['actual_immediate'])
                prediction_errors.append(immediate_error)
            
            avg_error = np.mean(prediction_errors)
            error_std = np.std(prediction_errors)
            
            # Model calibration adjustments
            calibration_factor = max(0.5, min(2.0, 1 / max(avg_error, 0.001)))
            
            return {
                'status': 'calibrated',
                'average_error': avg_error,
                'error_std': error_std,
                'calibration_factor': calibration_factor,
                'sample_size': len(self.impact_history)
            }
            
        except Exception as e:
            print(f"Model kalibrasyon hatası: {e}")
            return {'status': 'error', 'error': str(e)}
    
    def get_impact_statistics(self) -> Dict:
        """Impact istatistiklerini getirir"""
        try:
            if not self.impact_history:
                return {}
            
            recent_impacts = list(self.impact_history)[-20:]  # Last 20 records
            
            return {
                'avg_immediate_impact': np.mean([r['actual_immediate'] for r in recent_impacts]),
                'avg_temporary_impact': np.mean([r['actual_temporary'] for r in recent_impacts]),
                'avg_permanent_impact': np.mean([r['actual_permanent'] for r in recent_impacts]),
                'impact_volatility': np.std([r['actual_immediate'] for r in recent_impacts]),
                'recovery_success_rate': self._calculate_recovery_success_rate(recent_impacts)
            }
            
        except Exception as e:
            print(f"Impact istatistik hatası: {e}")
            return {}
    
    def _calculate_recovery_success_rate(self, impacts: List[Dict]) -> float:
        """Recovery başarı oranını hesaplar"""
        try:
            recovered_count = 0
            total_count = len(impacts)
            
            for impact in impacts:
                # Consider recovery successful if temporary impact is less than 50% of immediate
                if impact['actual_temporary'] < impact['actual_immediate'] * 0.5:
                    recovered_count += 1
            
            return recovered_count / total_count if total_count > 0 else 0
            
        except Exception:
            return 0
    
    def clear_history(self):
        """Geçmişi temizler"""
        self.price_history.clear()
        self.volume_history.clear()
        self.impact_history.clear()
        self.execution_history.clear()