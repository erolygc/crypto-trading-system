"""
Hidden Order Detector

Gizli büyük emirleri (iceberg, hidden orders) tespit etmek için algoritmalar içerir.
Order flow analizi, time-based pattern detection ve execution analysis yapmaktadır.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import deque
import math
from scipy import stats
import warnings
warnings.filterwarnings('ignore')


@dataclass
class HiddenOrderSignal:
    """Gizli emir sinyali"""
    order_type: str  # iceberg, hidden, dark_pool
    estimated_size: float
    confidence: float
    time_to_completion: int  # tahmini tamamlanma süresi (tick)
    execution_rate: float
    price_impact: float
    detection_timestamp: pd.Timestamp


@dataclass
class OrderFlowAnalysis:
    """Order flow analiz sonuçları"""
    buy_pressure: float
    sell_pressure: float
    net_flow: float
    flow_intensity: float
    block_activity: int
    dark_pool_volume: float


class HiddenOrderDetector:
    """
    Gizli büyük emirleri tespit eden sistem
    """
    
    def __init__(self, window_size: int = 100, min_iceberg_size: float = 0.1):
        """
        Args:
            window_size: Analiz penceresi boyutu
            min_iceberg_size: Minimum iceberg boyutu
        """
        self.window_size = window_size
        self.min_iceberg_size = min_iceberg_size
        self.price_history = deque(maxlen=window_size)
        self.volume_history = deque(maxlen=window_size)
        self.order_flow_history = deque(maxlen=window_size)
        self.execution_patterns = {}
        
    def detect_hidden_orders(self, current_price: float, 
                           volume: float, 
                           trades: List[Tuple[float, float, int]]) -> List[HiddenOrderSignal]:
        """
        Gizli emirleri tespit eder
        
        Args:
            current_price: Mevcut fiyat
            volume: İşlem hacmi
            trades: [(price, size, timestamp), ...]
            
        Returns:
            Tespit edilen gizli emirler
        """
        signals = []
        
        try:
            # Veri geçmişini güncelle
            self._update_history(current_price, volume, trades)
            
            # Iceberg detection
            iceberg_signals = self._detect_iceberg_orders()
            signals.extend(iceberg_signals)
            
            # Dark pool detection
            dark_pool_signals = self._detect_dark_pool_activity()
            signals.extend(dark_pool_signals)
            
            # Block trade detection
            block_signals = self._detect_block_trades()
            signals.extend(block_signals)
            
            # Hidden limit orders
            hidden_limit_signals = self._detect_hidden_limits()
            signals.extend(hidden_limit_signals)
            
            return signals
            
        except Exception as e:
            print(f"Gizli emir tespit hatası: {e}")
            return []
    
    def _update_history(self, price: float, volume: float, trades: List[Tuple[float, float, int]]):
        """Geçmiş verileri günceller"""
        timestamp = pd.Timestamp.now()
        
        self.price_history.append(price)
        self.volume_history.append(volume)
        
        # Order flow analizi
        flow_analysis = self._analyze_order_flow(trades)
        self.order_flow_history.append(flow_analysis)
    
    def _analyze_order_flow(self, trades: List[Tuple[float, float, int]]) -> OrderFlowAnalysis:
        """Order flow'u analiz eder"""
        if not trades:
            return OrderFlowAnalysis(0, 0, 0, 0, 0, 0)
        
        buy_volume = sum(size for price, size, ts in trades if size > 0)
        sell_volume = sum(-size for price, size, ts in trades if size < 0)
        
        total_volume = buy_volume + sell_volume
        
        # Block activity detection
        large_trades = [size for _, size, _ in trades if abs(size) > 1000]
        block_activity = len(large_trades)
        
        # Dark pool estimation (unusual patterns)
        unusual_volume = max(0, total_volume - np.mean(list(self.volume_history)) * 2)
        dark_pool_volume = unusual_volume * 0.3  # %30'u dark pool varsayımı
        
        return OrderFlowAnalysis(
            buy_pressure=buy_volume,
            sell_pressure=sell_volume,
            net_flow=buy_volume - sell_volume,
            flow_intensity=total_volume,
            block_activity=block_activity,
            dark_pool_volume=dark_pool_volume
        )
    
    def _detect_iceberg_orders(self) -> List[HiddenOrderSignal]:
        """Iceberg emirlerini tespit eder"""
        signals = []
        
        if len(self.price_history) < 10:
            return signals
        
        try:
            # Price continuity analysis
            price_array = np.array(self.price_history)
            volume_array = np.array(self.volume_history)
            
            # Sudden price moves with consistent volume
            price_changes = np.diff(price_array)
            volume_consistency = np.std(volume_array) / np.mean(volume_array) if np.mean(volume_array) > 0 else 0
            
            # Detect regular execution patterns
            regular_patterns = self._find_regular_patterns(price_array, volume_array)
            
            for pattern in regular_patterns:
                if pattern['regularity'] > 0.7 and pattern['volume_consistency'] > 0.8:
                    # Iceberg detected
                    estimated_size = pattern['avg_size'] * pattern['frequency']
                    confidence = pattern['regularity'] * pattern['volume_consistency']
                    
                    signals.append(HiddenOrderSignal(
                        order_type="iceberg",
                        estimated_size=estimated_size,
                        confidence=min(confidence, 1.0),
                        time_to_completion=self._estimate_completion_time(estimated_size),
                        execution_rate=pattern['frequency'],
                        price_impact=self._estimate_price_impact(estimated_size),
                        detection_timestamp=pd.Timestamp.now()
                    ))
        
        except Exception as e:
            print(f"Iceberg tespit hatası: {e}")
        
        return signals
    
    def _find_regular_patterns(self, prices: np.ndarray, volumes: np.ndarray) -> List[Dict]:
        """Düzenli execution pattern'lerini bulur"""
        patterns = []
        
        try:
            # Sliding window analysis
            window = min(20, len(prices) // 3)
            
            for start in range(0, len(prices) - window, window // 2):
                window_prices = prices[start:start + window]
                window_volumes = volumes[start:start + window]
                
                # Volume regularity
                vol_std = np.std(window_volumes)
                vol_mean = np.mean(window_volumes)
                volume_consistency = 1 - (vol_std / vol_mean) if vol_mean > 0 else 0
                
                # Price stability (iceberg indicator)
                price_std = np.std(window_prices)
                price_mean = np.mean(window_prices)
                price_stability = 1 - (price_std / price_mean) if price_mean > 0 else 0
                
                # Frequency analysis (regular intervals)
                frequency = self._calculate_execution_frequency(window_volumes)
                
                patterns.append({
                    'regularity': price_stability,
                    'volume_consistency': volume_consistency,
                    'avg_size': vol_mean,
                    'frequency': frequency,
                    'price_impact': price_std / price_mean if price_mean > 0 else 0
                })
        
        except Exception as e:
            print(f"Pattern analiz hatası: {e}")
        
        return patterns
    
    def _calculate_execution_frequency(self, volumes: np.ndarray) -> float:
        """Execution frequency hesaplar"""
        try:
            non_zero_volumes = volumes[volumes > 0]
            if len(non_zero_volumes) < 2:
                return 0
            
            # Time between executions
            execution_intervals = []
            for i in range(1, len(non_zero_volumes)):
                if non_zero_volumes[i] > 0 and non_zero_volumes[i-1] > 0:
                    execution_intervals.append(1)  # Adjacent executions
            
            return len(execution_intervals) / len(volumes)
        except Exception:
            return 0
    
    def _detect_dark_pool_activity(self) -> List[HiddenOrderSignal]:
        """Dark pool aktivitesini tespit eder"""
        signals = []
        
        try:
            if len(self.order_flow_history) < 5:
                return signals
            
            recent_flows = list(self.order_flow_history)[-5:]
            
            # Unusual volume spikes
            recent_volumes = [flow.flow_intensity for flow in recent_flows]
            avg_volume = np.mean(recent_volumes)
            volume_spike = max(recent_volumes) > avg_volume * 2
            
            # Block activity correlation
            block_activity = sum(flow.block_activity for flow in recent_flows)
            dark_pool_estimate = block_activity * 0.2  # 20% block activity estimation
            
            if volume_spike and dark_pool_estimate > self.min_iceberg_size:
                signals.append(HiddenOrderSignal(
                    order_type="dark_pool",
                    estimated_size=dark_pool_estimate,
                    confidence=0.6,
                    time_to_completion=self._estimate_completion_time(dark_pool_estimate),
                    execution_rate=0.1,
                    price_impact=self._estimate_price_impact(dark_pool_estimate) * 1.5,
                    detection_timestamp=pd.Timestamp.now()
                ))
        
        except Exception as e:
            print(f"Dark pool tespit hatası: {e}")
        
        return signals
    
    def _detect_block_trades(self) -> List[HiddenOrderSignal]:
        """Block trade'leri tespit eder"""
        signals = []
        
        try:
            if len(self.order_flow_history) < 3:
                return signals
            
            recent_flows = list(self.order_flow_history)[-3:]
            total_block_activity = sum(flow.block_activity for flow in recent_flows)
            
            if total_block_activity > 2:  # Multiple block trades detected
                estimated_block_size = total_block_activity * 500  # Average block size estimate
                
                signals.append(HiddenOrderSignal(
                    order_type="block_trade",
                    estimated_size=estimated_block_size,
                    confidence=0.8,
                    time_to_completion=5,  # Quick execution expected
                    execution_rate=1.0,
                    price_impact=self._estimate_price_impact(estimated_block_size) * 2,
                    detection_timestamp=pd.Timestamp.now()
                ))
        
        except Exception as e:
            print(f"Block trade tespit hatası: {e}")
        
        return signals
    
    def _detect_hidden_limits(self) -> List[HiddenOrderSignal]:
        """Hidden limit order'ları tespit eder"""
        signals = []
        
        try:
            if len(self.price_history) < 15:
                return signals
            
            price_array = np.array(self.price_history)
            
            # Support/Resistance levels with unusual stickiness
            price_std = np.std(price_array)
            recent_prices = price_array[-5:]
            recent_std = np.std(recent_prices)
            
            # Price sticking indicates hidden liquidity
            if recent_std < price_std * 0.5:
                # Calculate potential hidden size at this level
                avg_volume = np.mean(list(self.volume_history))
                sticking_strength = 1 - (recent_std / price_std) if price_std > 0 else 0
                
                estimated_hidden_size = avg_volume * sticking_strength * 2
                
                if estimated_hidden_size > self.min_iceberg_size:
                    signals.append(HiddenOrderSignal(
                        order_type="hidden_limit",
                        estimated_size=estimated_hidden_size,
                        confidence=sticking_strength * 0.7,
                        time_to_completion=self._estimate_completion_time(estimated_hidden_size),
                        execution_rate=0.05,  # Slow execution for limits
                        price_impact=price_std * sticking_strength,
                        detection_timestamp=pd.Timestamp.now()
                    ))
        
        except Exception as e:
            print(f"Hidden limit tespit hatası: {e}")
        
        return signals
    
    def _estimate_completion_time(self, size: float) -> int:
        """Iceberg tamamlanma süresini tahmin eder"""
        if not self.volume_history:
            return 10  # Default
        
        avg_volume = np.mean(list(self.volume_history))
        if avg_volume == 0:
            return 10
        
        execution_rate = avg_volume * 0.1  # 10% of average volume per period
        return max(1, int(size / execution_rate))
    
    def _estimate_price_impact(self, size: float) -> float:
        """Price impact tahmini yapar"""
        if not self.volume_history:
            return 0
        
        total_volume = sum(self.volume_history)
        if total_volume == 0:
            return 0
        
        volume_ratio = size / total_volume
        # Square root model for price impact
        impact = math.sqrt(volume_ratio) * 0.01  # 1% per unit volume ratio
        return impact
    
    def get_detection_statistics(self) -> Dict:
        """Tespit istatistiklerini getirir"""
        if not self.order_flow_history:
            return {}
        
        flows = list(self.order_flow_history)
        return {
            'total_detections': len(flows),
            'avg_buy_pressure': np.mean([f.buy_pressure for f in flows]),
            'avg_sell_pressure': np.mean([f.sell_pressure for f in flows]),
            'total_block_activity': sum(f.block_activity for f in flows),
            'estimated_dark_pool_volume': sum(f.dark_pool_volume for f in flows)
        }
    
    def clear_history(self):
        """Geçmişi temizler"""
        self.price_history.clear()
        self.volume_history.clear()
        self.order_flow_history.clear()
        self.execution_patterns.clear()