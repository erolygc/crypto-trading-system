"""
Real-time Iceberg Monitoring System

Real-time olarak iceberg tespiti ve takibi yapan sistem.
Streaming data processing, real-time alerts ve dashboard integration.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Callable
from dataclasses import dataclass, field
from collections import deque, defaultdict
from datetime import datetime, timedelta
import json
import threading
import time
from concurrent.futures import ThreadPoolExecutor
import warnings
warnings.filterwarnings('ignore')


@dataclass
class IcebergAlert:
    """Iceberg uyarısı"""
    alert_id: str
    iceberg_type: str  # "detected", "sized", "executing", "completed", "disappeared"
    confidence: float
    estimated_size: float
    current_execution: float
    remaining_size: float
    price_impact: float
    execution_rate: float
    timestamp: pd.Timestamp
    priority: str  # "low", "medium", "high", "critical"
    message: str


@dataclass
class MonitoringSession:
    """Monitoring oturum bilgisi"""
    session_id: str
    start_time: pd.Timestamp
    end_time: Optional[pd.Timestamp]
    total_alerts: int
    iceberg_detections: int
    execution_rate: float
    market_conditions: Dict[str, float]
    active_icebergs: List[str] = field(default_factory=list)


@dataclass
class RealTimeMetrics:
    """Real-time metrikler"""
    current_iceberg_count: int
    total_hidden_volume: float
    execution_intensity: float
    market_impact_score: float
    detection_accuracy: float
    alert_frequency: float  # alerts per minute


class IcebergMonitor:
    """
    Real-time iceberg monitoring sistemi
    """
    
    def __init__(self, 
                 alert_callback: Optional[Callable] = None,
                 monitoring_interval: float = 1.0,  # seconds
                 detection_threshold: float = 0.6):
        """
        Args:
            alert_callback: Alert callback fonksiyonu
            monitoring_interval: Monitoring aralığı (saniye)
            detection_threshold: Tespit eşiği
        """
        self.alert_callback = alert_callback
        self.monitoring_interval = monitoring_interval
        self.detection_threshold = detection_threshold
        
        # Real-time data streams
        self.order_stream = deque(maxlen=10000)
        self.quote_stream = deque(maxlen=10000)
        self.trade_stream = deque(maxlen=10000)
        self.price_stream = deque(maxlen=1000)
        
        # Tracking dictionaries
        self.active_icebergs = {}  # iceberg_id -> iceberg_data
        self.iceberg_history = deque(maxlen=500)
        self.monitoring_sessions = {}
        
        # Alert management
        self.alert_queue = deque(maxlen=1000)
        self.alert_subscribers = []
        
        # Performance metrics
        self.detection_metrics = defaultdict(int)
        self.execution_metrics = defaultdict(float)
        
        # Threading
        self.monitoring_active = False
        self.monitor_thread = None
        
    def start_monitoring(self, session_name: str = "default") -> str:
        """Real-time monitoring'i başlatır"""
        try:
            session_id = f"{session_name}_{int(time.time())}"
            
            self.monitoring_sessions[session_id] = MonitoringSession(
                session_id=session_id,
                start_time=pd.Timestamp.now(),
                end_time=None,
                total_alerts=0,
                iceberg_detections=0,
                execution_rate=0.0,
                market_conditions={}
            )
            
            # Start monitoring thread
            self.monitoring_active = True
            self.monitor_thread = threading.Thread(target=self._monitoring_loop, args=(session_id,))
            self.monitor_thread.daemon = True
            self.monitor_thread.start()
            
            return session_id
            
        except Exception as e:
            print(f"Monitoring başlatma hatası: {e}")
            return ""
    
    def stop_monitoring(self, session_id: str) -> bool:
        """Monitoring'i durdurur"""
        try:
            if session_id in self.monitoring_sessions:
                session = self.monitoring_sessions[session_id]
                session.end_time = pd.Timestamp.now()
                
                # Stop monitoring
                self.monitoring_active = False
                if self.monitor_thread:
                    self.monitor_thread.join(timeout=5)
                
                return True
            
            return False
            
        except Exception as e:
            print(f"Monitoring durdurma hatası: {e}")
            return False
    
    def _monitoring_loop(self, session_id: str):
        """Ana monitoring döngüsü"""
        try:
            while self.monitoring_active:
                # Process incoming data
                self._process_real_time_data()
                
                # Update active icebergs
                self._update_iceberg_tracking()
                
                # Generate alerts
                self._generate_real_time_alerts()
                
                # Update session metrics
                self._update_session_metrics(session_id)
                
                # Sleep for monitoring interval
                time.sleep(self.monitoring_interval)
                
        except Exception as e:
            print(f"Monitoring döngü hatası: {e}")
    
    def _process_real_time_data(self):
        """Real-time veri işleme"""
        try:
            # Process order stream
            while self.order_stream:
                order = self.order_stream.popleft()
                self._analyze_order_pattern(order)
            
            # Process trade stream  
            while self.trade_stream:
                trade = self.trade_stream.popleft()
                self._analyze_trade_pattern(trade)
            
            # Process quote stream
            while self.quote_stream:
                quote = self.quote_stream.popleft()
                self._analyze_quote_pattern(quote)
                
        except Exception as e:
            print(f"Real-time data processing hatası: {e}")
    
    def _analyze_order_pattern(self, order: Dict):
        """Order pattern analizi"""
        try:
            order_size = order.get('size', 0)
            order_side = order.get('side', 'unknown')
            order_price = order.get('price', 0)
            
            # Check for iceberg indicators in order patterns
            iceberg_indicators = self._detect_iceberg_indicators([order])
            
            for indicator in iceberg_indicators:
                iceberg_id = f"order_{order.get('order_id', 'unknown')}_{int(time.time())}"
                
                if iceberg_id not in self.active_icebergs:
                    self.active_icebergs[iceberg_id] = {
                        'type': 'order_based',
                        'size': order_size,
                        'side': order_side,
                        'price': order_price,
                        'detection_time': pd.Timestamp.now(),
                        'confidence': indicator.get('confidence', 0.5),
                        'execution_progress': 0,
                        'alerts_generated': 0
                    }
                    
                    self._create_iceberg_alert(
                        iceberg_id=iceberg_id,
                        alert_type="detected",
                        confidence=indicator.get('confidence', 0.5),
                        estimated_size=order_size
                    )
                    
        except Exception as e:
            print(f"Order pattern analiz hatası: {e}")
    
    def _analyze_trade_pattern(self, trade: Dict):
        """Trade pattern analizi"""
        try:
            trade_size = trade.get('size', 0)
            trade_price = trade.get('price', 0)
            trade_timestamp = pd.Timestamp.now()
            
            # Update execution tracking for active icebergs
            for iceberg_id, iceberg_data in list(self.active_icebergs.items()):
                if iceberg_data.get('type') in ['execution_based', 'order_based']:
                    # Check if this trade is part of the iceberg execution
                    if self._is_trade_part_of_iceberg(trade, iceberg_data):
                        iceberg_data['execution_progress'] += trade_size
                        iceberg_data['last_update'] = trade_timestamp
                        
                        # Check if execution is complete
                        execution_rate = trade_size
                        if iceberg_data['execution_progress'] >= iceberg_data['size'] * 0.95:
                            self._complete_iceberg(iceberg_id)
                        
                        self.detection_metrics['executions_tracked'] += 1
                        
        except Exception as e:
            print(f"Trade pattern analiz hatası: {e}")
    
    def _analyze_quote_pattern(self, quote: Dict):
        """Quote pattern analizi"""
        try:
            # Detect iceberg indicators from quote patterns
            iceberg_indicators = self._detect_iceberg_from_quotes([quote])
            
            for indicator in iceberg_indicators:
                iceberg_id = f"quote_{int(time.time())}_{len(self.active_icebergs)}"
                
                self.active_icebergs[iceberg_id] = {
                    'type': 'quote_based',
                    'estimated_size': indicator.get('size', 0),
                    'detection_time': pd.Timestamp.now(),
                    'confidence': indicator.get('confidence', 0.5),
                    'execution_progress': 0,
                    'quote_pattern': indicator
                }
                
                self._create_iceberg_alert(
                    iceberg_id=iceberg_id,
                    alert_type="detected",
                    confidence=indicator.get('confidence', 0.5),
                    estimated_size=indicator.get('size', 0)
                )
                
        except Exception as e:
            print(f"Quote pattern analiz hatası: {e}")
    
    def _detect_iceberg_indicators(self, orders: List[Dict]) -> List[Dict]:
        """Iceberg göstergelerini tespit eder (basitleştirilmiş)"""
        indicators = []
        
        try:
            for order in orders:
                order_size = order.get('size', 0)
                order_frequency = self._calculate_order_frequency()
                
                # Simple iceberg detection rules
                if order_size > 1000 and order_frequency > 0.1:
                    indicators.append({
                        'confidence': min(order_size / 10000, 1.0),
                        'type': 'large_order_sequence',
                        'size': order_size
                    })
                    
        except Exception as e:
            print(f"Iceberg indicator detection hatası: {e}")
        
        return indicators
    
    def _detect_iceberg_from_quotes(self, quotes: List[Dict]) -> List[Dict]:
        """Quote'lardan iceberg tespiti"""
        indicators = []
        
        try:
            # Analyze quote consistency patterns
            quote_sizes = []
            for quote in quotes:
                bid_size = quote.get('bid_size', 0)
                ask_size = quote.get('ask_size', 0)
                quote_sizes.extend([bid_size, ask_size])
            
            if len(quote_sizes) >= 3:
                # Check for consistent sizes (iceberg indicator)
                size_variance = np.var(quote_sizes)
                size_mean = np.mean(quote_sizes)
                
                if size_variance < (size_mean * 0.1) and size_mean > 500:
                    indicators.append({
                        'confidence': 0.7,
                        'type': 'quote_consistency',
                        'size': size_mean * 10  # Estimated total iceberg size
                    })
                    
        except Exception as e:
            print(f"Quote-based iceberg detection hatası: {e}")
        
        return indicators
    
    def _calculate_order_frequency(self) -> float:
        """Order frequency hesaplama"""
        try:
            if len(self.order_stream) < 2:
                return 0
            
            # Simple frequency calculation
            recent_orders = list(self.order_stream)[-10:]
            return len(recent_orders) / 60  # orders per minute (approximation)
            
        except Exception:
            return 0
    
    def _is_trade_part_of_iceberg(self, trade: Dict, iceberg_data: Dict) -> bool:
        """Trade'in iceberg'in parçası olup olmadığını kontrol eder"""
        try:
            trade_size = trade.get('size', 0)
            trade_price = trade.get('price', 0)
            
            iceberg_price = iceberg_data.get('price', 0)
            iceberg_side = iceberg_data.get('side', 'unknown')
            
            # Simple heuristic: similar price level and reasonable size
            if iceberg_price > 0:
                price_diff = abs(trade_price - iceberg_price) / iceberg_price
                size_ratio = trade_size / iceberg_data.get('size', 1)
                
                return price_diff < 0.001 and 0.1 < size_ratio < 2.0  # 0.1% price diff, 0.1x to 2x size
            
            return False
            
        except Exception:
            return False
    
    def _update_iceberg_tracking(self):
        """Iceberg tracking'i günceller"""
        try:
            current_time = pd.Timestamp.now()
            
            # Update all active icebergs
            for iceberg_id, iceberg_data in list(self.active_icebergs.items()):
                # Check for stale icebergs (no updates for > 5 minutes)
                last_update = iceberg_data.get('last_update', iceberg_data.get('detection_time'))
                time_since_update = (current_time - last_update).total_seconds()
                
                if time_since_update > 300:  # 5 minutes
                    self._deactivate_iceberg(iceberg_id, reason="timeout")
                    continue
                
                # Update execution metrics
                iceberg_data['age_seconds'] = (current_time - iceberg_data['detection_time']).total_seconds()
                
                # Calculate execution rate
                if iceberg_data['age_seconds'] > 0:
                    iceberg_data['execution_rate'] = iceberg_data['execution_progress'] / iceberg_data['age_seconds']
                
        except Exception as e:
            print(f"Iceberg tracking update hatası: {e}")
    
    def _generate_real_time_alerts(self):
        """Real-time alert üretimi"""
        try:
            for iceberg_id, iceberg_data in self.active_icebergs.items():
                # Check alert conditions
                alert_conditions = {
                    'size_threshold': iceberg_data.get('estimated_size', 0) > 5000,
                    'execution_threshold': iceberg_data.get('execution_progress', 0) > 1000,
                    'confidence_threshold': iceberg_data.get('confidence', 0) > 0.7,
                    'age_threshold': iceberg_data.get('age_seconds', 0) > 60
                }
                
                # Generate alerts based on conditions
                if alert_conditions['size_threshold']:
                    self._create_iceberg_alert(
                        iceberg_id=iceberg_id,
                        alert_type="sized",
                        confidence=iceberg_data['confidence'],
                        estimated_size=iceberg_data.get('estimated_size', 0)
                    )
                
                if alert_conditions['execution_threshold']:
                    self._create_iceberg_alert(
                        iceberg_id=iceberg_id,
                        alert_type="executing",
                        confidence=iceberg_data['confidence'],
                        estimated_size=iceberg_data.get('size', 0),
                        current_execution=iceberg_data.get('execution_progress', 0)
                    )
                
        except Exception as e:
            print(f"Real-time alert generation hatası: {e}")
    
    def _create_iceberg_alert(self, iceberg_id: str, alert_type: str, 
                            confidence: float, estimated_size: float,
                            current_execution: float = 0):
        """Iceberg alert oluşturur"""
        try:
            alert_id = f"{iceberg_id}_{alert_type}_{int(time.time())}"
            
            # Determine priority
            if confidence > 0.9:
                priority = "critical"
            elif confidence > 0.7:
                priority = "high"
            elif confidence > 0.5:
                priority = "medium"
            else:
                priority = "low"
            
            alert = IcebergAlert(
                alert_id=alert_id,
                iceberg_type=alert_type,
                confidence=confidence,
                estimated_size=estimated_size,
                current_execution=current_execution,
                remaining_size=max(0, estimated_size - current_execution),
                price_impact=0,  # Would be calculated based on market data
                execution_rate=0,  # Would be calculated based on timing
                timestamp=pd.Timestamp.now(),
                priority=priority,
                message=f"Iceberg {alert_type} detected: {estimated_size:.0f} units with {confidence:.2f} confidence"
            )
            
            self.alert_queue.append(alert)
            
            # Update iceberg data
            if iceberg_id in self.active_icebergs:
                self.active_icebergs[iceberg_id]['alerts_generated'] = \
                    self.active_icebergs[iceberg_id].get('alerts_generated', 0) + 1
            
            # Send to callback
            if self.alert_callback:
                self.alert_callback(alert)
            
        except Exception as e:
            print(f"Iceberg alert oluşturma hatası: {e}")
    
    def _complete_iceberg(self, iceberg_id: str):
        """Iceberg'i tamamlandı olarak işaretler"""
        try:
            if iceberg_id in self.active_icebergs:
                iceberg_data = self.active_icebergs[iceberg_id]
                
                self._create_iceberg_alert(
                    iceberg_id=iceberg_id,
                    alert_type="completed",
                    confidence=iceberg_data['confidence'],
                    estimated_size=iceberg_data.get('size', 0),
                    current_execution=iceberg_data.get('execution_progress', 0)
                )
                
                # Move to history
                iceberg_data['completion_time'] = pd.Timestamp.now()
                self.iceberg_history.append(iceberg_data)
                
                # Remove from active tracking
                del self.active_icebergs[iceberg_id]
                
        except Exception as e:
            print(f"Iceberg completion hatası: {e}")
    
    def _deactivate_iceberg(self, iceberg_id: str, reason: str = "unknown"):
        """Iceberg'i deaktif hale getirir"""
        try:
            if iceberg_id in self.active_icebergs:
                iceberg_data = self.active_icebergs[iceberg_id]
                iceberg_data['deactivation_reason'] = reason
                iceberg_data['deactivation_time'] = pd.Timestamp.now()
                
                self.iceberg_history.append(iceberg_data)
                del self.active_icebergs[iceberg_id]
                
        except Exception as e:
            print(f"Iceberg deactivation hatası: {e}")
    
    def _update_session_metrics(self, session_id: str):
        """Session metriklerini günceller"""
        try:
            if session_id in self.monitoring_sessions:
                session = self.monitoring_sessions[session_id]
                
                # Update metrics
                session.total_alerts = len(self.alert_queue)
                session.iceberg_detections = len(self.active_icebergs)
                session.active_icebergs = list(self.active_icebergs.keys())
                
                # Calculate execution rate
                if session.iceberg_detections > 0:
                    total_execution = sum(iceberg.get('execution_progress', 0) 
                                        for iceberg in self.active_icebergs.values())
                    total_time = sum(iceberg.get('age_seconds', 0) 
                                   for iceberg in self.active_icebergs.values())
                    
                    session.execution_rate = total_execution / max(total_time, 1)
                    
        except Exception as e:
            print(f"Session metrics update hatası: {e}")
    
    def add_order_data(self, order: Dict):
        """Order verisi ekleme"""
        self.order_stream.append(order)
    
    def add_trade_data(self, trade: Dict):
        """Trade verisi ekleme"""
        self.trade_stream.append(trade)
    
    def add_quote_data(self, quote: Dict):
        """Quote verisi ekleme"""
        self.quote_stream.append(quote)
    
    def add_price_data(self, price: float):
        """Price verisi ekleme"""
        self.price_stream.append(price)
    
    def subscribe_to_alerts(self, callback: Callable[[IcebergAlert], None]):
        """Alert aboneliği"""
        self.alert_subscribers.append(callback)
    
    def get_real_time_metrics(self, session_id: str) -> RealTimeMetrics:
        """Real-time metrikleri getirir"""
        try:
            if session_id in self.monitoring_sessions:
                session = self.monitoring_sessions[session_id]
                
                current_time = pd.Timestamp.now()
                session_duration = (current_time - session.start_time).total_seconds()
                
                return RealTimeMetrics(
                    current_iceberg_count=len(self.active_icebergs),
                    total_hidden_volume=sum(iceberg.get('size', 0) for iceberg in self.active_icebergs.values()),
                    execution_intensity=session.execution_rate,
                    market_impact_score=self._calculate_market_impact_score(),
                    detection_accuracy=self._calculate_detection_accuracy(),
                    alert_frequency=session.total_alerts / max(session_duration / 60, 1)  # alerts per minute
                )
            
            return RealTimeMetrics(0, 0, 0, 0, 0, 0)
            
        except Exception as e:
            print(f"Real-time metrics hatası: {e}")
            return RealTimeMetrics(0, 0, 0, 0, 0, 0)
    
    def _calculate_market_impact_score(self) -> float:
        """Market impact skoru hesaplama"""
        try:
            if not self.active_icebergs:
                return 0
            
            # Simple impact calculation based on active iceberg sizes
            total_size = sum(iceberg.get('size', 0) for iceberg in self.active_icebergs.values())
            avg_confidence = np.mean([iceberg.get('confidence', 0) for iceberg in self.active_icebergs.values()])
            
            # Normalize impact score
            impact_score = min(total_size / 100000, 1.0) * avg_confidence
            
            return impact_score
            
        except Exception:
            return 0
    
    def _calculate_detection_accuracy(self) -> float:
        """Detection accuracy hesaplama"""
        try:
            total_detections = self.detection_metrics['executions_tracked']
            if total_detections == 0:
                return 0.5  # Default for no data
            
            # Simple accuracy metric (would be more sophisticated in real implementation)
            completed_icebergs = len(self.iceberg_history)
            accuracy = completed_icebergs / max(total_detections, 1)
            
            return min(accuracy, 1.0)
            
        except Exception:
            return 0.5
    
    def get_monitoring_summary(self, session_id: str) -> Dict:
        """Monitoring özeti getirir"""
        try:
            if session_id not in self.monitoring_sessions:
                return {}
            
            session = self.monitoring_sessions[session_id]
            
            return {
                'session_info': {
                    'session_id': session.session_id,
                    'duration_minutes': (pd.Timestamp.now() - session.start_time).total_seconds() / 60,
                    'status': 'active' if self.monitoring_active else 'stopped'
                },
                'iceberg_statistics': {
                    'active_icebergs': len(self.active_icebergs),
                    'completed_icebergs': len(self.iceberg_history),
                    'total_detections': session.iceberg_detections
                },
                'alert_statistics': {
                    'total_alerts': session.total_alerts,
                    'critical_alerts': len([alert for alert in self.alert_queue if alert.priority == 'critical']),
                    'high_priority_alerts': len([alert for alert in self.alert_queue if alert.priority == 'high'])
                },
                'performance_metrics': {
                    'avg_execution_rate': session.execution_rate,
                    'detection_threshold': self.detection_threshold,
                    'monitoring_interval': self.monitoring_interval
                }
            }
            
        except Exception as e:
            print(f"Monitoring summary hatası: {e}")
            return {}
    
    def export_alert_history(self, format_type: str = "json") -> str:
        """Alert geçmişini export eder"""
        try:
            alerts_data = []
            
            for alert in self.alert_queue:
                alert_dict = {
                    'alert_id': alert.alert_id,
                    'iceberg_type': alert.iceberg_type,
                    'confidence': alert.confidence,
                    'estimated_size': alert.estimated_size,
                    'current_execution': alert.current_execution,
                    'remaining_size': alert.remaining_size,
                    'priority': alert.priority,
                    'timestamp': alert.timestamp.isoformat(),
                    'message': alert.message
                }
                alerts_data.append(alert_dict)
            
            if format_type.lower() == "json":
                return json.dumps(alerts_data, indent=2, default=str)
            else:
                # Could add CSV, XML, etc. format support
                return json.dumps(alerts_data, indent=2, default=str)
                
        except Exception as e:
            print(f"Alert export hatası: {e}")
            return ""
    
    def clear_monitoring_data(self):
        """Monitoring verilerini temizler"""
        try:
            self.order_stream.clear()
            self.quote_stream.clear()
            self.trade_stream.clear()
            self.price_stream.clear()
            self.active_icebergs.clear()
            self.iceberg_history.clear()
            self.alert_queue.clear()
            
            # Reset metrics
            self.detection_metrics.clear()
            self.execution_metrics.clear()
            
        except Exception as e:
            print(f"Monitoring data clear hatası: {e}")