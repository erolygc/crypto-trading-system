"""
Adversarial Trading Detector

Adversarial trading pattern'lerini tespit eden sistem.
Pump and dump, spoofing, layering, quote stuffing gibi manipulation taktikleri.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import deque, defaultdict
import math
from scipy import stats
import warnings
warnings.filterwarnings('ignore')


@dataclass
class AdversarialSignal:
    """Adversarial trading sinyali"""
    signal_type: str  # "spoofing", "layering", "quote_stuffing", "pump_dump"
    confidence: float
    severity: str  # "low", "medium", "high", "critical"
    evidence_count: int
    time_window: int  # seconds
    price_impact: float
    market_manipulation_score: float


@dataclass
class ManipulationPattern:
    """Manipulation pattern bilgisi"""
    pattern_type: str
    detection_timestamp: pd.Timestamp
    involved_parties: List[str]
    execution_timeline: List[pd.Timestamp]
    price_manipulation_range: Tuple[float, float]
    volume_anomalies: Dict[str, float]
    confidence_score: float


class AdversarialDetector:
    """
    Adversarial trading tespit sistemi
    """
    
    def __init__(self, analysis_window: int = 300, min_pattern_length: int = 10):
        """
        Args:
            analysis_window: Analiz penceresi (saniye)
            min_pattern_length: Minimum pattern uzunluğu
        """
        self.analysis_window = analysis_window
        self.min_pattern_length = min_pattern_length
        self.order_history = deque(maxlen=1000)
        self.quote_history = deque(maxlen=1000)
        self.price_history = deque(maxlen=analysis_window)
        self.volume_history = deque(maxlen=analysis_window)
        self.detection_threshold = 0.7
        
    def detect_adversarial_patterns(self, orders: List[Dict], 
                                  quotes: List[Dict], 
                                  trades: List[Dict]) -> List[AdversarialSignal]:
        """
        Adversarial pattern'leri tespit eder
        
        Args:
            orders: Order verileri
            quotes: Quote verileri  
            trades: Trade verileri
            
        Returns:
            Tespit edilen adversarial sinyaller
        """
        try:
            signals = []
            
            # Update histories
            self._update_histories(orders, quotes, trades)
            
            if len(self.order_history) < self.min_pattern_length:
                return signals
            
            # Pattern 1: Spoofing Detection
            spoofing_signals = self._detect_spoofing(quotes)
            signals.extend(spoofing_signals)
            
            # Pattern 2: Layering Detection
            layering_signals = self._detect_layering(orders)
            signals.extend(layering_signals)
            
            # Pattern 3: Quote Stuffing Detection
            stuffing_signals = self._detect_quote_stuffing(quotes)
            signals.extend(stuffing_signals)
            
            # Pattern 4: Pump and Dump Detection
            pump_dump_signals = self._detect_pump_and_dump(trades)
            signals.extend(pump_dump_signals)
            
            # Pattern 5: Wash Trading Detection
            wash_trading_signals = self._detect_wash_trading(trades)
            signals.extend(wash_trading_signals)
            
            # Pattern 6: Front-Running Detection
            front_run_signals = self._detect_front_running(orders, trades)
            signals.extend(front_run_signals)
            
            # Pattern 7: Iceberg Front-Running
            iceberg_front_run_signals = self._detect_iceberg_front_running(orders, trades)
            signals.extend(iceberg_front_run_signals)
            
            return signals
            
        except Exception as e:
            print(f"Adversarial pattern tespit hatası: {e}")
            return []
    
    def _update_histories(self, orders: List[Dict], quotes: List[Dict], trades: List[Dict]):
        """Geçmiş verileri günceller"""
        try:
            timestamp = pd.Timestamp.now()
            
            # Update order history
            for order in orders:
                self.order_history.append({
                    'timestamp': timestamp,
                    'order_id': order.get('order_id', 'unknown'),
                    'side': order.get('side', 'unknown'),
                    'size': order.get('size', 0),
                    'price': order.get('price', 0),
                    'trader_id': order.get('trader_id', 'unknown')
                })
            
            # Update quote history
            for quote in quotes:
                self.quote_history.append({
                    'timestamp': timestamp,
                    'bid_price': quote.get('bid_price', 0),
                    'ask_price': quote.get('ask_price', 0),
                    'bid_size': quote.get('bid_size', 0),
                    'ask_size': quote.get('ask_size', 0),
                    'maker_id': quote.get('maker_id', 'unknown')
                })
            
            # Update price/volume history
            for trade in trades:
                self.price_history.append(trade.get('price', 0))
                self.volume_history.append(trade.get('size', 0))
                
        except Exception as e:
            print(f"Geçmiş güncelleme hatası: {e}")
    
    def _detect_spoofing(self, quotes: List[Dict]) -> List[AdversarialSignal]:
        """Spoofing pattern'lerini tespit eder"""
        signals = []
        
        try:
            if len(quotes) < 20:
                return signals
            
            # Analyze quote withdrawal patterns
            quote_groups = defaultdict(list)
            for quote in quotes:
                timestamp = quote.get('timestamp', pd.Timestamp.now())
                time_key = timestamp.floor('1min')  # Group by minute
                quote_groups[time_key].append(quote)
            
            suspicious_patterns = 0
            for time_group, group_quotes in quote_groups.items():
                if len(group_quotes) < 5:
                    continue
                
                # Look for large quotes that get quickly withdrawn
                large_quotes = [q for q in group_quotes if 
                              q.get('bid_size', 0) > 1000 or q.get('ask_size', 0) > 1000]
                
                if len(large_quotes) > 2:
                    # Check if these large quotes appear and disappear quickly
                    quote_changes = len(group_quotes) / 60  # Quotes per minute
                    if quote_changes > 10:  # More than 10 quotes per minute
                        suspicious_patterns += 1
            
            if suspicious_patterns > 2:
                confidence = min(suspicious_patterns / 10, 1.0)
                signals.append(AdversarialSignal(
                    signal_type="spoofing",
                    confidence=confidence,
                    severity=self._classify_severity(confidence),
                    evidence_count=suspicious_patterns,
                    time_window=60,
                    price_impact=0.001,  # Small price impact typical of spoofing
                    market_manipulation_score=confidence * 0.8
                ))
        
        except Exception as e:
            print(f"Spoofing tespit hatası: {e}")
        
        return signals
    
    def _detect_layering(self, orders: List[Dict]) -> List[AdversarialSignal]:
        """Layering pattern'lerini tespit eder"""
        signals = []
        
        try:
            if len(orders) < 15:
                return signals
            
            # Group orders by trader
            trader_orders = defaultdict(list)
            for order in orders:
                trader_id = order.get('trader_id', 'unknown')
                if trader_id != 'unknown':
                    trader_orders[trader_id].append(order)
            
            layering_detected = False
            for trader_id, trader_order_list in trader_orders.items():
                if len(trader_order_list) < 5:
                    continue
                
                # Look for multiple orders at different price levels on same side
                bid_orders = [o for o in trader_order_list if o.get('side') == 'buy']
                ask_orders = [o for o in trader_order_list if o.get('side') == 'sell']
                
                # Check for layering on buy side
                if len(bid_orders) >= 3:
                    bid_prices = [o.get('price', 0) for o in bid_orders]
                    price_spread = max(bid_prices) - min(bid_prices) if bid_prices else 0
                    price_levels = len(set(round(p, 2) for p in bid_prices))  # Unique price levels
                    
                    # Layering: multiple orders at different levels
                    if price_levels >= 3 and price_spread > 0.001:
                        layering_detected = True
                        confidence = min(price_levels / 5, 1.0)
                        
                        signals.append(AdversarialSignal(
                            signal_type="layering",
                            confidence=confidence,
                            severity=self._classify_severity(confidence),
                            evidence_count=price_levels,
                            time_window=300,
                            price_impact=price_spread,
                            market_manipulation_score=confidence * 0.7
                        ))
                        break
            
            # Similar check for sell side
            if not layering_detected:
                for trader_id, trader_order_list in trader_orders.items():
                    if len(trader_order_list) < 5:
                        continue
                    
                    ask_orders = [o for o in trader_order_list if o.get('side') == 'sell']
                    if len(ask_orders) >= 3:
                        ask_prices = [o.get('price', 0) for o in ask_orders]
                        price_spread = max(ask_prices) - min(ask_prices) if ask_prices else 0
                        price_levels = len(set(round(p, 2) for p in ask_prices))
                        
                        if price_levels >= 3 and price_spread > 0.001:
                            confidence = min(price_levels / 5, 1.0)
                            
                            signals.append(AdversarialSignal(
                                signal_type="layering",
                                confidence=confidence,
                                severity=self._classify_severity(confidence),
                                evidence_count=price_levels,
                                time_window=300,
                                price_impact=price_spread,
                                market_manipulation_score=confidence * 0.7
                            ))
                            break
        
        except Exception as e:
            print(f"Layering tespit hatası: {e}")
        
        return signals
    
    def _detect_quote_stuffing(self, quotes: List[Dict]) -> List[AdversarialSignal]:
        """Quote stuffing pattern'lerini tespit eder"""
        signals = []
        
        try:
            if len(quotes) < 50:
                return signals
            
            # Analyze quote frequency by maker
            maker_frequencies = defaultdict(int)
            time_windows = []
            
            # Count quotes per second
            quote_timestamps = [pd.to_datetime(q.get('timestamp', pd.Timestamp.now())) for q in quotes]
            
            # Group by second
            for timestamp in quote_timestamps:
                time_key = timestamp.floor('1s')
                time_windows.append(time_key)
            
            from collections import Counter
            time_counts = Counter(time_windows)
            
            # Check for excessive quote frequency
            max_quotes_per_second = max(time_counts.values()) if time_counts else 0
            avg_quotes_per_second = np.mean(list(time_counts.values())) if time_counts else 0
            
            if max_quotes_per_second > avg_quotes_per_second * 10:
                stuffing_ratio = max_quotes_per_second / avg_quotes_per_second
                confidence = min(stuffing_ratio / 20, 1.0)  # Normalize confidence
                
                signals.append(AdversarialSignal(
                    signal_type="quote_stuffing",
                    confidence=confidence,
                    severity=self._classify_severity(confidence),
                    evidence_count=max_quotes_per_second,
                    time_window=1,
                    price_impact=0,  # No direct price impact
                    market_manipulation_score=confidence * 0.6
                ))
        
        except Exception as e:
            print(f"Quote stuffing tespit hatası: {e}")
        
        return signals
    
    def _detect_pump_and_dump(self, trades: List[Dict]) -> List[AdversarialSignal]:
        """Pump and dump pattern'lerini tespit eder"""
        signals = []
        
        try:
            if len(trades) < 20:
                return signals
            
            # Analyze price movements
            prices = [trade.get('price', 0) for trade in trades if trade.get('price', 0) > 0]
            volumes = [trade.get('size', 0) for trade in trades if trade.get('size', 0) > 0]
            
            if len(prices) < 10:
                return signals
            
            # Calculate price changes
            price_changes = np.diff(prices)
            
            # Pump phase: rapid price increase
            significant_increases = sum(1 for change in price_changes if change > np.std(price_changes))
            
            # Dump phase: rapid price decrease  
            significant_decreases = sum(1 for change in price_changes if change < -np.std(price_changes))
            
            # Volume spike during pump
            if volumes:
                avg_volume = np.mean(volumes)
                volume_spikes = sum(1 for vol in volumes if vol > avg_volume * 2)
                volume_ratio = volume_spikes / len(volumes)
            else:
                volume_ratio = 0
            
            # Pump and dump criteria
            pump_condition = significant_increases > len(price_changes) * 0.3
            dump_condition = significant_decreases > len(price_changes) * 0.3
            volume_condition = volume_ratio > 0.4
            
            if pump_condition and dump_condition and volume_condition:
                confidence = (pump_condition + dump_condition + volume_condition) / 3
                
                signals.append(AdversarialSignal(
                    signal_type="pump_and_dump",
                    confidence=confidence,
                    severity=self._classify_severity(confidence),
                    evidence_count=significant_increases + significant_decreases,
                    time_window=300,
                    price_impact=max(prices) - min(prices) if prices else 0,
                    market_manipulation_score=confidence
                ))
        
        except Exception as e:
            print(f"Pump and dump tespit hatası: {e}")
        
        return signals
    
    def _detect_wash_trading(self, trades: List[Dict]) -> List[AdversarialSignal]:
        """Wash trading pattern'lerini tespit eder"""
        signals = []
        
        try:
            if len(trades) < 10:
                return signals
            
            # Group trades by trader
            trader_trades = defaultdict(list)
            for trade in trades:
                trader_id = trade.get('trader_id', 'unknown')
                if trader_id != 'unknown':
                    trader_trades[trader_id].append(trade)
            
            for trader_id, trader_trade_list in trader_trades.items():
                if len(trader_trade_list) < 5:
                    continue
                
                # Look for buy and sell trades at similar prices (wash trading indicator)
                buy_trades = [t for t in trader_trade_list if t.get('side') == 'buy']
                sell_trades = [t for t in trader_trade_list if t.get('side') == 'sell']
                
                if len(buy_trades) >= 2 and len(sell_trades) >= 2:
                    # Check for similar prices
                    buy_prices = [t.get('price', 0) for t in buy_trades]
                    sell_prices = [t.get('price', 0) for t in sell_trades]
                    
                    similar_price_pairs = 0
                    for buy_price in buy_prices:
                        for sell_price in sell_prices:
                            if abs(buy_price - sell_price) / buy_price < 0.001:  # Within 0.1%
                                similar_price_pairs += 1
                    
                    if similar_price_pairs > 1:
                        wash_ratio = similar_price_pairs / (len(buy_trades) * len(sell_trades))
                        confidence = min(wash_ratio, 1.0)
                        
                        signals.append(AdversarialSignal(
                            signal_type="wash_trading",
                            confidence=confidence,
                            severity=self._classify_severity(confidence),
                            evidence_count=similar_price_pairs,
                            time_window=600,
                            price_impact=0.0005,  # Minimal price impact
                            market_manipulation_score=confidence * 0.5
                        ))
        
        except Exception as e:
            print(f"Wash trading tespit hatası: {e}")
        
        return signals
    
    def _detect_front_running(self, orders: List[Dict], trades: List[Dict]) -> List[AdversarialSignal]:
        """Front-running pattern'lerini tespit eder"""
        signals = []
        
        try:
            if len(orders) < 10 or len(trades) < 10:
                return signals
            
            # Look for trades that occur just after large orders
            large_orders = [o for o in orders if o.get('size', 0) > 5000]  # Large order threshold
            
            suspicious_executions = 0
            for large_order in large_orders:
                order_time = pd.to_datetime(large_order.get('timestamp', pd.Timestamp.now()))
                
                # Check for trades shortly after the large order
                quick_trades = [t for t in trades if 
                              abs((pd.to_datetime(t.get('timestamp', pd.Timestamp.now())) - order_time).total_seconds()) < 5]
                
                if len(quick_trades) > 3:
                    suspicious_executions += 1
            
            if suspicious_executions > len(large_orders) * 0.3:  # More than 30% of large orders trigger quick trades
                confidence = suspicious_executions / len(large_orders)
                
                signals.append(AdversarialSignal(
                    signal_type="front_running",
                    confidence=confidence,
                    severity=self._classify_severity(confidence),
                    evidence_count=suspicious_executions,
                    time_window=5,
                    price_impact=0.002,  # Small but consistent impact
                    market_manipulation_score=confidence * 0.8
                ))
        
        except Exception as e:
            print(f"Front-running tespit hatası: {e}")
        
        return signals
    
    def _detect_iceberg_front_running(self, orders: List[Dict], trades: List[Dict]) -> List[AdversarialSignal]:
        """Iceberg front-running tespiti"""
        signals = []
        
        try:
            if len(orders) < 15 or len(trades) < 15:
                return signals
            
            # Detect patterns suggesting iceberg front-running
            # 1. Small orders followed by larger execution
            # 2. Regular execution intervals suggesting hidden order discovery
            
            execution_patterns = self._analyze_execution_patterns(trades)
            
            if execution_patterns.get('regular_intervals', 0) > 0.7:
                # Regular execution intervals suggest iceberg discovery
                confidence = execution_patterns['regular_intervals']
                
                signals.append(AdversarialSignal(
                    signal_type="iceberg_front_running",
                    confidence=confidence,
                    severity=self._classify_severity(confidence),
                    evidence_count=int(confidence * 10),
                    time_window=60,
                    price_impact=execution_patterns.get('avg_price_impact', 0),
                    market_manipulation_score=confidence * 0.9  # High manipulation score
                ))
        
        except Exception as e:
            print(f"Iceberg front-running tespit hatası: {e}")
        
        return signals
    
    def _analyze_execution_patterns(self, trades: List[Dict]) -> Dict:
        """Execution pattern'lerini analiz eder"""
        try:
            if len(trades) < 10:
                return {}
            
            # Time intervals between trades
            timestamps = [pd.to_datetime(t.get('timestamp', pd.Timestamp.now())) for t in trades]
            intervals = [(timestamps[i] - timestamps[i-1]).total_seconds() 
                        for i in range(1, len(timestamps))]
            
            # Regularity analysis
            if intervals:
                avg_interval = np.mean(intervals)
                interval_std = np.std(intervals)
                regularity = 1 - (interval_std / avg_interval) if avg_interval > 0 else 0
            else:
                regularity = 0
            
            # Price impact analysis
            prices = [t.get('price', 0) for t in trades if t.get('price', 0) > 0]
            if len(prices) > 1:
                price_changes = np.abs(np.diff(prices))
                avg_price_impact = np.mean(price_changes) / np.mean(prices) if np.mean(prices) > 0 else 0
            else:
                avg_price_impact = 0
            
            return {
                'regular_intervals': regularity,
                'avg_price_impact': avg_price_impact,
                'avg_interval': np.mean(intervals) if intervals else 0
            }
            
        except Exception as e:
            print(f"Execution pattern analiz hatası: {e}")
            return {}
    
    def _classify_severity(self, confidence: float) -> str:
        """Confidence skoruna göre severity sınıflandırması"""
        if confidence >= 0.9:
            return "critical"
        elif confidence >= 0.7:
            return "high"
        elif confidence >= 0.5:
            return "medium"
        else:
            return "low"
    
    def calculate_market_manipulation_risk(self, signals: List[AdversarialSignal]) -> Dict:
        """Market manipulation riskini hesaplar"""
        try:
            if not signals:
                return {'overall_risk': 'low', 'risk_score': 0, 'top_threats': []}
            
            # Aggregate risk scores
            total_risk_score = sum(signal.market_manipulation_score * signal.confidence for signal in signals)
            signal_count = len(signals)
            
            # Risk level classification
            risk_score = total_risk_score / signal_count if signal_count > 0 else 0
            
            if risk_score >= 0.8:
                overall_risk = "critical"
            elif risk_score >= 0.6:
                overall_risk = "high"
            elif risk_score >= 0.4:
                overall_risk = "medium"
            else:
                overall_risk = "low"
            
            # Top threats
            sorted_signals = sorted(signals, key=lambda x: x.market_manipulation_score, reverse=True)
            top_threats = [signal.signal_type for signal in sorted_signals[:3]]
            
            return {
                'overall_risk': overall_risk,
                'risk_score': risk_score,
                'signal_count': signal_count,
                'top_threats': top_threats,
                'high_confidence_signals': len([s for s in signals if s.confidence > 0.7])
            }
            
        except Exception as e:
            print(f"Market manipulation risk hesaplama hatası: {e}")
            return {'overall_risk': 'unknown', 'risk_score': 0}
    
    def generate_alert_report(self, signals: List[AdversarialSignal]) -> Dict:
        """Alert raporu oluşturur"""
        try:
            if not signals:
                return {'alert_level': 'none', 'message': 'No adversarial patterns detected'}
            
            # Sort by confidence
            sorted_signals = sorted(signals, key=lambda x: x.confidence, reverse=True)
            highest_confidence = sorted_signals[0]
            
            # Alert level determination
            if highest_confidence.confidence >= 0.9:
                alert_level = "immediate_action"
                message = f"Critical {highest_confidence.signal_type} detected with {highest_confidence.confidence:.2f} confidence"
            elif highest_confidence.confidence >= 0.7:
                alert_level = "high_priority"
                message = f"High confidence {highest_confidence.signal_type} pattern detected"
            elif highest_confidence.confidence >= 0.5:
                alert_level = "monitor"
                message = f"Moderate {highest_confidence.signal_type} activity observed"
            else:
                alert_level = "low_priority"
                message = f"Low confidence signals detected, continued monitoring recommended"
            
            # Summary statistics
            signal_summary = {}
            for signal in signals:
                signal_type = signal.signal_type
                if signal_type not in signal_summary:
                    signal_summary[signal_type] = {'count': 0, 'avg_confidence': 0, 'total_confidence': 0}
                
                signal_summary[signal_type]['count'] += 1
                signal_summary[signal_type]['total_confidence'] += signal.confidence
                signal_summary[signal_type]['avg_confidence'] = signal_summary[signal_type]['total_confidence'] / signal_summary[signal_type]['count']
            
            return {
                'alert_level': alert_level,
                'message': message,
                'total_signals': len(signals),
                'signal_summary': signal_summary,
                'recommendations': self._generate_recommendations(signals),
                'timestamp': pd.Timestamp.now()
            }
            
        except Exception as e:
            print(f"Alert rapor oluşturma hatası: {e}")
            return {'alert_level': 'error', 'message': 'Error generating alert report'}
    
    def _generate_recommendations(self, signals: List[AdversarialSignal]) -> List[str]:
        """Risk azaltma önerilerini oluşturur"""
        recommendations = []
        
        try:
            signal_types = set(signal.signal_type for signal in signals)
            
            if 'spoofing' in signal_types:
                recommendations.append("Monitor quote withdrawals closely")
                recommendations.append("Implement quote validation rules")
            
            if 'front_running' in signal_types:
                recommendations.append("Consider order delay mechanisms")
                recommendations.append("Review execution timing")
            
            if 'pump_and_dump' in signal_types:
                recommendations.append("Increase surveillance on price movements")
                recommendations.append("Monitor unusual volume patterns")
            
            if 'iceberg_front_running' in signal_types:
                recommendations.append("Implement iceberg protection algorithms")
                recommendations.append("Consider order splitting strategies")
            
            if len(recommendations) == 0:
                recommendations.append("Continue normal monitoring")
            
            return recommendations
            
        except Exception as e:
            print(f"Öneri oluşturma hatası: {e}")
            return ["Unable to generate recommendations"]
    
    def get_detection_statistics(self) -> Dict:
        """Tespit istatistiklerini getirir"""
        try:
            return {
                'total_orders': len(self.order_history),
                'total_quotes': len(self.quote_history),
                'analysis_window': self.analysis_window,
                'min_pattern_length': self.min_pattern_length,
                'detection_threshold': self.detection_threshold
            }
            
        except Exception as e:
            print(f"Detection istatistik hatası: {e}")
            return {}
    
    def clear_history(self):
        """Geçmişi temizler"""
        self.order_history.clear()
        self.quote_history.clear()
        self.price_history.clear()
        self.volume_history.clear()