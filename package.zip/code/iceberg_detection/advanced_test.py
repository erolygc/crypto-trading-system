#!/usr/bin/env python3
"""
Iceberg Detection System - Advanced Test

Bu script, iceberg detection sisteminin gelişmiş test senaryolarını içerir.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from iceberg_detection import IcebergDetectionSystem, SystemConfiguration

def create_realistic_iceberg_scenario():
    """Gerçekçi iceberg senaryosu oluşturur"""
    
    # Büyük iceberg emri simülasyonu
    base_price = 100.00
    
    # Order book - büyük iceberg göstergeleri
    iceberg_bids = [
        (base_price, 2000),      # Ana iceberg seviyesi
        (base_price - 0.05, 300), # Normal seviyeler
        (base_price - 0.10, 500),
        (base_price - 0.15, 400),
        (base_price - 0.20, 600)
    ]
    
    iceberg_asks = [
        (base_price + 0.05, 300),  # Normal ask seviyeleri
        (base_price + 0.10, 450),
        (base_price + 0.15, 350),
        (base_price + 0.20, 500),
        (base_price + 0.25, 400)
    ]
    
    # Execution pattern - düzenli iceberg execution
    execution_trades = []
    current_time = datetime.now() - timedelta(minutes=10)
    
    for i in range(15):  # 15 execution
        trade_size = np.random.normal(150, 30)  # Ortalama 150, varyans 30
        trade_price = base_price + np.random.normal(0, 0.01)  # Küçük fiyat dalgalanması
        
        execution_trades.append((
            round(trade_price, 4),
            max(50, int(trade_size)),  # Minimum 50
            current_time + timedelta(minutes=i*0.5)
        ))
    
    return iceberg_bids, iceberg_asks, execution_trades

def create_adversarial_scenario():
    """Adversarial trading senaryosu oluşturur"""
    
    base_price = 100.00
    
    # Spoofing pattern - büyük emrler ardından hızlı iptal
    spoofing_bids = [
        (base_price, 5000),  # Büyük sahte emir
        (base_price - 0.02, 300),
        (base_price - 0.05, 400),
        (base_price - 0.08, 350),
        (base_price - 0.10, 500)
    ]
    
    spoofing_asks = [
        (base_price + 0.03, 200),
        (base_price + 0.05, 300),
        (base_price + 0.08, 250),
        (base_price + 0.10, 400),
        (base_price + 0.15, 300)
    ]
    
    # Layering pattern - aynı tarafta farklı seviyeler
    layering_trades = []
    current_time = datetime.now() - timedelta(minutes=5)
    
    # Aynı trader'dan farklı seviyelerde emirler
    for i in range(8):
        price_variations = [base_price - 0.02, base_price - 0.05, base_price - 0.08]
        trade_price = price_variations[i % 3]
        trade_size = np.random.normal(800, 100)
        
        layering_trades.append((
            round(trade_price, 4),
            max(500, int(trade_size)),
            current_time + timedelta(minutes=i*0.7)
        ))
    
    return spoofing_bids, spoofing_asks, layering_trades

def advanced_iceberg_test():
    """Gelişmiş iceberg tespit testi"""
    print("🧊 ADVANCED ICEBERG DETECTION TEST")
    print("=" * 50)
    
    # Daha hassas konfigürasyon
    config = SystemConfiguration(
        detection_sensitivity=0.8,
        min_iceberg_size=500,  # Daha küçük threshold
        enable_real_time_monitoring=False,
        enable_adversarial_detection=True
    )
    
    system = IcebergDetectionSystem(config)
    
    # Test 1: Iceberg Detection
    print("\n🔍 TEST 1: ICEBERG DETECTION")
    print("-" * 30)
    
    bids, asks, trades = create_realistic_iceberg_scenario()
    
    print(f"📊 Market Data:")
    print(f"   💰 Base Price: {bids[0][0]:.2f}")
    print(f"   🏗️  Large Bid Level: {bids[0][1]:,} units")
    print(f"   📈 Trade Count: {len(trades)}")
    print(f"   💹 Total Volume: {sum(trade[1] for trade in trades):,}")
    
    # Analiz çalıştır
    results = system.analyze_market_data(bids, asks, trades)
    
    print(f"\n📋 Analysis Results:")
    print(f"   🎯 Overall Confidence: {results.overall_confidence:.3f}")
    print(f"   ⚠️  Risk Level: {results.risk_level.upper()}")
    print(f"   🧊 Iceberg Estimates: {len(results.iceberg_estimates)}")
    print(f"   💧 Liquidity Score: {results.liquidity_metrics.liquidity_score:.3f}")
    
    # Detaylı iceberg analizi
    for i, estimate in enumerate(results.iceberg_estimates, 1):
        print(f"\n🧊 ICEBERG #{i} DETAILS:")
        print(f"   📏 Estimated Size: {estimate.estimated_size:,.0f} units")
        print(f"   🎯 Confidence Score: {estimate.confidence_score:.3f}")
        print(f"   📊 Execution Progress: {estimate.execution_progress:.1%}")
        print(f"   ⏳ Remaining Size: {estimate.remaining_size:,.0f} units")
        print(f"   📈 Confidence Interval: ({estimate.confidence_interval[0]:,.0f} - {estimate.confidence_interval[1]:,.0f})")
        print(f"   🔧 Estimation Method: {estimate.estimation_method}")
        
        # Evidence factors
        print(f"   🧪 Evidence Factors:")
        for factor, confidence in estimate.evidence_factors.items():
            print(f"      - {factor}: {confidence:.3f}")
    
    # Test 2: Adversarial Detection
    print(f"\n🚨 TEST 2: ADVERSARIAL TRADING DETECTION")
    print("-" * 30)
    
    adv_bids, adv_asks, adv_trades = create_adversarial_scenario()
    
    # Base price for adversarial scenario
    base_price = 100.00
    
    # Adversarial orders ve quotes
    adv_orders = [
        {'order_id': f'layer_{i:03d}', 'side': 'buy', 'size': 800, 'price': base_price - 0.02*i, 'trader_id': 'suspicious_001'}
        for i in range(3)
    ]
    
    adv_quotes = [
        {'bid_price': base_price - 0.02*i, 'ask_price': base_price + 0.03, 'bid_size': 1000, 'ask_size': 200, 'maker_id': 'spoof_mm'}
        for i in range(3)
    ]
    
    adv_results = system.analyze_market_data(adv_bids, adv_asks, adv_trades, 
                                           orders=adv_orders, quotes=adv_quotes)
    
    print(f"📋 Adversarial Analysis Results:")
    print(f"   🎯 Overall Confidence: {adv_results.overall_confidence:.3f}")
    print(f"   ⚠️  Risk Level: {adv_results.risk_level.upper()}")
    print(f"   🚨 Adversarial Signals: {len(adv_results.adversarial_signals)}")
    print(f"   📊 Market Making Patterns: {len(adv_results.market_making_patterns)}")
    
    # Adversarial signals detayı
    for signal in adv_results.adversarial_signals:
        print(f"\n🚨 ADVERSARIAL SIGNAL:")
        print(f"   🔍 Type: {signal.signal_type}")
        print(f"   🎯 Confidence: {signal.confidence:.3f}")
        print(f"   ⚠️  Severity: {signal.severity.upper()}")
        print(f"   📊 Evidence Count: {signal.evidence_count}")
        print(f"   ⏱️  Time Window: {signal.time_window}s")
        print(f"   💰 Price Impact: {signal.price_impact:.4f}")
        print(f"   🎭 Manipulation Score: {signal.market_manipulation_score:.3f}")
    
    # Market making patterns
    for pattern in adv_results.market_making_patterns:
        print(f"\n📊 MARKET MAKING PATTERN:")
        print(f"   🎭 Type: {pattern.pattern_type}")
        print(f"   🎯 Confidence: {pattern.confidence:.3f}")
        print(f"   🔄 Renewal Frequency: {pattern.renewal_frequency:.3f}")
        print(f"   💰 Market Impact Score: {pattern.market_impact_score:.3f}")
    
    # Combined Recommendations
    print(f"\n💡 COMBINED RECOMMENDATIONS:")
    all_recommendations = results.recommendations + adv_results.recommendations
    for i, rec in enumerate(all_recommendations[:5], 1):
        print(f"   {i}. {rec}")
    
    # Performance Comparison
    print(f"\n⚡ PERFORMANCE COMPARISON:")
    print(f"   📊 Normal vs Iceberg Detection:")
    print(f"      - Normal Confidence: {results.overall_confidence:.3f}")
    print(f"      - Adversarial Confidence: {adv_results.overall_confidence:.3f}")
    print(f"      - Risk Improvement: {adv_results.risk_level != results.risk_level}")
    
    return system, results, adv_results

if __name__ == "__main__":
    try:
        system, normal_results, adversarial_results = advanced_iceberg_test()
        
        print("\n" + "=" * 60)
        print("✅ ADVANCED TEST COMPLETED SUCCESSFULLY")
        print("🎉 Advanced iceberg detection features tested!")
        print("🧊 System capable of detecting:")
        print("   ✓ Hidden iceberg orders")
        print("   ✓ Execution patterns")
        print("   ✓ Adversarial trading behaviors")
        print("   ✓ Market manipulation tactics")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ ADVANCED TEST ERROR: {e}")
        import traceback
        traceback.print_exc()