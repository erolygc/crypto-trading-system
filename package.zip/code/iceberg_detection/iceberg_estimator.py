"""
Iceberg Size Estimator

Iceberg emirlerinin toplam boyutunu tahmin etmek için çeşitli algoritmalar kullanır.
Order book analysis, execution pattern analysis ve statistical modeling içerir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from collections import deque, defaultdict
from scipy import stats
from scipy.optimize import minimize_scalar
import math
import warnings
warnings.filterwarnings('ignore')


@dataclass
class IcebergEstimation:
    """Iceberg boyut tahmini"""
    estimated_size: float
    confidence_interval: Tuple[float, float]
    confidence_score: float
    execution_progress: float
    remaining_size: float
    estimation_method: str
    evidence_factors: Dict[str, float]


@dataclass
class ExecutionPattern:
    """Execution pattern bilgisi"""
    pattern_type: str
    frequency: float
    avg_size: float
    consistency: float
    decay_factor: float


class IcebergEstimator:
    """
    Iceberg boyut tahmin sistemi
    """
    
    def __init__(self, min_pattern_length: int = 10, confidence_threshold: float = 0.6):
        """
        Args:
            min_pattern_length: Minimum pattern uzunluğu
            confidence_threshold: Güven eşiği
        """
        self.min_pattern_length = min_pattern_length
        self.confidence_threshold = confidence_threshold
        self.execution_history = deque(maxlen=1000)
        self.pattern_library = defaultdict(list)
        self.iceberg_tracker = {}
        
    def estimate_iceberg_size(self, current_executions: List[Tuple[float, float]], 
                            order_book_snapshot: Dict,
                            execution_history: List[Tuple[float, float, pd.Timestamp]]) -> IcebergEstimation:
        """
        Iceberg boyutunu tahmin eder
        
        Args:
            current_executions: Mevcut executions [(price, size), ...]
            order_book_snapshot: Order book snapshot
            execution_history: Execution geçmişi
            
        Returns:
            Iceberg boyut tahmini
        """
        try:
            evidence_factors = {}
            
            # Method 1: Order book depth analysis
            book_estimation = self._estimate_from_order_book(order_book_snapshot)
            evidence_factors['order_book'] = book_estimation['confidence']
            
            # Method 2: Execution pattern analysis
            pattern_estimation = self._estimate_from_execution_pattern(execution_history)
            evidence_factors['execution_pattern'] = pattern_estimation['confidence']
            
            # Method 3: Statistical modeling
            statistical_estimation = self._estimate_from_statistics(current_executions, execution_history)
            evidence_factors['statistical'] = statistical_estimation['confidence']
            
            # Method 4: Market microstructure
            microstructure_estimation = self._estimate_from_microstructure(current_executions, order_book_snapshot)
            evidence_factors['microstructure'] = microstructure_estimation['confidence']
            
            # Combine estimates with weighted average
            total_confidence = sum(evidence_factors.values())
            if total_confidence == 0:
                return IcebergEstimation(0, (0, 0), 0, 0, 0, "none", evidence_factors)
            
            # Weighted average of estimates
            weighted_estimate = (
                book_estimation['size'] * evidence_factors['order_book'] +
                pattern_estimation['size'] * evidence_factors['execution_pattern'] +
                statistical_estimation['size'] * evidence_factors['statistical'] +
                microstructure_estimation['size'] * evidence_factors['microstructure']
            ) / total_confidence
            
            # Calculate confidence interval
            estimates = [book_estimation['size'], pattern_estimation['size'], 
                        statistical_estimation['size'], microstructure_estimation['size']]
            confidence_interval = self._calculate_confidence_interval(estimates, total_confidence)
            
            # Calculate execution progress
            executed_size = sum(size for _, size in current_executions)
            execution_progress = self._calculate_execution_progress(executed_size, weighted_estimate)
            
            remaining_size = max(0, weighted_estimate - executed_size)
            
            return IcebergEstimation(
                estimated_size=weighted_estimate,
                confidence_interval=confidence_interval,
                confidence_score=min(total_confidence / len(evidence_factors), 1.0),
                execution_progress=execution_progress,
                remaining_size=remaining_size,
                estimation_method="combined",
                evidence_factors=evidence_factors
            )
            
        except Exception as e:
            print(f"Iceberg boyut tahmin hatası: {e}")
            return IcebergEstimation(0, (0, 0), 0, 0, 0, "error", {})
    
    def _estimate_from_order_book(self, book_snapshot: Dict) -> Dict:
        """Order book'tan iceberg boyut tahmini"""
        try:
            bid_levels = book_snapshot.get('bid_levels', [])
            ask_levels = book_snapshot.get('ask_levels', [])
            
            if not bid_levels or not ask_levels:
                return {'size': 0, 'confidence': 0}
            
            # Analyze depth distribution
            bid_sizes = [level.size for level in bid_levels[:5]]
            ask_sizes = [level.size for level in ask_levels[:5]]
            
            # Look for unusual depth patterns
            total_depth = sum(bid_sizes) + sum(ask_sizes)
            depth_imbalance = abs(sum(bid_sizes) - sum(ask_sizes)) / total_depth if total_depth > 0 else 0
            
            # Large orders typically create depth imbalances
            if depth_imbalance > 0.3:
                estimated_size = total_depth * depth_imbalance * 2  # Conservative multiplier
                confidence = min(depth_imbalance * 2, 0.8)
            else:
                estimated_size = total_depth * 0.1  # Small default
                confidence = 0.2
            
            return {'size': estimated_size, 'confidence': confidence}
            
        except Exception as e:
            print(f"Order book tahmin hatası: {e}")
            return {'size': 0, 'confidence': 0}
    
    def _estimate_from_execution_pattern(self, history: List[Tuple[float, float, pd.Timestamp]]) -> Dict:
        """Execution pattern'den iceberg boyut tahmini"""
        try:
            if len(history) < self.min_pattern_length:
                return {'size': 0, 'confidence': 0}
            
            # Analyze execution patterns
            execution_patterns = self._analyze_execution_patterns(history)
            
            if not execution_patterns:
                return {'size': 0, 'confidence': 0}
            
            # Find most consistent pattern
            best_pattern = max(execution_patterns, key=lambda p: p.consistency * p.frequency)
            
            # Estimate total size based on pattern
            total_executions = len(history)
            estimated_size = best_pattern.avg_size * (1 / best_pattern.decay_factor)
            
            # Adjust based on pattern confidence
            confidence = best_pattern.consistency * min(best_pattern.frequency * 2, 1.0)
            
            return {'size': estimated_size, 'confidence': confidence}
            
        except Exception as e:
            print(f"Execution pattern tahmin hatası: {e}")
            return {'size': 0, 'confidence': 0}
    
    def _analyze_execution_patterns(self, history: List[Tuple[float, float, pd.Timestamp]]) -> List[ExecutionPattern]:
        """Execution pattern'leri analiz eder"""
        patterns = []
        
        try:
            if len(history) < self.min_pattern_length:
                return patterns
            
            sizes = [size for _, size, _ in history]
            
            # Sliding window pattern detection
            window_size = min(20, len(sizes) // 2)
            
            for start in range(0, len(sizes) - window_size, window_size // 2):
                window_sizes = sizes[start:start + window_size]
                
                # Pattern characteristics
                avg_size = np.mean(window_sizes)
                size_consistency = 1 - (np.std(window_sizes) / avg_size) if avg_size > 0 else 0
                
                # Regularity detection
                regularity = self._calculate_regularity(window_sizes)
                
                # Frequency analysis
                frequency = len([s for s in window_sizes if s > avg_size * 0.8]) / len(window_sizes)
                
                # Decay factor (size reduction over time)
                if len(window_sizes) > 5:
                    first_half = np.mean(window_sizes[:len(window_sizes)//2])
                    second_half = np.mean(window_sizes[len(window_sizes)//2:])
                    decay_factor = max(0.1, second_half / first_half) if first_half > 0 else 1.0
                else:
                    decay_factor = 1.0
                
                patterns.append(ExecutionPattern(
                    pattern_type="regular_execution",
                    frequency=frequency,
                    avg_size=avg_size,
                    consistency=max(0, size_consistency),
                    decay_factor=decay_factor
                ))
        
        except Exception as e:
            print(f"Pattern analiz hatası: {e}")
        
        return patterns
    
    def _calculate_regularity(self, sizes: List[float]) -> float:
        """Size regularity'sini hesaplar"""
        try:
            if len(sizes) < 3:
                return 0
            
            # Coefficient of variation
            mean_size = np.mean(sizes)
            std_size = np.std(sizes)
            
            if mean_size == 0:
                return 0
            
            cv = std_size / mean_size
            regularity = max(0, 1 - cv)  # Lower CV = higher regularity
            
            return regularity
        except Exception:
            return 0
    
    def _estimate_from_statistics(self, current_executions: List[Tuple[float, float]], 
                                history: List[Tuple[float, float, pd.Timestamp]]) -> Dict:
        """Statistical modeling ile iceberg boyut tahmini"""
        try:
            if not current_executions:
                return {'size': 0, 'confidence': 0}
            
            current_total = sum(size for _, size in current_executions)
            
            if len(history) < 10:
                # Insufficient history, use basic estimation
                estimated_size = current_total * 3  # Conservative multiplier
                confidence = 0.3
            else:
                # Statistical analysis
                all_sizes = [size for _, size, _ in history]
                historical_avg = np.mean(all_sizes)
                historical_std = np.std(all_sizes)
                
                # Normalize current execution
                current_normalized = current_total / historical_avg if historical_avg > 0 else 0
                
                # Estimate based on execution rate
                execution_rate = len(current_executions) / len(history)
                
                # Linear regression for trend
                if len(all_sizes) > 5:
                    trend_slope = self._calculate_trend(all_sizes[-10:])
                    trend_factor = max(0.5, 1 + trend_slope)
                else:
                    trend_factor = 1.0
                
                estimated_size = current_total * trend_factor * (1 / max(0.1, execution_rate))
                
                # Confidence based on consistency
                consistency = 1 - (historical_std / historical_avg) if historical_avg > 0 else 0
                confidence = min(consistency * 0.7, 0.8)
            
            return {'size': estimated_size, 'confidence': confidence}
            
        except Exception as e:
            print(f"Statistical tahmin hatası: {e}")
            return {'size': 0, 'confidence': 0}
    
    def _calculate_trend(self, sizes: List[float]) -> float:
        """Size trend'ini hesaplar"""
        try:
            if len(sizes) < 3:
                return 0
            
            # Simple linear regression slope
            x = np.arange(len(sizes))
            y = np.array(sizes)
            
            slope = np.polyfit(x, y, 1)[0]
            return slope
        except Exception:
            return 0
    
    def _estimate_from_microstructure(self, current_executions: List[Tuple[float, float]], 
                                    book_snapshot: Dict) -> Dict:
        """Market microstructure analizi ile tahmin"""
        try:
            if not current_executions or not book_snapshot:
                return {'size': 0, 'confidence': 0}
            
            current_total = sum(size for _, size in current_executions)
            
            # Analyze spread behavior
            spread = book_snapshot.get('spread', 0)
            mid_price = book_snapshot.get('mid_price', 0)
            spread_percentage = spread / mid_price if mid_price > 0 else 0
            
            # Analyze liquidity consumption
            bid_volume = book_snapshot.get('bid_volume', 0)
            ask_volume = book_snapshot.get('ask_volume', 0)
            total_liquidity = bid_volume + ask_volume
            
            # Volume-to-liquidity ratio
            volume_ratio = current_total / total_liquidity if total_liquidity > 0 else 0
            
            # Large orders typically cause spread widening
            spread_impact = min(spread_percentage * 10, 1.0)  # Scale spread impact
            
            # Estimate size based on market impact
            base_estimate = current_total * (1 + volume_ratio * 2)
            spread_multiplier = 1 + spread_impact
            
            estimated_size = base_estimate * spread_multiplier
            
            # Confidence based on multiple factors
            liquidity_confidence = min(volume_ratio, 0.5)
            spread_confidence = spread_impact
            confidence = (liquidity_confidence + spread_confidence) / 2
            
            return {'size': estimated_size, 'confidence': confidence}
            
        except Exception as e:
            print(f"Microstructure tahmin hatası: {e}")
            return {'size': 0, 'confidence': 0}
    
    def _calculate_confidence_interval(self, estimates: List[float], total_confidence: float) -> Tuple[float, float]:
        """Güven aralığını hesaplar"""
        try:
            if not estimates:
                return (0, 0)
            
            mean_estimate = np.mean(estimates)
            std_estimate = np.std(estimates)
            
            # Confidence-adjusted interval
            confidence_factor = min(total_confidence / len(estimates), 1.0)
            margin = std_estimate * confidence_factor
            
            lower_bound = max(0, mean_estimate - margin)
            upper_bound = mean_estimate + margin
            
            return (lower_bound, upper_bound)
        except Exception:
            return (0, 0)
    
    def _calculate_execution_progress(self, executed_size: float, estimated_total: float) -> float:
        """Execution progress'unu hesaplar"""
        try:
            if estimated_total <= 0:
                return 0
            
            progress = executed_size / estimated_total
            return min(progress, 1.0)  # Cap at 100%
        except Exception:
            return 0
    
    def update_execution_history(self, price: float, size: float, timestamp: pd.Timestamp):
        """Execution geçmişini günceller"""
        self.execution_history.append((price, size, timestamp))
    
    def get_estimation_quality(self, estimation: IcebergEstimation) -> Dict:
        """Tahmin kalitesini değerlendirir"""
        return {
            'overall_confidence': estimation.confidence_score,
            'evidence_consistency': len([v for v in estimation.evidence_factors.values() if v > 0.5]) / max(1, len(estimation.evidence_factors)),
            'execution_progress': estimation.execution_progress,
            'remaining_risk': estimation.remaining_size / max(estimation.estimated_size, 1)
        }
    
    def clear_history(self):
        """Geçmişi temizler"""
        self.execution_history.clear()
        self.pattern_library.clear()
        self.iceberg_tracker.clear()