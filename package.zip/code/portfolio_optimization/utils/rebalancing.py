"""
Portfolio Rebalancing Engine
Real-time portfolio rebalancing and turnover management
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
import logging
from datetime import datetime, timedelta
from dataclasses import dataclass

from core.config import OptimizationConfig


@dataclass
class TradeOrder:
    """Individual trade order"""
    asset_index: int
    symbol: str
    current_weight: float
    target_weight: float
    weight_change: float
    action: str  # 'BUY', 'SELL', 'HOLD'
    quantity: float
    trade_value: float
    priority: int = 0


@dataclass
class RebalancingResult:
    """Rebalancing result summary"""
    rebalancing_required: bool
    total_trades: int
    estimated_turnover: float
    transaction_costs: float
    trade_orders: List[TradeOrder]
    timestamp: datetime
    rebalancing_reason: str


class RebalancingEngine:
    """
    Portfolio Rebalancing Engine
    
    Manages portfolio rebalancing decisions and execution:
    - Rebalancing threshold monitoring
    - Turnover calculation
    - Transaction cost estimation
    - Trade order generation
    - Execution strategy
    """
    
    def __init__(self, config: OptimizationConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Rebalancing parameters
        self.rebalance_threshold = config.rebalance_threshold
        self.rebalance_frequency = config.rebalance_frequency
        self.transaction_cost = config.transaction_cost
        
        # Tracking
        self.last_rebalance_date: Optional[datetime] = None
        self.rebalancing_history: List[RebalancingResult] = []
        
        # Asset information
        self.symbols: List[str] = []
        self.current_prices: Optional[np.ndarray] = None
        
    def calculate_rebalancing(self,
                             current_weights: np.ndarray,
                             target_weights: np.ndarray,
                             current_prices: Optional[np.ndarray] = None) -> Tuple[bool, List[TradeOrder]]:
        """
        Calculate if rebalancing is needed and generate trade orders
        
        Args:
            current_weights: Current portfolio weights
            target_weights: Target portfolio weights
            current_prices: Current asset prices
            
        Returns:
            Tuple of (rebalancing_required, trade_orders)
        """
        weight_differences = target_weights - current_weights
        
        # Check if any weight difference exceeds threshold
        max_weight_deviation = np.max(np.abs(weight_differences))
        rebalancing_required = max_weight_deviation > self.rebalance_threshold
        
        # Generate trade orders
        trade_orders = self._generate_trade_orders(
            current_weights, target_weights, weight_differences, current_prices
        )
        
        self.logger.info(f"Rebalancing check: Required={rebalancing_required}, Trades={len(trade_orders)}")
        
        return rebalancing_required, trade_orders
        
    def _generate_trade_orders(self,
                              current_weights: np.ndarray,
                              target_weights: np.ndarray,
                              weight_differences: np.ndarray,
                              current_prices: Optional[np.ndarray] = None) -> List[TradeOrder]:
        """
        Generate individual trade orders
        
        Args:
            current_weights: Current weights
            target_weights: Target weights
            weight_differences: Weight differences (target - current)
            current_prices: Current prices
            
        Returns:
            List of trade orders
        """
        trade_orders = []
        n_assets = len(current_weights)
        
        # Set default prices if not provided
        if current_prices is None:
            current_prices = np.ones(n_assets)
            
        for i in range(n_assets):
            weight_diff = weight_differences[i]
            
            # Skip small changes
            if abs(weight_diff) < 0.001:  # Less than 0.1%
                continue
                
            # Determine action
            if weight_diff > 0:
                action = 'BUY'
            elif weight_diff < 0:
                action = 'SELL'
            else:
                action = 'HOLD'
                
            # Calculate trade details
            symbol = self.symbols[i] if i < len(self.symbols) else f"ASSET_{i}"
            current_weight = current_weights[i]
            target_weight = target_weights[i]
            trade_value = abs(weight_diff)  # Relative to portfolio value
            
            # Estimate quantity (assuming $1M portfolio)
            portfolio_value = 1000000  # $1M assumed
            quantity = (trade_value * portfolio_value) / current_prices[i] if current_prices[i] > 0 else 0
            
            # Priority based on trade size
            priority = 1 if abs(weight_diff) > 0.05 else 2  # High priority for large trades
            
            trade_order = TradeOrder(
                asset_index=i,
                symbol=symbol,
                current_weight=current_weight,
                target_weight=target_weight,
                weight_change=weight_diff,
                action=action,
                quantity=quantity,
                trade_value=trade_value,
                priority=priority
            )
            
            trade_orders.append(trade_order)
            
        # Sort by priority (large trades first)
        trade_orders.sort(key=lambda x: x.priority)
        
        return trade_orders
        
    def calculate_turnover(self, trade_orders: List[TradeOrder]) -> float:
        """
        Calculate portfolio turnover
        
        Args:
            trade_orders: List of trade orders
            
        Returns:
            Total turnover percentage
        """
        total_traded = sum(order.trade_value for order in trade_orders)
        
        # Turnover is the sum of absolute weight changes
        turnover = total_traded
        
        return min(turnover, 2.0)  # Cap at 200%
        
    def calculate_transaction_costs(self, trade_orders: List[TradeOrder]) -> float:
        """
        Calculate estimated transaction costs
        
        Args:
            trade_orders: List of trade orders
            
        Returns:
            Total transaction costs
        """
        total_traded_value = sum(order.trade_value for order in trade_orders)
        
        # Simple percentage-based transaction costs
        # In practice, this would include bid-ask spreads, commission, market impact
        transaction_costs = total_traded_value * self.transaction_cost
        
        return transaction_costs
        
    def should_rebalance(self,
                        current_weights: np.ndarray,
                        target_weights: np.ndarray,
                        last_rebalance: Optional[datetime] = None) -> Dict:
        """
        Determine if rebalancing should occur based on multiple criteria
        
        Args:
            current_weights: Current portfolio weights
            target_weights: Target portfolio weights
            last_rebalance: Date of last rebalancing
            
        Returns:
            Dictionary with rebalancing decision and reasoning
        """
        weight_differences = np.abs(target_weights - current_weights)
        max_deviation = np.max(weight_differences)
        mean_deviation = np.mean(weight_differences)
        
        # Threshold-based rebalancing
        threshold_trigger = max_deviation > self.rebalance_threshold
        
        # Time-based rebalancing
        time_trigger = False
        if last_rebalance is not None:
            days_since_rebalance = (datetime.now() - last_rebalance).days
            
            frequency_days = {
                'daily': 1,
                'weekly': 7,
                'monthly': 30,
                'quarterly': 90
            }
            
            rebalance_interval = frequency_days.get(self.rebalance_frequency, 30)
            time_trigger = days_since_rebalance >= rebalance_interval
            
        # Combined decision
        rebalancing_required = threshold_trigger or time_trigger
        
        reason = ""
        if threshold_trigger and time_trigger:
            reason = f"Threshold ({max_deviation:.1%}) and time-based triggers"
        elif threshold_trigger:
            reason = f"Threshold exceeded: {max_deviation:.1%} > {self.rebalance_threshold:.1%}"
        elif time_trigger:
            reason = f"Time-based: {days_since_rebalance} days since last rebalance"
        else:
            reason = f"No trigger: max deviation {max_deviation:.1%}, {days_since_rebalance} days"
            
        return {
            'rebalancing_required': rebalancing_required,
            'reason': reason,
            'max_deviation': max_deviation,
            'mean_deviation': mean_deviation,
            'threshold_trigger': threshold_trigger,
            'time_trigger': time_trigger,
            'days_since_rebalance': (datetime.now() - last_rebalance).days if last_rebalance else float('inf')
        }
        
    def optimize_execution_strategy(self,
                                  trade_orders: List[TradeOrder],
                                  market_conditions: Dict = None) -> Dict:
        """
        Optimize trade execution strategy
        
        Args:
            trade_orders: List of trade orders
            market_conditions: Market conditions data
            
        Returns:
            Optimized execution strategy
        """
        if market_conditions is None:
            market_conditions = {}
            
        # Separate large and small trades
        large_trades = [order for order in trade_orders if order.trade_value > 0.02]  # >2%
        small_trades = [order for order in trade_orders if order.trade_value <= 0.02]
        
        # Execution strategy
        execution_strategy = {
            'large_trades_immediate': len(large_trades) > 0,
            'small_trades_batched': len(small_trades) > 3,
            'max_daily_turnover': min(0.05, 0.10 - sum(o.trade_value for o in large_trades)),  # 5% max daily
            'execution_timeline': self._determine_execution_timeline(trade_orders),
            'estimated_market_impact': self._estimate_market_impact(trade_orders)
        }
        
        # If market conditions indicate high volatility, be more conservative
        volatility = market_conditions.get('volatility', 0.2)
        if volatility > 0.25:  # High volatility
            execution_strategy['max_daily_turnover'] *= 0.5
            execution_strategy['execution_timeline'] = 'scaled_over_days'
            
        return execution_strategy
        
    def _determine_execution_timeline(self, trade_orders: List[TradeOrder]) -> str:
        """Determine optimal execution timeline"""
        total_turnover = sum(order.trade_value for order in trade_orders)
        
        if total_turnover > 0.1:  # >10% turnover
            return 'scaled_over_days'
        elif total_turnover > 0.05:  # >5% turnover
            return 'same_day_limited'
        else:
            return 'immediate'
            
    def _estimate_market_impact(self, trade_orders: List[TradeOrder]) -> float:
        """Estimate market impact costs"""
        # Simplified market impact model
        total_volume = sum(order.trade_value for order in trade_orders)
        
        # Linear impact model: impact = k * volume^0.5
        impact_coefficient = 0.001  # 0.1% per sqrt(%)
        market_impact = impact_coefficient * np.sqrt(total_volume * 100)
        
        return min(market_impact, 0.05)  # Cap at 5%
        
    def generate_rebalancing_report(self,
                                   current_weights: np.ndarray,
                                   target_weights: np.ndarray,
                                   trade_orders: List[TradeOrder],
                                   execution_strategy: Dict) -> str:
        """
        Generate detailed rebalancing report
        
        Args:
            current_weights: Current weights
            target_weights: Target weights
            trade_orders: Trade orders
            execution_strategy: Execution strategy
            
        Returns:
            Formatted report
        """
        if not self.symbols:
            asset_labels = [f"Asset_{i}" for i in range(len(current_weights))]
        else:
            asset_labels = self.symbols
            
        turnover = self.calculate_turnover(trade_orders)
        transaction_costs = self.calculate_transaction_costs(trade_orders)
        
        report = f"""
PORTFÖY YENİDEN DENGELEME RAPORU
==============================

Tarih: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Rebalancing Özeti:
- Toplam İşlem Sayısı: {len(trade_orders)}
- Tahmini Devir: {turnover:.2%}
- İşlem Maliyetleri: {transaction_costs:.2%}
- Yürütme Stratejisi: {execution_strategy['execution_timeline']}

İşlem Detayları:
"""
        
        for order in trade_orders:
            report += f"- {order.symbol}: {order.action} {order.weight_change:+.1%} "
            report += f"(Mevcut: {order.current_weight:.1%} → Hedef: {order.target_weight:.1%})\n"
            
        report += f"\nAğırlık Değişiklikleri:\n"
        
        for i, (current, target, label) in enumerate(zip(current_weights, target_weights, asset_labels)):
            change = target - current
            if abs(change) > 0.001:  # Only show significant changes
                report += f"- {label}: {current:.1%} → {target:.1%} ({change:+.1%})\n"
                
        report += f"\nYürütme Stratejisi:\n"
        report += f"- Büyük İşlemler: {'Acil' if execution_strategy['large_trades_immediate'] else 'Planlı'}\n"
        report += f"- Küçük İşlemler: {'Toplu' if execution_strategy['small_trades_batched'] else 'Ayrı'}\n"
        report += f"- Günlük Limit: {execution_strategy['max_daily_turnover']:.1%}\n"
        report += f"- Tahmini Piyasa Etkisi: {execution_strategy['estimated_market_impact']:.2%}\n"
        
        return report
        
    def backtest_rebalancing(self,
                           historical_weights: np.ndarray,
                           target_weights_history: List[np.ndarray],
                           rebalancing_rules: Dict = None) -> Dict:
        """
        Backtest rebalancing strategy over historical data
        
        Args:
            historical_weights: Historical portfolio weights (T x N)
            target_weights_history: Historical target weights
            rebalancing_rules: Rebalancing rules and thresholds
            
        Returns:
            Backtest results
        """
        if rebalancing_rules is None:
            rebalancing_rules = {'threshold': self.rebalance_threshold}
            
        rebalancing_decisions = []
        turnover_history = []
        cost_history = []
        
        for t in range(1, len(historical_weights)):
            current_weights = historical_weights[t-1]
            target_weights = target_weights_history[t] if t < len(target_weights_history) else current_weights
            
            # Check rebalancing need
            rebalance_check = self.should_rebalance(
                current_weights, target_weights, None
            )
            
            if rebalance_check['rebalancing_required']:
                # Generate trades
                _, trade_orders = self.calculate_rebalancing(
                    current_weights, target_weights, None
                )
                
                turnover = self.calculate_turnover(trade_orders)
                costs = self.calculate_transaction_costs(trade_orders)
                
                rebalancing_decisions.append(True)
                turnover_history.append(turnover)
                cost_history.append(costs)
            else:
                rebalancing_decisions.append(False)
                turnover_history.append(0.0)
                cost_history.append(0.0)
                
        return {
            'rebalancing_decisions': rebalancing_decisions,
            'turnover_history': turnover_history,
            'cost_history': cost_history,
            'rebalancing_frequency': np.mean(rebalancing_decisions),
            'average_turnover': np.mean([t for t in turnover_history if t > 0]),
            'total_transaction_costs': np.sum(cost_history),
            'total_periods': len(rebalancing_decisions)
        }
        
    def set_symbols(self, symbols: List[str]):
        """Set asset symbols for reporting"""
        self.symbols = symbols
        
    def set_current_prices(self, prices: np.ndarray):
        """Set current asset prices"""
        self.current_prices = prices
        
    def update_last_rebalance(self, date: datetime = None):
        """Update last rebalancing date"""
        if date is None:
            date = datetime.now()
        self.last_rebalance_date = date
        
    def get_rebalancing_history(self) -> List[RebalancingResult]:
        """Get rebalancing history"""
        return self.rebalancing_history.copy()
        
    def save_rebalancing_result(self, result: RebalancingResult):
        """Save rebalancing result to history"""
        self.rebalancing_history.append(result)
        
        # Keep only last 100 records
        if len(self.rebalancing_history) > 100:
            self.rebalancing_history = self.rebalancing_history[-100:]
            
    def get_next_rebalance_date(self) -> Optional[datetime]:
        """Get suggested next rebalancing date"""
        if self.last_rebalance_date is None:
            return None
            
        frequency_days = {
            'daily': 1,
            'weekly': 7,
            'monthly': 30,
            'quarterly': 90
        }
        
        interval = frequency_days.get(self.rebalance_frequency, 30)
        return self.last_rebalance_date + timedelta(days=interval)
        
    def calculate_rebalancing_efficiency(self,
                                        rebalancing_results: List[RebalancingResult]) -> Dict:
        """
        Calculate efficiency metrics for rebalancing decisions
        
        Args:
            rebalancing_results: List of rebalancing results
            
        Returns:
            Efficiency metrics
        """
        if not rebalancing_results:
            return {}
            
        turnover_values = [r.estimated_turnover for r in rebalancing_results]
        cost_values = [r.transaction_costs for r in rebalancing_results]
        
        return {
            'average_turnover': np.mean(turnover_values),
            'turnover_std': np.std(turnover_values),
            'average_costs': np.mean(cost_values),
            'cost_std': np.std(cost_values),
            'total_rebalancing_events': len(rebalancing_results),
            'rebalancing_frequency': len(rebalancing_results) / max(1, len(turnover_values)),
            'efficiency_score': 1.0 / (1.0 + np.mean(turnover_values))  # Higher score = lower turnover
        }
