"""
Constraint Handler for Portfolio Optimization
Manages various portfolio constraints and limitations
"""

import numpy as np
import cvxpy as cp
from typing import Dict, List, Optional, Tuple, Any, Union
import logging
from dataclasses import dataclass

from core.config import OptimizationConfig


@dataclass
class ConstraintSpec:
    """Constraint specification"""
    type: str
    parameters: Dict
    description: str


class ConstraintHandler:
    """
    Portfolio Constraint Handler
    
    Manages various constraints in portfolio optimization:
    - Weight bounds
    - Sector constraints
    - Concentration limits
    - Liquidity constraints
    - ESG constraints
    - Turnover constraints
    """
    
    def __init__(self, config: OptimizationConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Constraint storage
        self.constraints: List[ConstraintSpec] = []
        self.sector_mapping: Dict[str, List[int]] = {}
        self.liquidity_scores: Optional[np.ndarray] = None
        self.esg_scores: Optional[np.ndarray] = None
        
        # Initialize default constraints
        self._initialize_default_constraints()
        
    def _initialize_default_constraints(self):
        """Initialize default portfolio constraints"""
        # Basic weight bounds
        self.add_weight_bounds(
            min_weight=self.config.min_weight,
            max_weight=self.config.max_weight
        )
        
        # Position concentration limit
        self.add_concentration_limit(
            max_position=self.config.max_position
        )
        
        # Budget constraint (weights sum to 1)
        self.add_budget_constraint()
        
    def add_weight_bounds(self, 
                         min_weight: float = None,
                         max_weight: float = None,
                         asset_specific: Dict[int, Tuple[float, float]] = None) -> ConstraintSpec:
        """
        Add weight bounds constraint
        
        Args:
            min_weight: Minimum weight for all assets
            max_weight: Maximum weight for all assets
            asset_specific: Asset-specific bounds {asset_index: (min, max)}
            
        Returns:
            Constraint specification
        """
        if min_weight is None:
            min_weight = self.config.min_weight
        if max_weight is None:
            max_weight = self.config.max_weight
            
        constraint = ConstraintSpec(
            type="weight_bounds",
            parameters={
                'min_weight': min_weight,
                'max_weight': max_weight,
                'asset_specific': asset_specific or {}
            },
            description=f"Weight bounds: [{min_weight}, {max_weight}]"
        )
        
        self.constraints.append(constraint)
        self.logger.info(f"Added weight bounds constraint: [{min_weight}, {max_weight}]")
        
        return constraint
        
    def add_budget_constraint(self) -> ConstraintSpec:
        """Add budget constraint (weights sum to 1)"""
        constraint = ConstraintSpec(
            type="budget",
            parameters={},
            description="Portfolio weights sum to 1"
        )
        
        self.constraints.append(constraint)
        self.logger.info("Added budget constraint")
        
        return constraint
        
    def add_concentration_limit(self, max_position: float = None) -> ConstraintSpec:
        """
        Add position concentration limit
        
        Args:
            max_position: Maximum weight for any single position
        """
        if max_position is None:
            max_position = self.config.max_position
            
        constraint = ConstraintSpec(
            type="concentration",
            parameters={
                'max_position': max_position
            },
            description=f"Maximum position size: {max_position:.1%}"
        )
        
        self.constraints.append(constraint)
        self.logger.info(f"Added concentration limit: {max_position:.1%}")
        
        return constraint
        
    def add_sector_constraints(self,
                              sector_mapping: Dict[str, List[int]],
                              sector_limits: Dict[str, float]) -> ConstraintSpec:
        """
        Add sector-based constraints
        
        Args:
            sector_mapping: Mapping from sector names to asset indices
            sector_limits: Maximum weights per sector
            
        Returns:
            Constraint specification
        """
        self.sector_mapping = sector_mapping
        
        constraint = ConstraintSpec(
            type="sector",
            parameters={
                'sector_mapping': sector_mapping,
                'sector_limits': sector_limits
            },
            description=f"Sector constraints: {sector_limits}"
        )
        
        self.constraints.append(constraint)
        self.logger.info(f"Added sector constraints: {sector_limits}")
        
        return constraint
        
    def add_liquidity_constraint(self,
                               liquidity_scores: np.ndarray,
                               min_liquidity: float = 0.5,
                               max_liquidity_weight: float = 0.8) -> ConstraintSpec:
        """
        Add liquidity constraints
        
        Args:
            liquidity_scores: Liquidity scores for each asset (0-1)
            min_liquidity: Minimum average portfolio liquidity
            max_liquidity_weight: Maximum weight for illiquid assets
            
        Returns:
            Constraint specification
        """
        self.liquidity_scores = liquidity_scores
        
        constraint = ConstraintSpec(
            type="liquidity",
            parameters={
                'min_liquidity': min_liquidity,
                'max_liquidity_weight': max_liquidity_weight,
                'liquidity_scores': liquidity_scores
            },
            description=f"Liquidity constraints: min {min_liquidity:.1f}"
        )
        
        self.constraints.append(constraint)
        self.logger.info(f"Added liquidity constraint: min {min_liquidity:.1f}")
        
        return constraint
        
    def add_esg_constraint(self,
                          esg_scores: np.ndarray,
                          min_esg_score: float = 50.0,
                          min_esg_weight: float = 0.3) -> ConstraintSpec:
        """
        Add ESG constraints
        
        Args:
            esg_scores: ESG scores for each asset (0-100)
            min_esg_score: Minimum average portfolio ESG score
            min_esg_weight: Minimum weight in ESG-rated assets
            
        Returns:
            Constraint specification
        """
        self.esg_scores = esg_scores
        
        constraint = ConstraintSpec(
            type="esg",
            parameters={
                'min_esg_score': min_esg_score,
                'min_esg_weight': min_esg_weight,
                'esg_scores': esg_scores
            },
            description=f"ESG constraints: min {min_esg_score:.0f} score, {min_esg_weight:.1%} weight"
        )
        
        self.constraints.append(constraint)
        self.logger.info(f"Added ESG constraint: min {min_esg_score:.0f} score")
        
        return constraint
        
    def add_correlation_constraint(self,
                                  correlation_matrix: np.ndarray,
                                  max_correlation: float = 0.8) -> ConstraintSpec:
        """
        Add correlation-based constraints
        
        Args:
            correlation_matrix: Correlation matrix between assets
            max_correlation: Maximum allowed correlation between assets
            
        Returns:
            Constraint specification
        """
        constraint = ConstraintSpec(
            type="correlation",
            parameters={
                'correlation_matrix': correlation_matrix,
                'max_correlation': max_correlation
            },
            description=f"Correlation limit: {max_correlation:.1f}"
        )
        
        self.constraints.append(constraint)
        self.logger.info(f"Added correlation constraint: {max_correlation:.1f}")
        
        return constraint
        
    def add_turnover_constraint(self,
                               max_turnover: float = 0.2,
                               current_weights: Optional[np.ndarray] = None) -> ConstraintSpec:
        """
        Add turnover constraints
        
        Args:
            max_turnover: Maximum allowable turnover
            current_weights: Current portfolio weights
            
        Returns:
            Constraint specification
        """
        constraint = ConstraintSpec(
            type="turnover",
            parameters={
                'max_turnover': max_turnover,
                'current_weights': current_weights
            },
            description=f"Turnover limit: {max_turnover:.1%}"
        )
        
        self.constraints.append(constraint)
        self.logger.info(f"Added turnover constraint: {max_turnover:.1%}")
        
        return constraint
        
    def add_volatility_constraint(self,
                                 max_volatility: float = 0.15,
                                 covariance_matrix: Optional[np.ndarray] = None) -> ConstraintSpec:
        """
        Add portfolio volatility constraints
        
        Args:
            max_volatility: Maximum portfolio volatility
            covariance_matrix: Asset covariance matrix
            
        Returns:
            Constraint specification
        """
        constraint = ConstraintSpec(
            type="volatility",
            parameters={
                'max_volatility': max_volatility,
                'covariance_matrix': covariance_matrix
            },
            description=f"Volatility limit: {max_volatility:.1%}"
        )
        
        self.constraints.append(constraint)
        self.logger.info(f"Added volatility constraint: {max_volatility:.1%}")
        
        return constraint
        
    def get_standard_constraints(self) -> List[Dict]:
        """
        Get standard constraint list for optimization
        
        Returns:
            List of constraint dictionaries
        """
        return [constraint.parameters for constraint in self.constraints]
        
    def build_cvxp_constraints(self, weights: cp.Variable, n_assets: int) -> List:
        """
        Build CVXPY constraints from specification
        
        Args:
            weights: CVXPY weight variables
            n_assets: Number of assets
            
        Returns:
            List of CVXPY constraints
        """
        cvxpy_constraints = []
        
        for constraint in self.constraints:
            if constraint.type == "budget":
                cvxpy_constraints.append(cp.sum(weights) == 1)
                
            elif constraint.type == "weight_bounds":
                params = constraint.parameters
                
                # General bounds
                cvxpy_constraints.append(weights >= params['min_weight'])
                cvxpy_constraints.append(weights <= params['max_weight'])
                
                # Asset-specific bounds
                if params['asset_specific']:
                    for asset_idx, (min_w, max_w) in params['asset_specific'].items():
                        cvxpy_constraints.append(weights[asset_idx] >= min_w)
                        cvxpy_constraints.append(weights[asset_idx] <= max_w)
                        
            elif constraint.type == "concentration":
                max_position = constraint.parameters['max_position']
                cvxpy_constraints.append(weights <= max_position)
                
            elif constraint.type == "sector":
                params = constraint.parameters
                sector_mapping = params['sector_mapping']
                sector_limits = params['sector_limits']
                
                for sector, limit in sector_limits.items():
                    if sector in sector_mapping:
                        sector_assets = sector_mapping[sector]
                        sector_weight = cp.sum(weights[sector_assets])
                        cvxpy_constraints.append(sector_weight <= limit)
                        
            elif constraint.type == "liquidity":
                params = constraint.parameters
                liquidity_scores = params['liquidity_scores']
                min_liquidity = params['min_liquidity']
                
                # Portfolio liquidity constraint
                portfolio_liquidity = weights @ liquidity_scores
                cvxpy_constraints.append(portfolio_liquidity >= min_liquidity)
                
                # Limit illiquid assets
                max_illiquid_weight = params['max_liquidity_weight']
                illiquid_assets = liquidity_scores < 0.5
                if np.any(illiquid_assets):
                    cvxpy_constraints.append(cp.sum(weights[illiquid_assets]) <= max_illiquid_weight)
                    
            elif constraint.type == "esg":
                params = constraint.parameters
                esg_scores = params['esg_scores']
                min_esg_score = params['min_esg_score']
                min_esg_weight = params['min_esg_weight']
                
                # Portfolio ESG score constraint
                portfolio_esg = weights @ esg_scores
                cvxpy_constraints.append(portfolio_esg >= min_esg_score)
                
                # Minimum weight in ESG assets
                esg_assets = esg_scores >= 60  # ESG-rated assets
                if np.any(esg_assets):
                    cvxpy_constraints.append(cp.sum(weights[esg_assets]) >= min_esg_weight)
                    
            elif constraint.type == "correlation":
                params = constraint.parameters
                correlation_matrix = params['correlation_matrix']
                max_correlation = params['max_correlation']
                
                # Simplified correlation constraint
                # In practice, this would require more complex constraints
                # For now, we'll limit the maximum weight of highly correlated pairs
                high_corr_pairs = np.where(correlation_matrix > max_correlation)
                for i, j in zip(high_corr_pairs[0], high_corr_pairs[1]):
                    if i < j:  # Avoid duplicates
                        cvxpy_constraints.append(weights[i] + weights[j] <= max_correlation + 0.5)
                        
            elif constraint.type == "turnover":
                params = constraint.parameters
                max_turnover = params['max_turnover']
                current_weights = params['current_weights']
                
                if current_weights is not None:
                    turnover = cp.sum(cp.abs(weights - current_weights))
                    cvxpy_constraints.append(turnover <= max_turnover)
                    
            elif constraint.type == "volatility":
                params = constraint.parameters
                max_volatility = params['max_volatility']
                covariance_matrix = params['covariance_matrix']
                
                if covariance_matrix is not None:
                    portfolio_variance = cp.quad_form(weights, covariance_matrix)
                    portfolio_volatility = cp.sqrt(portfolio_variance)
                    cvxpy_constraints.append(portfolio_volatility <= max_volatility)
                    
        return cvxpy_constraints
        
    def check_constraint_satisfaction(self, weights: np.ndarray) -> Dict[str, bool]:
        """
        Check if weights satisfy all constraints
        
        Args:
            weights: Portfolio weights to check
            
        Returns:
            Dictionary of constraint satisfaction status
        """
        satisfaction = {}
        n_assets = len(weights)
        
        for constraint in self.constraints:
            constraint_name = constraint.type
            params = constraint.parameters
            
            try:
                if constraint.type == "budget":
                    satisfaction[constraint_name] = abs(np.sum(weights) - 1.0) < 1e-6
                    
                elif constraint.type == "weight_bounds":
                    min_w = params['min_weight']
                    max_w = params['max_weight']
                    satisfaction[constraint_name] = np.all((weights >= min_w) & (weights <= max_w))
                    
                elif constraint.type == "concentration":
                    max_pos = params['max_position']
                    satisfaction[constraint_name] = np.max(weights) <= max_pos
                    
                elif constraint.type == "sector":
                    sector_mapping = params['sector_mapping']
                    sector_limits = params['sector_limits']
                    
                    all_sectors_ok = True
                    for sector, limit in sector_limits.items():
                        if sector in sector_mapping:
                            sector_weight = np.sum(weights[sector_mapping[sector]])
                            if sector_weight > limit + 1e-6:
                                all_sectors_ok = False
                                break
                    satisfaction[constraint_name] = all_sectors_ok
                    
                elif constraint.type == "liquidity":
                    liquidity_scores = params['liquidity_scores']
                    min_liquidity = params['min_liquidity']
                    
                    portfolio_liquidity = np.dot(weights, liquidity_scores)
                    satisfaction[constraint_name] = portfolio_liquidity >= min_liquidity
                    
                elif constraint.type == "esg":
                    esg_scores = params['esg_scores']
                    min_esg_score = params['min_esg_score']
                    
                    portfolio_esg = np.dot(weights, esg_scores)
                    satisfaction[constraint_name] = portfolio_esg >= min_esg_score
                    
                elif constraint.type == "turnover":
                    current_weights = params['current_weights']
                    max_turnover = params['max_turnover']
                    
                    if current_weights is not None:
                        turnover = np.sum(np.abs(weights - current_weights))
                        satisfaction[constraint_name] = turnover <= max_turnover
                    else:
                        satisfaction[constraint_name] = True
                        
                elif constraint.type == "volatility":
                    covariance_matrix = params['covariance_matrix']
                    max_volatility = params['max_volatility']
                    
                    if covariance_matrix is not None:
                        portfolio_variance = np.dot(weights, np.dot(covariance_matrix, weights))
                        portfolio_volatility = np.sqrt(portfolio_variance)
                        satisfaction[constraint_name] = portfolio_volatility <= max_volatility
                    else:
                        satisfaction[constraint_name] = True
                        
                else:
                    satisfaction[constraint_name] = True  # Unknown constraint type
                    
            except Exception as e:
                self.logger.error(f"Error checking constraint {constraint_name}: {e}")
                satisfaction[constraint_name] = False
                
        return satisfaction
        
    def get_constraint_summary(self) -> str:
        """
        Get human-readable constraint summary
        
        Returns:
            Formatted constraint summary
        """
        summary = "PORTFÖY KISIT ÖZETİ\n"
        summary += "===================\n\n"
        
        for i, constraint in enumerate(self.constraints, 1):
            summary += f"{i}. {constraint.description}\n"
            
        summary += f"\nToplam Kısıt Sayısı: {len(self.constraints)}\n"
        
        # Check if any critical constraints are missing
        constraint_types = {c.type for c in self.constraints}
        
        if "budget" not in constraint_types:
            summary += "\nUYARI: Bütçe kısıtı (ağırlıklar toplamı = 1) eksik!\n"
            
        if "weight_bounds" not in constraint_types:
            summary += "\nUYARI: Ağırlık sınırları eksik!\n"
            
        return summary
        
    def remove_constraint(self, constraint_type: str) -> bool:
        """
        Remove constraint of specified type
        
        Args:
            constraint_type: Type of constraint to remove
            
        Returns:
            True if constraint was found and removed
        """
        initial_count = len(self.constraints)
        self.constraints = [c for c in self.constraints if c.type != constraint_type]
        
        if len(self.constraints) < initial_count:
            self.logger.info(f"Removed constraint: {constraint_type}")
            return True
        else:
            self.logger.warning(f"Constraint not found: {constraint_type}")
            return False
            
    def clear_all_constraints(self):
        """Clear all constraints"""
        self.constraints.clear()
        self.logger.info("Cleared all constraints")
        
    def get_active_constraints(self) -> List[ConstraintSpec]:
        """Get list of currently active constraints"""
        return self.constraints.copy()
        
    def validate_constraint_parameters(self, constraint_type: str, parameters: Dict) -> bool:
        """
        Validate constraint parameters
        
        Args:
            constraint_type: Type of constraint
            parameters: Constraint parameters to validate
            
        Returns:
            True if parameters are valid
        """
        try:
            if constraint_type == "weight_bounds":
                min_w = parameters.get('min_weight', 0)
                max_w = parameters.get('max_weight', 1)
                return 0 <= min_w <= max_w <= 1
                
            elif constraint_type == "concentration":
                max_pos = parameters.get('max_position', 0)
                return 0 < max_pos <= 1
                
            elif constraint_type == "sector":
                sector_limits = parameters.get('sector_limits', {})
                return all(0 < limit <= 1 for limit in sector_limits.values())
                
            elif constraint_type == "liquidity":
                min_liquidity = parameters.get('min_liquidity', 0)
                max_liquidity_weight = parameters.get('max_liquidity_weight', 1)
                return 0 <= min_liquidity <= 1 and 0 < max_liquidity_weight <= 1
                
            elif constraint_type == "esg":
                min_esg_score = parameters.get('min_esg_score', 0)
                min_esg_weight = parameters.get('min_esg_weight', 0)
                return 0 <= min_esg_score <= 100 and 0 <= min_esg_weight <= 1
                
            elif constraint_type == "turnover":
                max_turnover = parameters.get('max_turnover', 0)
                return 0 <= max_turnover <= 2  # Max 200% turnover
                
            elif constraint_type == "volatility":
                max_volatility = parameters.get('max_volatility', 0)
                return 0 <= max_volatility <= 1  # Max 100% volatility
                
            else:
                return True  # Unknown constraint type
                
        except Exception as e:
            self.logger.error(f"Error validating constraint {constraint_type}: {e}")
            return False
