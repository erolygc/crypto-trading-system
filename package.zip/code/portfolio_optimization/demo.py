#!/usr/bin/env python3
"""
Portföy Optimizasyon Sistemi Demo
Modern Portfolio Theory + AI tabanlı portföy optimizasyonu
"""

import numpy as np
import logging
from datetime import datetime

# Portfolio Optimization imports
from core.config import Config
from core.portfolio_optimizer import PortfolioOptimizer
from models.markowitz import MarkowitzOptimizer
from models.black_litterman import BlackLittermanOptimizer
from models.risk_parity import RiskParityOptimizer
from models.multi_objective import MultiObjectiveOptimizer


def setup_logging():
    """Setup logging configuration"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('portfolio_optimization.log')
        ]
    )


def demo_markowitz_optimization():
    """Demo Markowitz optimization"""
    print("\n=== MARKOWITZ OPTİMİZASYONU ===")
    
    # Setup configuration
    config = Config()
    
    # Create sample data
    np.random.seed(42)
    n_assets = 6
    returns_data = np.random.multivariate_normal(
        mean=np.array([0.08, 0.06, 0.10, 0.07, 0.05, 0.09]),
        cov=np.array([
            [0.04, 0.01, 0.02, 0.01, 0.005, 0.015],
            [0.01, 0.03, 0.01, 0.015, 0.02, 0.01],
            [0.02, 0.01, 0.05, 0.02, 0.01, 0.025],
            [0.01, 0.015, 0.02, 0.04, 0.01, 0.01],
            [0.005, 0.02, 0.01, 0.01, 0.03, 0.01],
            [0.015, 0.01, 0.025, 0.01, 0.01, 0.045]
        ]),
        size=252
    )
    
    # Calculate expected returns and covariance
    expected_returns = np.mean(returns_data, axis=0) * 252  # Annualized
    covariance_matrix = np.cov(returns_data.T) * 252  # Annualized
    
    print(f"Assets: 6 stocks")
    print(f"Expected Returns: {[f'{r:.2%}' for r in expected_returns]}")
    
    # Run optimization
    optimizer = MarkowitzOptimizer(config.optimization)
    
    # Max Sharpe ratio portfolio
    weights_sharpe = optimizer.optimize(
        expected_returns=expected_returns,
        covariance_matrix=covariance_matrix,
        method="max_sharpe"
    )
    
    print(f"\nMax Sharpe Portfolio Weights:")
    for i, w in enumerate(weights_sharpe):
        if w > 0.01:
            print(f"  Asset {i+1}: {w:.1%}")
    
    # Efficient frontier
    frontier = optimizer.efficient_frontier(expected_returns, covariance_matrix)
    print(f"\nEfficient Frontier: {len(frontier['portfolios'])} points generated")


def demo_black_litterman():
    """Demo Black-Litterman optimization"""
    print("\n=== BLACK-LITTERMAN MODEL ===")
    
    config = Config()
    bl_optimizer = BlackLittermanOptimizer(config.optimization)
    
    # Sample market data
    np.random.seed(123)
    n_assets = 5
    prior_returns = np.array([0.08, 0.06, 0.10, 0.07, 0.05])
    prior_covariance = np.eye(n_assets) * 0.02
    np.fill_diagonal(prior_covariance, 0.04)
    
    # Add some correlation
    prior_covariance[0, 1] = prior_covariance[1, 0] = 0.01
    prior_covariance[2, 3] = prior_covariance[3, 2] = 0.015
    
    # Investor views
    views = np.array([0.12, 0.05, 0.08, 0.06, 0.04])  # Expected returns
    
    # Optimize with views
    weights = bl_optimizer.optimize(
        prior_returns=prior_returns,
        prior_covariance=prior_covariance,
        views=views
    )
    
    print("Black-Litterman Portfolio Weights:")
    for i, w in enumerate(weights):
        if w > 0.01:
            print(f"  Asset {i+1}: {w:.1%}")
    
    print(f"Posterior Expected Return: {bl_optimizer.get_posterior_mean():.2%}")
    print(f"Posterior Risk: {bl_optimizer.get_posterior_risk():.2%}")


def demo_risk_parity():
    """Demo Risk Parity optimization"""
    print("\n=== RİSK PARİTY OPTİMİZASYONU ===")
    
    config = Config()
    rp_optimizer = RiskParityOptimizer(config.optimization)
    
    # Sample covariance matrix
    covariance_matrix = np.array([
        [0.04, 0.01, 0.015],
        [0.01, 0.03, 0.008],
        [0.015, 0.008, 0.05]
    ])
    
    # Equal contribution risk parity
    weights = rp_optimizer.optimize(covariance_matrix, method="equal_contribution")
    
    print("Risk Parity Portfolio Weights:")
    for i, w in enumerate(weights):
        print(f"  Asset {i+1}: {w:.1%}")
    
    # Calculate risk contributions
    risk_contrib = rp_optimizer.calculate_risk_contributions(weights, covariance_matrix)
    print("\nRisk Contributions:")
    for i, contrib in enumerate(risk_contrib):
        print(f"  Asset {i+1}: {contrib:.1%}")


def demo_multi_objective():
    """Demo Multi-objective optimization"""
    print("\n=== MULTİ-OBJECTİVE OPTİMİZASYONU ===")
    
    config = Config()
    mo_optimizer = MultiObjectiveOptimizer(config.optimization)
    
    # Sample data
    np.random.seed(456)
    expected_returns = np.array([0.08, 0.10, 0.06, 0.12, 0.07])
    covariance_matrix = np.eye(5) * 0.04
    
    # Add some correlation
    covariance_matrix[0, 1] = covariance_matrix[1, 0] = 0.01
    covariance_matrix[2, 3] = covariance_matrix[3, 2] = 0.015
    
    # Proxy scores
    liquidity_scores = np.array([0.8, 0.6, 0.9, 0.7, 0.5])
    esg_scores = np.array([75, 60, 80, 55, 70])
    
    # Optimize
    weights = mo_optimizer.optimize(
        expected_returns=expected_returns,
        covariance_matrix=covariance_matrix,
        liquidity_scores=liquidity_scores,
        esg_scores=esg_scores,
        objectives=['return', 'risk', 'liquidity', 'esg']
    )
    
    print("Multi-Objective Portfolio Weights:")
    for i, w in enumerate(weights):
        if w > 0.01:
            print(f"  Asset {i+1}: {w:.1%}")
    
    # Calculate objective contributions
    contributions = mo_optimizer.calculate_objective_contributions(
        weights, expected_returns, covariance_matrix, liquidity_scores, esg_scores
    )
    
    print(f"\nPortfolio Objectives:")
    for obj, value in contributions['portfolio_objectives'].items():
        if obj == 'return':
            print(f"  {obj.capitalize()}: {value:.2%}")
        else:
            print(f"  {obj.capitalize()}: {value:.3f}")


def demo_integrated_system():
    """Demo integrated portfolio optimization system"""
    print("\n=== BÜTÜNLEŞİK PORTFÖY OPTİMİZASYONU ===")
    
    # Setup configuration
    config = Config()
    
    # Sample asset universe
    symbols = ["AAPL", "MSFT", "GOOGL", "AMZN", "TSLA", "JNJ"]
    
    # Initialize system
    optimizer = PortfolioOptimizer(config)
    
    # Note: In real usage, this would initialize with actual data
    print(f"Portfolio Optimization System Initialized")
    print(f"Asset Universe: {symbols}")
    print(f"Optimizations Available:")
    print(f"  - Markowitz (Mean-Variance)")
    print(f"  - Black-Litterman (With Views)")
    print(f"  - Risk Parity (Equal Risk Contribution)")
    print(f"  - Factor Models (PCA/FA)")
    print(f"  - Multi-Objective (Return-Risk-Liquidity-ESG)")
    
    print(f"\nReal-time Features:")
    print(f"  - Correlation Matrix Updates")
    print(f"  - Dynamic Rebalancing")
    print(f"  - VaR/CVaR Risk Management")
    print(f"  - ESG Integration")
    print(f"  - Constraint Handling")


def run_stress_tests():
    """Run stress tests on the system"""
    print("\n=== STRESS TESTLERİ ===")
    
    # Test with extreme market conditions
    print("Testing with high volatility scenario...")
    
    config = Config()
    
    # High volatility environment
    high_vol_covariance = np.eye(3) * 0.16  # 40% volatility
    returns = np.array([0.05, 0.03, 0.07])
    
    # Risk parity in high volatility
    rp_optimizer = RiskParityOptimizer(config.optimization)
    try:
        weights = rp_optimizer.optimize(high_vol_covariance, method="equal_contribution")
        print(f"✓ Risk Parity handled high volatility successfully")
    except Exception as e:
        print(f"✗ Risk Parity failed: {e}")
    
    # Black-Litterman stress test
    bl_optimizer = BlackLittermanOptimizer(config.optimization)
    try:
        stress_result = bl_optimizer.stress_test(returns, high_vol_covariance, market_shock=-0.3)
        print(f"✓ Black-Litterman stress test completed")
    except Exception as e:
        print(f"✗ Black-Litterman stress test failed: {e}")


def main():
    """Main demo function"""
    print("PORTFÖY OPTİMİZASYON SİSTEMİ DEMO")
    print("=" * 50)
    
    # Setup logging
    setup_logging()
    
    # Run demonstrations
    demo_markowitz_optimization()
    demo_black_litterman()
    demo_risk_parity()
    demo_multi_objective()
    demo_integrated_system()
    run_stress_tests()
    
    print("\n" + "=" * 50)
    print("DEMO TAMAMLANDI!")
    print("\nSistem özellikleri:")
    print("✓ Modern Portfolio Theory implementation")
    print("✓ Real-time correlation matrix calculation")
    print("✓ Multiple optimization methods")
    print("✓ ESG integration")
    print("✓ Dynamic rebalancing")
    print("✓ Risk management (VaR/CVaR)")
    print("✓ Constraint handling")
    print("✓ Multi-objective optimization")
    print("\nLog dosyası: portfolio_optimization.log")


if __name__ == "__main__":
    main()
