"""
Konfigürasyon yönetimi
"""

from dataclasses import dataclass
from typing import Dict, List, Optional, Union
import numpy as np


@dataclass
class OptimizationConfig:
    """Optimizasyon parametreleri"""
    # Markowitz optimizasyonu
    risk_aversion: float = 1.0
    target_return: Optional[float] = None
    risk_free_rate: float = 0.02
    
    # Kısıtlar
    min_weight: float = 0.0
    max_weight: float = 1.0
    max_position: float = 0.3
    rebalance_threshold: float = 0.05
    
    # Black-Litterman
    tau: float = 0.05  # Uncertainty in prior
    delta: float = 2.5  # Risk aversion parameter
    
    # Risk Parity
    risk_parity_target: str = "equal"  # "equal" or "inverse_vol"
    
    # ESG ağırlıkları
    esg_weight: float = 0.1
    e_weight: float = 0.33
    s_weight: float = 0.33
    g_weight: float = 0.34
    
    # Rebalancing
    rebalance_frequency: str = "monthly"  # daily, weekly, monthly, quarterly
    transaction_cost: float = 0.001
    
    # Factor models
    n_factors: int = 5
    factor_method: str = "pca"  # "pca", "fa", "both"
    
    # Multi-objective optimization
    objectives: List[str] = None
    
    def __post_init__(self):
        if self.objectives is None:
            self.objectives = ["return", "risk", "liquidity"]


@dataclass 
class DataConfig:
    """Veri yönetimi konfigürasyonu"""
    # Veri kaynağı
    data_source: str = "yahoo"  # yahoo, quandl, bloomberg, csv
    data_path: str = "data/"
    
    # Veri periyodu
    start_date: str = "2020-01-01"
    end_date: str = "2025-01-01"
    frequency: str = "daily"  # daily, weekly, monthly
    
    # Veri işleme
    lookback_period: int = 252  # 1 yıl
    rolling_window: int = 60   # 3 ay
    
    # ESG veri kaynağı
    esg_data_source: str = "msci"  # msci, sustainalytics, csv
    
    # Real-time settings
    update_frequency: int = 300  # seconds
    correlation_window: int = 60  # days


@dataclass
class RiskConfig:
    """Risk yönetimi konfigürasyonu"""
    # VaR ayarları
    var_confidence: float = 0.95
    var_method: str = "historical"  # historical, parametric, monte_carlo
    
    # CVaR ayarları
    cvar_confidence: float = 0.95
    
    # Stress test
    stress_scenarios: List[Dict] = None
    
    # Correlation analysis
    correlation_threshold: float = 0.8
    correlation_method: str = "pearson"  # pearson, kendall, spearman
    
    def __post_init__(self):
        if self.stress_scenarios is None:
            self.stress_scenarios = [
                {"name": "market_crash_2008", "return": -0.3, "duration": 60},
                {"name": "covid_2020", "return": -0.25, "duration": 90},
                {"name": "inflation_scare", "return": -0.15, "duration": 120}
            ]


class Config:
    """Ana konfigürasyon sınıfı"""
    
    def __init__(self, 
                 optimization: Optional[OptimizationConfig] = None,
                 data: Optional[DataConfig] = None,
                 risk: Optional[RiskConfig] = None):
        
        self.optimization = optimization or OptimizationConfig()
        self.data = data or DataConfig()
        self.risk = risk or RiskConfig()
        
    def update_optimization_params(self, **kwargs):
        """Optimizasyon parametrelerini güncelle"""
        for key, value in kwargs.items():
            if hasattr(self.optimization, key):
                setattr(self.optimization, key, value)
                
    def update_data_params(self, **kwargs):
        """Veri parametrelerini güncelle"""
        for key, value in kwargs.items():
            if hasattr(self.data, key):
                setattr(self.data, key, value)
                
    def update_risk_params(self, **kwargs):
        """Risk parametrelerini güncelle"""
        for key, value in kwargs.items():
            if hasattr(self.risk, key):
                setattr(self.risk, key, value)
                
    def get_asset_universe(self) -> List[str]:
        """Varsayılan varlık evreni"""
        return [
            "AAPL", "MSFT", "GOOGL", "AMZN", "TSLA",  # Tech
            "JNJ", "PFE", "UNH", "ABBV", "MRK",       # Healthcare
            "JPM", "BAC", "WFC", "GS", "MS",          # Financial
            "XOM", "CVX", "COP", "SLB", "EOG",        # Energy
            "NEE", "DUK", "SO", "D", "AEP",           # Utilities
            "SPY", "QQQ", "IWM", "VTI", "GLD"         # ETFs
        ]
        
    def get_esg_assets(self) -> List[str]:
        """ESG odaklı varlıklar"""
        return [
            "NEE", "AEP", "DUK", "SO",  # Renewable energy
            "MSCI", "ESGU", "ESGV",     # ESG ETFs
            "TSLA",                     # Clean tech
            "NVDA", "AMD"               # Green tech
        ]
