"""
Veri yönetimi - Real-time data, correlation matrix, ESG integration
"""

import numpy as np
import pandas as pd
import yfinance as yf
from typing import Dict, List, Tuple, Optional, Union
import logging
from datetime import datetime, timedelta
import asyncio
import threading
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

from .config import DataConfig


@dataclass
class AssetData:
    """Varlık veri yapısı"""
    symbol: str
    prices: pd.Series
    returns: pd.Series
    volume: pd.Series
    market_cap: Optional[float] = None
    beta: Optional[float] = None
    volatility: Optional[float] = None
    last_update: Optional[datetime] = None


@dataclass
class ESGData:
    """ESG veri yapısı"""
    symbol: str
    esg_score: float
    environmental_score: float
    social_score: float
    governance_score: float
    esg_rating: str
    carbon_intensity: Optional[float] = None
    last_update: Optional[datetime] = None


class DataManager:
    """Ana veri yönetimi sınıfı"""
    
    def __init__(self, config: DataConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self._lock = threading.Lock()
        
        # Veri depolama
        self.assets_data: Dict[str, AssetData] = {}
        self.esg_data: Dict[str, ESGData] = {}
        self.correlation_matrix: Optional[np.ndarray] = None
        self.covariance_matrix: Optional[np.ndarray] = None
        
        # Real-time güncelleme
        self._running = False
        self._update_thread = None
        self.executor = ThreadPoolExecutor(max_workers=5)
        
    def initialize_data(self, symbols: List[str]) -> Dict[str, AssetData]:
        """Başlangıç veri yükleme"""
        self.logger.info(f"Loading data for {len(symbols)} assets...")
        
        # Paralel veri yükleme
        futures = []
        for symbol in symbols:
            future = self.executor.submit(self._load_asset_data, symbol)
            futures.append((symbol, future))
            
        # Sonuçları topla
        for symbol, future in futures:
            try:
                asset_data = future.result(timeout=30)
                if asset_data is not None:
                    self.assets_data[symbol] = asset_data
                    self.logger.info(f"Loaded data for {symbol}")
            except Exception as e:
                self.logger.error(f"Failed to load data for {symbol}: {e}")
                
        # Correlation ve covariance matrislerini hesapla
        self._update_matrices()
        
        return self.assets_data
        
    def _load_asset_data(self, symbol: str) -> Optional[AssetData]:
        """Tek varlık verisi yükleme"""
        try:
            # Yahoo Finance'ten veri çek
            ticker = yf.Ticker(symbol)
            
            # Fiyat verisi
            hist = ticker.history(
                start=self.config.start_date,
                end=self.config.end_date,
                interval=self.config.frequency
            )
            
            if hist.empty:
                self.logger.warning(f"No data found for {symbol}")
                return None
                
            prices = hist['Close'].dropna()
            returns = prices.pct_change().dropna()
            volume = hist['Volume'].dropna()
            
            # Metrikler hesaplama
            market_cap = self._get_market_cap(symbol)
            beta = self._calculate_beta(returns)
            volatility = returns.std() * np.sqrt(252)  # Annualized
            
            return AssetData(
                symbol=symbol,
                prices=prices,
                returns=returns,
                volume=volume,
                market_cap=market_cap,
                beta=beta,
                volatility=volatility,
                last_update=datetime.now()
            )
            
        except Exception as e:
            self.logger.error(f"Error loading data for {symbol}: {e}")
            return None
            
    def _get_market_cap(self, symbol: str) -> Optional[float]:
        """Piyasa değeri hesaplama (mock data)"""
        # Gerçek uygulamada Bloomberg API, Yahoo Finance API vb. kullanılır
        try:
            ticker = yf.Ticker(symbol)
            info = ticker.info
            return info.get('marketCap', None)
        except:
            return None
            
    def _calculate_beta(self, returns: pd.Series, market_returns: pd.Series = None) -> float:
        """Beta hesaplama"""
        if market_returns is None:
            # S&P 500'i market proxy olarak kullan
            market_ticker = yf.Ticker("SPY")
            market_data = market_ticker.history(period="2y")['Close']
            market_returns = market_data.pct_change().dropna()
            
        # Tarih aralığını eşitle
        common_dates = returns.index.intersection(market_returns.index)
        aligned_returns = returns[common_dates]
        aligned_market = market_returns[common_dates]
        
        if len(aligned_returns) < 30:  # Yeterli veri yok
            return 1.0
            
        covariance = np.cov(aligned_returns, aligned_market)[0, 1]
        market_variance = np.var(aligned_market)
        
        return covariance / market_variance if market_variance > 0 else 1.0
        
    def load_esg_data(self, symbols: List[str]) -> Dict[str, ESGData]:
        """ESG verilerini yükleme (simulated)"""
        self.logger.info("Loading ESG data...")
        
        for symbol in symbols:
            try:
                # Gerçek ESG veri kaynağından çek
                esg_data = self._fetch_esg_data(symbol)
                if esg_data:
                    self.esg_data[symbol] = esg_data
                    
            except Exception as e:
                self.logger.error(f"Error loading ESG data for {symbol}: {e}")
                
        return self.esg_data
        
    def _fetch_esg_data(self, symbol: str) -> Optional[ESGData]:
        """ESG verisi çekme (simulated - gerçek uygulamada MSCI API vb. kullanılır)"""
        # Mock ESG veri - gerçek uygulamada ESG API'lerinden çekilir
        np.random.seed(hash(symbol) % 2**32)  # Consistent mock data
        
        esg_score = np.random.uniform(50, 90)
        e_score = np.random.uniform(40, 95)
        s_score = np.random.uniform(30, 90)
        g_score = np.random.uniform(35, 85)
        
        if esg_score >= 80:
            rating = "AAA"
        elif esg_score >= 70:
            rating = "AA"
        elif esg_score >= 60:
            rating = "A"
        elif esg_score >= 50:
            rating = "BBB"
        else:
            rating = "BB"
            
        return ESGData(
            symbol=symbol,
            esg_score=esg_score,
            environmental_score=e_score,
            social_score=s_score,
            governance_score=g_score,
            esg_rating=rating,
            carbon_intensity=np.random.uniform(50, 300),
            last_update=datetime.now()
        )
        
    def _update_matrices(self):
        """Correlation ve covariance matrislerini güncelle"""
        try:
            # Returns dataframe oluştur
            returns_df = pd.DataFrame({
                symbol: data.returns 
                for symbol, data in self.assets_data.items()
            })
            
            # Correlation matrix
            self.correlation_matrix = returns_df.corr().values
            
            # Covariance matrix (annualized)
            self.covariance_matrix = returns_df.cov().values * 252
            
            self.logger.info("Updated correlation and covariance matrices")
            
        except Exception as e:
            self.logger.error(f"Error updating matrices: {e}")
            
    def get_real_time_prices(self, symbols: List[str]) -> Dict[str, float]:
        """Real-time fiyat çekme"""
        prices = {}
        
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = {
                symbol: executor.submit(self._fetch_real_time_price, symbol)
                for symbol in symbols
            }
            
            for symbol, future in futures.items():
                try:
                    price = future.result(timeout=5)
                    if price:
                        prices[symbol] = price
                except Exception as e:
                    self.logger.error(f"Error fetching price for {symbol}: {e}")
                    
        return prices
        
    def _fetch_real_time_price(self, symbol: str) -> Optional[float]:
        """Tek varlık için real-time fiyat"""
        try:
            ticker = yf.Ticker(symbol)
            hist = ticker.history(period="1d")
            if not hist.empty:
                return hist['Close'].iloc[-1]
        except:
            pass
        return None
        
    def update_correlation_matrix(self, window: int = None) -> np.ndarray:
        """Real-time correlation matrix güncelleme"""
        if window is None:
            window = self.config.correlation_window
            
        try:
            # Son N günlük veri kullan
            returns_df = pd.DataFrame({
                symbol: data.returns.tail(window)
                for symbol, data in self.assets_data.items()
            })
            
            self.correlation_matrix = returns_df.corr().values
            
            self.logger.info(f"Updated correlation matrix with {window} days of data")
            return self.correlation_matrix
            
        except Exception as e:
            self.logger.error(f"Error updating correlation matrix: {e}")
            return self.correlation_matrix
            
    def get_factor_loadings(self, method: str = "pca") -> np.ndarray:
        """Factor loadings hesaplama (PCA veya FA)"""
        try:
            returns_df = pd.DataFrame({
                symbol: data.returns 
                for symbol, data in self.assets_data.items()
            }).dropna()
            
            if method == "pca":
                from sklearn.decomposition import PCA
                pca = PCA(n_components=min(5, returns_df.shape[1]))
                pca.fit(returns_df)
                return pca.components_.T
                
            elif method == "fa":
                from sklearn.decomposition import FactorAnalysis
                fa = FactorAnalysis(n_components=5, random_state=0)
                fa.fit(returns_df)
                return fa.components_.T
                
        except Exception as e:
            self.logger.error(f"Error calculating factor loadings: {e}")
            return np.eye(len(self.assets_data))
            
    def start_real_time_updates(self, symbols: List[str]):
        """Real-time güncellemeleri başlat"""
        if self._running:
            return
            
        self._running = True
        self._update_thread = threading.Thread(
            target=self._real_time_update_loop,
            args=(symbols,),
            daemon=True
        )
        self._update_thread.start()
        self.logger.info("Started real-time data updates")
        
    def _real_time_update_loop(self, symbols: List[str]):
        """Real-time güncelleme döngüsü"""
        while self._running:
            try:
                # Yeni fiyatları çek
                new_prices = self.get_real_time_prices(symbols)
                
                with self._lock:
                    # Verileri güncelle
                    for symbol, price in new_prices.items():
                        if symbol in self.assets_data:
                            # Yeni fiyatı ekle
                            asset = self.assets_data[symbol]
                            new_return = price / asset.prices.iloc[-1] - 1
                            
                            # Returns serisini güncelle
                            new_series = pd.Series(
                                [new_return],
                                index=[pd.Timestamp.now()],
                                name=symbol
                            )
                            asset.returns = pd.concat([asset.returns.tail(-1), new_series])
                            
                            # Fiyat serisini güncelle
                            price_series = pd.Series(
                                [price],
                                index=[pd.Timestamp.now()],
                                name=symbol
                            )
                            asset.prices = pd.concat([asset.prices.tail(-1), price_series])
                            
                            asset.last_update = datetime.now()
                            
                    # Matrisleri güncelle
                    self._update_matrices()
                    
                # Belirtilen süre kadar bekle
                import time
                time.sleep(self.config.update_frequency)
                
            except Exception as e:
                self.logger.error(f"Error in real-time update: {e}")
                time.sleep(10)  # Hata durumunda 10 saniye bekle
                
    def stop_real_time_updates(self):
        """Real-time güncellemeleri durdur"""
        self._running = False
        if self._update_thread and self._update_thread.is_alive():
            self._update_thread.join(timeout=5)
        self.logger.info("Stopped real-time data updates")
        
    def get_data_summary(self) -> Dict:
        """Veri özeti"""
        with self._lock:
            summary = {
                'total_assets': len(self.assets_data),
                'esg_assets': len(self.esg_data),
                'date_range': {
                    'start': None,
                    'end': None
                },
                'correlation_matrix_shape': self.correlation_matrix.shape if self.correlation_matrix is not None else None,
                'real_time_running': self._running
            }
            
            if self.assets_data:
                all_start_dates = [data.prices.index.min() for data in self.assets_data.values()]
                all_end_dates = [data.prices.index.max() for data in self.assets_data.values()]
                
                summary['date_range']['start'] = min(all_start_dates)
                summary['date_range']['end'] = max(all_end_dates)
                
            return summary
            
    def __del__(self):
        """Cleanup"""
        self.stop_real_time_updates()
        self.executor.shutdown(wait=True)
