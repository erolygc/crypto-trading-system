"""
Ana Portföy Optimizatörü - Tüm optimizasyon metodlarını birleştirir
"""

import numpy as np
import pandas as pd
import cvxpy as cp
from typing import Dict, List, Tuple, Optional, Union, Any
import logging
from datetime import datetime
from dataclasses import dataclass

from .data_manager import DataManager
from .config import Config, OptimizationConfig, RiskConfig
from models.markowitz import MarkowitzOptimizer
from models.black_litterman import BlackLittermanOptimizer
from models.risk_parity import RiskParityOptimizer
from models.factor_models import FactorModelOptimizer
from models.multi_objective import MultiObjectiveOptimizer
from risk.var_calculator import VaRCalculator
from utils.constraints import ConstraintHandler
from utils.rebalancing import RebalancingEngine


@dataclass
class PortfolioResult:
    """Portföy sonucu"""
    weights: np.ndarray
    expected_return: float
    expected_risk: float
    sharpe_ratio: float
    esg_score: Optional[float] = None
    var_95: Optional[float] = None
    cvar_95: Optional[float] = None
    turnover: float = 0.0
    optimization_method: str = ""
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()


@dataclass
class OptimizationResult:
    """Optimizasyon sonucu wrapper"""
    current_portfolio: PortfolioResult
    optimal_portfolio: PortfolioResult
    rebalancing_required: bool
    suggested_trades: List[Dict]
    performance_metrics: Dict
    risk_metrics: Dict
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()


class PortfolioOptimizer:
    """Ana Portföy Optimizasyon Sistemi"""
    
    def __init__(self, config: Config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Komponentler
        self.data_manager = DataManager(config.data)
        self.markowitz = MarkowitzOptimizer(config.optimization)
        self.black_litterman = BlackLittermanOptimizer(config.optimization)
        self.risk_parity = RiskParityOptimizer(config.optimization)
        self.factor_model = FactorModelOptimizer(config.optimization)
        self.multi_objective = MultiObjectiveOptimizer(config.optimization)
        self.var_calculator = VaRCalculator(config.risk)
        self.constraint_handler = ConstraintHandler(config.optimization)
        self.rebalancing = RebalancingEngine(config.optimization)
        
        # Durum
        self.current_weights: Optional[np.ndarray] = None
        self.optimization_history: List[OptimizationResult] = []
        
    def initialize_system(self, symbols: List[str]) -> Dict:
        """Sistemi başlat ve verileri yükle"""
        self.logger.info("Initializing portfolio optimization system...")
        
        # Veri yönetimini başlat
        assets_data = self.data_manager.initialize_data(symbols)
        esg_data = self.data_manager.load_esg_data(symbols)
        
        self.logger.info(f"Loaded data for {len(assets_data)} assets")
        self.logger.info(f"Loaded ESG data for {len(esg_data)} assets")
        
        # Real-time güncellemeleri başlat
        self.data_manager.start_real_time_updates(symbols)
        
        return {
            'assets_loaded': len(assets_data),
            'esg_loaded': len(esg_data),
            'data_summary': self.data_manager.get_data_summary()
        }
        
    def optimize_portfolio(self, 
                          method: str = "markowitz",
                          current_weights: Optional[np.ndarray] = None,
                          **kwargs) -> PortfolioResult:
        """
        Ana optimizasyon metodu
        
        Args:
            method: Optimizasyon yöntemi ('markowitz', 'black_litterman', 'risk_parity', 'factor', 'multi_objective')
            current_weights: Mevcut portföy ağırlıkları
            **kwargs: Ek parametreler
        """
        if method not in ['markowitz', 'black_litterman', 'risk_parity', 'factor', 'multi_objective']:
            raise ValueError(f"Unknown optimization method: {method}")
            
        # Verileri al
        returns = self._get_returns_matrix()
        expected_returns = self._get_expected_returns()
        covariance_matrix = self._get_covariance_matrix()
        
        # ESG skorlarını al (varsa)
        esg_scores = self._get_esg_scores() if kwargs.get('include_esg', False) else None
        
        # Mevcut ağırlıkları kaydet
        if current_weights is not None:
            self.current_weights = current_weights
            
        try:
            if method == "markowitz":
                result = self._optimize_markowitz(expected_returns, covariance_matrix, **kwargs)
                
            elif method == "black_litterman":
                # Black-Litterman için views gerekli
                views = kwargs.get('views', None)
                result = self._optimize_black_litterman(
                    expected_returns, covariance_matrix, views, **kwargs
                )
                
            elif method == "risk_parity":
                result = self._optimize_risk_parity(covariance_matrix, **kwargs)
                
            elif method == "factor":
                factor_loadings = kwargs.get('factor_loadings', None)
                result = self._optimize_factor_model(
                    expected_returns, covariance_matrix, factor_loadings, **kwargs
                )
                
            elif method == "multi_objective":
                objectives = kwargs.get('objectives', ['return', 'risk', 'liquidity'])
                result = self._optimize_multi_objective(
                    expected_returns, covariance_matrix, objectives, **kwargs
                )
                
            # Risk metriklerini hesapla
            result = self._add_risk_metrics(result, returns)
            
            # ESG skorunu ekle
            if esg_scores is not None:
                result.esg_score = np.dot(result.weights, esg_scores)
                
            result.optimization_method = method
            
            self.logger.info(f"Optimization completed using {method} method")
            return result
            
        except Exception as e:
            self.logger.error(f"Error in optimization: {e}")
            raise
            
    def _optimize_markowitz(self, 
                           expected_returns: np.ndarray, 
                           covariance_matrix: np.ndarray,
                           **kwargs) -> PortfolioResult:
        """Markowitz optimizasyonu"""
        # Kısıtlar
        constraints = self.constraint_handler.get_standard_constraints()
        
        # Hedef getiri (opsiyonel)
        target_return = kwargs.get('target_return')
        if target_return is not None:
            constraints.append({
                'type': 'return',
                'target': target_return
            })
            
        weights = self.markowitz.optimize(
            expected_returns=expected_returns,
            covariance_matrix=covariance_matrix,
            constraints=constraints
        )
        
        # Portföy metriklerini hesapla
        portfolio_return = np.dot(weights, expected_returns)
        portfolio_risk = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
        sharpe_ratio = (portfolio_return - self.config.optimization.risk_free_rate) / portfolio_risk
        
        return PortfolioResult(
            weights=weights,
            expected_return=portfolio_return,
            expected_risk=portfolio_risk,
            sharpe_ratio=sharpe_ratio
        )
        
    def _optimize_black_litterman(self,
                                 expected_returns: np.ndarray,
                                 covariance_matrix: np.ndarray,
                                 views: Optional[np.ndarray],
                                 **kwargs) -> PortfolioResult:
        """Black-Litterman optimizasyonu"""
        if views is None:
            # Basit view (tüm varlıklar için nötr)
            views = np.zeros(len(expected_returns))
            
        weights = self.black_litterman.optimize(
            prior_returns=expected_returns,
            prior_covariance=covariance_matrix,
            views=views,
            view_uncertainty=kwargs.get('view_uncertainty', 0.1)
        )
        
        # Posterior metriklerini hesapla
        posterior_return = self.black_litterman.get_posterior_mean()
        posterior_risk = self.black_litterman.get_posterior_risk()
        
        return PortfolioResult(
            weights=weights,
            expected_return=posterior_return,
            expected_risk=posterior_risk,
            sharpe_ratio=(posterior_return - self.config.optimization.risk_free_rate) / posterior_risk
        )
        
    def _optimize_risk_parity(self,
                             covariance_matrix: np.ndarray,
                             **kwargs) -> PortfolioResult:
        """Risk Parity optimizasyonu"""
        target_risks = kwargs.get('target_risks')  # Opsiyonel özel risk hedefleri
        
        weights = self.risk_parity.optimize(
            covariance_matrix=covariance_matrix,
            target_risks=target_risks
        )
        
        # Risk parity portföy metriklerini hesapla
        portfolio_risk = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
        
        # Risk parity'nin hedefi eşit risk katkısı olduğu için getiri estimate yok
        # Basit bir proxy kullanabiliriz
        portfolio_return = np.sum(weights) * 0.08  # 8% basit tahmin
        
        return PortfolioResult(
            weights=weights,
            expected_return=portfolio_return,
            expected_risk=portfolio_risk,
            sharpe_ratio=portfolio_return / portfolio_risk  # Risk-free rate ihmal
        )
        
    def _optimize_factor_model(self,
                              expected_returns: np.ndarray,
                              covariance_matrix: np.ndarray,
                              factor_loadings: Optional[np.ndarray],
                              **kwargs) -> PortfolioResult:
        """Factor model optimizasyonu"""
        if factor_loadings is None:
            factor_loadings = self.data_manager.get_factor_loadings()
            
        weights = self.factor_model.optimize(
            expected_returns=expected_returns,
            covariance_matrix=covariance_matrix,
            factor_loadings=factor_loadings
        )
        
        # Factor model metriklerini hesapla
        portfolio_return = np.dot(weights, expected_returns)
        portfolio_risk = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
        
        return PortfolioResult(
            weights=weights,
            expected_return=portfolio_return,
            expected_risk=portfolio_risk,
            sharpe_ratio=(portfolio_return - self.config.optimization.risk_free_rate) / portfolio_risk
        )
        
    def _optimize_multi_objective(self,
                                 expected_returns: np.ndarray,
                                 covariance_matrix: np.ndarray,
                                 objectives: List[str],
                                 **kwargs) -> PortfolioResult:
        """Multi-objective optimizasyon"""
        # Liquidity scores (volume tabanlı proxy)
        liquidity_scores = self._get_liquidity_scores()
        
        weights = self.multi_objective.optimize(
            expected_returns=expected_returns,
            covariance_matrix=covariance_matrix,
            liquidity_scores=liquidity_scores,
            esg_scores=self._get_esg_scores(),
            objectives=objectives,
            weights_config={
                'return': kwargs.get('return_weight', 0.4),
                'risk': kwargs.get('risk_weight', 0.4),
                'liquidity': kwargs.get('liquidity_weight', 0.1),
                'esg': kwargs.get('esg_weight', 0.1)
            }
        )
        
        # Multi-objective portföy metrikleri
        portfolio_return = np.dot(weights, expected_returns)
        portfolio_risk = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
        
        return PortfolioResult(
            weights=weights,
            expected_return=portfolio_return,
            expected_risk=portfolio_risk,
            sharpe_ratio=(portfolio_return - self.config.optimization.risk_free_rate) / portfolio_risk
        )
        
    def dynamic_allocation(self, 
                          market_regime: str,
                          current_portfolio: PortfolioResult) -> PortfolioResult:
        """
        Dinamik varlık tahsisi
        
        Args:
            market_regime: Market rejimi ('bull', 'bear', 'sideways', 'high_vol', 'low_vol')
            current_portfolio: Mevcut portföy
        """
        # Market rejime göre parametreleri ayarla
        regime_params = self._get_regime_parameters(market_regime)
        
        # Risk aversion'ı rejime göre ayarla
        original_risk_aversion = self.config.optimization.risk_aversion
        self.config.optimization.risk_aversion = regime_params['risk_aversion']
        
        # Maksimum pozisyon büyüklüğünü rejime göre ayarla
        original_max_position = self.config.optimization.max_weight
        self.config.optimization.max_weight = regime_params['max_position']
        
        try:
            # Optimizasyonu çalıştır
            optimal_portfolio = self.optimize_portfolio(
                method="markowitz",
                current_weights=current_portfolio.weights
            )
            
            return optimal_portfolio
            
        finally:
            # Parametreleri geri al
            self.config.optimization.risk_aversion = original_risk_aversion
            self.config.optimization.max_weight = original_max_position
            
    def _get_regime_parameters(self, regime: str) -> Dict:
        """Market rejime göre parametreler"""
        regime_map = {
            'bull': {
                'risk_aversion': 0.5,  # Daha agresif
                'max_position': 0.4    # Daha büyük pozisyonlar
            },
            'bear': {
                'risk_aversion': 3.0,  # Daha temkinli
                'max_position': 0.2    # Daha küçük pozisyonlar
            },
            'sideways': {
                'risk_aversion': 1.5,
                'max_position': 0.25
            },
            'high_vol': {
                'risk_aversion': 2.5,
                'max_position': 0.15
            },
            'low_vol': {
                'risk_aversion': 0.8,
                'max_position': 0.35
            }
        }
        
        return regime_map.get(regime, regime_map['sideways'])
        
    def rebalance_portfolio(self, 
                           current_portfolio: PortfolioResult,
                           optimal_portfolio: PortfolioResult) -> OptimizationResult:
        """Portföy yeniden dengeleme"""
        # Rebalancing gerekli mi kontrol et
        rebalancing_required, trades = self.rebalancing.calculate_rebalancing(
            current_weights=current_portfolio.weights,
            target_weights=optimal_portfolio.weights,
            current_prices=None  # Real-time fiyatlar kullanılır
        )
        
        # Performans metrikleri
        performance_metrics = self._calculate_performance_metrics(
            current_portfolio, optimal_portfolio
        )
        
        # Risk metrikleri
        risk_metrics = self._calculate_risk_metrics(optimal_portfolio.weights)
        
        return OptimizationResult(
            current_portfolio=current_portfolio,
            optimal_portfolio=optimal_portfolio,
            rebalancing_required=rebalancing_required,
            suggested_trades=trades,
            performance_metrics=performance_metrics,
            risk_metrics=risk_metrics
        )
        
    def _get_returns_matrix(self) -> np.ndarray:
        """Returns matrix'i al"""
        returns_df = pd.DataFrame({
            symbol: data.returns 
            for symbol, data in self.data_manager.assets_data.items()
        })
        return returns_df.values
        
    def _get_expected_returns(self) -> np.ndarray:
        """Beklenen getiri tahmini"""
        returns_df = pd.DataFrame({
            symbol: data.returns 
            for symbol, data in self.data_manager.assets_data.items()
        })
        
        # Historical mean + momentum adjustment
        historical_mean = returns_df.mean().values
        
        # Momentum (son 60 günlük trend)
        momentum = returns_df.tail(60).mean().values * 0.3
        
        # Composite expectation
        expected_returns = 0.7 * historical_mean + 0.3 * momentum
        
        return expected_returns
        
    def _get_covariance_matrix(self) -> np.ndarray:
        """Covariance matrix'i al"""
        if self.data_manager.covariance_matrix is not None:
            return self.data_manager.covariance_matrix
        else:
            # Hesapla
            returns_df = pd.DataFrame({
                symbol: data.returns 
                for symbol, data in self.data_manager.assets_data.items()
            })
            return returns_df.cov().values * 252  # Annualized
            
    def _get_esg_scores(self) -> Optional[np.ndarray]:
        """ESG skorları"""
        if not self.data_manager.esg_data:
            return None
            
        symbols = list(self.data_manager.assets_data.keys())
        esg_scores = []
        
        for symbol in symbols:
            if symbol in self.data_manager.esg_data:
                esg_scores.append(self.data_manager.esg_data[symbol].esg_score)
            else:
                esg_scores.append(50.0)  # Default score
                
        return np.array(esg_scores)
        
    def _get_liquidity_scores(self) -> np.ndarray:
        """Liquidity skorları (volume tabanlı proxy)"""
        returns_df = pd.DataFrame({
            symbol: data.returns 
            for symbol, data in self.data_manager.assets_data.items()
        })
        
        # Volume proxy olarak returns volatilitesi kullan
        volatility = returns_df.std().values
        
        # Daha az volatil = daha likit
        liquidity_scores = 1.0 / (1.0 + volatility)
        liquidity_scores = liquidity_scores / np.sum(liquidity_scores)  # Normalize
        
        return liquidity_scores
        
    def _add_risk_metrics(self, result: PortfolioResult, returns: np.ndarray) -> PortfolioResult:
        """Risk metriklerini ekle"""
        # VaR ve CVaR hesapla
        portfolio_returns = np.dot(returns, result.weights)
        
        var_95 = self.var_calculator.calculate_var(portfolio_returns, confidence=0.95)
        cvar_95 = self.var_calculator.calculate_cvar(portfolio_returns, confidence=0.95)
        
        result.var_95 = var_95
        result.cvar_95 = cvar_95
        
        return result
        
    def _calculate_performance_metrics(self, current: PortfolioResult, optimal: PortfolioResult) -> Dict:
        """Performans metrikleri hesapla"""
        return {
            'current_sharpe': current.sharpe_ratio,
            'optimal_sharpe': optimal.sharpe_ratio,
            'sharpe_improvement': optimal.sharpe_ratio - current.sharpe_ratio,
            'current_return': current.expected_return,
            'optimal_return': optimal.expected_return,
            'return_improvement': optimal.expected_return - current.expected_return,
            'current_risk': current.expected_risk,
            'optimal_risk': optimal.expected_risk,
            'risk_reduction': current.expected_risk - optimal.expected_risk
        }
        
    def _calculate_risk_metrics(self, weights: np.ndarray) -> Dict:
        """Risk metrikleri hesapla"""
        returns = self._get_returns_matrix()
        portfolio_returns = np.dot(returns, weights)
        
        return {
            'var_95': self.var_calculator.calculate_var(portfolio_returns, 0.95),
            'cvar_95': self.var_calculator.calculate_cvar(portfolio_returns, 0.95),
            'max_drawdown': self._calculate_max_drawdown(portfolio_returns),
            'volatility': np.std(portfolio_returns) * np.sqrt(252),
            'diversification_ratio': self._calculate_diversification_ratio(weights)
        }
        
    def _calculate_max_drawdown(self, returns: np.ndarray) -> float:
        """Maksimum drawdown hesapla"""
        cumulative_returns = (1 + pd.Series(returns)).cumprod()
        running_max = cumulative_returns.expanding().max()
        drawdown = (cumulative_returns - running_max) / running_max
        return drawdown.min()
        
    def _calculate_diversification_ratio(self, weights: np.ndarray) -> float:
        """Diversifikasyon oranı hesapla"""
        covariance_matrix = self._get_covariance_matrix()
        
        # Portföy volatilitesi
        portfolio_variance = np.dot(weights, np.dot(covariance_matrix, weights))
        portfolio_volatility = np.sqrt(portfolio_variance)
        
        # Ağırlıklı ortalama volatilite
        volatilities = np.sqrt(np.diag(covariance_matrix))
        weighted_avg_vol = np.dot(weights, volatilities)
        
        return weighted_avg_vol / portfolio_volatility if portfolio_volatility > 0 else 1.0
        
    def get_optimization_history(self) -> List[OptimizationResult]:
        """Optimizasyon geçmişi"""
        return self.optimization_history
        
    def save_optimization_result(self, result: OptimizationResult):
        """Optimizasyon sonucunu kaydet"""
        self.optimization_history.append(result)
        
        # Son 100 sonucu tut (memory management)
        if len(self.optimization_history) > 100:
            self.optimization_history = self.optimization_history[-100:]
            
    def generate_report(self, result: OptimizationResult) -> str:
        """Detaylı rapor oluştur"""
        symbols = list(self.data_manager.assets_data.keys())
        
        report = f"""
PORTFÖY OPTİMİZASYON RAPORU
============================

Tarih: {result.timestamp.strftime('%Y-%m-%d %H:%M:%S')}

Mevcut Portföy:
- Beklenen Getiri: {result.current_portfolio.expected_return:.2%}
- Beklenen Risk: {result.current_portfolio.expected_risk:.2%}
- Sharpe Oranı: {result.current_portfolio.sharpe_ratio:.3f}
- VaR(95%): {result.current_portfolio.var_95:.2%}
- CVaR(95%): {result.current_portfolio.cvar_95:.2%}

Optimal Portföy (Yöntem: {result.optimal_portfolio.optimization_method}):
- Beklenen Getiri: {result.optimal_portfolio.expected_return:.2%}
- Beklenen Risk: {result.optimal_portfolio.expected_risk:.2%}
- Sharpe Oranı: {result.optimal_portfolio.sharpe_ratio:.3f}
- VaR(95%): {result.optimal_portfolio.var_95:.2%}
- CVaR(95%): {result.optimal_portfolio.cvar_95:.2%}
- ESG Skoru: {result.optimal_portfolio.esg_score:.1f}

Performans İyileştirmeleri:
- Sharpe Artışı: {result.performance_metrics['sharpe_improvement']:.3f}
- Getiri Artışı: {result.performance_metrics['return_improvement']:.2%}
- Risk Azalışı: {result.performance_metrics['risk_reduction']:.2%}

Rebalancing:
- Gerekli: {'Evet' if result.rebalancing_required else 'Hayır'}
- Önerilen İşlem Sayısı: {len(result.suggested_trades)}

Optimal Ağırlıklar:
"""
        
        for i, symbol in enumerate(symbols):
            weight = result.optimal_portfolio.weights[i]
            if weight > 0.01:  # Sadece %1'den büyük ağırlıkları göster
                report += f"- {symbol}: {weight:.1%}\n"
                
        return report
        
    def shutdown(self):
        """Sistem kapatma"""
        self.logger.info("Shutting down portfolio optimization system...")
        self.data_manager.stop_real_time_updates()
        self.logger.info("System shutdown complete")
