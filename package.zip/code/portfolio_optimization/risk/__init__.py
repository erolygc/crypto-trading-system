"""
Risk Management Module
"""

from .var_calculator import VaRCalculator

__all__ = [
    'VaRCalculator'
]