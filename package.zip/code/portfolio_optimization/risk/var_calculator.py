"""
Value at Risk (VaR) and Conditional VaR (CVaR) Calculator
Risk measurement and analysis tools
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
import logging
from scipy import stats
from scipy.optimize import minimize
import warnings

from core.config import RiskConfig


class VaRCalculator:
    """
    Value at Risk (VaR) and Conditional VaR (CVaR) Calculator
    
    Implements multiple VaR calculation methods:
    - Historical Simulation VaR
    - Parametric VaR (Normal, t-distribution)
    - Monte Carlo VaR
    - Modified Cornish-Fisher VaR
    """
    
    def __init__(self, config: RiskConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
    def calculate_var(self,
                     returns: np.ndarray,
                     confidence: float = None,
                     method: str = None) -> float:
        """
        Calculate Value at Risk
        
        Args:
            returns: Portfolio returns series
            confidence: Confidence level (e.g., 0.95 for 95%)
            method: VaR calculation method
            
        Returns:
            VaR value (positive number representing loss)
        """
        if confidence is None:
            confidence = self.config.var_confidence
            
        if method is None:
            method = self.config.var_method
            
        if method == "historical":
            return self._historical_var(returns, confidence)
        elif method == "parametric":
            return self._parametric_var(returns, confidence)
        elif method == "monte_carlo":
            return self._monte_carlo_var(returns, confidence)
        elif method == "modified":
            return self._modified_var(returns, confidence)
        else:
            raise ValueError(f"Unknown VaR method: {method}")
            
    def _historical_var(self, returns: np.ndarray, confidence: float) -> float:
        """Historical Simulation VaR"""
        if len(returns) < 10:
            self.logger.warning("Insufficient data for historical VaR")
            return np.std(returns) * 2.33  # Rough approximation
            
        # Sort returns in ascending order
        sorted_returns = np.sort(returns)
        
        # Calculate VaR threshold
        var_percentile = (1 - confidence) * 100
        var_threshold = np.percentile(sorted_returns, var_percentile)
        
        # VaR is positive (representing loss)
        var_value = -var_threshold
        
        return max(var_value, 0.0)  # Ensure non-negative
        
    def _parametric_var(self, returns: np.ndarray, confidence: float) -> float:
        """Parametric VaR using normal distribution"""
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        
        # Z-score for confidence level
        z_score = stats.norm.ppf(1 - confidence)
        
        # VaR calculation
        var_value = -(mean_return + z_score * std_return)
        
        return max(var_value, 0.0)
        
    def _monte_carlo_var(self, returns: np.ndarray, confidence: float, 
                        n_simulations: int = 10000) -> float:
        """Monte Carlo VaR"""
        # Fit normal distribution to returns
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        
        # Generate random scenarios
        simulated_returns = np.random.normal(mean_return, std_return, n_simulations)
        
        # Calculate VaR
        sorted_simulated = np.sort(simulated_returns)
        var_percentile = (1 - confidence) * 100
        var_threshold = np.percentile(sorted_simulated, var_percentile)
        
        var_value = -var_threshold
        
        return max(var_value, 0.0)
        
    def _modified_var(self, returns: np.ndarray, confidence: float) -> float:
        """Modified VaR using Cornish-Fisher expansion"""
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        
        # Calculate higher moments
        skewness = stats.skew(returns)
        kurtosis = stats.kurtosis(returns, fisher=True)  # Excess kurtosis
        
        # Z-score for confidence level
        z = stats.norm.ppf(1 - confidence)
        
        # Cornish-Fisher adjustment
        z_cf = z + (z**2 - 1) * skewness / 6 + (z**3 - 3*z) * kurtosis / 24 - \
               (2*z**3 - 5*z) * (skewness**2) / 36
               
        # Modified VaR
        var_value = -(mean_return + z_cf * std_return)
        
        return max(var_value, 0.0)
        
    def calculate_cvar(self,
                      returns: np.ndarray,
                      confidence: float = None,
                      method: str = None) -> float:
        """
        Calculate Conditional Value at Risk (CVaR)
        
        Also known as Expected Shortfall (ES)
        
        Args:
            returns: Portfolio returns series
            confidence: Confidence level
            method: CVaR calculation method
            
        Returns:
            CVaR value (positive number representing expected loss beyond VaR)
        """
        if confidence is None:
            confidence = self.config.cvar_confidence
            
        if method is None:
            method = self.config.var_method
            
        # First calculate VaR
        var_value = self.calculate_var(returns, confidence, method)
        
        # Find the VaR threshold
        var_threshold = -var_value
        
        # CVaR is the average of returns worse than VaR
        tail_returns = returns[returns <= var_threshold]
        
        if len(tail_returns) == 0:
            return var_value  # Fallback to VaR
            
        cvar_value = -np.mean(tail_returns)
        
        return max(cvar_value, var_value)  # CVaR should be >= VaR
        
    def calculate_esg_var(self,
                         returns: np.ndarray,
                         esg_scores: np.ndarray,
                         esg_weight: float = 0.1) -> float:
        """
        Calculate ESG-adjusted VaR
        
        Applies ESG penalty to risk calculation
        
        Args:
            returns: Portfolio returns
            esg_scores: ESG scores for portfolio assets
            esg_weight: Weight given to ESG in risk adjustment
            
        Returns:
            ESG-adjusted VaR
        """
        # Calculate base VaR
        base_var = self.calculate_var(returns)
        
        # ESG adjustment factor
        avg_esg_score = np.mean(esg_scores) / 100.0  # Normalize to 0-1
        
        # Lower ESG scores increase risk
        esg_penalty = (1 - avg_esg_score) * esg_weight
        
        esg_adjusted_var = base_var * (1 + esg_penalty)
        
        return esg_adjusted_var
        
    def backtest_var(self,
                    returns: np.ndarray,
                    var_estimates: np.ndarray,
                    confidence: float = 0.95) -> Dict:
        """
        Backtest VaR estimates
        
        Test how often actual losses exceeded VaR estimates
        
        Args:
            returns: Actual portfolio returns
            var_estimates: VaR estimates (one per day)
            confidence: Confidence level
            
        Returns:
            Backtest results
        """
        if len(returns) != len(var_estimates):
            raise ValueError("Returns and VaR estimates must have same length")
            
        # Identify VaR violations
        violations = returns < -var_estimates  # Losses worse than VaR
        
        # Expected violation rate
        expected_violations = (1 - confidence) * len(returns)
        actual_violations = np.sum(violations)
        
        # Violation rate
        violation_rate = actual_violations / len(returns)
        
        # Kupiec test (unconditional coverage test)
        lr_uc = self._kupiec_test(returns, var_estimates, confidence)
        
        # Christoffersen test (conditional coverage test)
        lr_cc = self._christoffersen_test(violations)
        
        return {
            'total_observations': len(returns),
            'expected_violations': expected_violations,
            'actual_violations': actual_violations,
            'violation_rate': violation_rate,
            'expected_violation_rate': 1 - confidence,
            'kupiec_statistic': lr_uc['statistic'],
            'kupiec_p_value': lr_uc['p_value'],
            'christoffersen_statistic': lr_cc['statistic'],
            'christoffersen_p_value': lr_cc['p_value'],
            'violations': violations,
            'violation_dates': np.where(violations)[0]
        }
        
    def _kupiec_test(self, returns: np.ndarray, var_estimates: np.ndarray, confidence: float) -> Dict:
        """
        Kupiec Unconditional Coverage Test
        
        Tests if the violation rate is consistent with the confidence level
        """
        violations = returns < -var_estimates
        n = len(returns)
        x = np.sum(violations)
        p = 1 - confidence
        
        if x == 0:
            statistic = 0
            p_value = 1
        else:
            # Likelihood ratio statistic
            statistic = -2 * np.log((p**x * (1-p)**(n-x)) / ((x/n)**x * (1-x/n)**(n-x)))
            # Chi-square test with 1 degree of freedom
            p_value = 1 - stats.chi2.cdf(statistic, 1)
            
        return {'statistic': statistic, 'p_value': p_value}
        
    def _christoffersen_test(self, violations: np.ndarray) -> Dict:
        """
        Christoffersen Conditional Coverage Test
        
        Tests if violations are independent (no clustering)
        """
        n = len(violations)
        
        if n < 2:
            return {'statistic': 0, 'p_value': 1}
            
        # Count violation patterns
        n00 = np.sum((violations[:-1] == 0) & (violations[1:] == 0))
        n01 = np.sum((violations[:-1] == 0) & (violations[1:] == 1))
        n10 = np.sum((violations[:-1] == 1) & (violations[1:] == 0))
        n11 = np.sum((violations[:-1] == 1) & (violations[1:] == 1))
        
        # Transition probabilities
        p01 = n01 / (n00 + n01) if (n00 + n01) > 0 else 0
        p11 = n11 / (n10 + n11) if (n10 + n11) > 0 else 0
        
        # Overall violation rate
        pi = np.mean(violations)
        
        if pi == 0 or pi == 1:
            return {'statistic': 0, 'p_value': 1}
            
        # Likelihood ratio statistic
        lr = -2 * np.log((pi**(n00 + n10) * (1-pi)**(n01 + n11)) /
                        ((1-p01)**n00 * p01**n01 * (1-p11)**n10 * p11**n11))
                        
        # Chi-square test with 1 degree of freedom
        p_value = 1 - stats.chi2.cdf(lr, 1)
        
        return {'statistic': lr, 'p_value': p_value}
        
    def stress_test_var(self,
                       returns: np.ndarray,
                       stress_scenarios: List[Dict] = None) -> Dict:
        """
        Perform stress tests on VaR calculations
        
        Args:
            returns: Portfolio returns
            stress_scenarios: List of stress scenarios
            
        Returns:
            Stress test results
        """
        if stress_scenarios is None:
            stress_scenarios = self.config.stress_scenarios
            
        stress_results = {}
        
        for scenario in stress_scenarios:
            scenario_name = scenario['name']
            shock_return = scenario['return']
            duration = scenario.get('duration', 1)
            
            try:
                # Apply stress scenario to returns
                stressed_returns = self._apply_stress_scenario(returns, shock_return, duration)
                
                # Calculate VaR under stress
                stressed_var = self.calculate_var(stressed_returns)
                stressed_cvar = self.calculate_cvar(stressed_returns)
                
                # Calculate baseline VaR for comparison
                baseline_var = self.calculate_var(returns)
                baseline_cvar = self.calculate_cvar(returns)
                
                stress_results[scenario_name] = {
                    'shock_magnitude': shock_return,
                    'duration': duration,
                    'stressed_var': stressed_var,
                    'stressed_cvar': stressed_cvar,
                    'baseline_var': baseline_var,
                    'baseline_cvar': baseline_cvar,
                    'var_increase': stressed_var - baseline_var,
                    'cvar_increase': stressed_cvar - baseline_cvar,
                    'var_multiplier': stressed_var / baseline_var if baseline_var > 0 else 0
                }
                
            except Exception as e:
                self.logger.error(f"Error in stress test {scenario_name}: {e}")
                stress_results[scenario_name] = {'error': str(e)}
                
        return stress_results
        
    def _apply_stress_scenario(self, returns: np.ndarray, shock_return: float, duration: int) -> np.ndarray:
        """Apply stress scenario to returns"""
        stressed_returns = returns.copy()
        
        # Apply shock to the last 'duration' observations
        for i in range(max(0, len(stressed_returns) - duration), len(stressed_returns)):
            stressed_returns[i] = shock_return
            
        return stressed_returns
        
    def dynamic_var(self, returns: np.ndarray, window_size: int = 252) -> np.ndarray:
        """
        Calculate rolling/dynamic VaR
        
        Args:
            returns: Portfolio returns series
            window_size: Rolling window size
            
        Returns:
            Array of rolling VaR estimates
        """
        n_periods = len(returns)
        rolling_var = np.zeros(n_periods)
        
        for i in range(window_size, n_periods):
            window_returns = returns[i-window_size:i]
            rolling_var[i] = self.calculate_var(window_returns)
            
        # For the first 'window_size' periods, use expanding window
        for i in range(1, window_size):
            expanding_returns = returns[:i+1]
            rolling_var[i] = self.calculate_var(expanding_returns)
            
        return rolling_var
        
    def portfolio_var_decomposition(self,
                                   weights: np.ndarray,
                                   covariance_matrix: np.ndarray,
                                   confidence: float = 0.95) -> Dict:
        """
        Decompose portfolio VaR into component contributions
        
        Args:
            weights: Portfolio weights
            covariance_matrix: Covariance matrix
            confidence: Confidence level
            
        Returns:
            VaR decomposition
        """
        n_assets = len(weights)
        
        # Portfolio volatility
        portfolio_vol = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
        
        # VaR (normal approximation)
        z_score = stats.norm.ppf(1 - confidence)
        portfolio_var = z_score * portfolio_vol
        
        # Marginal VaR (marginal contribution to VaR)
        marginal_var = z_score * (covariance_matrix @ weights) / portfolio_vol
        
        # Component VaR
        component_var = weights * marginal_var
        
        # Percentage contribution to VaR
        var_contributions = component_var / portfolio_var
        
        return {
            'portfolio_var': portfolio_var,
            'marginal_var': marginal_var,
            'component_var': component_var,
            'var_contributions': var_contributions,
            'confidence_level': confidence,
            'volatility_contribution': {
                'total_vol': portfolio_vol,
                'component_vol_contributions': portfolio_vol * var_contributions
            }
        }
        
    def calculate_esg_risk_adjusted_var(self,
                                      returns: np.ndarray,
                                      esg_scores: np.ndarray,
                                      esg_weights: np.ndarray,
                                      esg_config: Dict) -> Dict:
        """
        Calculate ESG risk-adjusted VaR with ESG constraints
        
        Args:
            returns: Portfolio returns
            esg_scores: ESG scores for each asset
            esg_weights: Portfolio weights
            esg_config: ESG configuration parameters
            
        Returns:
            ESG risk-adjusted VaR metrics
        """
        # Base VaR
        base_var = self.calculate_var(returns)
        
        # ESG sector/category adjustments
        esg_penalty_factors = esg_config.get('penalty_factors', {})
        min_esg_score = esg_config.get('min_esg_score', 50.0)
        
        # Calculate ESG-adjusted risk
        weighted_esg_score = np.sum(esg_weights * esg_scores)
        
        # ESG penalty based on portfolio ESG score
        if weighted_esg_score < min_esg_score:
            esg_penalty = (min_esg_score - weighted_esg_score) / min_esg_score
        else:
            esg_penalty = 0
            
        # Apply ESG penalty to VaR
        esg_adjusted_var = base_var * (1 + esg_penalty)
        
        # Calculate sector-based penalties
        sector_adjustments = {}
        for sector, penalty_factor in esg_penalty_factors.items():
            sector_weight = np.sum(esg_weights)  # Simplified
            sector_adjustments[sector] = penalty_factor * sector_weight
            
        return {
            'base_var': base_var,
            'esg_adjusted_var': esg_adjusted_var,
            'esg_penalty': esg_penalty,
            'weighted_esg_score': weighted_esg_score,
            'min_esg_score': min_esg_score,
            'sector_adjustments': sector_adjustments,
            'var_increase_due_to_esg': esg_adjusted_var - base_var
        }
        
    def report_var_metrics(self, returns: np.ndarray, confidence: float = 0.95) -> str:
        """
        Generate comprehensive VaR report
        
        Args:
            returns: Portfolio returns
            confidence: Confidence level
            
        Returns:
            Formatted VaR report
        """
        # Calculate all VaR metrics
        historical_var = self.calculate_var(returns, confidence, 'historical')
        parametric_var = self.calculate_var(returns, confidence, 'parametric')
        modified_var = self.calculate_var(returns, confidence, 'modified')
        cvar_value = self.calculate_cvar(returns, confidence)
        
        # Additional statistics
        mean_return = np.mean(returns)
        volatility = np.std(returns)
        skewness = stats.skew(returns)
        kurtosis = stats.kurtosis(returns, fisher=True)
        
        report = f"""
VALUE AT RISK RAPORU
===================

Risk Ölçütleri:
- Beklenen Getiri: {mean_return:.2%}
- Volatilite: {volatility:.2%}
- Skewness: {skewness:.3f}
- Kurtosis: {kurtosis:.3f}

VaR Metodları ({confidence*100:.0f}% güven seviyesi):
- Tarihsel VaR: {historical_var:.2%}
- Parametrik VaR: {parametric_var:.2%}
- Modified VaR: {modified_var:.2%}
- CVaR (Expected Shortfall): {cvar_value:.2%}

Risk Yorumu:
- En Yüksek Risk: {max(historical_var, parametric_var, modified_var):.2%}
- En Düşük Risk: {min(historical_var, parametric_var, modified_var):.2%}
- CVaR/ VaR Oranı: {cvar_value/historical_var:.2f}

Değerlendirme:
- {'Yüksek Risk' if historical_var > 0.02 else 'Orta Risk' if historical_var > 0.01 else 'Düşük Risk'} 
- {'Fazla Negatif Çarpıklık' if skewness < -0.5 else 'Normal Çarpıklık' if abs(skewness) < 0.5 else 'Pozitif Çarpıklık'}
- {'Yüksek Kurtosis' if kurtosis > 3 else 'Normal Kurtosis' if abs(kurtosis) < 3 else 'Düşük Kurtosis'}
"""
        
        return report
