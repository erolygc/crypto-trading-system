#!/usr/bin/env python3
"""
Test script for Portfolio Optimization System
"""

import sys
import numpy as np
import traceback

# Add the current directory to path
sys.path.append('/workspace/code/portfolio_optimization')

def test_imports():
    """Test all imports"""
    try:
        from core.config import Config, OptimizationConfig, DataConfig, RiskConfig
        from core.data_manager import DataManager
        from core.portfolio_optimizer import PortfolioOptimizer, PortfolioResult
        from models.markowitz import MarkowitzOptimizer
        from models.black_litterman import BlackLittermanOptimizer
        from models.risk_parity import RiskParityOptimizer
        from models.factor_models import FactorModelOptimizer
        from models.multi_objective import MultiObjectiveOptimizer
        from risk.var_calculator import VaRCalculator
        from utils.constraints import ConstraintHandler
        from utils.rebalancing import RebalancingEngine
        
        print("✓ All imports successful")
        return True
    except Exception as e:
        print(f"✗ Import failed: {e}")
        traceback.print_exc()
        return False

def test_config():
    """Test configuration system"""
    try:
        from core.config import Config, OptimizationConfig, DataConfig, RiskConfig
        
        config = Config()
        print(f"✓ Config created with {len(config.get_asset_universe())} assets")
        
        # Test parameter updates
        config.update_optimization_params(risk_aversion=2.0)
        assert config.optimization.risk_aversion == 2.0
        
        print("✓ Config parameter updates work")
        return True
    except Exception as e:
        print(f"✗ Config test failed: {e}")
        traceback.print_exc()
        return False

def test_optimizer():
    """Test basic optimization"""
    try:
        from core.config import Config
        from models.markowitz import MarkowitzOptimizer
        
        config = Config()
        optimizer = MarkowitzOptimizer(config.optimization)
        
        # Create sample data
        np.random.seed(42)
        expected_returns = np.array([0.08, 0.06, 0.10, 0.07, 0.05])
        covariance_matrix = np.eye(5) * 0.04
        
        # Test optimization
        weights = optimizer.optimize(
            expected_returns=expected_returns,
            covariance_matrix=covariance_matrix,
            method="max_sharpe"
        )
        
        assert len(weights) == 5
        assert abs(np.sum(weights) - 1.0) < 1e-6
        assert np.all(weights >= 0)
        
        print(f"✓ Markowitz optimization successful: {weights}")
        return True
    except Exception as e:
        print(f"✗ Optimizer test failed: {e}")
        traceback.print_exc()
        return False

def test_risk_parity():
    """Test risk parity optimization"""
    try:
        from core.config import Config
        from models.risk_parity import RiskParityOptimizer
        
        config = Config()
        optimizer = RiskParityOptimizer(config.optimization)
        
        # Sample covariance matrix
        covariance_matrix = np.array([
            [0.04, 0.01, 0.015],
            [0.01, 0.03, 0.008],
            [0.015, 0.008, 0.05]
        ])
        
        # Test risk parity
        weights = optimizer.optimize(covariance_matrix, method="equal_contribution")
        
        assert len(weights) == 3
        assert abs(np.sum(weights) - 1.0) < 1e-6
        
        # Test risk contributions
        risk_contrib = optimizer.calculate_risk_contributions(weights, covariance_matrix)
        assert len(risk_contrib) == 3
        
        print(f"✓ Risk parity optimization successful")
        return True
    except Exception as e:
        print(f"✗ Risk parity test failed: {e}")
        traceback.print_exc()
        return False

def test_var_calculator():
    """Test VaR calculator"""
    try:
        from core.config import Config
        from risk.var_calculator import VaRCalculator
        
        config = Config()
        var_calc = VaRCalculator(config.risk)
        
        # Generate sample returns
        np.random.seed(123)
        returns = np.random.normal(0.0005, 0.015, 252)
        
        # Test VaR calculations
        var_historical = var_calc.calculate_var(returns, method="historical")
        var_parametric = var_calc.calculate_var(returns, method="parametric")
        cvar_value = var_calc.calculate_cvar(returns)
        
        assert var_historical > 0
        assert var_parametric > 0
        assert cvar_value >= var_historical
        
        print(f"✓ VaR calculations successful: Historical={var_historical:.3f}")
        return True
    except Exception as e:
        print(f"✗ VaR calculator test failed: {e}")
        traceback.print_exc()
        return False

def test_constraints():
    """Test constraint handler"""
    try:
        from core.config import Config
        from utils.constraints import ConstraintHandler
        
        config = Config()
        handler = ConstraintHandler(config.optimization)
        
        # Test weight bounds
        constraint = handler.add_weight_bounds(0.05, 0.40)
        assert constraint.type == "weight_bounds"
        
        # Test budget constraint
        handler.add_budget_constraint()
        constraints = handler.get_standard_constraints()
        
        assert len(constraints) >= 2
        
        # Test constraint satisfaction
        weights = np.array([0.2, 0.3, 0.25, 0.15, 0.1])
        satisfaction = handler.check_constraint_satisfaction(weights)
        
        print(f"✓ Constraint handler working: {len(constraints)} constraints")
        return True
    except Exception as e:
        print(f"✗ Constraints test failed: {e}")
        traceback.print_exc()
        return False

def test_rebalancing():
    """Test rebalancing engine"""
    try:
        from core.config import Config
        from utils.rebalancing import RebalancingEngine
        
        config = Config()
        engine = RebalancingEngine(config.optimization)
        
        # Test rebalancing calculation
        current_weights = np.array([0.2, 0.3, 0.15, 0.25, 0.1])
        target_weights = np.array([0.18, 0.32, 0.17, 0.23, 0.1])
        
        rebalancing_required, trade_orders = engine.calculate_rebalancing(
            current_weights, target_weights
        )
        
        # Test turnover calculation
        turnover = engine.calculate_turnover(trade_orders)
        costs = engine.calculate_transaction_costs(trade_orders)
        
        assert isinstance(rebalancing_required, bool)
        assert isinstance(trade_orders, list)
        assert turnover >= 0
        assert costs >= 0
        
        print(f"✓ Rebalancing engine working: {len(trade_orders)} trades")
        return True
    except Exception as e:
        print(f"✗ Rebalancing test failed: {e}")
        traceback.print_exc()
        return False

def run_all_tests():
    """Run all tests"""
    print("PORTFÖY OPTİMİZASYON SİSTEMİ TESTLERİ")
    print("=" * 50)
    
    tests = [
        ("Imports", test_imports),
        ("Configuration", test_config),
        ("Markowitz Optimizer", test_optimizer),
        ("Risk Parity", test_risk_parity),
        ("VaR Calculator", test_var_calculator),
        ("Constraints", test_constraints),
        ("Rebalancing", test_rebalancing),
    ]
    
    passed = 0
    failed = 0
    
    for test_name, test_func in tests:
        print(f"\n--- {test_name} ---")
        try:
            if test_func():
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"✗ {test_name} crashed: {e}")
            failed += 1
    
    print("\n" + "=" * 50)
    print(f"TEST SONUÇLARI: {passed} başarılı, {failed} başarısız")
    
    if failed == 0:
        print("🎉 Tüm testler başarılı! Sistem hazır.")
        return True
    else:
        print("⚠️ Bazı testler başarısız. Lütfen hataları kontrol edin.")
        return False

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
