"""
Black-Litterman Portfolio Optimizer
Advanced portfolio optimization with investor views
"""

import numpy as np
import cvxpy as cp
from typing import Dict, List, Optional, Tuple
import logging
from scipy.optimize import minimize

from core.config import OptimizationConfig


class BlackLittermanOptimizer:
    """
    Black-Litterman Model Optimizer
    
    Incorporates investor views into portfolio optimization
    """
    
    def __init__(self, config: OptimizationConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Model parameters
        self.tau = config.tau  # Uncertainty in prior
        self.delta = config.delta  # Risk aversion parameter
        
        # Storage
        self.prior_mean: Optional[np.ndarray] = None
        self.prior_covariance: Optional[np.ndarray] = None
        self.posterior_mean: Optional[np.ndarray] = None
        self.posterior_covariance: Optional[np.ndarray] = None
        
    def optimize(self,
                prior_returns: np.ndarray,
                prior_covariance: np.ndarray,
                views: np.ndarray,
                view_uncertainty: float = 0.1,
                market_cap_weights: Optional[np.ndarray] = None,
                risk_aversion: Optional[float] = None) -> np.ndarray:
        """
        Black-Litterman optimization
        
        Args:
            prior_returns: Prior expected returns (equilibrium returns)
            prior_covariance: Prior covariance matrix
            views: Investor views vector
            view_uncertainty: Uncertainty in views
            market_cap_weights: Market cap weights for equilibrium
            risk_aversion: Risk aversion parameter
            
        Returns:
            Optimal portfolio weights
        """
        if risk_aversion is None:
            risk_aversion = self.delta
            
        n_assets = len(prior_returns)
        
        # Calculate equilibrium returns if not provided
        if market_cap_weights is None:
            market_cap_weights = np.ones(n_assets) / n_assets  # Equal weights
            
        # Equilibrium returns: π = δ * Σ * w_market
        equilibrium_returns = risk_aversion * np.dot(prior_covariance, market_cap_weights)
        
        # Store prior
        self.prior_mean = equilibrium_returns
        self.prior_covariance = prior_covariance
        
        # Black-Litterman adjustment
        posterior_results = self._black_litterman_adjustment(
            prior_mean=equilibrium_returns,
            prior_covariance=prior_covariance,
            views=views,
            view_uncertainty=view_uncertainty
        )
        
        self.posterior_mean = posterior_results['posterior_mean']
        self.posterior_covariance = posterior_results['posterior_covariance']
        
        # Optimize with posterior inputs
        weights = self._optimize_posterior(
            posterior_mean=self.posterior_mean,
            posterior_covariance=self.posterior_covariance,
            risk_aversion=risk_aversion
        )
        
        self.logger.info("Black-Litterman optimization completed successfully")
        return weights
        
    def _black_litterman_adjustment(self,
                                   prior_mean: np.ndarray,
                                   prior_covariance: np.ndarray,
                                   views: np.ndarray,
                                   view_uncertainty: float) -> Dict:
        """
        Apply Black-Litterman adjustment formula
        
        μ = τΣP'(PτΣP' + Ω)^(-1)(Q - Pπ) + π
        Σ = Σ + τΣP'(PτΣP' + Ω)^(-1)PτΣ
        
        where:
        - π = prior mean
        - Σ = prior covariance
        - P = view matrix
        - Q = view returns
        - Ω = view uncertainty matrix
        - τ = uncertainty scaling factor
        """
        n_assets = len(prior_mean)
        
        # View matrix P (identity for simplicity - each view is about one asset)
        P = np.eye(n_assets)
        
        # View uncertainty matrix Ω (diagonal)
        Omega = np.eye(n_assets) * view_uncertainty
        
        # Intermediate calculations
        tau_Sigma = self.tau * prior_covariance
        P_tau_Sigma = np.dot(P.T, tau_Sigma)
        P_tau_Sigma_P = np.dot(P_tau_Sigma, P)
        M = np.linalg.inv(P_tau_Sigma_P + Omega)
        
        # Posterior mean
        view_adjustment = np.dot(P_tau_Sigma, M)
        posterior_mean = prior_mean + np.dot(view_adjustment, views - np.dot(P, prior_mean))
        
        # Posterior covariance
        posterior_covariance = prior_covariance + tau_Sigma - np.dot(P_tau_Sigma, M)
        posterior_covariance = 0.5 * (posterior_covariance + posterior_covariance.T)  # Ensure symmetry
        
        return {
            'posterior_mean': posterior_mean,
            'posterior_covariance': posterior_covariance
        }
        
    def _optimize_posterior(self,
                           posterior_mean: np.ndarray,
                           posterior_covariance: np.ndarray,
                           risk_aversion: float) -> np.ndarray:
        """Optimize using posterior distribution"""
        n_assets = len(posterior_mean)
        
        def objective(weights):
            """Negative utility (to minimize)"""
            portfolio_return = np.dot(weights, posterior_mean)
            portfolio_variance = np.dot(weights, np.dot(posterior_covariance, weights))
            utility = portfolio_return - 0.5 * risk_aversion * portfolio_variance
            return -utility  # Minimize negative utility
            
        def constraint_weights_sum_to_one(weights):
            """Weights sum to 1 constraint"""
            return np.sum(weights) - 1.0
            
        def constraint_weights_bounds(weights):
            """Weight bounds constraint"""
            min_weight = self.config.min_weight
            max_weight = self.config.max_weight
            max_position = self.config.max_position
            
            constraints = []
            constraints.extend([min_weight - w for w in weights])  # w >= min_weight
            constraints.extend([w - max_weight for w in weights])   # w <= max_weight
            constraints.extend([w - max_position for w in weights]) # w <= max_position
            
            return np.array(constraints)
            
        # Initial guess (equal weights)
        x0 = np.ones(n_assets) / n_assets
        
        # Constraints
        constraints = [
            {'type': 'eq', 'fun': constraint_weights_sum_to_one},
            {'type': 'ineq', 'fun': constraint_weights_bounds}
        ]
        
        # Bounds for each weight
        bounds = [(self.config.min_weight, self.config.max_weight) for _ in range(n_assets)]
        
        try:
            # Optimize
            result = minimize(
                objective,
                x0,
                method='SLSQP',
                bounds=bounds,
                constraints=constraints,
                options={'maxiter': 1000, 'ftol': 1e-9}
            )
            
            if result.success:
                weights = result.x
                # Clean up numerical errors
                weights = np.round(weights, 6)
                weights = weights / np.sum(weights)  # Ensure sum = 1
                return weights
            else:
                self.logger.warning(f"Optimization failed: {result.message}")
                return np.ones(n_assets) / n_assets
                
        except Exception as e:
            self.logger.error(f"Error in Black-Litterman optimization: {e}")
            return np.ones(n_assets) / n_assets
            
    def get_posterior_mean(self) -> float:
        """Get posterior expected portfolio return"""
        if self.posterior_mean is not None:
            # Equal weights for reporting (could use optimal weights)
            n_assets = len(self.posterior_mean)
            weights = np.ones(n_assets) / n_assets
            return np.dot(weights, self.posterior_mean)
        return 0.0
        
    def get_posterior_risk(self) -> float:
        """Get posterior portfolio risk"""
        if self.posterior_covariance is not None:
            # Equal weights for reporting
            n_assets = len(self.posterior_covariance)
            weights = np.ones(n_assets) / n_assets
            portfolio_variance = np.dot(weights, np.dot(self.posterior_covariance, weights))
            return np.sqrt(portfolio_variance)
        return 0.0
        
    def add_view(self, asset_index: int, view_return: float, confidence: float = 1.0) -> np.ndarray:
        """
        Add a single view about an asset
        
        Args:
            asset_index: Index of the asset
            view_return: Expected return for the view
            confidence: Confidence in the view (0-1)
            
        Returns:
            Updated view vector
        """
        n_assets = max(asset_index + 1, 10)  # Assume at least 10 assets
        views = np.zeros(n_assets)
        views[asset_index] = view_return
        
        # Adjust uncertainty based on confidence
        view_uncertainty = 1.0 / confidence if confidence > 0 else 1.0
        
        return views, view_uncertainty
        
    def add_relative_view(self, asset1_index: int, asset2_index: int, 
                         view_spread: float, confidence: float = 1.0) -> Tuple[np.ndarray, float]:
        """
        Add relative view between two assets
        
        Args:
            asset1_index: First asset index
            asset2_index: Second asset index  
            view_spread: Expected spread (asset1 - asset2)
            confidence: Confidence in the view
            
        Returns:
            View vector and uncertainty
        """
        n_assets = max(asset1_index, asset2_index) + 1
        views = np.zeros(n_assets)
        views[asset1_index] = view_spread
        views[asset2_index] = -view_spread
        
        # Adjusted uncertainty for relative views
        view_uncertainty = 1.0 / confidence if confidence > 0 else 1.0
        
        return views, view_uncertainty
        
    def scenario_analysis(self,
                         prior_returns: np.ndarray,
                         prior_covariance: np.ndarray,
                         scenarios: List[Dict]) -> Dict:
        """
        Perform scenario analysis with Black-Litterman
        
        Args:
            prior_returns: Prior expected returns
            prior_covariance: Prior covariance matrix
            scenarios: List of scenario dictionaries with 'name' and 'views'
            
        Returns:
            Scenario analysis results
        """
        results = {}
        
        for scenario in scenarios:
            scenario_name = scenario['name']
            scenario_views = scenario['views']
            
            try:
                weights = self.optimize(
                    prior_returns=prior_returns,
                    prior_covariance=prior_covariance,
                    views=scenario_views
                )
                
                results[scenario_name] = {
                    'weights': weights,
                    'posterior_mean': self.posterior_mean,
                    'posterior_covariance': self.posterior_covariance
                }
                
            except Exception as e:
                self.logger.error(f"Error in scenario {scenario_name}: {e}")
                results[scenario_name] = {'error': str(e)}
                
        return results
        
    def stress_test(self,
                   prior_returns: np.ndarray,
                   prior_covariance: np.ndarray,
                   market_shock: float = -0.3,
                   view_uncertainty: float = 0.2) -> Dict:
        """
        Stress test with market shock
        
        Args:
            prior_returns: Prior expected returns
            prior_covariance: Prior covariance matrix
            market_shock: Market shock size (-0.3 = 30% down)
            view_uncertainty: Uncertainty in shock estimate
            
        Returns:
            Stress test results
        """
        # Create view: market will decline by market_shock
        n_assets = len(prior_returns)
        market_views = np.full(n_assets, market_shock / n_assets)  # Distributed view
        
        try:
            weights = self.optimize(
                prior_returns=prior_returns,
                prior_covariance=prior_covariance,
                views=market_views,
                view_uncertainty=view_uncertainty
            )
            
            return {
                'shock_scenario': {
                    'market_shock': market_shock,
                    'weights': weights,
                    'posterior_mean': self.posterior_mean,
                    'posterior_risk': self.get_posterior_risk()
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error in stress test: {e}")
            return {'error': str(e)}
            
    def confidence_intervals(self,
                           confidence_level: float = 0.95,
                           n_simulations: int = 10000) -> Dict:
        """
        Calculate confidence intervals for expected returns
        
        Args:
            confidence_level: Confidence level (0.95 for 95%)
            n_simulations: Number of Monte Carlo simulations
            
        Returns:
            Confidence intervals for each asset
        """
        if self.posterior_mean is None or self.posterior_covariance is None:
            raise ValueError("Must run optimization first to get posterior distribution")
            
        n_assets = len(self.posterior_mean)
        
        # Generate random samples from posterior distribution
        simulations = np.random.multivariate_normal(
            self.posterior_mean,
            self.posterior_covariance,
            n_simulations
        )
        
        # Calculate confidence intervals
        alpha = 1 - confidence_level
        lower_percentile = (alpha / 2) * 100
        upper_percentile = (1 - alpha / 2) * 100
        
        confidence_intervals = {}
        
        for i in range(n_assets):
            asset_simulations = simulations[:, i]
            lower_bound = np.percentile(asset_simulations, lower_percentile)
            upper_bound = np.percentile(asset_simulations, upper_percentile)
            mean_return = np.mean(asset_simulations)
            
            confidence_intervals[f'asset_{i}'] = {
                'mean': mean_return,
                'lower_bound': lower_bound,
                'upper_bound': upper_bound,
                'confidence_level': confidence_level
            }
            
        return confidence_intervals
        
    def calculate_implied_returns(self, market_weights: np.ndarray) -> np.ndarray:
        """
        Calculate implied market returns (equilibrium)
        
        Args:
            market_weights: Market capitalizations weights
            
        Returns:
            Implied expected returns
        """
        if self.prior_covariance is None:
            raise ValueError("Must provide covariance matrix first")
            
        # π = δ * Σ * w_market
        implied_returns = self.delta * np.dot(self.prior_covariance, market_weights)
        return implied_returns
