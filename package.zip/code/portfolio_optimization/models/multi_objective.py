"""
Multi-Objective Portfolio Optimizer
Simultaneous optimization of return, risk, liquidity, and ESG objectives
"""

import numpy as np
import pandas as pd
import cvxpy as cp
from typing import Dict, List, Optional, Tuple, Any
import logging
from dataclasses import dataclass
from scipy.optimize import minimize

from core.config import OptimizationConfig


@dataclass
class ObjectiveConfig:
    """Multi-objective optimization configuration"""
    return_weight: float = 0.4
    risk_weight: float = 0.4
    liquidity_weight: float = 0.1
    esg_weight: float = 0.1
    
    # Normalization parameters
    target_return: float = 0.10  # 10% annual target
    max_risk: float = 0.15       # 15% max risk
    min_liquidity: float = 0.5   # 50% min liquidity
    min_esg: float = 60.0        # 60 ESG score min


class MultiObjectiveOptimizer:
    """
    Multi-Objective Portfolio Optimizer
    
    Optimizes portfolios considering multiple objectives simultaneously:
    - Return maximization
    - Risk minimization
    - Liquidity maximization
    - ESG score maximization
    """
    
    def __init__(self, config: OptimizationConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Multi-objective configuration
        self.objective_config = ObjectiveConfig()
        
    def optimize(self,
                expected_returns: np.ndarray,
                covariance_matrix: np.ndarray,
                liquidity_scores: Optional[np.ndarray] = None,
                esg_scores: Optional[np.ndarray] = None,
                objectives: List[str] = None,
                weights_config: Optional[Dict] = None) -> np.ndarray:
        """
        Multi-objective optimization
        
        Args:
            expected_returns: Expected returns for each asset
            covariance_matrix: Covariance matrix of returns
            liquidity_scores: Liquidity scores (0-1 scale)
            esg_scores: ESG scores (0-100 scale)
            objectives: List of objectives to optimize
            weights_config: Weights for each objective
            
        Returns:
            Optimal portfolio weights
        """
        if objectives is None:
            objectives = ['return', 'risk', 'liquidity']
            
        if weights_config is not None:
            self._update_objective_weights(weights_config)
            
        n_assets = len(expected_returns)
        
        # Default liquidity scores if not provided
        if liquidity_scores is None:
            liquidity_scores = np.ones(n_assets) * 0.8  # Default high liquidity
            self.logger.warning("Using default liquidity scores")
            
        # Default ESG scores if not provided
        if esg_scores is None:
            esg_scores = np.ones(n_assets) * 50.0  # Default neutral ESG
            self.logger.warning("Using default ESG scores")
            
        # Normalize objectives
        normalized_objectives = self._normalize_objectives(
            expected_returns, covariance_matrix, liquidity_scores, esg_scores
        )
        
        # Multi-objective optimization
        weights = self._multi_objective_optimization(
            expected_returns=expected_returns,
            covariance_matrix=covariance_matrix,
            normalized_objectives=normalized_objectives,
            objectives=objectives
        )
        
        self.logger.info(f"Multi-objective optimization completed with objectives: {objectives}")
        return weights
        
    def _update_objective_weights(self, weights_config: Dict):
        """Update objective weights from config"""
        for objective, weight in weights_config.items():
            if hasattr(self.objective_config, f"{objective}_weight"):
                setattr(self.objective_config, f"{objective}_weight", weight)
                
    def _normalize_objectives(self,
                            expected_returns: np.ndarray,
                            covariance_matrix: np.ndarray,
                            liquidity_scores: np.ndarray,
                            esg_scores: np.ndarray) -> Dict:
        """
        Normalize objectives to comparable scales
        
        Args:
            expected_returns: Expected returns
            covariance_matrix: Covariance matrix
            liquidity_scores: Liquidity scores
            esg_scores: ESG scores
            
        Returns:
            Dictionary of normalized objectives
        """
        n_assets = len(expected_returns)
        
        # Normalize return (higher is better)
        norm_returns = expected_returns / np.std(expected_returns) if np.std(expected_returns) > 0 else expected_returns
        
        # Normalize risk (lower is better, so we negate)
        volatilities = np.sqrt(np.diag(covariance_matrix))
        norm_risks = -volatilities / np.std(volatilities) if np.std(volatilities) > 0 else -volatilities
        
        # Normalize liquidity (higher is better)
        norm_liquidity = liquidity_scores / np.max(liquidity_scores) if np.max(liquidity_scores) > 0 else liquidity_scores
        
        # Normalize ESG (higher is better)
        norm_esg = esg_scores / 100.0  # Scale to 0-1
        
        return {
            'returns': norm_returns,
            'risks': norm_risks,
            'liquidity': norm_liquidity,
            'esg': norm_esg
        }
        
    def _multi_objective_optimization(self,
                                     expected_returns: np.ndarray,
                                     covariance_matrix: np.ndarray,
                                     normalized_objectives: Dict,
                                     objectives: List[str]) -> np.ndarray:
        """
        Multi-objective optimization using weighted sum approach
        
        Args:
            expected_returns: Expected returns
            covariance_matrix: Covariance matrix
            normalized_objectives: Normalized objective values
            objectives: List of objectives to optimize
            
        Returns:
            Optimal portfolio weights
        """
        n_assets = len(expected_returns)
        
        # CVXPY implementation
        weights = cp.Variable(n_assets)
        
        # Calculate portfolio objective values
        portfolio_return = weights @ expected_returns
        portfolio_variance = cp.quad_form(weights, covariance_matrix)
        portfolio_risk = cp.sqrt(portfolio_variance)
        portfolio_liquidity = weights @ normalized_objectives['liquidity']
        portfolio_esg = weights @ normalized_objectives['esg']
        
        # Composite objective function
        composite_objective = 0
        
        if 'return' in objectives:
            composite_objective += self.objective_config.return_weight * portfolio_return
            
        if 'risk' in objectives:
            # Minimize risk (negative because CVXPY minimizes)
            composite_objective += self.objective_config.risk_weight * (-portfolio_risk)
            
        if 'liquidity' in objectives:
            composite_objective += self.objective_config.liquidity_weight * portfolio_liquidity
            
        if 'esg' in objectives:
            composite_objective += self.objective_config.esg_weight * portfolio_esg
            
        # Objective to minimize (negative of composite)
        objective = cp.Maximize(composite_objective)
        
        # Constraints
        constraints = [
            cp.sum(weights) == 1,  # Budget constraint
            weights >= self.config.min_weight,  # Long-only constraint
            weights <= self.config.max_weight,  # Weight upper bound
            weights <= self.config.max_position  # Position size limit
        ]
        
        # Additional constraints for specific objectives
        if 'return' in objectives:
            # Expected return constraint
            constraints.append(
                portfolio_return >= self.objective_config.target_return
            )
            
        if 'risk' in objectives:
            # Risk limit constraint
            constraints.append(
                portfolio_risk <= self.objective_config.max_risk
            )
            
        if 'liquidity' in objectives:
            # Minimum liquidity constraint
            constraints.append(
                portfolio_liquidity >= self.objective_config.min_liquidity
            )
            
        if 'esg' in objectives:
            # Minimum ESG constraint
            constraints.append(
                portfolio_esg >= self.objective_config.min_esg / 100.0  # Normalized
            )
            
        # Solve optimization problem
        problem = cp.Problem(objective, constraints)
        
        try:
            problem.solve(
                solver=cp.ECOS,
                verbose=False,
                max_iters=1000
            )
            
            if problem.status in ["infeasible", "unbounded"]:
                self.logger.warning(f"Multi-objective optimization failed: {problem.status}")
                return self._fallback_weights(n_assets, objectives)
                
            optimal_weights = weights.value
            optimal_weights = np.round(optimal_weights, 6)
            
            # Ensure weights sum to 1
            if abs(np.sum(optimal_weights) - 1.0) > 1e-6:
                optimal_weights = optimal_weights / np.sum(optimal_weights)
                
            return optimal_weights
            
        except Exception as e:
            self.logger.error(f"Error in multi-objective optimization: {e}")
            return self._fallback_weights(n_assets, objectives)
            
    def _fallback_weights(self, n_assets: int, objectives: List[str]) -> np.ndarray:
        """Fallback weights when optimization fails"""
        if 'esg' in objectives:
            # Equal weights with slight ESG bias
            weights = np.ones(n_assets) / n_assets
        else:
            # Simple equal weights
            weights = np.ones(n_assets) / n_assets
        return weights
        
    def optimize_pareto_front(self,
                            expected_returns: np.ndarray,
                            covariance_matrix: np.ndarray,
                            liquidity_scores: np.ndarray,
                            esg_scores: np.ndarray,
                            num_points: int = 50) -> Dict:
        """
        Generate Pareto frontier for multi-objective optimization
        
        Args:
            expected_returns: Expected returns
            covariance_matrix: Covariance matrix
            liquidity_scores: Liquidity scores
            esg_scores: ESG scores
            num_points: Number of Pareto points to generate
            
        Returns:
            Pareto frontier data
        """
        pareto_solutions = []
        
        # Grid search over return-risk tradeoff
        return_range = np.linspace(0.05, 0.20, num_points // 3)
        
        for target_return in return_range:
            try:
                weights = self.optimize(
                    expected_returns=expected_returns,
                    covariance_matrix=covariance_matrix,
                    liquidity_scores=liquidity_scores,
                    esg_scores=esg_scores,
                    objectives=['return', 'risk'],
                    weights_config={'return_weight': 0.8, 'risk_weight': 0.2}
                )
                
                portfolio_return = np.dot(weights, expected_returns)
                portfolio_risk = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
                portfolio_liquidity = np.dot(weights, liquidity_scores)
                portfolio_esg = np.dot(weights, esg_scores)
                
                if portfolio_return >= target_return:
                    pareto_solutions.append({
                        'return': portfolio_return,
                        'risk': portfolio_risk,
                        'liquidity': portfolio_liquidity,
                        'esg': portfolio_esg,
                        'weights': weights
                    })
                    
            except Exception as e:
                self.logger.warning(f"Error generating Pareto point: {e}")
                continue
                
        return {
            'pareto_solutions': pareto_solutions,
            'num_solutions': len(pareto_solutions),
            'pareto_front': self._extract_pareto_front(pareto_solutions)
        }
        
    def _extract_pareto_front(self, solutions: List[Dict]) -> List[Dict]:
        """Extract Pareto-optimal solutions"""
        if not solutions:
            return []
            
        # Sort by return (descending) and risk (ascending)
        sorted_solutions = sorted(
            solutions,
            key=lambda x: (-x['return'], x['risk'])
        )
        
        # Keep only non-dominated solutions
        pareto_front = []
        min_risk = float('inf')
        
        for solution in sorted_solutions:
            if solution['risk'] < min_risk:
                pareto_front.append(solution)
                min_risk = solution['risk']
                
        return pareto_front
        
    def calculate_objective_contributions(self,
                                        weights: np.ndarray,
                                        expected_returns: np.ndarray,
                                        covariance_matrix: np.ndarray,
                                        liquidity_scores: np.ndarray,
                                        esg_scores: np.ndarray) -> Dict:
        """
        Calculate contribution of each asset to each objective
        
        Args:
            weights: Portfolio weights
            expected_returns: Expected returns
            covariance_matrix: Covariance matrix
            liquidity_scores: Liquidity scores
            esg_scores: ESG scores
            
        Returns:
            Objective contributions
        """
        n_assets = len(weights)
        
        # Portfolio objective values
        portfolio_return = np.dot(weights, expected_returns)
        portfolio_risk = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
        portfolio_liquidity = np.dot(weights, liquidity_scores)
        portfolio_esg = np.dot(weights, esg_scores)
        
        # Asset contributions to each objective
        return_contributions = weights * expected_returns
        liquidity_contributions = weights * liquidity_scores
        esg_contributions = weights * esg_scores
        
        # Risk contributions (approximation using marginal risk)
        marginal_risk = np.dot(covariance_matrix, weights) / portfolio_risk
        risk_contributions = weights * marginal_risk
        
        # Normalize risk contributions to sum to portfolio risk
        risk_contributions = risk_contributions / np.sum(risk_contributions) * portfolio_risk
        
        return {
            'portfolio_objectives': {
                'return': portfolio_return,
                'risk': portfolio_risk,
                'liquidity': portfolio_liquidity,
                'esg': portfolio_esg
            },
            'asset_contributions': {
                f'asset_{i}': {
                    'return_contribution': return_contributions[i],
                    'risk_contribution': risk_contributions[i],
                    'liquidity_contribution': liquidity_contributions[i],
                    'esg_contribution': esg_contributions[i],
                    'weight': weights[i]
                }
                for i in range(n_assets)
            }
        }
        
    def sensitivity_analysis(self,
                           expected_returns: np.ndarray,
                           covariance_matrix: np.ndarray,
                           liquidity_scores: np.ndarray,
                           esg_scores: np.ndarray,
                           weight_variations: List[Dict]) -> Dict:
        """
        Perform sensitivity analysis on objective weights
        
        Args:
            expected_returns: Expected returns
            covariance_matrix: Covariance matrix
            liquidity_scores: Liquidity scores
            esg_scores: ESG scores
            weight_variations: List of weight variations to test
            
        Returns:
            Sensitivity analysis results
        """
        sensitivity_results = []
        
        for variation in weight_variations:
            try:
                weights = self.optimize(
                    expected_returns=expected_returns,
                    covariance_matrix=covariance_matrix,
                    liquidity_scores=liquidity_scores,
                    esg_scores=esg_scores,
                    weights_config=variation
                )
                
                # Calculate portfolio metrics
                portfolio_return = np.dot(weights, expected_returns)
                portfolio_risk = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
                portfolio_liquidity = np.dot(weights, liquidity_scores)
                portfolio_esg = np.dot(weights, esg_scores)
                
                sensitivity_results.append({
                    'weight_config': variation,
                    'weights': weights,
                    'return': portfolio_return,
                    'risk': portfolio_risk,
                    'liquidity': portfolio_liquidity,
                    'esg': portfolio_esg
                })
                
            except Exception as e:
                self.logger.warning(f"Error in sensitivity analysis: {e}")
                sensitivity_results.append({
                    'weight_config': variation,
                    'error': str(e)
                })
                
        return {
            'sensitivity_results': sensitivity_results,
            'num_variations': len(sensitivity_results)
        }
        
    def optimize_with_constraints(self,
                                expected_returns: np.ndarray,
                                covariance_matrix: np.ndarray,
                                liquidity_scores: np.ndarray,
                                esg_scores: np.ndarray,
                                additional_constraints: Dict) -> np.ndarray:
        """
        Multi-objective optimization with additional constraints
        
        Args:
            expected_returns: Expected returns
            covariance_matrix: Covariance matrix
            liquidity_scores: Liquidity scores
            esg_scores: ESG scores
            additional_constraints: Additional constraint parameters
            
        Returns:
            Optimal portfolio weights
        """
        # Update objective config with additional constraints
        if 'target_return' in additional_constraints:
            self.objective_config.target_return = additional_constraints['target_return']
            
        if 'max_risk' in additional_constraints:
            self.objective_config.max_risk = additional_constraints['max_risk']
            
        if 'min_liquidity' in additional_constraints:
            self.objective_config.min_liquidity = additional_constraints['min_liquidity']
            
        if 'min_esg' in additional_constraints:
            self.objective_config.min_esg = additional_constraints['min_esg']
            
        # Run optimization
        return self.optimize(
            expected_returns=expected_returns,
            covariance_matrix=covariance_matrix,
            liquidity_scores=liquidity_scores,
            esg_scores=esg_scores
        )
        
    def backtest_multi_objective(self,
                               returns_data: np.ndarray,
                               window_size: int = 252,
                               objectives: List[str] = None,
                               weights_config: Dict = None) -> Dict:
        """
        Backtest multi-objective strategy over time
        
        Args:
            returns_data: Historical returns data (T x N)
            window_size: Rolling window size
            objectives: List of objectives to optimize
            weights_config: Objective weights configuration
            
        Returns:
            Backtest results
        """
        n_periods, n_assets = returns_data.shape
        
        if objectives is None:
            objectives = ['return', 'risk']
            
        if weights_config is None:
            weights_config = {
                'return_weight': 0.5,
                'risk_weight': 0.5
            }
            
        portfolio_returns = []
        portfolio_weights = []
        objective_scores_history = []
        
        for i in range(window_size, n_periods):
            try:
                # Get window data
                window_returns = returns_data[i-window_size:i]
                
                # Calculate expected returns
                expected_returns = np.mean(window_returns, axis=0)
                
                # Calculate covariance matrix
                covariance_matrix = np.cov(window_returns.T)
                
                # Generate proxy scores
                liquidity_scores = np.random.uniform(0.5, 1.0, n_assets)  # Random proxy
                esg_scores = np.random.uniform(40, 90, n_assets)  # Random proxy
                
                # Optimize
                weights = self.optimize(
                    expected_returns=expected_returns,
                    covariance_matrix=covariance_matrix,
                    liquidity_scores=liquidity_scores,
                    esg_scores=esg_scores,
                    objectives=objectives,
                    weights_config=weights_config
                )
                
                # Calculate objective scores
                objective_scores = self.calculate_objective_contributions(
                    weights, expected_returns, covariance_matrix, 
                    liquidity_scores, esg_scores
                )
                
                # Next period return
                next_return = returns_data[i]
                portfolio_return = np.dot(weights, next_return)
                
                portfolio_returns.append(portfolio_return)
                portfolio_weights.append(weights)
                objective_scores_history.append(objective_scores)
                
            except Exception as e:
                self.logger.warning(f"Multi-objective optimization failed at period {i}: {e}")
                # Use equal weights
                weights = np.ones(n_assets) / n_assets
                portfolio_return = np.dot(weights, returns_data[i])
                portfolio_returns.append(portfolio_return)
                portfolio_weights.append(weights)
                
        # Calculate performance metrics
        portfolio_returns = np.array(portfolio_returns)
        portfolio_weights = np.array(portfolio_weights)
        
        return {
            'portfolio_returns': portfolio_returns,
            'portfolio_weights': portfolio_weights,
            'objective_scores_history': objective_scores_history,
            'objectives': objectives,
            'num_periods': len(portfolio_returns),
            'annual_return': np.mean(portfolio_returns) * 252,
            'annual_volatility': np.std(portfolio_returns) * np.sqrt(252),
            'sharpe_ratio': np.mean(portfolio_returns) / np.std(portfolio_returns) * np.sqrt(252),
            'max_drawdown': self._calculate_max_drawdown(portfolio_returns)
        }
        
    def _calculate_max_drawdown(self, returns: np.ndarray) -> float:
        """Calculate maximum drawdown"""
        cumulative_returns = (1 + pd.Series(returns)).cumprod()
        running_max = cumulative_returns.expanding().max()
        drawdown = (cumulative_returns - running_max) / running_max
        return drawdown.min()
