"""
Risk Parity Portfolio Optimizer
Equal risk contribution portfolio optimization
"""

import numpy as np
import pandas as pd
import cvxpy as cp
from typing import Dict, List, Optional, Tuple
import logging
from scipy.optimize import minimize

from core.config import OptimizationConfig


class RiskParityOptimizer:
    """
    Risk Parity Portfolio Optimizer
    
    Creates portfolios where each asset contributes equally to total portfolio risk
    Also supports inverse volatility and other risk parity variants
    """
    
    def __init__(self, config: OptimizationConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
    def optimize(self,
                 covariance_matrix: np.ndarray,
                 target_risks: Optional[np.ndarray] = None,
                 method: str = "equal_contribution") -> np.ndarray:
        """
        Risk parity optimization
        
        Args:
            covariance_matrix: Covariance matrix of returns
            target_risks: Target risk contributions for each asset
            method: Risk parity method ("equal_contribution", "inverse_vol", "custom")
            
        Returns:
            Optimal portfolio weights
        """
        n_assets = len(covariance_matrix)
        
        if method == "equal_contribution":
            return self._equal_contribution_optimization(covariance_matrix)
            
        elif method == "inverse_vol":
            return self._inverse_volatility_optimization(covariance_matrix)
            
        elif method == "custom":
            return self._custom_risk_parity_optimization(covariance_matrix, target_risks)
            
        else:
            raise ValueError(f"Unknown risk parity method: {method}")
            
    def _equal_contribution_optimization(self, covariance_matrix: np.ndarray) -> np.ndarray:
        """
        Equal risk contribution optimization
        
        Each asset contributes equally to portfolio risk
        """
        n_assets = len(covariance_matrix)
        
        def risk_contribution_objective(weights):
            """Calculate risk contributions"""
            portfolio_risk = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
            
            if portfolio_risk == 0:
                return np.ones(n_assets) * 0.1  # Avoid division by zero
                
            # Risk contributions: w_i * (Σw)_i / portfolio_risk
            marginal_contrib = np.dot(covariance_matrix, weights)
            risk_contrib = weights * marginal_contrib / portfolio_risk
            
            return risk_contrib
            
        def objective_function(weights):
            """Objective: minimize sum of squared deviations from equal contribution"""
            risk_contrib = risk_contribution_objective(weights)
            equal_contribution = 1.0 / n_assets
            
            # Sum of squared deviations
            deviation = np.sum((risk_contrib - equal_contribution) ** 2)
            return deviation
            
        def constraint_weights_sum_to_one(weights):
            """Weights must sum to 1"""
            return np.sum(weights) - 1.0
            
        def constraint_no_short_selling(weights):
            """No short selling constraint"""
            return weights  # CVXPY will handle non-negativity
            
        # CVXPY implementation for better numerical stability
        weights = cp.Variable(n_assets)
        
        # Portfolio risk
        portfolio_variance = cp.quad_form(weights, covariance_matrix)
        portfolio_risk = cp.sqrt(portfolio_variance)
        
        # Risk contributions
        marginal_contrib = covariance_matrix @ weights
        risk_contrib = cp.multiply(weights, marginal_contrib) / portfolio_risk
        
        # Objective: minimize sum of squared deviations from equal contribution
        equal_contribution = 1.0 / n_assets
        objective = cp.Minimize(
            cp.sum_squares(risk_contrib - equal_contribution)
        )
        
        # Constraints
        constraints = [
            cp.sum(weights) == 1,
            weights >= self.config.min_weight,
            weights <= self.config.max_weight,
            weights <= self.config.max_position
        ]
        
        # Solve optimization problem
        problem = cp.Problem(objective, constraints)
        
        try:
            problem.solve(
                solver=cp.ECOS,
                verbose=False,
                max_iters=1000
            )
            
            if problem.status in ["infeasible", "unbounded"]:
                self.logger.warning(f"Risk parity optimization failed with status: {problem.status}")
                return self._fallback_weights(n_assets)
                
            optimal_weights = weights.value
            optimal_weights = np.round(optimal_weights, 6)
            
            # Verify weights sum to 1
            if abs(np.sum(optimal_weights) - 1.0) > 1e-6:
                optimal_weights = optimal_weights / np.sum(optimal_weights)
                
            self.logger.info("Equal contribution risk parity optimization completed successfully")
            return optimal_weights
            
        except Exception as e:
            self.logger.error(f"Error in equal contribution optimization: {e}")
            return self._fallback_weights(n_assets)
            
    def _inverse_volatility_optimization(self, covariance_matrix: np.ndarray) -> np.ndarray:
        """
        Inverse volatility weighting
        
        Weights proportional to inverse of individual asset volatilities
        """
        # Calculate individual volatilities
        volatilities = np.sqrt(np.diag(covariance_matrix))
        
        # Inverse volatility weights
        inv_volatilities = 1.0 / volatilities
        
        # Normalize to sum to 1
        weights = inv_volatilities / np.sum(inv_volatilities)
        
        # Apply constraints
        weights = self._apply_constraints(weights)
        
        self.logger.info("Inverse volatility optimization completed successfully")
        return weights
        
    def _custom_risk_parity_optimization(self,
                                       covariance_matrix: np.ndarray,
                                       target_risks: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Custom risk parity with specified target risk contributions
        
        Args:
            covariance_matrix: Covariance matrix
            target_risks: Target risk contributions for each asset
        """
        n_assets = len(covariance_matrix)
        
        if target_risks is None:
            # Default to equal contribution
            target_risks = np.ones(n_assets) / n_assets
        elif len(target_risks) != n_assets:
            raise ValueError(f"Target risks length ({len(target_risks)}) must match number of assets ({n_assets})")
        elif abs(np.sum(target_risks) - 1.0) > 1e-6:
            # Normalize target risks to sum to 1
            target_risks = target_risks / np.sum(target_risks)
            
        # CVXPY implementation
        weights = cp.Variable(n_assets)
        
        # Portfolio risk
        portfolio_variance = cp.quad_form(weights, covariance_matrix)
        portfolio_risk = cp.sqrt(portfolio_variance)
        
        # Risk contributions
        marginal_contrib = covariance_matrix @ weights
        risk_contrib = cp.multiply(weights, marginal_contrib) / portfolio_risk
        
        # Objective: minimize sum of squared deviations from target contributions
        objective = cp.Minimize(
            cp.sum_squares(risk_contrib - target_risks)
        )
        
        # Constraints
        constraints = [
            cp.sum(weights) == 1,
            weights >= self.config.min_weight,
            weights <= self.config.max_weight,
            weights <= self.config.max_position
        ]
        
        # Solve optimization problem
        problem = cp.Problem(objective, constraints)
        
        try:
            problem.solve(
                solver=cp.ECOS,
                verbose=False,
                max_iters=1000
            )
            
            if problem.status in ["infeasible", "unbounded"]:
                self.logger.warning(f"Custom risk parity optimization failed with status: {problem.status}")
                return self._fallback_weights(n_assets)
                
            optimal_weights = weights.value
            optimal_weights = np.round(optimal_weights, 6)
            
            # Verify weights sum to 1
            if abs(np.sum(optimal_weights) - 1.0) > 1e-6:
                optimal_weights = optimal_weights / np.sum(optimal_weights)
                
            self.logger.info("Custom risk parity optimization completed successfully")
            return optimal_weights
            
        except Exception as e:
            self.logger.error(f"Error in custom risk parity optimization: {e}")
            return self._fallback_weights(n_assets)
            
    def _apply_constraints(self, weights: np.ndarray) -> np.ndarray:
        """Apply weight constraints to existing weights"""
        n_assets = len(weights)
        
        # Apply weight bounds
        weights = np.maximum(weights, self.config.min_weight)
        weights = np.minimum(weights, self.config.max_weight)
        
        # Apply maximum position size
        weights = np.minimum(weights, self.config.max_position)
        
        # Renormalize to sum to 1
        if np.sum(weights) > 0:
            weights = weights / np.sum(weights)
        else:
            weights = np.ones(n_assets) / n_assets
            
        return weights
        
    def _fallback_weights(self, n_assets: int) -> np.ndarray:
        """Fallback equal weights in case of optimization failure"""
        return np.ones(n_assets) / n_assets
        
    def calculate_risk_contributions(self,
                                   weights: np.ndarray,
                                   covariance_matrix: np.ndarray) -> np.ndarray:
        """
        Calculate risk contributions for given weights
        
        Args:
            weights: Portfolio weights
            covariance_matrix: Covariance matrix
            
        Returns:
            Risk contributions array
        """
        portfolio_risk = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
        
        if portfolio_risk == 0:
            return np.zeros(len(weights))
            
        marginal_contrib = np.dot(covariance_matrix, weights)
        risk_contrib = weights * marginal_contrib / portfolio_risk
        
        return risk_contrib
        
    def calculate_risk_budget(self,
                            weights: np.ndarray,
                            covariance_matrix: np.ndarray) -> Dict:
        """
        Calculate detailed risk budget analysis
        
        Args:
            weights: Portfolio weights
            covariance_matrix: Covariance matrix
            
        Returns:
            Risk budget analysis dictionary
        """
        n_assets = len(weights)
        risk_contrib = self.calculate_risk_contributions(weights, covariance_matrix)
        
        # Portfolio metrics
        portfolio_risk = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
        portfolio_variance = np.dot(weights, np.dot(covariance_matrix, weights))
        
        # Individual asset metrics
        asset_metrics = {}
        for i in range(n_assets):
            # Marginal contribution
            marginal_contrib = covariance_matrix[i] @ weights
            
            # Component contribution
            component_contrib = weights[i] * marginal_contrib
            
            # Percentage of total risk
            risk_percentage = component_contrib / portfolio_variance if portfolio_variance > 0 else 0
            
            asset_metrics[f'asset_{i}'] = {
                'weight': weights[i],
                'marginal_contribution': marginal_contrib,
                'risk_contribution': risk_contrib[i],
                'risk_percentage': risk_percentage,
                'diversification_ratio': self._calculate_diversification_ratio(weights, i, covariance_matrix)
            }
            
        return {
            'portfolio_risk': portfolio_risk,
            'portfolio_variance': portfolio_variance,
            'risk_contributions': risk_contrib,
            'asset_metrics': asset_metrics,
            'num_assets': n_assets
        }
        
    def _calculate_diversification_ratio(self,
                                       weights: np.ndarray,
                                       asset_index: int,
                                       covariance_matrix: np.ndarray) -> float:
        """
        Calculate diversification ratio for a specific asset
        
        Args:
            weights: Portfolio weights
            asset_index: Asset index
            covariance_matrix: Covariance matrix
            
        Returns:
            Diversification ratio
        """
        # Asset standalone volatility
        asset_vol = np.sqrt(covariance_matrix[asset_index, asset_index])
        
        # Marginal contribution to portfolio risk
        marginal_contrib = covariance_matrix[asset_index] @ weights
        portfolio_risk = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
        
        # Diversification ratio
        if portfolio_risk == 0:
            return 1.0
            
        diversification_ratio = marginal_contrib / portfolio_risk / asset_vol
        
        return min(diversification_ratio, 1.0)  # Cap at 1.0
        
    def stress_test(self,
                   weights: np.ndarray,
                   covariance_matrix: np.ndarray,
                   shock_scenarios: List[Dict]) -> Dict:
        """
        Perform stress tests on risk parity portfolio
        
        Args:
            weights: Portfolio weights
            covariance_matrix: Baseline covariance matrix
            shock_scenarios: List of shock scenarios
            
        Returns:
            Stress test results
        """
        results = {}
        
        for scenario in shock_scenarios:
            scenario_name = scenario['name']
            shock_type = scenario.get('type', 'correlation')
            shock_magnitude = scenario.get('magnitude', 0.1)
            
            try:
                if shock_type == 'correlation':
                    # Increase correlations by shock_magnitude
                    shocked_covariance = self._shock_correlations(covariance_matrix, shock_magnitude)
                    
                elif shock_type == 'volatility':
                    # Increase volatilities by shock_magnitude
                    shocked_covariance = self._shock_volatilities(covariance_matrix, shock_magnitude)
                    
                elif shock_type == 'systematic':
                    # Systematic shock to all assets
                    shocked_covariance = self._systematic_shock(covariance_matrix, shock_magnitude)
                    
                else:
                    self.logger.warning(f"Unknown shock type: {shock_type}")
                    continue
                    
                # Calculate new risk metrics
                portfolio_risk = np.sqrt(np.dot(weights, np.dot(shocked_covariance, weights)))
                risk_contrib = self.calculate_risk_contributions(weights, shocked_covariance)
                
                results[scenario_name] = {
                    'shocked_risk': portfolio_risk,
                    'shocked_risk_contributions': risk_contrib,
                    'shock_type': shock_type,
                    'shock_magnitude': shock_magnitude
                }
                
            except Exception as e:
                self.logger.error(f"Error in stress test scenario {scenario_name}: {e}")
                results[scenario_name] = {'error': str(e)}
                
        return results
        
    def _shock_correlations(self, covariance_matrix: np.ndarray, shock_magnitude: float) -> np.ndarray:
        """Shock correlations by increasing correlation coefficients"""
        shocked_covariance = covariance_matrix.copy()
        n_assets = len(covariance_matrix)
        
        # Get volatilities
        volatilities = np.sqrt(np.diag(covariance_matrix))
        
        # Increase correlation coefficients
        for i in range(n_assets):
            for j in range(i+1, n_assets):
                # Current correlation
                current_corr = covariance_matrix[i, j] / (volatilities[i] * volatilities[j])
                
                # Apply shock
                new_corr = min(1.0, current_corr + shock_magnitude)
                
                # Update covariance
                shocked_covariance[i, j] = new_corr * volatilities[i] * volatilities[j]
                shocked_covariance[j, i] = new_corr * volatilities[i] * volatilities[j]
                
        return shocked_covariance
        
    def _shock_volatilities(self, covariance_matrix: np.ndarray, shock_magnitude: float) -> np.ndarray:
        """Shock volatilities by increasing standard deviations"""
        shocked_covariance = covariance_matrix.copy()
        n_assets = len(covariance_matrix)
        
        # Increase volatilities
        for i in range(n_assets):
            # New volatility
            old_vol = np.sqrt(covariance_matrix[i, i])
            new_vol = old_vol * (1 + shock_magnitude)
            
            # Update diagonal element
            shocked_covariance[i, i] = new_vol ** 2
            
            # Update correlations (keep correlations constant)
            for j in range(n_assets):
                if i != j:
                    correlation = covariance_matrix[i, j] / (old_vol * np.sqrt(covariance_matrix[j, j]))
                    shocked_covariance[i, j] = correlation * new_vol * np.sqrt(covariance_matrix[j, j])
                    shocked_covariance[j, i] = correlation * new_vol * np.sqrt(covariance_matrix[j, j])
                    
        return shocked_covariance
        
    def _systematic_shock(self, covariance_matrix: np.ndarray, shock_magnitude: float) -> np.ndarray:
        """Apply systematic shock to covariance matrix"""
        # Add systematic risk component
        n_assets = len(covariance_matrix)
        
        # Create systematic risk matrix
        systematic_matrix = np.full((n_assets, n_assets), shock_magnitude)
        np.fill_diagonal(systematic_matrix, 1.0)
        
        # Add to existing covariance
        shocked_covariance = covariance_matrix + systematic_matrix * 0.01  # 1% additional systematic risk
        
        return shocked_covariance
        
    def backtest_risk_parity(self,
                           returns_data: np.ndarray,
                           window_size: int = 252,
                           method: str = "equal_contribution") -> Dict:
        """
        Backtest risk parity strategy over time
        
        Args:
            returns_data: Historical returns data (T x N)
            window_size: Rolling window size
            method: Risk parity method
            
        Returns:
            Backtest results
        """
        n_periods, n_assets = returns_data.shape
        portfolio_returns = []
        portfolio_weights = []
        risk_contributions_history = []
        
        for i in range(window_size, n_periods):
            try:
                # Get window data
                window_returns = returns_data[i-window_size:i]
                
                # Calculate covariance matrix
                covariance_matrix = np.cov(window_returns.T)
                
                # Optimize risk parity weights
                weights = self.optimize(covariance_matrix, method=method)
                
                # Calculate risk contributions
                risk_contrib = self.calculate_risk_contributions(weights, covariance_matrix)
                
                # Next period return
                next_return = returns_data[i]
                portfolio_return = np.dot(weights, next_return)
                
                portfolio_returns.append(portfolio_return)
                portfolio_weights.append(weights)
                risk_contributions_history.append(risk_contrib)
                
            except Exception as e:
                self.logger.warning(f"Risk parity optimization failed at period {i}: {e}")
                # Use equal weights
                weights = np.ones(n_assets) / n_assets
                portfolio_return = np.dot(weights, returns_data[i])
                portfolio_returns.append(portfolio_return)
                portfolio_weights.append(weights)
                risk_contributions_history.append(np.ones(n_assets) / n_assets)
                
        # Calculate performance metrics
        portfolio_returns = np.array(portfolio_returns)
        portfolio_weights = np.array(portfolio_weights)
        
        return {
            'portfolio_returns': portfolio_returns,
            'portfolio_weights': portfolio_weights,
            'risk_contributions_history': np.array(risk_contributions_history),
            'num_periods': len(portfolio_returns),
            'annual_return': np.mean(portfolio_returns) * 252,
            'annual_volatility': np.std(portfolio_returns) * np.sqrt(252),
            'sharpe_ratio': np.mean(portfolio_returns) / np.std(portfolio_returns) * np.sqrt(252),
            'max_drawdown': self._calculate_max_drawdown(portfolio_returns),
            'calmar_ratio': (np.mean(portfolio_returns) * 252) / abs(self._calculate_max_drawdown(portfolio_returns))
        }
        
    def _calculate_max_drawdown(self, returns: np.ndarray) -> float:
        """Calculate maximum drawdown"""
        cumulative_returns = (1 + pd.Series(returns)).cumprod()
        running_max = cumulative_returns.expanding().max()
        drawdown = (cumulative_returns - running_max) / running_max
        return drawdown.min()
