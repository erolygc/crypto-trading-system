"""
Factor Model Portfolio Optimizer
PCA and Factor Analysis based portfolio optimization
"""

import numpy as np
import pandas as pd
import cvxpy as cp
from typing import Dict, List, Optional, Tuple
import logging
from sklearn.decomposition import PCA, FactorAnalysis
from sklearn.preprocessing import StandardScaler

from core.config import OptimizationConfig


class FactorModelOptimizer:
    """
    Factor Model Portfolio Optimizer
    
    Uses Principal Component Analysis (PCA) and Factor Analysis (FA)
    to identify risk factors and optimize portfolios
    """
    
    def __init__(self, config: OptimizationConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Factor model parameters
        self.n_factors = config.n_factors
        self.factor_method = config.factor_method  # "pca", "fa", or "both"
        
        # Storage
        self.factor_loadings: Optional[np.ndarray] = None
        self.factor_returns: Optional[np.ndarray] = None
        self.factor_covariance: Optional[np.ndarray] = None
        self.specific_variance: Optional[np.ndarray] = None
        
    def optimize(self,
                expected_returns: np.ndarray,
                covariance_matrix: np.ndarray,
                factor_loadings: Optional[np.ndarray] = None,
                returns_data: Optional[np.ndarray] = None) -> np.ndarray:
        """
        Factor model optimization
        
        Args:
            expected_returns: Expected returns for each asset
            covariance_matrix: Historical covariance matrix
            factor_loadings: Pre-computed factor loadings matrix
            returns_data: Historical returns for factor analysis
            
        Returns:
            Optimal portfolio weights
        """
        # Get or calculate factor loadings
        if factor_loadings is not None:
            self.factor_loadings = factor_loadings
        elif returns_data is not None:
            self._calculate_factor_loadings(returns_data)
        else:
            # Use PCA as default factor extraction
            self._estimate_factor_loadings(covariance_matrix, expected_returns)
            
        # Calculate factor model parameters
        self._estimate_factor_parameters(expected_returns, covariance_matrix)
        
        # Optimize portfolio using factor model
        weights = self._factor_model_optimization(expected_returns)
        
        self.logger.info(f"Factor model optimization completed using {self.factor_method}")
        return weights
        
    def _calculate_factor_loadings(self, returns_data: np.ndarray):
        """
        Calculate factor loadings using PCA or Factor Analysis
        
        Args:
            returns_data: Historical returns matrix (T x N)
        """
        n_assets = returns_data.shape[1]
        
        # Standardize returns
        scaler = StandardScaler()
        returns_scaled = scaler.fit_transform(returns_data)
        
        if self.factor_method == "pca":
            self._pca_factor_extraction(returns_scaled)
            
        elif self.factor_method == "fa":
            self._factor_analysis_extraction(returns_scaled)
            
        elif self.factor_method == "both":
            # Use PCA for factor loadings
            self._pca_factor_extraction(returns_scaled)
            
        else:
            raise ValueError(f"Unknown factor method: {self.factor_method}")
            
    def _pca_factor_extraction(self, returns_scaled: np.ndarray):
        """Extract factors using Principal Component Analysis"""
        pca = PCA(n_components=self.n_factors)
        pca.fit(returns_scaled)
        
        # Factor loadings (assets x factors)
        self.factor_loadings = pca.components_.T
        
        # Factor returns
        factor_returns = pca.transform(returns_scaled)
        
        # Calculate factor covariance matrix
        self.factor_covariance = np.cov(factor_returns.T)
        
        # Calculate specific variance (idiosyncratic risk)
        specific_var = np.var(returns_scaled, axis=0) - np.sum(
            pca.explained_variance_ratio_
        ) * np.var(returns_scaled, axis=0)
        
        self.specific_variance = np.maximum(specific_var, 1e-6)  # Ensure positive
        
        self.logger.info(f"PCA extracted {self.n_factors} factors")
        self.logger.info(f"Explained variance: {pca.explained_variance_ratio_.sum():.3f}")
        
    def _factor_analysis_extraction(self, returns_scaled: np.ndarray):
        """Extract factors using Factor Analysis"""
        fa = FactorAnalysis(n_components=self.n_factors, random_state=42)
        fa.fit(returns_scaled)
        
        # Factor loadings
        self.factor_loadings = fa.components_.T
        
        # Estimate factor returns
        factor_returns = fa.transform(returns_scaled)
        
        # Calculate factor covariance matrix
        self.factor_covariance = np.cov(factor_returns.T)
        
        # Specific variance from factor analysis
        self.specific_variance = np.diag(fa.noise_variance_)
        
        self.logger.info(f"Factor Analysis extracted {self.n_factors} factors")
        
    def _estimate_factor_loadings(self, covariance_matrix: np.ndarray, expected_returns: np.ndarray):
        """
        Estimate factor loadings from covariance matrix and expected returns
        Used when historical data is not available
        """
        n_assets = len(expected_returns)
        
        # Use spectral decomposition to approximate factor loadings
        eigenvals, eigenvecs = np.linalg.eigh(covariance_matrix)
        
        # Sort by eigenvalues (descending)
        idx = np.argsort(eigenvals)[::-1]
        eigenvals = eigenvals[idx]
        eigenvecs = eigenvecs[:, idx]
        
        # Use top N eigenvectors as factor loadings
        self.factor_loadings = eigenvecs[:, :self.n_factors]
        
        # Approximate factor covariance
        self.factor_covariance = np.diag(eigenvals[:self.n_factors])
        
        # Approximate specific variance
        reconstructed_var = np.sum(self.factor_loadings ** 2, axis=1) @ np.diag(eigenvals[:self.n_factors])
        asset_variance = np.diag(covariance_matrix)
        self.specific_variance = np.maximum(asset_variance - reconstructed_var, 1e-6)
        
        self.logger.info(f"Estimated {self.n_factors} factors from covariance matrix")
        
    def _estimate_factor_parameters(self, expected_returns: np.ndarray, covariance_matrix: np.ndarray):
        """
        Estimate factor model parameters
        
        Args:
            expected_returns: Expected returns
            covariance_matrix: Covariance matrix
        """
        if self.factor_loadings is None:
            raise ValueError("Factor loadings must be calculated first")
            
        n_assets, n_factors = self.factor_loadings.shape
        
        # Factor model: R = B * F + ε
        # Where B is factor loadings, F is factor returns, ε is specific returns
        
        # Estimate factor returns that best explain expected returns
        # Using least squares: F ≈ (B'B)^(-1) * B' * R
        try:
            factor_returns = np.linalg.lstsq(self.factor_loadings, expected_returns, rcond=None)[0]
        except:
            # Fallback: use pseudo-inverse
            factor_returns = np.linalg.pinv(self.factor_loadings) @ expected_returns
            
        self.factor_returns = factor_returns
        
        # Factor covariance matrix
        if self.factor_covariance is None:
            # Estimate from factor loadings and asset covariance
            specific_cov = np.diag(self.specific_variance)
            reconstructed_cov = self.factor_loadings @ self.factor_loadings.T
            self.factor_covariance = np.eye(n_factors)  # Simplified assumption
            
        # Ensure positive definite
        self.factor_covariance = self._ensure_positive_definite(self.factor_covariance)
        
    def _factor_model_optimization(self, expected_returns: np.ndarray) -> np.ndarray:
        """
        Optimize portfolio using factor model
        
        The optimization uses the factor representation:
        Σ = B * Ω * B' + D
        μ = B * f + ε
        
        Where:
        - B: Factor loadings
        - Ω: Factor covariance
        - D: Specific variance (diagonal)
        - f: Factor returns
        - ε: Specific returns
        """
        n_assets = len(expected_returns)
        
        # Decision variables
        weights = cp.Variable(n_assets)
        
        # Factor model expected returns
        # μ = B * f + ε
        specific_returns = expected_returns - self.factor_loadings @ self.factor_returns
        
        # Portfolio factor exposure
        factor_exposure = self.factor_loadings.T @ weights
        portfolio_specific = cp.sum(cp.multiply(specific_returns, weights))
        
        # Portfolio expected return
        portfolio_expected_return = (self.factor_returns @ factor_exposure) + portfolio_specific
        
        # Factor model covariance
        # Σ = B * Ω * B' + D
        factor_portfolio_risk = factor_exposure.T @ self.factor_covariance @ factor_exposure
        specific_portfolio_risk = cp.sum(cp.multiply(self.specific_variance, weights**2))
        
        portfolio_variance = factor_portfolio_risk + specific_portfolio_risk
        portfolio_risk = cp.sqrt(portfolio_variance)
        
        # Objective: maximize Sharpe ratio
        risk_free_rate = self.config.risk_free_rate
        sharpe_ratio = (portfolio_expected_return - risk_free_rate) / portfolio_risk
        objective = cp.Maximize(sharpe_ratio)
        
        # Constraints
        constraints = [
            cp.sum(weights) == 1,  # Budget constraint
            weights >= self.config.min_weight,  # Long-only constraint
            weights <= self.config.max_weight,  # Weight upper bound
            weights <= self.config.max_position  # Position size limit
        ]
        
        # Solve optimization problem
        problem = cp.Problem(objective, constraints)
        
        try:
            problem.solve(
                solver=cp.ECOS,
                verbose=False,
                max_iters=1000
            )
            
            if problem.status in ["infeasible", "unbounded"]:
                self.logger.warning(f"Factor model optimization failed: {problem.status}")
                return self._fallback_weights(n_assets)
                
            optimal_weights = weights.value
            optimal_weights = np.round(optimal_weights, 6)
            
            # Ensure weights sum to 1
            if abs(np.sum(optimal_weights) - 1.0) > 1e-6:
                optimal_weights = optimal_weights / np.sum(optimal_weights)
                
            return optimal_weights
            
        except Exception as e:
            self.logger.error(f"Error in factor model optimization: {e}")
            return self._fallback_weights(n_assets)
            
    def _fallback_weights(self, n_assets: int) -> np.ndarray:
        """Fallback equal weights"""
        return np.ones(n_assets) / n_assets
        
    def _ensure_positive_definite(self, matrix: np.ndarray, regularization: float = 1e-6) -> np.ndarray:
        """
        Ensure matrix is positive definite
        
        Args:
            matrix: Input matrix
            regularization: Regularization parameter
            
        Returns:
            Positive definite matrix
        """
        # Add regularization to diagonal
        matrix_reg = matrix + regularization * np.eye(len(matrix))
        
        # If still not positive definite, add more regularization
        eigenvals = np.linalg.eigvals(matrix_reg)
        if np.any(eigenvals <= 0):
            # Find minimum eigenvalue
            min_eigenval = np.min(eigenvals)
            # Add enough to make it positive
            additional_regularization = abs(min_eigenval) + regularization
            matrix_reg = matrix_reg + additional_regularization * np.eye(len(matrix))
            
        return matrix_reg
        
    def get_factor_analysis_report(self) -> Dict:
        """
        Generate detailed factor analysis report
        
        Returns:
            Factor analysis report
        """
        if self.factor_loadings is None:
            raise ValueError("Must run optimization first to get factor analysis")
            
        n_assets, n_factors = self.factor_loadings.shape
        
        # Factor interpretation (simplified)
        factor_interpretations = self._interpret_factors()
        
        # Asset factor exposures
        asset_exposures = {}
        for i in range(n_assets):
            asset_exposures[f'asset_{i}'] = {
                'factor_loadings': self.factor_loadings[i, :].tolist(),
                'specific_variance': self.specific_variance[i],
                'r_squared': self._calculate_r_squared(i)
            }
            
        return {
            'factor_analysis': {
                'n_factors': n_factors,
                'factor_method': self.factor_method,
                'factor_interpretations': factor_interpretations
            },
            'factor_parameters': {
                'factor_loadings': self.factor_loadings,
                'factor_returns': self.factor_returns,
                'factor_covariance': self.factor_covariance,
                'specific_variance': self.specific_variance
            },
            'asset_exposures': asset_exposures,
            'model_fit': {
                'total_variance_explained': self._calculate_total_variance_explained(),
                'average_r_squared': self._calculate_average_r_squared()
            }
        }
        
    def _interpret_factors(self) -> List[Dict]:
        """Interpret factors based on loadings (simplified interpretation)"""
        n_factors = self.factor_loadings.shape[1]
        interpretations = []
        
        for i in range(n_factors):
            factor_loadings = self.factor_loadings[:, i]
            
            # Find assets with highest absolute loadings
            high_loading_assets = np.argsort(np.abs(factor_loadings))[-5:]
            
            interpretation = {
                'factor_index': i,
                'interpretation': f'Market Factor {i+1}',  # Simplified
                'top_assets': high_loading_assets.tolist(),
                'loading_range': [float(factor_loadings.min()), float(factor_loadings.max())]
            }
            
            interpretations.append(interpretation)
            
        return interpretations
        
    def _calculate_r_squared(self, asset_index: int) -> float:
        """
        Calculate R-squared for specific asset
        
        Args:
            asset_index: Asset index
            
        Returns:
            R-squared value
        """
        asset_loadings = self.factor_loadings[asset_index, :]
        
        # Variance explained by factors
        factor_variance = asset_loadings @ self.factor_covariance @ asset_loadings
        total_variance = factor_variance + self.specific_variance[asset_index]
        
        return factor_variance / total_variance if total_variance > 0 else 0.0
        
    def _calculate_total_variance_explained(self) -> float:
        """Calculate total variance explained by all factors"""
        n_assets = self.factor_loadings.shape[0]
        
        total_explained_variance = 0
        total_variance = 0
        
        for i in range(n_assets):
            asset_loadings = self.factor_loadings[i, :]
            factor_variance = asset_loadings @ self.factor_covariance @ asset_loadings
            specific_variance = self.specific_variance[i]
            total_asset_variance = factor_variance + specific_variance
            
            total_explained_variance += factor_variance
            total_variance += total_asset_variance
            
        return total_explained_variance / total_variance if total_variance > 0 else 0.0
        
    def _calculate_average_r_squared(self) -> float:
        """Calculate average R-squared across all assets"""
        n_assets = self.factor_loadings.shape[0]
        
        r_squared_values = []
        for i in range(n_assets):
            r_squared_values.append(self._calculate_r_squared(i))
            
        return np.mean(r_squared_values)
        
    def factor_portfolio_analysis(self, weights: np.ndarray) -> Dict:
        """
        Analyze portfolio factor exposures
        
        Args:
            weights: Portfolio weights
            
        Returns:
            Portfolio factor analysis
        """
        if self.factor_loadings is None:
            raise ValueError("Must run optimization first")
            
        # Portfolio factor exposures
        portfolio_factor_exposures = self.factor_loadings.T @ weights
        
        # Factor contributions to portfolio variance
        factor_contributions = np.diag(
            portfolio_factor_exposures @ self.factor_covariance @ portfolio_factor_exposures
        )
        
        # Specific contribution
        specific_contribution = np.sum(weights**2 * self.specific_variance)
        
        total_portfolio_variance = np.sum(factor_contributions) + specific_contribution
        
        # Factor contributions as percentages
        factor_contribution_percentages = factor_contributions / total_portfolio_variance
        
        return {
            'portfolio_factor_exposures': portfolio_factor_exposures,
            'factor_contributions': factor_contributions,
            'factor_contribution_percentages': factor_contribution_percentages,
            'specific_contribution': specific_contribution,
            'specific_contribution_percentage': specific_contribution / total_portfolio_variance,
            'total_factors': len(portfolio_factor_exposures)
        }
        
    def stress_test_factor_model(self, factor_shocks: Dict) -> Dict:
        """
        Stress test factor model with factor shocks
        
        Args:
            factor_shocks: Dictionary with factor shocks {factor_index: shock_magnitude}
            
        Returns:
            Stress test results
        """
        if self.factor_loadings is None:
            raise ValueError("Must run optimization first")
            
        # Apply factor shocks
        shocked_factor_returns = self.factor_returns.copy()
        
        for factor_index, shock_magnitude in factor_shocks.items():
            if 0 <= factor_index < len(shocked_factor_returns):
                shocked_factor_returns[factor_index] += shock_magnitude
                
        # Calculate new portfolio expected returns
        portfolio_returns = self.factor_loadings @ shocked_factor_returns + \
                           (1 - np.sum(self.factor_loadings**2, axis=1)) * np.mean(self.specific_variance)
        
        return {
            'shocked_factor_returns': shocked_factor_returns,
            'original_factor_returns': self.factor_returns,
            'factor_shocks': factor_shocks,
            'shocked_portfolio_returns': portfolio_returns
        }
        
    def backtest_factor_model(self,
                            returns_data: np.ndarray,
                            window_size: int = 252,
                            method: str = "pca") -> Dict:
        """
        Backtest factor model optimization over time
        
        Args:
            returns_data: Historical returns data (T x N)
            window_size: Rolling window size
            method: Factor extraction method
            
        Returns:
            Backtest results
        """
        n_periods, n_assets = returns_data.shape
        portfolio_returns = []
        portfolio_weights = []
        factor_analysis_history = []
        
        for i in range(window_size, n_periods):
            try:
                # Get window data
                window_returns = returns_data[i-window_size:i]
                
                # Calculate expected returns (recent average)
                expected_returns = np.mean(window_returns, axis=0)
                
                # Calculate covariance matrix
                covariance_matrix = np.cov(window_returns.T)
                
                # Optimize using factor model
                weights = self.optimize(
                    expected_returns=expected_returns,
                    covariance_matrix=covariance_matrix,
                    returns_data=window_returns
                )
                
                # Store factor analysis
                factor_analysis = self.factor_portfolio_analysis(weights)
                
                # Next period return
                next_return = returns_data[i]
                portfolio_return = np.dot(weights, next_return)
                
                portfolio_returns.append(portfolio_return)
                portfolio_weights.append(weights)
                factor_analysis_history.append(factor_analysis)
                
            except Exception as e:
                self.logger.warning(f"Factor model optimization failed at period {i}: {e}")
                # Use equal weights
                weights = np.ones(n_assets) / n_assets
                portfolio_return = np.dot(weights, returns_data[i])
                portfolio_returns.append(portfolio_return)
                portfolio_weights.append(weights)
                
        # Calculate performance metrics
        portfolio_returns = np.array(portfolio_returns)
        portfolio_weights = np.array(portfolio_weights)
        
        return {
            'portfolio_returns': portfolio_returns,
            'portfolio_weights': portfolio_weights,
            'factor_analysis_history': factor_analysis_history,
            'num_periods': len(portfolio_returns),
            'annual_return': np.mean(portfolio_returns) * 252,
            'annual_volatility': np.std(portfolio_returns) * np.sqrt(252),
            'sharpe_ratio': np.mean(portfolio_returns) / np.std(portfolio_returns) * np.sqrt(252),
            'max_drawdown': self._calculate_max_drawdown(portfolio_returns)
        }
        
    def _calculate_max_drawdown(self, returns: np.ndarray) -> float:
        """Calculate maximum drawdown"""
        cumulative_returns = (1 + pd.Series(returns)).cumprod()
        running_max = cumulative_returns.expanding().max()
        drawdown = (cumulative_returns - running_max) / running_max
        return drawdown.min()
