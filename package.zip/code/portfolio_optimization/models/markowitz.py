"""
Markowitz Portfolio Optimizer
Mean-variance optimization implementation
"""

import numpy as np
import cvxpy as cp
from typing import Dict, List, Optional
import logging

from core.config import OptimizationConfig


class MarkowitzOptimizer:
    """
    Markowitz Mean-Variance Portfolio Optimizer
    
    Classical modern portfolio theory implementation using quadratic programming
    """
    
    def __init__(self, config: OptimizationConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
    def optimize(self, 
                 expected_returns: np.ndarray,
                 covariance_matrix: np.ndarray,
                 constraints: List[Dict] = None,
                 method: str = "max_sharpe") -> np.ndarray:
        """
        Markowitz optimization
        
        Args:
            expected_returns: Expected returns for each asset
            covariance_matrix: Covariance matrix of returns
            constraints: List of constraint dictionaries
            method: Optimization method ("max_sharpe", "min_risk", "max_return")
            
        Returns:
            Optimal portfolio weights
        """
        n_assets = len(expected_returns)
        
        # Decision variables
        weights = cp.Variable(n_assets)
        
        # Portfolio return and risk
        portfolio_return = weights @ expected_returns
        portfolio_variance = cp.quad_form(weights, covariance_matrix)
        portfolio_risk = cp.sqrt(portfolio_variance)
        
        # Objective function based on method
        if method == "max_sharpe":
            # Maximize Sharpe ratio: (portfolio_return - risk_free_rate) / portfolio_risk
            risk_free_rate = self.config.risk_free_rate
            sharpe_ratio = (portfolio_return - risk_free_rate) / portfolio_risk
            objective = cp.Maximize(sharpe_ratio)
            
        elif method == "min_risk":
            # Minimize portfolio risk
            objective = cp.Minimize(portfolio_risk)
            
        elif method == "max_return":
            # Maximize expected return subject to risk constraint
            risk_limit = cp.Parameter(nonneg=True)
            risk_limit.value = 0.15  # 15% risk limit
            objective = cp.Maximize(portfolio_return)
            constraints.append({
                'type': 'risk_constraint',
                'limit': risk_limit
            })
            
        else:
            raise ValueError(f"Unknown optimization method: {method}")
            
        # Build constraints
        optimization_constraints = self._build_constraints(weights, constraints)
        
        # Solve optimization problem
        problem = cp.Problem(objective, optimization_constraints)
        
        try:
            problem.solve(
                solver=cp.ECOS,
                verbose=False,
                max_iters=1000
            )
            
            if problem.status not in ["infeasible", "unbounded"]:
                optimal_weights = weights.value
                
                # Clean up numerical errors (round to 6 decimal places)
                optimal_weights = np.round(optimal_weights, 6)
                
                # Ensure weights sum to 1 (small numerical errors)
                if abs(np.sum(optimal_weights) - 1.0) > 1e-6:
                    optimal_weights = optimal_weights / np.sum(optimal_weights)
                    
                self.logger.info(f"Markowitz optimization completed successfully. Status: {problem.status}")
                return optimal_weights
            else:
                self.logger.error(f"Markowitz optimization failed. Status: {problem.status}")
                # Return equal weights as fallback
                return np.ones(n_assets) / n_assets
                
        except Exception as e:
            self.logger.error(f"Error in Markowitz optimization: {e}")
            # Return equal weights as fallback
            return np.ones(n_assets) / n_assets
            
    def _build_constraints(self, weights: cp.Variable, constraints: List[Dict]) -> List:
        """Build optimization constraints"""
        optimization_constraints = []
        
        # Default constraints
        optimization_constraints.append(
            cp.sum(weights) == 1  # Weights sum to 1
        )
        
        # Add user-defined constraints
        if constraints:
            for constraint in constraints:
                constraint_type = constraint.get('type', '')
                
                if constraint_type == 'weight_bounds':
                    # Individual weight bounds
                    min_weight = constraint.get('min_weight', self.config.min_weight)
                    max_weight = constraint.get('max_weight', self.config.max_weight)
                    optimization_constraints.append(weights >= min_weight)
                    optimization_constraints.append(weights <= max_weight)
                    
                elif constraint_type == 'max_position':
                    # Maximum position size
                    max_pos = constraint.get('max_position', self.config.max_position)
                    optimization_constraints.append(weights <= max_pos)
                    
                elif constraint_type == 'sector_constraints':
                    # Sector-based constraints (requires sector mapping)
                    sector_constraints = constraint.get('constraints', {})
                    # Implementation would require sector mapping for each asset
                    
                elif constraint_type == 'return':
                    # Target return constraint
                    target_return = constraint.get('target')
                    if target_return is not None:
                        # This requires expected returns to be passed as parameter
                        # For now, implement simplified version
                        pass
                        
                elif constraint_type == 'risk_constraint':
                    # Risk limit constraint
                    risk_limit = constraint.get('limit', 0.15)
                    # This would require portfolio_risk to be available
                    pass
                    
        else:
            # Default constraints if none specified
            optimization_constraints.append(
                weights >= self.config.min_weight
            )
            optimization_constraints.append(
                weights <= self.config.max_weight
            )
            optimization_constraints.append(
                weights <= self.config.max_position
            )
            
        return optimization_constraints
        
    def efficient_frontier(self,
                          expected_returns: np.ndarray,
                          covariance_matrix: np.ndarray,
                          num_portfolios: int = 100) -> Dict:
        """
        Generate efficient frontier
        
        Args:
            expected_returns: Expected returns
            covariance_matrix: Covariance matrix
            num_portfolios: Number of portfolios to generate
            
        Returns:
            Dictionary with returns, risks, and weights
        """
        returns_range = np.linspace(
            expected_returns.min(),
            expected_returns.max(),
            num_portfolios
        )
        
        frontier_portfolios = []
        
        for target_return in returns_range:
            try:
                weights = self.optimize(
                    expected_returns=expected_returns,
                    covariance_matrix=covariance_matrix,
                    method="max_return"
                )
                
                portfolio_return = np.dot(weights, expected_returns)
                portfolio_variance = np.dot(weights, np.dot(covariance_matrix, weights))
                portfolio_risk = np.sqrt(portfolio_variance)
                
                if abs(portfolio_return - target_return) < 0.001:  # Close to target
                    frontier_portfolios.append({
                        'return': portfolio_return,
                        'risk': portfolio_risk,
                        'weights': weights
                    })
                    
            except Exception as e:
                self.logger.warning(f"Error generating efficient frontier point: {e}")
                continue
                
        return {
            'portfolios': frontier_portfolios,
            'returns': [p['return'] for p in frontier_portfolios],
            'risks': [p['risk'] for p in frontier_portfolios]
        }
        
    def tangency_portfolio(self,
                          expected_returns: np.ndarray,
                          covariance_matrix: np.ndarray,
                          risk_free_rate: Optional[float] = None) -> Dict:
        """
        Calculate tangency portfolio (maximum Sharpe ratio portfolio)
        
        Args:
            expected_returns: Expected returns
            covariance_matrix: Covariance matrix
            risk_free_rate: Risk-free rate (uses config if None)
            
        Returns:
            Dictionary with tangency portfolio details
        """
        if risk_free_rate is None:
            risk_free_rate = self.config.risk_free_rate
            
        # Optimize for maximum Sharpe ratio
        weights = self.optimize(
            expected_returns=expected_returns,
            covariance_matrix=covariance_matrix,
            method="max_sharpe"
        )
        
        # Calculate portfolio metrics
        portfolio_return = np.dot(weights, expected_returns)
        portfolio_risk = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
        sharpe_ratio = (portfolio_return - risk_free_rate) / portfolio_risk
        
        return {
            'weights': weights,
            'expected_return': portfolio_return,
            'expected_risk': portfolio_risk,
            'sharpe_ratio': sharpe_ratio,
            'risk_free_rate': risk_free_rate
        }
        
    def critical_line_algorithm(self,
                               expected_returns: np.ndarray,
                               covariance_matrix: np.ndarray) -> List[Dict]:
        """
        Critical Line Algorithm (CLA) for efficient frontier
        
        More efficient than generic QP for large portfolios
        """
        # Simplified CLA implementation
        # Full implementation would be more complex
        
        n_assets = len(expected_returns)
        
        # Start with equal weights
        current_weights = np.ones(n_assets) / n_assets
        
        portfolios = []
        
        # Generate several portfolios along efficient frontier
        target_returns = np.linspace(
            expected_returns.min(),
            expected_returns.max(),
            20
        )
        
        for target_return in target_returns:
            try:
                weights = self.optimize(
                    expected_returns=expected_returns,
                    covariance_matrix=covariance_matrix,
                    method="max_return"
                )
                
                portfolio_return = np.dot(weights, expected_returns)
                portfolio_risk = np.sqrt(np.dot(weights, np.dot(covariance_matrix, weights)))
                
                portfolios.append({
                    'return': portfolio_return,
                    'risk': portfolio_risk,
                    'weights': weights
                })
                
            except Exception as e:
                self.logger.warning(f"Error in CLA step: {e}")
                continue
                
        return portfolios
        
    def backtest_optimization(self,
                             returns_data: np.ndarray,
                             window_size: int = 252) -> Dict:
        """
        Backtest Markowitz optimization over time
        
        Args:
            returns_data: Historical returns data (T x N)
            window_size: Rolling window size in days
            
        Returns:
            Backtest results
        """
        n_periods, n_assets = returns_data.shape
        portfolio_returns = []
        portfolio_weights = []
        
        for i in range(window_size, n_periods):
            # Get window data
            window_returns = returns_data[i-window_size:i]
            
            # Calculate inputs
            expected_returns = np.mean(window_returns, axis=0)
            covariance_matrix = np.cov(window_returns.T)
            
            # Optimize
            try:
                weights = self.optimize(
                    expected_returns=expected_returns,
                    covariance_matrix=covariance_matrix
                )
                
                # Next period return
                next_return = returns_data[i]
                portfolio_return = np.dot(weights, next_return)
                
                portfolio_returns.append(portfolio_return)
                portfolio_weights.append(weights)
                
            except Exception as e:
                self.logger.warning(f"Optimization failed at period {i}: {e}")
                # Use equal weights
                weights = np.ones(n_assets) / n_assets
                portfolio_return = np.dot(weights, returns_data[i])
                portfolio_returns.append(portfolio_return)
                portfolio_weights.append(weights)
                
        return {
            'portfolio_returns': np.array(portfolio_returns),
            'portfolio_weights': np.array(portfolio_weights),
            'num_periods': len(portfolio_returns),
            'annual_return': np.mean(portfolio_returns) * 252,
            'annual_volatility': np.std(portfolio_returns) * np.sqrt(252),
            'sharpe_ratio': np.mean(portfolio_returns) / np.std(portfolio_returns) * np.sqrt(252)
        }
