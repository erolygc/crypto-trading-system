"""
Multi-Factor Sinyal Skorlama Sistemi
===================================

Çoklu faktörlere dayalı sinyal skorlama engine'i.
Sharpe ratio, win rate, maximum drawdown ve stability metriklerini birleştirir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from scipy import stats
from dataclasses import dataclass
import warnings

warnings.filterwarnings('ignore')


@dataclass
class SignalMetrics:
    """Sinyal performans metrikleri"""
    signal_id: str
    strategy_name: str
    returns: np.ndarray
    timestamps: np.ndarray
    positions: np.ndarray
    
    # Hesaplanan metrikler
    sharpe_ratio: float = 0.0
    win_rate: float = 0.0
    max_drawdown: float = 0.0
    stability_score: float = 0.0
    sortino_ratio: float = 0.0
    calmar_ratio: float = 0.0
    profit_factor: float = 0.0
    avg_trade_return: float = 0.0
    trade_frequency: float = 0.0


class MultiFactorScorer:
    """
    Multi-factor signal scoring engine
    
    Sharpe ratio, win rate, max drawdown, stability gibi metrikleri
    ağırlıklı olarak birleştirerek sinyal skorlama yapar.
    """
    
    def __init__(self, 
                 risk_free_rate: float = 0.02,
                 scoring_weights: Optional[Dict[str, float]] = None):
        """
        Initialize multi-factor scorer
        
        Args:
            risk_free_rate: Risksiz getiri oranı (yıllık)
            scoring_weights: Skorlama ağırlıkları
        """
        self.risk_free_rate = risk_free_rate
        self.scoring_weights = scoring_weights or {
            'sharpe_ratio': 0.25,
            'win_rate': 0.20,
            'stability': 0.20,
            'max_drawdown': 0.15,
            'sortino_ratio': 0.10,
            'calmar_ratio': 0.10
        }
        
        # Normalizasyon parametreleri
        self.normalization_params = {
            'sharpe_ratio': {'min': -3.0, 'max': 3.0},
            'win_rate': {'min': 0.0, 'max': 1.0},
            'max_drawdown': {'min': 0.0, 'max': 1.0},
            'stability': {'min': 0.0, 'max': 1.0},
            'sortino_ratio': {'min': -3.0, 'max': 3.0},
            'calmar_ratio': {'min': -3.0, 'max': 3.0}
        }
    
    def calculate_metrics(self, signal_data: Dict) -> SignalMetrics:
        """
        Sinyal için tüm metrikleri hesapla
        
        Args:
            signal_data: Sinyal verisi {
                'signal_id': str,
                'strategy_name': str,
                'returns': np.ndarray,
                'timestamps': np.ndarray,
                'positions': np.ndarray
            }
        
        Returns:
            SignalMetrics: Hesaplanan metrikler
        """
        metrics = SignalMetrics(**signal_data)
        
        # Temel metrikleri hesapla
        metrics.sharpe_ratio = self._calculate_sharpe_ratio(metrics.returns)
        metrics.win_rate = self._calculate_win_rate(metrics.returns)
        metrics.max_drawdown = self._calculate_max_drawdown(metrics.returns)
        metrics.stability_score = self._calculate_stability(metrics.returns)
        metrics.sortino_ratio = self._calculate_sortino_ratio(metrics.returns)
        metrics.calmar_ratio = self._calculate_calmar_ratio(metrics.returns)
        
        # Ek metrikler
        metrics.profit_factor = self._calculate_profit_factor(metrics.returns)
        metrics.avg_trade_return = self._calculate_avg_trade_return(metrics.returns)
        metrics.trade_frequency = self._calculate_trade_frequency(metrics.positions)
        
        return metrics
    
    def _calculate_sharpe_ratio(self, returns: np.ndarray) -> float:
        """Sharpe oranı hesapla"""
        if len(returns) < 2 or np.std(returns) == 0:
            return 0.0
        
        excess_returns = returns - (self.risk_free_rate / 252)  # Günlük risksiz getiri
        return np.mean(excess_returns) / np.std(returns) * np.sqrt(252)
    
    def _calculate_win_rate(self, returns: np.ndarray) -> float:
        """Kazanma oranı hesapla"""
        if len(returns) == 0:
            return 0.0
        return np.sum(returns > 0) / len(returns)
    
    def _calculate_max_drawdown(self, returns: np.ndarray) -> float:
        """Maximum drawdown hesapla"""
        if len(returns) == 0:
            return 0.0
        
        # Convert to pandas Series for expanding operations
        cumulative = pd.Series(returns).add(1).cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        return abs(drawdown.min())
    
    def _calculate_stability(self, returns: np.ndarray) -> float:
        """Getiri stabilitesi hesapla (yüksek = daha istikrarlı)"""
        if len(returns) < 2:
            return 0.0
        
        # Pozisyon değişimleri ile volatiliteyi ölç
        rolling_vol = pd.Series(returns).rolling(window=min(20, len(returns)//2)).std()
        avg_vol = rolling_vol.mean()
        
        if avg_vol == 0:
            return 1.0
        
        # Volatiliteyi tersine çevir (düşük vol = yüksek stabilite)
        stability = 1 / (1 + avg_vol)
        return min(stability, 1.0)
    
    def _calculate_sortino_ratio(self, returns: np.ndarray) -> float:
        """Sortino oranı hesapla (negatif volatilite ile)"""
        if len(returns) < 2:
            return 0.0
        
        excess_returns = returns - (self.risk_free_rate / 252)
        downside_deviation = np.std(returns[returns < 0])
        
        if downside_deviation == 0:
            return 0.0
        
        return np.mean(excess_returns) / downside_deviation * np.sqrt(252)
    
    def _calculate_calmar_ratio(self, returns: np.ndarray) -> float:
        """Calmar oranı hesapla (yıllık getiri / max drawdown)"""
        if len(returns) == 0:
            return 0.0
        
        annual_return = np.prod(1 + returns) ** (252 / len(returns)) - 1
        max_dd = self._calculate_max_drawdown(returns)
        
        if max_dd == 0:
            return 0.0
        
        return annual_return / max_dd
    
    def _calculate_profit_factor(self, returns: np.ndarray) -> float:
        """Profit factor hesapla"""
        gross_profit = np.sum(returns[returns > 0])
        gross_loss = abs(np.sum(returns[returns < 0]))
        
        if gross_loss == 0:
            return float('inf') if gross_profit > 0 else 0.0
        
        return gross_profit / gross_loss
    
    def _calculate_avg_trade_return(self, returns: np.ndarray) -> float:
        """Ortalama trade getirisi hesapla"""
        if len(returns) == 0:
            return 0.0
        return np.mean(returns)
    
    def _calculate_trade_frequency(self, positions: np.ndarray) -> float:
        """Trade frekansı hesapla (günlük pozisyon değişimi)"""
        if len(positions) < 2:
            return 0.0
        
        position_changes = np.sum(np.diff(positions) != 0)
        return position_changes / len(positions)
    
    def normalize_score(self, metric_name: str, value: float) -> float:
        """
        Metrik değerini 0-1 aralığına normalizasyon
        
        Args:
            metric_name: Metrik adı
            value: Ham metrik değeri
        
        Returns:
            Normalize edilmiş skor (0-1)
        """
        if metric_name not in self.normalization_params:
            return 0.5  # Default orta değer
        
        params = self.normalization_params[metric_name]
        min_val, max_val = params['min'], params['max']
        
        # Linear normalization
        normalized = (value - min_val) / (max_val - min_val)
        
        # 0-1 aralığına kısıtla
        return max(0.0, min(1.0, normalized))
    
    def calculate_composite_score(self, metrics: SignalMetrics) -> float:
        """
        Ağırlıklı composite skor hesapla
        
        Args:
            metrics: Hesaplanmış metrikler
        
        Returns:
            Composite skor (0-1)
        """
        # Her metrik için normalize skor hesapla
        normalized_scores = {
            'sharpe_ratio': self.normalize_score('sharpe_ratio', metrics.sharpe_ratio),
            'win_rate': self.normalize_score('win_rate', metrics.win_rate),
            'stability': self.normalize_score('stability', metrics.stability_score),
            'max_drawdown': self.normalize_score('max_drawdown', 1 - metrics.max_drawdown),  # Ters çevir
            'sortino_ratio': self.normalize_score('sortino_ratio', metrics.sortino_ratio),
            'calmar_ratio': self.normalize_score('calmar_ratio', metrics.calmar_ratio)
        }
        
        # Ağırlıklı ortalama hesapla
        weighted_score = 0.0
        total_weight = 0.0
        
        for metric_name, weight in self.scoring_weights.items():
            if metric_name in normalized_scores:
                weighted_score += normalized_scores[metric_name] * weight
                total_weight += weight
        
        if total_weight == 0:
            return 0.0
        
        return weighted_score / total_weight
    
    def batch_score(self, signals_data: List[Dict]) -> List[Tuple[SignalMetrics, float]]:
        """
        Toplu sinyal skorlama
        
        Args:
            signals_data: Sinyal verileri listesi
        
        Returns:
            List[Tuple[SignalMetrics, float]]: (metrikler, composite_skor) tuples
        """
        results = []
        
        for signal_data in signals_data:
            metrics = self.calculate_metrics(signal_data)
            composite_score = self.calculate_composite_score(metrics)
            results.append((metrics, composite_score))
        
        return results
    
    def get_score_breakdown(self, metrics: SignalMetrics) -> Dict[str, float]:
        """
        Skor bileşenlerinin detayını döndür
        
        Args:
            metrics: Hesaplanmış metrikler
        
        Returns:
            Dict[str, float]: Skor breakdown'u
        """
        normalized_scores = {
            'sharpe_ratio': self.normalize_score('sharpe_ratio', metrics.sharpe_ratio),
            'win_rate': self.normalize_score('win_rate', metrics.win_rate),
            'stability': self.normalize_score('stability', metrics.stability_score),
            'max_drawdown': self.normalize_score('max_drawdown', 1 - metrics.max_drawdown),
            'sortino_ratio': self.normalize_score('sortino_ratio', metrics.sortino_ratio),
            'calmar_ratio': self.normalize_score('calmar_ratio', metrics.calmar_ratio)
        }
        
        return normalized_scores
    
    def adjust_weights(self, new_weights: Dict[str, float]):
        """
        Skorlama ağırlıklarını güncelle
        
        Args:
            new_weights: Yeni ağırlıklar
        """
        # Ağırlıkları normalizele (toplamı 1 olsun)
        total_weight = sum(new_weights.values())
        if total_weight > 0:
            new_weights = {k: v/total_weight for k, v in new_weights.items()}
        
        self.scoring_weights.update(new_weights)
    
    def get_performance_ranking(self, scored_signals: List[Tuple[SignalMetrics, float]]) -> List[Tuple[str, float, str]]:
        """
        Skorlanmış sinyalleri sırala
        
        Args:
            scored_signals: Skorlanmış sinyaller
        
        Returns:
            List[Tuple[str, float, str]]: (signal_id, score, strategy_name) tuples
        """
        ranking = []
        
        for metrics, score in scored_signals:
            ranking.append((metrics.signal_id, score, metrics.strategy_name))
        
        # Skora göre sırala (azalan)
        ranking.sort(key=lambda x: x[1], reverse=True)
        
        return ranking