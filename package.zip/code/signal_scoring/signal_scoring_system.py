"""
Signal Scoring Sistemi Ana Entegrasyon ve Demo
=============================================

Tüm bileşenleri bir araya getiren ana sistem ve demo script.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from datetime import datetime, timedelta
import json
import warnings

# Import all components
from .multi_factor_scorer import MultiFactorScorer, SignalMetrics
from .market_regime_detector import MarketRegimeDetector, MarketRegime
from .confidence_calculator import ConfidenceCalculator, ConfidenceMetrics
from .ensemble_scorer import EnsembleScorer, WeightingMethod
from .performance_attribution import PerformanceAttribution
from .signal_ranking import SignalRanking, RankingMethod, SignalRank
from .account_manager_interface import AccountManagerInterface, RiskProfile

warnings.filterwarnings('ignore')


class SignalScoringSystem:
    """
    Ana Signal Scoring Sistemi
    
    Tüm bileşenleri entegre eden ve coordinate eden ana sistem.
    End-to-end signal scoring, ranking ve execution pipeline sağlar.
    """
    
    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize the complete signal scoring system
        
        Args:
            config: Sistem konfigürasyonu
        """
        self.config = config or self._default_config()
        
        # Initialize components
        self.multi_factor_scorer = MultiFactorScorer(
            risk_free_rate=self.config.get('risk_free_rate', 0.02)
        )
        
        self.market_regime_detector = MarketRegimeDetector(
            lookback_period=self.config.get('lookback_period', 50),
            trend_threshold=self.config.get('trend_threshold', 0.02),
            volatility_threshold=self.config.get('volatility_threshold', 0.025)
        )
        
        self.confidence_calculator = ConfidenceCalculator(
            confidence_level=self.config.get('confidence_level', 0.95),
            bootstrap_samples=self.config.get('bootstrap_samples', 1000)
        )
        
        self.ensemble_scorer = EnsembleScorer(
            weighting_method=WeightingMethod(self.config.get('weighting_method', 'dynamic_adaptive'))
        )
        
        self.performance_attribution = PerformanceAttribution(
            benchmark=self.config.get('benchmark', 'SPY')
        )
        
        self.signal_ranking = SignalRanking(
            ranking_method=RankingMethod(self.config.get('ranking_method', 'composite_score')),
            max_active_signals=self.config.get('max_active_signals', 10)
        )
        
        self.account_interface = AccountManagerInterface()
        
        # Data storage
        self.signal_database: Dict[str, Dict] = {}
        self.processing_history: List[Dict] = []
        self.performance_metrics: Dict[str, List[float]] = {}
        
        # Set up ensemble components
        self._setup_ensemble_components()
        
        # Set up signal ranking scoring engine
        self.signal_ranking.set_scoring_engine(self)
    
    def _default_config(self) -> Dict:
        """Default sistem konfigürasyonu"""
        return {
            'risk_free_rate': 0.02,
            'lookback_period': 50,
            'trend_threshold': 0.02,
            'volatility_threshold': 0.025,
            'confidence_level': 0.95,
            'bootstrap_samples': 1000,
            'weighting_method': 'dynamic_adaptive',
            'ranking_method': 'composite_score',
            'max_active_signals': 10,
            'benchmark': 'SPY'
        }
    
    def _setup_ensemble_components(self):
        """Ensemble components'ı ayarla"""
        # Add scoring components to ensemble
        self.ensemble_scorer.add_component(
            name="multi_factor_scorer",
            scorer_function=self._ensemble_multi_factor_scoring,
            initial_weight=0.4,
            initial_confidence=0.8
        )
        
        self.ensemble_scorer.add_component(
            name="confidence_weighted",
            scorer_function=self._ensemble_confidence_weighted_scoring,
            initial_weight=0.3,
            initial_confidence=0.7
        )
        
        self.ensemble_scorer.add_component(
            name="market_regime_adjusted",
            scorer_function=self._ensemble_market_regime_scoring,
            initial_weight=0.2,
            initial_confidence=0.6
        )
        
        self.ensemble_scorer.add_component(
            name="risk_adjusted",
            scorer_function=self._ensemble_risk_adjusted_scoring,
            initial_weight=0.1,
            initial_confidence=0.5
        )
    
    def process_signal(self, signal_data: Dict) -> Dict:
        """
        Tek sinyal için complete processing pipeline
        
        Args:
            signal_data: Sinyal verisi
        
        Returns:
            Dict: Complete processing sonucu
        """
        signal_id = signal_data.get('signal_id')
        if not signal_id:
            raise ValueError("Signal ID is required")
        
        processing_start = datetime.now()
        
        try:
            # Step 1: Multi-factor scoring
            metrics = self.multi_factor_scorer.calculate_metrics(signal_data)
            multi_factor_score = self.multi_factor_scorer.calculate_composite_score(metrics)
            
            # Step 2: Market regime detection and adjustment
            price_data = self._extract_price_data(signal_data)
            regime_metrics = None
            market_adjustment = 1.0
            
            if price_data is not None and len(price_data) > 0:
                try:
                    regime_metrics = self.market_regime_detector.detect_regime(price_data)
                    adjustments = self.market_regime_detector.get_regime_adjustments(regime_metrics.regime)
                    market_adjustment = adjustments.get('volatility_adjustment', 1.0)
                except Exception as e:
                    print(f"Market regime detection failed: {e}")
            
            # Step 3: Confidence calculation
            confidence_metrics = self.confidence_calculator.calculate_signal_confidence(signal_data)
            
            # Step 4: Ensemble scoring
            ensemble_result = self.ensemble_scorer.calculate_ensemble_score(signal_data)
            
            # Step 5: Performance attribution for this signal
            signal_attribution = self.performance_attribution.signal_level_attribution(
                signal_data, ensemble_result.component_scores, ensemble_result.final_score
            )
            
            # Combine all scores
            final_score = self._combine_scores(
                multi_factor_score=multi_factor_score,
                ensemble_score=ensemble_result.final_score,
                confidence_score=confidence_metrics.mean_score,
                market_adjustment=market_adjustment,
                risk_adjusted_score=ensemble_result.final_score / (1 + confidence_metrics.uncertainty_score)
            )
            
            # Update signal with processing results
            processed_signal = signal_data.copy()
            processed_signal.update({
                'processed_at': processing_start.isoformat(),
                'multi_factor_score': multi_factor_score,
                'ensemble_score': ensemble_result.final_score,
                'confidence_score': confidence_metrics.mean_score,
                'confidence_interval': confidence_metrics.confidence_interval,
                'market_regime': regime_metrics.regime.value if regime_metrics else 'unknown',
                'market_adjustment': market_adjustment,
                'uncertainty_score': confidence_metrics.uncertainty_score,
                'final_score': final_score,
                'component_scores': ensemble_result.component_scores,
                'attribution': signal_attribution,
                'tier': self._calculate_signal_tier(final_score),
                'processing_time_ms': (datetime.now() - processing_start).total_seconds() * 1000
            })
            
            # Store in database
            self.signal_database[signal_id] = processed_signal
            
            # Add to signal ranking system
            self.signal_ranking.add_signal(processed_signal)
            
            # Log processing
            self.processing_history.append({
                'signal_id': signal_id,
                'processed_at': processing_start.isoformat(),
                'final_score': final_score,
                'tier': processed_signal['tier'],
                'processing_time_ms': processed_signal['processing_time_ms']
            })
            
            return processed_signal
            
        except Exception as e:
            # Error handling
            error_result = {
                'signal_id': signal_id,
                'processed_at': processing_start.isoformat(),
                'error': str(e),
                'final_score': 0.0,
                'tier': 'D',
                'processing_time_ms': (datetime.now() - processing_start).total_seconds() * 1000
            }
            
            self.signal_database[signal_id] = error_result
            return error_result
    
    def batch_process_signals(self, signals_data: List[Dict]) -> List[Dict]:
        """
        Toplu sinyal processing
        
        Args:
            signals_data: Sinyal verileri listesi
        
        Returns:
            List[Dict]: Processing sonuçları
        """
        results = []
        
        print(f"Processing {len(signals_data)} signals...")
        
        for i, signal_data in enumerate(signals_data):
            try:
                result = self.process_signal(signal_data)
                results.append(result)
                
                if (i + 1) % 10 == 0:
                    print(f"Processed {i + 1}/{len(signals_data)} signals")
                    
            except Exception as e:
                print(f"Error processing signal {i+1}: {e}")
                error_result = {
                    'signal_id': signal_data.get('signal_id', f'signal_{i}'),
                    'error': str(e),
                    'final_score': 0.0,
                    'tier': 'D'
                }
                results.append(error_result)
        
        print(f"Completed processing {len(results)} signals")
        
        return results
    
    def get_signal_rankings(self, n_top: Optional[int] = None) -> Dict:
        """
        Sinyal rankings'ini getir
        
        Args:
            n_top: En iyi N sinyal sayısı
        
        Returns:
            Dict: Ranking sonuçları
        """
        # Get ranking result
        ranking_result = self.signal_ranking.get_ranking_result()
        
        # Add system analytics
        ranking_result.summary_stats.update({
            'total_processed': len(self.signal_database),
            'success_rate': len([s for s in self.signal_database.values() if 'error' not in s]) / max(len(self.signal_database), 1),
            'avg_processing_time': np.mean([s.get('processing_time_ms', 0) for s in self.processing_history[-100:]]),
            'system_uptime': (datetime.now() - datetime.fromisoformat(self.processing_history[0]['processed_at'])).total_seconds() if self.processing_history else 0
        })
        
        return {
            'ranking_result': ranking_result,
            'top_n_signals': ranking_result.top_signals[:n_top] if n_top else ranking_result.top_signals,
            'system_analytics': ranking_result.summary_stats,
            'diversification_analysis': ranking_result.diversification_analysis
        }
    
    def generate_comprehensive_report(self) -> Dict:
        """
        Kapsamlı sistem raporu oluştur
        
        Returns:
            Dict: Comprehensive system report
        """
        # Get rankings
        rankings = self.get_signal_rankings()
        
        # System performance
        system_performance = self._calculate_system_performance()
        
        # Portfolio view
        portfolio_view = self.account_interface.get_aggregated_portfolio_view()
        
        # Risk monitoring
        risk_monitoring = self.account_interface.monitor_portfolio_risk()
        
        # Execution report
        execution_report = self.account_interface.generate_execution_report()
        
        # Market regime analysis
        market_regime_analysis = self._analyze_market_regimes()
        
        # Performance attribution summary
        if self.processing_history:
            recent_signals = list(self.signal_database.values())[-50:]  # Last 50 signals
            
            attribution_summary = self._generate_attribution_summary(recent_signals)
        else:
            attribution_summary = {}
        
        report = {
            'executive_summary': {
                'total_signals_processed': len(self.signal_database),
                'active_signals': len([s for s in self.signal_database.values() if s.get('tier') in ['A', 'B']]),
                'system_health': 'Healthy' if len(self.processing_history) > 0 else 'Initializing',
                'last_updated': datetime.now().isoformat()
            },
            'signal_rankings': rankings,
            'system_performance': system_performance,
            'portfolio_view': portfolio_view,
            'risk_monitoring': risk_monitoring,
            'execution_report': execution_report,
            'market_regime_analysis': market_regime_analysis,
            'performance_attribution': attribution_summary,
            'recommendations': self._generate_recommendations()
        }
        
        return report
    
    def _extract_price_data(self, signal_data: Dict) -> Optional[pd.DataFrame]:
        """Signal data'dan price data extract et"""
        # Simplified - in real implementation would extract actual price data
        if 'price_data' in signal_data:
            return signal_data['price_data']
        
        # Generate synthetic price data for demo
        if 'historical_returns' in signal_data:
            returns = np.array(signal_data['historical_returns'])
            prices = 100 * np.cumprod(1 + returns)
            dates = pd.date_range(start=datetime.now() - timedelta(days=len(returns)), 
                                periods=len(returns), freq='D')
            
            return pd.DataFrame({
                'close': prices,
                'volume': np.random.randint(1000, 10000, len(prices))
            }, index=dates)
        
        return None
    
    def _combine_scores(self, **scores) -> float:
        """Farklı skorları combine et"""
        weights = {
            'multi_factor_score': 0.3,
            'ensemble_score': 0.4,
            'confidence_score': 0.2,
            'risk_adjusted_score': 0.1
        }
        
        # Apply market adjustment
        market_adjustment = scores.get('market_adjustment', 1.0)
        
        combined_score = 0.0
        total_weight = 0.0
        
        for score_name, weight in weights.items():
            if score_name in scores:
                score_value = scores[score_name]
                combined_score += score_value * weight
                total_weight += weight
        
        # Normalize and apply market adjustment
        if total_weight > 0:
            combined_score = (combined_score / total_weight) * market_adjustment
        
        return max(0.0, min(1.0, combined_score))  # Clip to [0, 1]
    
    def _calculate_signal_tier(self, score: float) -> str:
        """Skora göre tier hesapla"""
        if score >= 0.8:
            return 'A'
        elif score >= 0.6:
            return 'B'
        elif score >= 0.4:
            return 'C'
        else:
            return 'D'
    
    def _calculate_system_performance(self) -> Dict:
        """System performance hesapla"""
        if not self.processing_history:
            return {}
        
        recent_processing = self.processing_history[-100:]  # Last 100 operations
        
        scores = [p['final_score'] for p in recent_processing if p['final_score'] > 0]
        processing_times = [p['processing_time_ms'] for p in recent_processing]
        
        return {
            'avg_score': np.mean(scores) if scores else 0.0,
            'score_std': np.std(scores) if scores else 0.0,
            'avg_processing_time_ms': np.mean(processing_times) if processing_times else 0.0,
            'processing_throughput_per_minute': len(recent_processing) / 60 if processing_times else 0.0,
            'success_rate': len([s for s in self.signal_database.values() if 'error' not in s]) / max(len(self.signal_database), 1)
        }
    
    def _analyze_market_regimes(self) -> Dict:
        """Market regime analysis"""
        # Analyze recent signals for regime patterns
        recent_signals = list(self.signal_database.values())[-50:]
        
        regime_distribution = {}
        regime_performance = {}
        
        for signal in recent_signals:
            regime = signal.get('market_regime', 'unknown')
            
            if regime not in regime_distribution:
                regime_distribution[regime] = 0
                regime_performance[regime] = []
            
            regime_distribution[regime] += 1
            regime_performance[regime].append(signal.get('final_score', 0))
        
        # Calculate average performance by regime
        for regime in regime_performance:
            scores = regime_performance[regime]
            regime_performance[regime] = {
                'count': len(scores),
                'avg_score': np.mean(scores),
                'avg_confidence': np.mean([s.get('confidence_score', 0) for s in recent_signals if s.get('market_regime') == regime])
            }
        
        return {
            'regime_distribution': regime_distribution,
            'regime_performance': regime_performance,
            'dominant_regime': max(regime_distribution, key=regime_distribution.get) if regime_distribution else 'unknown'
        }
    
    def _generate_attribution_summary(self, signals: List[Dict]) -> Dict:
        """Performance attribution summary oluştur"""
        if not signals:
            return {}
        
        # Strategy performance analysis
        strategy_performance = {}
        component_performance = {}
        
        for signal in signals:
            strategy = signal.get('strategy_name', 'unknown')
            attribution = signal.get('attribution', {})
            
            if strategy not in strategy_performance:
                strategy_performance[strategy] = []
            strategy_performance[strategy].append(signal.get('final_score', 0))
            
            # Component contributions
            for component, contribution in attribution.items():
                if component not in component_performance:
                    component_performance[component] = []
                component_performance[component].append(contribution)
        
        # Calculate averages
        strategy_summary = {}
        for strategy, scores in strategy_performance.items():
            strategy_summary[strategy] = {
                'avg_score': np.mean(scores),
                'signal_count': len(scores),
                'consistency': 1 - (np.std(scores) / (np.mean(scores) + 1e-8))
            }
        
        component_summary = {}
        for component, contributions in component_performance.items():
            component_summary[component] = {
                'avg_contribution': np.mean(contributions),
                'total_contribution': np.sum(contributions),
                'signal_count': len(contributions)
            }
        
        return {
            'strategy_performance': strategy_summary,
            'component_performance': component_summary,
            'top_strategy': max(strategy_summary, key=lambda x: strategy_summary[x]['avg_score']) if strategy_summary else 'none'
        }
    
    def _generate_recommendations(self) -> List[str]:
        """Sistem önerilerini oluştur"""
        recommendations = []
        
        # Signal quality recommendations
        if self.processing_history:
            recent_scores = [p['final_score'] for p in self.processing_history[-50:]]
            avg_score = np.mean(recent_scores)
            
            if avg_score < 0.5:
                recommendations.append("Consider adjusting signal quality thresholds")
            elif avg_score > 0.8:
                recommendations.append("Excellent signal quality - consider increasing position sizes")
        
        # System performance recommendations
        system_perf = self._calculate_system_performance()
        if system_perf.get('avg_processing_time_ms', 0) > 1000:
            recommendations.append("Consider optimizing processing pipeline for better performance")
        
        # Risk recommendations
        risk_monitoring = self.account_interface.monitor_portfolio_risk()
        if risk_monitoring.get('overall_risk_score', 0) > 0.8:
            recommendations.append("Portfolio risk is high - consider reducing position sizes")
        
        return recommendations
    
    # Ensemble scoring methods
    def _ensemble_multi_factor_scoring(self, signal_data: Dict, market_data: Optional[Dict] = None) -> float:
        """Multi-factor ensemble scoring"""
        metrics = self.multi_factor_scorer.calculate_metrics(signal_data)
        return self.multi_factor_scorer.calculate_composite_score(metrics)
    
    def _ensemble_confidence_weighted_scoring(self, signal_data: Dict, market_data: Optional[Dict] = None) -> float:
        """Confidence-weighted ensemble scoring"""
        confidence_metrics = self.confidence_calculator.calculate_signal_confidence(signal_data)
        return confidence_metrics.mean_score
    
    def _ensemble_market_regime_scoring(self, signal_data: Dict, market_data: Optional[Dict] = None) -> float:
        """Market regime adjusted ensemble scoring"""
        base_score = self._ensemble_multi_factor_scoring(signal_data, market_data)
        
        if market_data and 'regime' in market_data:
            regime = market_data['regime']
            adjustments = self.market_regime_detector.get_regime_adjustments(regime)
            adjustment_factor = adjustments.get('volatility_adjustment', 1.0)
            return base_score * adjustment_factor
        
        return base_score
    
    def _ensemble_risk_adjusted_scoring(self, signal_data: Dict, market_data: Optional[Dict] = None) -> float:
        """Risk-adjusted ensemble scoring"""
        base_score = self._ensemble_multi_factor_scoring(signal_data, market_data)
        confidence_metrics = self.confidence_calculator.calculate_signal_confidence(signal_data)
        
        # Adjust score based on uncertainty
        uncertainty_penalty = confidence_metrics.uncertainty_score
        return base_score * (1 - uncertainty_penalty)
    
    # External interface methods for compatibility
    def calculate_scores(self, signal_data: Dict) -> Dict[str, float]:
        """Signal scoring interface for ranking system"""
        metrics = self.multi_factor_scorer.calculate_metrics(signal_data)
        composite_score = self.multi_factor_scorer.calculate_composite_score(metrics)
        
        confidence_metrics = self.confidence_calculator.calculate_signal_confidence(signal_data)
        
        return {
            'composite': composite_score,
            'confidence': confidence_metrics.mean_score,
            'risk': confidence_metrics.uncertainty_score,
            'momentum': metrics.stability_score
        }


def generate_demo_data(num_signals: int = 50) -> List[Dict]:
    """
    Demo için synthetic signal data oluştur
    
    Args:
        num_signals: Oluşturulacak sinyal sayısı
    
    Returns:
        List[Dict]: Demo signal data
    """
    strategies = ['DVK', 'Genetic', 'Manual']
    assets = ['AAPL', 'GOOGL', 'MSFT', 'TSLA', 'NVDA', 'META', 'AMZN']
    sectors = ['Technology', 'Healthcare', 'Finance', 'Energy', 'Consumer']
    
    signals = []
    
    for i in range(num_signals):
        # Generate realistic signal data
        returns = np.random.normal(0.001, 0.02, 30)  # 30 days of returns
        positions = np.random.choice([-1, 0, 1], 30)  # Position changes
        
        signal = {
            'signal_id': f'signal_{i:04d}',
            'strategy_name': np.random.choice(strategies),
            'asset': np.random.choice(assets),
            'sector': np.random.choice(sectors),
            'returns': returns,
            'positions': positions,
            'historical_returns': returns.tolist(),
            'current_price': np.random.uniform(50, 500),
            'volume': np.random.randint(100000, 1000000),
            'timestamp': datetime.now() - timedelta(days=np.random.randint(1, 30))
        }
        
        signals.append(signal)
    
    return signals


def run_demo():
    """Demo script'i çalıştır"""
    print("🚀 Signal Scoring System Demo")
    print("=" * 50)
    
    # Initialize system
    print("Initializing signal scoring system...")
    config = {
        'max_active_signals': 10,
        'confidence_level': 0.95,
        'weighting_method': 'dynamic_adaptive'
    }
    
    scoring_system = SignalScoringSystem(config)
    
    # Generate demo data
    print("Generating demo signal data...")
    demo_signals = generate_demo_data(30)
    
    # Process signals
    print("Processing signals...")
    processed_signals = scoring_system.batch_process_signals(demo_signals)
    
    # Get rankings
    print("Generating rankings...")
    rankings = scoring_system.get_signal_rankings(n_top=10)
    
    # Print top signals
    print("\n🏆 Top 5 Signals:")
    print("-" * 40)
    for i, signal in enumerate(rankings['top_n_signals'][:5], 1):
        print(f"{i}. {signal.signal_id}")
        print(f"   Score: {signal.composite_score:.3f}")
        print(f"   Confidence: {signal.confidence_score:.3f}")
        print(f"   Tier: {signal.tier}")
        print(f"   Strategy: {signal.signal_data.get('strategy_name', 'Unknown')}")
        print()
    
    # Generate comprehensive report
    print("Generating comprehensive report...")
    report = scoring_system.generate_comprehensive_report()
    
    # Print key metrics
    print("\n📊 System Performance:")
    print("-" * 30)
    perf = report['system_performance']
    print(f"Total Signals: {report['executive_summary']['total_signals_processed']}")
    print(f"Active Signals: {report['executive_summary']['active_signals']}")
    print(f"Average Score: {perf.get('avg_score', 0):.3f}")
    print(f"Success Rate: {perf.get('success_rate', 0):.1%}")
    print(f"Avg Processing Time: {perf.get('avg_processing_time_ms', 0):.1f}ms")
    
    print("\n📈 Market Analysis:")
    print("-" * 20)
    market = report['market_regime_analysis']
    print(f"Dominant Regime: {market.get('dominant_regime', 'Unknown')}")
    
    if market.get('regime_performance'):
        print("Regime Performance:")
        for regime, perf in market['regime_performance'].items():
            print(f"  {regime}: {perf['avg_score']:.3f} (n={perf['count']})")
    
    print("\n💡 Recommendations:")
    print("-" * 18)
    for rec in report['recommendations']:
        print(f"• {rec}")
    
    print(f"\n✅ Demo completed successfully!")
    print(f"Processed {len(processed_signals)} signals")
    
    return scoring_system, report


if __name__ == "__main__":
    # Run the demo
    scoring_system, report = run_demo()