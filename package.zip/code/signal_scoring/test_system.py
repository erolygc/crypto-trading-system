#!/usr/bin/env python3
"""
Test script for Signal Scoring System
"""

import sys
import os
sys.path.append('/workspace/code')

# Test all components
def test_all_components():
    print("🧪 Testing Signal Scoring System Components")
    print("=" * 50)
    
    try:
        # Test imports
        print("1. Testing imports...")
        from signal_scoring import (
            MultiFactorScorer, MarketRegimeDetector, ConfidenceCalculator,
            EnsembleScorer, PerformanceAttribution, SignalRanking,
            AccountManagerInterface, SignalScoringSystem
        )
        print("   ✅ All imports successful")
        
        # Test MultiFactorScorer
        print("\n2. Testing MultiFactorScorer...")
        import numpy as np
        scorer = MultiFactorScorer()
        
        signal_data = {
            'signal_id': 'TEST_001',
            'strategy_name': 'TestStrategy',
            'returns': np.random.normal(0.001, 0.02, 50),
            'positions': np.random.choice([-1, 0, 1], 50),
            'timestamps': np.arange(50)
        }
        
        metrics = scorer.calculate_metrics(signal_data)
        composite_score = scorer.calculate_composite_score(metrics)
        print(f"   ✅ MultiFactorScorer: Score = {composite_score:.3f}")
        
        # Test MarketRegimeDetector
        print("\n3. Testing MarketRegimeDetector...")
        import pandas as pd
        detector = MarketRegimeDetector()
        
        # Generate test price data
        prices = 100 * np.cumprod(1 + np.random.normal(0.001, 0.02, 50))
        price_data = pd.DataFrame({
            'close': prices,
            'volume': np.random.randint(1000, 10000, 50)
        })
        
        regime_metrics = detector.detect_regime(price_data)
        print(f"   ✅ MarketRegimeDetector: Regime = {regime_metrics.regime.value}")
        
        # Test ConfidenceCalculator
        print("\n4. Testing ConfidenceCalculator...")
        calculator = ConfidenceCalculator()
        confidence_metrics = calculator.calculate_signal_confidence(signal_data)
        print(f"   ✅ ConfidenceCalculator: Confidence = {confidence_metrics.mean_score:.3f}")
        
        # Test EnsembleScorer
        print("\n5. Testing EnsembleScorer...")
        ensemble = EnsembleScorer()
        ensemble.add_component("test_scorer", lambda x, y: 0.5, 0.3, 0.7)
        ensemble_result = ensemble.calculate_ensemble_score(signal_data)
        print(f"   ✅ EnsembleScorer: Score = {ensemble_result.final_score:.3f}")
        
        # Test SignalRanking
        print("\n6. Testing SignalRanking...")
        ranking = SignalRanking()
        signal_rank = ranking.add_signal(signal_data)
        top_signals = ranking.get_top_signals(n=5)
        print(f"   ✅ SignalRanking: {len(top_signals)} signals ranked")
        
        # Test AccountManagerInterface
        print("\n7. Testing AccountManagerInterface...")
        interface = AccountManagerInterface()
        print(f"   ✅ AccountManagerInterface: Initialized successfully")
        
        # Test complete system
        print("\n8. Testing complete SignalScoringSystem...")
        system = SignalScoringSystem()
        result = system.process_signal(signal_data)
        print(f"   ✅ SignalScoringSystem: Final score = {result['final_score']:.3f}")
        print(f"   ✅ SignalScoringSystem: Tier = {result['tier']}")
        
        print("\n🎉 All tests passed successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_batch_processing():
    print("\n📊 Testing Batch Processing")
    print("-" * 30)
    
    try:
        from signal_scoring import SignalScoringSystem
        import numpy as np
        
        # Generate test signals
        signals = []
        for i in range(10):
            signal = {
                'signal_id': f'BATCH_TEST_{i:03d}',
                'strategy_name': f'Strategy_{i%3}',
                'asset': f'ASSET_{i%5}',
                'returns': np.random.normal(0.001, 0.02, 30),
                'positions': np.random.choice([-1, 0, 1], 30)
            }
            signals.append(signal)
        
        # Process batch
        system = SignalScoringSystem()
        results = system.batch_process_signals(signals)
        
        print(f"Processed {len(results)} signals")
        
        # Check results
        successful = [r for r in results if 'error' not in r]
        print(f"Successful: {len(successful)}/{len(results)}")
        
        if successful:
            avg_score = np.mean([r['final_score'] for r in successful])
            print(f"Average score: {avg_score:.3f}")
        
        print("✅ Batch processing test completed")
        return True
        
    except Exception as e:
        print(f"❌ Batch processing test failed: {e}")
        return False

def test_performance():
    print("\n⚡ Testing Performance")
    print("-" * 20)
    
    try:
        import time
        from signal_scoring import SignalScoringSystem
        import numpy as np
        
        # Generate larger test dataset
        signals = []
        for i in range(50):
            signal = {
                'signal_id': f'PERF_TEST_{i:03d}',
                'strategy_name': f'Strategy_{i%3}',
                'asset': f'ASSET_{i%10}',
                'returns': np.random.normal(0.001, 0.02, 50),
                'positions': np.random.choice([-1, 0, 1], 50)
            }
            signals.append(signal)
        
        # Measure processing time
        system = SignalScoringSystem()
        
        start_time = time.time()
        results = system.batch_process_signals(signals)
        end_time = time.time()
        
        processing_time = end_time - start_time
        signals_per_second = len(signals) / processing_time
        
        print(f"Processing time: {processing_time:.2f} seconds")
        print(f"Signals per second: {signals_per_second:.1f}")
        print(f"Average time per signal: {processing_time/len(signals)*1000:.1f}ms")
        
        # Check if performance meets requirements (< 100ms per signal)
        avg_time_per_signal = processing_time / len(signals) * 1000
        if avg_time_per_signal < 100:
            print("✅ Performance requirement met (< 100ms per signal)")
        else:
            print(f"⚠️ Performance could be improved (avg: {avg_time_per_signal:.1f}ms)")
        
        return True
        
    except Exception as e:
        print(f"❌ Performance test failed: {e}")
        return False

def main():
    print("🚀 Signal Scoring System Test Suite")
    print("=" * 50)
    
    # Run all tests
    tests_passed = 0
    total_tests = 3
    
    if test_all_components():
        tests_passed += 1
    
    if test_batch_processing():
        tests_passed += 1
    
    if test_performance():
        tests_passed += 1
    
    # Summary
    print(f"\n📋 Test Summary")
    print("=" * 20)
    print(f"Tests passed: {tests_passed}/{total_tests}")
    
    if tests_passed == total_tests:
        print("🎉 All tests passed! System is ready to use.")
    else:
        print(f"⚠️ {total_tests - tests_passed} test(s) failed. Please check the issues.")
    
    return tests_passed == total_tests

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)