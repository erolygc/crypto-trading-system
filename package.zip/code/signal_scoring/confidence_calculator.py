"""
Confidence Interval ve Uncertainty Quantification Sistemi
=======================================================

Sinyal skorları için güven aralıkları hesaplayan ve belirsizlik ölçen sistem.
Bootstrap, Monte Carlo ve Bayesian yaklaşımlarını kullanır.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union
from dataclasses import dataclass
from scipy import stats
from scipy.stats import bootstrap
import warnings

warnings.filterwarnings('ignore')


@dataclass
class ConfidenceMetrics:
    """Güven metrikleri"""
    mean_score: float
    confidence_interval: Tuple[float, float]
    confidence_level: float
    prediction_interval: Tuple[float, float]
    uncertainty_score: float
    sample_size: int
    standard_error: float
    bootstrap_distribution: np.ndarray


@dataclass
class StatisticalTest:
    """İstatistiksel test sonuçları"""
    test_name: str
    statistic: float
    p_value: float
    significant: bool
    effect_size: float
    interpretation: str


class ConfidenceCalculator:
    """
    Sinyal güvenilirlik ve belirsizlik hesaplama sistemi
    
    Bootstrap, Monte Carlo sampling ve Bayesian metodları kullanarak
    sinyal skorlarının güven aralıklarını ve belirsizlik ölçümlerini hesaplar.
    """
    
    def __init__(self, 
                 confidence_level: float = 0.95,
                 bootstrap_samples: int = 1000,
                 monte_carlo_runs: int = 5000):
        """
        Initialize confidence calculator
        
        Args:
            confidence_level: Güven seviyesi (0.95 = 95%)
            bootstrap_samples: Bootstrap örnek sayısı
            monte_carlo_runs: Monte Carlo çalıştırma sayısı
        """
        self.confidence_level = confidence_level
        self.bootstrap_samples = bootstrap_samples
        self.monte_carlo_runs = monte_carlo_runs
        self.alpha = 1 - confidence_level
        
        # Minimum sample size for reliable statistics
        self.min_sample_size = 10
    
    def calculate_signal_confidence(self, 
                                  signal_data: Dict,
                                  score_history: Optional[List[float]] = None) -> ConfidenceMetrics:
        """
        Tek sinyal için güven metrikleri hesapla
        
        Args:
            signal_data: Sinyal verisi
            score_history: Geçmiş skorlar (varsa)
        
        Returns:
            ConfidenceMetrics: Hesaplanan güven metrikleri
        """
        returns = np.array(signal_data.get('returns', []))
        
        if len(returns) < self.min_sample_size:
            # Küçük sample için conservative yaklaşım
            return self._calculate_conservative_confidence(signal_data)
        
        # Ana skorları hesapla
        scores = self._calculate_individual_scores(returns)
        
        # Bootstrap güven aralığı hesapla
        confidence_interval = self._bootstrap_confidence_interval(scores)
        
        # Prediction interval hesapla
        prediction_interval = self._calculate_prediction_interval(returns)
        
        # Uncertainty score hesapla
        uncertainty_score = self._calculate_uncertainty_score(scores)
        
        # Bootstrap dağılımı hesapla
        bootstrap_dist = self._bootstrap_distribution(scores)
        
        return ConfidenceMetrics(
            mean_score=np.mean(scores),
            confidence_interval=confidence_interval,
            confidence_level=self.confidence_level,
            prediction_interval=prediction_interval,
            uncertainty_score=uncertainty_score,
            sample_size=len(returns),
            standard_error=np.std(scores) / np.sqrt(len(scores)),
            bootstrap_distribution=bootstrap_dist
        )
    
    def batch_confidence_analysis(self, signals_data: List[Dict]) -> Dict[str, ConfidenceMetrics]:
        """
        Toplu sinyal güven analizi
        
        Args:
            signals_data: Sinyal verileri listesi
        
        Returns:
            Dict[str, ConfidenceMetrics]: Sinyal ID -> Güven metrikleri
        """
        results = {}
        
        for signal_data in signals_data:
            signal_id = signal_data.get('signal_id', 'unknown')
            try:
                confidence_metrics = self.calculate_signal_confidence(signal_data)
                results[signal_id] = confidence_metrics
            except Exception as e:
                print(f"Error calculating confidence for {signal_id}: {e}")
                continue
        
        return results
    
    def _calculate_individual_scores(self, returns: np.ndarray) -> np.ndarray:
        """Tekil skorları hesapla"""
        # Çeşitli performance metrikleri
        scores = []
        
        # Sharpe ratio
        sharpe = self._calculate_sharpe(returns)
        scores.append(sharpe)
        
        # Win rate
        win_rate = np.sum(returns > 0) / len(returns)
        scores.append(win_rate)
        
        # Profit factor
        profit_factor = self._calculate_profit_factor(returns)
        scores.append(profit_factor)
        
        # Sortino ratio
        sortino = self._calculate_sortino(returns)
        scores.append(sortino)
        
        # Calmar ratio
        calmar = self._calculate_calmar_ratio(returns)
        scores.append(calmar)
        
        return np.array(scores)
    
    def _bootstrap_confidence_interval(self, scores: np.ndarray) -> Tuple[float, float]:
        """Bootstrap ile güven aralığı hesapla"""
        if len(scores) < 2:
            return (scores[0] if len(scores) > 0 else 0.0, scores[0] if len(scores) > 0 else 0.0)
        
        # Bootstrap sampling
        bootstrap_scores = []
        
        for _ in range(self.bootstrap_samples):
            # Resample with replacement
            sample_indices = np.random.choice(len(scores), size=len(scores), replace=True)
            bootstrap_sample = scores[sample_indices]
            bootstrap_scores.append(np.mean(bootstrap_sample))
        
        bootstrap_scores = np.array(bootstrap_scores)
        
        # Güven aralığını hesapla
        lower_percentile = (self.alpha / 2) * 100
        upper_percentile = (1 - self.alpha / 2) * 100
        
        confidence_interval = (
            np.percentile(bootstrap_scores, lower_percentile),
            np.percentile(bootstrap_scores, upper_percentile)
        )
        
        return confidence_interval
    
    def _calculate_prediction_interval(self, returns: np.ndarray) -> Tuple[float, float]:
        """Gelecek tahmin aralığı hesapla"""
        if len(returns) < 2:
            mean_return = np.mean(returns) if len(returns) > 0 else 0.0
            return (mean_return, mean_return)
        
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        
        # Student t-distribution kullan
        t_value = stats.t.ppf(1 - self.alpha/2, len(returns) - 1)
        
        # Prediction interval
        margin_error = t_value * std_return * np.sqrt(1 + 1/len(returns))
        
        prediction_interval = (
            mean_return - margin_error,
            mean_return + margin_error
        )
        
        return prediction_interval
    
    def _calculate_uncertainty_score(self, scores: np.ndarray) -> float:
        """Belirsizlik skoru hesapla"""
        if len(scores) < 2:
            return 1.0  # Maximum uncertainty for single observation
        
        # Coefficient of variation
        cv = np.std(scores) / (np.abs(np.mean(scores)) + 1e-8)
        
        # Sample size adjustment
        size_adjustment = 1 / np.sqrt(len(scores))
        
        # Uncertainty score (0 = certain, 1 = very uncertain)
        uncertainty = cv * size_adjustment
        
        return min(uncertainty, 1.0)
    
    def _bootstrap_distribution(self, scores: np.ndarray) -> np.ndarray:
        """Bootstrap dağılımı hesapla"""
        bootstrap_scores = []
        
        for _ in range(self.bootstrap_samples):
            sample_indices = np.random.choice(len(scores), size=len(scores), replace=True)
            bootstrap_sample = scores[sample_indices]
            bootstrap_scores.append(np.mean(bootstrap_sample))
        
        return np.array(bootstrap_scores)
    
    def _calculate_conservative_confidence(self, signal_data: Dict) -> ConfidenceMetrics:
        """Küçük sample için conservative güven hesaplama"""
        returns = np.array(signal_data.get('returns', []))
        
        if len(returns) == 0:
            return ConfidenceMetrics(
                mean_score=0.0,
                confidence_interval=(0.0, 0.0),
                confidence_level=self.confidence_level,
                prediction_interval=(0.0, 0.0),
                uncertainty_score=1.0,
                sample_size=0,
                standard_error=0.0,
                bootstrap_distribution=np.array([])
            )
        
        mean_return = np.mean(returns)
        
        # Conservative confidence interval (wide)
        std_return = np.std(returns) if len(returns) > 1 else abs(mean_return) + 0.01
        
        # Conservative t-value
        df = max(len(returns) - 1, 1)
        t_value = stats.t.ppf(1 - self.alpha/2, df)
        
        margin_error = t_value * std_return / np.sqrt(max(len(returns), 1))
        
        confidence_interval = (
            mean_return - margin_error,
            mean_return + margin_error
        )
        
        return ConfidenceMetrics(
            mean_score=mean_return,
            confidence_interval=confidence_interval,
            confidence_level=self.confidence_level,
            prediction_interval=confidence_interval,  # Same for small samples
            uncertainty_score=min(1.0, 1.0 / max(len(returns), 1)),
            sample_size=len(returns),
            standard_error=std_return / np.sqrt(max(len(returns), 1)),
            bootstrap_distribution=np.array([])
        )
    
    def monte_carlo_uncertainty(self, 
                               returns: np.ndarray,
                               n_simulations: Optional[int] = None) -> Dict[str, float]:
        """
        Monte Carlo ile belirsizlik analizi
        
        Args:
            returns: Geçmiş getiriler
            n_simulations: Simülasyon sayısı
        
        Returns:
            Dict[str, float]: Monte Carlo sonuçları
        """
        n_simulations = n_simulations or self.monte_carlo_runs
        
        if len(returns) < 2:
            return {'mean_return': 0.0, 'volatility': 0.0, 'sharpe_std': 0.0}
        
        # Historical statistics
        mean_return = np.mean(returns)
        volatility = np.std(returns)
        
        # Monte Carlo simulations
        simulated_returns = []
        
        for _ in range(n_simulations):
            # Random walk simulation
            random_returns = np.random.normal(mean_return, volatility, len(returns))
            simulated_returns.append(random_returns)
        
        simulated_returns = np.array(simulated_returns)
        
        # Calculate statistics
        simulation_means = np.mean(simulated_returns, axis=1)
        simulation_volatilities = np.std(simulated_returns, axis=1)
        
        return {
            'mean_return': np.mean(simulation_means),
            'volatility': np.mean(simulation_volatilities),
            'sharpe_std': np.std(simulation_means),
            'volatility_std': np.std(simulation_volatilities),
            'confidence_range': (
                np.percentile(simulation_means, self.alpha/2 * 100),
                np.percentile(simulation_means, (1 - self.alpha/2) * 100)
            )
        }
    
    def statistical_significance_test(self, 
                                    signal1_data: Dict, 
                                    signal2_data: Dict) -> StatisticalTest:
        """
        İki sinyal arasında istatistiksel anlamlılık testi
        
        Args:
            signal1_data: İlk sinyal verisi
            signal2_data: İkinci sinyal verisi
        
        Returns:
            StatisticalTest: Test sonucu
        """
        returns1 = np.array(signal1_data.get('returns', []))
        returns2 = np.array(signal2_data.get('returns', []))
        
        if len(returns1) < 2 or len(returns2) < 2:
            return StatisticalTest(
                test_name="Insufficient Data",
                statistic=0.0,
                p_value=1.0,
                significant=False,
                effect_size=0.0,
                interpretation="Yetersiz veri"
            )
        
        # Perform t-test
        statistic, p_value = stats.ttest_ind(returns1, returns2)
        
        # Calculate effect size (Cohen's d)
        pooled_std = np.sqrt((np.var(returns1) + np.var(returns2)) / 2)
        cohens_d = (np.mean(returns1) - np.mean(returns2)) / (pooled_std + 1e-8)
        
        # Interpretation
        if abs(cohens_d) < 0.2:
            effect_interpretation = "Küçük etki"
        elif abs(cohens_d) < 0.5:
            effect_interpretation = "Orta etki"
        elif abs(cohens_d) < 0.8:
            effect_interpretation = "Büyük etki"
        else:
            effect_interpretation = "Çok büyük etki"
        
        return StatisticalTest(
            test_name="Independent T-Test",
            statistic=statistic,
            p_value=p_value,
            significant=p_value < 0.05,
            effect_size=abs(cohens_d),
            interpretation=f"{effect_interpretation}, p-value: {p_value:.4f}"
        )
    
    def bayesian_probability_analysis(self, 
                                    signal_data: Dict,
                                    prior_alpha: float = 1.0,
                                    prior_beta: float = 1.0) -> Dict[str, float]:
        """
        Bayesian probability analysis
        
        Args:
            signal_data: Sinyal verisi
            prior_alpha: Beta dağılımı önseli alpha
            prior_beta: Beta dağılımı önseli beta
        
        Returns:
            Dict[str, float]: Bayesian analiz sonuçları
        """
        returns = np.array(signal_data.get('returns', []))
        
        if len(returns) == 0:
            return {
                'posterior_mean': 0.0,
                'posterior_variance': 0.0,
                'prob_positive_return': 0.5,
                'credible_interval': (0.0, 0.0)
            }
        
        # Binary outcomes (positive/negative returns)
        successes = np.sum(returns > 0)
        failures = len(returns) - successes
        
        # Beta-Binomial posterior
        posterior_alpha = prior_alpha + successes
        posterior_beta = prior_beta + failures
        
        # Posterior statistics
        posterior_mean = posterior_alpha / (posterior_alpha + posterior_beta)
        posterior_variance = (posterior_alpha * posterior_beta) / \
                           ((posterior_alpha + posterior_beta)**2 * (posterior_alpha + posterior_beta + 1))
        
        # Credible interval
        credible_interval = (
            stats.beta.ppf(self.alpha/2, posterior_alpha, posterior_beta),
            stats.beta.ppf(1 - self.alpha/2, posterior_alpha, posterior_beta)
        )
        
        return {
            'posterior_mean': posterior_mean,
            'posterior_variance': posterior_variance,
            'prob_positive_return': posterior_mean,
            'credible_interval': credible_interval,
            'successes': successes,
            'failures': failures,
            'total_observations': len(returns)
        }
    
    def risk_adjusted_confidence(self, 
                               confidence_metrics: ConfidenceMetrics,
                               risk_tolerance: float = 0.5) -> Dict[str, float]:
        """
        Risk toleransına göre ayarlı güven
        
        Args:
            confidence_metrics: Temel güven metrikleri
            risk_tolerance: Risk toleransı (0-1)
        
        Returns:
            Dict[str, float]: Risk ayarlı güven metrikleri
        """
        # Risk adjustment factors
        uncertainty_penalty = confidence_metrics.uncertainty_score * (1 - risk_tolerance)
        sample_size_bonus = min(confidence_metrics.sample_size / 100, 0.2)  # Max 20% bonus
        
        # Adjusted confidence
        adjusted_confidence = confidence_metrics.confidence_level - uncertainty_penalty + sample_size_bonus
        
        # Adjusted interval width
        base_width = confidence_metrics.confidence_interval[1] - confidence_metrics.confidence_interval[0]
        adjusted_width = base_width * (1 + uncertainty_penalty)
        
        # Risk-adjusted score
        base_score = confidence_metrics.mean_score
        risk_adjusted_score = base_score * (1 - uncertainty_penalty) * (1 + sample_size_bonus)
        
        return {
            'risk_adjusted_confidence': min(adjusted_confidence, 1.0),
            'risk_adjusted_score': risk_adjusted_score,
            'adjusted_interval_width': adjusted_width,
            'uncertainty_penalty': uncertainty_penalty,
            'sample_size_bonus': sample_size_bonus,
            'risk_tolerance_factor': risk_tolerance
        }
    
    def compare_signal_confidence(self, 
                                confidence_dict: Dict[str, ConfidenceMetrics]) -> List[Tuple[str, float, str]]:
        """
        Sinyal güvenlerini karşılaştır ve sırala
        
        Args:
            confidence_dict: Sinyal ID -> ConfidenceMetrics mapping
        
        Returns:
            List[Tuple[str, float, str]]: (signal_id, adjusted_confidence, interpretation)
        """
        rankings = []
        
        for signal_id, metrics in confidence_dict.items():
            # Risk-adjusted confidence hesapla
            risk_adjusted = self.risk_adjusted_confidence(metrics)
            
            confidence_score = risk_adjusted['risk_adjusted_confidence']
            
            # Interpretation
            if confidence_score > 0.8:
                interpretation = "Yüksek Güven"
            elif confidence_score > 0.6:
                interpretation = "Orta Güven"
            elif confidence_score > 0.4:
                interpretation = "Düşük Güven"
            else:
                interpretation = "Çok Düşük Güven"
            
            rankings.append((signal_id, confidence_score, interpretation))
        
        # Güvene göre sırala
        rankings.sort(key=lambda x: x[1], reverse=True)
        
        return rankings
    
    # Helper methods for score calculations
    def _calculate_sharpe(self, returns: np.ndarray, risk_free_rate: float = 0.02) -> float:
        """Sharpe ratio hesapla"""
        if len(returns) < 2 or np.std(returns) == 0:
            return 0.0
        
        excess_returns = returns - (risk_free_rate / 252)
        return np.mean(excess_returns) / np.std(returns) * np.sqrt(252)
    
    def _calculate_profit_factor(self, returns: np.ndarray) -> float:
        """Profit factor hesapla"""
        gross_profit = np.sum(returns[returns > 0])
        gross_loss = abs(np.sum(returns[returns < 0]))
        
        if gross_loss == 0:
            return float('inf') if gross_profit > 0 else 0.0
        
        return gross_profit / gross_loss
    
    def _calculate_sortino(self, returns: np.ndarray, risk_free_rate: float = 0.02) -> float:
        """Sortino ratio hesapla"""
        if len(returns) < 2:
            return 0.0
        
        excess_returns = returns - (risk_free_rate / 252)
        downside_deviation = np.std(returns[returns < 0])
        
        if downside_deviation == 0:
            return 0.0
        
        return np.mean(excess_returns) / downside_deviation * np.sqrt(252)
    
    def _calculate_calmar_ratio(self, returns: np.ndarray) -> float:
        """Calmar ratio hesapla"""
        if len(returns) == 0:
            return 0.0
        
        # Convert to pandas Series for expanding operations
        cumulative = pd.Series(returns).add(1).cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        max_dd = abs(drawdown.min())
        
        annual_return = np.prod(1 + returns) ** (252 / len(returns)) - 1
        
        if max_dd == 0:
            return 0.0
        
        return annual_return / max_dd