"""
Ensemble Scoring Sistemi
========================

Farklı skorlama algoritmalarını ağırlıklı olarak birleştiren ensemble sistem.
Dynamic weighting, performance-based rebalancing ve consensus mechanisms içerir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Callable
from dataclasses import dataclass
from enum import Enum
from abc import ABC, abstractmethod
import warnings

warnings.filterwarnings('ignore')


class WeightingMethod(Enum):
    """Ağırlıklandırma yöntemleri"""
    EQUAL_WEIGHT = "equal_weight"
    PERFORMANCE_WEIGHT = "performance_weight"
    CONFIDENCE_WEIGHT = "confidence_weight"
    DYNAMIC_ADAPTIVE = "dynamic_adaptive"
    RISK_PARITY = "risk_parity"
    MARKET_REGIME = "market_regime"
    VOLATILITY_ADJUSTED = "volatility_adjusted"


@dataclass
class ScorerComponent:
    """Ensemble skorlayıcı bileşeni"""
    name: str
    scorer_function: Callable
    weight: float
    confidence: float
    performance_history: List[float]
    last_update: pd.Timestamp
    
    def __post_init__(self):
        if not self.performance_history:
            self.performance_history = []
        if pd.isna(self.last_update):
            self.last_update = pd.Timestamp.now()


@dataclass
class EnsembleResult:
    """Ensemble skorlama sonucu"""
    final_score: float
    component_scores: Dict[str, float]
    component_weights: Dict[str, float]
    consensus_metrics: Dict[str, float]
    confidence_level: float
    disagreement_score: float
    performance_attribution: Dict[str, float]


class BaseEnsembleStrategy(ABC):
    """Ensemble stratejiler için base class"""
    
    @abstractmethod
    def calculate_weights(self, components: List[ScorerComponent], market_data: Optional[Dict] = None) -> Dict[str, float]:
        """Ağırlıkları hesapla"""
        pass


class EqualWeightStrategy(BaseEnsembleStrategy):
    """Eşit ağırlık stratejisi"""
    
    def calculate_weights(self, components: List[ScorerComponent], market_data: Optional[Dict] = None) -> Dict[str, float]:
        """Eşit ağırlıklar hesapla"""
        n_components = len(components)
        if n_components == 0:
            return {}
        
        equal_weight = 1.0 / n_components
        return {comp.name: equal_weight for comp in components}


class PerformanceWeightStrategy(BaseEnsembleStrategy):
    """Performans bazlı ağırlıklandırma"""
    
    def __init__(self, lookback_period: int = 30, decay_factor: float = 0.9):
        self.lookback_period = lookback_period
        self.decay_factor = decay_factor
    
    def calculate_weights(self, components: List[ScorerComponent], market_data: Optional[Dict] = None) -> Dict[str, float]:
        """Performans bazlı ağırlıklar hesapla"""
        if not components:
            return {}
        
        # Recent performance scores (weighted average)
        weights = {}
        total_weight = 0.0
        
        for component in components:
            if len(component.performance_history) == 0:
                performance_score = 0.5  # Neutral default
            else:
                # Recent performance with decay
                recent_scores = component.performance_history[-self.lookback_period:]
                weights_list = [self.decay_factor ** (len(recent_scores) - 1 - i) 
                              for i in range(len(recent_scores))]
                
                performance_score = np.average(recent_scores, weights=weights_list)
            
            weights[component.name] = max(performance_score, 0.01)  # Minimum weight
            total_weight += weights[component.name]
        
        # Normalize weights
        if total_weight > 0:
            weights = {k: v/total_weight for k, v in weights.items()}
        else:
            # Fallback to equal weights
            equal_weight = 1.0 / len(components)
            weights = {comp.name: equal_weight for comp in components}
        
        return weights


class ConfidenceWeightStrategy(BaseEnsembleStrategy):
    """Güven seviyesi bazlı ağırlıklandırma"""
    
    def calculate_weights(self, components: List[ScorerComponent], market_data: Optional[Dict] = None) -> Dict[str, float]:
        """Güven bazlı ağırlıklar hesapla"""
        if not components:
            return {}
        
        # Use component confidence scores
        weights = {}
        total_weight = 0.0
        
        for component in components:
            confidence_weight = component.confidence
            weights[component.name] = max(confidence_weight, 0.01)
            total_weight += weights[component.name]
        
        # Normalize weights
        if total_weight > 0:
            weights = {k: v/total_weight for k, v in weights.items()}
        else:
            # Fallback to equal weights
            equal_weight = 1.0 / len(components)
            weights = {comp.name: equal_weight for comp in components}
        
        return weights


class DynamicAdaptiveStrategy(BaseEnsembleStrategy):
    """Dinamik adaptif ağırlıklandırma"""
    
    def __init__(self, adaptation_rate: float = 0.1, min_weight: float = 0.05):
        self.adaptation_rate = adaptation_rate
        self.min_weight = min_weight
    
    def calculate_weights(self, components: List[ScorerComponent], market_data: Optional[Dict] = None) -> Dict[str, float]:
        """Adaptif ağırlıklar hesapla"""
        if not components:
            return {}
        
        # Base weights from current performance
        base_weights = PerformanceWeightStrategy().calculate_weights(components, market_data)
        
        # Adjust based on recent performance trends
        adjusted_weights = {}
        total_weight = 0.0
        
        for component in components:
            current_weight = base_weights[component.name]
            
            # Trend adjustment
            trend_factor = self._calculate_trend_factor(component)
            
            # Market regime adjustment (if available)
            regime_factor = 1.0
            if market_data and 'market_regime' in market_data:
                regime_factor = self._calculate_regime_factor(component, market_data['market_regime'])
            
            # Apply adjustments
            adjusted_weight = current_weight * (1 + self.adaptation_rate * trend_factor) * regime_factor
            adjusted_weights[component.name] = max(adjusted_weight, self.min_weight)
            total_weight += adjusted_weights[component.name]
        
        # Re-normalize
        adjusted_weights = {k: v/total_weight for k, v in adjusted_weights.items()}
        
        return adjusted_weights
    
    def _calculate_trend_factor(self, component: ScorerComponent) -> float:
        """Performans trend faktörü hesapla"""
        if len(component.performance_history) < 3:
            return 0.0
        
        # Simple linear trend
        recent = component.performance_history[-10:]  # Last 10 observations
        x = np.arange(len(recent))
        slope, _ = np.polyfit(x, recent, 1)
        
        # Normalize slope to [-1, 1]
        return np.tanh(slope * 10)
    
    def _calculate_regime_factor(self, component: ScorerComponent, market_regime: str) -> float:
        """Market rejim faktörü hesapla"""
        # Simple regime-based adjustments
        regime_adjustments = {
            'strong_uptrend': {'momentum': 1.2, 'trend_following': 1.3, 'mean_reversion': 0.8},
            'strong_downtrend': {'momentum': 1.2, 'trend_following': 1.3, 'mean_reversion': 0.8},
            'sideways': {'mean_reversion': 1.3, 'momentum': 0.8, 'breakout': 0.9},
            'high_volatility': {'risk_management': 1.4, 'momentum': 0.9},
            'low_volatility': {'breakout': 1.2, 'trend_following': 1.1}
        }
        
        component_type = self._infer_component_type(component.name)
        
        if market_regime in regime_adjustments and component_type in regime_adjustments[market_regime]:
            return regime_adjustments[market_regime][component_type]
        
        return 1.0
    
    def _infer_component_type(self, component_name: str) -> str:
        """Component tipini infer et"""
        name_lower = component_name.lower()
        
        if 'momentum' in name_lower:
            return 'momentum'
        elif 'trend' in name_lower:
            return 'trend_following'
        elif 'mean_reversion' in name_lower or 'reversion' in name_lower:
            return 'mean_reversion'
        elif 'breakout' in name_lower:
            return 'breakout'
        elif 'risk' in name_lower or 'risk_management' in name_lower:
            return 'risk_management'
        else:
            return 'momentum'  # Default


class EnsembleScorer:
    """
    Ensemble signal scoring system
    
    Çoklu skorlayıcıları birleştirerek optimal sinyal skorlaması yapar.
    Dynamic weighting, performance tracking ve consensus mechanisms içerir.
    """
    
    def __init__(self, 
                 weighting_method: WeightingMethod = WeightingMethod.DYNAMIC_ADAPTIVE,
                 rebalance_frequency: str = 'daily',
                 min_component_weight: float = 0.05):
        """
        Initialize ensemble scorer
        
        Args:
            weighting_method: Ağırlıklandırma yöntemi
            rebalance_frequency: Yeniden ağırlıklandırma sıklığı
            min_component_weight: Minimum component ağırlığı
        """
        self.weighting_method = weighting_method
        self.rebalance_frequency = rebalance_frequency
        self.min_component_weight = min_component_weight
        
        self.components: List[ScorerComponent] = []
        self.current_weights: Dict[str, float] = {}
        self.performance_tracker = {}
        self.last_rebalance = pd.Timestamp.now()
        
        # Strategy mapping
        self.strategies = {
            WeightingMethod.EQUAL_WEIGHT: EqualWeightStrategy(),
            WeightingMethod.PERFORMANCE_WEIGHT: PerformanceWeightStrategy(),
            WeightingMethod.CONFIDENCE_WEIGHT: ConfidenceWeightStrategy(),
            WeightingMethod.DYNAMIC_ADAPTIVE: DynamicAdaptiveStrategy(),
        }
    
    def add_component(self, 
                     name: str,
                     scorer_function: Callable,
                     initial_weight: float = 0.2,
                     initial_confidence: float = 0.5):
        """
        Ensemble'a yeni component ekle
        
        Args:
            name: Component adı
            scorer_function: Skorlama fonksiyonu
            initial_weight: Başlangıç ağırlığı
            initial_confidence: Başlangıç güven seviyesi
        """
        component = ScorerComponent(
            name=name,
            scorer_function=scorer_function,
            weight=initial_weight,
            confidence=initial_confidence,
            performance_history=[],
            last_update=pd.Timestamp.now()
        )
        
        self.components.append(component)
        self._rebalance_weights()
    
    def remove_component(self, name: str):
        """Ensemble'dan component çıkar"""
        self.components = [comp for comp in self.components if comp.name != name]
        self._rebalance_weights()
    
    def update_component_performance(self, name: str, performance_score: float):
        """Component performansını güncelle"""
        for component in self.components:
            if component.name == name:
                component.performance_history.append(performance_score)
                component.last_update = pd.Timestamp.now()
                
                # Limit history size
                if len(component.performance_history) > 100:
                    component.performance_history.pop(0)
                
                break
        
        # Check if rebalancing is needed
        if self._should_rebalance():
            self._rebalance_weights()
    
    def calculate_ensemble_score(self, 
                               signal_data: Dict,
                               market_data: Optional[Dict] = None) -> EnsembleResult:
        """
        Ensemble skorlaması hesapla
        
        Args:
            signal_data: Sinyal verisi
            market_data: Market verisi (rejim, volatilite vb.)
        
        Returns:
            EnsembleResult: Ensemble skorlama sonucu
        """
        if not self.components:
            raise ValueError("No components in ensemble")
        
        # Calculate individual component scores
        component_scores = {}
        for component in self.components:
            try:
                score = component.scorer_function(signal_data, market_data)
                component_scores[component.name] = score
            except Exception as e:
                print(f"Error in component {component.name}: {e}")
                component_scores[component.name] = 0.0
        
        # Get current weights
        if not self.current_weights or self._should_rebalance():
            self._rebalance_weights(market_data)
        
        # Calculate weighted final score
        final_score = sum(component_scores[name] * self.current_weights.get(name, 0) 
                         for name in component_scores.keys())
        
        # Calculate consensus metrics
        consensus_metrics = self._calculate_consensus_metrics(component_scores)
        
        # Calculate disagreement score
        disagreement_score = self._calculate_disagreement(component_scores)
        
        # Performance attribution
        attribution = self._calculate_performance_attribution(component_scores)
        
        # Update component performances
        self._update_component_performances(component_scores)
        
        return EnsembleResult(
            final_score=final_score,
            component_scores=component_scores,
            component_weights=self.current_weights.copy(),
            consensus_metrics=consensus_metrics,
            confidence_level=self._calculate_confidence_level(component_scores, disagreement_score),
            disagreement_score=disagreement_score,
            performance_attribution=attribution
        )
    
    def _rebalance_weights(self, market_data: Optional[Dict] = None):
        """Ağırlıkları yeniden dengele"""
        strategy = self.strategies.get(self.weighting_method, EqualWeightStrategy())
        
        try:
            self.current_weights = strategy.calculate_weights(self.components, market_data)
            
            # Apply minimum weight constraint
            total_weight = sum(self.current_weights.values())
            for name in self.current_weights:
                if self.current_weights[name] < self.min_component_weight:
                    self.current_weights[name] = self.min_component_weight
            
            # Re-normalize
            total_weight = sum(self.current_weights.values())
            if total_weight > 0:
                self.current_weights = {k: v/total_weight for k, v in self.current_weights.items()}
            
            self.last_rebalance = pd.Timestamp.now()
            
        except Exception as e:
            print(f"Error in weight rebalancing: {e}")
            # Fallback to equal weights
            self.current_weights = EqualWeightStrategy().calculate_weights(self.components, market_data)
    
    def _should_rebalance(self) -> bool:
        """Rebalancing gerekli mi kontrol et"""
        # Time-based rebalancing
        time_since_rebalance = pd.Timestamp.now() - self.last_rebalance
        
        rebalance_intervals = {
            'daily': pd.Timedelta(days=1),
            'weekly': pd.Timedelta(weeks=1),
            'monthly': pd.Timedelta(days=30)
        }
        
        return time_since_rebalance >= rebalance_intervals.get(self.rebalance_frequency, pd.Timedelta(days=1))
    
    def _calculate_consensus_metrics(self, component_scores: Dict[str, float]) -> Dict[str, float]:
        """Consensus metriklerini hesapla"""
        if not component_scores:
            return {}
        
        scores = list(component_scores.values())
        
        return {
            'mean_score': np.mean(scores),
            'median_score': np.median(scores),
            'std_score': np.std(scores),
            'min_score': np.min(scores),
            'max_score': np.max(scores),
            'score_range': np.max(scores) - np.min(scores),
            'agreement_level': 1.0 - (np.std(scores) / (np.mean(scores) + 1e-8))
        }
    
    def _calculate_disagreement(self, component_scores: Dict[str, float]) -> float:
        """Component'lar arası anlaşmazlık skorunu hesapla"""
        if len(component_scores) < 2:
            return 0.0
        
        scores = list(component_scores.values())
        
        # Standard deviation as disagreement measure
        disagreement = np.std(scores) / (np.mean(np.abs(scores)) + 1e-8)
        
        return min(disagreement, 1.0)
    
    def _calculate_confidence_level(self, component_scores: Dict[str, float], disagreement: float) -> float:
        """Ensemble güven seviyesini hesapla"""
        # Base confidence from number of components
        base_confidence = min(len(component_scores) / 10, 1.0)
        
        # Adjust for disagreement (high disagreement = low confidence)
        disagreement_penalty = disagreement * 0.5
        
        # Adjust for performance consistency
        scores = list(component_scores.values())
        performance_consistency = 1.0 - (np.std(scores) / (np.mean(np.abs(scores)) + 1e-8))
        
        confidence = base_confidence * (1 - disagreement_penalty) * performance_consistency
        
        return max(min(confidence, 1.0), 0.0)
    
    def _calculate_performance_attribution(self, component_scores: Dict[str, float]) -> Dict[str, float]:
        """Performance attribution hesapla"""
        attribution = {}
        total_score = sum(component_scores.values())
        
        if total_score == 0:
            return {name: 0.0 for name in component_scores.keys()}
        
        for name, score in component_scores.items():
            weight = self.current_weights.get(name, 0)
            contribution = score * weight
            attribution[name] = contribution / total_score if total_score != 0 else 0
        
        return attribution
    
    def _update_component_performances(self, component_scores: Dict[str, float]):
        """Component performanslarını güncelle"""
        for name, score in component_scores.items():
            self.update_component_performance(name, score)
    
    def get_ensemble_summary(self) -> Dict:
        """Ensemble özet bilgisini getir"""
        if not self.components:
            return {"status": "No components"}
        
        return {
            "method": self.weighting_method.value,
            "num_components": len(self.components),
            "current_weights": self.current_weights.copy(),
            "last_rebalance": self.last_rebalance.isoformat(),
            "rebalance_frequency": self.rebalance_frequency,
            "component_details": [
                {
                    "name": comp.name,
                    "weight": comp.weight,
                    "confidence": comp.confidence,
                    "performance_avg": np.mean(comp.performance_history) if comp.performance_history else 0.0,
                    "last_update": comp.last_update.isoformat()
                }
                for comp in self.components
            ]
        }
    
    def set_weighting_method(self, method: WeightingMethod):
        """Ağırlıklandırma yöntemini değiştir"""
        self.weighting_method = method
        self._rebalance_weights()
    
    def optimize_weights(self, 
                        historical_data: List[Dict],
                        objective: str = 'max_sharpe') -> Dict[str, float]:
        """
        Geçmiş verilere dayalı olarak optimal ağırlıkları bul
        
        Args:
            historical_data: Geçmiş sinyal verileri
            objective: Optimizasyon hedefi ('max_sharpe', 'min_volatility', 'max_return')
        
        Returns:
            Dict[str, float]: Optimal ağırlıklar
        """
        if len(historical_data) < 10:
            print("Insufficient historical data for optimization")
            return self.current_weights
        
        # Calculate component performance on historical data
        component_performances = {comp.name: [] for comp in self.components}
        
        for signal_data in historical_data:
            for component in self.components:
                try:
                    score = component.scorer_function(signal_data)
                    component_performances[component.name].append(score)
                except:
                    component_performances[component.name].append(0.0)
        
        # Simple optimization (could be enhanced with more sophisticated methods)
        optimal_weights = {}
        
        for name, scores in component_performances.items():
            if scores:
                # Use recent performance for optimization
                recent_scores = scores[-min(30, len(scores)):]
                performance_score = np.mean(recent_scores)
                optimal_weights[name] = max(performance_score, 0.01)
            else:
                optimal_weights[name] = 0.1
        
        # Normalize weights
        total_weight = sum(optimal_weights.values())
        if total_weight > 0:
            optimal_weights = {k: v/total_weight for k, v in optimal_weights.items()}
        
        self.current_weights = optimal_weights
        
        return optimal_weights
    
    def cross_validate_ensemble(self, 
                              validation_data: List[Dict],
                              n_folds: int = 5) -> Dict[str, float]:
        """
        Ensemble'ı cross-validation ile değerlendir
        
        Args:
            validation_data: Validation verileri
            n_folds: CV fold sayısı
        
        Returns:
            Dict[str, float]: CV sonuçları
        """
        if len(validation_data) < n_folds:
            return {"error": "Insufficient data for cross-validation"}
        
        # Simple time series split
        fold_size = len(validation_data) // n_folds
        cv_scores = []
        
        for i in range(n_folds):
            start_idx = i * fold_size
            end_idx = start_idx + fold_size if i < n_folds - 1 else len(validation_data)
            
            fold_data = validation_data[start_idx:end_idx]
            fold_scores = []
            
            for signal_data in fold_data:
                try:
                    result = self.calculate_ensemble_score(signal_data)
                    fold_scores.append(result.final_score)
                except:
                    fold_scores.append(0.0)
            
            cv_scores.append(np.mean(fold_scores) if fold_scores else 0.0)
        
        return {
            "cv_mean": np.mean(cv_scores),
            "cv_std": np.std(cv_scores),
            "cv_scores": cv_scores,
            "fold_size": fold_size
        }