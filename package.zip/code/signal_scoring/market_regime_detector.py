"""
Market Regime Detection Sistemi
==============================

Market rejimini (trend vs range) tespit eden ve buna göre sinyal skorlamasını 
ayarlayan akıllı sistem.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union
from dataclasses import dataclass
from enum import Enum
import warnings

warnings.filterwarnings('ignore')


class MarketRegime(Enum):
    """Market rejim tipleri"""
    STRONG_UPTREND = "strong_uptrend"
    WEAK_UPTREND = "weak_uptrend"
    SIDEWAYS = "sideways"
    WEAK_DOWNTREND = "weak_downtrend"
    STRONG_DOWNTREND = "strong_downtrend"
    HIGH_VOLATILITY = "high_volatility"
    LOW_VOLATILITY = "low_volatility"


@dataclass
class RegimeMetrics:
    """Rejim tespit metrikleri"""
    regime: MarketRegime
    confidence: float
    trend_strength: float
    volatility_level: float
    momentum_score: float
    support_resistance: Dict[str, float]
    regime_duration: int  # Gün cinsinden


@dataclass
class RegimeAdjustedScoring:
    """Rejim ayarlı skorlama parametreleri"""
    base_weights: Dict[str, float]
    regime_multipliers: Dict[str, float]
    volatility_adjustment: float
    trend_sensitivity: float


class MarketRegimeDetector:
    """
    Market regime tespit ve skorlama ayarlama sistemi
    
    Trend gücü, volatilite ve momentum'a dayalı olarak market rejimini tespit eder.
    Farklı rejimler için farklı skorlama ağırlıkları uygular.
    """
    
    def __init__(self, 
                 lookback_period: int = 50,
                 trend_threshold: float = 0.02,
                 volatility_threshold: float = 0.025):
        """
        Initialize market regime detector
        
        Args:
            lookback_period: Analiz için geriye bakma periyodu
            trend_threshold: Trend tespiti için eşik değeri
            volatility_threshold: Volatilite sınıflandırması için eşik
        """
        self.lookback_period = lookback_period
        self.trend_threshold = trend_threshold
        self.volatility_threshold = volatility_threshold
        
        # Rejim ayarlı skorlama parametreleri
        self.regime_scoring = {
            MarketRegime.STRONG_UPTREND: RegimeAdjustedScoring(
                base_weights={'trend_indicators': 0.4, 'momentum': 0.3, 'volume': 0.3},
                regime_multipliers={'bullish_signals': 1.2, 'bearish_signals': 0.8},
                volatility_adjustment=1.1,
                trend_sensitivity=0.8
            ),
            MarketRegime.STRONG_DOWNTREND: RegimeAdjustedScoring(
                base_weights={'trend_indicators': 0.4, 'momentum': 0.3, 'volume': 0.3},
                regime_multipliers={'bearish_signals': 1.2, 'bullish_signals': 0.8},
                volatility_adjustment=0.9,
                trend_sensitivity=0.8
            ),
            MarketRegime.SIDEWAYS: RegimeAdjustedScoring(
                base_weights={'mean_reversion': 0.4, 'support_resistance': 0.35, 'momentum': 0.25},
                regime_multipliers={'oversold_signals': 1.1, 'overbought_signals': 1.1},
                volatility_adjustment=0.8,
                trend_sensitivity=0.2
            ),
            MarketRegime.HIGH_VOLATILITY: RegimeAdjustedScoring(
                base_weights={'risk_management': 0.5, 'position_sizing': 0.3, 'momentum': 0.2},
                regime_multipliers={'conservative_signals': 1.3, 'aggressive_signals': 0.7},
                volatility_adjustment=0.7,
                trend_sensitivity=0.5
            ),
            MarketRegime.LOW_VOLATILITY: RegimeAdjustedScoring(
                base_weights={'trend_following': 0.4, 'momentum': 0.35, 'breakout': 0.25},
                regime_multipliers={'breakout_signals': 1.2, 'ranging_signals': 0.9},
                volatility_adjustment=1.2,
                trend_sensitivity=0.7
            )
        }
    
    def detect_regime(self, price_data: pd.DataFrame) -> RegimeMetrics:
        """
        Market rejimini tespit et
        
        Args:
            price_data: OHLCV data DataFrame
        
        Returns:
            RegimeMetrics: Tespit edilen rejim ve metrikler
        """
        if len(price_data) < self.lookback_period:
            raise ValueError(f"En az {self.lookback_period} veri noktası gerekli")
        
        # Son verileri al
        data = price_data.tail(self.lookback_period).copy()
        close_prices = data['close'].values
        volumes = data.get('volume', pd.Series(1, index=data.index)).values
        
        # Teknik indikatörleri hesapla
        trend_strength = self._calculate_trend_strength(close_prices)
        volatility_level = self._calculate_volatility_level(close_prices)
        momentum_score = self._calculate_momentum_score(close_prices)
        support_resistance = self._calculate_support_resistance(close_prices)
        regime_duration = self._calculate_regime_duration(data)
        
        # Rejim tespiti yap
        regime = self._classify_regime(trend_strength, volatility_level, momentum_score)
        
        # Güven seviyesi hesapla
        confidence = self._calculate_regime_confidence(trend_strength, volatility_level, momentum_score)
        
        return RegimeMetrics(
            regime=regime,
            confidence=confidence,
            trend_strength=trend_strength,
            volatility_level=volatility_level,
            momentum_score=momentum_score,
            support_resistance=support_resistance,
            regime_duration=regime_duration
        )
    
    def _calculate_trend_strength(self, prices: np.ndarray) -> float:
        """Trend gücünü hesapla"""
        if len(prices) < 20:
            return 0.0
        
        # Linear regression slope
        x = np.arange(len(prices))
        slope, intercept = np.polyfit(x, prices, 1)
        
        # Normalize slope (percentage based)
        normalized_slope = slope / np.mean(prices)
        
        return normalized_slope
    
    def _calculate_volatility_level(self, prices: np.ndarray) -> float:
        """Volatilite seviyesini hesapla"""
        if len(prices) < 2:
            return 0.0
        
        returns = np.diff(prices) / prices[:-1]
        volatility = np.std(returns)
        
        return volatility
    
    def _calculate_momentum_score(self, prices: np.ndarray) -> float:
        """Momentum skorunu hesapla"""
        if len(prices) < 20:
            return 0.0
        
        # ROC (Rate of Change) tabanlı momentum
        roc_short = (prices[-1] - prices[-5]) / prices[-5] if len(prices) >= 5 else 0
        roc_long = (prices[-1] - prices[-20]) / prices[-20] if len(prices) >= 20 else 0
        
        # Momentum skorunu 0-1 aralığına normalize et
        momentum = (roc_short + roc_long) / 2
        normalized_momentum = np.tanh(momentum)  # -1 ile 1 arası
        
        return (normalized_momentum + 1) / 2  # 0 ile 1 arası
    
    def _calculate_support_resistance(self, prices: np.ndarray) -> Dict[str, float]:
        """Destek ve direnç seviyelerini hesapla"""
        if len(prices) < 20:
            return {'support': prices[-1], 'resistance': prices[-1]}
        
        # Basit pivot points
        recent_prices = prices[-20:]
        
        support = np.min(recent_prices)
        resistance = np.max(recent_prices)
        current_price = prices[-1]
        
        # Fiyatın desteğe/dirence uzaklığı
        support_distance = (current_price - support) / current_price
        resistance_distance = (resistance - current_price) / current_price
        
        return {
            'support': support,
            'resistance': resistance,
            'support_distance': support_distance,
            'resistance_distance': resistance_distance,
            'current_price': current_price
        }
    
    def _calculate_regime_duration(self, data: pd.DataFrame) -> int:
        """Rejim süresini hesapla (gün cinsinden)"""
        # Basit implementation - gerçek sistemde daha karmaşık analiz olabilir
        return len(data)
    
    def _classify_regime(self, trend_strength: float, volatility_level: float, momentum_score: float) -> MarketRegime:
        """Rejim sınıflandırması yap"""
        
        # Volatilite seviyesine göre ayrım
        is_high_vol = volatility_level > self.volatility_threshold
        is_low_vol = volatility_level < (self.volatility_threshold * 0.5)
        
        if is_high_vol:
            return MarketRegime.HIGH_VOLATILITY
        elif is_low_vol and abs(trend_strength) < self.trend_threshold:
            return MarketRegime.LOW_VOLATILITY
        
        # Trend gücüne göre ayrım
        if trend_strength > self.trend_threshold:
            if trend_strength > (self.trend_threshold * 2):
                return MarketRegime.STRONG_UPTREND
            else:
                return MarketRegime.WEAK_UPTREND
        elif trend_strength < -self.trend_threshold:
            if trend_strength < (-self.trend_threshold * 2):
                return MarketRegime.STRONG_DOWNTREND
            else:
                return MarketRegime.WEAK_DOWNTREND
        else:
            return MarketRegime.SIDEWAYS
    
    def _calculate_regime_confidence(self, trend_strength: float, volatility_level: float, momentum_score: float) -> float:
        """Rejim tespiti güven seviyesini hesapla"""
        # Trend gücüne dayalı güven
        trend_confidence = min(abs(trend_strength) / (self.trend_threshold * 2), 1.0)
        
        # Volatiliteye dayalı güven (düşük volatilite = yüksek güven)
        volatility_confidence = 1.0 - min(volatility_level / (self.volatility_threshold * 2), 1.0)
        
        # Momentum'a dayalı güven
        momentum_confidence = abs(momentum_score - 0.5) * 2  # 0 ile 1 arası
        
        # Ortalama güven
        confidence = (trend_confidence + volatility_confidence + momentum_confidence) / 3
        
        return min(confidence, 1.0)
    
    def get_regime_adjustments(self, regime: MarketRegime) -> Dict[str, float]:
        """
        Belirli rejim için skorlama ayarlarını getir
        
        Args:
            regime: Tespit edilen market rejimi
        
        Returns:
            Dict[str, float]: Rejim ayarları
        """
        if regime in self.regime_scoring:
            scoring = self.regime_scoring[regime]
            return {
                'trend_sensitivity': scoring.trend_sensitivity,
                'volatility_adjustment': scoring.volatility_adjustment,
                'regime_confidence_boost': scoring.confidence if hasattr(scoring, 'confidence') else 1.0
            }
        else:
            # Default ayarlar
            return {
                'trend_sensitivity': 0.5,
                'volatility_adjustment': 1.0,
                'regime_confidence_boost': 1.0
            }
    
    def adjust_scoring_weights(self, base_weights: Dict[str, float], regime: MarketRegime) -> Dict[str, float]:
        """
        Rejime göre skorlama ağırlıklarını ayarla
        
        Args:
            base_weights: Temel ağırlıklar
            regime: Market rejimi
        
        Returns:
            Dict[str, float]: Ajust edilmiş ağırlıklar
        """
        adjustments = self.get_regime_adjustments(regime)
        
        # Ağırlıkları rejime göre ayarla
        adjusted_weights = base_weights.copy()
        
        trend_sensitivity = adjustments['trend_sensitivity']
        volatility_adjustment = adjustments['volatility_adjustment']
        
        # Trend hassasiyetine göre ağırlık ayarı
        for key in adjusted_weights:
            if 'trend' in key.lower():
                adjusted_weights[key] *= (1 + trend_sensitivity * 0.2)
            elif 'volatility' in key.lower() or 'risk' in key.lower():
                adjusted_weights[key] *= volatility_adjustment
        
        # Normalize weights
        total_weight = sum(adjusted_weights.values())
        if total_weight > 0:
            adjusted_weights = {k: v/total_weight for k, v in adjusted_weights.items()}
        
        return adjusted_weights
    
    def analyze_multiple_assets(self, price_data_dict: Dict[str, pd.DataFrame]) -> Dict[str, RegimeMetrics]:
        """
        Çoklu asset için rejim analizi yap
        
        Args:
            price_data_dict: Asset -> Price Data mapping
        
        Returns:
            Dict[str, RegimeMetrics]: Asset -> Regime mapping
        """
        results = {}
        
        for asset, price_data in price_data_dict.items():
            try:
                regime_metrics = self.detect_regime(price_data)
                results[asset] = regime_metrics
            except Exception as e:
                print(f"Error analyzing {asset}: {e}")
                continue
        
        return results
    
    def get_regime_summary(self, regime_metrics: RegimeMetrics) -> Dict:
        """
        Rejim analizinin özetini getir
        
        Args:
            regime_metrics: Rejim metrikleri
        
        Returns:
            Dict: Özet bilgiler
        """
        return {
            'regime_type': regime_metrics.regime.value,
            'confidence_level': 'Yüksek' if regime_metrics.confidence > 0.7 else 'Orta' if regime_metrics.confidence > 0.4 else 'Düşük',
            'trend_direction': 'Yükseliş' if regime_metrics.trend_strength > 0 else 'Düşüş' if regime_metrics.trend_strength < 0 else 'Yatay',
            'trend_magnitude': 'Güçlü' if abs(regime_metrics.trend_strength) > self.trend_threshold * 2 else 'Zayıf',
            'volatility_regime': 'Yüksek' if regime_metrics.volatility_level > self.volatility_threshold else 'Düşük',
            'momentum_bias': 'Pozitif' if regime_metrics.momentum_score > 0.6 else 'Negatif' if regime_metrics.momentum_score < 0.4 else 'Nötr',
            'key_levels': {
                'near_support': regime_metrics.support_resistance.get('support_distance', 0) < 0.02,
                'near_resistance': regime_metrics.support_resistance.get('resistance_distance', 0) < 0.02
            },
            'recommended_approach': self._get_recommended_approach(regime_metrics.regime)
        }
    
    def _get_recommended_approach(self, regime: MarketRegime) -> str:
        """Rejime göre önerilen yaklaşımı getir"""
        approach_mapping = {
            MarketRegime.STRONG_UPTREND: "Trend takip stratejileri, uzun pozisyonlar",
            MarketRegime.STRONG_DOWNTREND: "Trend takip stratejileri, kısa pozisyonlar",
            MarketRegime.SIDEWAYS: "Mean reversion, aralık ticareti",
            MarketRegime.WEAK_UPTREND: "Temkinli trend takip, pozisyon boyutu küçült",
            MarketRegime.WEAK_DOWNTREND: "Temkinli trend takip, pozisyon boyutu küçült",
            MarketRegime.HIGH_VOLATILITy: "Risk yönetimi öncelik, pozisyon boyutu küçült",
            MarketRegime.LOW_VOLATILITy: "Breakout stratejileri, volatilite artışını bekle"
        }
        return approach_mapping.get(regime, "Çeşitlendirilmiş yaklaşım")