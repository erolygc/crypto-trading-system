"""
Account Manager Interface Sistemi
=================================

Account Managers ile seamless entegrasyon sağlayan interface sistemi.
Portfolio management, risk monitoring ve execution coordination içerir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Any
from dataclasses import dataclass, field
from enum import Enum
from abc import ABC, abstractmethod
from collections import defaultdict
import json
from datetime import datetime, timedelta
import warnings

warnings.filterwarnings('ignore')


class AccountType(Enum):
    """Account tipleri"""
    INDIVIDUAL = "individual"
    INSTITUTIONAL = "institutional"
    ADVISORY = "advisory"
    FAMILY_OFFICE = "family_office"
    HEDGE_FUND = "hedge_fund"


class RiskProfile(Enum):
    """Risk profilleri"""
    CONSERVATIVE = "conservative"
    MODERATE = "moderate"
    BALANCED = "balanced"
    AGGRESSIVE = "aggressive"
    VERY_AGGRESSIVE = "very_aggressive"


class ExecutionPriority(Enum):
    """Execution öncelik seviyeleri"""
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    URGENT = 4


@dataclass
class AccountConstraints:
    """Account kısıtlamaları"""
    max_position_size: float = 0.1
    max_sector_exposure: float = 0.3
    max_single_asset_exposure: float = 0.2
    max_leverage: float = 1.0
    min_cash_reserve: float = 0.05
    max_daily_loss: float = 0.02
    restricted_assets: List[str] = field(default_factory=list)
    allowed_strategies: List[str] = field(default_factory=list)
    rebalance_frequency: str = "daily"
    risk_limits: Dict[str, float] = field(default_factory=dict)


@dataclass
class AccountMetrics:
    """Account metrikleri"""
    total_value: float
    cash_position: float
    invested_amount: float
    daily_pnl: float
    ytd_return: float
    sharpe_ratio: float
    max_drawdown: float
    win_rate: float
    active_positions: int
    risk_utilization: float
    concentration_risk: float


@dataclass
class SignalExecution:
    """Signal execution bilgisi"""
    signal_id: str
    account_id: str
    signal_data: Dict
    execution_time: datetime
    execution_price: float
    executed_quantity: float
    order_type: str
    priority: ExecutionPriority
    status: str
    result: Optional[Dict] = None


class BaseAccountManager(ABC):
    """Account Manager için base class"""
    
    @abstractmethod
    def evaluate_signal(self, signal: Dict, account_constraints: AccountConstraints) -> Dict[str, Any]:
        """Sinyali evaluate et"""
        pass
    
    @abstractmethod
    def execute_signal(self, signal: Dict, execution_params: Dict) -> SignalExecution:
        """Sinyali execute et"""
        pass
    
    @abstractmethod
    def get_account_status(self) -> AccountMetrics:
        """Account durumunu getir"""
        pass


class AccountManagerInterface:
    """
    Account Manager Interface sistemi
    
    Çoklu account manager'lar ile entegre çalışır, sinyal execution'ı 
    koordine eder ve portfolio management sağlar.
    """
    
    def __init__(self):
        """Initialize account manager interface"""
        self.account_managers: Dict[str, BaseAccountManager] = {}
        self.account_configs: Dict[str, AccountConstraints] = {}
        self.execution_history: List[SignalExecution] = []
        self.risk_monitors: Dict[str, Any] = {}
        self.portfolio_aggregator = None
        
        # Default risk profiles
        self.risk_profiles = {
            RiskProfile.CONSERVATIVE: AccountConstraints(
                max_position_size=0.05,
                max_sector_exposure=0.2,
                max_single_asset_exposure=0.1,
                max_leverage=1.0,
                min_cash_reserve=0.2,
                max_daily_loss=0.01
            ),
            RiskProfile.MODERATE: AccountConstraints(
                max_position_size=0.08,
                max_sector_exposure=0.25,
                max_single_asset_exposure=0.15,
                max_leverage=1.5,
                min_cash_reserve=0.1,
                max_daily_loss=0.015
            ),
            RiskProfile.BALANCED: AccountConstraints(
                max_position_size=0.1,
                max_sector_exposure=0.3,
                max_single_asset_exposure=0.2,
                max_leverage=2.0,
                min_cash_reserve=0.05,
                max_daily_loss=0.02
            ),
            RiskProfile.AGGRESSIVE: AccountConstraints(
                max_position_size=0.15,
                max_sector_exposure=0.4,
                max_single_asset_exposure=0.25,
                max_leverage=3.0,
                min_cash_reserve=0.02,
                max_daily_loss=0.03
            ),
            RiskProfile.VERY_AGGRESSIVE: AccountConstraints(
                max_position_size=0.2,
                max_sector_exposure=0.5,
                max_single_asset_exposure=0.3,
                max_leverage=5.0,
                min_cash_reserve=0.01,
                max_daily_loss=0.05
            )
        }
    
    def register_account_manager(self, 
                               account_id: str,
                               manager: BaseAccountManager,
                               risk_profile: RiskProfile = RiskProfile.BALANCED,
                               custom_constraints: Optional[AccountConstraints] = None):
        """
        Account Manager'ı kaydet
        
        Args:
            account_id: Account ID
            manager: Account Manager instance
            risk_profile: Risk profili
            custom_constraints: Özel kısıtlamalar
        """
        if custom_constraints:
            constraints = custom_constraints
        else:
            constraints = self.risk_profiles[risk_profile]
        
        self.account_managers[account_id] = manager
        self.account_configs[account_id] = constraints
        
        print(f"Account manager {account_id} registered with {risk_profile.value} risk profile")
    
    def unregister_account_manager(self, account_id: str):
        """Account Manager'ı kayıttan sil"""
        if account_id in self.account_managers:
            del self.account_managers[account_id]
        if account_id in self.account_configs:
            del self.account_configs[account_id]
        
        print(f"Account manager {account_id} unregistered")
    
    def distribute_signal_to_accounts(self, 
                                    signal: Dict,
                                    account_preferences: Optional[Dict[str, Dict]] = None) -> Dict[str, Dict]:
        """
        Sinyali uygun account'lara dağıt
        
        Args:
            signal: Sinyal verisi
            account_preferences: Account bazlı tercihler
        
        Returns:
            Dict[str, Dict]: Account ID -> Execution plan mapping
        """
        execution_plans = {}
        
        for account_id, manager in self.account_managers.items():
            try:
                # Evaluate signal for this account
                account_constraints = self.account_configs[account_id]
                
                evaluation = manager.evaluate_signal(signal, account_constraints)
                
                if evaluation.get('approved', False):
                    # Determine execution parameters
                    exec_params = self._determine_execution_params(
                        signal, account_constraints, evaluation
                    )
                    
                    execution_plans[account_id] = {
                        'manager': manager,
                        'evaluation': evaluation,
                        'execution_params': exec_params,
                        'signal': signal
                    }
                
            except Exception as e:
                print(f"Error evaluating signal for account {account_id}: {e}")
                continue
        
        return execution_plans
    
    def execute_signal_across_accounts(self,
                                     signal: Dict,
                                     execution_plans: Dict[str, Dict],
                                     global_constraints: Optional[Dict] = None) -> Dict[str, SignalExecution]:
        """
        Sinyali birden fazla account'ta execute et
        
        Args:
            signal: Sinyal verisi
            execution_plans: Execution planları
            global_constraints: Global kısıtlamalar
        
        Returns:
            Dict[str, SignalExecution]: Account ID -> Execution sonucu
        """
        execution_results = {}
        
        # Apply global constraints if any
        if global_constraints:
            execution_plans = self._apply_global_constraints(execution_plans, global_constraints)
        
        for account_id, plan in execution_plans.items():
            try:
                manager = plan['manager']
                exec_params = plan['execution_params']
                
                # Execute signal
                execution = manager.execute_signal(signal, exec_params)
                execution_results[account_id] = execution
                
                # Add to history
                self.execution_history.append(execution)
                
                print(f"Signal {signal['signal_id']} executed for account {account_id}")
                
            except Exception as e:
                print(f"Error executing signal for account {account_id}: {e}")
                
                # Create failed execution record
                failed_execution = SignalExecution(
                    signal_id=signal.get('signal_id', 'unknown'),
                    account_id=account_id,
                    signal_data=signal,
                    execution_time=datetime.now(),
                    execution_price=0.0,
                    executed_quantity=0.0,
                    order_type='market',
                    priority=ExecutionPriority.MEDIUM,
                    status='failed',
                    result={'error': str(e)}
                )
                execution_results[account_id] = failed_execution
        
        return execution_results
    
    def get_aggregated_portfolio_view(self) -> Dict[str, Any]:
        """
        Tüm account'ların aggregate portfolio view'ını getir
        
        Returns:
            Dict[str, Any]: Aggregate portfolio bilgileri
        """
        total_value = 0.0
        total_cash = 0.0
        total_pnl = 0.0
        total_positions = 0
        
        account_details = {}
        strategy_exposure = defaultdict(float)
        sector_exposure = defaultdict(float)
        asset_exposure = defaultdict(float)
        
        for account_id, manager in self.account_managers.items():
            try:
                metrics = manager.get_account_status()
                
                total_value += metrics.total_value
                total_cash += metrics.cash_position
                total_pnl += metrics.daily_pnl
                total_positions += metrics.active_positions
                
                account_details[account_id] = {
                    'total_value': metrics.total_value,
                    'cash_position': metrics.cash_position,
                    'invested_amount': metrics.invested_amount,
                    'daily_pnl': metrics.daily_pnl,
                    'ytd_return': metrics.ytd_return,
                    'sharpe_ratio': metrics.sharpe_ratio,
                    'max_drawdown': metrics.max_drawdown,
                    'risk_utilization': metrics.risk_utilization
                }
                
                # Calculate exposures (simplified)
                positions = metrics.active_positions
                if positions > 0:
                    strategy_exposure[f"{account_id}_strategy"] = metrics.invested_amount / total_value
                    sector_exposure[f"{account_id}_sector"] = metrics.concentration_risk
                
            except Exception as e:
                print(f"Error getting metrics for account {account_id}: {e}")
                continue
        
        # Calculate aggregate metrics
        aggregate_return = total_pnl / total_value if total_value > 0 else 0.0
        cash_percentage = total_cash / total_value if total_value > 0 else 0.0
        invested_percentage = 1.0 - cash_percentage
        
        return {
            'aggregate_metrics': {
                'total_value': total_value,
                'total_cash': total_cash,
                'invested_value': total_value - total_cash,
                'daily_pnl': total_pnl,
                'daily_return': aggregate_return,
                'cash_percentage': cash_percentage,
                'invested_percentage': invested_percentage,
                'total_active_positions': total_positions,
                'num_accounts': len(self.account_managers)
            },
            'account_details': account_details,
            'exposures': {
                'strategy_exposure': dict(strategy_exposure),
                'sector_exposure': dict(sector_exposure),
                'asset_exposure': dict(asset_exposure)
            },
            'performance_summary': self._calculate_aggregate_performance()
        }
    
    def monitor_portfolio_risk(self) -> Dict[str, Any]:
        """
        Portfolio riskini monitör et
        
        Returns:
            Dict[str, Any]: Risk monitoring sonuçları
        """
        risk_analysis = {
            'overall_risk_score': 0.0,
            'risk_alerts': [],
            'concentration_risk': 0.0,
            'correlation_risk': 0.0,
            'leverage_risk': 0.0,
            'account_risk_breakdown': {}
        }
        
        account_risks = []
        
        for account_id, manager in self.account_managers.items():
            try:
                metrics = manager.get_account_status()
                account_risks.append(metrics.risk_utilization)
                
                risk_analysis['account_risk_breakdown'][account_id] = {
                    'risk_utilization': metrics.risk_utilization,
                    'concentration_risk': metrics.concentration_risk,
                    'max_drawdown': metrics.max_drawdown,
                    'daily_pnl': metrics.daily_pnl
                }
                
                # Check for risk alerts
                if metrics.risk_utilization > 0.9:
                    risk_analysis['risk_alerts'].append(f"High risk utilization for account {account_id}")
                
                if metrics.concentration_risk > 0.5:
                    risk_analysis['risk_alerts'].append(f"High concentration risk for account {account_id}")
                
                if metrics.daily_pnl < -0.05:
                    risk_analysis['risk_alerts'].append(f"Significant daily loss for account {account_id}")
                
            except Exception as e:
                print(f"Error monitoring risk for account {account_id}: {e}")
                continue
        
        # Overall risk calculation
        if account_risks:
            risk_analysis['overall_risk_score'] = np.mean(account_risks)
            risk_analysis['concentration_risk'] = np.std(account_risks)
        
        return risk_analysis
    
    def generate_execution_report(self, 
                                start_time: Optional[datetime] = None,
                                end_time: Optional[datetime] = None) -> Dict[str, Any]:
        """
        Execution raporu oluştur
        
        Args:
            start_time: Rapor başlangıç zamanı
            end_time: Rapor bitiş zamanı
        
        Returns:
            Dict[str, Any]: Execution raporu
        """
        if not start_time:
            start_time = datetime.now() - timedelta(days=30)
        if not end_time:
            end_time = datetime.now()
        
        # Filter executions by time range
        filtered_executions = [
            exec for exec in self.execution_history
            if start_time <= exec.execution_time <= end_time
        ]
        
        if not filtered_executions:
            return {'message': 'No executions in the specified time range'}
        
        # Calculate statistics
        total_executions = len(filtered_executions)
        successful_executions = len([e for e in filtered_executions if e.status == 'completed'])
        failed_executions = len([e for e in filtered_executions if e.status == 'failed'])
        
        execution_summary = {
            'total_executions': total_executions,
            'successful_executions': successful_executions,
            'failed_executions': failed_executions,
            'success_rate': successful_executions / total_executions if total_executions > 0 else 0,
            'time_range': {
                'start': start_time.isoformat(),
                'end': end_time.isoformat()
            }
        }
        
        # Account breakdown
        account_breakdown = {}
        for execution in filtered_executions:
            account_id = execution.account_id
            if account_id not in account_breakdown:
                account_breakdown[account_id] = {
                    'total_executions': 0,
                    'successful_executions': 0,
                    'failed_executions': 0
                }
            
            account_breakdown[account_id]['total_executions'] += 1
            if execution.status == 'completed':
                account_breakdown[account_id]['successful_executions'] += 1
            else:
                account_breakdown[account_id]['failed_executions'] += 1
        
        # Strategy performance
        strategy_performance = {}
        for execution in filtered_executions:
            signal_data = execution.signal_data
            strategy = signal_data.get('strategy', 'unknown')
            
            if strategy not in strategy_performance:
                strategy_performance[strategy] = {
                    'total_executions': 0,
                    'success_rate': 0.0,
                    'total_executed_quantity': 0.0,
                    'average_execution_price': 0.0
                }
            
            strategy_performance[strategy]['total_executions'] += 1
            if execution.status == 'completed':
                strategy_performance[strategy]['total_executed_quantity'] += execution.executed_quantity
                strategy_performance[strategy]['average_execution_price'] += execution.execution_price
        
        # Calculate success rates and averages
        for strategy, stats in strategy_performance.items():
            total_exec = stats['total_executions']
            if total_exec > 0:
                completed_count = len([e for e in filtered_executions 
                                     if e.status == 'completed' and e.signal_data.get('strategy') == strategy])
                stats['success_rate'] = completed_count / total_exec
                
                if stats['total_executed_quantity'] > 0:
                    completed_executions = [e for e in filtered_executions 
                                          if e.status == 'completed' and e.signal_data.get('strategy') == strategy]
                    stats['average_execution_price'] = np.mean([e.execution_price for e in completed_executions])
        
        return {
            'execution_summary': execution_summary,
            'account_breakdown': account_breakdown,
            'strategy_performance': strategy_performance,
            'risk_metrics': self.monitor_portfolio_risk(),
            'portfolio_view': self.get_aggregated_portfolio_view()
        }
    
    def _determine_execution_params(self, 
                                   signal: Dict, 
                                   constraints: AccountConstraints,
                                   evaluation: Dict) -> Dict:
        """Execution parametrelerini belirle"""
        params = {
            'order_type': 'market',
            'quantity': 0.0,
            'limit_price': None,
            'time_in_force': 'day',
            'priority': ExecutionPriority.MEDIUM
        }
        
        # Adjust quantity based on signal and constraints
        signal_strength = evaluation.get('signal_strength', 0.5)
        max_position = constraints.max_position_size
        recommended_quantity = min(signal_strength * max_position, constraints.max_position_size)
        
        params['quantity'] = recommended_quantity
        
        # Set priority based on signal quality
        if signal_strength > 0.8:
            params['priority'] = ExecutionPriority.HIGH
        elif signal_strength < 0.3:
            params['priority'] = ExecutionPriority.LOW
        
        # Set order type based on account type (simplified)
        if evaluation.get('market_impact', 0) > 0.05:
            params['order_type'] = 'limit'
            params['limit_price'] = signal.get('current_price', 0) * 0.99
        
        return params
    
    def _apply_global_constraints(self, 
                                 execution_plans: Dict[str, Dict],
                                 global_constraints: Dict) -> Dict[str, Dict]:
        """Global kısıtlamaları uygula"""
        max_total_exposure = global_constraints.get('max_total_exposure', 0.5)
        min_signal_quality = global_constraints.get('min_signal_quality', 0.6)
        
        # Filter plans based on global constraints
        filtered_plans = {}
        
        for account_id, plan in execution_plans.items():
            evaluation = plan['evaluation']
            
            # Check signal quality threshold
            if evaluation.get('signal_strength', 0) < min_signal_quality:
                continue
            
            filtered_plans[account_id] = plan
        
        # Limit total exposure
        total_exposure = sum(plan['execution_params'].get('quantity', 0) for plan in filtered_plans.values())
        
        if total_exposure > max_total_exposure:
            # Scale down all quantities proportionally
            scale_factor = max_total_exposure / total_exposure
            
            for plan in filtered_plans.values():
                current_qty = plan['execution_params'].get('quantity', 0)
                plan['execution_params']['quantity'] = current_qty * scale_factor
        
        return filtered_plans
    
    def _calculate_aggregate_performance(self) -> Dict[str, float]:
        """Aggregate performance hesapla"""
        if not self.account_managers:
            return {}
        
        account_returns = []
        account_sharpes = []
        account_drawdowns = []
        
        for account_id, manager in self.account_managers.items():
            try:
                metrics = manager.get_account_status()
                account_returns.append(metrics.ytd_return)
                account_sharpes.append(metrics.sharpe_ratio)
                account_drawdowns.append(metrics.max_drawdown)
            except:
                continue
        
        if not account_returns:
            return {}
        
        return {
            'aggregate_ytd_return': np.mean(account_returns),
            'aggregate_sharpe_ratio': np.mean(account_sharpes),
            'aggregate_max_drawdown': np.mean(account_drawdowns),
            'return_std': np.std(account_returns),
            'sharpe_std': np.std(account_sharpes)
        }
    
    def get_account_summary(self) -> Dict[str, Any]:
        """Tüm account'ların özetini getir"""
        summary = {
            'total_accounts': len(self.account_managers),
            'account_types': {},
            'risk_profiles': {},
            'total_exposure': 0.0,
            'account_details': {}
        }
        
        for account_id, manager in self.account_managers.items():
            try:
                constraints = self.account_configs[account_id]
                metrics = manager.get_account_status()
                
                # Account type (inferred from constraints)
                if constraints.max_leverage <= 1.0:
                    account_type = AccountType.INDIVIDUAL
                elif constraints.max_leverage <= 2.0:
                    account_type = AccountType.ADVISORY
                else:
                    account_type = AccountType.INSTITUTIONAL
                
                summary['account_types'][account_type.value] = summary['account_types'].get(account_type.value, 0) + 1
                summary['total_exposure'] += metrics.invested_amount
                
                summary['account_details'][account_id] = {
                    'account_type': account_type.value,
                    'max_position_size': constraints.max_position_size,
                    'max_leverage': constraints.max_leverage,
                    'total_value': metrics.total_value,
                    'invested_amount': metrics.invested_amount,
                    'ytd_return': metrics.ytd_return,
                    'sharpe_ratio': metrics.sharpe_ratio,
                    'risk_utilization': metrics.risk_utilization
                }
                
            except Exception as e:
                print(f"Error getting summary for account {account_id}: {e}")
                continue
        
        return summary