"""
Real-time Signal Ranking Sistemi
=================================

Gerçek zamanlı sinyal skorlaması, ranking ve selection yapan akıllı sistem.
Dynamic ranking, priority queue management ve real-time updates içerir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union, Set
from dataclasses import dataclass, field
from enum import Enum
from collections import defaultdict, deque
import heapq
import threading
import time
from datetime import datetime, timedelta
import warnings

warnings.filterwarnings('ignore')


class RankingMethod(Enum):
    """Ranking yöntemleri"""
    COMPOSITE_SCORE = "composite_score"
    CONFIDENCE_WEIGHTED = "confidence_weighted"
    RISK_ADJUSTED = "risk_adjusted"
    MOMENTUM_BASED = "momentum_based"
    DIVERSIFICATION_AWARE = "diversification_aware"


class SignalStatus(Enum):
    """Sinyal durumları"""
    ACTIVE = "active"
    PENDING = "pending"
    EXECUTED = "executed"
    EXPIRED = "expired"
    CANCELLED = "cancelled"


@dataclass
class SignalRank:
    """Sinyal ranking bilgisi"""
    signal_id: str
    signal_data: Dict
    current_score: float
    confidence_score: float
    risk_score: float
    momentum_score: float
    composite_score: float
    rank: int
    percentile: float
    tier: str  # "A", "B", "C", "D"
    last_updated: datetime
    priority_score: float = 0.0
    
    def __lt__(self, other):
        """Priority queue için comparison operator"""
        return self.priority_score > other.priority_score  # Max-heap


@dataclass
class RankingCriteria:
    """Ranking kriterleri"""
    score_weights: Dict[str, float] = field(default_factory=lambda: {
        'composite': 0.4,
        'confidence': 0.3,
        'risk': 0.2,
        'momentum': 0.1
    })
    
    min_confidence: float = 0.3
    max_risk_score: float = 0.8
    min_momentum: float = 0.0
    tier_thresholds: Dict[str, float] = field(default_factory=lambda: {
        'A': 0.8,
        'B': 0.6,
        'C': 0.4,
        'D': 0.2
    })


@dataclass
class RankingResult:
    """Ranking sonucu"""
    ranked_signals: List[SignalRank]
    top_signals: List[SignalRank]
    summary_stats: Dict[str, float]
    diversification_analysis: Dict[str, float]
    execution_queue: List[SignalRank]
    timestamp: datetime


class SignalRanking:
    """
    Real-time signal ranking ve selection sistemi
    
    Çoklu faktörlü scoring, real-time updates ve intelligent selection
    yaparak optimal sinyal seti oluşturur.
    """
    
    def __init__(self,
                 ranking_method: RankingMethod = RankingMethod.COMPOSITE_SCORE,
                 max_active_signals: int = 10,
                 ranking_criteria: Optional[RankingCriteria] = None,
                 update_interval: float = 1.0):
        """
        Initialize signal ranking system
        
        Args:
            ranking_method: Ranking yöntemi
            max_active_signals: Maksimum aktif sinyal sayısı
            ranking_criteria: Ranking kriterleri
            update_interval: Update aralığı (saniye)
        """
        self.ranking_method = ranking_method
        self.max_active_signals = max_active_signals
        self.update_interval = update_interval
        self.ranking_criteria = ranking_criteria or RankingCriteria()
        
        # Data structures
        self.signal_registry: Dict[str, SignalRank] = {}
        self.active_signals: Dict[str, SignalRank] = {}
        self.pending_signals: Dict[str, SignalRank] = {}
        self.execution_queue: List[SignalRank] = []
        
        # Performance tracking
        self.ranking_history: List[RankingResult] = []
        self.performance_metrics = defaultdict(list)
        
        # Threading for real-time updates
        self._update_thread = None
        self._running = False
        self._lock = threading.RLock()
        
        # Portfolio constraints
        self.portfolio_constraints = {
            'max_position_size': 0.1,  # 10% max per signal
            'max_sector_concentration': 0.3,  # 30% max per sector
            'correlation_threshold': 0.7,  # Max correlation between signals
            'max_volatility': 0.2  # 20% max portfolio volatility
        }
        
        # Scoring components
        self.scoring_engine = None  # Will be set externally
    
    def start_real_time_ranking(self):
        """Real-time ranking sistemini başlat"""
        if not self._running:
            self._running = True
            self._update_thread = threading.Thread(target=self._real_time_update_loop)
            self._update_thread.daemon = True
            self._update_thread.start()
            print("Real-time ranking system started")
    
    def stop_real_time_ranking(self):
        """Real-time ranking sistemini durdur"""
        self._running = False
        if self._update_thread:
            self._update_thread.join(timeout=5.0)
        print("Real-time ranking system stopped")
    
    def add_signal(self, signal_data: Dict) -> SignalRank:
        """
        Yeni sinyal ekle
        
        Args:
            signal_data: Sinyal verisi
        
        Returns:
            SignalRank: Eklenen sinyal ranking bilgisi
        """
        signal_id = signal_data.get('signal_id')
        if not signal_id:
            raise ValueError("Signal ID is required")
        
        # Calculate scores
        scores = self._calculate_signal_scores(signal_data)
        
        # Create signal rank
        signal_rank = SignalRank(
            signal_id=signal_id,
            signal_data=signal_data,
            current_score=scores['composite'],
            confidence_score=scores['confidence'],
            risk_score=scores['risk'],
            momentum_score=scores['momentum'],
            composite_score=scores['composite'],
            rank=0,
            percentile=0.0,
            tier=self._calculate_tier(scores['composite']),
            last_updated=datetime.now(),
            priority_score=self._calculate_priority_score(scores)
        )
        
        with self._lock:
            self.signal_registry[signal_id] = signal_rank
            self.pending_signals[signal_id] = signal_rank
        
        # Trigger ranking update
        self._update_rankings()
        
        return signal_rank
    
    def remove_signal(self, signal_id: str, status: SignalStatus = SignalStatus.CANCELLED):
        """Sinyal kaldır"""
        with self._lock:
            if signal_id in self.signal_registry:
                signal_rank = self.signal_registry[signal_id]
                
                # Remove from appropriate category
                if signal_id in self.active_signals:
                    del self.active_signals[signal_id]
                if signal_id in self.pending_signals:
                    del self.pending_signals[signal_id]
                
                # Update status
                signal_rank.signal_data['status'] = status.value
            
            # Update rankings
            self._update_rankings()
    
    def update_signal_scores(self, signal_id: str, new_scores: Dict[str, float]):
        """Sinyal skorlarını güncelle"""
        with self._lock:
            if signal_id in self.signal_registry:
                signal_rank = self.signal_registry[signal_id]
                
                # Update scores
                signal_rank.current_score = new_scores.get('composite', signal_rank.current_score)
                signal_rank.confidence_score = new_scores.get('confidence', signal_rank.confidence_score)
                signal_rank.risk_score = new_scores.get('risk', signal_rank.risk_score)
                signal_rank.momentum_score = new_scores.get('momentum', signal_rank.momentum_score)
                signal_rank.composite_score = signal_rank.current_score
                signal_rank.tier = self._calculate_tier(signal_rank.current_score)
                signal_rank.priority_score = self._calculate_priority_score(new_scores)
                signal_rank.last_updated = datetime.now()
            
            # Update rankings
            self._update_rankings()
    
    def get_top_signals(self, n: Optional[int] = None, tier_filter: Optional[str] = None) -> List[SignalRank]:
        """
        En iyi N sinyali getir
        
        Args:
            n: Sinyal sayısı (None = tümü)
            tier_filter: Tier filtresi ("A", "B", "C", "D")
        
        Returns:
            List[SignalRank]: En iyi sinyaller
        """
        with self._lock:
            # Get all active and pending signals
            all_signals = list(self.active_signals.values()) + list(self.pending_signals.values())
            
            # Filter by tier if specified
            if tier_filter:
                all_signals = [s for s in all_signals if s.tier == tier_filter]
            
            # Sort by composite score
            sorted_signals = sorted(all_signals, key=lambda s: s.composite_score, reverse=True)
            
            # Apply diversification constraints
            diversified_signals = self._apply_diversification_constraints(sorted_signals)
            
            # Return top N
            if n:
                return diversified_signals[:n]
            else:
                return diversified_signals
    
    def get_ranking_result(self) -> RankingResult:
        """
        Mevcut ranking sonucunu getir
        
        Returns:
            RankingResult: Comprehensive ranking result
        """
        with self._lock:
            # Get all signals
            all_signals = list(self.active_signals.values()) + list(self.pending_signals.values())
            
            # Sort by composite score
            ranked_signals = sorted(all_signals, key=lambda s: s.composite_score, reverse=True)
            
            # Update ranks and percentiles
            self._update_ranks_and_percentiles(ranked_signals)
            
            # Get top signals
            top_signals = ranked_signals[:self.max_active_signals]
            
            # Summary statistics
            summary_stats = self._calculate_summary_stats(ranked_signals)
            
            # Diversification analysis
            diversification_analysis = self._analyze_diversification(ranked_signals)
            
            # Execution queue (priority based)
            execution_queue = self._build_execution_queue(ranked_signals)
            
            # Save to history
            result = RankingResult(
                ranked_signals=ranked_signals,
                top_signals=top_signals,
                summary_stats=summary_stats,
                diversification_analysis=diversification_analysis,
                execution_queue=execution_queue,
                timestamp=datetime.now()
            )
            
            self.ranking_history.append(result)
            
            # Keep only recent history
            if len(self.ranking_history) > 1000:
                self.ranking_history = self.ranking_history[-500:]
            
            return result
    
    def rank_by_confidence(self, min_confidence: float = 0.5) -> List[SignalRank]:
        """Güven seviyesine göre ranking yap"""
        with self._lock:
            all_signals = list(self.active_signals.values()) + list(self.pending_signals.values())
            
            # Filter by confidence
            high_confidence_signals = [s for s in all_signals if s.confidence_score >= min_confidence]
            
            # Sort by confidence
            confidence_ranked = sorted(high_confidence_signals, key=lambda s: s.confidence_score, reverse=True)
            
            return confidence_ranked
    
    def rank_by_risk_adjusted(self) -> List[SignalRank]:
        """Risk ayarlı skorlama ile ranking yap"""
        with self._lock:
            all_signals = list(self.active_signals.values()) + list(self.pending_signals.values())
            
            # Calculate risk-adjusted scores
            risk_adjusted_signals = []
            for signal in all_signals:
                # Risk-adjusted score = Composite / (1 + Risk)
                risk_adjusted_score = signal.composite_score / (1 + signal.risk_score + 1e-8)
                
                # Create new object with adjusted score
                adjusted_signal = SignalRank(
                    signal_id=signal.signal_id,
                    signal_data=signal.signal_data,
                    current_score=signal.current_score,
                    confidence_score=signal.confidence_score,
                    risk_score=signal.risk_score,
                    momentum_score=signal.momentum_score,
                    composite_score=risk_adjusted_score,
                    rank=signal.rank,
                    percentile=signal.percentile,
                    tier=signal.tier,
                    last_updated=signal.last_updated,
                    priority_score=signal.priority_score
                )
                risk_adjusted_signals.append(adjusted_signal)
            
            # Sort by risk-adjusted score
            return sorted(risk_adjusted_signals, key=lambda s: s.composite_score, reverse=True)
    
    def optimize_signal_selection(self, 
                                constraints: Optional[Dict] = None) -> List[SignalRank]:
        """
        Optimized signal selection with constraints
        
        Args:
            constraints: Portfolio constraints
        
        Returns:
            List[SignalRank]: Optimized signal selection
        """
        constraints = constraints or self.portfolio_constraints
        
        with self._lock:
            all_signals = list(self.active_signals.values()) + list(self.pending_signals.values())
            
            # Greedy optimization with constraints
            selected_signals = []
            remaining_signals = sorted(all_signals, key=lambda s: s.composite_score, reverse=True)
            
            while remaining_signals and len(selected_signals) < self.max_active_signals:
                candidate = remaining_signals.pop(0)
                
                # Check constraints
                if self._check_selection_constraints(candidate, selected_signals, constraints):
                    selected_signals.append(candidate)
            
            return selected_signals
    
    def get_ranking_analytics(self) -> Dict:
        """Ranking analitiklerini getir"""
        with self._lock:
            total_signals = len(self.signal_registry)
            active_count = len(self.active_signals)
            pending_count = len(self.pending_signals)
            
            # Tier distribution
            tier_counts = defaultdict(int)
            for signal in self.signal_registry.values():
                tier_counts[signal.tier] += 1
            
            # Average scores
            all_scores = [s.composite_score for s in self.signal_registry.values()]
            avg_score = np.mean(all_scores) if all_scores else 0.0
            
            # Performance metrics
            recent_performance = []
            for signal in self.signal_registry.values():
                perf_score = signal.signal_data.get('performance_score', 0.0)
                recent_performance.append(perf_score)
            
            return {
                'total_signals': total_signals,
                'active_signals': active_count,
                'pending_signals': pending_count,
                'average_score': avg_score,
                'tier_distribution': dict(tier_counts),
                'recent_performance': np.mean(recent_performance) if recent_performance else 0.0,
                'ranking_method': self.ranking_method.value,
                'last_update': max([s.last_updated for s in self.signal_registry.values()] + [datetime.now()]).isoformat()
            }
    
    def _real_time_update_loop(self):
        """Real-time update loop"""
        while self._running:
            try:
                self._update_rankings()
                time.sleep(self.update_interval)
            except Exception as e:
                print(f"Error in real-time update: {e}")
                time.sleep(self.update_interval)
    
    def _update_rankings(self):
        """Rankings'i güncelle"""
        with self._lock:
            # Recalculate scores for all signals
            for signal_id, signal_rank in list(self.signal_registry.items()):
                try:
                    # Get fresh scores from data
                    if self.scoring_engine:
                        new_scores = self.scoring_engine.calculate_scores(signal_rank.signal_data)
                        signal_rank.current_score = new_scores.get('composite', signal_rank.current_score)
                        signal_rank.confidence_score = new_scores.get('confidence', signal_rank.confidence_score)
                        signal_rank.risk_score = new_scores.get('risk', signal_rank.risk_score)
                        signal_rank.momentum_score = new_scores.get('momentum', signal_rank.momentum_score)
                        signal_rank.composite_score = signal_rank.current_score
                        signal_rank.priority_score = self._calculate_priority_score(new_scores)
                    else:
                        # Simple score update
                        signal_rank.priority_score = signal_rank.composite_score
                    
                    signal_rank.last_updated = datetime.now()
                    signal_rank.tier = self._calculate_tier(signal_rank.composite_score)
                
                except Exception as e:
                    print(f"Error updating signal {signal_id}: {e}")
            
            # Re-categorize signals
            self._re_categorize_signals()
    
    def _calculate_signal_scores(self, signal_data: Dict) -> Dict[str, float]:
        """Sinyal skorlarını hesapla"""
        # Use external scoring engine if available
        if self.scoring_engine:
            return self.scoring_engine.calculate_scores(signal_data)
        
        # Simple fallback scoring
        base_score = signal_data.get('base_score', 0.5)
        confidence = signal_data.get('confidence', 0.5)
        risk = 1.0 - signal_data.get('risk_score', 0.5)
        momentum = signal_data.get('momentum_score', 0.5)
        
        composite = (base_score * 0.4 + confidence * 0.3 + risk * 0.2 + momentum * 0.1)
        
        return {
            'composite': composite,
            'confidence': confidence,
            'risk': risk,
            'momentum': momentum
        }
    
    def _calculate_tier(self, score: float) -> str:
        """Skora göre tier hesapla"""
        thresholds = self.ranking_criteria.tier_thresholds
        
        if score >= thresholds['A']:
            return 'A'
        elif score >= thresholds['B']:
            return 'B'
        elif score >= thresholds['C']:
            return 'C'
        else:
            return 'D'
    
    def _calculate_priority_score(self, scores: Dict[str, float]) -> float:
        """Priority skorunu hesapla"""
        weights = self.ranking_criteria.score_weights
        
        priority = (
            scores.get('composite', 0) * weights.get('composite', 0) +
            scores.get('confidence', 0) * weights.get('confidence', 0) +
            (1 - scores.get('risk', 0)) * weights.get('risk', 0) +
            scores.get('momentum', 0) * weights.get('momentum', 0)
        )
        
        return priority
    
    def _update_ranks_and_percentiles(self, ranked_signals: List[SignalRank]):
        """Rank ve percentile güncellemeleri"""
        n = len(ranked_signals)
        
        for i, signal in enumerate(ranked_signals):
            signal.rank = i + 1
            signal.percentile = (n - i) / n  # 0-1, higher = better
    
    def _calculate_summary_stats(self, signals: List[SignalRank]) -> Dict[str, float]:
        """Summary statistics hesapla"""
        if not signals:
            return {}
        
        scores = [s.composite_score for s in signals]
        
        return {
            'count': len(signals),
            'mean_score': np.mean(scores),
            'median_score': np.median(scores),
            'std_score': np.std(scores),
            'min_score': np.min(scores),
            'max_score': np.max(scores),
            'tier_A_count': len([s for s in signals if s.tier == 'A']),
            'tier_B_count': len([s for s in signals if s.tier == 'B']),
            'tier_C_count': len([s for s in signals if s.tier == 'C']),
            'tier_D_count': len([s for s in signals if s.tier == 'D'])
        }
    
    def _apply_diversification_constraints(self, signals: List[SignalRank]) -> List[SignalRank]:
        """Diversification kısıtlamalarını uygula"""
        selected = []
        used_assets = set()
        used_sectors = set()
        
        for signal in signals:
            asset = signal.signal_data.get('asset', 'unknown')
            sector = signal.signal_data.get('sector', 'unknown')
            
            # Check asset uniqueness
            if asset in used_assets:
                continue
            
            # Check sector concentration
            sector_count = len([s for s in selected if s.signal_data.get('sector') == sector])
            if sector_count >= 3:  # Max 3 signals per sector
                continue
            
            # Add to selection
            selected.append(signal)
            used_assets.add(asset)
            used_sectors.add(sector)
            
            # Stop if we have enough signals
            if len(selected) >= self.max_active_signals:
                break
        
        return selected
    
    def _analyze_diversification(self, signals: List[SignalRank]) -> Dict[str, float]:
        """Diversification analizi"""
        if len(signals) < 2:
            return {'diversification_score': 1.0}
        
        # Asset diversity
        assets = [s.signal_data.get('asset', 'unknown') for s in signals]
        asset_diversity = len(set(assets)) / len(assets)
        
        # Sector diversity
        sectors = [s.signal_data.get('sector', 'unknown') for s in signals]
        sector_diversity = len(set(sectors)) / len(sectors)
        
        # Score diversity (correlation between scores)
        scores = [s.composite_score for s in signals]
        score_correlation = np.corrcoef(scores[:-1], scores[1:])[0, 1] if len(scores) > 1 else 0
        score_diversity = 1.0 - abs(score_correlation)
        
        overall_diversification = (asset_diversity + sector_diversity + score_diversity) / 3
        
        return {
            'asset_diversity': asset_diversity,
            'sector_diversity': sector_diversity,
            'score_diversity': score_diversity,
            'diversification_score': overall_diversification,
            'unique_assets': len(set(assets)),
            'unique_sectors': len(set(sectors))
        }
    
    def _build_execution_queue(self, signals: List[SignalRank]) -> List[SignalRank]:
        """Execution queue oluştur"""
        # Priority queue based on composite score and urgency
        queue = []
        
        for signal in signals:
            if signal.tier in ['A', 'B']:  # Only high-tier signals
                queue.append(signal)
        
        # Sort by priority score
        queue.sort(key=lambda s: s.priority_score, reverse=True)
        
        return queue[:self.max_active_signals]
    
    def _re_categorize_signals(self):
        """Sinyalleri yeniden kategorize et"""
        active_threshold = 0.6  # Minimum score for active
        
        self.active_signals.clear()
        self.pending_signals.clear()
        
        for signal_id, signal_rank in self.signal_registry.items():
            if signal_rank.composite_score >= active_threshold and signal_rank.tier in ['A', 'B']:
                self.active_signals[signal_id] = signal_rank
            else:
                self.pending_signals[signal_id] = signal_rank
    
    def _check_selection_constraints(self, candidate: SignalRank, selected: List[SignalRank], constraints: Dict) -> bool:
        """Selection kısıtlamalarını kontrol et"""
        # Position size check
        candidate_size = candidate.signal_data.get('position_size', 0.1)
        max_size = constraints.get('max_position_size', 0.1)
        
        if candidate_size > max_size:
            return False
        
        # Sector concentration check
        candidate_sector = candidate.signal_data.get('sector', 'unknown')
        selected_in_sector = len([s for s in selected if s.signal_data.get('sector') == candidate_sector])
        max_sector = constraints.get('max_sector_concentration', 0.3)
        
        if selected_in_sector >= max_sector * self.max_active_signals:
            return False
        
        # Correlation check (simplified)
        # In real implementation, would calculate actual correlations
        
        return True
    
    def set_scoring_engine(self, scoring_engine):
        """Scoring engine'i ayarla"""
        self.scoring_engine = scoring_engine
    
    def set_portfolio_constraints(self, constraints: Dict):
        """Portfolio kısıtlamalarını ayarla"""
        self.portfolio_constraints.update(constraints)
    
    def export_ranking_history(self, n_recent: int = 100) -> List[Dict]:
        """Ranking geçmişini export et"""
        recent_history = self.ranking_history[-n_recent:] if len(self.ranking_history) > n_recent else self.ranking_history
        
        export_data = []
        for ranking_result in recent_history:
            export_data.append({
                'timestamp': ranking_result.timestamp.isoformat(),
                'total_signals': len(ranking_result.ranked_signals),
                'top_score': ranking_result.ranked_signals[0].composite_score if ranking_result.ranked_signals else 0,
                'average_score': ranking_result.summary_stats.get('mean_score', 0),
                'tier_A_count': ranking_result.summary_stats.get('tier_A_count', 0),
                'diversification_score': ranking_result.diversification_analysis.get('diversification_score', 0)
            })
        
        return export_data