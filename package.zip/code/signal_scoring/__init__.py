"""
Akıllı Sinyal Skorlama ve Ranking Sistemi
==========================================

Bu modül, tüm trading stratejilerinden gelen sinyalleri akıllıca skorlayan 
ve ranking yapan kapsamlı bir sistemdir.

Özellikler:
- Multi-factor scoring (Sharpe, win rate, max drawdown, stability)
- Market regime adjustment (trend/range market'te farklı skorlama)
- Confidence intervals ve uncertainty quantification
- Real-time signal ranking ve selection
- Account Managers ile seamless entegrasyon
- Ensemble scoring (weighted combination)
- Performance attribution analysis
"""

from .multi_factor_scorer import MultiFactorScorer
from .market_regime_detector import MarketRegimeDetector
from .confidence_calculator import ConfidenceCalculator
from .ensemble_scorer import EnsembleScorer
from .performance_attribution import PerformanceAttribution
from .signal_ranking import SignalRanking
from .account_manager_interface import AccountManagerInterface
from .signal_scoring_system import SignalScoringSystem

__version__ = "1.0.0"
__all__ = [
    "MultiFactorScorer",
    "MarketRegimeDetector", 
    "ConfidenceCalculator",
    "EnsembleScorer",
    "PerformanceAttribution",
    "SignalRanking",
    "AccountManagerInterface",
    "SignalScoringSystem"
]