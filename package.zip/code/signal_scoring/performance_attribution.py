"""
Performance Attribution Analizi
==============================

Sinyal skorlamasına katkı yapan faktörleri ve stratejileri analiz eden sistem.
Brinson modeli ve modern attribution teknikleri kullanır.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Union
from dataclasses import dataclass
from datetime import datetime, timedelta
import warnings

warnings.filterwarnings('ignore')


@dataclass
class AttributionFactor:
    """Attribution faktörü"""
    name: str
    contribution: float
    weight: float
    performance: float
    selection_effect: float
    allocation_effect: float
    interaction_effect: float


@dataclass
class PeriodAttribution:
    """Dönem bazlı attribution"""
    period_start: datetime
    period_end: datetime
    total_return: float
    benchmark_return: float
    active_return: float
    factor_contributions: Dict[str, AttributionFactor]
    strategy_contributions: Dict[str, float]


@dataclass
class AttributionSummary:
    """Attribution özeti"""
    total_active_return: float
    total_contributions: Dict[str, float]
    allocation_effect: float
    selection_effect: float
    interaction_effect: float
    attribution_r_squared: float
    tracking_error: float
    information_ratio: float


class PerformanceAttribution:
    """
    Performance attribution analysis sistemi
    
    Brinson-Fachler modeli ve modern attribution teknikleri kullanarak
    performansın kaynaklarını analiz eder.
    """
    
    def __init__(self, 
                 benchmark: str = 'SPY',
                 attribution_method: str = 'brinson_fachler',
                 rebalance_frequency: str = 'daily'):
        """
        Initialize performance attribution
        
        Args:
            benchmark: Benchmark sembol
            attribution_method: Attribution yöntemi
            rebalance_frequency: Yeniden dengeleme sıklığı
        """
        self.benchmark = benchmark
        self.attribution_method = attribution_method
        self.rebalance_frequency = rebalance_frequency
        
        self.attribution_history: List[PeriodAttribution] = []
        self.factor_definitions = self._initialize_factors()
        self.strategy_mappings = self._initialize_strategies()
    
    def analyze_period_attribution(self,
                                 portfolio_data: Dict,
                                 benchmark_data: Dict,
                                 factor_data: Dict,
                                 period_start: datetime,
                                 period_end: datetime) -> PeriodAttribution:
        """
        Belirli dönem için attribution analizi yap
        
        Args:
            portfolio_data: Portfolio verileri
            benchmark_data: Benchmark verileri
            factor_data: Factor verileri
            period_start: Dönem başlangıcı
            period_end: Dönem bitişi
        
        Returns:
            PeriodAttribution: Dönem attribution sonucu
        """
        # Dönem getirileri hesapla
        portfolio_return = self._calculate_period_return(portfolio_data, period_start, period_end)
        benchmark_return = self._calculate_period_return(benchmark_data, period_start, period_end)
        active_return = portfolio_return - benchmark_return
        
        # Factor contributions
        factor_contributions = self._calculate_factor_contributions(
            portfolio_data, benchmark_data, factor_data, period_start, period_end
        )
        
        # Strategy contributions
        strategy_contributions = self._calculate_strategy_contributions(
            portfolio_data, period_start, period_end
        )
        
        attribution = PeriodAttribution(
            period_start=period_start,
            period_end=period_end,
            total_return=portfolio_return,
            benchmark_return=benchmark_return,
            active_return=active_return,
            factor_contributions=factor_contributions,
            strategy_contributions=strategy_contributions
        )
        
        self.attribution_history.append(attribution)
        
        return attribution
    
    def comprehensive_attribution_analysis(self,
                                         portfolio_data: Dict,
                                         benchmark_data: Dict,
                                         factor_data: Dict,
                                         strategy_data: Dict,
                                         start_date: datetime,
                                         end_date: datetime) -> AttributionSummary:
        """
        Kapsamlı attribution analizi
        
        Args:
            portfolio_data: Portfolio verileri
            benchmark_data: Benchmark verileri
            factor_data: Factor verileri
            strategy_data: Strategy verileri
            start_date: Analiz başlangıç tarihi
            end_date: Analiz bitiş tarihi
        
        Returns:
            AttributionSummary: Kapsamlı attribution özeti
        """
        # Periyodik analizler yap
        period_attributions = self._analyze_periods(
            portfolio_data, benchmark_data, factor_data, strategy_data, start_date, end_date
        )
        
        # Toplam active return
        total_active_return = sum(attr.active_return for attr in period_attributions)
        
        # Factor contributions (weighted by time)
        total_contributions = self._aggregate_factor_contributions(period_attributions)
        
        # Allocation, selection, interaction effects
        allocation_effect, selection_effect, interaction_effect = self._calculate_brinson_effects(
            portfolio_data, benchmark_data, period_attributions
        )
        
        # Risk-adjusted metrics
        attribution_r_squared = self._calculate_attribution_r_squared(period_attributions)
        tracking_error = self._calculate_tracking_error(period_attributions)
        information_ratio = total_active_return / tracking_error if tracking_error > 0 else 0
        
        return AttributionSummary(
            total_active_return=total_active_return,
            total_contributions=total_contributions,
            allocation_effect=allocation_effect,
            selection_effect=selection_effect,
            interaction_effect=interaction_effect,
            attribution_r_squared=attribution_r_squared,
            tracking_error=tracking_error,
            information_ratio=information_ratio
        )
    
    def signal_level_attribution(self,
                               signal_data: Dict,
                               component_scores: Dict[str, float],
                               final_score: float) -> Dict[str, float]:
        """
        Tek sinyal için attribution analizi
        
        Args:
            signal_data: Sinyal verisi
            component_scores: Component skorları
            final_score: Final ensemble skoru
        
        Returns:
            Dict[str, float]: Sinyal level attribution
        """
        attribution = {}
        total_weighted_score = 0.0
        
        # Component contribution hesapla
        for component_name, component_score in component_scores.items():
            # Bu calculation ensemble weights'e bağlı olmalı
            # Simplified approach for now
            contribution = component_score * (1.0 / len(component_scores))
            attribution[component_name] = contribution
            total_weighted_score += contribution
        
        # Normalize to ensure sum equals final score
        if total_weighted_score != 0:
            scaling_factor = final_score / total_weighted_score
            attribution = {k: v * scaling_factor for k, v in attribution.items()}
        
        return attribution
    
    def strategy_performance_analysis(self,
                                    strategy_performance: Dict[str, Dict],
                                    portfolio_weights: Dict[str, float]) -> Dict[str, Dict]:
        """
        Strategy bazlı performans analizi
        
        Args:
            strategy_performance: Strategy performans verileri
            portfolio_weights: Portfolio ağırlıkları
        
        Returns:
            Dict[str, Dict]: Strategy analiz sonuçları
        """
        analysis = {}
        
        for strategy_name, performance in strategy_performance.items():
            weight = portfolio_weights.get(strategy_name, 0.0)
            
            # Risk-adjusted metrics
            annual_return = performance.get('annual_return', 0.0)
            volatility = performance.get('volatility', 0.0)
            sharpe_ratio = annual_return / volatility if volatility > 0 else 0
            
            # Active contribution
            contribution = weight * annual_return
            
            # Risk contribution
            risk_contribution = weight * volatility
            
            analysis[strategy_name] = {
                'weight': weight,
                'annual_return': annual_return,
                'volatility': volatility,
                'sharpe_ratio': sharpe_ratio,
                'active_contribution': contribution,
                'risk_contribution': risk_contribution,
                'information_ratio': performance.get('information_ratio', 0.0),
                'max_drawdown': performance.get('max_drawdown', 0.0),
                'win_rate': performance.get('win_rate', 0.0),
                'profit_factor': performance.get('profit_factor', 0.0)
            }
        
        return analysis
    
    def factor_exposure_analysis(self,
                               factor_loadings: Dict[str, float],
                               factor_returns: Dict[str, float]) -> Dict[str, float]:
        """
        Factor exposure analizi
        
        Args:
            factor_loadings: Factor yükleri (beta'lar)
            factor_returns: Factor getirileri
        
        Returns:
            Dict[str, float]: Factor contribution analizi
        """
        factor_contributions = {}
        total_contribution = 0.0
        
        for factor_name, loading in factor_loadings.items():
            if factor_name in factor_returns:
                contribution = loading * factor_returns[factor_name]
                factor_contributions[factor_name] = {
                    'loading': loading,
                    'factor_return': factor_returns[factor_name],
                    'contribution': contribution
                }
                total_contribution += contribution
        
        return {
            'factor_contributions': factor_contributions,
            'total_factor_contribution': total_contribution,
            'explained_return': total_contribution,
            'residual_return': 0.0  # Simplified
        }
    
    def temporal_attribution_analysis(self,
                                    attribution_history: List[PeriodAttribution],
                                    window_size: int = 30) -> Dict[str, Dict]:
        """
        Temporal (zaman boyutlu) attribution analizi
        
        Args:
            attribution_history: Attributions geçmişi
            window_size: Rolling window boyutu
        
        Returns:
            Dict[str, Dict]: Temporal analiz sonuçları
        """
        temporal_analysis = {}
        
        if len(attribution_history) < window_size:
            return temporal_analysis
        
        # Rolling attribution metrics
        rolling_active_returns = []
        rolling_factor_contributions = {}
        
        for i in range(len(attribution_history) - window_size + 1):
            window_attrs = attribution_history[i:i+window_size]
            
            # Rolling active return
            rolling_return = sum(attr.active_return for attr in window_attrs)
            rolling_active_returns.append(rolling_return)
            
            # Rolling factor contributions
            for factor_name in self.factor_definitions.keys():
                factor_contrib = sum(
                    attr.factor_contributions.get(factor_name, AttributionFactor("", 0, 0, 0, 0, 0, 0)).contribution
                    for attr in window_attrs
                )
                
                if factor_name not in rolling_factor_contributions:
                    rolling_factor_contributions[factor_name] = []
                rolling_factor_contributions[factor_name].append(factor_contrib)
        
        # Calculate statistics
        temporal_analysis['rolling_performance'] = {
            'mean_active_return': np.mean(rolling_active_returns),
            'std_active_return': np.std(rolling_active_returns),
            'max_active_return': np.max(rolling_active_returns),
            'min_active_return': np.min(rolling_active_returns)
        }
        
        temporal_analysis['rolling_factor_contributions'] = {}
        for factor_name, contributions in rolling_factor_contributions.items():
            temporal_analysis['rolling_factor_contributions'][factor_name] = {
                'mean_contribution': np.mean(contributions),
                'std_contribution': np.std(contributions),
                'consistency': 1.0 - (np.std(contributions) / (np.abs(np.mean(contributions)) + 1e-8))
            }
        
        return temporal_analysis
    
    def performance_ranking_analysis(self,
                                   strategy_performances: Dict[str, Dict],
                                   ranking_criteria: str = 'sharpe_ratio') -> List[Tuple[str, Dict]]:
        """
        Strategy performans sıralama analizi
        
        Args:
            strategy_performances: Strategy performans verileri
            ranking_criteria: Sıralama kriteri
        
        Returns:
            List[Tuple[str, Dict]]: Sıralanmış strategy listesi
        """
        if not strategy_performances:
            return []
        
        # Sort by criteria
        if ranking_criteria in ['sharpe_ratio', 'information_ratio']:
            # Higher is better
            sorted_strategies = sorted(
                strategy_performances.items(),
                key=lambda x: x[1].get(ranking_criteria, 0.0),
                reverse=True
            )
        elif ranking_criteria in ['max_drawdown', 'volatility']:
            # Lower is better
            sorted_strategies = sorted(
                strategy_performances.items(),
                key=lambda x: x[1].get(ranking_criteria, float('inf'))
            )
        elif ranking_criteria in ['annual_return', 'total_return']:
            # Higher is better
            sorted_strategies = sorted(
                strategy_performances.items(),
                key=lambda x: x[1].get(ranking_criteria, 0.0),
                reverse=True
            )
        else:
            # Default to Sharpe ratio
            sorted_strategies = sorted(
                strategy_performances.items(),
                key=lambda x: x[1].get('sharpe_ratio', 0.0),
                reverse=True
            )
        
        return sorted_strategies
    
    def risk_attribution_analysis(self,
                                risk_contributions: Dict[str, float],
                                portfolio_volatility: float) -> Dict[str, float]:
        """
        Risk attribution analizi
        
        Args:
            risk_contributions: Strategy risk katkıları
            portfolio_volatility: Portfolio volatilitesi
        
        Returns:
            Dict[str, float]: Risk attribution sonuçları
        """
        risk_attribution = {}
        
        for strategy, risk_contrib in risk_contributions.items():
            # Risk contribution percentage
            risk_percentage = risk_contrib / portfolio_volatility if portfolio_volatility > 0 else 0
            
            risk_attribution[strategy] = {
                'absolute_contribution': risk_contrib,
                'percentage_contribution': risk_percentage,
                'risk_adjusted_contribution': risk_contrib / (risk_contrib + 1e-8)
            }
        
        # Sort by risk contribution
        risk_attribution = dict(sorted(
            risk_attribution.items(),
            key=lambda x: x[1]['absolute_contribution'],
            reverse=True
        ))
        
        return risk_attribution
    
    def generate_attribution_report(self,
                                  attribution_summary: AttributionSummary,
                                  temporal_analysis: Dict[str, Dict],
                                  strategy_ranking: List[Tuple[str, Dict]]) -> Dict:
        """
        Attribution raporu oluştur
        
        Args:
            attribution_summary: Attribution özeti
            temporal_analysis: Temporal analiz
            strategy_ranking: Strategy sıralaması
        
        Returns:
            Dict: Comprehensive attribution report
        """
        report = {
            'executive_summary': {
                'total_active_return': attribution_summary.total_active_return,
                'information_ratio': attribution_summary.information_ratio,
                'tracking_error': attribution_summary.tracking_error,
                'attribution_r_squared': attribution_summary.attribution_r_squared
            },
            'performance_decomposition': {
                'allocation_effect': attribution_summary.allocation_effect,
                'selection_effect': attribution_summary.selection_effect,
                'interaction_effect': attribution_summary.interaction_effect
            },
            'factor_analysis': {
                'factor_contributions': attribution_summary.total_contributions,
                'top_factors': dict(list(attribution_summary.total_contributions.items())[:5])
            },
            'strategy_analysis': {
                'top_strategies': strategy_ranking[:5],
                'strategy_count': len(strategy_ranking)
            },
            'temporal_analysis': temporal_analysis,
            'risk_analysis': {
                'tracking_error_risk': attribution_summary.tracking_error,
                'performance_consistency': temporal_analysis.get('rolling_performance', {}).get('std_active_return', 0.0)
            },
            'recommendations': self._generate_recommendations(attribution_summary, strategy_ranking)
        }
        
        return report
    
    def _initialize_factors(self) -> Dict[str, str]:
        """Factor tanımlarını başlat"""
        return {
            'momentum': 'Price momentum factor',
            'value': 'Value factor',
            'quality': 'Quality factor',
            'size': 'Size factor',
            'low_vol': 'Low volatility factor',
            'growth': 'Growth factor',
            'reversal': 'Mean reversion factor'
        }
    
    def _initialize_strategies(self) -> Dict[str, str]:
        """Strategy mapping'leri başlat"""
        return {
            'momentum_strategy': 'Momentum based trading',
            'mean_reversion': 'Mean reversion strategy',
            'trend_following': 'Trend following',
            'breakout': 'Breakout strategy',
            'pairs_trading': 'Pairs trading',
            'risk_arbitrage': 'Risk arbitrage'
        }
    
    def _calculate_period_return(self, data: Dict, start: datetime, end: datetime) -> float:
        """Dönem getirisi hesapla"""
        # Simplified - real implementation would handle actual date ranges
        return data.get('period_return', 0.0)
    
    def _calculate_factor_contributions(self, portfolio_data: Dict, benchmark_data: Dict, 
                                      factor_data: Dict, start: datetime, end: datetime) -> Dict[str, AttributionFactor]:
        """Factor contribution'larını hesapla"""
        contributions = {}
        
        for factor_name, factor_def in self.factor_definitions.items():
            # Simplified factor loading and return calculation
            factor_return = factor_data.get(factor_name, {}).get('return', 0.0)
            factor_weight = portfolio_data.get('factor_weights', {}).get(factor_name, 0.0)
            
            contribution = factor_weight * factor_return
            
            contributions[factor_name] = AttributionFactor(
                name=factor_name,
                contribution=contribution,
                weight=factor_weight,
                performance=factor_return,
                selection_effect=0.0,  # Simplified
                allocation_effect=0.0,  # Simplified
                interaction_effect=0.0  # Simplified
            )
        
        return contributions
    
    def _calculate_strategy_contributions(self, portfolio_data: Dict, start: datetime, end: datetime) -> Dict[str, float]:
        """Strategy contribution'larını hesapla"""
        strategy_weights = portfolio_data.get('strategy_weights', {})
        strategy_returns = portfolio_data.get('strategy_returns', {})
        
        contributions = {}
        for strategy_name, weight in strategy_weights.items():
            strategy_return = strategy_returns.get(strategy_name, 0.0)
            contributions[strategy_name] = weight * strategy_return
        
        return contributions
    
    def _analyze_periods(self, portfolio_data: Dict, benchmark_data: Dict, factor_data: Dict,
                        strategy_data: Dict, start_date: datetime, end_date: datetime) -> List[PeriodAttribution]:
        """Periyodik analizler yap"""
        period_attributions = []
        
        # Monthly breakdown
        current_date = start_date
        while current_date < end_date:
            period_end = min(current_date + timedelta(days=30), end_date)
            
            attribution = self.analyze_period_attribution(
                portfolio_data, benchmark_data, factor_data,
                current_date, period_end
            )
            
            period_attributions.append(attribution)
            current_date = period_end
        
        return period_attributions
    
    def _aggregate_factor_contributions(self, period_attributions: List[PeriodAttribution]) -> Dict[str, float]:
        """Factor contribution'ları birleştir"""
        total_contributions = {}
        
        for attribution in period_attributions:
            for factor_name, factor in attribution.factor_contributions.items():
                if factor_name not in total_contributions:
                    total_contributions[factor_name] = 0.0
                total_contributions[factor_name] += factor.contribution
        
        return total_contributions
    
    def _calculate_brinson_effects(self, portfolio_data: Dict, benchmark_data: Dict, 
                                 period_attributions: List[PeriodAttribution]) -> Tuple[float, float, float]:
        """Brinson-Fachler effects hesapla"""
        # Simplified implementation
        allocation_effect = 0.0
        selection_effect = 0.0
        interaction_effect = 0.0
        
        for attribution in period_attributions:
            allocation_effect += attribution.active_return * 0.3  # Simplified
            selection_effect += attribution.active_return * 0.5   # Simplified
            interaction_effect += attribution.active_return * 0.2  # Simplified
        
        return allocation_effect, selection_effect, interaction_effect
    
    def _calculate_attribution_r_squared(self, period_attributions: List[PeriodAttribution]) -> float:
        """Attribution R-squared hesapla"""
        if not period_attributions:
            return 0.0
        
        active_returns = [attr.active_return for attr in period_attributions]
        explained_returns = []
        
        for attribution in period_attributions:
            explained = sum(factor.contribution for factor in attribution.factor_contributions.values())
            explained_returns.append(explained)
        
        # Simple correlation-based R-squared
        if len(active_returns) > 1:
            correlation = np.corrcoef(active_returns, explained_returns)[0, 1]
            return correlation ** 2 if not np.isnan(correlation) else 0.0
        
        return 0.0
    
    def _calculate_tracking_error(self, period_attributions: List[PeriodAttribution]) -> float:
        """Tracking error hesapla"""
        if not period_attributions:
            return 0.0
        
        active_returns = [attr.active_return for attr in period_attributions]
        return np.std(active_returns) if len(active_returns) > 1 else 0.0
    
    def _generate_recommendations(self, attribution_summary: AttributionSummary, 
                                strategy_ranking: List[Tuple[str, Dict]]) -> List[str]:
        """Attribution analizine dayalı öneriler oluştur"""
        recommendations = []
        
        # Performance-based recommendations
        if attribution_summary.information_ratio > 0.5:
            recommendations.append("Strong information ratio indicates good active management")
        elif attribution_summary.information_ratio < 0.2:
            recommendations.append("Low information ratio suggests need for strategy refinement")
        
        # Allocation recommendations
        if attribution_summary.allocation_effect > attribution_summary.selection_effect:
            recommendations.append("Allocation decisions are driving performance more than selection")
        
        # Strategy recommendations
        if strategy_ranking:
            top_strategy = strategy_ranking[0]
            if top_strategy[1].get('sharpe_ratio', 0) > 1.0:
                recommendations.append(f"Consider increasing allocation to top strategy: {top_strategy[0]}")
            
            worst_strategy = strategy_ranking[-1]
            if worst_strategy[1].get('sharpe_ratio', 0) < 0.0:
                recommendations.append(f"Consider reducing allocation to underperforming strategy: {worst_strategy[0]}")
        
        return recommendations