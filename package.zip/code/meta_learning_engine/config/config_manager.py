"""
Meta-Learning Engine Konfigürasyon Modülü
========================================

Bu modül, Meta-Learning Engine'in yapılandırma ayarlarını yönetir.
"""

import os
import json
import logging
from typing import Dict, Any, Optional
from dataclasses import dataclass, asdict

@dataclass
class MetaLearningEngineConfig:
    """Meta-Learning Engine ana yapılandırması"""
    update_frequency: int = 60  # saniye
    performance_threshold: float = 0.05
    regime_change_threshold: float = 0.1
    drift_detection_threshold: float = 0.05
    max_parallel_processes: int = 4
    enable_real_time_learning: bool = True
    enable_ab_testing: bool = True
    enable_hyperparameter_optimization: bool = True
    risk_aware: bool = True
    
@dataclass
class MonitoringConfig:
    """İzleme sistemi yapılandırması"""
    lookback_window: int = 252
    performance_thresholds: Dict[str, float] = None
    alert_levels: Dict[str, str] = None
    email_config: Dict[str, Any] = None
    webhook_config: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.performance_thresholds is None:
            self.performance_thresholds = {
                'sharpe_ratio': 1.0,
                'max_drawdown': 0.15,
                'var_95': 0.05,
                'win_rate': 0.45,
                'profit_factor': 1.2
            }
        
        if self.alert_levels is None:
            self.alert_levels = {
                'info': ['console', 'file'],
                'warning': ['console', 'email', 'file'],
                'error': ['console', 'email', 'webhook', 'file'],
                'critical': ['console', 'email', 'webhook', 'file']
            }

@dataclass
class AnalysisConfig:
    """Analiz sistemi yapılandırması"""
    strategy_analysis: Dict[str, Any] = None
    regime_detection: Dict[str, Any] = None
    drift_detection: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.strategy_analysis is None:
            self.strategy_analysis = {
                'lookback_days': 252,
                'performance_thresholds': {
                    'sharpe_ratio': 1.0,
                    'max_drawdown': 0.20,
                    'win_rate': 0.45,
                    'profit_factor': 1.2,
                    'volatility': 0.30
                }
            }
        
        if self.regime_detection is None:
            self.regime_detection = {
                'n_regimes': 4,
                'transition_threshold': 0.7,
                'min_regime_duration': 10
            }
        
        if self.drift_detection is None:
            self.drift_detection = {
                'window_size': 100,
                'significance_level': 0.05,
                'drift_thresholds': {
                    'performance_drift': 0.1,
                    'distribution_drift': 0.05,
                    'concept_drift': 0.15
                }
            }

@dataclass
class AutomationConfig:
    """Otomasyon sistemi yapılandırması"""
    strategy_control: Dict[str, Any] = None
    ab_testing: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.strategy_control is None:
            self.strategy_control = {
                'auto_activation_enabled': True,
                'auto_deactivation_enabled': True,
                'parameter_adjustment_enabled': True,
                'min_performance_threshold': 0.02,
                'max_drawdown_threshold': 0.20,
                'correlation_threshold': 0.80
            }
        
        if self.ab_testing is None:
            self.ab_testing = {
                'max_concurrent_tests': 10,
                'significance_level': 0.05,
                'minimum_sample_size': 100,
                'maximum_test_duration_days': 30
            }

@dataclass
class OptimizationConfig:
    """Optimizasyon sistemi yapılandırması"""
    hyperparameter_optimization: Dict[str, Any] = None
    correlation_analysis: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.hyperparameter_optimization is None:
            self.hyperparameter_optimization = {
                'max_concurrent_jobs': 5,
                'optimization_methods': [
                    'grid_search', 'bayesian', 'random_search', 
                    'genetic', 'particle_swarm'
                ],
                'default_parameter_spaces': {
                    'trading_strategy': {
                        'lookback_period': [10, 100],
                        'threshold': [0.001, 0.1],
                        'max_position_size': [0.05, 0.5],
                        'stop_loss': [0.005, 0.05],
                        'take_profit': [0.01, 0.2]
                    }
                }
            }
        
        if self.correlation_analysis is None:
            self.correlation_analysis = {
                'correlation_threshold': 0.8,
                'lookback_window': 252,
                'update_frequency': 60
            }

@dataclass
class LearningConfig:
    """Öğrenme sistemi yapılandırması"""
    real_time_learning: Dict[str, Any] = None
    model_management: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.real_time_learning is None:
            self.real_time_learning = {
                'learning_rate': 0.01,
                'max_models': 20,
                'min_samples_for_training': 10,
                'retrain_threshold': 0.05,
                'learning_frequency_minutes': 60
            }
        
        if self.model_management is None:
            self.model_management = {
                'auto_save_models': True,
                'model_retention_days': 30,
                'enable_feature_importance': True,
                'incremental_learning': True
            }

@dataclass
class IntegrationConfig:
    """Entegrasyon sistemi yapılandırması"""
    system_connections: Dict[str, Any] = None
    sync_settings: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.system_connections is None:
            self.system_connections = {
                'risk_management_system': {
                    'connection_type': 'api',
                    'endpoint': 'http://localhost:8000/risk_management'
                },
                'portfolio_optimizer': {
                    'connection_type': 'api',
                    'endpoint': 'http://localhost:8000/portfolio_optimizer'
                },
                'backtest_engine': {
                    'connection_type': 'api',
                    'endpoint': 'http://localhost:8000/backtest_engine'
                }
            }
        
        if self.sync_settings is None:
            self.sync_settings = {
                'auto_sync_enabled': True,
                'sync_interval_seconds': 60,
                'retry_attempts': 3,
                'timeout_seconds': 30,
                'batch_size': 100,
                'enable_real_time_updates': True,
                'failover_enabled': True
            }

class ConfigManager:
    """Konfigürasyon yöneticisi"""
    
    def __init__(self, config_path: str = "config/meta_learning_config.json"):
        self.config_path = config_path
        self.logger = logging.getLogger(__name__)
        
        # Varsayılan konfigürasyonlar
        self.meta_learning_config = MetaLearningEngineConfig()
        self.monitoring_config = MonitoringConfig()
        self.analysis_config = AnalysisConfig()
        self.automation_config = AutomationConfig()
        self.optimization_config = OptimizationConfig()
        self.learning_config = LearningConfig()
        self.integration_config = IntegrationConfig()
        
        # Konfigürasyonu yükle
        self.load_config()
    
    def load_config(self):
        """Konfigürasyonu dosyadan yükle"""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    config_data = json.load(f)
                
                # Her konfigürasyonu güncelle
                if 'meta_learning' in config_data:
                    self._update_config(self.meta_learning_config, config_data['meta_learning'])
                
                if 'monitoring' in config_data:
                    self._update_config(self.monitoring_config, config_data['monitoring'])
                
                if 'analysis' in config_data:
                    self._update_config(self.analysis_config, config_data['analysis'])
                
                if 'automation' in config_data:
                    self._update_config(self.automation_config, config_data['automation'])
                
                if 'optimization' in config_data:
                    self._update_config(self.optimization_config, config_data['optimization'])
                
                if 'learning' in config_data:
                    self._update_config(self.learning_config, config_data['learning'])
                
                if 'integration' in config_data:
                    self._update_config(self.integration_config, config_data['integration'])
                
                self.logger.info(f"Konfigürasyon yüklendi: {self.config_path}")
            else:
                self.logger.info("Konfigürasyon dosyası bulunamadı, varsayılan değerler kullanılıyor")
                self.save_config()
                
        except Exception as e:
            self.logger.error(f"Konfigürasyon yükleme hatası: {e}")
    
    def save_config(self):
        """Konfigürasyonu dosyaya kaydet"""
        try:
            # Konfigürasyon dizinini oluştur
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            
            # Tüm konfigürasyonları birleştir
            config_data = {
                'meta_learning': asdict(self.meta_learning_config),
                'monitoring': asdict(self.monitoring_config),
                'analysis': asdict(self.analysis_config),
                'automation': asdict(self.automation_config),
                'optimization': asdict(self.optimization_config),
                'learning': asdict(self.learning_config),
                'integration': asdict(self.integration_config)
            }
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(config_data, f, indent=2, ensure_ascii=False)
            
            self.logger.info(f"Konfigürasyon kaydedildi: {self.config_path}")
            
        except Exception as e:
            self.logger.error(f"Konfigürasyon kaydetme hatası: {e}")
    
    def _update_config(self, config_obj: Any, config_data: Dict[str, Any]):
        """Konfigürasyon objesini güncelle"""
        for key, value in config_data.items():
            if hasattr(config_obj, key):
                setattr(config_obj, key, value)
    
    def get_config_summary(self) -> Dict[str, Any]:
        """Konfigürasyon özetini getir"""
        return {
            'meta_learning': {
                'update_frequency': self.meta_learning_config.update_frequency,
                'enable_real_time_learning': self.meta_learning_config.enable_real_time_learning,
                'enable_ab_testing': self.meta_learning_config.enable_ab_testing,
                'enable_hyperparameter_optimization': self.meta_learning_config.enable_hyperparameter_optimization
            },
            'monitoring': {
                'lookback_window': self.monitoring_config.lookback_window,
                'performance_thresholds': self.monitoring_config.performance_thresholds
            },
            'analysis': {
                'regime_detection': self.analysis_config.regime_detection,
                'drift_detection': self.analysis_config.drift_detection
            },
            'automation': {
                'max_concurrent_tests': self.automation_config.ab_testing.get('max_concurrent_tests', 10)
            },
            'optimization': {
                'max_concurrent_jobs': self.optimization_config.hyperparameter_optimization.get('max_concurrent_jobs', 5)
            },
            'learning': {
                'max_models': self.learning_config.real_time_learning.get('max_models', 20),
                'learning_frequency_minutes': self.learning_config.real_time_learning.get('learning_frequency_minutes', 60)
            },
            'integration': {
                'connected_systems': len(self.integration_config.system_connections),
                'sync_interval_seconds': self.integration_config.sync_settings.get('sync_interval_seconds', 60)
            }
        }
    
    def update_config(self, section: str, key: str, value: Any):
        """Belirli bir konfigürasyon değerini güncelle"""
        config_mapping = {
            'meta_learning': self.meta_learning_config,
            'monitoring': self.monitoring_config,
            'analysis': self.analysis_config,
            'automation': self.automation_config,
            'optimization': self.optimization_config,
            'learning': self.learning_config,
            'integration': self.integration_config
        }
        
        if section in config_mapping:
            config_obj = config_mapping[section]
            if hasattr(config_obj, key):
                setattr(config_obj, key, value)
                self.save_config()
                self.logger.info(f"Konfigürasyon güncellendi: {section}.{key} = {value}")
            else:
                self.logger.error(f"Konfigürasyon anahtarı bulunamadı: {section}.{key}")
        else:
            self.logger.error(f"Konfigürasyon bölümü bulunamadı: {section}")

# Global config manager instance
config_manager = ConfigManager()