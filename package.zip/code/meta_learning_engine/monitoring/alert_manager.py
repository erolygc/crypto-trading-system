"""
Alert Manager - Uyarı Yönetim Sistemi
===================================

Bu modül, sistem uyarılarını yönetir ve dağıtır.
"""

import logging
import json
import smtplib
from email.mime.text import MimeText
from email.mime.multipart import MimeMultipart
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, asdict
from datetime import datetime
from collections import defaultdict, deque
import threading
import time

@dataclass
class Alert:
    """Uyarı veri yapısı"""
    id: str
    timestamp: float
    level: str  # info, warning, error, critical
    component: str
    message: str
    data: Dict[str, Any]
    acknowledged: bool = False
    resolved: bool = False

class AlertManager:
    """
    Uyarı Yönetim Sistemi
    
    Sistem uyarılarını toplar, filtreler ve çeşitli kanallar üzerinden dağıtır.
    """
    
    def __init__(self, max_alerts: int = 1000):
        """
        Alert Manager başlat
        
        Args:
            max_alerts: Saklanacak maksimum uyarı sayısı
        """
        self.logger = logging.getLogger(__name__)
        self.max_alerts = max_alerts
        
        # Uyarıları sakla
        self.alerts = deque(maxlen=max_alerts)
        self.alert_rules = deque(maxlen=100)
        
        # Bildirim kanalları
        self.notification_channels = {
            'console': self._send_console_alert,
            'email': self._send_email_alert,
            'webhook': self._send_webhook_alert,
            'file': self._send_file_alert
        }
        
        # Uyarı istatistikleri
        self.alert_stats = defaultdict(int)
        self.alert_history = defaultdict(deque)
        
        # Yapılandırma
        self.config = {
            'email': {
                'smtp_server': 'smtp.gmail.com',
                'smtp_port': 587,
                'username': '',
                'password': '',
                'recipients': []
            },
            'webhook': {
                'url': '',
                'headers': {'Content-Type': 'application/json'}
            },
            'file': {
                'path': 'alerts.jsonl',
                'append': True
            },
            'levels': {
                'info': ['console', 'file'],
                'warning': ['console', 'email', 'file'],
                'error': ['console', 'email', 'webhook', 'file'],
                'critical': ['console', 'email', 'webhook', 'file']
            }
        }
        
        self.logger.info("Alert Manager başlatıldı")
    
    def configure_email(self, smtp_server: str, smtp_port: int, username: str, 
                       password: str, recipients: List[str]):
        """
        Email yapılandırması
        
        Args:
            smtp_server: SMTP sunucu
            smtp_port: SMTP port
            username: Kullanıcı adı
            password: Şifre
            recipients: Alıcı listesi
        """
        self.config['email'].update({
            'smtp_server': smtp_server,
            'smtp_port': smtp_port,
            'username': username,
            'password': password,
            'recipients': recipients
        })
        self.logger.info("Email yapılandırması güncellendi")
    
    def configure_webhook(self, url: str, headers: Dict[str, str] = None):
        """
        Webhook yapılandırması
        
        Args:
            url: Webhook URL
            headers: HTTP başlıkları
        """
        self.config['webhook'].update({
            'url': url,
            'headers': headers or {'Content-Type': 'application/json'}
        })
        self.logger.info("Webhook yapılandırması güncellendi")
    
    def configure_file(self, filepath: str, append: bool = True):
        """
        Dosya yapılandırması
        
        Args:
            filepath: Dosya yolu
            append: Ekleme modu
        """
        self.config['file'].update({
            'path': filepath,
            'append': append
        })
        self.logger.info("Dosya yapılandırması güncellendi")
    
    def add_alert_rule(self, rule: Dict[str, Any]):
        """
        Uyarı kuralı ekle
        
        Args:
            rule: Uyarı kuralı
        """
        self.alert_rules.append(rule)
        self.logger.info(f"Uyarı kuralı eklendi: {rule.get('name', 'Unknown')}")
    
    def send_alert(self, level: str, message: str, component: str = "meta_learning_engine",
                  data: Dict[str, Any] = None, immediate: bool = True) -> str:
        """
        Uyarı gönder
        
        Args:
            level: Uyarı seviyesi (info, warning, error, critical)
            message: Uyarı mesajı
            component: Bileşen adı
            data: Ek veriler
            immediate: Anında gönder
        
        Returns:
            str: Uyarı ID'si
        """
        alert_id = f"{component}_{int(time.time() * 1000000)}"
        
        alert = Alert(
            id=alert_id,
            timestamp=time.time(),
            level=level,
            component=component,
            message=message,
            data=data or {}
        )
        
        self.alerts.append(alert)
        self.alert_stats[level] += 1
        self.alert_history[level].append(alert)
        
        # Uyarı kurallarını kontrol et
        triggered_rules = self._check_alert_rules(alert)
        
        if immediate or triggered_rules:
            self._distribute_alert(alert, triggered_rules)
        
        self.logger.info(f"Uyarı gönderildi [{level}]: {message}")
        return alert_id
    
    def _check_alert_rules(self, alert: Alert) -> List[Dict[str, Any]]:
        """
        Uyarı kurallarını kontrol et
        
        Args:
            alert: Uyarı objesi
        
        Returns:
            List[Dict]: Tetiklenen kurallar
        """
        triggered_rules = []
        
        for rule in self.alert_rules:
            try:
                if self._evaluate_rule(rule, alert):
                    triggered_rules.append(rule)
            except Exception as e:
                self.logger.error(f"Kural değerlendirme hatası: {e}")
        
        return triggered_rules
    
    def _evaluate_rule(self, rule: Dict[str, Any], alert: Alert) -> bool:
        """
        Kuralı değerlendir
        
        Args:
            rule: Uyarı kuralı
            alert: Uyarı objesi
        
        Returns:
            bool: Kuralın tetiklenip tetiklenmediği
        """
        # Seviye kontrolü
        if 'level' in rule and alert.level not in rule['level']:
            return False
        
        # Bileşen kontrolü
        if 'component' in rule and alert.component not in rule['component']:
            return False
        
        # Mesaj kontrolü
        if 'message_contains' in rule:
            if rule['message_contains'] not in alert.message:
                return False
        
        # Frekans kontrolü
        if 'frequency_threshold' in rule:
            recent_alerts = [a for a in self.alert_history.get(alert.level, []) 
                           if a.timestamp > time.time() - 3600]  # Son 1 saat
            if len(recent_alerts) >= rule['frequency_threshold']:
                return True
        
        return True
    
    def _distribute_alert(self, alert: Alert, triggered_rules: List[Dict[str, Any]]):
        """
        Uyarıyı dağıt
        
        Args:
            alert: Uyarı objesi
            triggered_rules: Tetiklenen kurallar
        """
        # Seviyeye göre kanalları belirle
        channels = self.config['levels'].get(alert.level, ['console'])
        
        # Tetiklenen kurallar varsa, onların kanallarını da ekle
        for rule in triggered_rules:
            if 'channels' in rule:
                channels.extend(rule['channels'])
        
        channels = list(set(channels))  # Tekrarları kaldır
        
        # Kanallar üzerinden gönder
        for channel in channels:
            try:
                self.notification_channels[channel](alert)
            except Exception as e:
                self.logger.error(f"Kanal gönderim hatası ({channel}): {e}")
    
    def _send_console_alert(self, alert: Alert):
        """Konsol uyarısı gönder"""
        timestamp = datetime.fromtimestamp(alert.timestamp).strftime('%Y-%m-%d %H:%M:%S')
        
        # Seviyeye göre renk kodları
        colors = {
            'info': '\033[94m',      # Mavi
            'warning': '\033[93m',   # Sarı
            'error': '\033[91m',     # Kırmızı
            'critical': '\033[95m'   # Mor
        }
        reset_color = '\033[0m'
        
        color = colors.get(alert.level, '')
        print(f"{color}[{timestamp}] {alert.level.upper()}: {alert.message}{reset_color}")
    
    def _send_email_alert(self, alert: Alert):
        """Email uyarısı gönder"""
        email_config = self.config['email']
        
        if not all([email_config['smtp_server'], email_config['username'], 
                   email_config['password'], email_config['recipients']]):
            self.logger.warning("Email yapılandırması eksik")
            return
        
        try:
            # Email içeriği oluştur
            subject = f"[{alert.level.upper()}] Meta-Learning Engine - {alert.component}"
            
            body = f"""
Uyarı Detayları:
- Zaman: {datetime.fromtimestamp(alert.timestamp).strftime('%Y-%m-%d %H:%M:%S')}
- Seviye: {alert.level}
- Bileşen: {alert.component}
- Mesaj: {alert.message}

Ek Veriler:
{json.dumps(alert.data, indent=2, ensure_ascii=False)}
            """
            
            # Email gönder
            msg = MimeMultipart()
            msg['From'] = email_config['username']
            msg['To'] = ', '.join(email_config['recipients'])
            msg['Subject'] = subject
            msg.attach(MimeText(body, 'plain', 'utf-8'))
            
            server = smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port'])
            server.starttls()
            server.login(email_config['username'], email_config['password'])
            server.send_message(msg)
            server.quit()
            
            self.logger.info(f"Email uyarısı gönderildi: {alert.id}")
            
        except Exception as e:
            self.logger.error(f"Email gönderim hatası: {e}")
    
    def _send_webhook_alert(self, alert: Alert):
        """Webhook uyarısı gönder"""
        import requests
        
        webhook_config = self.config['webhook']
        
        if not webhook_config['url']:
            self.logger.warning("Webhook URL yapılandırması eksik")
            return
        
        try:
            payload = {
                'alert_id': alert.id,
                'timestamp': alert.timestamp,
                'level': alert.level,
                'component': alert.component,
                'message': alert.message,
                'data': alert.data
            }
            
            response = requests.post(
                webhook_config['url'],
                json=payload,
                headers=webhook_config['headers'],
                timeout=10
            )
            
            response.raise_for_status()
            self.logger.info(f"Webhook uyarısı gönderildi: {alert.id}")
            
        except Exception as e:
            self.logger.error(f"Webhook gönderim hatası: {e}")
    
    def _send_file_alert(self, alert: Alert):
        """Dosya uyarısı gönder"""
        file_config = self.config['file']
        
        try:
            mode = 'a' if file_config['append'] else 'w'
            
            with open(file_config['path'], mode, encoding='utf-8') as f:
                f.write(json.dumps(asdict(alert), ensure_ascii=False) + '\n')
            
            self.logger.debug(f"Dosya uyarısı kaydedildi: {alert.id}")
            
        except Exception as e:
            self.logger.error(f"Dosya yazma hatası: {e}")
    
    def acknowledge_alert(self, alert_id: str) -> bool:
        """
        Uyarıyı onayla
        
        Args:
            alert_id: Uyarı ID'si
        
        Returns:
            bool: İşlem başarısı
        """
        for alert in self.alerts:
            if alert.id == alert_id:
                alert.acknowledged = True
                self.logger.info(f"Uyarı onaylandı: {alert_id}")
                return True
        
        return False
    
    def resolve_alert(self, alert_id: str) -> bool:
        """
        Uyarıyı çözülmüş olarak işaretle
        
        Args:
            alert_id: Uyarı ID'si
        
        Returns:
            bool: İşlem başarısı
        """
        for alert in self.alerts:
            if alert.id == alert_id:
                alert.resolved = True
                self.logger.info(f"Uyarı çözüldü: {alert_id}")
                return True
        
        return False
    
    def get_active_alerts(self, level: Optional[str] = None) -> List[Alert]:
        """
        Aktif uyarıları getir
        
        Args:
            level: Uyarı seviyesi filtresi
        
        Returns:
            List[Alert]: Aktif uyarılar
        """
        active_alerts = [alert for alert in self.alerts if not alert.resolved]
        
        if level:
            active_alerts = [alert for alert in active_alerts if alert.level == level]
        
        return sorted(active_alerts, key=lambda x: x.timestamp, reverse=True)
    
    def get_alert_statistics(self, time_window_hours: int = 24) -> Dict[str, Any]:
        """
        Uyarı istatistiklerini getir
        
        Args:
            time_window_hours: Zaman penceresi (saat)
        
        Returns:
            Dict: İstatistikler
        """
        cutoff_time = time.time() - (time_window_hours * 3600)
        recent_alerts = [alert for alert in self.alerts if alert.timestamp > cutoff_time]
        
        stats = {
            'total_alerts': len(recent_alerts),
            'by_level': {},
            'by_component': {},
            'acknowledged': len([a for a in recent_alerts if a.acknowledged]),
            'resolved': len([a for a in recent_alerts if a.resolved]),
            'time_window_hours': time_window_hours
        }
        
        # Seviyeye göre sayım
        for level in ['info', 'warning', 'error', 'critical']:
            stats['by_level'][level] = len([a for a in recent_alerts if a.level == level])
        
        # Bileşene göre sayım
        components = set(alert.component for alert in recent_alerts)
        for component in components:
            stats['by_component'][component] = len([a for a in recent_alerts if a.component == component])
        
        return stats