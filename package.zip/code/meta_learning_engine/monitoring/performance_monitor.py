"""
Performance Monitor - Performans İzleme Sistemi
===============================================

Bu modül, trading sistemlerinin performans metriklerini toplar ve analiz eder.
"""

import logging
import time
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import threading
from collections import defaultdict, deque

@dataclass
class PerformanceMetrics:
    """Performans metrikleri veri yapısı"""
    timestamp: float
    total_return: float
    sharpe_ratio: float
    max_drawdown: float
    win_rate: float
    profit_factor: float
    volatility: float
    var_95: float  # Value at Risk %95
    cvar_95: float  # Conditional Value at Risk %95
    calmar_ratio: float
    sortino_ratio: float
    information_ratio: float
    beta: float
    alpha: float
    tracking_error: float
    strategy_returns: Dict[str, float]
    risk_metrics: Dict[str, float]

class PerformanceMonitor:
    """
    Performans İzleme Sistemi
    
    Gerçek zamanlı performans metriklerini toplar, hesaplar ve izler.
    """
    
    def __init__(self, lookback_window: int = 252):
        """
        Performance Monitor başlat
        
        Args:
            lookback_window: Geçmişe bakma penceresi (gün sayısı)
        """
        self.logger = logging.getLogger(__name__)
        self.lookback_window = lookback_window
        
        # Performans verilerini sakla
        self.metrics_history = deque(maxlen=lookback_window)
        self.strategy_performance = defaultdict(deque)
        self.risk_metrics_history = deque(maxlen=lookback_window)
        
        # Sistemin bağlı olduğu kaynaklar
        self.data_sources = {}
        self.strategy_managers = {}
        
        # Eşik değerler
        self.performance_thresholds = {
            'sharpe_ratio': 1.0,
            'max_drawdown': 0.15,
            'var_95': 0.05,
            'win_rate': 0.45,
            'profit_factor': 1.2
        }
        
        self.logger.info("Performance Monitor başlatıldı")
    
    def register_data_source(self, name: str, source: Any):
        """
        Veri kaynağını kaydet
        
        Args:
            name: Veri kaynağı adı
            source: Veri kaynağı objesi
        """
        self.data_sources[name] = source
        self.logger.info(f"Veri kaynağı kaydedildi: {name}")
    
    def register_strategy_manager(self, name: str, manager: Any):
        """
        Strateji yöneticisini kaydet
        
        Args:
            name: Strateji yöneticisi adı
            manager: Strateji yöneticisi objesi
        """
        self.strategy_managers[name] = manager
        self.logger.info(f"Strateji yöneticisi kaydedildi: {name}")
    
    def collect_metrics(self) -> PerformanceMetrics:
        """
        Anlık performans metriklerini topla
        
        Returns:
            PerformanceMetrics: Hesaplanan performans metrikleri
        """
        try:
            # Veri kaynaklarından veri topla
            market_data = self._collect_market_data()
            portfolio_data = self._collect_portfolio_data()
            strategy_data = self._collect_strategy_data()
            
            # Temel metrikleri hesapla
            timestamp = time.time()
            returns = self._calculate_returns(portfolio_data)
            
            metrics = PerformanceMetrics(
                timestamp=timestamp,
                total_return=self._calculate_total_return(returns),
                sharpe_ratio=self._calculate_sharpe_ratio(returns),
                max_drawdown=self._calculate_max_drawdown(portfolio_data),
                win_rate=self._calculate_win_rate(returns),
                profit_factor=self._calculate_profit_factor(returns),
                volatility=self._calculate_volatility(returns),
                var_95=self._calculate_var(returns, confidence=0.95),
                cvar_95=self._calculate_cvar(returns, confidence=0.95),
                calmar_ratio=self._calculate_calmar_ratio(returns),
                sortino_ratio=self._calculate_sortino_ratio(returns),
                information_ratio=self._calculate_information_ratio(returns, market_data),
                beta=self._calculate_beta(returns, market_data),
                alpha=self._calculate_alpha(returns, market_data),
                tracking_error=self._calculate_tracking_error(returns, market_data),
                strategy_returns=strategy_data,
                risk_metrics=self._calculate_risk_metrics(returns, portfolio_data)
            )
            
            # Geçmişe ekle
            self.metrics_history.append(metrics)
            for strategy, return_val in strategy_data.items():
                self.strategy_performance[strategy].append({
                    'timestamp': timestamp,
                    'return': return_val
                })
            
            return metrics
            
        except Exception as e:
            self.logger.error(f"Metrik toplama hatası: {e}")
            raise
    
    def _collect_market_data(self) -> Dict[str, Any]:
        """Piyasa verilerini topla"""
        market_data = {}
        
        for name, source in self.data_sources.items():
            try:
                if hasattr(source, 'get_market_data'):
                    market_data[name] = source.get_market_data()
                elif hasattr(source, 'market_data'):
                    market_data[name] = source.market_data
            except Exception as e:
                self.logger.warning(f"Piyasa verisi alınamadı ({name}): {e}")
        
        return market_data
    
    def _collect_portfolio_data(self) -> Dict[str, Any]:
        """Portföy verilerini topla"""
        portfolio_data = {}
        
        for name, manager in self.strategy_managers.items():
            try:
                if hasattr(manager, 'get_portfolio_data'):
                    portfolio_data[name] = manager.get_portfolio_data()
                elif hasattr(manager, 'portfolio_data'):
                    portfolio_data[name] = manager.portfolio_data
            except Exception as e:
                self.logger.warning(f"Portföy verisi alınamadı ({name}): {e}")
        
        return portfolio_data
    
    def _collect_strategy_data(self) -> Dict[str, float]:
        """Strateji performans verilerini topla"""
        strategy_data = {}
        
        for name, manager in self.strategy_managers.items():
            try:
                if hasattr(manager, 'get_strategy_returns'):
                    strategy_data[name] = manager.get_strategy_returns()
                elif hasattr(manager, 'strategy_returns'):
                    strategy_data[name] = manager.strategy_returns
            except Exception as e:
                self.logger.warning(f"Strateji verisi alınamadı ({name}): {e}")
        
        return strategy_data
    
    def _calculate_returns(self, portfolio_data: Dict[str, Any]) -> np.ndarray:
        """Getiri hesapla"""
        # Basit getiri hesaplama - gerçek uygulamada daha karmaşık olabilir
        total_value = 0
        prev_total_value = 0
        
        for name, data in portfolio_data.items():
            if 'current_value' in data and 'previous_value' in data:
                total_value += data['current_value']
                prev_total_value += data['previous_value']
        
        if prev_total_value == 0:
            return np.array([0.0])
        
        return np.array([(total_value - prev_total_value) / prev_total_value])
    
    def _calculate_total_return(self, returns: np.ndarray) -> float:
        """Toplam getiri hesapla"""
        if len(returns) == 0:
            return 0.0
        return np.prod(1 + returns) - 1
    
    def _calculate_sharpe_ratio(self, returns: np.ndarray, risk_free_rate: float = 0.02) -> float:
        """Sharpe oranı hesapla"""
        if len(returns) == 0 or np.std(returns) == 0:
            return 0.0
        
        excess_returns = returns - risk_free_rate / 252  # Günlük risk-free rate
        return np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252)
    
    def _calculate_max_drawdown(self, portfolio_data: Dict[str, Any]) -> float:
        """Maksimum çekilme hesapla"""
        values = []
        
        for name, data in portfolio_data.items():
            if 'value_history' in data:
                values.extend(data['value_history'])
        
        if len(values) < 2:
            return 0.0
        
        values = np.array(values)
        peak = np.maximum.accumulate(values)
        drawdown = (values - peak) / peak
        
        return abs(np.min(drawdown))
    
    def _calculate_win_rate(self, returns: np.ndarray) -> float:
        """Kazanma oranı hesapla"""
        if len(returns) == 0:
            return 0.0
        positive_returns = returns[returns > 0]
        return len(positive_returns) / len(returns)
    
    def _calculate_profit_factor(self, returns: np.ndarray) -> float:
        """Kar faktörü hesapla"""
        if len(returns) == 0:
            return 1.0
        
        gross_profit = np.sum(returns[returns > 0])
        gross_loss = abs(np.sum(returns[returns < 0]))
        
        if gross_loss == 0:
            return float('inf')
        
        return gross_profit / gross_loss
    
    def _calculate_volatility(self, returns: np.ndarray) -> float:
        """Volatilite hesapla"""
        if len(returns) == 0:
            return 0.0
        return np.std(returns) * np.sqrt(252)  # Yıllık volatilite
    
    def _calculate_var(self, returns: np.ndarray, confidence: float = 0.95) -> float:
        """Value at Risk hesapla"""
        if len(returns) == 0:
            return 0.0
        
        return abs(np.percentile(returns, (1 - confidence) * 100))
    
    def _calculate_cvar(self, returns: np.ndarray, confidence: float = 0.95) -> float:
        """Conditional Value at Risk hesapla"""
        if len(returns) == 0:
            return 0.0
        
        var = self._calculate_var(returns, confidence)
        tail_returns = returns[returns <= -var]
        
        if len(tail_returns) == 0:
            return var
        
        return abs(np.mean(tail_returns))
    
    def _calculate_calmar_ratio(self, returns: np.ndarray) -> float:
        """Calmar oranı hesapla"""
        total_return = self._calculate_total_return(returns)
        max_drawdown = self._calculate_max_drawdown({})
        
        if max_drawdown == 0:
            return float('inf')
        
        return total_return / max_drawdown
    
    def _calculate_sortino_ratio(self, returns: np.ndarray, risk_free_rate: float = 0.02) -> float:
        """Sortino oranı hesapla"""
        if len(returns) == 0:
            return 0.0
        
        excess_returns = returns - risk_free_rate / 252
        negative_returns = excess_returns[excess_returns < 0]
        
        if len(negative_returns) == 0:
            return float('inf')
        
        downside_deviation = np.std(negative_returns)
        
        if downside_deviation == 0:
            return float('inf')
        
        return np.mean(excess_returns) / downside_deviation * np.sqrt(252)
    
    def _calculate_information_ratio(self, returns: np.ndarray, market_data: Dict[str, Any]) -> float:
        """Information ratio hesapla"""
        # Basit hesaplama - gerçek uygulamada benchmark ile karşılaştırma
        if len(returns) == 0:
            return 0.0
        
        return np.mean(returns) / np.std(returns) * np.sqrt(252)
    
    def _calculate_beta(self, returns: np.ndarray, market_data: Dict[str, Any]) -> float:
        """Beta hesapla"""
        # Basit hesaplama - gerçek uygulamada piyasa verisi ile korelasyon
        return 1.0  # Placeholder
    
    def _calculate_alpha(self, returns: np.ndarray, market_data: Dict[str, Any]) -> float:
        """Alpha hesapla"""
        # Basit hesaplama
        return np.mean(returns) * 252  # Yıllık ortalama getiri
    
    def _calculate_tracking_error(self, returns: np.ndarray, market_data: Dict[str, Any]) -> float:
        """Tracking error hesapla"""
        # Basit hesaplama
        return np.std(returns) * np.sqrt(252)
    
    def _calculate_risk_metrics(self, returns: np.ndarray, portfolio_data: Dict[str, Any]) -> Dict[str, float]:
        """Risk metrikleri hesapla"""
        return {
            'var_95': self._calculate_var(returns, 0.95),
            'cvar_95': self._calculate_cvar(returns, 0.95),
            'volatility': self._calculate_volatility(returns),
            'skewness': float(np.mean(((returns - np.mean(returns)) / np.std(returns)) ** 3)),
            'kurtosis': float(np.mean(((returns - np.mean(returns)) / np.std(returns)) ** 4)),
            'max_consecutive_losses': self._calculate_max_consecutive_losses(returns)
        }
    
    def _calculate_max_consecutive_losses(self, returns: np.ndarray) -> int:
        """Maksimum ardışık kayıp sayısı hesapla"""
        if len(returns) == 0:
            return 0
        
        max_consecutive = 0
        current_consecutive = 0
        
        for ret in returns:
            if ret < 0:
                current_consecutive += 1
                max_consecutive = max(max_consecutive, current_consecutive)
            else:
                current_consecutive = 0
        
        return max_consecutive
    
    def get_performance_summary(self, strategy_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Performans özeti döndür
        
        Args:
            strategy_name: Belirli strateji için (opsiyonel)
        
        Returns:
            Dict: Performans özeti
        """
        if not self.metrics_history:
            return {}
        
        recent_metrics = list(self.metrics_history)[-30:]  # Son 30 kayıt
        
        if strategy_name and strategy_name in self.strategy_performance:
            strategy_metrics = list(self.strategy_performance[strategy_name])[-30:]
            returns = np.array([m['return'] for m in strategy_metrics])
        else:
            returns = np.array([m.total_return for m in recent_metrics])
        
        return {
            'average_return': float(np.mean(returns)),
            'return_volatility': float(np.std(returns)),
            'sharpe_ratio': float(np.mean([m.sharpe_ratio for m in recent_metrics])),
            'max_drawdown': float(np.mean([m.max_drawdown for m in recent_metrics])),
            'win_rate': float(np.mean([m.win_rate for m in recent_metrics])),
            'var_95': float(np.mean([m.var_95 for m in recent_metrics])),
            'total_observations': len(recent_metrics)
        }
    
    def check_performance_alerts(self) -> List[Dict[str, Any]]:
        """
        Performans uyarılarını kontrol et
        
        Returns:
            List[Dict]: Uyarı listesi
        """
        alerts = []
        
        if not self.metrics_history:
            return alerts
        
        latest_metrics = self.metrics_history[-1]
        
        # Eşik kontrolü
        for metric_name, threshold in self.performance_thresholds.items():
            current_value = getattr(latest_metrics, metric_name, 0)
            
            if metric_name == 'max_drawdown':
                # Maksimum çekilme için negatif kontrol
                if current_value > threshold:
                    alerts.append({
                        'level': 'warning',
                        'metric': metric_name,
                        'current_value': current_value,
                        'threshold': threshold,
                        'message': f"Maksimum çekilme eşiğini aştı: {current_value:.3f} > {threshold:.3f}"
                    })
            else:
                # Diğer metrikler için pozitif kontrol
                if current_value < threshold:
                    alerts.append({
                        'level': 'warning',
                        'metric': metric_name,
                        'current_value': current_value,
                        'threshold': threshold,
                        'message': f"{metric_name} eşiğinin altında: {current_value:.3f} < {threshold:.3f}"
                    })
        
        return alerts