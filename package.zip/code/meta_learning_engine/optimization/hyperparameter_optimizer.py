"""
Hyperparameter Optimizer - Hiperparametre Optimizasyon Sistemi
============================================================

Bu modül, model hiperparametrelerini optimize eder.
"""

import logging
import time
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import threading
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor, as_completed
import random
import itertools

from sklearn.model_selection import ParameterGrid
from skopt import gp_minimize
from skopt.space import Real, Integer, Categorical
from scipy.optimize import minimize

@dataclass
class OptimizationJob:
    """Optimizasyon işi"""
    job_id: str
    model_name: str
    parameter_space: Dict[str, Any]
    objective_function: str  # 'sharpe_ratio', 'total_return', 'calmar_ratio', etc.
    optimization_method: str  # 'grid_search', 'bayesian', 'random_search', 'genetic'
    start_time: float
    status: str = 'running'  # 'running', 'completed', 'failed', 'cancelled'
    best_params: Optional[Dict[str, Any]] = None
    best_score: Optional[float] = None
    iterations_completed: int = 0
    max_iterations: int = 100
    convergence_threshold: float = 0.001
    constraints: Dict[str, Any] = field(default_factory=dict)

@dataclass
class OptimizationResult:
    """Optimizasyon sonucu"""
    job_id: str
    model_name: str
    completed_time: float
    best_parameters: Dict[str, Any]
    best_score: float
    optimization_history: List[Dict[str, Any]]
    convergence_achieved: bool
    iterations_used: int
    method: str
    improvements: List[Dict[str, Any]]

class HyperparameterOptimizer:
    """
    Hiperparametre Optimizasyon Sistemi
    
    Model hiperparametrelerini farklı yöntemlerle optimize eder.
    """
    
    def __init__(self, max_concurrent_jobs: int = 5):
        """
        Hyperparameter Optimizer başlat
        
        Args:
            max_concurrent_jobs: Maksimum eşzamanlı optimizasyon işi
        """
        self.logger = logging.getLogger(__name__)
        self.max_concurrent_jobs = max_concurrent_jobs
        
        # Optimizasyon işleri
        self.active_jobs = {}
        self.completed_jobs = {}
        self.optimization_results = {}
        
        # Model performans verileri
        self.model_performance = defaultdict(lambda: defaultdict(list))
        self.parameter_history = defaultdict(lambda: defaultdict(list))
        
        # Optimizasyon sonuçları
        self.best_parameters_cache = {}
        self.optimization_statistics = defaultdict(int)
        
        # Threading
        self.executor = ThreadPoolExecutor(max_workers=max_concurrent_jobs)
        self.lock = threading.Lock()
        
        # Desteklenen optimizasyon yöntemleri
        self.optimization_methods = [
            'grid_search', 'bayesian', 'random_search', 'genetic', 'particle_swarm'
        ]
        
        # Hedef fonksiyonları
        self.objective_functions = {
            'sharpe_ratio': self._sharpe_ratio_objective,
            'total_return': self._total_return_objective,
            'calmar_ratio': self._calmar_ratio_objective,
            'sortino_ratio': self._sortino_ratio_objective,
            'risk_adjusted_return': self._risk_adjusted_return_objective,
            'profit_factor': self._profit_factor_objective,
            'custom': self._custom_objective
        }
        
        # Varsayılan parameter space'leri
        self.default_parameter_spaces = {
            'trading_strategy': {
                'lookback_period': Integer(10, 100),
                'threshold': Real(0.001, 0.1),
                'max_position_size': Real(0.05, 0.5),
                'stop_loss': Real(0.005, 0.05),
                'take_profit': Real(0.01, 0.2)
            },
            'risk_management': {
                'risk_factor': Real(0.1, 2.0),
                'volatility_target': Real(0.01, 0.3),
                'correlation_limit': Real(0.5, 0.9),
                'max_drawdown_limit': Real(0.1, 0.5)
            },
            'signal_generation': {
                'sensitivity': Real(0.5, 2.0),
                'confirmation_period': Integer(1, 10),
                'noise_filter': Real(0.1, 0.9),
                'momentum_window': Integer(5, 50)
            }
        }
        
        self.logger.info("Hyperparameter Optimizer başlatıldı")
    
    def optimize_hyperparameters(self, model_name: str, 
                               parameter_space: Dict[str, Any],
                               objective_function: str = 'sharpe_ratio',
                               method: str = 'bayesian',
                               max_iterations: int = 100,
                               constraints: Dict[str, Any] = None) -> str:
        """
        Hiperparametre optimizasyonu başlat
        
        Args:
            model_name: Model adı
            parameter_space: Parametre uzayı tanımı
            objective_function: Hedef fonksiyon
            method: Optimizasyon yöntemi
            max_iterations: Maksimum iterasyon sayısı
            constraints: Kısıtlar
        
        Returns:
            str: Optimizasyon işi ID'si
        """
        try:
            with self.lock:
                # Maksimum iş sayısı kontrolü
                if len(self.active_jobs) >= self.max_concurrent_jobs:
                    raise ValueError("Maksimum eşzamanlı optimizasyon işi sayısına ulaşıldı")
                
                # Geçerli yöntem kontrolü
                if method not in self.optimization_methods:
                    raise ValueError(f"Desteklenmeyen optimizasyon yöntemi: {method}")
                
                # İş ID oluştur
                job_id = f"opt_{model_name}_{int(time.time() * 1000)}"
                
                # Optimizasyon işi oluştur
                job = OptimizationJob(
                    job_id=job_id,
                    model_name=model_name,
                    parameter_space=parameter_space,
                    objective_function=objective_function,
                    optimization_method=method,
                    start_time=time.time(),
                    max_iterations=max_iterations,
                    constraints=constraints or {}
                )
                
                self.active_jobs[job_id] = job
                
                # Optimizasyonu başlat
                self._start_optimization_job(job)
                
                self.logger.info(f"Hiperparametre optimizasyonu başlatıldı: {job_id}")
                return job_id
                
        except Exception as e:
            self.logger.error(f"Optimizasyon başlatma hatası: {e}")
            raise
    
    def _start_optimization_job(self, job: OptimizationJob):
        """Optimizasyon işini başlat"""
        try:
            if job.optimization_method == 'grid_search':
                self._run_grid_search(job)
            elif job.optimization_method == 'bayesian':
                self._run_bayesian_optimization(job)
            elif job.optimization_method == 'random_search':
                self._run_random_search(job)
            elif job.optimization_method == 'genetic':
                self._run_genetic_optimization(job)
            elif job.optimization_method == 'particle_swarm':
                self._run_particle_swarm_optimization(job)
                
        except Exception as e:
            self.logger.error(f"Optimizasyon işi hatası ({job.job_id}): {e}")
            job.status = 'failed'
    
    def _run_grid_search(self, job: OptimizationJob):
        """Grid search optimizasyonu çalıştır"""
        try:
            # Parameter grid oluştur
            param_grid = list(ParameterGrid(job.parameter_space))
            
            if len(param_grid) == 0:
                raise ValueError("Parameter grid boş")
            
            best_score = float('-inf')
            best_params = None
            history = []
            
            objective_func = self.objective_functions.get(job.objective_function)
            if not objective_func:
                raise ValueError(f"Bilinmeyen hedef fonksiyon: {job.objective_function}")
            
            for i, params in enumerate(param_grid):
                if job.status != 'running':
                    break
                
                # Kısıtları kontrol et
                if not self._check_constraints(params, job.constraints):
                    continue
                
                # Skoru hesapla
                score = self._evaluate_parameters(job.model_name, params, objective_func)
                
                history.append({
                    'iteration': i,
                    'parameters': params,
                    'score': score,
                    'timestamp': time.time()
                })
                
                # En iyi skoru güncelle
                if score > best_score:
                    best_score = score
                    best_params = params.copy()
                
                job.iterations_completed = i + 1
                
                # Yakınsama kontrolü
                if i >= 10:  # İlk 10 iterasyondan sonra kontrol et
                    recent_scores = [h['score'] for h in history[-10:]]
                    score_improvement = max(recent_scores) - min(recent_scores)
                    
                    if score_improvement < job.convergence_threshold:
                        job.status = 'completed'
                        break
                
                # Maksimum iterasyon kontrolü
                if i >= job.max_iterations - 1:
                    break
            
            # Sonuçları kaydet
            result = OptimizationResult(
                job_id=job.job_id,
                model_name=job.model_name,
                completed_time=time.time(),
                best_parameters=best_params or {},
                best_score=best_score,
                optimization_history=history,
                convergence_achieved=job.status == 'completed',
                iterations_used=job.iterations_completed,
                method=job.optimization_method,
                improvements=self._calculate_improvements(job.model_name, best_params, best_score)
            )
            
            self._finalize_optimization_job(job, result)
            
        except Exception as e:
            self.logger.error(f"Grid search hatası ({job.job_id}): {e}")
            job.status = 'failed'
    
    def _run_bayesian_optimization(self, job: OptimizationJob):
        """Bayesian optimizasyon çalıştır"""
        try:
            # SKOpt için parameter space dönüştür
            skopt_space = []
            param_names = []
            
            for param_name, param_config in job.parameter_space.items():
                param_names.append(param_name)
                
                if isinstance(param_config, Integer):
                    skopt_space.append(Integer(param_config.low, param_config.high))
                elif isinstance(param_config, Real):
                    skopt_space.append(Real(param_config.low, param_config.high))
                elif isinstance(param_config, Categorical):
                    skopt_space.append(Categorical(param_config.categories))
                else:
                    # Basit sayısal değerleri dönüştür
                    if isinstance(param_config, tuple) and len(param_config) == 2:
                        if isinstance(param_config[0], int):
                            skopt_space.append(Integer(param_config[0], param_config[1]))
                        else:
                            skopt_space.append(Real(param_config[0], param_config[1]))
            
            objective_func = self.objective_functions.get(job.objective_function)
            if not objective_func:
                raise ValueError(f"Bilinmeyen hedef fonksiyon: {job.objective_function}")
            
            # Objective function wrapper
            def objective_wrapper(params):
                param_dict = dict(zip(param_names, params))
                
                if not self._check_constraints(param_dict, job.constraints):
                    return 1e10  # Penaltı değeri
                
                return -self._evaluate_parameters(job.model_name, param_dict, objective_func)  # Negatif çünkü minimize ediyor
            
            # Bayesian optimization çalıştır
            result = gp_minimize(
                func=objective_wrapper,
                dimensions=skopt_space,
                n_calls=job.max_iterations,
                random_state=42
            )
            
            # En iyi parametreleri çıkar
            best_params = dict(zip(param_names, result.x))
            best_score = -result.fun  # Negatif'i geri al
            
            # Geçmiş oluştur (basitleştirilmiş)
            history = [{
                'iteration': 0,
                'parameters': best_params,
                'score': best_score,
                'timestamp': time.time()
            }]
            
            job.iterations_completed = job.max_iterations
            job.status = 'completed'
            
            # Sonuçları kaydet
            opt_result = OptimizationResult(
                job_id=job.job_id,
                model_name=job.model_name,
                completed_time=time.time(),
                best_parameters=best_params,
                best_score=best_score,
                optimization_history=history,
                convergence_achieved=True,
                iterations_used=job.max_iterations,
                method=job.optimization_method,
                improvements=self._calculate_improvements(job.model_name, best_params, best_score)
            )
            
            self._finalize_optimization_job(job, opt_result)
            
        except Exception as e:
            self.logger.error(f"Bayesian optimizasyon hatası ({job.job_id}): {e}")
            job.status = 'failed'
    
    def _run_random_search(self, job: OptimizationJob):
        """Random search optimizasyon çalıştır"""
        try:
            objective_func = self.objective_functions.get(job.objective_function)
            if not objective_func:
                raise ValueError(f"Bilinmeyen hedef fonksiyon: {job.objective_function}")
            
            best_score = float('-inf')
            best_params = None
            history = []
            
            for i in range(job.max_iterations):
                if job.status != 'running':
                    break
                
                # Rastgele parametreler oluştur
                params = {}
                for param_name, param_config in job.parameter_space.items():
                    if isinstance(param_config, Integer):
                        params[param_name] = random.randint(param_config.low, param_config.high)
                    elif isinstance(param_config, Real):
                        params[param_name] = random.uniform(param_config.low, param_config.high)
                    elif isinstance(param_config, Categorical):
                        params[param_name] = random.choice(param_config.categories)
                    else:
                        # Tuple format
                        if isinstance(param_config, tuple) and len(param_config) == 2:
                            if isinstance(param_config[0], int):
                                params[param_name] = random.randint(param_config[0], param_config[1])
                            else:
                                params[param_name] = random.uniform(param_config[0], param_config[1])
                
                # Kısıtları kontrol et
                if not self._check_constraints(params, job.constraints):
                    continue
                
                # Skoru hesapla
                score = self._evaluate_parameters(job.model_name, params, objective_func)
                
                history.append({
                    'iteration': i,
                    'parameters': params,
                    'score': score,
                    'timestamp': time.time()
                })
                
                # En iyi skoru güncelle
                if score > best_score:
                    best_score = score
                    best_params = params.copy()
                
                job.iterations_completed = i + 1
                
                # Yakınsama kontrolü
                if i >= 10:
                    recent_scores = [h['score'] for h in history[-10:]]
                    score_improvement = max(recent_scores) - min(recent_scores)
                    
                    if score_improvement < job.convergence_threshold:
                        job.status = 'completed'
                        break
            
            # Sonuçları kaydet
            result = OptimizationResult(
                job_id=job.job_id,
                model_name=job.model_name,
                completed_time=time.time(),
                best_parameters=best_params or {},
                best_score=best_score,
                optimization_history=history,
                convergence_achieved=job.status == 'completed',
                iterations_used=job.iterations_completed,
                method=job.optimization_method,
                improvements=self._calculate_improvements(job.model_name, best_params, best_score)
            )
            
            self._finalize_optimization_job(job, result)
            
        except Exception as e:
            self.logger.error(f"Random search hatası ({job.job_id}): {e}")
            job.status = 'failed'
    
    def _run_genetic_optimization(self, job: OptimizationJob):
        """Genetic algorithm optimizasyon çalıştır"""
        # Basitleştirilmiş genetic algorithm implementasyonu
        try:
            population_size = min(50, job.max_iterations // 4)
            mutation_rate = 0.1
            crossover_rate = 0.8
            elite_size = int(population_size * 0.2)
            
            objective_func = self.objective_functions.get(job.objective_function)
            if not objective_func:
                raise ValueError(f"Bilinmeyen hedef fonksiyon: {job.objective_function}")
            
            # İlk popülasyonu oluştur
            population = []
            for _ in range(population_size):
                individual = self._generate_random_parameters(job.parameter_space)
                if self._check_constraints(individual, job.constraints):
                    population.append(individual)
            
            best_score = float('-inf')
            best_params = None
            history = []
            generation = 0
            
            while generation * population_size < job.max_iterations and job.status == 'running':
                # Fitness hesapla
                fitness_scores = []
                for individual in population:
                    score = self._evaluate_parameters(job.model_name, individual, objective_func)
                    fitness_scores.append(score)
                
                # En iyi bireyi kaydet
                max_score_idx = np.argmax(fitness_scores)
                if fitness_scores[max_score_idx] > best_score:
                    best_score = fitness_scores[max_score_idx]
                    best_params = population[max_score_idx].copy()
                
                history.append({
                    'generation': generation,
                    'best_score': best_score,
                    'avg_score': np.mean(fitness_scores),
                    'timestamp': time.time()
                })
                
                # Yeni popülasyon oluştur
                new_population = []
                
                # Elitizm - en iyileri direkt aktar
                elite_indices = np.argsort(fitness_scores)[-elite_size:]
                for idx in elite_indices:
                    new_population.append(population[idx].copy())
                
                # Seçim ve çaprazlama
                while len(new_population) < population_size:
                    # Turnuva seçimi
                    parent1 = self._tournament_selection(population, fitness_scores, 3)
                    parent2 = self._tournament_selection(population, fitness_scores, 3)
                    
                    # Çaprazlama
                    if random.random() < crossover_rate:
                        child1, child2 = self._crossover(parent1, parent2)
                    else:
                        child1, child2 = parent1.copy(), parent2.copy()
                    
                    # Mutasyon
                    if random.random() < mutation_rate:
                        child1 = self._mutate(child1, job.parameter_space)
                    if random.random() < mutation_rate:
                        child2 = self._mutate(child2, job.parameter_space)
                    
                    # Kısıtları kontrol et
                    if self._check_constraints(child1, job.constraints):
                        new_population.append(child1)
                    if len(new_population) < population_size and self._check_constraints(child2, job.constraints):
                        new_population.append(child2)
                
                population = new_population
                job.iterations_completed = (generation + 1) * population_size
                generation += 1
            
            job.status = 'completed'
            
            # Sonuçları kaydet
            result = OptimizationResult(
                job_id=job.job_id,
                model_name=job.model_name,
                completed_time=time.time(),
                best_parameters=best_params or {},
                best_score=best_score,
                optimization_history=history,
                convergence_achieved=True,
                iterations_used=job.iterations_completed,
                method=job.optimization_method,
                improvements=self._calculate_improvements(job.model_name, best_params, best_score)
            )
            
            self._finalize_optimization_job(job, result)
            
        except Exception as e:
            self.logger.error(f"Genetic optimizasyon hatası ({job.job_id}): {e}")
            job.status = 'failed'
    
    def _run_particle_swarm_optimization(self, job: OptimizationJob):
        """Particle Swarm Optimization çalıştır"""
        # Basitleştirilmiş PSO implementasyonu
        try:
            n_particles = min(30, job.max_iterations // 3)
            inertia = 0.9
            cognitive_coeff = 2.0
            social_coeff = 2.0
            
            objective_func = self.objective_functions.get(job.objective_function)
            if not objective_func:
                raise ValueError(f"Bilinmeyen hedef fonksiyon: {job.objective_function}")
            
            # Parçacıkları başlat
            particles = []
            velocities = []
            personal_best = []
            personal_best_scores = []
            
            for _ in range(n_particles):
                position = self._generate_random_parameters(job.parameter_space)
                if self._check_constraints(position, job.constraints):
                    particles.append(position)
                    velocities.append(self._generate_random_velocity(job.parameter_space))
                    personal_best.append(position.copy())
                    score = self._evaluate_parameters(job.model_name, position, objective_func)
                    personal_best_scores.append(score)
            
            global_best = max(personal_best_scores)
            global_best_position = personal_best[personal_best_scores.index(global_best)].copy()
            
            best_score = global_best
            best_params = global_best_position.copy()
            history = []
            iteration = 0
            
            while iteration < job.max_iterations and job.status == 'running':
                for i in range(len(particles)):
                    # Hız güncelleme
                    r1, r2 = random.random(), random.random()
                    
                    for param_name in job.parameter_space.keys():
                        cognitive = cognitive_coeff * r1 * (personal_best[i][param_name] - particles[i][param_name])
                        social = social_coeff * r2 * (global_best_position[param_name] - particles[i][param_name])
                        velocities[i][param_name] = (inertia * velocities[i][param_name] + 
                                                   cognitive + social)
                    
                    # Pozisyon güncelleme
                    for param_name in particles[i].keys():
                        particles[i][param_name] += velocities[i][param_name]
                        particles[i][param_name] = self._clip_parameter(
                            particles[i][param_name], job.parameter_space[param_name]
                        )
                    
                    # Kısıtları kontrol et
                    if not self._check_constraints(particles[i], job.constraints):
                        continue
                    
                    # Skor hesapla
                    score = self._evaluate_parameters(job.model_name, particles[i], objective_func)
                    
                    # Kişisel en iyiyi güncelle
                    if score > personal_best_scores[i]:
                        personal_best_scores[i] = score
                        personal_best[i] = particles[i].copy()
                        
                        # Küresel en iyiyi güncelle
                        if score > global_best:
                            global_best = score
                            global_best_position = particles[i].copy()
                
                best_score = global_best
                best_params = global_best_position.copy()
                
                history.append({
                    'iteration': iteration,
                    'best_score': best_score,
                    'timestamp': time.time()
                })
                
                job.iterations_completed = iteration + 1
                iteration += 1
            
            job.status = 'completed'
            
            # Sonuçları kaydet
            result = OptimizationResult(
                job_id=job.job_id,
                model_name=job.model_name,
                completed_time=time.time(),
                best_parameters=best_params,
                best_score=best_score,
                optimization_history=history,
                convergence_achieved=True,
                iterations_used=job.iterations_completed,
                method=job.optimization_method,
                improvements=self._calculate_improvements(job.model_name, best_params, best_score)
            )
            
            self._finalize_optimization_job(job, result)
            
        except Exception as e:
            self.logger.error(f"PSO hatası ({job.job_id}): {e}")
            job.status = 'failed'
    
    def _evaluate_parameters(self, model_name: str, parameters: Dict[str, Any], 
                           objective_func: Callable) -> float:
        """
        Parametrelerin skorunu hesapla
        
        Args:
            model_name: Model adı
            parameters: Parametreler
            objective_func: Hedef fonksiyon
        
        Returns:
            float: Skor
        """
        try:
            # Model performans verilerini al
            performance_data = self.model_performance[model_name]
            
            # Hedef fonksiyonu değerlendir
            score = objective_func(parameters, performance_data)
            
            # Parametre geçmişine ekle
            self.parameter_history[model_name][str(sorted(parameters.items()))].append({
                'timestamp': time.time(),
                'score': score,
                'parameters': parameters.copy()
            })
            
            return score
            
        except Exception as e:
            self.logger.warning(f"Parametre değerlendirme hatası ({model_name}): {e}")
            return 0.0
    
    # Hedef fonksiyonları
    def _sharpe_ratio_objective(self, parameters: Dict[str, Any], 
                              performance_data: Dict[str, List]) -> float:
        """Sharpe ratio hedef fonksiyonu"""
        # Basit hesaplama - gerçek uygulamada daha karmaşık olabilir
        returns = performance_data.get('returns', [])
        if len(returns) == 0:
            return 0.0
        
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        
        if std_return == 0:
            return 0.0
        
        # Parametrelere göre ceza uygula
        penalty = 0
        
        # Lookback period cezası
        if 'lookback_period' in parameters:
            if parameters['lookback_period'] > 100:
                penalty += 0.1
        
        # Stop loss cezası
        if 'stop_loss' in parameters and parameters['stop_loss'] < 0.01:
            penalty += 0.2
        
        sharpe = mean_return / std_return * np.sqrt(252)
        return max(0, sharpe - penalty)
    
    def _total_return_objective(self, parameters: Dict[str, Any], 
                              performance_data: Dict[str, List]) -> float:
        """Toplam getiri hedef fonksiyonu"""
        returns = performance_data.get('returns', [])
        if len(returns) == 0:
            return 0.0
        
        total_return = np.prod(1 + np.array(returns)) - 1
        
        # Risk cezası
        if 'max_drawdown' in performance_data:
            max_dd = performance_data['max_drawdown'][-1] if performance_data['max_drawdown'] else 0
            if max_dd > 0.2:
                total_return *= 0.8  # %20 ceza
        
        return total_return
    
    def _calmar_ratio_objective(self, parameters: Dict[str, Any], 
                              performance_data: Dict[str, List]) -> float:
        """Calmar ratio hedef fonksiyonu"""
        returns = performance_data.get('returns', [])
        if len(returns) == 0:
            return 0.0
        
        total_return = np.prod(1 + np.array(returns)) - 1
        max_dd = performance_data.get('max_drawdown', [0])[-1]
        
        if max_dd == 0:
            return 0.0
        
        return total_return / max_dd
    
    def _sortino_ratio_objective(self, parameters: Dict[str, Any], 
                               performance_data: Dict[str, List]) -> float:
        """Sortino ratio hedef fonksiyonu"""
        returns = performance_data.get('returns', [])
        if len(returns) == 0:
            return 0.0
        
        mean_return = np.mean(returns)
        negative_returns = [r for r in returns if r < 0]
        
        if len(negative_returns) == 0:
            return float('inf')
        
        downside_deviation = np.std(negative_returns)
        if downside_deviation == 0:
            return 0.0
        
        return (mean_return - 0.02/252) / downside_deviation * np.sqrt(252)
    
    def _risk_adjusted_return_objective(self, parameters: Dict[str, Any], 
                                      performance_data: Dict[str, List]) -> float:
        """Risk-ayarlı getiri hedef fonksiyonu"""
        returns = performance_data.get('returns', [])
        if len(returns) == 0:
            return 0.0
        
        total_return = np.prod(1 + np.array(returns)) - 1
        volatility = np.std(returns) * np.sqrt(252)
        
        if volatility == 0:
            return 0.0
        
        return total_return / volatility
    
    def _profit_factor_objective(self, parameters: Dict[str, Any], 
                               performance_data: Dict[str, List]) -> float:
        """Kar faktörü hedef fonksiyonu"""
        returns = performance_data.get('returns', [])
        if len(returns) == 0:
            return 1.0
        
        gross_profit = sum(r for r in returns if r > 0)
        gross_loss = abs(sum(r for r in returns if r < 0))
        
        if gross_loss == 0:
            return float('inf')
        
        return gross_profit / gross_loss
    
    def _custom_objective(self, parameters: Dict[str, Any], 
                        performance_data: Dict[str, List]) -> float:
        """Özel hedef fonksiyonu"""
        # Kullanıcı tanımlı özel fonksiyon burada uygulanabilir
        return 0.0
    
    # Yardımcı fonksiyonlar
    def _check_constraints(self, parameters: Dict[str, Any], 
                          constraints: Dict[str, Any]) -> bool:
        """Kısıtları kontrol et"""
        for constraint_name, constraint_value in constraints.items():
            if constraint_name == 'max_position_size' and parameters.get('max_position_size', 0) > constraint_value:
                return False
            elif constraint_name == 'min_sharpe_ratio':
                # Sharpe ratio tahmini (basitleştirilmiş)
                if 'returns' not in self.model_performance.get(list(self.model_performance.keys())[0], {}):
                    continue
        return True
    
    def _generate_random_parameters(self, parameter_space: Dict[str, Any]) -> Dict[str, Any]:
        """Rastgele parametreler oluştur"""
        params = {}
        for param_name, param_config in parameter_space.items():
            if isinstance(param_config, Integer):
                params[param_name] = random.randint(param_config.low, param_config.high)
            elif isinstance(param_config, Real):
                params[param_name] = random.uniform(param_config.low, param_config.high)
            elif isinstance(param_config, Categorical):
                params[param_name] = random.choice(param_config.categories)
        return params
    
    def _generate_random_velocity(self, parameter_space: Dict[str, Any]) -> Dict[str, Any]:
        """Rastgele hız vektörü oluştur (PSO için)"""
        velocity = {}
        for param_name, param_config in parameter_space.items():
            if isinstance(param_config, Integer):
                velocity[param_name] = random.uniform(-10, 10)
            elif isinstance(param_config, Real):
                velocity[param_name] = random.uniform(-0.1, 0.1)
            elif isinstance(param_config, Categorical):
                velocity[param_name] = random.choice([0, 1, -1])
        return velocity
    
    def _clip_parameter(self, value: float, param_config) -> float:
        """Parametreyi sınırlar içinde tut"""
        if isinstance(param_config, Integer):
            return int(np.clip(value, param_config.low, param_config.high))
        elif isinstance(param_config, Real):
            return np.clip(value, param_config.low, param_config.high)
        return value
    
    def _tournament_selection(self, population: List[Dict[str, Any]], 
                            fitness_scores: List[float], tournament_size: int) -> Dict[str, Any]:
        """Turnuva seçimi"""
        tournament_indices = random.sample(range(len(population)), tournament_size)
        best_idx = max(tournament_indices, key=lambda i: fitness_scores[i])
        return population[best_idx].copy()
    
    def _crossover(self, parent1: Dict[str, Any], parent2: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """Çaprazlama"""
        child1, child2 = parent1.copy(), parent2.copy()
        
        for param_name in parent1.keys():
            if random.random() < 0.5:
                child1[param_name], child2[param_name] = child2[param_name], child1[param_name]
        
        return child1, child2
    
    def _mutate(self, individual: Dict[str, Any], parameter_space: Dict[str, Any]) -> Dict[str, Any]:
        """Mutasyon"""
        mutated = individual.copy()
        
        for param_name, param_config in parameter_space.items():
            if isinstance(param_config, Categorical):
                # Kategorik parametreler için değiştir
                if random.random() < 0.1:
                    mutated[param_name] = random.choice(param_config.categories)
            else:
                # Sayısal parametreler için küçük değişim
                if isinstance(param_config, Integer):
                    mutation_range = max(1, (param_config.high - param_config.low) // 10)
                    mutated[param_name] += random.randint(-mutation_range, mutation_range)
                    mutated[param_name] = int(np.clip(mutated[param_name], param_config.low, param_config.high))
                elif isinstance(param_config, Real):
                    mutation_range = (param_config.high - param_config.low) * 0.1
                    mutated[param_name] += random.uniform(-mutation_range, mutation_range)
                    mutated[param_name] = np.clip(mutated[param_name], param_config.low, param_config.high)
        
        return mutated
    
    def _calculate_improvements(self, model_name: str, new_params: Dict[str, Any], 
                              new_score: float) -> List[Dict[str, Any]]:
        """İyileştirmeleri hesapla"""
        improvements = []
        
        # Mevcut en iyi parametreleri karşılaştır
        if model_name in self.best_parameters_cache:
            old_params = self.best_parameters_cache[model_name]['parameters']
            old_score = self.best_parameters_cache[model_name]['score']
            
            if new_score > old_score:
                score_improvement = (new_score - old_score) / old_score * 100
                
                improvements.append({
                    'type': 'score_improvement',
                    'old_score': old_score,
                    'new_score': new_score,
                    'improvement_percent': score_improvement,
                    'timestamp': time.time()
                })
        
        return improvements
    
    def _finalize_optimization_job(self, job: OptimizationJob, result: OptimizationResult):
        """Optimizasyon işini tamamla"""
        with self.lock:
            if job.job_id in self.active_jobs:
                del self.active_jobs[job.job_id]
            
            job.status = 'completed'
            job.best_params = result.best_parameters
            job.best_score = result.best_score
            
            self.completed_jobs[job.job_id] = job
            self.optimization_results[job.job_id] = result
            
            # Cache'i güncelle
            self.best_parameters_cache[job.model_name] = {
                'parameters': result.best_parameters,
                'score': result.best_score,
                'timestamp': time.time()
            }
            
            self.logger.info(f"Optimizasyon tamamlandı: {job.job_id} - Skor: {result.best_score:.4f}")
    
    def get_optimization_status(self, job_id: str) -> Dict[str, Any]:
        """Optimizasyon durumunu getir"""
        if job_id in self.active_jobs:
            job = self.active_jobs[job_id]
            return {
                'job_id': job_id,
                'status': 'running',
                'progress': job.iterations_completed / job.max_iterations,
                'iterations_completed': job.iterations_completed,
                'max_iterations': job.max_iterations,
                'model_name': job.model_name,
                'method': job.optimization_method
            }
        elif job_id in self.completed_jobs:
            job = self.completed_jobs[job_id]
            result = self.optimization_results.get(job_id)
            return {
                'job_id': job_id,
                'status': 'completed',
                'iterations_completed': job.iterations_completed,
                'best_score': job.best_score,
                'best_parameters': job.best_params,
                'model_name': job.model_name,
                'method': job.optimization_method,
                'convergence_achieved': result.convergence_achieved if result else False
            }
        
        return {}
    
    def apply_optimization(self, optimization_suggestion: Dict[str, Any]) -> bool:
        """Optimizasyon önerisini uygula"""
        try:
            job_id = optimization_suggestion.get('job_id')
            if job_id and job_id in self.completed_jobs:
                job = self.completed_jobs[job_id]
                
                # En iyi parametreleri uygula
                if job.best_params:
                    model_name = job.model_name
                    
                    # Burada gerçek sistem ile entegrasyon yapılır
                    # Örneğin: model.update_parameters(job.best_params)
                    
                    self.logger.info(f"Optimizasyon uygulandı: {model_name} - {job.best_params}")
                    return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Optimizasyon uygulama hatası: {e}")
            return False
    
    def schedule_retraining(self, model_name: str, drift_info: Dict[str, Any]):
        """Model yeniden eğitimini planla"""
        try:
            # Drift bilgisine göre parametre alanı oluştur
            parameter_space = self.default_parameter_spaces.get('trading_strategy', {})
            
            if drift_info.get('severity') == 'high':
                # Kritik drift - daha kapsamlı optimizasyon
                max_iterations = 200
                method = 'bayesian'
            else:
                # Düşük drift - hızlı optimizasyon
                max_iterations = 50
                method = 'random_search'
            
            # Optimizasyonu başlat
            job_id = self.optimize_hyperparameters(
                model_name=model_name,
                parameter_space=parameter_space,
                objective_function='sharpe_ratio',
                method=method,
                max_iterations=max_iterations
            )
            
            self.logger.info(f"Yeniden eğitim planlandı: {model_name} - {job_id}")
            
        except Exception as e:
            self.logger.error(f"Yeniden eğitim planlama hatası: {e}")
    
    def get_optimization_statistics(self) -> Dict[str, Any]:
        """Optimizasyon istatistiklerini getir"""
        with self.lock:
            total_completed = len(self.completed_jobs)
            
            if total_completed == 0:
                return {
                    'total_jobs': 0,
                    'active_jobs': len(self.active_jobs),
                    'success_rate': 0.0
                }
            
            # Başarı oranı
            successful_jobs = sum(1 for job in self.completed_jobs.values() if job.status == 'completed')
            success_rate = successful_jobs / total_completed
            
            # Ortalama skor iyileştirmesi
            score_improvements = []
            for result in self.optimization_results.values():
                if result.improvements:
                    for improvement in result.improvements:
                        if improvement['type'] == 'score_improvement':
                            score_improvements.append(improvement['improvement_percent'])
            
            return {
                'total_jobs': total_completed,
                'active_jobs': len(self.active_jobs),
                'success_rate': success_rate,
                'avg_score_improvement': np.mean(score_improvements) if score_improvements else 0.0,
                'best_scores': {
                    model_name: cache['score'] 
                    for model_name, cache in self.best_parameters_cache.items()
                }
            }