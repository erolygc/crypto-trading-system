"""
Correlation Analyzer - Çapraz Strateji Korelasyon Analizi
========================================================

Bu modül, stratejiler arası korelasyon analizini yapar.
"""

import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime
from collections import defaultdict
import threading

@dataclass
class CorrelationResult:
    """Korelasyon analiz sonucu"""
    strategy_pairs: List[Tuple[str, str]]
    correlation_matrix: np.ndarray
    average_correlation: float
    high_correlation_pairs: List[Tuple[str, str, float]]
    correlation_threshold: float
    diversification_opportunities: List[Dict[str, Any]]

class CorrelationAnalyzer:
    """
    Çapraz Strateji Korelasyon Analizi
    
    Farklı stratejiler arasındaki korelasyonları analiz eder ve 
    çeşitlendirme fırsatlarını belirler.
    """
    
    def __init__(self, lookback_period: int = 252, correlation_threshold: float = 0.8):
        """
        Correlation Analyzer başlat
        
        Args:
            lookback_period: Korelasyon hesaplama periyodu
            correlation_threshold: Yüksek korelasyon eşiği
        """
        self.logger = logging.getLogger(__name__)
        self.lookback_period = lookback_period
        self.correlation_threshold = correlation_threshold
        
        # Korelasyon verilerini sakla
        self.correlation_cache = {}
        self.strategy_returns = defaultdict(list)
        self.last_update = 0
        
        # Thread güvenliği
        self.lock = threading.Lock()
        
        self.logger.info("Correlation Analyzer başlatıldı")
    
    def analyze_correlations(self, strategy_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """
        Strateji korelasyonlarını analiz et
        
        Args:
            strategy_analysis: Strateji analiz sonuçları
        
        Returns:
            Dict[str, Any]: Korelasyon analiz sonuçları
        """
        try:
            with self.lock:
                # Strateji verilerini topla
                strategy_names = []
                returns_data = {}
                
                individual_analysis = strategy_analysis.get('individual_analysis', {})
                
                for strategy_name, metrics in individual_analysis.items():
                    strategy_names.append(strategy_name)
                    
                    # Getiri verilerini al (örnek veri oluştur)
                    if hasattr(metrics, 'total_return'):
                        # Simüle edilmiş zaman serisi verisi
                        np.random.seed(hash(strategy_name) % 2**32)
                        returns = np.random.normal(
                            metrics.total_return / 252,  # Günlük getiri
                            0.02,  # Volatilite
                            min(252, self.lookback_period)
                        )
                        returns_data[strategy_name] = returns
                
                if len(strategy_names) < 2:
                    return self._empty_correlation_result()
                
                # Korelasyon matrisini hesapla
                correlation_matrix = self._calculate_correlation_matrix(returns_data)
                
                # Yüksek korelasyonlu çiftleri tespit et
                high_correlation_pairs = self._find_high_correlations(
                    strategy_names, correlation_matrix
                )
                
                # Çeşitlendirme fırsatlarını analiz et
                diversification_opportunities = self._find_diversification_opportunities(
                    strategy_names, correlation_matrix
                )
                
                # Ortalama korelasyonu hesapla
                average_correlation = self._calculate_average_correlation(correlation_matrix)
                
                result = CorrelationResult(
                    strategy_pairs=[(strategy_names[i], strategy_names[j]) 
                                  for i in range(len(strategy_names)) 
                                  for j in range(i+1, len(strategy_names))],
                    correlation_matrix=correlation_matrix,
                    average_correlation=average_correlation,
                    high_correlation_pairs=high_correlation_pairs,
                    correlation_threshold=self.correlation_threshold,
                    diversification_opportunities=diversification_opportunities
                )
                
                # Sonuçları cache'e kaydet
                self.correlation_cache = {
                    'strategy_names': strategy_names,
                    'correlation_matrix': correlation_matrix,
                    'timestamp': datetime.now().timestamp()
                }
                
                self.last_update = datetime.now().timestamp()
                
                return {
                    'comparison': result,
                    'matrix': correlation_matrix.tolist(),
                    'strategy_names': strategy_names,
                    'average_correlation': average_correlation,
                    'high_correlation_pairs': [(pair[0], pair[1], float(pair[2])) 
                                             for pair in high_correlation_pairs],
                    'diversification_score': self._calculate_diversification_score(correlation_matrix)
                }
                
        except Exception as e:
            self.logger.error(f"Korelasyon analizi hatası: {e}")
            return self._empty_correlation_result()
    
    def _calculate_correlation_matrix(self, returns_data: Dict[str, np.ndarray]) -> np.ndarray:
        """Korelasyon matrisini hesapla"""
        strategy_names = list(returns_data.keys())
        n_strategies = len(strategy_names)
        
        correlation_matrix = np.zeros((n_strategies, n_strategies))
        
        for i, name_i in enumerate(strategy_names):
            for j, name_j in enumerate(strategy_names):
                if i == j:
                    correlation_matrix[i, j] = 1.0
                else:
                    returns_i = returns_data[name_i]
                    returns_j = returns_data[name_j]
                    
                    # Minimum uzunluğa göre align et
                    min_length = min(len(returns_i), len(returns_j))
                    if min_length > 0:
                        correlation_matrix[i, j] = np.corrcoef(
                            returns_i[-min_length:], returns_j[-min_length:]
                        )[0, 1]
                    else:
                        correlation_matrix[i, j] = 0.0
        
        return correlation_matrix
    
    def _find_high_correlations(self, strategy_names: List[str], 
                              correlation_matrix: np.ndarray) -> List[Tuple[str, str, float]]:
        """Yüksek korelasyonlu strateji çiftlerini bul"""
        high_correlations = []
        
        n = len(strategy_names)
        for i in range(n):
            for j in range(i + 1, n):
                correlation = correlation_matrix[i, j]
                if abs(correlation) >= self.correlation_threshold:
                    high_correlations.append((strategy_names[i], strategy_names[j], correlation))
        
        return high_correlations
    
    def _find_diversification_opportunities(self, strategy_names: List[str],
                                         correlation_matrix: np.ndarray) -> List[Dict[str, Any]]:
        """Çeşitlendirme fırsatlarını bul"""
        opportunities = []
        
        n = len(strategy_names)
        
        # Düşük korelasyonlu stratejileri bul
        for i in range(n):
            for j in range(i + 1, n):
                correlation = correlation_matrix[i, j]
                
                if abs(correlation) < 0.3:  # Düşük korelasyon
                    opportunities.append({
                        'strategy_1': strategy_names[i],
                        'strategy_2': strategy_names[j],
                        'correlation': correlation,
                        'diversification_benefit': 1 - abs(correlation),
                        'recommendation': 'Yüksek çeşitlendirme potansiyeli'
                    })
        
        # Yüksek korelasyonlu stratejileri gruplandır
        correlation_groups = self._group_highly_correlated_strategies(
            strategy_names, correlation_matrix
        )
        
        for group in correlation_groups:
            if len(group) > 1:
                opportunities.append({
                    'group': group,
                    'recommendation': 'Bu stratejilerden sadece birini tutun',
                    'reason': 'Yüksek korelasyon'
                })
        
        return opportunities
    
    def _group_highly_correlated_strategies(self, strategy_names: List[str],
                                          correlation_matrix: np.ndarray) -> List[List[str]]:
        """Yüksek korelasyonlu stratejileri gruplandır"""
        n = len(strategy_names)
        visited = [False] * n
        groups = []
        
        for i in range(n):
            if not visited[i]:
                group = [strategy_names[i]]
                visited[i] = True
                
                # Benzer stratejileri bul
                for j in range(i + 1, n):
                    if not visited[j] and abs(correlation_matrix[i, j]) >= self.correlation_threshold:
                        group.append(strategy_names[j])
                        visited[j] = True
                
                if len(group) > 1:
                    groups.append(group)
        
        return groups
    
    def _calculate_average_correlation(self, correlation_matrix: np.ndarray) -> float:
        """Ortalama korelasyonu hesapla"""
        # Diagonal elemanları hariç tut
        n = correlation_matrix.shape[0]
        if n <= 1:
            return 0.0
        
        # Üst üçgeni al (diagonal hariç)
        upper_triangle = correlation_matrix[np.triu_indices(n, k=1)]
        return float(np.mean(np.abs(upper_triangle)))
    
    def _calculate_diversification_score(self, correlation_matrix: np.ndarray) -> float:
        """Çeşitlendirme skorunu hesapla"""
        n = correlation_matrix.shape[0]
        if n <= 1:
            return 1.0
        
        # Ortalama mutlak korelasyon
        upper_triangle = correlation_matrix[np.triu_indices(n, k=1)]
        avg_correlation = np.mean(np.abs(upper_triangle))
        
        # Çeşitlendirme skoru (0-1, 1 en iyi)
        diversification_score = 1 - avg_correlation
        return max(0, diversification_score)
    
    def _empty_correlation_result(self) -> Dict[str, Any]:
        """Boş korelasyon sonucu"""
        return {
            'comparison': CorrelationResult(
                strategy_pairs=[],
                correlation_matrix=np.array([[1.0]]),
                average_correlation=0.0,
                high_correlation_pairs=[],
                correlation_threshold=self.correlation_threshold,
                diversification_opportunities=[]
            ),
            'matrix': [[1.0]],
            'strategy_names': [],
            'average_correlation': 0.0,
            'high_correlation_pairs': [],
            'diversification_score': 1.0
        }
    
    def get_correlation_for_pair(self, strategy_1: str, strategy_2: str) -> Optional[float]:
        """
        İki strateji arasındaki korelasyonu getir
        
        Args:
            strategy_1: Birinci strateji
            strategy_2: İkinci strateji
        
        Returns:
            Optional[float]: Korelasyon değeri
        """
        if not self.correlation_cache:
            return None
        
        strategy_names = self.correlation_cache.get('strategy_names', [])
        
        try:
            idx_1 = strategy_names.index(strategy_1)
            idx_2 = strategy_names.index(strategy_2)
            
            correlation_matrix = self.correlation_cache['correlation_matrix']
            return float(correlation_matrix[idx_1, idx_2])
        
        except (ValueError, IndexError):
            return None
    
    def update_correlation_threshold(self, new_threshold: float):
        """Korelasyon eşiğini güncelle"""
        self.correlation_threshold = new_threshold
        self.logger.info(f"Korelasyon eşiği güncellendi: {new_threshold}")
    
    def get_correlation_statistics(self) -> Dict[str, Any]:
        """Korelasyon istatistiklerini getir"""
        if not self.correlation_cache:
            return {}
        
        correlation_matrix = self.correlation_cache.get('correlation_matrix', np.array([[1.0]]))
        strategy_names = self.correlation_cache.get('strategy_names', [])
        
        n = correlation_matrix.shape[0]
        
        # İstatistikleri hesapla
        if n > 1:
            upper_triangle = correlation_matrix[np.triu_indices(n, k=1)]
            
            stats = {
                'total_strategy_pairs': len(upper_triangle),
                'average_correlation': float(np.mean(np.abs(upper_triangle))),
                'max_correlation': float(np.max(np.abs(upper_triangle))),
                'min_correlation': float(np.min(np.abs(upper_triangle))),
                'correlation_std': float(np.std(np.abs(upper_triangle))),
                'high_correlation_count': int(np.sum(np.abs(upper_triangle) >= self.correlation_threshold)),
                'low_correlation_count': int(np.sum(np.abs(upper_triangle) < 0.3)),
                'diversification_score': self._calculate_diversification_score(correlation_matrix),
                'strategy_count': n,
                'last_update': self.last_update
            }
        else:
            stats = {
                'total_strategy_pairs': 0,
                'average_correlation': 0.0,
                'max_correlation': 0.0,
                'min_correlation': 0.0,
                'correlation_std': 0.0,
                'high_correlation_count': 0,
                'low_correlation_count': 0,
                'diversification_score': 1.0,
                'strategy_count': n,
                'last_update': self.last_update
            }
        
        return stats