"""
Strategy Controller - Otomatik Strateji Yönetim Sistemi
=====================================================

Bu modül, stratejilerin otomatik aktivasyon, deaktivasyon ve parametre ayarlamalarını yönetir.
"""

import logging
import time
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import threading
from collections import defaultdict, deque

@dataclass
class StrategyAction:
    """Strateji eylemi"""
    action_id: str
    strategy_name: str
    action_type: str  # 'activate', 'deactivate', 'adjust_parameters', 'pause', 'resume'
    parameters: Dict[str, Any]
    priority: int  # 1-10, 10 en yüksek
    reason: str
    scheduled_time: float
    status: str  # 'scheduled', 'executed', 'failed', 'cancelled'
    result: Optional[Dict[str, Any]] = None

@dataclass
class StrategyControlConfig:
    """Strateji kontrol yapılandırması"""
    auto_activation_enabled: bool = True
    auto_deactivation_enabled: bool = True
    parameter_adjustment_enabled: bool = True
    min_performance_threshold: float = 0.02
    max_drawdown_threshold: float = 0.20
    correlation_threshold: float = 0.80
    regime_specific_rules: Dict[str, Dict[str, Any]] = None
    risk_limits: Dict[str, float] = None

class StrategyController:
    """
    Otomatik Strateji Yönetim Sistemi
    
    Stratejilerin performansına göre otomatik aktivasyon, deaktivasyon 
    ve parametre ayarlamalarını yapar.
    """
    
    def __init__(self, config: Optional[StrategyControlConfig] = None):
        """
        Strategy Controller başlat
        
        Args:
            config: Kontrol yapılandırması
        """
        self.logger = logging.getLogger(__name__)
        self.config = config or StrategyControlConfig()
        
        # Strateji durumları
        self.strategy_status = defaultdict(str)  # 'active', 'inactive', 'paused', 'error'
        self.strategy_parameters = defaultdict(dict)
        self.strategy_performance = defaultdict(dict)
        self.strategy_risk_metrics = defaultdict(dict)
        
        # Eylem yönetimi
        self.action_queue = deque(maxlen=1000)
        self.executed_actions = deque(maxlen=1000)
        self.pending_actions = {}
        
        # Rejim bazlı kurallar
        self.regime_specific_rules = self.config.regime_specific_rules or self._initialize_regime_rules()
        
        # Risk limitleri
        self.risk_limits = self.config.risk_limits or self._initialize_risk_limits()
        
        # Performans geçmişi
        self.performance_history = defaultdict(lambda: defaultdict(list))
        self.risk_history = defaultdict(lambda: defaultdict(list))
        
        # Thread güvenliği
        self.lock = threading.Lock()
        
        # Strateji yöneticileri (gerçek sistemlerle entegrasyon)
        self.strategy_managers = {}
        
        self.logger.info("Strategy Controller başlatıldı")
    
    def register_strategy_manager(self, strategy_name: str, manager: Any):
        """
        Strateji yöneticisini kaydet
        
        Args:
            strategy_name: Strateji adı
            manager: Strateji yöneticisi objesi
        """
        self.strategy_managers[strategy_name] = manager
        self.logger.info(f"Strateji yöneticisi kaydedildi: {strategy_name}")
    
    def evaluate_strategies(self, strategy_analysis: Dict[str, Any], 
                          correlation_data: Dict[str, Any],
                          risk_metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        Stratejileri değerlendir ve eylem önerileri oluştur
        
        Args:
            strategy_analysis: Strateji analiz sonuçları
            correlation_data: Korelasyon analiz verileri
            risk_metrics: Risk metrikleri
        
        Returns:
            Dict[str, Any]: Eylem önerileri
        """
        try:
            actions = {}
            
            # Bireysel strateji değerlendirmesi
            individual_analysis = strategy_analysis.get('individual_analysis', {})
            
            for strategy_name, metrics in individual_analysis.items():
                strategy_actions = self._evaluate_individual_strategy(
                    strategy_name, metrics, correlation_data, risk_metrics
                )
                
                if strategy_actions:
                    actions[strategy_name] = strategy_actions
            
            # Portföy düzeyi değerlendirme
            portfolio_actions = self._evaluate_portfolio_level(
                individual_analysis, correlation_data, risk_metrics
            )
            
            actions.update(portfolio_actions)
            
            # Eylemleri sırala ve sınırla
            actions = self._prioritize_actions(actions)
            
            return actions
            
        except Exception as e:
            self.logger.error(f"Strateji değerlendirme hatası: {e}")
            return {}
    
    def _evaluate_individual_strategy(self, strategy_name: str, metrics: Any,
                                    correlation_data: Dict[str, Any],
                                    risk_metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        Tek bir stratejiyi değerlendir
        
        Args:
            strategy_name: Strateji adı
            metrics: Strateji metrikleri
            correlation_data: Korelasyon verileri
            risk_metrics: Risk metrikleri
        
        Returns:
            Dict[str, Any]: Önerilen eylem
        """
        actions = {}
        
        # Performans tabanlı değerlendirme
        if hasattr(metrics, 'sharpe_ratio'):
            sharpe = metrics.sharpe_ratio
            max_drawdown = metrics.max_drawdown
            win_rate = metrics.win_rate
            
            # Düşük performans - deaktivasyon
            if sharpe < self.config.min_performance_threshold:
                actions = {
                    'type': 'deactivate',
                    'reason': f"Düşük Sharpe oranı: {sharpe:.3f}",
                    'priority': 8,
                    'parameters': {}
                }
            
            # Yüksek çekilme - risk yönetimi
            elif max_drawdown > self.config.max_drawdown_threshold:
                actions = {
                    'type': 'adjust_parameters',
                    'reason': f"Yüksek maksimum çekilme: {max_drawdown:.3f}",
                    'priority': 9,
                    'parameters': {
                        'risk_factor': 0.5,  # Risk azaltma
                        'position_size': 0.7  # Pozisyon boyutu azaltma
                    }
                }
            
            # İyi performans - aktivasyon veya optimizasyon
            elif sharpe > 2.0 and win_rate > 0.6:
                if self.strategy_status[strategy_name] != 'active':
                    actions = {
                        'type': 'activate',
                        'reason': f"Yüksek performans: Sharpe={sharpe:.3f}, WinRate={win_rate:.3f}",
                        'priority': 7,
                        'parameters': {}
                    }
                
                # Optimizasyon önerisi
                elif self.config.parameter_adjustment_enabled:
                    actions = {
                        'type': 'adjust_parameters',
                        'reason': "Performans optimizasyonu",
                        'priority': 5,
                        'parameters': self._suggest_optimization_parameters(metrics)
                    }
        
        # Risk metrikleri kontrolü
        strategy_risk = risk_metrics.get(strategy_name, {})
        if strategy_risk:
            var_95 = strategy_risk.get('var_95', 0)
            if var_95 > 0.1:  # %10 VaR
                actions = {
                    'type': 'adjust_parameters',
                    'reason': f"Yüksek Value at Risk: {var_95:.3f}",
                    'priority': 8,
                    'parameters': {
                        'max_position_size': 0.1,
                        'stop_loss': 0.02
                    }
                }
        
        return actions
    
    def _evaluate_portfolio_level(self, individual_analysis: Dict[str, Any],
                                correlation_data: Dict[str, Any],
                                risk_metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        Portföy düzeyi değerlendirme
        
        Args:
            individual_analysis: Bireysel strateji analizleri
            correlation_data: Korelasyon verileri
            risk_metrics: Risk metrikleri
        
        Returns:
            Dict[str, Any]: Portföy eylemleri
        """
        portfolio_actions = {}
        
        # Çoklu strateji korelasyon kontrolü
        comparison = correlation_data.get('comparison')
        if comparison and hasattr(comparison, 'similar_strategies'):
            for similar_group in comparison.similar_strategies:
                if len(similar_group) > 1:
                    # Yüksek korelasyonlu stratejilerden birini devre dışı bırak
                    strategy_names = list(individual_analysis.keys())
                    group_names = [strategy_names[i] for i in similar_group if i < len(strategy_names)]
                    
                    # En düşük performanslısını seç
                    if group_names:
                        worst_performer = min(
                            group_names,
                            key=lambda name: getattr(individual_analysis[name], 'sharpe_ratio', 0)
                        )
                        
                        portfolio_actions[worst_performer] = {
                            'type': 'deactivate',
                            'reason': f"Yüksek korelasyonlu strateji grubu: {group_names}",
                            'priority': 6,
                            'parameters': {}
                        }
        
        # Toplam risk kontrolü
        total_var = sum(risk.get('var_95', 0) for risk in risk_metrics.values())
        if total_var > 0.2:  # %20 toplam VaR
            # En riskli stratejileri azalt
            sorted_strategies = sorted(
                risk_metrics.items(),
                key=lambda x: x[1].get('var_95', 0),
                reverse=True
            )
            
            for strategy_name, _ in sorted_strategies[:2]:  # En riskli 2'si
                if strategy_name not in portfolio_actions:
                    portfolio_actions[strategy_name] = {
                        'type': 'adjust_parameters',
                        'reason': f"Toplam portföy riski yüksek: {total_var:.3f}",
                        'priority': 7,
                        'parameters': {
                            'position_size': 0.5,
                            'leverage': 0.8
                        }
                    }
        
        return portfolio_actions
    
    def _suggest_optimization_parameters(self, metrics: Any) -> Dict[str, Any]:
        """
        Optimizasyon parametreleri öner
        
        Args:
            metrics: Strateji metrikleri
        
        Returns:
            Dict[str, Any]: Önerilen parametreler
        """
        suggestions = {}
        
        # Volatilite bazlı ayarlamalar
        if hasattr(metrics, 'volatility'):
            vol = metrics.volatility
            if vol > 0.3:  # Yüksek volatilite
                suggestions['volatility_target'] = 0.2
                suggestions['stop_loss'] = 0.02
            elif vol < 0.1:  # Düşük volatilite
                suggestions['volatility_target'] = 0.15
                suggestions['position_amplification'] = 1.2
        
        # Momentum bazlı ayarlamalar
        if hasattr(metrics, 'momentum_score'):
            momentum = metrics.momentum_score
            if momentum > 0.7:
                suggestions['trend_following'] = 1.1
            elif momentum < 0.3:
                suggestions['mean_reversion'] = 1.1
        
        return suggestions
    
    def _prioritize_actions(self, actions: Dict[str, Any]) -> Dict[str, Any]:
        """
        Eylemleri öncelik sırasına göre düzenle
        
        Args:
            actions: Ham eylemler
        
        Returns:
            Dict[str, Any]: Önceliklendirilmiş eylemler
        """
        # Öncelik sırasına göre sırala
        sorted_actions = sorted(
            actions.items(),
            key=lambda x: x[1].get('priority', 0),
            reverse=True
        )
        
        # En yüksek öncelikli eylemleri al
        max_actions = 10  # Maksimum eylem sayısı
        prioritized_actions = dict(sorted_actions[:max_actions])
        
        return prioritized_actions
    
    def execute_action(self, strategy_name: str, action: Dict[str, Any]) -> bool:
        """
        Strateji eylemini çalıştır
        
        Args:
            strategy_name: Strateji adı
            action: Eylem bilgileri
        
        Returns:
            bool: İşlem başarısı
        """
        try:
            action_id = f"{strategy_name}_{int(time.time() * 1000)}"
            
            # Eylem objesi oluştur
            strategy_action = StrategyAction(
                action_id=action_id,
                strategy_name=strategy_name,
                action_type=action['type'],
                parameters=action.get('parameters', {}),
                priority=action.get('priority', 5),
                reason=action['reason'],
                scheduled_time=time.time(),
                status='scheduled'
            )
            
            # Eylemi kuyruğa ekle
            with self.lock:
                self.action_queue.append(strategy_action)
                self.pending_actions[action_id] = strategy_action
            
            # Eylemi çalıştır
            result = self._execute_single_action(strategy_action)
            
            # Sonucu güncelle
            strategy_action.status = 'executed' if result['success'] else 'failed'
            strategy_action.result = result
            
            with self.lock:
                if action_id in self.pending_actions:
                    del self.pending_actions[action_id]
                self.executed_actions.append(strategy_action)
            
            return result['success']
            
        except Exception as e:
            self.logger.error(f"Eylem çalıştırma hatası ({strategy_name}): {e}")
            return False
    
    def _execute_single_action(self, action: StrategyAction) -> Dict[str, Any]:
        """
        Tek eylemi çalıştır
        
        Args:
            action: Eylem objesi
        
        Returns:
            Dict[str, Any]: Eylem sonucu
        """
        strategy_name = action.strategy_name
        action_type = action.action_type
        
        try:
            # Strateji yöneticisini al
            manager = self.strategy_managers.get(strategy_name)
            
            if not manager:
                return {'success': False, 'error': 'Strateji yöneticisi bulunamadı'}
            
            # Eylem tipine göre işlem yap
            if action_type == 'activate':
                return self._activate_strategy(strategy_name, manager, action.parameters)
            elif action_type == 'deactivate':
                return self._deactivate_strategy(strategy_name, manager)
            elif action_type == 'adjust_parameters':
                return self._adjust_strategy_parameters(strategy_name, manager, action.parameters)
            elif action_type == 'pause':
                return self._pause_strategy(strategy_name, manager)
            elif action_type == 'resume':
                return self._resume_strategy(strategy_name, manager)
            else:
                return {'success': False, 'error': f"Bilinmeyen eylem tipi: {action_type}"}
                
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _activate_strategy(self, strategy_name: str, manager: Any, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Stratejiyi aktive et"""
        try:
            if hasattr(manager, 'activate'):
                manager.activate(**parameters)
            
            self.strategy_status[strategy_name] = 'active'
            
            # Parametreleri güncelle
            if parameters:
                self.strategy_parameters[strategy_name].update(parameters)
            
            self.logger.info(f"Strateji aktive edildi: {strategy_name}")
            return {'success': True, 'message': f"Strateji {strategy_name} aktive edildi"}
            
        except Exception as e:
            return {'success': False, 'error': f"Aktivasyon hatası: {e}"}
    
    def _deactivate_strategy(self, strategy_name: str, manager: Any) -> Dict[str, Any]:
        """Stratejiyi deaktive et"""
        try:
            if hasattr(manager, 'deactivate'):
                manager.deactivate()
            
            self.strategy_status[strategy_name] = 'inactive'
            
            self.logger.info(f"Strateji deaktive edildi: {strategy_name}")
            return {'success': True, 'message': f"Strateji {strategy_name} deaktive edildi"}
            
        except Exception as e:
            return {'success': False, 'error': f"Deaktivasyon hatası: {e}"}
    
    def _adjust_strategy_parameters(self, strategy_name: str, manager: Any, parameters: Dict[str, Any]) -> Dict[str, Any]:
        """Strateji parametrelerini ayarla"""
        try:
            if hasattr(manager, 'update_parameters'):
                manager.update_parameters(**parameters)
            
            # Parametreleri kaydet
            self.strategy_parameters[strategy_name].update(parameters)
            
            self.logger.info(f"Strateji parametreleri güncellendi: {strategy_name}")
            return {'success': True, 'message': f"Strateji {strategy_name} parametreleri güncellendi"}
            
        except Exception as e:
            return {'success': False, 'error': f"Parametre ayarlama hatası: {e}"}
    
    def _pause_strategy(self, strategy_name: str, manager: Any) -> Dict[str, Any]:
        """Stratejiyi duraklat"""
        try:
            if hasattr(manager, 'pause'):
                manager.pause()
            
            self.strategy_status[strategy_name] = 'paused'
            
            self.logger.info(f"Strateji duraklatıldı: {strategy_name}")
            return {'success': True, 'message': f"Strateji {strategy_name} duraklatıldı"}
            
        except Exception as e:
            return {'success': False, 'error': f"Duraklatma hatası: {e}"}
    
    def _resume_strategy(self, strategy_name: str, manager: Any) -> Dict[str, Any]:
        """Stratejiyi devam ettir"""
        try:
            if hasattr(manager, 'resume'):
                manager.resume()
            
            self.strategy_status[strategy_name] = 'active'
            
            self.logger.info(f"Strateji devam ettirildi: {strategy_name}")
            return {'success': True, 'message': f"Strateji {strategy_name} devam ettirildi"}
            
        except Exception as e:
            return {'success': False, 'error': f"Devam ettirme hatası: {e}"}
    
    def activate_strategy(self, strategy_name: str, parameters: Dict[str, Any] = None) -> bool:
        """
        Stratejiyi manuel olarak aktive et
        
        Args:
            strategy_name: Strateji adı
            parameters: Aktifleştirme parametreleri
        
        Returns:
            bool: İşlem başarısı
        """
        manager = self.strategy_managers.get(strategy_name)
        if not manager:
            return False
        
        parameters = parameters or {}
        result = self._activate_strategy(strategy_name, manager, parameters)
        return result['success']
    
    def deactivate_strategy(self, strategy_name: str) -> bool:
        """
        Stratejiyi manuel olarak deaktive et
        
        Args:
            strategy_name: Strateji adı
        
        Returns:
            bool: İşlem başarısı
        """
        manager = self.strategy_managers.get(strategy_name)
        if not manager:
            return False
        
        result = self._deactivate_strategy(strategy_name, manager)
        return result['success']
    
    def adjust_parameters(self, strategy_name: str, parameters: Dict[str, Any]) -> bool:
        """
        Strateji parametrelerini manuel olarak ayarla
        
        Args:
            strategy_name: Strateji adı
            parameters: Yeni parametreler
        
        Returns:
            bool: İşlem başarısı
        """
        manager = self.strategy_managers.get(strategy_name)
        if not manager:
            return False
        
        result = self._adjust_strategy_parameters(strategy_name, manager, parameters)
        return result['success']
    
    def get_regime_recommendations(self, regime: str) -> Dict[str, Any]:
        """
        Rejime özel strateji önerileri al
        
        Args:
            regime: Piyasa rejimi
        
        Returns:
            Dict[str, Any]: Rejim önerileri
        """
        return self.regime_specific_rules.get(regime, {})
    
    def adjust_strategies_for_regime(self, regime: str, recommendations: Dict[str, Any]):
        """
        Rejime göre stratejileri ayarla
        
        Args:
            regime: Piyasa rejimi
            recommendations: Rejim önerileri
        """
        try:
            # Rejime özel parametreleri uygula
            for strategy_name, config in recommendations.items():
                if strategy_name in self.strategy_managers:
                    parameters = config.get('parameters', {})
                    if parameters:
                        self.adjust_parameters(strategy_name, parameters)
                        
                        # Durumu güncelle
                        self.strategy_status[strategy_name] = config.get('status', 'active')
            
            self.logger.info(f"Rejim bazlı ayarlamalar uygulandı: {regime}")
            
        except Exception as e:
            self.logger.error(f"Rejim ayarlama hatası: {e}")
    
    def deactivate_models(self, model_names: List[str]):
        """
        Modelleri geçici olarak deaktive et
        
        Args:
            model_names: Model adları
        """
        for model_name in model_names:
            self.deactivate_strategy(model_name)
            self.logger.warning(f"Model geçici olarak deaktive edildi: {model_name}")
    
    def _initialize_regime_rules(self) -> Dict[str, Dict[str, Any]]:
        """Rejim bazlı kuralları başlat"""
        return {
            'bull_market': {
                'momentum_strategies': {
                    'parameters': {'trend_following_strength': 1.2},
                    'status': 'active'
                },
                'mean_reversion_strategies': {
                    'parameters': {'position_size': 0.7},
                    'status': 'active'
                }
            },
            'bear_market': {
                'momentum_strategies': {
                    'parameters': {'position_size': 0.5, 'stop_loss': 0.02},
                    'status': 'active'
                },
                'mean_reversion_strategies': {
                    'parameters': {'trend_following_strength': 1.1},
                    'status': 'active'
                }
            },
            'sideways_market': {
                'mean_reversion_strategies': {
                    'parameters': {'position_size': 1.1},
                    'status': 'active'
                },
                'momentum_strategies': {
                    'parameters': {'position_size': 0.8},
                    'status': 'active'
                }
            },
            'high_volatility': {
                'all_strategies': {
                    'parameters': {'position_size': 0.6, 'stop_loss': 0.015},
                    'status': 'active'
                }
            }
        }
    
    def _initialize_risk_limits(self) -> Dict[str, float]:
        """Risk limitlerini başlat"""
        return {
            'max_total_var': 0.20,
            'max_single_position_var': 0.05,
            'max_correlation_exposure': 0.80,
            'max_leverage': 2.0,
            'min_cash_reserve': 0.10
        }
    
    def get_strategy_status(self) -> Dict[str, str]:
        """Tüm stratejilerin mevcut durumunu getir"""
        return dict(self.strategy_status)
    
    def get_action_history(self, hours: int = 24) -> List[StrategyAction]:
        """Son eylem geçmişini getir"""
        cutoff_time = time.time() - (hours * 3600)
        
        recent_actions = []
        for action in self.action_queue:
            if action.scheduled_time > cutoff_time:
                recent_actions.append(action)
        
        return sorted(recent_actions, key=lambda x: x.scheduled_time, reverse=True)
    
    def get_control_statistics(self) -> Dict[str, Any]:
        """Kontrol istatistiklerini getir"""
        return {
            'total_strategies': len(self.strategy_managers),
            'active_strategies': len([s for s in self.strategy_status.values() if s == 'active']),
            'inactive_strategies': len([s for s in self.strategy_status.values() if s == 'inactive']),
            'paused_strategies': len([s for s in self.strategy_status.values() if s == 'paused']),
            'pending_actions': len(self.pending_actions),
            'executed_actions_24h': len([a for a in self.executed_actions 
                                      if a.scheduled_time > time.time() - 86400]),
            'success_rate': self._calculate_action_success_rate()
        }
    
    def _calculate_action_success_rate(self) -> float:
        """Eylem başarı oranını hesapla"""
        if not self.executed_actions:
            return 1.0
        
        successful_actions = sum(1 for a in self.executed_actions if a.status == 'executed')
        return successful_actions / len(self.executed_actions)