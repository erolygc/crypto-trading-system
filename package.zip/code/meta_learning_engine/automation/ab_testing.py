"""
AB Testing Engine - A/B Test Otomasyon Sistemi
===========================================

Bu modül, A/B testlerini otomatik olarak yönetir ve analiz eder.
"""

import logging
import time
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import threading
from collections import defaultdict, deque
from scipy import stats
import hashlib

@dataclass
class ABTest:
    """A/B test tanımı"""
    test_id: str
    name: str
    description: str
    variant_a: Dict[str, Any]  # Kontrol grubu
    variant_b: Dict[str, Any]  # Test grubu
    metric: str  # Test edilecek metrik
    start_time: float
    end_time: Optional[float] = None
    status: str = 'running'  # 'running', 'completed', 'stopped'
    significance_level: float = 0.05
    minimum_sample_size: int = 100
    traffic_split: float = 0.5  # %50-50 split

@dataclass
class ABTestResult:
    """A/B test sonucu"""
    test_id: str
    completed_time: float
    variant_a_results: Dict[str, float]
    variant_b_results: Dict[str, float]
    statistical_significance: bool
    p_value: float
    effect_size: float
    confidence_interval: Tuple[float, float]
    recommendation: str  # 'accept_variant_b', 'keep_variant_a', 'inconclusive'
    sample_sizes: Dict[str, int]

class ABTestingEngine:
    """
    A/B Test Otomasyon Sistemi
    
    A/B testlerini oluşturur, yönetir ve sonuçlarını analiz eder.
    """
    
    def __init__(self, max_concurrent_tests: int = 10):
        """
        AB Testing Engine başlat
        
        Args:
            max_concurrent_tests: Maksimum eşzamanlı test sayısı
        """
        self.logger = logging.getLogger(__name__)
        self.max_concurrent_tests = max_concurrent_tests
        
        # Test yönetimi
        self.active_tests = {}
        self.completed_tests = {}
        self.test_results = {}
        self.test_data = defaultdict(lambda: defaultdict(list))
        
        # Performans verileri
        self.performance_tracking = defaultdict(lambda: defaultdict(list))
        
        # Eşik değerler
        self.test_thresholds = {
            'significance_level': 0.05,
            'minimum_effect_size': 0.05,
            'minimum_sample_size': 100,
            'maximum_test_duration_days': 30,
            'confidence_interval_width': 0.1
        }
        
        # Thread güvenliği
        self.lock = threading.Lock()
        
        # Test metrikleri
        self.supported_metrics = [
            'sharpe_ratio', 'total_return', 'max_drawdown', 
            'win_rate', 'profit_factor', 'volatility', 'calmar_ratio'
        ]
        
        self.logger.info("AB Testing Engine başlatıldı")
    
    def create_test(self, name: str, description: str, variant_a: Dict[str, Any],
                   variant_b: Dict[str, Any], metric: str, 
                   significance_level: float = 0.05,
                   minimum_sample_size: int = 100,
                   traffic_split: float = 0.5) -> str:
        """
        Yeni A/B testi oluştur
        
        Args:
            name: Test adı
            description: Test açıklaması
            variant_a: Kontrol grubu parametreleri
            variant_b: Test grubu parametreleri
            metric: Test metriği
            significance_level: Anlamlılık seviyesi
            minimum_sample_size: Minimum örnek boyutu
            traffic_split: Trafik bölünmesi
        
        Returns:
            str: Test ID
        """
        try:
            with self.lock:
                # Test ID oluştur
                test_id = self._generate_test_id(name, variant_a, variant_b)
                
                # Aynı test zaten var mı kontrol et
                if test_id in self.active_tests or test_id in self.completed_tests:
                    raise ValueError(f"Test zaten mevcut: {test_id}")
                
                # Maksimum test sayısı kontrolü
                if len(self.active_tests) >= self.max_concurrent_tests:
                    raise ValueError("Maksimum eşzamanlı test sayısına ulaşıldı")
                
                # Test oluştur
                test = ABTest(
                    test_id=test_id,
                    name=name,
                    description=description,
                    variant_a=variant_a,
                    variant_b=variant_b,
                    metric=metric,
                    start_time=time.time(),
                    significance_level=significance_level,
                    minimum_sample_size=minimum_sample_size,
                    traffic_split=traffic_split
                )
                
                self.active_tests[test_id] = test
                
                self.logger.info(f"A/B testi oluşturuldu: {name} ({test_id})")
                return test_id
                
        except Exception as e:
            self.logger.error(f"Test oluşturma hatası: {e}")
            raise
    
    def _generate_test_id(self, name: str, variant_a: Dict[str, Any], 
                         variant_b: Dict[str, Any]) -> str:
        """Test ID oluştur"""
        # Parametreleri hash'le
        a_hash = hashlib.md5(str(sorted(variant_a.items())).encode()).hexdigest()[:8]
        b_hash = hashlib.md5(str(sorted(variant_b.items())).encode()).hexdigest()[:8]
        
        # Test adını normalize et
        name_normalized = name.lower().replace(' ', '_')
        
        return f"abtest_{name_normalized}_{a_hash}_{b_hash}"
    
    def add_test_data(self, test_id: str, variant: str, data: Dict[str, Any]):
        """
        Test verisi ekle
        
        Args:
            test_id: Test ID
            variant: 'a' veya 'b'
            data: Performans verileri
        """
        try:
            with self.lock:
                if test_id not in self.active_tests:
                    raise ValueError(f"Test bulunamadı: {test_id}")
                
                # Veriyi sakla
                for metric, value in data.items():
                    self.test_data[test_id][f"{variant}_{metric}"].append({
                        'timestamp': time.time(),
                        'value': value
                    })
                
                self.logger.debug(f"Test verisi eklendi: {test_id}/{variant}")
                
        except Exception as e:
            self.logger.error(f"Veri ekleme hatası: {e}")
    
    def evaluate_tests(self, performance_data: Dict[str, Any]):
        """
        Aktif testleri değerlendir
        
        Args:
            performance_data: Performans verileri
        """
        try:
            with self.lock:
                completed_tests = []
                
                for test_id, test in self.active_tests.items():
                    if self._should_evaluate_test(test, performance_data):
                        result = self._evaluate_single_test(test)
                        
                        if result:
                            self.test_results[test_id] = result
                            completed_tests.append(test_id)
                
                # Tamamlanan testleri aktif listeden kaldır
                for test_id in completed_tests:
                    test = self.active_tests.pop(test_id)
                    test.status = 'completed'
                    test.end_time = time.time()
                    self.completed_tests[test_id] = test
                    
                    self.logger.info(f"Test tamamlandı: {test.name} - {result.recommendation}")
                
        except Exception as e:
            self.logger.error(f"Test değerlendirme hatası: {e}")
    
    def _should_evaluate_test(self, test: ABTest, performance_data: Dict[str, Any]) -> bool:
        """Test değerlendirme zamanını kontrol et"""
        current_time = time.time()
        test_duration = (current_time - test.start_time) / 86400  # Gün cinsinden
        
        # Maksimum süre aşıldı mı?
        if test_duration > self.test_thresholds['maximum_test_duration_days']:
            return True
        
        # Yeterli veri var mı kontrol et
        test_data_a = self.test_data[test.test_id].get('a_total_return', [])
        test_data_b = self.test_data[test.test_id].get('b_total_return', [])
        
        if (len(test_data_a) >= test.minimum_sample_size and 
            len(test_data_b) >= test.minimum_sample_size):
            return True
        
        # Performans verilerinde anlamlı fark var mı?
        if self._detect_early_significance(test):
            return True
        
        return False
    
    def _detect_early_significance(self, test: ABTest) -> bool:
        """Erken anlamlılık tespiti"""
        try:
            # Son veri noktalarını al
            recent_data_points = 20
            
            variant_a_data = self.test_data[test.test_id].get(f"a_{test.metric}", [])
            variant_b_data = self.test_data[test.test_id].get(f"b_{test.metric}", [])
            
            if len(variant_a_data) < recent_data_points or len(variant_b_data) < recent_data_points:
                return False
            
            # Son N veri noktasını al
            a_values = [d['value'] for d in variant_a_data[-recent_data_points:]]
            b_values = [d['value'] for d in variant_b_data[-recent_data_points:]]
            
            # T-test yap
            statistic, p_value = stats.ttest_ind(a_values, b_values)
            
            return p_value < test.significance_level / 4  # Conservatively adjusted
            
        except Exception as e:
            self.logger.warning(f"Erken anlamlılık tespiti hatası: {e}")
            return False
    
    def _evaluate_single_test(self, test: ABTest) -> Optional[ABTestResult]:
        """
        Tek bir testi değerlendir
        
        Args:
            test: Test objesi
        
        Returns:
            Optional[ABTestResult]: Test sonucu
        """
        try:
            # Test metriği verilerini al
            metric_a = f"a_{test.metric}"
            metric_b = f"b_{test.metric}"
            
            data_a = self.test_data[test.test_id].get(metric_a, [])
            data_b = self.test_data[test.test_id].get(metric_b, [])
            
            if len(data_a) == 0 or len(data_b) == 0:
                return None
            
            # Değerleri çıkar
            values_a = [d['value'] for d in data_a]
            values_b = [d['value'] for d in data_b]
            
            # İstatistiksel test
            statistic, p_value = stats.ttest_ind(values_a, values_b)
            
            # Etki boyutu hesapla
            effect_size = self._calculate_effect_size(values_a, values_b)
            
            # Güven aralığı
            confidence_interval = self._calculate_confidence_interval(values_a, values_b)
            
            # Anlamlılık kontrolü
            is_significant = p_value < test.significance_level
            
            # Öneri oluştur
            recommendation = self._generate_recommendation(
                is_significant, effect_size, test.significance_level, 
                len(values_a), len(values_b)
            )
            
            # Ortalama değerleri hesapla
            variant_a_results = {test.metric: np.mean(values_a)}
            variant_b_results = {test.metric: np.mean(values_b)}
            
            result = ABTestResult(
                test_id=test.test_id,
                completed_time=time.time(),
                variant_a_results=variant_a_results,
                variant_b_results=variant_b_results,
                statistical_significance=is_significance,
                p_value=p_value,
                effect_size=effect_size,
                confidence_interval=confidence_interval,
                recommendation=recommendation,
                sample_sizes={'variant_a': len(values_a), 'variant_b': len(values_b)}
            )
            
            return result
            
        except Exception as e:
            self.logger.error(f"Test değerlendirme hatası ({test.test_id}): {e}")
            return None
    
    def _calculate_effect_size(self, values_a: List[float], values_b: List[float]) -> float:
        """Etki boyutu hesapla (Cohen's d)"""
        if len(values_a) == 0 or len(values_b) == 0:
            return 0.0
        
        mean_a = np.mean(values_a)
        mean_b = np.mean(values_b)
        
        # Pooled standard deviation
        std_a = np.std(values_a, ddof=1) if len(values_a) > 1 else 0
        std_b = np.std(values_b, ddof=1) if len(values_b) > 1 else 0
        pooled_std = np.sqrt(((len(values_a) - 1) * std_a**2 + (len(values_b) - 1) * std_b**2) / 
                           (len(values_a) + len(values_b) - 2))
        
        if pooled_std == 0:
            return 0.0
        
        return (mean_b - mean_a) / pooled_std
    
    def _calculate_confidence_interval(self, values_a: List[float], 
                                     values_b: List[float]) -> Tuple[float, float]:
        """Güven aralığı hesapla"""
        if len(values_a) == 0 or len(values_b) == 0:
            return (0.0, 0.0)
        
        mean_a = np.mean(values_a)
        mean_b = np.mean(values_b)
        mean_diff = mean_b - mean_a
        
        # Standard error of difference
        std_a = np.std(values_a, ddof=1) if len(values_a) > 1 else 0
        std_b = np.std(values_b, ddof=1) if len(values_b) > 1 else 0
        
        se_a = std_a / np.sqrt(len(values_a))
        se_b = std_b / np.sqrt(len(values_b))
        se_diff = np.sqrt(se_a**2 + se_b**2)
        
        # t-critical value (approximation)
        t_critical = 1.96  # %95 confidence for large samples
        
        margin_error = t_critical * se_diff
        
        return (mean_diff - margin_error, mean_diff + margin_error)
    
    def _generate_recommendation(self, is_significant: bool, effect_size: float,
                               significance_level: float, sample_a: int, sample_b: int) -> str:
        """Test sonucuna göre öneri oluştur"""
        # Yeterli örnek boyutu kontrolü
        min_samples = self.test_thresholds['minimum_sample_size']
        
        if sample_a < min_samples or sample_b < min_samples:
            return 'insufficient_data'
        
        # İstatistiksel olarak anlamlı değil
        if not is_significant:
            return 'inconclusive'
        
        # Küçük etki boyutu
        if abs(effect_size) < self.test_thresholds['minimum_effect_size']:
            return 'too_small_effect'
        
        # Anlamlı ve büyük etki
        if effect_size > 0:
            return 'accept_variant_b'
        else:
            return 'keep_variant_a'
    
    def get_test_status(self, test_id: str) -> Dict[str, Any]:
        """
        Test durumunu getir
        
        Args:
            test_id: Test ID
        
        Returns:
            Dict[str, Any]: Test durumu
        """
        # Aktif testlerde ara
        if test_id in self.active_tests:
            test = self.active_tests[test_id]
            return {
                'test_id': test_id,
                'name': test.name,
                'status': 'running',
                'start_time': test.start_time,
                'variant_a': test.variant_a,
                'variant_b': test.variant_b,
                'metric': test.metric
            }
        
        # Tamamlanan testlerde ara
        if test_id in self.completed_tests:
            test = self.completed_tests[test_id]
            result = self.test_results.get(test_id)
            
            return {
                'test_id': test_id,
                'name': test.name,
                'status': 'completed',
                'start_time': test.start_time,
                'end_time': test.end_time,
                'variant_a': test.variant_a,
                'variant_b': test.variant_b,
                'metric': test.metric,
                'result': {
                    'recommendation': result.recommendation if result else 'unknown',
                    'p_value': result.p_value if result else None,
                    'effect_size': result.effect_size if result else None,
                    'significant': result.statistical_significance if result else None
                } if result else None
            }
        
        return {}
    
    def list_active_tests(self) -> List[Dict[str, Any]]:
        """Aktif testleri listele"""
        with self.lock:
            return [
                {
                    'test_id': test.test_id,
                    'name': test.name,
                    'status': 'running',
                    'start_time': test.start_time,
                    'duration_days': (time.time() - test.start_time) / 86400,
                    'metric': test.metric,
                    'sample_sizes': self._get_current_sample_sizes(test.test_id)
                }
                for test in self.active_tests.values()
            ]
    
    def _get_current_sample_sizes(self, test_id: str) -> Dict[str, int]:
        """Test için mevcut örnek boyutlarını al"""
        sizes = {'variant_a': 0, 'variant_b': 0}
        
        for variant in ['a', 'b']:
            total_key = f"{variant}_total_return"
            if total_key in self.test_data[test_id]:
                sizes[f"variant_{variant}"] = len(self.test_data[test_id][total_key])
        
        return sizes
    
    def get_test_results(self, test_id: str) -> Optional[ABTestResult]:
        """Test sonuçlarını getir"""
        return self.test_results.get(test_id)
    
    def stop_test(self, test_id: str) -> bool:
        """
        Testi durdur
        
        Args:
            test_id: Test ID
        
        Returns:
            bool: İşlem başarısı
        """
        try:
            with self.lock:
                if test_id not in self.active_tests:
                    return False
                
                test = self.active_tests.pop(test_id)
                test.status = 'stopped'
                test.end_time = time.time()
                self.completed_tests[test_id] = test
                
                self.logger.info(f"Test durduruldu: {test.name}")
                return True
                
        except Exception as e:
            self.logger.error(f"Test durdurma hatası: {e}")
            return False
    
    def get_test_statistics(self) -> Dict[str, Any]:
        """Test istatistiklerini getir"""
        with self.lock:
            total_tests = len(self.completed_tests)
            
            if total_tests == 0:
                return {
                    'total_tests': 0,
                    'active_tests': len(self.active_tests),
                    'completion_rate': 0.0
                }
            
            # Öneri dağılımı
            recommendation_counts = defaultdict(int)
            significant_tests = 0
            
            for result in self.test_results.values():
                recommendation_counts[result.recommendation] += 1
                if result.statistical_significance:
                    significant_tests += 1
            
            return {
                'total_tests': total_tests,
                'active_tests': len(self.active_tests),
                'completion_rate': 1.0,
                'significant_tests': significant_tests,
                'significance_rate': significant_tests / total_tests,
                'recommendation_distribution': dict(recommendation_counts),
                'avg_test_duration_days': np.mean([
                    (test.end_time - test.start_time) / 86400 
                    for test in self.completed_tests.values() 
                    if test.end_time
                ])
            }
    
    def export_test_data(self, test_id: str, filepath: str):
        """
        Test verilerini dosyaya aktar
        
        Args:
            test_id: Test ID
            filepath: Dosya yolu
        """
        try:
            if test_id not in self.test_data:
                raise ValueError(f"Test verisi bulunamadı: {test_id}")
            
            # Veriyi DataFrame'e çevir
            all_data = []
            
            for metric_key, data_points in self.test_data[test_id].items():
                for data_point in data_points:
                    all_data.append({
                        'timestamp': data_point['timestamp'],
                        'metric': metric_key,
                        'value': data_point['value']
                    })
            
            df = pd.DataFrame(all_data)
            df.to_csv(filepath, index=False)
            
            self.logger.info(f"Test verisi aktarıldı: {filepath}")
            
        except Exception as e:
            self.logger.error(f"Veri aktarma hatası: {e}")
            raise