"""
Meta-Learning Engine Demo
========================

Bu dosya, Meta-Learning Engine'in nasıl kullanılacağını gösteren örnekler içerir.
"""

import time
import numpy as np
import logging
from datetime import datetime, timedelta

# Meta-Learning Engine'i import et
from meta_learning_engine import (
    MetaLearningEngine, MetaLearningConfig,
    PerformanceMonitor, AlertManager,
    StrategyAnalyzer, RegimeDetector, DriftDetector,
    StrategyController, ABTestingEngine,
    HyperparameterOptimizer, CorrelationAnalyzer,
    RiskAdjustedMetrics, RealtimeLearner,
    SystemIntegrator, ConfigManager,
    setup_logging, PerformanceTimer
)

def demo_basic_usage():
    """Temel kullanım örneği"""
    print("\n=== Meta-Learning Engine Temel Kullanım ===")
    
    # Logging ayarla
    setup_logging(level="INFO")
    
    # Konfigürasyon oluştur
    config = MetaLearningConfig(
        update_frequency=30,  # 30 saniye
        performance_threshold=0.05,
        enable_real_time_learning=True,
        enable_ab_testing=True,
        enable_hyperparameter_optimization=True
    )
    
    # Engine'i başlat
    engine = MetaLearningEngine(config)
    
    # Simüle edilmiş performans verisi oluştur
    performance_data = generate_sample_performance_data()
    
    print(f"Engine başlatıldı")
    print(f"Mevcut durum: {engine.get_current_status()}")
    
    # Simüle edilmiş işlem döngüsü
    for i in range(5):
        print(f"\nDöngü {i+1}/5")
        
        # Yeni performans verisi ekle
        new_data = generate_sample_performance_data()
        
        # Engine'i güncelle (manuel)
        engine._execute_update_cycle()
        
        # Durum kontrolü
        status = engine.get_current_status()
        print(f"Aktif strateji sayısı: {len(status['active_strategies'])}")
        print(f"Mevcut rejim: {status['current_regime']}")
        
        time.sleep(2)
    
    # Final durum
    print(f"\nFinal durum: {engine.get_current_status()}")
    
    # Engine'i durdur
    engine.stop()
    print("Engine durduruldu")

def demo_performance_monitoring():
    """Performans izleme örneği"""
    print("\n=== Performance Monitoring Demo ===")
    
    # Performance Monitor oluştur
    monitor = PerformanceMonitor()
    
    # Veri kaynaklarını simüle et
    class MockStrategyManager:
        def get_portfolio_data(self):
            return {
                'current_value': 100000 + np.random.normal(0, 1000),
                'previous_value': 99000 + np.random.normal(0, 1000),
                'value_history': [99000 + i * 100 + np.random.normal(0, 500) for i in range(30)]
            }
    
    # Strateji yöneticilerini kaydet
    monitor.register_strategy_manager('strategy_1', MockStrategyManager())
    monitor.register_strategy_manager('strategy_2', MockStrategyManager())
    
    # Metrikleri topla
    for i in range(5):
        metrics = monitor.collect_metrics()
        print(f"Döngü {i+1}:")
        print(f"  Toplam Getiri: {metrics.total_return:.4f}")
        print(f"  Sharpe Ratio: {metrics.sharpe_ratio:.4f}")
        print(f"  Max Drawdown: {metrics.max_drawdown:.4f}")
        print(f"  Win Rate: {metrics.win_rate:.4f}")
        
        # Performans özetini al
        summary = monitor.get_performance_summary()
        if summary:
            print(f"  Özet - Ortalama Return: {summary['average_return']:.4f}")
        
        time.sleep(1)
    
    # Uyarıları kontrol et
    alerts = monitor.check_performance_alerts()
    print(f"\nTespit edilen uyarılar: {len(alerts)}")
    for alert in alerts:
        print(f"  - {alert['message']}")

def demo_alert_system():
    """Uyarı sistemi örneği"""
    print("\n=== Alert System Demo ===")
    
    # Alert Manager oluştur
    alert_manager = AlertManager()
    
    # Email konfigürasyonu (örnek)
    # alert_manager.configure_email(
    #     smtp_server="smtp.gmail.com",
    #     smtp_port=587,
    #     username="your_email@gmail.com",
    #     password="your_app_password",
    #     recipients=["admin@company.com"]
    # )
    
    # Webhook konfigürasyonu
    # alert_manager.configure_webhook(
    #     url="https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK",
    #     headers={"Content-Type": "application/json"}
    # )
    
    # Test uyarıları gönder
    alert_manager.send_alert(
        level="info",
        message="Meta-Learning Engine başarıyla başlatıldı",
        component="demo"
    )
    
    alert_manager.send_alert(
        level="warning",
        message="Düşük Sharpe Ratio tespit edildi",
        component="strategy_1",
        data={"sharpe_ratio": 0.8, "threshold": 1.0}
    )
    
    alert_manager.send_alert(
        level="error",
        message="Model drift tespit edildi",
        component="drift_detector",
        data={"drift_score": 0.15, "model": "strategy_model_v1"}
    )
    
    # Uyarı istatistikleri
    stats = alert_manager.get_alert_statistics()
    print(f"Uyarı istatistikleri:")
    print(f"  Toplam uyarı: {stats['total_alerts']}")
    print(f"  Seviyelere göre: {stats['by_level']}")
    
    # Aktif uyarılar
    active_alerts = alert_manager.get_active_alerts()
    print(f"Aktif uyarılar: {len(active_alerts)}")

def demo_strategy_analysis():
    """Strateji analizi örneği"""
    print("\n=== Strategy Analysis Demo ===")
    
    # Strategy Analyzer oluştur
    analyzer = StrategyAnalyzer()
    
    # Örnek strateji verileri ekle
    strategies = ['momentum_strategy', 'mean_reversion', 'breakout_strategy']
    
    for strategy_name in strategies:
        # Simüle edilmiş veri
        strategy_data = generate_strategy_data(strategy_name)
        analyzer.add_strategy_data(strategy_name, strategy_data)
    
    # Analiz yap
    analysis_results = analyzer.analyze_strategies({})
    
    print(f"Analiz sonuçları:")
    print(f"  Analiz edilen strateji sayısı: {len(analysis_results['individual_analysis'])}")
    
    # Her strateji için detayları göster
    for strategy_name, metrics in analysis_results['individual_analysis'].items():
        print(f"\n  {strategy_name}:")
        print(f"    Sharpe Ratio: {metrics.sharpe_ratio:.3f}")
        print(f"    Max Drawdown: {metrics.max_drawdown:.3f}")
        print(f"    Win Rate: {metrics.win_rate:.3f}")
        print(f"    Calmar Ratio: {metrics.calmar_ratio:.3f}")
    
    # Karşılaştırmalı analiz
    if analysis_results['comparison']:
        comparison = analysis_results['comparison']
        print(f"\nEn iyi performer: {comparison.best_strategy}")
        print(f"Sıralama:")
        for strategy, score in comparison.ranking:
            print(f"  {strategy}: {score:.3f}")
    
    # Öneriler
    recommendations = analysis_results.get('recommendations', [])
    if recommendations:
        print(f"\nÖneriler:")
        for rec in recommendations:
            print(f"  - {rec}")
    
    # Uyarılar
    warnings = analysis_results.get('warnings', [])
    if warnings:
        print(f"\nUyarılar:")
        for warning in warnings:
            print(f"  - {warning}")

def demo_regime_detection():
    """Rejim tespiti örneği"""
    print("\n=== Regime Detection Demo ===")
    
    # Regime Detector oluştur
    detector = RegimeDetector(n_regimes=4)
    
    # Simüle edilmiş piyasa verileri ile rejim tespiti
    market_data = generate_market_data()
    
    # 10 döngü rejim tespiti
    regimes = []
    for i in range(10):
        # Her döngüde yeni veri oluştur
        data = generate_market_data()
        regime = detector.detect_regime(data)
        regimes.append(regime)
        
        print(f"Döngü {i+1}: Tespit edilen rejim = {regime}")
        time.sleep(0.5)
    
    # Rejim geçmişi
    history = detector.get_regime_history(days=1)
    print(f"\nRejim geçmişi kayıt sayısı: {len(history)}")
    
    # İstatistikler
    stats = detector.get_regime_statistics()
    print(f"Rejim istatistikleri:")
    print(f"  Mevcut rejim: {stats.get('current_regime', 'unknown')}")
    print(f"  Ortalama güven seviyesi: {stats.get('average_confidence', 0):.3f}")
    print(f"  30 günde geçiş sayısı: {stats.get('total_transitions_30d', 0)}")

def demo_drift_detection():
    """Model drift tespiti örneği"""
    print("\n=== Model Drift Detection Demo ===")
    
    # Drift Detector oluştur
    detector = DriftDetector(window_size=100)
    
    # Model kaydet
    initial_performance = {
        'sharpe_ratio': 1.5,
        'total_return': 0.12,
        'max_drawdown': 0.08,
        'win_rate': 0.60
    }
    
    detector.register_model(
        model_name='strategy_model_v1',
        initial_performance=initial_performance,
        baseline_data=np.random.normal(0.01, 0.02, 50)
    )
    
    # Simüle edilmiş performans verisi ile drift test
    for i in range(5):
        # İlk 3 döngüde normal performans
        if i < 3:
            performance_data = {
                'strategy_model_v1': {
                    'sharpe_ratio': 1.5 + np.random.normal(0, 0.1),
                    'total_return': 0.12 + np.random.normal(0, 0.01),
                    'max_drawdown': 0.08 + np.random.normal(0, 0.01)
                }
            }
        else:
            # Sonraki döngülerde drift simüle et
            performance_data = {
                'strategy_model_v1': {
                    'sharpe_ratio': 0.8 + np.random.normal(0, 0.1),  # Performans düşüşü
                    'total_return': 0.05 + np.random.normal(0, 0.01),
                    'max_drawdown': 0.20 + np.random.normal(0, 0.02)  # Çekilme artışı
                }
            }
        
        # Drift tespiti yap
        drift_results = detector.detect_drift(performance_data)
        
        print(f"Döngü {i+1}:")
        if drift_results:
            for model_name, drift_info in drift_results.items():
                print(f"  {model_name}:")
                print(f"    Drift tespit edildi: {drift_info['is_drift_detected']}")
                print(f"    Genel drift skoru: {drift_info['overall_drift_score']:.3f}")
                print(f"    Şiddet: {drift_info['severity']}")
        
        time.sleep(1)
    
    # Drift istatistikleri
    stats = detector.get_drift_statistics()
    print(f"\nDrift istatistikleri:")
    print(f"  İzlenen model sayısı: {stats['total_models_monitored']}")
    print(f"  Son 24 saatte drift oranı: {stats['drift_rate_24h']:.3f}")
    print(f"  Toplam drift olayı: {stats['total_drift_events']}")

def demo_ab_testing():
    """A/B test örneği"""
    print("\n=== A/B Testing Demo ===")
    
    # A/B Testing Engine oluştur
    ab_engine = ABTestingEngine(max_concurrent_tests=5)
    
    # Test oluştur
    test_id = ab_engine.create_test(
        name="Stop Loss Optimizasyonu",
        description="Farklı stop loss seviyelerinin performans karşılaştırması",
        variant_a={'stop_loss': 0.02, 'take_profit': 0.04},
        variant_b={'stop_loss': 0.03, 'take_profit': 0.06},
        metric='sharpe_ratio',
        significance_level=0.05,
        minimum_sample_size=20
    )
    
    print(f"A/B testi oluşturuldu: {test_id}")
    
    # Simüle edilmiş test verisi
    for i in range(25):
        # Variant A için veri
        variant_a_data = generate_test_data(variant='a')
        ab_engine.add_test_data(test_id, 'a', variant_a_data)
        
        # Variant B için veri
        variant_b_data = generate_test_data(variant='b')
        ab_engine.add_test_data(test_id, 'b', variant_b_data)
        
        print(f"Veri eklendi - Döngü {i+1}/25")
        
        if (i + 1) % 5 == 0:
            # Test durumunu kontrol et
            status = ab_engine.get_test_status(test_id)
            print(f"  Test durumu: {status.get('status', 'unknown')}")
            
            if status.get('result'):
                result = status['result']
                print(f"  Önerilen aksiyon: {result['recommendation']}")
                print(f"  P-value: {result.get('p_value', 'N/A')}")
                print(f"  Etki boyutu: {result.get('effect_size', 'N/A')}")
        
        time.sleep(0.2)
    
    # Final test sonuçları
    final_status = ab_engine.get_test_status(test_id)
    print(f"\nFinal test sonucu:")
    if final_status.get('result'):
        result = final_status['result']
        print(f"  Öneri: {result['recommendation']}")
        print(f"  İstatistiksel anlamlılık: {result['significant']}")
        print(f"  P-value: {result['p_value']:.6f}")
        print(f"  Etki boyutu: {result['effect_size']:.4f}")

def demo_optimization():
    """Hiperparametre optimizasyonu örneği"""
    print("\n=== Hyperparameter Optimization Demo ===")
    
    # Optimizer oluştur
    optimizer = HyperparameterOptimizer(max_concurrent_jobs=3)
    
    # Model performans verisi simüle et
    model_name = 'trading_strategy_v1'
    
    # Simüle edilmiş performans geçmişi
    for i in range(50):
        returns = np.random.normal(0.001, 0.02, 30)
        optimizer.model_performance[model_name]['returns'].append({
            'timestamp': time.time() - (50-i) * 3600,
            'returns': returns
        })
    
    # Parameter space tanımla
    parameter_space = {
        'lookback_period': (20, 100),
        'threshold': (0.001, 0.05),
        'max_position_size': (0.1, 0.8),
        'stop_loss': (0.005, 0.03)
    }
    
    # Optimizasyon işi başlat
    job_id = optimizer.optimize_hyperparameters(
        model_name=model_name,
        parameter_space=parameter_space,
        objective_function='sharpe_ratio',
        method='random_search',
        max_iterations=20
    )
    
    print(f"Optimizasyon işi başlatıldı: {job_id}")
    
    # Optimizasyonu bekle (simülasyon)
    for i in range(10):
        status = optimizer.get_optimization_status(job_id)
        if status.get('status') == 'completed':
            print(f"Optimizasyon tamamlandı!")
            print(f"  En iyi parametreler: {status.get('best_parameters')}")
            print(f"  En iyi skor: {status.get('best_score'):.4f}")
            break
        
        print(f"Optimizasyon devam ediyor... Döngü {i+1}/10")
        time.sleep(1)
    else:
        print("Optimizasyon hala devam ediyor")
    
    # Optimizasyon istatistikleri
    stats = optimizer.get_optimization_statistics()
    print(f"\nOptimizasyon istatistikleri:")
    print(f"  Toplam iş: {stats['total_jobs']}")
    print(f"  Aktif iş: {stats['active_jobs']}")
    print(f"  Başarı oranı: {stats['success_rate']:.3f}")

def demo_correlation_analysis():
    """Korelasyon analizi örneği"""
    print("\n=== Correlation Analysis Demo ===")
    
    # Correlation Analyzer oluştur
    analyzer = CorrelationAnalyzer(
        lookback_period=252,
        correlation_threshold=0.8
    )
    
    # Simüle edilmiş strateji verisi
    strategy_analysis = {
        'individual_analysis': {
            'momentum_strategy': MockStrategyMetrics('momentum_strategy'),
            'mean_reversion': MockStrategyMetrics('mean_reversion'),
            'breakout_strategy': MockStrategyMetrics('breakout_strategy'),
            'scalping_strategy': MockStrategyMetrics('scalping_strategy')
        }
    }
    
    # Korelasyon analizi yap
    correlation_results = analyzer.analyze_correlations(strategy_analysis)
    
    print(f"Korelasyon analizi sonuçları:")
    print(f"  Analiz edilen strateji sayısı: {len(correlation_results['strategy_names'])}")
    print(f"  Ortalama korelasyon: {correlation_results['average_correlation']:.3f}")
    print(f"  Çeşitlendirme skoru: {correlation_results['diversification_score']:.3f}")
    
    # Korelasyon matrisi
    matrix = correlation_results['matrix']
    strategy_names = correlation_results['strategy_names']
    
    print(f"\nKorelasyon Matrisi:")
    print(f"Stratejiler: {strategy_names}")
    for i, row in enumerate(matrix):
        print(f"{strategy_names[i]:15} {row}")
    
    # Yüksek korelasyonlu çiftler
    high_corr_pairs = correlation_results['high_correlation_pairs']
    if high_corr_pairs:
        print(f"\nYüksek korelasyonlu strateji çiftleri:")
        for pair in high_corr_pairs:
            print(f"  {pair[0]} - {pair[1]}: {pair[2]:.3f}")
    
    # Çeşitlendirme fırsatları
    div_opportunities = correlation_results['comparison'].diversification_opportunities
    if div_opportunities:
        print(f"\nÇeşitlendirme fırsatları:")
        for opp in div_opportunities[:3]:  # İlk 3'ünü göster
            print(f"  {opp}")

def demo_realtime_learning():
    """Gerçek zamanlı öğrenme örneği"""
    print("\n=== Realtime Learning Demo ===")
    
    # Realtime Learner oluştur
    learner = RealtimeLearner(
        learning_rate=0.01,
        max_models=10
    )
    
    # Model oluştur
    model_id = learner.create_model(
        model_id='performance_predictor',
        model_type='regression',
        algorithm='sgd'
    )
    
    print(f"Model oluşturuldu: {model_id}")
    
    # Eğitim verisi ekle
    for i in range(30):
        features = {
            'market_volatility': np.random.uniform(0.1, 0.3),
            'trend_strength': np.random.uniform(0.0, 1.0),
            'momentum': np.random.uniform(-1.0, 1.0),
            'volume_ratio': np.random.uniform(0.5, 2.0)
        }
        
        # Hedef değer (simüle edilmiş)
        target = (features['trend_strength'] * 0.02 + 
                 features['momentum'] * 0.01 + 
                 np.random.normal(0, 0.005))
        
        learner.add_training_data('performance_predictor', features, target)
        
        if (i + 1) % 10 == 0:
            print(f"Eğitim verisi eklendi: {i+1}/30")
    
    # Modelleri güncelle (performans verisi ile)
    performance_data = {
        'strategy_1': {'total_return': 0.12, 'sharpe_ratio': 1.5},
        'strategy_2': {'total_return': 0.08, 'sharpe_ratio': 0.9}
    }
    
    strategy_analysis = {'individual_analysis': {}}
    learner.update_models(performance_data, strategy_analysis)
    
    # Tahmin yap
    test_features = {
        'market_volatility': 0.20,
        'trend_strength': 0.8,
        'momentum': 0.6,
        'volume_ratio': 1.2
    }
    
    prediction = learner.predict('performance_predictor', test_features)
    print(f"\nTahmin sonucu: {prediction:.4f}")
    
    # Geri bildirim sağla
    actual_value = 0.015  # Gerçek performans
    learner.provide_feedback('performance_predictor', actual_value, reward=0.5)
    
    # Model bilgilerini al
    model_info = learner.get_model_info('performance_predictor')
    print(f"\nModel bilgileri:")
    print(f"  Eğitim veri boyutu: {model_info['training_data_size']}")
    print(f"  Son eğitim: {datetime.fromtimestamp(model_info['last_trained']).strftime('%Y-%m-%d %H:%M:%S')}")
    
    # Öğrenme istatistikleri
    stats = learner.get_learning_statistics()
    print(f"\nÖğrenme istatistikleri:")
    print(f"  Toplam model: {stats['total_models']}")
    print(f"  Aktif model: {stats['active_models']}")
    print(f"  Toplam eğitim verisi: {stats['total_training_data_points']}")

def demo_system_integration():
    """Sistem entegrasyonu örneği"""
    print("\n=== System Integration Demo ===")
    
    # System Integrator oluştur
    integrator = SystemIntegrator()
    
    # Sistemleri kaydet
    systems = [
        ('risk_management', 'api', 'http://localhost:8000/risk_management'),
        ('portfolio_optimizer', 'api', 'http://localhost:8000/portfolio'),
        ('backtest_engine', 'api', 'http://localhost:8000/backtest')
    ]
    
    for system_name, conn_type, endpoint in systems:
        integrator.register_system(system_name, conn_type, endpoint)
        print(f"Sistem kaydedildi: {system_name}")
    
    # Sistemlere bağlan (simülasyon)
    for system_name, _, _ in systems:
        # Gerçek bağlantı test etmek yerine simüle et
        success = True  # Simülasyon
        if success:
            integrator.connections[system_name].status = 'connected'
            print(f"Sisteme bağlanıldı: {system_name}")
    
    # Sistemlere veri gönder
    update_data = {
        'timestamp': datetime.now().isoformat(),
        'performance_metrics': {
            'total_return': 0.15,
            'sharpe_ratio': 1.8,
            'max_drawdown': 0.08
        },
        'strategy_updates': {
            'momentum_strategy': {'status': 'active', 'allocation': 0.4},
            'mean_reversion': {'status': 'active', 'allocation': 0.3}
        },
        'risk_alerts': []
    }
    
    integrator.update_systems(update_data)
    print("Sistemlere veri gönderildi")
    
    # Sistem durumunu kontrol et
    status = integrator.get_system_status()
    print(f"\nSistem durumu:")
    print(f"  Toplam sistem: {status['total_systems']}")
    print(f"  Bağlı sistem: {status['connected_systems']}")
    print(f"  Sync kuyruğu boyutu: {status['queue_size']}")
    
    # Entegrasyon istatistikleri
    stats = integrator.get_integration_statistics()
    print(f"\nEntegrasyon istatistikleri:")
    print(f"  Toplam sync: {stats['total_syncs']}")
    print(f"  Son 1 saatte sync: {stats['recent_syncs_1h']}")
    print(f"  Başarı oranı: {stats['success_rate_1h']:.3f}")
    
    # Sağlık kontrolü
    health = integrator.health_check()
    print(f"\nSistem sağlığı:")
    print(f"  Genel durum: {health['overall_health']}")
    if health['checks']:
        print(f"  Kontroller:")
        for check, message in health['checks'].items():
            print(f"    {check}: {message}")

def demo_config_management():
    """Konfigürasyon yönetimi örneği"""
    print("\n=== Configuration Management Demo ===")
    
    # Config Manager oluştur
    config_manager = ConfigManager()
    
    # Mevcut konfigürasyonu göster
    summary = config_manager.get_config_summary()
    print("Mevcut konfigürasyon özeti:")
    print(f"  Güncelleme sıklığı: {summary['meta_learning']['update_frequency']}s")
    print(f"  A/B test sınırı: {summary['automation']['max_concurrent_tests']}")
    print(f"  Optimizasyon iş sınırı: {summary['optimization']['max_concurrent_jobs']}")
    print(f"  Model sınırı: {summary['learning']['max_models']}")
    print(f"  Senkronizasyon aralığı: {summary['integration']['sync_interval_seconds']}s")
    
    # Konfigürasyon güncelleme
    print("\nKonfigürasyon güncellemeleri:")
    
    # Güncelleme sıklığını değiştir
    config_manager.update_config('meta_learning', 'update_frequency', 45)
    print("  Güncelleme sıklığı 45 saniyeye ayarlandı")
    
    # A/B test sınırını değiştir
    config_manager.update_config('automation', 'max_concurrent_tests', 8)
    print("  A/B test sınırı 8'e ayarlandı")
    
    # Yeni konfigürasyonu göster
    new_summary = config_manager.get_config_summary()
    print(f"\nGüncellenmiş konfigürasyon:")
    print(f"  Güncelleme sıklığı: {new_summary['meta_learning']['update_frequency']}s")
    print(f"  A/B test sınırı: {new_summary['automation']['max_concurrent_tests']}")

# Yardımcı fonksiyonlar
def generate_sample_performance_data():
    """Örnek performans verisi oluştur"""
    return {
        'total_return': np.random.normal(0.1, 0.05),
        'sharpe_ratio': np.random.normal(1.2, 0.3),
        'max_drawdown': abs(np.random.normal(0.08, 0.03)),
        'volatility': np.random.normal(0.15, 0.05),
        'win_rate': np.random.uniform(0.4, 0.7),
        'returns': np.random.normal(0.001, 0.02, 30)
    }

def generate_strategy_data(strategy_name):
    """Örnek strateji verisi oluştur"""
    return {
        'returns': np.random.normal(0.001, 0.02, 50),
        'total_return': np.random.normal(0.12, 0.05),
        'sharpe_ratio': np.random.normal(1.3, 0.4),
        'max_drawdown': abs(np.random.normal(0.08, 0.03)),
        'volatility': np.random.normal(0.15, 0.05),
        'win_rate': np.random.uniform(0.45, 0.65)
    }

def generate_market_data():
    """Örnek piyasa verisi oluştur"""
    return {
        'returns': np.random.normal(0, 0.02, 30),
        'volatility': np.random.uniform(0.1, 0.3),
        'trend_strength': np.random.uniform(-0.5, 0.5),
        'momentum_20': np.random.normal(0, 0.01),
        'volume': np.random.uniform(0.8, 1.2, 30),
        'var_95': np.random.uniform(0.01, 0.05),
        'max_drawdown': abs(np.random.normal(0.05, 0.02))
    }

def generate_test_data(variant='a'):
    """Örnek A/B test verisi oluştur"""
    if variant == 'a':
        return {
            'sharpe_ratio': np.random.normal(1.2, 0.2),
            'total_return': np.random.normal(0.10, 0.03),
            'max_drawdown': abs(np.random.normal(0.08, 0.02))
        }
    else:  # variant 'b'
        return {
            'sharpe_ratio': np.random.normal(1.4, 0.2),
            'total_return': np.random.normal(0.12, 0.03),
            'max_drawdown': abs(np.random.normal(0.06, 0.02))
        }

class MockStrategyMetrics:
    """Mock strateji metrikleri"""
    def __init__(self, strategy_name):
        self.strategy_name = strategy_name
        self.total_return = np.random.normal(0.12, 0.05)
        self.annualized_return = np.random.normal(0.15, 0.06)
        self.volatility = np.random.normal(0.15, 0.05)
        self.sharpe_ratio = np.random.normal(1.3, 0.4)
        self.sortino_ratio = np.random.normal(1.5, 0.5)
        self.max_drawdown = abs(np.random.normal(0.08, 0.03))
        self.calmar_ratio = np.random.normal(1.8, 0.6)
        self.win_rate = np.random.uniform(0.45, 0.65)
        self.profit_factor = np.random.uniform(1.2, 2.0)
        self.var_95 = np.random.uniform(0.01, 0.05)
        self.cvar_95 = np.random.uniform(0.015, 0.08)
        self.information_ratio = np.random.normal(0.8, 0.3)
        self.beta = np.random.normal(1.0, 0.2)
        self.alpha = np.random.normal(0.02, 0.01)
        self.turnover = np.random.uniform(0.5, 2.0)
        self.unique_trades = np.random.randint(50, 200)
        self.avg_trade_duration = np.random.uniform(2, 24)  # saat
        self.risk_adjusted_return = np.random.normal(0.8, 0.2)
        self.consistency_score = np.random.uniform(0.6, 0.9)

def run_all_demos():
    """Tüm demo'ları çalıştır"""
    print("Meta-Learning Engine Demo Başlatılıyor...")
    print("=" * 60)
    
    demos = [
        demo_basic_usage,
        demo_performance_monitoring,
        demo_alert_system,
        demo_strategy_analysis,
        demo_regime_detection,
        demo_drift_detection,
        demo_ab_testing,
        demo_optimization,
        demo_correlation_analysis,
        demo_realtime_learning,
        demo_system_integration,
        demo_config_management
    ]
    
    for i, demo_func in enumerate(demos, 1):
        try:
            print(f"\nDemo {i}/{len(demos)}: {demo_func.__doc__.strip()}")
            print("-" * 40)
            demo_func()
            
            # Demo'lar arası kısa mola
            if i < len(demos):
                print(f"\nDemo {i} tamamlandı. 2 saniye bekleniyor...")
                time.sleep(2)
                
        except Exception as e:
            print(f"Demo {i} sırasında hata oluştu: {e}")
            continue
    
    print(f"\n" + "=" * 60)
    print("Tüm demo'lar tamamlandı!")

if __name__ == "__main__":
    # Logging'i ayarla
    setup_logging(level="WARNING")  # Demo sırasında sadece önemli loglar
    
    # Tüm demo'ları çalıştır
    run_all_demos()