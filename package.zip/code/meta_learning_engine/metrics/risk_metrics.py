"""
Risk-Adjusted Metrics - Risk-Ayarlı Performans Metrikleri
========================================================

Bu modül, risk-ayarlı performans metriklerini hesaplar.
"""

import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime

@dataclass
class RiskAdjustedMetrics:
    """Risk-ayarlı metrikler"""
    model_name: str
    timestamp: float
    sharpe_ratio: float
    sortino_ratio: float
    calmar_ratio: float
    information_ratio: float
    treynor_ratio: float
    jensen_alpha: float
    beta: float
    var_95: float
    cvar_95: float
    max_drawdown: float
    recovery_factor: float
    ulcer_index: float
    sterling_ratio: float

class RiskAdjustedMetricsCalculator:
    """Risk-ayarlı metrikler hesaplayıcısı"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def calculate_metrics(self, performance_data: Dict[str, Any]) -> Dict[str, RiskAdjustedMetrics]:
        """Risk-ayarlı metrikleri hesapla"""
        metrics = {}
        
        for model_name, data in performance_data.items():
            if isinstance(data, dict):
                returns = np.array(data.get('returns', [0]))
                
                metrics[model_name] = RiskAdjustedMetrics(
                    model_name=model_name,
                    timestamp=datetime.now().timestamp(),
                    sharpe_ratio=self._calculate_sharpe_ratio(returns),
                    sortino_ratio=self._calculate_sortino_ratio(returns),
                    calmar_ratio=self._calculate_calmar_ratio(returns),
                    information_ratio=self._calculate_information_ratio(returns),
                    treynor_ratio=self._calculate_treynor_ratio(returns),
                    jensen_alpha=self._calculate_jensen_alpha(returns),
                    beta=self._calculate_beta(returns),
                    var_95=self._calculate_var(returns, 0.95),
                    cvar_95=self._calculate_cvar(returns, 0.95),
                    max_drawdown=self._calculate_max_drawdown(returns),
                    recovery_factor=self._calculate_recovery_factor(returns),
                    ulcer_index=self._calculate_ulcer_index(returns),
                    sterling_ratio=self._calculate_sterling_ratio(returns)
                )
        
        return metrics
    
    def _calculate_sharpe_ratio(self, returns: np.ndarray, risk_free_rate: float = 0.02) -> float:
        if len(returns) == 0 or np.std(returns) == 0:
            return 0.0
        excess_returns = returns - risk_free_rate / 252
        return np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252)
    
    def _calculate_sortino_ratio(self, returns: np.ndarray, risk_free_rate: float = 0.02) -> float:
        if len(returns) == 0:
            return 0.0
        excess_returns = returns - risk_free_rate / 252
        negative_returns = excess_returns[excess_returns < 0]
        if len(negative_returns) == 0:
            return float('inf')
        downside_deviation = np.std(negative_returns)
        return np.mean(excess_returns) / downside_deviation * np.sqrt(252)
    
    def _calculate_calmar_ratio(self, returns: np.ndarray) -> float:
        if len(returns) == 0:
            return 0.0
        total_return = np.prod(1 + returns) - 1
        max_dd = self._calculate_max_drawdown(returns)
        return total_return / max_dd if max_dd > 0 else 0.0
    
    def _calculate_information_ratio(self, returns: np.ndarray, benchmark_returns: np.ndarray = None) -> float:
        if len(returns) == 0 or np.std(returns) == 0:
            return 0.0
        return np.mean(returns) / np.std(returns) * np.sqrt(252)
    
    def _calculate_treynor_ratio(self, returns: np.ndarray, risk_free_rate: float = 0.02) -> float:
        if len(returns) == 0:
            return 0.0
        beta = self._calculate_beta(returns)
        excess_return = np.mean(returns) * 252 - risk_free_rate
        return excess_return / beta if beta != 0 else 0.0
    
    def _calculate_jensen_alpha(self, returns: np.ndarray, risk_free_rate: float = 0.02) -> float:
        if len(returns) == 0:
            return 0.0
        expected_return = risk_free_rate + self._calculate_beta(returns) * 0.08  # Market premium
        actual_return = np.mean(returns) * 252
        return actual_return - expected_return
    
    def _calculate_beta(self, returns: np.ndarray, market_returns: np.ndarray = None) -> float:
        # Placeholder - gerçek uygulamada piyasa verisi ile hesaplanır
        return 1.0
    
    def _calculate_var(self, returns: np.ndarray, confidence: float = 0.95) -> float:
        if len(returns) == 0:
            return 0.0
        return abs(np.percentile(returns, (1 - confidence) * 100))
    
    def _calculate_cvar(self, returns: np.ndarray, confidence: float = 0.95) -> float:
        if len(returns) == 0:
            return 0.0
        var = self._calculate_var(returns, confidence)
        tail_returns = returns[returns <= -var]
        return abs(np.mean(tail_returns)) if len(tail_returns) > 0 else var
    
    def _calculate_max_drawdown(self, returns: np.ndarray) -> float:
        if len(returns) == 0:
            return 0.0
        cumulative = np.cumprod(1 + returns)
        peak = np.maximum.accumulate(cumulative)
        drawdown = (cumulative - peak) / peak
        return abs(np.min(drawdown))
    
    def _calculate_recovery_factor(self, returns: np.ndarray) -> float:
        if len(returns) == 0:
            return 0.0
        total_return = np.prod(1 + returns) - 1
        max_dd = self._calculate_max_drawdown(returns)
        return total_return / max_dd if max_dd > 0 else 0.0
    
    def _calculate_ulcer_index(self, returns: np.ndarray) -> float:
        if len(returns) == 0:
            return 0.0
        cumulative = np.cumprod(1 + returns)
        peak = np.maximum.accumulate(cumulative)
        drawdowns = (cumulative - peak) / peak
        return np.sqrt(np.mean(drawdowns**2))
    
    def _calculate_sterling_ratio(self, returns: np.ndarray, periods: int = 36) -> float:
        if len(returns) == 0:
            return 0.0
        total_return = np.prod(1 + returns) - 1
        annual_return = (1 + total_return) ** (252 / len(returns)) - 1
        annual_volatility = np.std(returns) * np.sqrt(252)
        return annual_return / annual_volatility if annual_volatility > 0 else 0.0
    
    def calculate_overall_risk_score(self, performance_history: List[Dict[str, Any]]) -> float:
        """Genel risk skorunu hesapla"""
        if not performance_history:
            return 0.0
        
        # Son 30 günün risk metriklerini al
        recent_data = performance_history[-30:]
        risk_scores = []
        
        for data in recent_data:
            if 'risk_metrics' in data:
                risk_metrics = data['risk_metrics']
                # Risk skorunu normalize et (0-1 arası)
                score = min(1.0, risk_metrics.get('var_95', 0) / 0.1)  # %10 VaR normalizasyonu
                risk_scores.append(score)
        
        return np.mean(risk_scores) if risk_scores else 0.0

class RiskAdjustedMetrics:
    """Risk-ayarlı metrikler hesaplama sistemi"""
    
    def __init__(self):
        self.calculator = RiskAdjustedMetricsCalculator()
        self.logger = logging.getLogger(__name__)
    
    def calculate_metrics(self, performance_data: Dict[str, Any]) -> Dict[str, RiskAdjustedMetrics]:
        """Risk-ayarlı metrikleri hesapla"""
        return self.calculator.calculate_metrics(performance_data)
    
    def get_risk_adjusted_score(self, metrics: RiskAdjustedMetrics) -> float:
        """Risk-ayarlı skor hesapla"""
        # Çoklu metrik kombinasyonu
        score = (
            metrics.sharpe_ratio * 0.3 +
            metrics.sortino_ratio * 0.2 +
            metrics.calmar_ratio * 0.2 +
            (1 - metrics.var_95) * 0.15 +  # Düşük VaR daha iyi
            (1 - metrics.ulcer_index) * 0.15  # Düşük Ulcer Index daha iyi
        )
        
        return max(0, score)  # Negatif skorları 0'a çevir
    
    def rank_strategies_by_risk_adjusted_performance(self, metrics_dict: Dict[str, RiskAdjustedMetrics]) -> List[tuple]:
        """Stratejileri risk-ayarlı performansa göre sırala"""
        scores = []
        
        for model_name, metrics in metrics_dict.items():
            score = self.get_risk_adjusted_score(metrics)
            scores.append((model_name, score))
        
        return sorted(scores, key=lambda x: x[1], reverse=True)