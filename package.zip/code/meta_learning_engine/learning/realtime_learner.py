"""
Realtime Learner - Gerçek Zamanlı Öğrenme Sistemi
===============================================

Bu modül, gerçek zamanlı öğrenme algoritmalarını içerir.
"""

import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta
import threading
from collections import defaultdict, deque
from sklearn.linear_model import SGDRegressor, SGDClassifier
from sklearn.ensemble import RandomForestRegressor, RandomForestClassifier
from sklearn.preprocessing import StandardScaler
import pickle

@dataclass
class LearningModel:
    """Öğrenme modeli"""
    model_id: str
    model_type: str  # 'regression', 'classification', 'reinforcement'
    algorithm: str  # 'sgd', 'random_forest', 'neural_network'
    model: Any  # Sklearn model
    scaler: Optional[StandardScaler] = None
    last_trained: float = 0.0
    training_data_size: int = 0
    performance_metrics: Dict[str, float] = None
    feature_importance: Optional[Dict[str, float]] = None

@dataclass
class LearningFeedback:
    """Öğrenme geri bildirimi"""
    feedback_id: str
    model_id: str
    timestamp: float
    input_data: Dict[str, float]
    predicted_value: float
    actual_value: Optional[float] = None
    reward: Optional[float] = None
    action_taken: Optional[str] = None

class RealtimeLearner:
    """
    Gerçek Zamanlı Öğrenme Sistemi
    
    Sistemin performans verilerinden öğrenir ve modelleri günceller.
    """
    
    def __init__(self, learning_rate: float = 0.01, max_models: int = 20):
        """
        Realtime Learner başlat
        
        Args:
            learning_rate: Öğrenme oranı
            max_models: Maksimum model sayısı
        """
        self.logger = logging.getLogger(__name__)
        self.learning_rate = learning_rate
        self.max_models = max_models
        
        # Modeller ve veriler
        self.models = {}
        self.training_data = defaultdict(lambda: deque(maxlen=1000))
        self.feedback_buffer = deque(maxlen=1000)
        self.performance_history = defaultdict(lambda: deque(maxlen=100))
        
        # Öğrenme konfigürasyonu
        self.learning_config = {
            'min_samples_for_training': 10,
            'retrain_threshold': 0.05,  # %5 performans düşüşü
            'feature_importance_threshold': 0.01,
            'learning_frequency_minutes': 60,
            'max_training_time_seconds': 30
        }
        
        # Thread güvenliği
        self.lock = threading.Lock()
        
        # Öğrenme stratejileri
        self.learning_strategies = {
            'online_sgd': self._train_sgd_model,
            'batch_random_forest': self._train_random_forest,
            'incremental_learning': self._incremental_learning
        }
        
        self.logger.info("Realtime Learner başlatıldı")
    
    def create_model(self, model_id: str, model_type: str = 'regression', 
                    algorithm: str = 'sgd', feature_names: List[str] = None) -> bool:
        """
        Yeni öğrenme modeli oluştur
        
        Args:
            model_id: Model ID
            model_type: Model tipi
            algorithm: Algoritma
            feature_names: Özellik adları
        
        Returns:
            bool: Oluşturma başarısı
        """
        try:
            with self.lock:
                if len(self.models) >= self.max_models:
                    self.logger.warning("Maksimum model sayısına ulaşıldı")
                    return False
                
                if model_id in self.models:
                    self.logger.warning(f"Model zaten mevcut: {model_id}")
                    return False
                
                # Model oluştur
                if algorithm == 'sgd':
                    if model_type == 'regression':
                        model = SGDRegressor(learning_rate='constant', eta0=self.learning_rate)
                    else:
                        model = SGDClassifier(learning_rate='constant', eta0=self.learning_rate)
                elif algorithm == 'random_forest':
                    if model_type == 'regression':
                        model = RandomForestRegressor(n_estimators=10, warm_start=True)
                    else:
                        model = RandomForestClassifier(n_estimators=10, warm_start=True)
                else:
                    self.logger.error(f"Desteklenmeyen algoritma: {algorithm}")
                    return False
                
                # Scaler oluştur
                scaler = StandardScaler()
                
                learning_model = LearningModel(
                    model_id=model_id,
                    model_type=model_type,
                    algorithm=algorithm,
                    model=model,
                    scaler=scaler
                )
                
                self.models[model_id] = learning_model
                
                self.logger.info(f"Model oluşturuldu: {model_id}")
                return True
                
        except Exception as e:
            self.logger.error(f"Model oluşturma hatası: {e}")
            return False
    
    def add_training_data(self, model_id: str, features: Dict[str, float], target: float):
        """
        Eğitim verisi ekle
        
        Args:
            model_id: Model ID
            features: Özellikler
            target: Hedef değer
        """
        try:
            if model_id not in self.models:
                self.logger.warning(f"Model bulunamadı: {model_id}")
                return
            
            with self.lock:
                self.training_data[model_id].append({
                    'features': features,
                    'target': target,
                    'timestamp': datetime.now().timestamp()
                })
                
                self.logger.debug(f"Eğitim verisi eklendi: {model_id}")
                
        except Exception as e:
            self.logger.error(f"Eğitim verisi ekleme hatası: {e}")
    
    def update_models(self, performance_data: Dict[str, Any], 
                     strategy_analysis: Dict[str, Any]):
        """
        Modelleri güncelle
        
        Args:
            performance_data: Performans verileri
            strategy_analysis: Strateji analiz verileri
        """
        try:
            # Özellikler ve hedefler oluştur
            features, targets = self._extract_learning_features(performance_data, strategy_analysis)
            
            with self.lock:
                for model_id, learning_model in self.models.items():
                    # Model için uygun veri seç
                    model_data = self._select_model_data(model_id, features, targets)
                    
                    if len(model_data['features']) >= self.learning_config['min_samples_for_training']:
                        self._train_model(learning_model, model_data)
                        
                        # Geri bildirim buffer'ını temizle
                        self._clear_processed_feedback(model_id)
                
        except Exception as e:
            self.logger.error(f"Model güncelleme hatası: {e}")
    
    def _extract_learning_features(self, performance_data: Dict[str, Any], 
                                 strategy_analysis: Dict[str, Any]) -> tuple:
        """Öğrenme için özellikleri çıkar"""
        features = []
        targets = []
        
        try:
            # Performans verilerinden özellikler
            for strategy_name, strategy_data in performance_data.items():
                if isinstance(strategy_data, dict):
                    feature_row = {
                        'sharpe_ratio': strategy_data.get('sharpe_ratio', 0.0),
                        'total_return': strategy_data.get('total_return', 0.0),
                        'max_drawdown': strategy_data.get('max_drawdown', 0.0),
                        'volatility': strategy_data.get('volatility', 0.0),
                        'win_rate': strategy_data.get('win_rate', 0.0),
                        'timestamp': datetime.now().timestamp()
                    }
                    
                    # Strateji analiz verilerinden ek özellikler
                    if strategy_name in strategy_analysis.get('individual_analysis', {}):
                        analysis_data = strategy_analysis['individual_analysis'][strategy_name]
                        feature_row.update({
                            'calmar_ratio': getattr(analysis_data, 'calmar_ratio', 0.0),
                            'sortino_ratio': getattr(analysis_data, 'sortino_ratio', 0.0),
                            'profit_factor': getattr(analysis_data, 'profit_factor', 1.0)
                        })
                    
                    features.append(feature_row)
                    
                    # Hedef: Gelecek performans tahmini (simüle)
                    # Gerçek uygulamada: strateji verisi n-1 dönem sonrası
                    future_return = strategy_data.get('total_return', 0.0) * 1.02  # Simüle
                    targets.append(future_return)
                    
        except Exception as e:
            self.logger.error(f"Özellik çıkarma hatası: {e}")
        
        return features, targets
    
    def _select_model_data(self, model_id: str, all_features: List[Dict], 
                         all_targets: List[float]) -> Dict[str, List]:
        """Model için uygun veri seç"""
        model_data = {'features': [], 'targets': []}
        
        # Model özelinde veri filtreleme
        model = self.models[model_id]
        
        for i, feature_row in enumerate(all_features):
            # Model tipine göre filtreleme
            if model.model_type == 'regression' and model.algorithm == 'sgd':
                # SGD için sayısal özellikler
                numeric_features = {k: v for k, v in feature_row.items() 
                                  if isinstance(v, (int, float)) and k != 'timestamp'}
                model_data['features'].append(list(numeric_features.values()))
                model_data['targets'].append(all_targets[i])
        
        return model_data
    
    def _train_model(self, learning_model: LearningModel, model_data: Dict[str, List]):
        """Modeli eğit"""
        try:
            features = np.array(model_data['features'])
            targets = np.array(model_data['targets'])
            
            if len(features) == 0 or len(targets) == 0:
                return
            
            # Veriyi normalize et
            if learning_model.scaler:
                features_scaled = learning_model.scaler.fit_transform(features)
            else:
                features_scaled = features
            
            # Model tipine göre eğit
            if learning_model.model_type == 'regression':
                learning_model.model.fit(features_scaled, targets)
            else:
                # Sınıflandırma için targets'ı kategorilere çevir
                categories = np.digitize(targets, bins=np.percentile(targets, [33, 67]))
                learning_model.model.fit(features_scaled, categories)
            
            # Model bilgilerini güncelle
            learning_model.last_trained = datetime.now().timestamp()
            learning_model.training_data_size = len(features)
            
            # Performance metriklerini hesapla
            predictions = learning_model.model.predict(features_scaled)
            mse = np.mean((targets - predictions) ** 2)
            learning_model.performance_metrics = {'mse': mse}
            
            # Feature importance (Random Forest için)
            if learning_model.algorithm == 'random_forest':
                if hasattr(learning_model.model, 'feature_importances_'):
                    learning_model.feature_importance = {
                        f'feature_{i}': importance 
                        for i, importance in enumerate(learning_model.model.feature_importances_)
                    }
            
            self.logger.info(f"Model eğitildi: {learning_model.model_id} - Veri boyutu: {len(features)}")
            
        except Exception as e:
            self.logger.error(f"Model eğitim hatası: {e}")
    
    def predict(self, model_id: str, features: Dict[str, float]) -> Optional[float]:
        """
        Tahmin yap
        
        Args:
            model_id: Model ID
            features: Özellikler
        
        Returns:
            Optional[float]: Tahmin değeri
        """
        try:
            if model_id not in self.models:
                return None
            
            learning_model = self.models[model_id]
            
            # Özellikleri sayısal formata çevir
            numeric_features = [v for v in features.values() if isinstance(v, (int, float))]
            
            if len(numeric_features) == 0:
                return None
            
            # Normalize et
            if learning_model.scaler:
                features_scaled = learning_model.scaler.transform([numeric_features])
            else:
                features_scaled = [numeric_features]
            
            # Tahmin yap
            prediction = learning_model.model.predict(features_scaled)[0]
            
            # Geri bildirim kaydı
            feedback = LearningFeedback(
                feedback_id=f"{model_id}_{int(datetime.now().timestamp() * 1000)}",
                model_id=model_id,
                timestamp=datetime.now().timestamp(),
                input_data=features,
                predicted_value=prediction
            )
            
            self.feedback_buffer.append(feedback)
            
            return prediction
            
        except Exception as e:
            self.logger.error(f"Tahmin hatası: {e}")
            return None
    
    def provide_feedback(self, model_id: str, actual_value: float, 
                        reward: float = None, action_taken: str = None) -> bool:
        """
        Geri bildirim sağla
        
        Args:
            model_id: Model ID
            actual_value: Gerçek değer
            reward: Ödül
            action_taken: Alınan eylem
        
        Returns:
            bool: İşlem başarısı
        """
        try:
            # Son geri bildirim buffer'ını kontrol et
            for feedback in reversed(self.feedback_buffer):
                if feedback.model_id == model_id:
                    feedback.actual_value = actual_value
                    feedback.reward = reward
                    feedback.action_taken = action_taken
                    
                    # Model performansını güncelle
                    self._update_model_performance(model_id, feedback)
                    
                    return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Geri bildirim hatası: {e}")
            return False
    
    def _update_model_performance(self, model_id: str, feedback: LearningFeedback):
        """Model performansını güncelle"""
        try:
            if model_id in self.models:
                model = self.models[model_id]
                
                # Tahmin hatası
                if feedback.actual_value is not None and feedback.predicted_value is not None:
                    prediction_error = abs(feedback.predicted_value - feedback.actual_value)
                    
                    # Performans geçmişine ekle
                    self.performance_history[model_id].append({
                        'timestamp': feedback.timestamp,
                        'prediction_error': prediction_error,
                        'reward': feedback.reward
                    })
                    
                    # Performans metriklerini güncelle
                    recent_errors = [p['prediction_error'] for p in list(self.performance_history[model_id])[-10:]]
                    avg_error = np.mean(recent_errors) if recent_errors else 0
                    
                    if model.performance_metrics:
                        model.performance_metrics['avg_prediction_error'] = avg_error
                
        except Exception as e:
            self.logger.error(f"Performans güncelleme hatası: {e}")
    
    def _clear_processed_feedback(self, model_id: str):
        """İşlenmiş geri bildirimleri temizle"""
        # Eski geri bildirimleri temizle
        cutoff_time = datetime.now().timestamp() - 3600  # 1 saat
        
        self.feedback_buffer = deque(
            [f for f in self.feedback_buffer if f.timestamp > cutoff_time],
            maxlen=1000
        )
    
    def _train_sgd_model(self, model: Any, data: Dict[str, List]):
        """SGD model eğitimi"""
        # Online learning için incremental training
        features = np.array(data['features'])
        targets = np.array(data['targets'])
        
        # Küçük batch'ler halinde eğit
        batch_size = min(32, len(features))
        for i in range(0, len(features), batch_size):
            end_idx = min(i + batch_size, len(features))
            X_batch = features[i:end_idx]
            y_batch = targets[i:end_idx]
            
            model.partial_fit(X_batch, y_batch)
    
    def _train_random_forest(self, model: Any, data: Dict[str, List]):
        """Random Forest model eğitimi"""
        # Batch training
        features = np.array(data['features'])
        targets = np.array(data['targets'])
        
        model.fit(features, targets)
    
    def _incremental_learning(self, model: Any, data: Dict[str, List]):
        """Artımsal öğrenme"""
        # Hibrit yaklaşım
        self._train_sgd_model(model, data)
    
    def get_model_info(self, model_id: str) -> Optional[Dict[str, Any]]:
        """Model bilgilerini getir"""
        if model_id not in self.models:
            return None
        
        model = self.models[model_id]
        
        return {
            'model_id': model_id,
            'model_type': model.model_type,
            'algorithm': model.algorithm,
            'last_trained': model.last_trained,
            'training_data_size': model.training_data_size,
            'performance_metrics': model.performance_metrics,
            'feature_importance': model.feature_importance,
            'data_buffer_size': len(self.training_data[model_id])
        }
    
    def get_learning_statistics(self) -> Dict[str, Any]:
        """Öğrenme istatistiklerini getir"""
        with self.lock:
            total_models = len(self.models)
            active_models = sum(1 for model in self.models.values() 
                              if model.training_data_size > 0)
            
            total_training_data = sum(len(data) for data in self.training_data.values())
            total_feedback = len(self.feedback_buffer)
            
            # Ortalama performans
            avg_errors = []
            for model_id in self.models:
                if model_id in self.performance_history and self.performance_history[model_id]:
                    recent_error = self.performance_history[model_id][-1].get('prediction_error', 0)
                    avg_errors.append(recent_error)
            
            return {
                'total_models': total_models,
                'active_models': active_models,
                'total_training_data_points': total_training_data,
                'total_feedback_provided': total_feedback,
                'avg_prediction_error': np.mean(avg_errors) if avg_errors else 0.0,
                'learning_frequency_minutes': self.learning_config['learning_frequency_minutes']
            }
    
    def save_models(self, filepath: str):
        """Modelleri kaydet"""
        try:
            model_data = {}
            
            for model_id, learning_model in self.models.items():
                model_data[model_id] = {
                    'model_id': model_id,
                    'model_type': learning_model.model_type,
                    'algorithm': learning_model.algorithm,
                    'model': pickle.dumps(learning_model.model),
                    'scaler': pickle.dumps(learning_model.scaler) if learning_model.scaler else None,
                    'last_trained': learning_model.last_trained,
                    'training_data_size': learning_model.training_data_size,
                    'performance_metrics': learning_model.performance_metrics,
                    'feature_importance': learning_model.feature_importance
                }
            
            with open(filepath, 'wb') as f:
                pickle.dump(model_data, f)
            
            self.logger.info(f"Modeller kaydedildi: {filepath}")
            
        except Exception as e:
            self.logger.error(f"Model kaydetme hatası: {e}")
    
    def load_models(self, filepath: str):
        """Modelleri yükle"""
        try:
            with open(filepath, 'rb') as f:
                model_data = pickle.load(f)
            
            for model_id, data in model_data.items():
                model = pickle.loads(data['model'])
                scaler = pickle.loads(data['scaler']) if data['scaler'] else None
                
                learning_model = LearningModel(
                    model_id=model_id,
                    model_type=data['model_type'],
                    algorithm=data['algorithm'],
                    model=model,
                    scaler=scaler,
                    last_trained=data['last_trained'],
                    training_data_size=data['training_data_size'],
                    performance_metrics=data['performance_metrics'],
                    feature_importance=data['feature_importance']
                )
                
                self.models[model_id] = learning_model
            
            self.logger.info(f"Modeller yüklendi: {filepath}")
            
        except Exception as e:
            self.logger.error(f"Model yükleme hatası: {e}")
    
    def delete_model(self, model_id: str) -> bool:
        """Modeli sil"""
        try:
            if model_id in self.models:
                with self.lock:
                    del self.models[model_id]
                    if model_id in self.training_data:
                        del self.training_data[model_id]
                    if model_id in self.performance_history:
                        del self.performance_history[model_id]
                
                self.logger.info(f"Model silindi: {model_id}")
                return True
            
            return False
            
        except Exception as e:
            self.logger.error(f"Model silme hatası: {e}")
            return False