"""
Drift Detector - Model Drift Tespit Sistemi
==========================================

Bu modül, model performansındaki drift'i (kaymaları) tespit eder ve analiz eder.
"""

import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import threading
from collections import deque, defaultdict
from scipy import stats
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
from sklearn.covariance import EllipticEnvelope
from sklearn.ensemble import IsolationForest
from sklearn.cluster import DBSCAN

@dataclass
class DriftEvent:
    """Drift olayı veri yapısı"""
    event_id: str
    timestamp: float
    model_name: str
    drift_type: str  # 'performance', 'data_distribution', 'concept_drift'
    severity: str  # 'low', 'medium', 'high', 'critical'
    drift_score: float
    description: str
    metrics_before: Dict[str, float]
    metrics_after: Dict[str, float]
    recommendation: str

@dataclass
class DriftMetrics:
    """Drift metrikleri"""
    model_name: str
    timestamp: float
    performance_drift: float
    distribution_drift: float
    concept_drift: float
    overall_drift_score: float
    significance_level: float
    is_drift_detected: bool

class DriftDetector:
    """
    Model Drift Tespit Sistemi
    
    Model performansındaki drift'i (kaymaları) tespit eder ve sınıflandırır.
    """
    
    def __init__(self, window_size: int = 100, significance_level: float = 0.05):
        """
        Drift Detector başlat
        
        Args:
            window_size: Drift tespiti için pencere boyutu
            significance_level: İstatistiksel anlamlılık seviyesi
        """
        self.logger = logging.getLogger(__name__)
        self.window_size = window_size
        self.significance_level = significance_level
        
        # Drift verilerini sakla
        self.performance_history = defaultdict(deque)
        self.data_history = defaultdict(deque)
        self.prediction_history = defaultdict(deque)
        self.drift_events = deque(maxlen=1000)
        self.drift_metrics_history = deque(maxlen=1000)
        
        # Drift tespit modelleri
        self.outlier_detectors = {}
        self.baseline_metrics = {}
        self.reference_periods = {}
        
        # Eşik değerler
        self.drift_thresholds = {
            'performance_drift': 0.1,  # %10 performans düşüşü
            'distribution_drift': 0.05,  # %5 dağılım değişikliği
            'concept_drift': 0.15,  # %15 kavram değişikliği
            'severity_levels': {
                'low': 0.05,
                'medium': 0.10,
                'high': 0.20,
                'critical': 0.30
            }
        }
        
        # Thread güvenliği
        self.lock = threading.Lock()
        
        self.logger.info("Drift Detector başlatıldı")
    
    def register_model(self, model_name: str, initial_performance: Dict[str, float],
                      baseline_data: np.ndarray = None):
        """
        Modeli drift takibi için kaydet
        
        Args:
            model_name: Model adı
            initial_performance: Başlangıç performans metrikleri
            baseline_data: Referans veri seti
        """
        with self.lock:
            self.baseline_metrics[model_name] = initial_performance
            
            if baseline_data is not None:
                self.data_history[model_name].append(baseline_data)
                
                # Outlier detector oluştur
                try:
                    self.outlier_detectors[model_name] = EllipticEnvelope(contamination=0.1)
                    self.outlier_detectors[model_name].fit(baseline_data.reshape(-1, 1))
                except:
                    # DBSCAN kullan
                    self.outlier_detectors[model_name] = DBSCAN(eps=0.1, min_samples=5)
                    self.outlier_detectors[model_name].fit(baseline_data.reshape(-1, 1))
            
            self.reference_periods[model_name] = {
                'start_time': datetime.now().timestamp(),
                'baseline_performance': initial_performance,
                'data_samples': baseline_data.shape[0] if baseline_data is not None else 0
            }
            
            self.logger.info(f"Model kaydedildi drift takibi için: {model_name}")
    
    def detect_drift(self, performance_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Model drift'ini tespit et
        
        Args:
            performance_data: Performans verileri
        
        Returns:
            Dict[str, Any]: Drift tespit sonuçları
        """
        try:
            drift_results = {}
            
            # Her model için drift kontrolü
            for model_name in self.baseline_metrics.keys():
                model_drift = self._analyze_model_drift(model_name, performance_data)
                drift_results[model_name] = model_drift
                
                # Kritik drift tespit edilirse olay oluştur
                if model_drift['is_drift_detected']:
                    self._create_drift_event(model_name, model_drift, performance_data)
            
            return drift_results
            
        except Exception as e:
            self.logger.error(f"Drift tespiti hatası: {e}")
            return {}
    
    def _analyze_model_drift(self, model_name: str, performance_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Tek bir model için drift analizi
        
        Args:
            model_name: Model adı
            performance_data: Performans verileri
        
        Returns:
            Dict[str, Any]: Drift analiz sonuçları
        """
        # Performans drift'i kontrol et
        performance_drift = self._detect_performance_drift(model_name, performance_data)
        
        # Veri dağılım drift'i kontrol et
        distribution_drift = self._detect_distribution_drift(model_name, performance_data)
        
        # Kavram drift'i kontrol et
        concept_drift = self._detect_concept_drift(model_name, performance_data)
        
        # Genel drift skoru hesapla
        overall_drift_score = np.mean([
            performance_drift['score'],
            distribution_drift['score'],
            concept_drift['score']
        ])
        
        # Drift tespiti yap
        is_drift_detected = (
            performance_drift['score'] > self.drift_thresholds['performance_drift'] or
            distribution_drift['score'] > self.drift_thresholds['distribution_drift'] or
            concept_drift['score'] > self.drift_thresholds['concept_drift']
        )
        
        # Drift metriklerini kaydet
        drift_metrics = DriftMetrics(
            model_name=model_name,
            timestamp=datetime.now().timestamp(),
            performance_drift=performance_drift['score'],
            distribution_drift=distribution_drift['score'],
            concept_drift=concept_drift['score'],
            overall_drift_score=overall_drift_score,
            significance_level=self.significance_level,
            is_drift_detected=is_drift_detected
        )
        
        self.drift_metrics_history.append(drift_metrics)
        
        return {
            'model_name': model_name,
            'performance_drift': performance_drift,
            'distribution_drift': distribution_drift,
            'concept_drift': concept_drift,
            'overall_drift_score': overall_drift_score,
            'is_drift_detected': is_drift_detected,
            'severity': self._determine_drift_severity(overall_drift_score),
            'significance': self._check_statistical_significance(overall_drift_score)
        }
    
    def _detect_performance_drift(self, model_name: str, performance_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Performans drift'ini tespit et
        
        Args:
            model_name: Model adı
            performance_data: Performans verileri
        
        Returns:
            Dict[str, Any]: Performans drift analizi
        """
        # Mevcut performans metrikleri
        current_metrics = performance_data.get(model_name, {})
        
        if not current_metrics:
            return {'score': 0.0, 'details': 'Veri yok'}
        
        # Baseline metrikler
        baseline = self.baseline_metrics.get(model_name, {})
        
        # Temel metriklerdeki değişim
        drift_scores = []
        
        for metric_name, current_value in current_metrics.items():
            if metric_name in baseline:
                baseline_value = baseline[metric_name]
                
                if baseline_value != 0:
                    # Göreli değişim
                    relative_change = abs(current_value - baseline_value) / abs(baseline_value)
                    drift_scores.append(relative_change)
                else:
                    # Mutlak değişim (baseline 0 ise)
                    drift_scores.append(abs(current_value))
        
        # Performans drift skoru
        performance_drift_score = np.mean(drift_scores) if drift_scores else 0.0
        
        return {
            'score': performance_drift_score,
            'details': {
                'metrics_compared': len(drift_scores),
                'max_change': max(drift_scores) if drift_scores else 0.0,
                'avg_change': np.mean(drift_scores) if drift_scores else 0.0
            },
            'significant_metrics': [score for score in drift_scores if score > 0.1]
        }
    
    def _detect_distribution_drift(self, model_name: str, performance_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Veri dağılım drift'ini tespit et
        
        Args:
            model_name: Model adı
            performance_data: Performans verileri
        
        Returns:
            Dict[str, Any]: Dağılım drift analizi
        """
        # Yeni veri noktalarını topla
        new_data_points = performance_data.get(f"{model_name}_data", [])
        
        if not new_data_points:
            return {'score': 0.0, 'details': 'Veri noktası yok'}
        
        new_data = np.array(new_data_points)
        
        # Outlier detection kullan
        if model_name in self.outlier_detectors:
            try:
                detector = self.outlier_detectors[model_name]
                
                # Outlier oranını hesapla
                if hasattr(detector, 'predict'):
                    predictions = detector.predict(new_data.reshape(-1, 1))
                    outlier_ratio = np.sum(predictions == -1) / len(predictions)
                    
                    # Distribution drift skoru
                    distribution_drift_score = outlier_ratio
                    
                    return {
                        'score': distribution_drift_score,
                        'details': {
                            'outliers_detected': np.sum(predictions == -1),
                            'total_points': len(predictions),
                            'outlier_ratio': outlier_ratio
                        }
                    }
            except Exception as e:
                self.logger.warning(f"Outlier detection hatası ({model_name}): {e}")
        
        # Kolmogorov-Smirnov test kullan (normal dağılım varsayımı)
        if len(self.data_history[model_name]) > 0:
            baseline_data = list(self.data_history[model_name])[0]
            
            try:
                # KS test
                ks_statistic, p_value = stats.ks_2samp(baseline_data, new_data)
                
                distribution_drift_score = ks_statistic
                
                return {
                    'score': distribution_drift_score,
                    'details': {
                        'ks_statistic': ks_statistic,
                        'p_value': p_value,
                        'is_significant': p_value < self.significance_level
                    }
                }
            except Exception as e:
                self.logger.warning(f"KS test hatası ({model_name}): {e}")
        
        return {'score': 0.0, 'details': 'Test uygulanamadı'}
    
    def _detect_concept_drift(self, model_name: str, performance_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Kavram drift'ini tespit et
        
        Args:
            model_name: Model adı
            performance_data: Performans verileri
        
        Returns:
            Dict[str, Any]: Kavram drift analizi
        """
        # Tahmin sonuçları
        predictions = performance_data.get(f"{model_name}_predictions", [])
        actual_labels = performance_data.get(f"{model_name}_actual", [])
        
        if len(predictions) < 10 or len(actual_labels) < 10:
            return {'score': 0.0, 'details': 'Yeterli veri yok'}
        
        # Model tahmin doğruluğu
        try:
            current_accuracy = accuracy_score(actual_labels, predictions)
            
            # Geçmiş performans geçmişinden ortalamayı al
            if len(self.prediction_history[model_name]) > 0:
                historical_accuracies = []
                for history_item in list(self.prediction_history[model_name])[-10:]:
                    if 'accuracy' in history_item:
                        historical_accuracies.append(history_item['accuracy'])
                
                if historical_accuracies:
                    avg_historical_accuracy = np.mean(historical_accuracies)
                    
                    # Kavram drift skoru
                    concept_drift_score = abs(current_accuracy - avg_historical_accuracy)
                    
                    return {
                        'score': concept_drift_score,
                        'details': {
                            'current_accuracy': current_accuracy,
                            'historical_avg_accuracy': avg_historical_accuracy,
                            'accuracy_change': concept_drift_score
                        }
                    }
        except Exception as e:
            self.logger.warning(f"Kavram drift analizi hatası ({model_name}): {e}")
        
        return {'score': 0.0, 'details': 'Analiz uygulanamadı'}
    
    def _determine_drift_severity(self, drift_score: float) -> str:
        """Drift şiddetini belirle"""
        thresholds = self.drift_thresholds['severity_levels']
        
        if drift_score >= thresholds['critical']:
            return 'critical'
        elif drift_score >= thresholds['high']:
            return 'high'
        elif drift_score >= thresholds['medium']:
            return 'medium'
        else:
            return 'low'
    
    def _check_statistical_significance(self, drift_score: float) -> bool:
        """İstatistiksel anlamlılığı kontrol et"""
        # Basit eşik tabanlı kontrol (gerçek uygulamada daha karmaşık olabilir)
        return drift_score > self.significance_level
    
    def _create_drift_event(self, model_name: str, drift_analysis: Dict[str, Any], 
                          performance_data: Dict[str, Any]):
        """
        Drift olayı oluştur
        
        Args:
            model_name: Model adı
            drift_analysis: Drift analizi
            performance_data: Performans verileri
        """
        event_id = f"drift_{model_name}_{int(datetime.now().timestamp() * 1000)}"
        
        # En yüksek drift tipini belirle
        drift_types = [
            ('performance', drift_analysis['performance_drift']['score']),
            ('distribution', drift_analysis['distribution_drift']['score']),
            ('concept', drift_analysis['concept_drift']['score'])
        ]
        
        max_drift_type, max_drift_score = max(drift_types, key=lambda x: x[1])
        
        # Öneri oluştur
        recommendation = self._generate_drift_recommendation(model_name, drift_analysis)
        
        # Drift olayı oluştur
        drift_event = DriftEvent(
            event_id=event_id,
            timestamp=datetime.now().timestamp(),
            model_name=model_name,
            drift_type=max_drift_type,
            severity=drift_analysis['severity'],
            drift_score=max_drift_score,
            description=f"{model_name} modelinde {max_drift_type} drift tespit edildi (skor: {max_drift_score:.3f})",
            metrics_before=self.baseline_metrics.get(model_name, {}),
            metrics_after=performance_data.get(model_name, {}),
            recommendation=recommendation
        )
        
        self.drift_events.append(drift_event)
        
        self.logger.warning(f"Drift tespit edildi - {model_name}: {drift_event.description}")
    
    def _generate_drift_recommendation(self, model_name: str, drift_analysis: Dict[str, Any]) -> str:
        """
        Drift için öneri oluştur
        
        Args:
            model_name: Model adı
            drift_analysis: Drift analizi
        
        Returns:
            str: Öneri metni
        """
        severity = drift_analysis['severity']
        
        if severity == 'critical':
            return f"{model_name} modeli acil olarak yeniden eğitilmeli. Kritik drift tespit edildi."
        elif severity == 'high':
            return f"{model_name} modeli kısa sürede yeniden eğitilmeli. Yüksek drift tespit edildi."
        elif severity == 'medium':
            return f"{model_name} modeli parametreleri gözden geçirilmeli. Orta seviye drift tespit edildi."
        else:
            return f"{model_name} modeli izlenmeli. Düşük seviye drift tespit edildi."
    
    def get_recent_drift_events(self, hours: int = 24) -> List[DriftEvent]:
        """
        Son drift olaylarını getir
        
        Args:
            hours: Kaç saat geriye bakılacak
        
        Returns:
            List[DriftEvent]: Drift olayları
        """
        cutoff_time = datetime.now().timestamp() - (hours * 3600)
        return [event for event in self.drift_events 
                if event.timestamp > cutoff_time]
    
    def get_drift_statistics(self) -> Dict[str, Any]:
        """Drift istatistiklerini getir"""
        if not self.drift_metrics_history:
            return {}
        
        recent_metrics = list(self.drift_metrics_history)[-100:]  # Son 100 kayıt
        
        # Drift tespit oranı
        drift_detected_count = sum(1 for m in recent_metrics if m.is_drift_detected)
        drift_rate = drift_detected_count / len(recent_metrics)
        
        # Ortalama drift skorları
        avg_performance_drift = np.mean([m.performance_drift for m in recent_metrics])
        avg_distribution_drift = np.mean([m.distribution_drift for m in recent_metrics])
        avg_concept_drift = np.mean([m.concept_drift for m in recent_metrics])
        avg_overall_drift = np.mean([m.overall_drift_score for m in recent_metrics])
        
        # Model bazında drift analizi
        model_drift_stats = defaultdict(lambda: {
            'drift_events': 0,
            'avg_drift_score': 0.0,
            'severity_distribution': defaultdict(int)
        })
        
        for event in self.drift_events:
            model_stats = model_drift_stats[event.model_name]
            model_stats['drift_events'] += 1
            model_stats['severity_distribution'][event.severity] += 1
        
        # Model bazında ortalama drift skorları
        model_scores = defaultdict(list)
        for metrics in recent_metrics:
            model_scores[metrics.model_name].append(metrics.overall_drift_score)
        
        for model_name, scores in model_scores.items():
            model_drift_stats[model_name]['avg_drift_score'] = np.mean(scores)
        
        return {
            'total_models_monitored': len(self.baseline_metrics),
            'drift_rate_24h': drift_rate,
            'avg_performance_drift': avg_performance_drift,
            'avg_distribution_drift': avg_distribution_drift,
            'avg_concept_drift': avg_concept_drift,
            'avg_overall_drift': avg_overall_drift,
            'total_drift_events': len(self.drift_events),
            'model_drift_statistics': dict(model_drift_stats),
            'recent_drift_events_count': len(self.get_recent_drift_events(24))
        }
    
    def update_baseline(self, model_name: str, new_performance: Dict[str, float]):
        """
        Model baseline'ını güncelle
        
        Args:
            model_name: Model adı
            new_performance: Yeni performans metrikleri
        """
        with self.lock:
            self.baseline_metrics[model_name] = new_performance
            self.reference_periods[model_name]['last_update'] = datetime.now().timestamp()
            
            self.logger.info(f"Model baseline güncellendi: {model_name}")
    
    def reset_model(self, model_name: str):
        """
        Model drift takibini sıfırla
        
        Args:
            model_name: Model adı
        """
        with self.lock:
            # Drift geçmişini temizle
            self.drift_metrics_history = deque(
                [m for m in self.drift_metrics_history if m.model_name != model_name],
                maxlen=1000
            )
            
            self.logger.info(f"Model drift takibi sıfırlandı: {model_name}")