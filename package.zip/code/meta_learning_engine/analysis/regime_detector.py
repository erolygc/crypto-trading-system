"""
Regime Detector - Rejim Değişikliği Tespit Sistemi
=================================================

Bu modül, piyasa rejimlerini tespit eder ve değişiklikleri analiz eder.
"""

import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import threading
from collections import deque, defaultdict
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.mixture import GaussianMixture

@dataclass
class MarketRegime:
    """Piyasa rejimi veri yapısı"""
    regime_id: str
    name: str
    characteristics: Dict[str, float]
    probability: float
    start_time: float
    confidence: float
    key_metrics: Dict[str, Any]

@dataclass
class RegimeTransition:
    """Rejim geçişi veri yapısı"""
    from_regime: str
    to_regime: str
    transition_time: float
    confidence: float
    duration: float
    causes: List[str]

class RegimeDetector:
    """
    Rejim Değişikliği Tespit Sistemi
    
    Piyasa rejimlerini tanımlar, tespit eder ve değişiklikleri analiz eder.
    """
    
    def __init__(self, n_regimes: int = 4, lookback_window: int = 252):
        """
        Regime Detector başlat
        
        Args:
            n_regimes: Tespit edilecek rejim sayısı
            lookback_window: Geçmişe bakma penceresi
        """
        self.logger = logging.getLogger(__name__)
        self.n_regimes = n_regimes
        self.lookback_window = lookback_window
        
        # Rejim verilerini sakla
        self.regime_history = deque(maxlen=lookback_window)
        self.current_regime = None
        self.regime_transitions = deque(maxlen=100)
        
        # Model bileşenleri
        self.regime_classifier = None
        self.feature_scaler = StandardScaler()
        self.transition_detector = None
        
        # Rejim tanımları
        self.regime_definitions = {
            'bull_market': {
                'name': 'Yükseliş Piyasası',
                'characteristics': {
                    'volatility': 'low',
                    'trend': 'positive',
                    'volume': 'normal',
                    'momentum': 'high'
                }
            },
            'bear_market': {
                'name': 'Düşüş Piyasası',
                'characteristics': {
                    'volatility': 'high',
                    'trend': 'negative',
                    'volume': 'normal',
                    'momentum': 'low'
                }
            },
            'sideways_market': {
                'name': 'Yatay Piyasa',
                'characteristics': {
                    'volatility': 'low',
                    'trend': 'neutral',
                    'volume': 'normal',
                    'momentum': 'medium'
                }
            },
            'high_volatility': {
                'name': 'Yüksek Volatilite',
                'characteristics': {
                    'volatility': 'very_high',
                    'trend': 'uncertain',
                    'volume': 'high',
                    'momentum': 'variable'
                }
            }
        }
        
        # Eşik değerler
        self.transition_threshold = 0.7  # Rejim değişikliği için güven eşiği
        self.min_regime_duration = 10  # Minimum rejim süresi (gün)
        
        # Thread güvenliği
        self.lock = threading.Lock()
        
        self.logger.info("Regime Detector başlatıldı")
    
    def detect_regime(self, performance_data: Dict[str, Any]) -> str:
        """
        Mevcut piyasa rejimini tespit et
        
        Args:
            performance_data: Performans verileri
        
        Returns:
            str: Tespit edilen rejim adı
        """
        try:
            with self.lock:
                # Özellik vektörü oluştur
                features = self._extract_features(performance_data)
                
                # Rejim tespiti yap
                regime_probabilities = self._classify_regime(features)
                
                # En yüksek olasılıklı rejimi seç
                current_regime = max(regime_probabilities, key=regime_probabilities.get)
                confidence = regime_probabilities[current_regime]
                
                # Rejim değişikliği kontrolü
                if (self.current_regime != current_regime and 
                    confidence >= self.transition_threshold and
                    self._check_regime_duration()):
                    
                    self._handle_regime_change(current_regime, confidence, features)
                
                # Mevcut rejimi güncelle
                self.current_regime = current_regime
                
                # Rejim verisini sakla
                regime_data = MarketRegime(
                    regime_id=f"{current_regime}_{int(datetime.now().timestamp())}",
                    name=self.regime_definitions.get(current_regime, {}).get('name', current_regime),
                    characteristics=self.regime_definitions.get(current_regime, {}).get('characteristics', {}),
                    probability=confidence,
                    start_time=datetime.now().timestamp(),
                    confidence=confidence,
                    key_metrics=features
                )
                
                self.regime_history.append(regime_data)
                
                return current_regime
                
        except Exception as e:
            self.logger.error(f"Rejim tespiti hatası: {e}")
            return 'unknown'
    
    def _extract_features(self, performance_data: Dict[str, Any]) -> Dict[str, float]:
        """
        Rejim tespiti için özellik vektörü çıkar
        
        Args:
            performance_data: Performans verileri
        
        Returns:
            Dict[str, float]: Özellikler
        """
        features = {}
        
        # Volatilite özellikleri
        if 'returns' in performance_data:
            returns = np.array(performance_data['returns'])
            if len(returns) > 0:
                features['volatility'] = np.std(returns)
                features['volatility_percentile'] = np.percentile(features['volatility'], 50)
                
                # GARCH benzeri volatilite ölçümü
                squared_returns = returns ** 2
                features['volatility_clustering'] = np.std(squared_returns[-10:]) if len(squared_returns) >= 10 else 0
        
        # Trend özellikleri
        if 'cumulative_returns' in performance_data:
            cum_returns = np.array(performance_data['cumulative_returns'])
            if len(cum_returns) > 1:
                features['trend_strength'] = (cum_returns[-1] - cum_returns[0]) / len(cum_returns)
                features['trend_consistency'] = np.mean(np.diff(cum_returns) > 0)
        
        # Momentum özellikleri
        if 'returns' in performance_data:
            returns = np.array(performance_data['returns'])
            if len(returns) >= 20:
                features['momentum_20'] = np.mean(returns[-20:])
                features['momentum_momentum'] = np.mean(returns[-10:]) - np.mean(returns[-20:-10])
        
        # Hacim özellikleri
        if 'volume' in performance_data:
            volume = np.array(performance_data['volume'])
            if len(volume) > 0:
                features['volume_level'] = np.mean(volume)
                features['volume_trend'] = np.mean(np.diff(volume[-10:])) if len(volume) >= 10 else 0
        
        # Risk metrikleri
        if 'var_95' in performance_data:
            features['var_95'] = performance_data['var_95']
        if 'max_drawdown' in performance_data:
            features['max_drawdown'] = performance_data['max_drawdown']
        
        # Rejim karakteristikleri
        features.update(self._calculate_regime_characteristics(performance_data))
        
        return features
    
    def _calculate_regime_characteristics(self, performance_data: Dict[str, Any]) -> Dict[str, float]:
        """Rejim karakteristiklerini hesapla"""
        characteristics = {}
        
        # Zaman serisi özelliklerini hesapla
        if 'returns' in performance_data:
            returns = np.array(performance_data['returns'])
            
            if len(returns) > 0:
                # Otokorelasyon
                if len(returns) > 1:
                    autocorr_1 = np.corrcoef(returns[:-1], returns[1:])[0, 1]
                    characteristics['autocorrelation'] = autocorr_1 if not np.isnan(autocorr_1) else 0
                
                # Çarpıklık ve basıklık
                if len(returns) > 2:
                    characteristics['skewness'] = float(pd.Series(returns).skew())
                    characteristics['kurtosis'] = float(pd.Series(returns).kurtosis())
                
                # Yön değişim sıklığı
                if len(returns) > 1:
                    direction_changes = sum(1 for i in range(1, len(returns)) 
                                          if returns[i-1] * returns[i] < 0)
                    characteristics['direction_change_frequency'] = direction_changes / len(returns)
        
        return characteristics
    
    def _classify_regime(self, features: Dict[str, float]) -> Dict[str, float]:
        """
        Özellikleri kullanarak rejim sınıflandırması yap
        
        Args:
            features: Özellikler
        
        Returns:
            Dict[str, float]: Rejim olasılıkları
        """
        if not self.regime_classifier:
            self._initialize_classifier()
        
        # Features'ları numpy array'e çevir
        feature_vector = np.array(list(features.values())).reshape(1, -1)
        
        # Eksik değerleri kontrol et
        if np.any(np.isnan(feature_vector)):
            # NaN değerleri 0 ile değiştir
            feature_vector = np.nan_to_num(feature_vector, nan=0.0)
        
        # Normalize et
        feature_vector_scaled = self.feature_scaler.transform(feature_vector)
        
        # Rejim olasılıklarını al
        if hasattr(self.regime_classifier, 'predict_proba'):
            probabilities = self.regime_classifier.predict_proba(feature_vector_scaled)[0]
        else:
            # KMeans için en yakın cluster'ı bul
            cluster_labels = self.regime_classifier.predict(feature_vector_scaled)
            probabilities = np.zeros(self.n_regimes)
            probabilities[cluster_labels[0]] = 1.0
        
        # Rejim adları ile eşleştir
        regime_names = list(self.regime_definitions.keys())
        if len(regime_names) != len(probabilities):
            # Rejim sayısını ayarla
            regime_names = [f'regime_{i}' for i in range(len(probabilities))]
        
        regime_probabilities = {}
        for i, prob in enumerate(probabilities):
            regime_name = regime_names[i] if i < len(regime_names) else f'regime_{i}'
            regime_probabilities[regime_name] = float(prob)
        
        return regime_probabilities
    
    def _initialize_classifier(self):
        """Sınıflandırıcıyı başlat"""
        try:
            # Geçmiş verilerden örnekler oluştur (gerçek uygulamada historical data kullanılır)
            synthetic_data = self._generate_synthetic_regime_data()
            
            if len(synthetic_data) > 0:
                features = np.array([list(sample.keys()) for sample in synthetic_data])
                labels = np.array([sample['regime'] for sample in synthetic_data])
                
                # Eksik değerleri temizle
                features = np.nan_to_num(features)
                
                # Normalize et
                features_scaled = self.feature_scaler.fit_transform(features)
                
                # KMeans veya Gaussian Mixture Model kullan
                try:
                    self.regime_classifier = GaussianMixture(
                        n_components=self.n_regimes, 
                        random_state=42
                    )
                    self.regime_classifier.fit(features_scaled)
                except:
                    self.regime_classifier = KMeans(
                        n_clusters=self.n_regimes, 
                        random_state=42,
                        n_init=10
                    )
                    self.regime_classifier.fit(features_scaled)
                
                self.logger.info("Rejim sınıflandırıcısı başlatıldı")
                
        except Exception as e:
            self.logger.error(f"Sınıflandırıcı başlatma hatası: {e}")
            # Basit heuristic classifier kullan
            self.regime_classifier = None
    
    def _generate_synthetic_regime_data(self) -> List[Dict[str, Any]]:
        """Sentetik rejim verileri oluştur (eğitim için)"""
        synthetic_data = []
        
        # Her rejim için örnekler oluştur
        for regime_name, definition in self.regime_definitions.items():
            for _ in range(20):  # Her rejim için 20 örnek
                sample = {'regime': regime_name}
                
                # Rejim karakteristiğine göre features oluştur
                if regime_name == 'bull_market':
                    sample.update({
                        'volatility': np.random.normal(0.015, 0.005),
                        'trend_strength': np.random.normal(0.001, 0.0005),
                        'momentum_20': np.random.normal(0.0005, 0.0002),
                        'var_95': np.random.normal(0.02, 0.005),
                        'max_drawdown': np.random.normal(0.05, 0.02)
                    })
                elif regime_name == 'bear_market':
                    sample.update({
                        'volatility': np.random.normal(0.035, 0.01),
                        'trend_strength': np.random.normal(-0.001, 0.0005),
                        'momentum_20': np.random.normal(-0.0005, 0.0002),
                        'var_95': np.random.normal(0.05, 0.01),
                        'max_drawdown': np.random.normal(0.15, 0.05)
                    })
                elif regime_name == 'sideways_market':
                    sample.update({
                        'volatility': np.random.normal(0.01, 0.003),
                        'trend_strength': np.random.normal(0.0, 0.0003),
                        'momentum_20': np.random.normal(0.0, 0.0001),
                        'var_95': np.random.normal(0.015, 0.003),
                        'max_drawdown': np.random.normal(0.03, 0.01)
                    })
                elif regime_name == 'high_volatility':
                    sample.update({
                        'volatility': np.random.normal(0.05, 0.015),
                        'trend_strength': np.random.normal(0.0, 0.001),
                        'momentum_20': np.random.normal(0.0, 0.0005),
                        'var_95': np.random.normal(0.08, 0.02),
                        'max_drawdown': np.random.normal(0.25, 0.1)
                    })
                
                synthetic_data.append(sample)
        
        return synthetic_data
    
    def _handle_regime_change(self, new_regime: str, confidence: float, features: Dict[str, float]):
        """
        Rejim değişikliğini işle
        
        Args:
            new_regime: Yeni rejim
            confidence: Güven seviyesi
            features: Özellikler
        """
        previous_regime = self.current_regime
        
        # Geçiş süresini hesapla
        if self.regime_history:
            last_regime = self.regime_history[-1]
            duration = datetime.now().timestamp() - last_regime.start_time
        else:
            duration = 0
        
        # Geçiş nedenlerini analiz et
        causes = self._analyze_regime_change_causes(features)
        
        # Geçiş kaydı oluştur
        transition = RegimeTransition(
            from_regime=previous_regime or 'unknown',
            to_regime=new_regime,
            transition_time=datetime.now().timestamp(),
            confidence=confidence,
            duration=duration,
            causes=causes
        )
        
        self.regime_transitions.append(transition)
        
        self.logger.info(f"Rejim değişikliği tespit edildi: {previous_regime} -> {new_regime} "
                        f"(güven: {confidence:.2f})")
    
    def _analyze_regime_change_causes(self, features: Dict[str, float]) -> List[str]:
        """Rejim değişikliği nedenlerini analiz et"""
        causes = []
        
        # Volatilite değişikliği
        if 'volatility' in features:
            if features['volatility'] > 0.03:
                causes.append("Yüksek volatilite")
            elif features['volatility'] < 0.015:
                causes.append("Düşük volatilite")
        
        # Trend değişikliği
        if 'trend_strength' in features:
            if features['trend_strength'] > 0.001:
                causes.append("Güçlü yukarı trend")
            elif features['trend_strength'] < -0.001:
                causes.append("Güçlü aşağı trend")
        
        # Momentum değişikliği
        if 'momentum_20' in features:
            if features['momentum_20'] > 0.0005:
                causes.append("Pozitif momentum")
            elif features['momentum_20'] < -0.0005:
                causes.append("Negatif momentum")
        
        return causes
    
    def _check_regime_duration(self) -> bool:
        """Minimum rejim süresini kontrol et"""
        if not self.regime_history:
            return True
        
        last_regime = self.regime_history[-1]
        duration = datetime.now().timestamp() - last_regime.start_time
        min_duration_seconds = self.min_regime_duration * 24 * 3600  # Günü saniyeye çevir
        
        return duration >= min_duration_seconds
    
    def get_current_regime(self) -> Optional[MarketRegime]:
        """Mevcut rejim bilgisini döndür"""
        if self.regime_history:
            return self.regime_history[-1]
        return None
    
    def get_regime_history(self, days: int = 30) -> List[MarketRegime]:
        """
        Rejim geçmişini getir
        
        Args:
            days: Kaç gün geriye bakılacak
        
        Returns:
            List[MarketRegime]: Rejim geçmişi
        """
        cutoff_time = datetime.now().timestamp() - (days * 24 * 3600)
        return [regime for regime in self.regime_history 
                if regime.start_time > cutoff_time]
    
    def get_regime_statistics(self) -> Dict[str, Any]:
        """Rejim istatistiklerini getir"""
        if not self.regime_history:
            return {}
        
        recent_regimes = list(self.regime_history)[-30:]  # Son 30 kayıt
        
        # Rejim dağılımı
        regime_counts = {}
        for regime in recent_regimes:
            regime_name = regime.name
            regime_counts[regime_name] = regime_counts.get(regime_name, 0) + 1
        
        # Ortalama güven seviyesi
        avg_confidence = np.mean([regime.confidence for regime in recent_regimes])
        
        # En sık görülen rejim
        most_common_regime = max(regime_counts, key=regime_counts.get) if regime_counts else None
        
        # Geçiş istatistikleri
        recent_transitions = [t for t in self.regime_transitions 
                             if t.transition_time > datetime.now().timestamp() - (30 * 24 * 3600)]
        
        return {
            'current_regime': self.current_regime,
            'regime_distribution': regime_counts,
            'most_common_regime': most_common_regime,
            'average_confidence': avg_confidence,
            'total_transitions_30d': len(recent_transitions),
            'avg_regime_duration_days': np.mean([t.duration / (24 * 3600) for t in recent_transitions]) if recent_transitions else 0,
            'transition_frequency': len(recent_transitions) / 30 if recent_transitions else 0
        }
    
    def predict_regime_probability(self, horizon_days: int = 5) -> Dict[str, float]:
        """
        Gelecek rejim olasılıklarını tahmin et
        
        Args:
            horizon_days: Tahmin ufku (gün)
        
        Returns:
            Dict[str, float]: Rejim olasılıkları
        """
        # Basit geçiş matrisi tabanlı tahmin
        if len(self.regime_transitions) < 2:
            return {regime: 1.0 / len(self.regime_definitions) for regime in self.regime_definitions.keys()}
        
        # Geçiş matrisi oluştur
        transition_matrix = self._build_transition_matrix()
        
        # Mevcut rejim vektörü
        current_state = np.zeros(len(self.regime_definitions))
        if self.current_regime in self.regime_definitions:
            current_state[list(self.regime_definitions.keys()).index(self.current_regime)] = 1.0
        
        # Tahmin (basit power method)
        future_state = np.linalg.matrix_power(transition_matrix, horizon_days).dot(current_state)
        
        # Rejim adları ile eşleştir
        probabilities = {}
        regime_names = list(self.regime_definitions.keys())
        for i, prob in enumerate(future_state):
            regime_name = regime_names[i] if i < len(regime_names) else f'regime_{i}'
            probabilities[regime_name] = float(prob)
        
        return probabilities
    
    def _build_transition_matrix(self) -> np.ndarray:
        """Geçiş matrisi oluştur"""
        n_regimes = len(self.regime_definitions)
        transition_matrix = np.ones((n_regimes, n_regimes)) / n_regimes  # Uniform başlangıç
        
        # Geçmiş geçişlerden sayıları say
        regime_names = list(self.regime_definitions.keys())
        
        for transition in self.regime_transitions:
            if transition.from_regime in regime_names and transition.to_regime in regime_names:
                from_idx = regime_names.index(transition.from_regime)
                to_idx = regime_names.index(transition.to_regime)
                transition_matrix[from_idx, to_idx] += 1
        
        # Normalize et (satır toplamları 1 olsun)
        row_sums = transition_matrix.sum(axis=1)
        for i in range(n_regimes):
            if row_sums[i] > 0:
                transition_matrix[i, :] /= row_sums[i]
        
        return transition_matrix