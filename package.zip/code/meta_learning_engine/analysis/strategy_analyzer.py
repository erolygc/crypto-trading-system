"""
Strategy Analyzer - Strateji Performans Analizi
==============================================

Bu modül, trading stratejilerinin performansını analiz eder ve kıyaslar.
"""

import logging
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from collections import defaultdict
import threading
from datetime import datetime, timedelta

@dataclass
class StrategyMetrics:
    """Strateji metrikleri"""
    strategy_name: str
    total_return: float
    annualized_return: float
    volatility: float
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown: float
    calmar_ratio: float
    win_rate: float
    profit_factor: float
    var_95: float
    cvar_95: float
    information_ratio: float
    beta: float
    alpha: float
    turnover: float
    unique_trades: int
    avg_trade_duration: float
    risk_adjusted_return: float
    consistency_score: float

@dataclass
class StrategyComparison:
    """Strateji karşılaştırma sonucu"""
    best_strategy: str
    ranking: List[Tuple[str, float]]
    correlation_matrix: np.ndarray
    correlation_threshold: float
    similar_strategies: List[List[str]]
    diversification_benefit: Dict[str, float]

class StrategyAnalyzer:
    """
    Strateji Performans Analiz Sistemi
    
    Trading stratejilerinin performansını detaylı olarak analiz eder,
    karşılaştırır ve optimize eder.
    """
    
    def __init__(self, lookback_days: int = 252):
        """
        Strategy Analyzer başlat
        
        Args:
            lookback_days: Analiz için geçmiş gün sayısı
        """
        self.logger = logging.getLogger(__name__)
        self.lookback_days = lookback_days
        
        # Strateji performans verileri
        self.strategy_data = defaultdict(dict)
        self.strategy_returns = defaultdict(list)
        self.strategy_trades = defaultdict(list)
        self.performance_history = defaultdict(list)
        
        # Korelasyon verileri
        self.correlation_cache = {}
        self.last_correlation_update = 0
        
        # Eşik değerler
        self.performance_thresholds = {
            'sharpe_ratio': 1.0,
            'max_drawdown': 0.20,
            'win_rate': 0.45,
            'profit_factor': 1.2,
            'volatility': 0.30
        }
        
        # Thread güvenliği
        self.lock = threading.Lock()
        
        self.logger.info("Strategy Analyzer başlatıldı")
    
    def add_strategy_data(self, strategy_name: str, data: Dict[str, Any]):
        """
        Strateji verisi ekle
        
        Args:
            strategy_name: Strateji adı
            data: Strateji verileri
        """
        with self.lock:
            self.strategy_data[strategy_name].update(data)
            
            # Getiri verisi varsa ekle
            if 'returns' in data:
                self.strategy_returns[strategy_name].extend(data['returns'])
            
            # İşlem verisi varsa ekle
            if 'trades' in data:
                self.strategy_trades[strategy_name].extend(data['trades'])
            
            self.logger.debug(f"Strateji verisi eklendi: {strategy_name}")
    
    def analyze_strategies(self, performance_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Tüm stratejileri analiz et
        
        Args:
            performance_data: Performans verileri
        
        Returns:
            Dict: Analiz sonuçları
        """
        try:
            results = {
                'individual_analysis': {},
                'comparison': None,
                'summary': {},
                'recommendations': [],
                'warnings': []
            }
            
            # Her strateji için ayrı ayrı analiz
            strategy_names = list(self.strategy_data.keys())
            
            for strategy_name in strategy_names:
                strategy_metrics = self._analyze_individual_strategy(strategy_name)
                results['individual_analysis'][strategy_name] = strategy_metrics
            
            # Karşılaştırmalı analiz
            if len(strategy_names) > 1:
                comparison = self._compare_strategies(strategy_names)
                results['comparison'] = comparison
            
            # Özet istatistikler
            results['summary'] = self._generate_summary(results['individual_analysis'])
            
            # Öneriler ve uyarılar
            results['recommendations'] = self._generate_recommendations(results)
            results['warnings'] = self._generate_warnings(results)
            
            return results
            
        except Exception as e:
            self.logger.error(f"Strateji analizi hatası: {e}")
            raise
    
    def _analyze_individual_strategy(self, strategy_name: str) -> StrategyMetrics:
        """
        Tek bir stratejiyi analiz et
        
        Args:
            strategy_name: Strateji adı
        
        Returns:
            StrategyMetrics: Strateji metrikleri
        """
        data = self.strategy_data.get(strategy_name, {})
        returns = np.array(self.strategy_returns.get(strategy_name, [0]))
        trades = self.strategy_trades.get(strategy_name, [])
        
        if len(returns) == 0:
            # Boş veri durumu
            return StrategyMetrics(
                strategy_name=strategy_name,
                total_return=0.0,
                annualized_return=0.0,
                volatility=0.0,
                sharpe_ratio=0.0,
                sortino_ratio=0.0,
                max_drawdown=0.0,
                calmar_ratio=0.0,
                win_rate=0.0,
                profit_factor=1.0,
                var_95=0.0,
                cvar_95=0.0,
                information_ratio=0.0,
                beta=0.0,
                alpha=0.0,
                turnover=0.0,
                unique_trades=0,
                avg_trade_duration=0.0,
                risk_adjusted_return=0.0,
                consistency_score=0.0
            )
        
        # Temel metrikler
        total_return = self._calculate_total_return(returns)
        annualized_return = self._calculate_annualized_return(returns)
        volatility = self._calculate_volatility(returns)
        sharpe_ratio = self._calculate_sharpe_ratio(returns)
        sortino_ratio = self._calculate_sortino_ratio(returns)
        max_drawdown = self._calculate_max_drawdown_from_returns(returns)
        calmar_ratio = self._calculate_calmar_ratio(total_return, max_drawdown)
        
        # İşlem metrikleri
        win_rate = self._calculate_win_rate(trades)
        profit_factor = self._calculate_profit_factor(trades)
        turnover = self._calculate_turnover(trades, data)
        unique_trades = len(trades)
        avg_trade_duration = self._calculate_avg_trade_duration(trades)
        
        # Risk metrikleri
        var_95 = self._calculate_var(returns, 0.95)
        cvar_95 = self._calculate_cvar(returns, 0.95)
        
        # Beta ve Alpha
        beta = self._calculate_beta(returns, data)
        alpha = self._calculate_alpha(returns, data, beta)
        
        # Information ratio
        information_ratio = self._calculate_information_ratio(returns, data)
        
        # Risk-ayarlı getiri
        risk_adjusted_return = self._calculate_risk_adjusted_return(total_return, volatility)
        
        # Tutarlılık skoru
        consistency_score = self._calculate_consistency_score(returns)
        
        return StrategyMetrics(
            strategy_name=strategy_name,
            total_return=total_return,
            annualized_return=annualized_return,
            volatility=volatility,
            sharpe_ratio=sharpe_ratio,
            sortino_ratio=sortino_ratio,
            max_drawdown=max_drawdown,
            calmar_ratio=calmar_ratio,
            win_rate=win_rate,
            profit_factor=profit_factor,
            var_95=var_95,
            cvar_95=cvar_95,
            information_ratio=information_ratio,
            beta=beta,
            alpha=alpha,
            turnover=turnover,
            unique_trades=unique_trades,
            avg_trade_duration=avg_trade_duration,
            risk_adjusted_return=risk_adjusted_return,
            consistency_score=consistency_score
        )
    
    def _compare_strategies(self, strategy_names: List[str]) -> StrategyComparison:
        """
        Stratejileri karşılaştır
        
        Args:
            strategy_names: Strateji adları
        
        Returns:
            StrategyComparison: Karşılaştırma sonucu
        """
        # Performans sıralaması
        rankings = []
        for name in strategy_names:
            metrics = self._analyze_individual_strategy(name)
            # Sharpe ratio'a göre sırala
            ranking_score = metrics.sharpe_ratio * 0.4 + \
                          metrics.calmar_ratio * 0.3 + \
                          metrics.consistency_score * 0.3
            rankings.append((name, ranking_score))
        
        rankings.sort(key=lambda x: x[1], reverse=True)
        
        # Korelasyon matrisi
        returns_data = {}
        for name in strategy_names:
            returns = np.array(self.strategy_returns.get(name, [0]))
            if len(returns) > 0:
                returns_data[name] = returns
        
        if len(returns_data) > 1:
            correlation_matrix = self._calculate_correlation_matrix(returns_data)
        else:
            correlation_matrix = np.array([[1.0]])
        
        # Yüksek korelasyonlu stratejileri tespit et
        correlation_threshold = 0.8
        similar_strategies = self._find_similar_strategies(correlation_matrix, correlation_threshold)
        
        # Çeşitlendirme faydası
        diversification_benefit = self._calculate_diversification_benefit(returns_data, correlation_matrix)
        
        return StrategyComparison(
            best_strategy=rankings[0][0],
            ranking=rankings,
            correlation_matrix=correlation_matrix,
            correlation_threshold=correlation_threshold,
            similar_strategies=similar_strategies,
            diversification_benefit=diversification_benefit
        )
    
    def _calculate_total_return(self, returns: np.ndarray) -> float:
        """Toplam getiri hesapla"""
        if len(returns) == 0:
            return 0.0
        return np.prod(1 + returns) - 1
    
    def _calculate_annualized_return(self, returns: np.ndarray) -> float:
        """Yıllık getiri hesapla"""
        if len(returns) == 0:
            return 0.0
        
        total_return = self._calculate_total_return(returns)
        # 252 işlem günü varsayımı
        periods = len(returns)
        if periods == 0:
            return 0.0
        
        return (1 + total_return) ** (252 / periods) - 1
    
    def _calculate_volatility(self, returns: np.ndarray) -> float:
        """Volatilite hesapla"""
        if len(returns) == 0:
            return 0.0
        return np.std(returns) * np.sqrt(252)
    
    def _calculate_sharpe_ratio(self, returns: np.ndarray, risk_free_rate: float = 0.02) -> float:
        """Sharpe oranı hesapla"""
        if len(returns) == 0 or np.std(returns) == 0:
            return 0.0
        
        excess_returns = returns - risk_free_rate / 252
        return np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252)
    
    def _calculate_sortino_ratio(self, returns: np.ndarray, risk_free_rate: float = 0.02) -> float:
        """Sortino oranı hesapla"""
        if len(returns) == 0:
            return 0.0
        
        excess_returns = returns - risk_free_rate / 252
        negative_returns = excess_returns[excess_returns < 0]
        
        if len(negative_returns) == 0:
            return float('inf')
        
        downside_deviation = np.std(negative_returns)
        
        if downside_deviation == 0:
            return float('inf')
        
        return np.mean(excess_returns) / downside_deviation * np.sqrt(252)
    
    def _calculate_max_drawdown_from_returns(self, returns: np.ndarray) -> float:
        """Getirilerden maksimum çekilme hesapla"""
        if len(returns) == 0:
            return 0.0
        
        # Kümülatif getiri hesapla
        cumulative_returns = np.cumprod(1 + returns)
        peak = np.maximum.accumulate(cumulative_returns)
        drawdown = (cumulative_returns - peak) / peak
        
        return abs(np.min(drawdown))
    
    def _calculate_calmar_ratio(self, total_return: float, max_drawdown: float) -> float:
        """Calmar oranı hesapla"""
        if max_drawdown == 0:
            return float('inf')
        return total_return / max_drawdown
    
    def _calculate_win_rate(self, trades: List[Dict[str, Any]]) -> float:
        """Kazanma oranı hesapla"""
        if len(trades) == 0:
            return 0.0
        
        winning_trades = [t for t in trades if t.get('pnl', 0) > 0]
        return len(winning_trades) / len(trades)
    
    def _calculate_profit_factor(self, trades: List[Dict[str, Any]]) -> float:
        """Kar faktörü hesapla"""
        if len(trades) == 0:
            return 1.0
        
        gross_profit = sum(t['pnl'] for t in trades if t.get('pnl', 0) > 0)
        gross_loss = abs(sum(t['pnl'] for t in trades if t.get('pnl', 0) < 0))
        
        if gross_loss == 0:
            return float('inf')
        
        return gross_profit / gross_loss
    
    def _calculate_turnover(self, trades: List[Dict[str, Any]], data: Dict[str, Any]) -> float:
        """Ciro hesapla"""
        if len(trades) == 0:
            return 0.0
        
        total_volume = sum(abs(t.get('quantity', 0)) for t in trades)
        portfolio_value = data.get('portfolio_value', 1)
        
        if portfolio_value == 0:
            return 0.0
        
        return total_volume / portfolio_value
    
    def _calculate_avg_trade_duration(self, trades: List[Dict[str, Any]]) -> float:
        """Ortalama işlem süresi hesapla"""
        durations = []
        
        for trade in trades:
            entry_time = trade.get('entry_time')
            exit_time = trade.get('exit_time')
            
            if entry_time and exit_time:
                duration = (exit_time - entry_time) / 3600  # Saat cinsinden
                durations.append(duration)
        
        return np.mean(durations) if durations else 0.0
    
    def _calculate_var(self, returns: np.ndarray, confidence: float = 0.95) -> float:
        """Value at Risk hesapla"""
        if len(returns) == 0:
            return 0.0
        
        return abs(np.percentile(returns, (1 - confidence) * 100))
    
    def _calculate_cvar(self, returns: np.ndarray, confidence: float = 0.95) -> float:
        """Conditional Value at Risk hesapla"""
        if len(returns) == 0:
            return 0.0
        
        var = self._calculate_var(returns, confidence)
        tail_returns = returns[returns <= -var]
        
        if len(tail_returns) == 0:
            return var
        
        return abs(np.mean(tail_returns))
    
    def _calculate_beta(self, returns: np.ndarray, data: Dict[str, Any]) -> float:
        """Beta hesapla"""
        # Placeholder - gerçek uygulamada piyasa getirisi ile karşılaştırma
        return 1.0
    
    def _calculate_alpha(self, returns: np.ndarray, data: Dict[str, Any], beta: float) -> float:
        """Alpha hesapla"""
        # Placeholder - CAPM modeli kullanılabilir
        market_return = data.get('market_return', 0.0)
        risk_free_rate = 0.02
        
        expected_return = risk_free_rate + beta * (market_return - risk_free_rate)
        actual_return = np.mean(returns) * 252
        
        return actual_return - expected_return
    
    def _calculate_information_ratio(self, returns: np.ndarray, data: Dict[str, Any]) -> float:
        """Information ratio hesapla"""
        # Placeholder - benchmark ile karşılaştırma
        if len(returns) == 0 or np.std(returns) == 0:
            return 0.0
        
        benchmark_return = data.get('benchmark_return', 0.0)
        excess_returns = returns - benchmark_return
        
        return np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252)
    
    def _calculate_risk_adjusted_return(self, total_return: float, volatility: float) -> float:
        """Risk-ayarlı getiri hesapla"""
        if volatility == 0:
            return total_return
        
        return total_return / volatility
    
    def _calculate_consistency_score(self, returns: np.ndarray) -> float:
        """Tutarlılık skoru hesapla"""
        if len(returns) == 0:
            return 0.0
        
        # Pozitif ve negatif getirilerin dağılımı
        positive_returns = returns[returns > 0]
        negative_returns = returns[returns < 0]
        
        positive_ratio = len(positive_returns) / len(returns)
        
        # Volatilite normalizasyonu
        volatility = np.std(returns)
        volatility_score = 1 / (1 + volatility) if volatility > 0 else 1
        
        # Kombinasyon
        consistency_score = positive_ratio * volatility_score
        
        return consistency_score
    
    def _calculate_correlation_matrix(self, returns_data: Dict[str, np.ndarray]) -> np.ndarray:
        """Korelasyon matrisi hesapla"""
        strategy_names = list(returns_data.keys())
        n_strategies = len(strategy_names)
        
        correlation_matrix = np.zeros((n_strategies, n_strategies))
        
        for i, name_i in enumerate(strategy_names):
            for j, name_j in enumerate(strategy_names):
                if i == j:
                    correlation_matrix[i, j] = 1.0
                else:
                    returns_i = returns_data[name_i]
                    returns_j = returns_data[name_j]
                    
                    # Minimum uzunluğa göre align et
                    min_length = min(len(returns_i), len(returns_j))
                    if min_length > 0:
                        correlation_matrix[i, j] = np.corrcoef(
                            returns_i[-min_length:], returns_j[-min_length:]
                        )[0, 1]
                    else:
                        correlation_matrix[i, j] = 0.0
        
        return correlation_matrix
    
    def _find_similar_strategies(self, correlation_matrix: np.ndarray, threshold: float) -> List[List[str]]:
        """Benzer stratejileri tespit et"""
        n = correlation_matrix.shape[0]
        similar_groups = []
        
        for i in range(n):
            similar_to_i = [i]
            
            for j in range(i + 1, n):
                if abs(correlation_matrix[i, j]) >= threshold:
                    similar_to_i.append(j)
            
            if len(similar_to_i) > 1:
                similar_groups.append(similar_to_i)
        
        return similar_groups
    
    def _calculate_diversification_benefit(self, returns_data: Dict[str, np.ndarray], 
                                         correlation_matrix: np.ndarray) -> Dict[str, float]:
        """Çeşitlendirme faydası hesapla"""
        strategy_names = list(returns_data.keys())
        benefits = {}
        
        for name in strategy_names:
            # Bu strateji ile diğerleri arasındaki ortalama korelasyon
            idx = strategy_names.index(name)
            correlations = [correlation_matrix[idx, j] for j in range(len(strategy_names)) 
                          if j != idx and abs(correlation_matrix[idx, j]) < 0.8]
            
            if correlations:
                avg_correlation = np.mean([abs(c) for c in correlations])
                # Düşük korelasyon = yüksek fayda
                benefits[name] = 1 - avg_correlation
            else:
                benefits[name] = 1.0
        
        return benefits
    
    def _generate_summary(self, individual_analysis: Dict[str, StrategyMetrics]) -> Dict[str, Any]:
        """Özet istatistikler oluştur"""
        if not individual_analysis:
            return {}
        
        metrics_list = list(individual_analysis.values())
        
        return {
            'total_strategies': len(metrics_list),
            'avg_sharpe_ratio': np.mean([m.sharpe_ratio for m in metrics_list]),
            'avg_max_drawdown': np.mean([m.max_drawdown for m in metrics_list]),
            'avg_win_rate': np.mean([m.win_rate for m in metrics_list]),
            'best_performer': max(metrics_list, key=lambda x: x.sharpe_ratio).strategy_name,
            'worst_performer': min(metrics_list, key=lambda x: x.sharpe_ratio).strategy_name,
            'total_unique_trades': sum(m.unique_trades for m in metrics_list),
            'avg_consistency_score': np.mean([m.consistency_score for m in metrics_list])
        }
    
    def _generate_recommendations(self, analysis_results: Dict[str, Any]) -> List[str]:
        """Öneriler oluştur"""
        recommendations = []
        
        # Düşük performanslı stratejiler
        individual_analysis = analysis_results.get('individual_analysis', {})
        
        for strategy_name, metrics in individual_analysis.items():
            if metrics.sharpe_ratio < self.performance_thresholds['sharpe_ratio']:
                recommendations.append(
                    f"{strategy_name}: Sharpe oranı düşük ({metrics.sharpe_ratio:.2f}). "
                    f"Parametre optimizasyonu gerekli."
                )
            
            if metrics.max_drawdown > self.performance_thresholds['max_drawdown']:
                recommendations.append(
                    f"{strategy_name}: Maksimum çekilme yüksek ({metrics.max_drawdown:.2f}). "
                    f"Risk yönetimi iyileştirilmeli."
                )
            
            if metrics.win_rate < self.performance_thresholds['win_rate']:
                recommendations.append(
                    f"{strategy_name}: Kazanma oranı düşük ({metrics.win_rate:.2f}). "
                    f"Sinyal kalitesi artırılmalı."
                )
        
        # Yüksek korelasyonlu stratejiler
        comparison = analysis_results.get('comparison')
        if comparison:
            for similar_group in comparison.similar_strategies:
                if len(similar_group) > 1:
                    strategy_names = list(individual_analysis.keys())
                    group_names = [strategy_names[i] for i in similar_group]
                    recommendations.append(
                        f"Yüksek korelasyonlu stratejiler: {', '.join(group_names)}. "
                        f"Çeşitlendirme azaltılmalı veya stratejiler birleştirilmeli."
                    )
        
        return recommendations
    
    def _generate_warnings(self, analysis_results: Dict[str, Any]) -> List[str]:
        """Uyarılar oluştur"""
        warnings = []
        
        individual_analysis = analysis_results.get('individual_analysis', {})
        
        # Kritik uyarılar
        for strategy_name, metrics in individual_analysis.items():
            if metrics.sharpe_ratio < 0:
                warnings.append(
                    f"{strategy_name}: Negatif Sharpe oranı ({metrics.sharpe_ratio:.2f}). "
                    f"Strateji derhal incelenmeli."
                )
            
            if metrics.max_drawdown > 0.5:
                warnings.append(
                    f"{strategy_name}: Çok yüksek maksimum çekilme (%{metrics.max_drawdown*100:.1f}). "
                    f"Acil risk yönetimi gerekli."
                )
            
            if metrics.profit_factor < 0.8:
                warnings.append(
                    f"{strategy_name}: Düşük kar faktörü ({metrics.profit_factor:.2f}). "
                    f"Strateji kayıp üretiyor."
                )
        
        return warnings