"""
System Integrator - Sistem Entegrasyon Modülü
============================================

Bu modül, Meta-Learning Engine'i diğer sistem bileşenleriyle entegre eder.
"""

import logging
import time
import json
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass
from datetime import datetime
import threading
from collections import defaultdict, deque

@dataclass
class IntegrationConfig:
    """Entegrasyon yapılandırması"""
    auto_sync_enabled: bool = True
    sync_interval_seconds: int = 60
    retry_attempts: int = 3
    timeout_seconds: int = 30
    batch_size: int = 100
    enable_real_time_updates: bool = True
    failover_enabled: bool = True

@dataclass
class SystemConnection:
    """Sistem bağlantısı"""
    system_name: str
    connection_type: str  # 'api', 'database', 'message_queue', 'file'
    endpoint: str
    status: str = 'disconnected'  # 'connected', 'disconnected', 'error'
    last_sync: float = 0.0
    error_count: int = 0
    total_operations: int = 0
    successful_operations: int = 0

class SystemIntegrator:
    """
    Sistem Entegrasyon Modülü
    
    Meta-Learning Engine'i diğer sistem bileşenleriyle entegre eder.
    """
    
    def __init__(self, config: Optional[IntegrationConfig] = None):
        """
        System Integrator başlat
        
        Args:
            config: Entegrasyon yapılandırması
        """
        self.logger = logging.getLogger(__name__)
        self.config = config or IntegrationConfig()
        
        # Sistem bağlantıları
        self.connections = {}
        self.subscribed_systems = set()
        
        # Veri senkronizasyonu
        self.sync_queue = deque(maxlen=1000)
        self.pending_updates = defaultdict(list)
        self.sync_history = deque(maxlen=1000)
        
        # Callback fonksiyonları
        self.event_callbacks = defaultdict(list)
        self.data_sync_callbacks = defaultdict(list)
        
        # Threading
        self.sync_thread = None
        self.is_running = False
        self.lock = threading.Lock()
        
        # Sistem konnektörleri
        self.connectors = {
            'api': self._api_connector,
            'database': self._database_connector,
            'message_queue': self._message_queue_connector,
            'file': self._file_connector
        }
        
        # Varsayılan sistem entegrasyonları
        self._initialize_default_integrations()
        
        self.logger.info("System Integrator başlatıldı")
    
    def _initialize_default_integrations(self):
        """Varsayılan sistem entegrasyonlarını başlat"""
        # Bu, gerçek sistemlerle entegrasyon için kullanılır
        # Örnek: risk_management, portfolio_optimization, etc.
        
        default_systems = [
            'risk_management_system',
            'portfolio_optimizer',
            'backtest_engine',
            'correlation_engine',
            'genetic_engine',
            'signal_scoring_system'
        ]
        
        for system_name in default_systems:
            connection = SystemConnection(
                system_name=system_name,
                connection_type='api',
                endpoint=f'http://localhost:8000/{system_name}'
            )
            self.connections[system_name] = connection
    
    def register_system(self, system_name: str, connection_type: str, endpoint: str):
        """
        Sistemi kaydet
        
        Args:
            system_name: Sistem adı
            connection_type: Bağlantı tipi
            endpoint: Uç nokta
        """
        with self.lock:
            connection = SystemConnection(
                system_name=system_name,
                connection_type=connection_type,
                endpoint=endpoint
            )
            
            self.connections[system_name] = connection
            self.logger.info(f"Sistem kaydedildi: {system_name}")
    
    def connect_system(self, system_name: str) -> bool:
        """
        Sisteme bağlan
        
        Args:
            system_name: Sistem adı
        
        Returns:
            bool: Bağlantı başarısı
        """
        try:
            if system_name not in self.connections:
                self.logger.error(f"Sistem bulunamadı: {system_name}")
                return False
            
            connection = self.connections[system_name]
            
            # Bağlantı testi
            if self._test_connection(connection):
                connection.status = 'connected'
                connection.last_sync = time.time()
                
                self.logger.info(f"Sisteme bağlanıldı: {system_name}")
                return True
            else:
                connection.status = 'error'
                self.logger.error(f"Sistem bağlantısı başarısız: {system_name}")
                return False
                
        except Exception as e:
            self.logger.error(f"Sistem bağlantı hatası: {e}")
            return False
    
    def disconnect_system(self, system_name: str):
        """Sistem bağlantısını kes"""
        if system_name in self.connections:
            self.connections[system_name].status = 'disconnected'
            self.logger.info(f"Sistem bağlantısı kesildi: {system_name}")
    
    def update_systems(self, data: Dict[str, Any]):
        """
        Sistemlere veri gönder
        
        Args:
            data: Gönderilecek veriler
        """
        try:
            if self.config.auto_sync_enabled:
                self._queue_system_update(data)
            else:
                self._send_immediate_update(data)
                
        except Exception as e:
            self.logger.error(f"Sistem güncelleme hatası: {e}")
    
    def _queue_system_update(self, data: Dict[str, Any]):
        """Sistem güncellemesini kuyruğa ekle"""
        update_item = {
            'timestamp': time.time(),
            'data': data,
            'systems': list(self.connections.keys()),
            'retry_count': 0
        }
        
        self.sync_queue.append(update_item)
        
        # Sync thread çalışmıyorsa başlat
        if not self.is_running:
            self._start_sync_thread()
    
    def _send_immediate_update(self, data: Dict[str, Any]):
        """Anında sistem güncellemesi gönder"""
        with self.lock:
            for system_name, connection in self.connections.items():
                if connection.status == 'connected':
                    self._send_to_system(system_name, data)
    
    def _send_to_system(self, system_name: str, data: Dict[str, Any]):
        """Sisteme veri gönder"""
        try:
            connection = self.connections[system_name]
            connection.total_operations += 1
            
            # Bağlantı tipine göre gönder
            if connection.connection_type in self.connectors:
                success = self.connectors[connection.connection_type](system_name, data)
                
                if success:
                    connection.successful_operations += 1
                    connection.last_sync = time.time()
                else:
                    connection.error_count += 1
                    self.logger.warning(f"Sistem güncellemesi başarısız: {system_name}")
            
        except Exception as e:
            self.logger.error(f"Sistem gönderim hatası ({system_name}): {e}")
            if system_name in self.connections:
                self.connections[system_name].error_count += 1
    
    def _api_connector(self, system_name: str, data: Dict[str, Any]) -> bool:
        """API bağlantısı"""
        import requests
        
        try:
            connection = self.connections[system_name]
            
            response = requests.post(
                f"{connection.endpoint}/update",
                json=data,
                timeout=self.config.timeout_seconds
            )
            
            return response.status_code == 200
            
        except Exception as e:
            self.logger.error(f"API bağlantı hatası ({system_name}): {e}")
            return False
    
    def _database_connector(self, system_name: str, data: Dict[str, Any]) -> bool:
        """Veritabanı bağlantısı"""
        # Placeholder - gerçek veritabanı implementasyonu
        try:
            # Örnek: MongoDB, PostgreSQL, vs.
            self.logger.debug(f"Veritabanı güncellemesi: {system_name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Veritabanı bağlantı hatası ({system_name}): {e}")
            return False
    
    def _message_queue_connector(self, system_name: str, data: Dict[str, Any]) -> bool:
        """Message queue bağlantısı"""
        # Placeholder - gerçek message queue implementasyonu
        try:
            # Örnek: Kafka, RabbitMQ, Redis, vs.
            self.logger.debug(f"Message queue güncellemesi: {system_name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Message queue hatası ({system_name}): {e}")
            return False
    
    def _file_connector(self, system_name: str, data: Dict[str, Any]) -> bool:
        """Dosya bağlantısı"""
        try:
            connection = self.connections[system_name]
            
            # JSON dosyasına yaz
            filepath = f"{connection.endpoint}/{system_name}_data.json"
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Dosya yazma hatası ({system_name}): {e}")
            return False
    
    def _test_connection(self, connection: SystemConnection) -> bool:
        """Bağlantıyı test et"""
        try:
            if connection.connection_type == 'api':
                import requests
                response = requests.get(
                    f"{connection.endpoint}/health",
                    timeout=5
                )
                return response.status_code == 200
            
            elif connection.connection_type == 'database':
                # Veritabanı bağlantı testi
                return True
                
            elif connection.connection_type == 'message_queue':
                # Message queue bağlantı testi
                return True
                
            elif connection.connection_type == 'file':
                # Dosya erişim testi
                import os
                return os.path.exists(connection.endpoint)
            
            return False
            
        except Exception as e:
            self.logger.error(f"Bağlantı testi hatası: {e}")
            return False
    
    def _start_sync_thread(self):
        """Senkronizasyon thread'ini başlat"""
        if not self.is_running:
            self.is_running = True
            self.sync_thread = threading.Thread(target=self._sync_worker, daemon=True)
            self.sync_thread.start()
            self.logger.info("Senkronizasyon thread'i başlatıldı")
    
    def _sync_worker(self):
        """Senkronizasyon çalışanı"""
        while self.is_running:
            try:
                if self.sync_queue:
                    self._process_sync_queue()
                
                time.sleep(self.config.sync_interval_seconds)
                
            except Exception as e:
                self.logger.error(f"Senkronizasyon worker hatası: {e}")
                time.sleep(5)  # Hata durumunda bekle
    
    def _process_sync_queue(self):
        """Senkronizasyon kuyruğunu işle"""
        items_to_process = min(self.config.batch_size, len(self.sync_queue))
        
        for _ in range(items_to_process):
            try:
                update_item = self.sync_queue.popleft()
                
                for system_name in update_item['systems']:
                    if system_name in self.connections:
                        connection = self.connections[system_name]
                        
                        if connection.status == 'connected':
                            self._send_to_system(system_name, update_item['data'])
                            
                            # Sync geçmişine ekle
                            self.sync_history.append({
                                'timestamp': update_item['timestamp'],
                                'system': system_name,
                                'success': True
                            })
                        else:
                            # Bağlantı problemi
                            update_item['retry_count'] += 1
                            if update_item['retry_count'] < self.config.retry_attempts:
                                self.sync_queue.append(update_item)
                
            except Exception as e:
                self.logger.error(f"Sync kuyruk işleme hatası: {e}")
    
    def subscribe_to_events(self, system_name: str, callback: Callable):
        """Sistem olaylarına abone ol"""
        self.event_callbacks[system_name].append(callback)
        self.subscribed_systems.add(system_name)
        
        self.logger.info(f"Sistem olaylarına abone olundu: {system_name}")
    
    def add_data_sync_callback(self, system_name: str, callback: Callable):
        """Veri senkronizasyon callback'i ekle"""
        self.data_sync_callbacks[system_name].append(callback)
        
        self.logger.info(f"Veri sync callback'i eklendi: {system_name}")
    
    def trigger_event(self, system_name: str, event_type: str, event_data: Dict[str, Any]):
        """Sistem olayını tetikle"""
        try:
            if system_name in self.event_callbacks:
                for callback in self.event_callbacks[system_name]:
                    callback(event_type, event_data)
            
            self.logger.debug(f"Olay tetiklendi: {system_name}/{event_type}")
            
        except Exception as e:
            self.logger.error(f"Olay tetikleme hatası: {e}")
    
    def get_system_status(self) -> Dict[str, Any]:
        """Sistem durumunu getir"""
        with self.lock:
            status = {}
            
            for system_name, connection in self.connections.items():
                status[system_name] = {
                    'connection_type': connection.connection_type,
                    'endpoint': connection.endpoint,
                    'status': connection.status,
                    'last_sync': connection.last_sync,
                    'error_count': connection.error_count,
                    'success_rate': connection.successful_operations / max(1, connection.total_operations)
                }
            
            return {
                'total_systems': len(self.connections),
                'connected_systems': len([c for c in self.connections.values() if c.status == 'connected']),
                'systems': status,
                'queue_size': len(self.sync_queue),
                'sync_thread_running': self.is_running
            }
    
    def get_integration_statistics(self) -> Dict[str, Any]:
        """Entegrasyon istatistiklerini getir"""
        with self.lock:
            if not self.sync_history:
                return {}
            
            recent_syncs = [s for s in self.sync_history if s['timestamp'] > time.time() - 3600]
            
            return {
                'total_syncs': len(self.sync_history),
                'recent_syncs_1h': len(recent_syncs),
                'success_rate_1h': len([s for s in recent_syncs if s['success']]) / max(1, len(recent_syncs)),
                'avg_sync_interval': self.config.sync_interval_seconds,
                'connected_systems_count': len([c for c in self.connections.values() if c.status == 'connected'])
            }
    
    def health_check(self) -> Dict[str, Any]:
        """Sistem sağlık kontrolü"""
        health_status = {
            'overall_health': 'healthy',
            'checks': {}
        }
        
        # Bağlantı kontrolü
        disconnected_systems = [name for name, conn in self.connections.items() 
                               if conn.status != 'connected']
        
        if disconnected_systems:
            health_status['checks']['connections'] = f"Bazı sistemler bağlantısız: {disconnected_systems}"
        
        # Sync kuyruk kontrolü
        if len(self.sync_queue) > self.config.batch_size:
            health_status['checks']['queue'] = f"Senkronizasyon kuyruğu dolu: {len(self.sync_queue)} item"
        
        # Thread kontrolü
        if not self.is_running or (self.sync_thread and not self.sync_thread.is_alive()):
            health_status['checks']['thread'] = "Senkronizasyon thread'i çalışmıyor"
        
        # Hata oranı kontrolü
        total_errors = sum(conn.error_count for conn in self.connections.values())
        total_operations = sum(conn.total_operations for conn in self.connections.values())
        error_rate = total_errors / max(1, total_operations)
        
        if error_rate > 0.1:  # %10'dan fazla hata
            health_status['checks']['error_rate'] = f"Yüksek hata oranı: %{error_rate*100:.1f}"
        
        # Genel sağlık durumu
        if health_status['checks']:
            health_status['overall_health'] = 'degraded'
        
        return health_status
    
    def shutdown(self):
        """Sistem entegrasyonunu kapat"""
        self.is_running = False
        
        if self.sync_thread:
            self.sync_thread.join(timeout=5)
        
        # Tüm bağlantıları kapat
        for connection in self.connections.values():
            connection.status = 'disconnected'
        
        self.logger.info("System Integrator kapatıldı")