"""
Meta-Learning Engine - Ana Koordinatör
=====================================

Bu modül, tüm Meta-Learning sisteminin ana koordinatörüdür.
"""

import logging
import threading
import time
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import pandas as pd

from ..monitoring.performance_monitor import PerformanceMonitor
from ..monitoring.alert_manager import AlertManager
from ..analysis.strategy_analyzer import StrategyAnalyzer
from ..analysis.regime_detector import RegimeDetector
from ..analysis.drift_detector import DriftDetector
from ..automation.strategy_controller import StrategyController
from ..automation.ab_testing import ABTestingEngine
from ..optimization.hyperparameter_optimizer import HyperparameterOptimizer
from ..optimization.correlation_analyzer import CorrelationAnalyzer
from ..metrics.risk_metrics import RiskAdjustedMetrics
from ..learning.realtime_learner import RealtimeLearner
from ..integration.system_integrator import SystemIntegrator

@dataclass
class MetaLearningConfig:
    """Meta-Learning Engine yapılandırma ayarları"""
    update_frequency: int = 60  # saniye
    performance_threshold: float = 0.05  # %5 performans eşiği
    regime_change_threshold: float = 0.1
    drift_detection_threshold: float = 0.05
    max_parallel_processes: int = 4
    enable_real_time_learning: bool = True
    enable_ab_testing: bool = True
    enable_hyperparameter_optimization: bool = True
    risk_aware: bool = True

class MetaLearningEngine:
    """
    Meta-Learning Engine Ana Koordinatör
    
    Bu sınıf, tüm Meta-Learning sistem bileşenlerini koordine eder ve:
    - Performans izleme ve uyarı sistemlerini yönetir
    - Strateji performans analizi yapar
    - Otomatik strateji aktivasyon/deaktivasyon yapar
    - Rejim değişikliği tespit eder
    - Model drift tespiti yapar
    - A/B testing otomasyonu sağlar
    - Hiperparametre optimizasyonu yapar
    - Çapraz strateji korelasyon analizi yapar
    - Risk-ayarlı performans metriklerini hesaplar
    - Otomatik geri bildirim döngüleri oluşturur
    - Gerçek zamanlı öğrenme algoritmaları çalıştırır
    """
    
    def __init__(self, config: Optional[MetaLearningConfig] = None):
        """
        Meta-Learning Engine'i başlat
        
        Args:
            config: Yapılandırma ayarları
        """
        self.config = config or MetaLearningConfig()
        self.logger = logging.getLogger(__name__)
        
        # Bileşen başlatma
        self.performance_monitor = PerformanceMonitor()
        self.alert_manager = AlertManager()
        self.strategy_analyzer = StrategyAnalyzer()
        self.regime_detector = RegimeDetector()
        self.drift_detector = DriftDetector()
        self.strategy_controller = StrategyController()
        self.ab_testing = ABTestingEngine()
        self.hyperparameter_optimizer = HyperparameterOptimizer()
        self.correlation_analyzer = CorrelationAnalyzer()
        self.risk_metrics = RiskAdjustedMetrics()
        self.realtime_learner = RealtimeLearner()
        self.system_integrator = SystemIntegrator()
        
        # Durum takibi
        self.is_running = False
        self.last_update = time.time()
        self.performance_history = []
        self.active_strategies = {}
        self.current_regime = "unknown"
        self.detected_drift = {}
        
        # Threading
        self.executor = ThreadPoolExecutor(max_workers=self.config.max_parallel_processes)
        self.update_thread = None
        
        self.logger.info("Meta-Learning Engine başlatıldı")
    
    def start(self):
        """Meta-Learning Engine'i başlat"""
        if self.is_running:
            self.logger.warning("Engine zaten çalışıyor")
            return
            
        self.is_running = True
        self.update_thread = threading.Thread(target=self._update_loop, daemon=True)
        self.update_thread.start()
        
        self.logger.info("Meta-Learning Engine başlatıldı")
    
    def stop(self):
        """Meta-Learning Engine'i durdur"""
        self.is_running = False
        if self.update_thread:
            self.update_thread.join(timeout=5)
        
        self.logger.info("Meta-Learning Engine durduruldu")
    
    def _update_loop(self):
        """Ana güncelleme döngüsü"""
        while self.is_running:
            try:
                self._execute_update_cycle()
                time.sleep(self.config.update_frequency)
            except Exception as e:
                self.logger.error(f"Güncelleme döngüsü hatası: {e}")
                self.alert_manager.send_alert(
                    level="error",
                    message=f"Meta-Learning Engine güncelleme hatası: {e}"
                )
    
    def _execute_update_cycle(self):
        """Tek bir güncelleme döngüsü çalıştır"""
        start_time = time.time()
        
        # 1. Performans izleme
        performance_data = self.performance_monitor.collect_metrics()
        
        # 2. Rejim tespiti
        current_regime = self.regime_detector.detect_regime(performance_data)
        if current_regime != self.current_regime:
            self.logger.info(f"Rejim değişikliği tespit edildi: {self.current_regime} -> {current_regime}")
            self.current_regime = current_regime
            self._handle_regime_change(current_regime)
        
        # 3. Model drift tespiti
        drift_data = self.drift_detector.detect_drift(performance_data)
        if drift_data:
            self.logger.warning(f"Model drift tespit edildi: {drift_data}")
            self._handle_model_drift(drift_data)
        
        # 4. Strateji performans analizi
        strategy_analysis = self.strategy_analyzer.analyze_strategies(performance_data)
        
        # 5. Çapraz korelasyon analizi
        correlation_data = self.correlation_analyzer.analyze_correlations(strategy_analysis)
        
        # 6. Risk-ayarlı metrikler
        risk_metrics = self.risk_metrics.calculate_metrics(performance_data)
        
        # 7. A/B Testing kontrolü
        if self.config.enable_ab_testing:
            self.ab_testing.evaluate_tests(performance_data)
        
        # 8. Hiperparametre optimizasyonu
        if self.config.enable_hyperparameter_optimization:
            optimization_suggestions = self.hyperparameter_optimizer.optimize(strategy_analysis)
            if optimization_suggestions:
                self._apply_optimization(optimization_suggestions)
        
        # 9. Strateji aktivasyon/deaktivasyon
        strategy_actions = self.strategy_controller.evaluate_strategies(
            strategy_analysis, correlation_data, risk_metrics
        )
        self._execute_strategy_actions(strategy_actions)
        
        # 10. Gerçek zamanlı öğrenme
        if self.config.enable_real_time_learning:
            self.realtime_learner.update_models(performance_data, strategy_analysis)
        
        # 11. Sistem entegrasyonu
        self.system_integrator.update_systems({
            'performance': performance_data,
            'regime': current_regime,
            'strategies': strategy_analysis,
            'risk_metrics': risk_metrics,
            'correlations': correlation_data
        })
        
        # Geçmişe ekle
        self.performance_history.append({
            'timestamp': time.time(),
            'performance': performance_data,
            'regime': current_regime,
            'strategies': strategy_analysis,
            'risk_metrics': risk_metrics
        })
        
        # Geçmişi temizle (son 1000 kayıt)
        if len(self.performance_history) > 1000:
            self.performance_history = self.performance_history[-1000:]
        
        self.last_update = time.time()
        execution_time = time.time() - start_time
        
        self.logger.debug(f"Güncelleme döngüsü tamamlandı ({execution_time:.2f}s)")
    
    def _handle_regime_change(self, new_regime: str):
        """Rejim değişikliğini işle"""
        self.alert_manager.send_alert(
            level="info",
            message=f"Market rejimi değişti: {self.current_regime} -> {new_regime}"
        )
        
        # Rejime göre strateji önerilerini al
        regime_recommendations = self.strategy_controller.get_regime_recommendations(new_regime)
        
        # Otomatik strateji ayarlamaları
        self.strategy_controller.adjust_strategies_for_regime(new_regime, regime_recommendations)
    
    def _handle_model_drift(self, drift_data: Dict[str, Any]):
        """Model drift'ini işle"""
        self.alert_manager.send_alert(
            level="warning",
            message=f"Model drift tespit edildi: {drift_data}"
        )
        
        # Drift tespit edilen modeller için yeniden eğitim planla
        for model_name, drift_info in drift_data.items():
            self.hyperparameter_optimizer.schedule_retraining(model_name, drift_info)
        
        # Stratejileri geçici olarak devre dışı bırak (kritik drift için)
        critical_drift_models = [name for name, info in drift_data.items() 
                               if info.get('severity', 'low') == 'high']
        
        if critical_drift_models:
            self.strategy_controller.deactivate_models(critical_drift_models)
    
    def _apply_optimization(self, suggestions: List[Dict[str, Any]]):
        """Optimizasyon önerilerini uygula"""
        for suggestion in suggestions:
            try:
                self.hyperparameter_optimizer.apply_optimization(suggestion)
                self.logger.info(f"Optimizasyon uygulandı: {suggestion}")
            except Exception as e:
                self.logger.error(f"Optimizasyon uygulanamadı: {e}")
    
    def _execute_strategy_actions(self, actions: Dict[str, Any]):
        """Strateji eylemlerini çalıştır"""
        for strategy_name, action in actions.items():
            try:
                if action['type'] == 'activate':
                    self.strategy_controller.activate_strategy(strategy_name, action.get('params'))
                elif action['type'] == 'deactivate':
                    self.strategy_controller.deactivate_strategy(strategy_name)
                elif action['type'] == 'adjust_parameters':
                    self.strategy_controller.adjust_parameters(strategy_name, action.get('parameters'))
                
                self.active_strategies[strategy_name] = action
            except Exception as e:
                self.logger.error(f"Strateji eylemi uygulanamadı ({strategy_name}): {e}")
    
    def get_current_status(self) -> Dict[str, Any]:
        """Mevcut sistem durumunu döndür"""
        return {
            'is_running': self.is_running,
            'last_update': self.last_update,
            'current_regime': self.current_regime,
            'active_strategies': self.active_strategies,
            'detected_drift': self.detected_drift,
            'performance_history_count': len(self.performance_history),
            'recent_performance': self.performance_history[-5:] if self.performance_history else []
        }
    
    def get_performance_summary(self, periods: int = 30) -> Dict[str, Any]:
        """Belirtilen dönem için performans özetini döndür"""
        if not self.performance_history:
            return {}
        
        recent_data = self.performance_history[-periods:]
        
        # Metrikleri hesapla
        performance_values = [p['performance'].get('total_return', 0) for p in recent_data]
        regime_changes = len(set(p['regime'] for p in recent_data))
        drift_incidents = sum(1 for p in recent_data if p.get('drift_detected'))
        
        return {
            'periods_analyzed': len(recent_data),
            'average_performance': np.mean(performance_values),
            'performance_volatility': np.std(performance_values),
            'regime_changes': regime_changes,
            'drift_incidents': drift_incidents,
            'active_strategy_count': len(self.active_strategies),
            'risk_score': self.risk_metrics.calculate_overall_risk_score(recent_data)
        }
    
    def export_analysis(self, filepath: str):
        """Analiz sonuçlarını dosyaya aktar"""
        try:
            analysis_data = {
                'config': self.config.__dict__,
                'status': self.get_current_status(),
                'performance_history': self.performance_history,
                'active_strategies': self.active_strategies,
                'summary': self.get_performance_summary()
            }
            
            # JSON formatında kaydet
            import json
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(analysis_data, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"Analiz sonuçları {filepath} dosyasına kaydedildi")
        except Exception as e:
            self.logger.error(f"Analiz sonuçları kaydedilemedi: {e}")
            raise