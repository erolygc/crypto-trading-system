"""
Bitwisers 2.0 Meta-Learning Engine (Denetmen YZ)
===============================================

Bu modül, Bitwisers 2.0 trading sisteminin kendi performansını izleyen ve 
iyileştiren 'meta-beyin' bileşenidir.

Ana Bileşenler:
- Performance monitoring ve alerting
- Strategy performance analysis
- Automatic strategy activation/deactivation
- Regime change detection
- Model drift detection
- A/B testing automation
- Hyperparameter optimization
- Cross-strategy correlation analysis
- Risk-adjusted performance metrics
- Automated feedback loops
- Real-time learning algorithms
- Integration with tüm faz sistemleri

Yazar: Bitwisers 2.0 Development Team
Tarih: 2025-10-30
"""

from .core.meta_learning_engine import MetaLearningEngine, MetaLearningConfig
from .monitoring.performance_monitor import PerformanceMonitor, PerformanceMetrics
from .monitoring.alert_manager import AlertManager, Alert
from .analysis.strategy_analyzer import StrategyAnalyzer, StrategyMetrics, StrategyComparison
from .analysis.regime_detector import RegimeDetector, MarketRegime, RegimeTransition
from .analysis.drift_detector import DriftDetector, DriftEvent, DriftMetrics
from .automation.strategy_controller import StrategyController, StrategyAction, StrategyControlConfig
from .automation.ab_testing import ABTestingEngine, ABTest, ABTestResult
from .optimization.hyperparameter_optimizer import HyperparameterOptimizer, OptimizationJob, OptimizationResult
from .optimization.correlation_analyzer import CorrelationAnalyzer, CorrelationResult
from .metrics.risk_metrics import RiskAdjustedMetrics, RiskAdjustedMetricsCalculator
from .learning.realtime_learner import RealtimeLearner, LearningModel, LearningFeedback
from .integration.system_integrator import SystemIntegrator, IntegrationConfig, SystemConnection
from .config.config_manager import ConfigManager
from .utils.helpers import *

__version__ = "2.0.0"
__author__ = "Bitwisers 2.0 Development Team"

__all__ = [
    # Ana sınıflar
    'MetaLearningEngine',
    'MetaLearningConfig',
    
    # Monitoring
    'PerformanceMonitor',
    'PerformanceMetrics',
    'AlertManager',
    'Alert',
    
    # Analysis
    'StrategyAnalyzer',
    'StrategyMetrics',
    'StrategyComparison',
    'RegimeDetector',
    'MarketRegime',
    'RegimeTransition',
    'DriftDetector',
    'DriftEvent',
    'DriftMetrics',
    
    # Automation
    'StrategyController',
    'StrategyAction',
    'StrategyControlConfig',
    'ABTestingEngine',
    'ABTest',
    'ABTestResult',
    
    # Optimization
    'HyperparameterOptimizer',
    'OptimizationJob',
    'OptimizationResult',
    'CorrelationAnalyzer',
    'CorrelationResult',
    
    # Metrics
    'RiskAdjustedMetrics',
    'RiskAdjustedMetricsCalculator',
    
    # Learning
    'RealtimeLearner',
    'LearningModel',
    'LearningFeedback',
    
    # Integration
    'SystemIntegrator',
    'IntegrationConfig',
    'SystemConnection',
    
    # Config
    'ConfigManager',
    
    # Utils
    'setup_logging',
    'timer_decorator',
    'retry_on_failure',
    'PerformanceTimer',
    'DataValidator',
    'DataSanitizer',
    'ThreadSafeCounter',
    'CacheManager',
    'JSONEncoder',
    'MetricsCalculator',
    'generate_id',
    'safe_divide',
    'normalize_data',
    'moving_average',
    'exponential_smoothing',
    'ProgressTracker',
    'save_pickle',
    'load_pickle'
]