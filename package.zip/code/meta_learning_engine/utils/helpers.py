"""
Utils Modülü - Yardımcı Fonksiyonlar
===================================

Meta-Learning Engine için yardımcı fonksiyonlar ve araçlar.
"""

import logging
import time
import json
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Union, Tuple
from datetime import datetime, timedelta
from functools import wraps
import threading
from collections import defaultdict, deque
import hashlib
import pickle

def setup_logging(level: str = "INFO", log_file: str = "logs/meta_learning_engine.log"):
    """Logging sistemini ayarla"""
    # Log dizinini oluştur
    import os
    os.makedirs(os.path.dirname(log_file), exist_ok=True)
    
    # Logging formatı
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # File handler
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setFormatter(formatter)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    
    # Root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, level.upper()))
    root_logger.addHandler(file_handler)
    root_logger.addHandler(console_handler)
    
    return root_logger

def timer_decorator(func):
    """Fonksiyon süresini ölçen decorator"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        
        logger = logging.getLogger(__name__)
        logger.debug(f"{func.__name__} tamamlandı: {end_time - start_time:.2f} saniye")
        
        return result
    return wrapper

def retry_on_failure(max_attempts: int = 3, delay: float = 1.0):
    """Hata durumunda tekrar deneme decorator"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(max_attempts):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_attempts - 1:
                        time.sleep(delay * (attempt + 1))
                    else:
                        logger = logging.getLogger(__name__)
                        logger.error(f"Fonksiyon başarısız oldu ({max_attempts} deneme): {func.__name__}")
            
            raise last_exception
        return wrapper
    return decorator

class PerformanceTimer:
    """Performans zamanlayıcısı"""
    
    def __init__(self):
        self.timers = {}
        self.logger = logging.getLogger(__name__)
    
    def start_timer(self, timer_name: str):
        """Zamanlayıcıyı başlat"""
        self.timers[timer_name] = time.time()
    
    def end_timer(self, timer_name: str) -> float:
        """Zamanlayıcıyı bitir ve süreyi döndür"""
        if timer_name not in self.timers:
            self.logger.warning(f"Zamanlayıcı bulunamadı: {timer_name}")
            return 0.0
        
        elapsed_time = time.time() - self.timers[timer_name]
        del self.timers[timer_name]
        
        self.logger.debug(f"Timer '{timer_name}': {elapsed_time:.2f} saniye")
        return elapsed_time

class DataValidator:
    """Veri doğrulama araçları"""
    
    @staticmethod
    def validate_performance_data(data: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """Performans verilerini doğrula"""
        errors = []
        
        # Gerekli alanlar
        required_fields = ['returns', 'total_return']
        
        for field in required_fields:
            if field not in data:
                errors.append(f"Eksik alan: {field}")
        
        # Veri tipi kontrolleri
        if 'returns' in data and not isinstance(data['returns'], list):
            errors.append("Returns alanı liste olmalı")
        
        if 'total_return' in data and not isinstance(data['total_return'], (int, float)):
            errors.append("Total return sayısal olmalı")
        
        # Değer aralığı kontrolleri
        if 'total_return' in data and abs(data['total_return']) > 10:
            errors.append("Total return değeri çok büyük: makul aralık -10 ile 10")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def validate_strategy_parameters(params: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """Strateji parametrelerini doğrula"""
        errors = []
        
        # Pozisyon boyutu kontrolü
        if 'max_position_size' in params:
            if not (0 < params['max_position_size'] <= 1):
                errors.append("Max position size 0-1 arasında olmalı")
        
        # Stop loss kontrolü
        if 'stop_loss' in params:
            if not (0 < params['stop_loss'] <= 0.5):
                errors.append("Stop loss 0-0.5 arasında olmalı")
        
        # Lookback period kontrolü
        if 'lookback_period' in params:
            if not (1 <= params['lookback_period'] <= 1000):
                errors.append("Lookback period 1-1000 arasında olmalı")
        
        return len(errors) == 0, errors

class DataSanitizer:
    """Veri temizleme araçları"""
    
    @staticmethod
    def clean_returns_data(returns: List[float], max_abs_value: float = 1.0) -> List[float]:
        """Getiri verilerini temizle"""
        cleaned_returns = []
        
        for ret in returns:
            if isinstance(ret, (int, float)) and not np.isnan(ret):
                # Aşırı değerleri sınırla
                cleaned_ret = max(-max_abs_value, min(max_abs_value, ret))
                cleaned_returns.append(cleaned_ret)
        
        return cleaned_returns
    
    @staticmethod
    def remove_outliers(data: np.ndarray, method: str = 'iqr', factor: float = 1.5) -> np.ndarray:
        """Ayırık değerleri kaldır"""
        if method == 'iqr':
            Q1 = np.percentile(data, 25)
            Q3 = np.percentile(data, 75)
            IQR = Q3 - Q1
            lower_bound = Q1 - factor * IQR
            upper_bound = Q3 + factor * IQR
            
            return data[(data >= lower_bound) & (data <= upper_bound)]
        
        elif method == 'std':
            mean = np.mean(data)
            std = np.std(data)
            return data[np.abs(data - mean) <= factor * std]
        
        else:
            return data

class ThreadSafeCounter:
    """Thread güvenli sayaç"""
    
    def __init__(self, initial_value: int = 0):
        self._value = initial_value
        self._lock = threading.Lock()
    
    def increment(self, amount: int = 1):
        """Sayaç değerini artır"""
        with self._lock:
            self._value += amount
            return self._value
    
    def decrement(self, amount: int = 1):
        """Sayaç değerini azalt"""
        with self._lock:
            self._value -= amount
            return self._value
    
    @property
    def value(self) -> int:
        """Sayaç değerini al"""
        with self._lock:
            return self._value
    
    def reset(self):
        """Sayaç değerini sıfırla"""
        with self._lock:
            self._value = 0

class CacheManager:
    """Basit cache yöneticisi"""
    
    def __init__(self, max_size: int = 1000, ttl: int = 3600):
        self.max_size = max_size
        self.ttl = ttl  # Time to live in seconds
        self.cache = {}
        self.timestamps = {}
        self.access_times = {}
        self.lock = threading.Lock()
    
    def get(self, key: str) -> Optional[Any]:
        """Cache'den veri al"""
        with self.lock:
            if key in self.cache:
                # TTL kontrolü
                if time.time() - self.timestamps[key] > self.ttl:
                    self._remove_key(key)
                    return None
                
                self.access_times[key] = time.time()
                return self.cache[key]
            
            return None
    
    def set(self, key: str, value: Any):
        """Cache'e veri kaydet"""
        with self.lock:
            # Boyut sınırı kontrolü
            if len(self.cache) >= self.max_size:
                self._evict_lru()
            
            self.cache[key] = value
            self.timestamps[key] = time.time()
            self.access_times[key] = time.time()
    
    def _remove_key(self, key: str):
        """Anahtarı kaldır"""
        if key in self.cache:
            del self.cache[key]
        if key in self.timestamps:
            del self.timestamps[key]
        if key in self.access_times:
            del self.access_times[key]
    
    def _evict_lru(self):
        """En az kullanılan öğeyi çıkar"""
        if not self.access_times:
            return
        
        lru_key = min(self.access_times, key=self.access_times.get)
        self._remove_key(lru_key)
    
    def clear(self):
        """Cache'i temizle"""
        with self.lock:
            self.cache.clear()
            self.timestamps.clear()
            self.access_times.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """Cache istatistiklerini al"""
        with self.lock:
            return {
                'size': len(self.cache),
                'max_size': self.max_size,
                'hit_ratio': getattr(self, '_hit_count', 0) / max(1, getattr(self, '_access_count', 1))
            }

class JSONEncoder(json.JSONEncoder):
    """Özel JSON encoder"""
    
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, datetime):
            return obj.isoformat()
        elif hasattr(obj, '__dict__'):
            return obj.__dict__
        
        return super().default(obj)

class MetricsCalculator:
    """Performans metrikleri hesaplayıcısı"""
    
    @staticmethod
    def calculate_sharpe_ratio(returns: np.ndarray, risk_free_rate: float = 0.02) -> float:
        """Sharpe oranı hesapla"""
        if len(returns) == 0 or np.std(returns) == 0:
            return 0.0
        
        excess_returns = returns - risk_free_rate / 252
        return np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252)
    
    @staticmethod
    def calculate_max_drawdown(returns: np.ndarray) -> float:
        """Maksimum çekilme hesapla"""
        if len(returns) == 0:
            return 0.0
        
        cumulative = np.cumprod(1 + returns)
        peak = np.maximum.accumulate(cumulative)
        drawdown = (cumulative - peak) / peak
        return abs(np.min(drawdown))
    
    @staticmethod
    def calculate_calmar_ratio(returns: np.ndarray) -> float:
        """Calmar oranı hesapla"""
        if len(returns) == 0:
            return 0.0
        
        total_return = np.prod(1 + returns) - 1
        max_dd = MetricsCalculator.calculate_max_drawdown(returns)
        
        return total_return / max_dd if max_dd > 0 else 0.0
    
    @staticmethod
    def calculate_win_rate(returns: np.ndarray) -> float:
        """Kazanma oranı hesapla"""
        if len(returns) == 0:
            return 0.0
        
        positive_returns = returns[returns > 0]
        return len(positive_returns) / len(returns)

def generate_id(prefix: str = "", length: int = 8) -> str:
    """Benzersiz ID oluştur"""
    timestamp = str(time.time())
    random_part = str(np.random.randint(1000, 9999))
    hash_input = f"{timestamp}{random_part}".encode()
    hash_hex = hashlib.md5(hash_input).hexdigest()[:length]
    
    return f"{prefix}{hash_hex}" if prefix else hash_hex

def safe_divide(numerator: float, denominator: float, default: float = 0.0) -> float:
    """Güvenli bölme işlemi"""
    if denominator == 0 or np.isnan(denominator) or np.isinf(denominator):
        return default
    
    result = numerator / denominator
    
    # NaN veya sonsuz değerleri kontrol et
    if np.isnan(result) or np.isinf(result):
        return default
    
    return result

def normalize_data(data: np.ndarray, method: str = 'minmax') -> np.ndarray:
    """Veriyi normalize et"""
    if len(data) == 0:
        return data
    
    if method == 'minmax':
        min_val = np.min(data)
        max_val = np.max(data)
        
        if max_val == min_val:
            return np.zeros_like(data)
        
        return (data - min_val) / (max_val - min_val)
    
    elif method == 'zscore':
        mean = np.mean(data)
        std = np.std(data)
        
        if std == 0:
            return np.zeros_like(data)
        
        return (data - mean) / std
    
    else:
        return data

def moving_average(data: np.ndarray, window: int) -> np.ndarray:
    """Hareketli ortalama hesapla"""
    if len(data) < window:
        return data
    
    return np.convolve(data, np.ones(window)/window, mode='valid')

def exponential_smoothing(data: np.ndarray, alpha: float = 0.3) -> np.ndarray:
    """Üstel düzleştirme"""
    if len(data) == 0:
        return data
    
    result = np.zeros_like(data)
    result[0] = data[0]
    
    for i in range(1, len(data)):
        result[i] = alpha * data[i] + (1 - alpha) * result[i-1]
    
    return result

class ProgressTracker:
    """İlerleme takipçisi"""
    
    def __init__(self, total_steps: int, description: str = ""):
        self.total_steps = total_steps
        self.current_step = 0
        self.start_time = time.time()
        self.description = description
    
    def update(self, steps: int = 1):
        """İlerlemeyi güncelle"""
        self.current_step = min(self.current_step + steps, self.total_steps)
    
    def get_progress(self) -> Dict[str, Any]:
        """İlerleme bilgilerini al"""
        elapsed_time = time.time() - self.start_time
        
        if self.current_step == 0:
            eta = 0
        else:
            avg_time_per_step = elapsed_time / self.current_step
            eta = avg_time_per_step * (self.total_steps - self.current_step)
        
        progress_percent = (self.current_step / self.total_steps) * 100
        
        return {
            'current_step': self.current_step,
            'total_steps': self.total_steps,
            'progress_percent': progress_percent,
            'elapsed_time': elapsed_time,
            'eta': eta,
            'description': self.description
        }
    
    def __str__(self) -> str:
        progress = self.get_progress()
        return f"{progress['description']}: {progress['current_step']}/{progress['total_steps']} ({progress['progress_percent']:.1f}%)"

def save_pickle(data: Any, filepath: str):
    """Veriyi pickle dosyasına kaydet"""
    import os
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    
    with open(filepath, 'wb') as f:
        pickle.dump(data, f)

def load_pickle(filepath: str) -> Any:
    """Pickle dosyasından veri yükle"""
    with open(filepath, 'rb') as f:
        return pickle.load(f)