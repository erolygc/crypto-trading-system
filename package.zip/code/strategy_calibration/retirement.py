"""
Strategy Retirement Modülü
=========================
Zayıf performans gösteren stratejilerin otomatik emekliliği.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging
from abc import ABC, abstractmethod
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

from .core import StrategyConfig, StrategyMetrics

@dataclass
class RetirementCriteria:
    """Emeklilik kriterleri"""
    min_sharpe_ratio: float = 0.5
    max_drawdown_threshold: float = -0.3
    min_trades: int = 20
    min_win_rate: float = 0.3
    performance_stagnation_days: int = 30
    consecutive_loss_threshold: int = 5
    risk_adjusted_return_threshold: float = 0.1
    confidence_level: float = 0.05

@dataclass
class RetirementDecision:
    """Emeklilik kararı"""
    strategy_id: str
    decision: str  # "retire", "monitor", "continue", "promote"
    confidence: float
    reasons: List[str]
    metrics_at_decision: Dict[str, Any]
    recommendation: str
    timestamp: datetime = field(default_factory=datetime.now)

@dataclass
class RetirementAnalysis:
    """Emeklilik analizi sonucu"""
    strategy_id: str
    current_metrics: StrategyMetrics
    historical_performance: List[StrategyMetrics]
    trend_analysis: Dict[str, Any]
    risk_assessment: Dict[str, Any]
    decision: RetirementDecision
    retirement_date: Optional[datetime] = None
    archived_data: Optional[Dict[str, Any]] = None

class RetirementAnalyzer:
    """Emeklilik analiz motoru"""
    
    def __init__(self, criteria: RetirementCriteria = None):
        self.criteria = criteria or RetirementCriteria()
        self.logger = logging.getLogger(__name__)
    
    def analyze_strategy(
        self,
        strategy_config: StrategyConfig,
        current_metrics: StrategyMetrics,
        historical_metrics: List[StrategyMetrics],
        benchmark_metrics: Optional[StrategyMetrics] = None
    ) -> RetirementAnalysis:
        """Strateji emeklilik analizi"""
        
        try:
            self.logger.info(f"Emeklilik analizi başlatılıyor: {strategy_config.strategy_id}")
            
            # 1. Trend analizi
            trend_analysis = self._analyze_performance_trend(historical_metrics)
            
            # 2. Risk değerlendirmesi
            risk_assessment = self._assess_risk_level(current_metrics, historical_metrics)
            
            # 3. Karar ver
            decision = self._make_retirement_decision(
                strategy_config,
                current_metrics,
                trend_analysis,
                risk_assessment,
                benchmark_metrics
            )
            
            # 4. Emeklilik tarihi belirle
            retirement_date = None
            if decision.decision == "retire":
                retirement_date = datetime.now()
            
            # 5. Arşiv verileri hazırla
            archived_data = self._prepare_archive_data(
                strategy_config, 
                current_metrics, 
                historical_metrics, 
                trend_analysis, 
                risk_assessment
            )
            
            return RetirementAnalysis(
                strategy_id=strategy_config.strategy_id,
                current_metrics=current_metrics,
                historical_performance=historical_metrics,
                trend_analysis=trend_analysis,
                risk_assessment=risk_assessment,
                decision=decision,
                retirement_date=retirement_date,
                archived_data=archived_data
            )
            
        except Exception as e:
            self.logger.error(f"Emeklilik analizi hatası: {e}")
            raise
    
    def _analyze_performance_trend(self, historical_metrics: List[StrategyMetrics]) -> Dict[str, Any]:
        """Performans trendi analizi"""
        
        if len(historical_metrics) < 2:
            return {
                'trend': 'insufficient_data',
                'slope': 0,
                'r_squared': 0,
                'significance': 0,
                'improvement_rate': 0
            }
        
        # Zaman serisi oluştur
        timestamps = [metrics.timestamp for metrics in historical_metrics]
        returns = [metrics.total_return for metrics in historical_metrics]
        sharpe_ratios = [metrics.sharpe_ratio for metrics in historical_metrics]
        
        # İndeks oluştur (günler)
        days_from_start = [(ts - timestamps[0]).days for ts in timestamps]
        
        # Linear trend analizi (returns)
        if len(set(days_from_start)) > 1:
            slope_return, intercept_return, r_value_return, p_value_return, std_err_return = stats.linregress(days_from_start, returns)
            r_squared_return = r_value_return ** 2
            
            # Sharpe ratio trendi
            slope_sharpe, _, r_value_sharpe, p_value_sharpe, _ = stats.linregress(days_from_start, sharpe_ratios)
            r_squared_sharpe = r_value_sharpe ** 2
        else:
            slope_return = slope_sharpe = 0
            r_squared_return = r_squared_sharpe = 0
            p_value_return = p_value_sharpe = 1
        
        # Trend belirleme
        if r_squared_return > 0.5 and p_value_return < self.criteria.confidence_level:
            if slope_return > 0:
                trend = "improving"
            else:
                trend = "declining"
        else:
            trend = "stable"
        
        # İyileşme hızı (günlük)
        period_days = days_from_start[-1] - days_from_start[0] if days_from_start else 1
        improvement_rate = slope_return * period_days if period_days > 0 else 0
        
        return {
            'trend': trend,
            'return_slope': slope_return,
            'sharpe_slope': slope_sharpe,
            'return_r_squared': r_squared_return,
            'sharpe_r_squared': r_squared_sharpe,
            'return_p_value': p_value_return,
            'sharpe_p_value': p_value_sharpe,
            'improvement_rate': improvement_rate,
            'period_days': period_days,
            'data_points': len(historical_metrics)
        }
    
    def _assess_risk_level(
        self, 
        current_metrics: StrategyMetrics, 
        historical_metrics: List[StrategyMetrics]
    ) -> Dict[str, Any]:
        """Risk seviyesi değerlendirmesi"""
        
        # Mevcut risk metrikleri
        current_risk_score = self._calculate_risk_score(current_metrics)
        
        # Tarihsel risk stabilitesi
        if len(historical_metrics) > 1:
            risk_scores = [self._calculate_risk_score(metrics) for metrics in historical_metrics]
            risk_volatility = np.std(risk_scores)
            risk_trend = "increasing" if risk_scores[-1] > np.mean(risk_scores[:-1]) else "decreasing"
        else:
            risk_volatility = 0
            risk_trend = "stable"
        
        # Konsantrasyon riski (drawdown sürekliliği)
        consecutive_losses = self._count_consecutive_losses(historical_metrics)
        
        # Risk seviyesi sınıflandırması
        if current_risk_score > 0.8:
            risk_level = "high"
        elif current_risk_score > 0.5:
            risk_level = "medium"
        else:
            risk_level = "low"
        
        return {
            'current_risk_score': current_risk_score,
            'risk_level': risk_level,
            'risk_volatility': risk_volatility,
            'risk_trend': risk_trend,
            'consecutive_losses': consecutive_losses,
            'risk_assessment': 'acceptable' if current_risk_score < 0.7 else 'concerning'
        }
    
    def _calculate_risk_score(self, metrics: StrategyMetrics) -> float:
        """Risk skoru hesaplama (0-1, 1 = yüksek risk)"""
        
        # Normalize edilmiş risk bileşenleri
        drawdown_risk = min(abs(metrics.max_drawdown), 1.0)  # Max 100% drawdown
        volatility_risk = min(abs(metrics.var_95), 1.0)      # VaR riski
        tail_risk = min(abs(metrics.expected_shortfall), 1.0)  # Tail risk
        
        # Ağırlıklı risk skoru
        risk_score = (
            0.4 * drawdown_risk +
            0.3 * volatility_risk +
            0.3 * tail_risk
        )
        
        return min(1.0, risk_score)
    
    def _count_consecutive_losses(self, historical_metrics: List[StrategyMetrics]) -> int:
        """Ardışık kayıpları say"""
        
        if not historical_metrics:
            return 0
        
        consecutive_losses = 0
        
        # Son performanslardan geriye doğru say
        for metrics in reversed(historical_metrics):
            if metrics.total_return < 0:
                consecutive_losses += 1
            else:
                break
        
        return consecutive_losses
    
    def _make_retirement_decision(
        self,
        strategy_config: StrategyConfig,
        current_metrics: StrategyMetrics,
        trend_analysis: Dict[str, Any],
        risk_assessment: Dict[str, Any],
        benchmark_metrics: Optional[StrategyMetrics] = None
    ) -> RetirementDecision:
        """Emeklilik kararı ver"""
        
        decision_reasons = []
        retirement_score = 0  # 0 = devam et, 1 = emekli et
        
        # 1. Performans kriterleri
        if current_metrics.sharpe_ratio < self.criteria.min_sharpe_ratio:
            decision_reasons.append(f"Düşük Sharpe ratio ({current_metrics.sharpe_ratio:.3f} < {self.criteria.min_sharpe_ratio})")
            retirement_score += 0.3
        
        if current_metrics.max_drawdown < self.criteria.max_drawdown_threshold:
            decision_reasons.append(f"Yüksek drawdown ({current_metrics.max_drawdown:.3f} < {self.criteria.max_drawdown_threshold})")
            retirement_score += 0.3
        
        if current_metrics.win_rate < self.criteria.min_win_rate:
            decision_reasons.append(f"Düşük win rate ({current_metrics.win_rate:.3f} < {self.criteria.min_win_rate})")
            retirement_score += 0.2
        
        # 2. Trend kriterleri
        if trend_analysis['trend'] == 'declining':
            decision_reasons.append("Azalan performans trendi")
            retirement_score += 0.2
        
        if trend_analysis.get('improvement_rate', 0) < 0:
            decision_reasons.append("Negatif iyileşme hızı")
            retirement_score += 0.1
        
        # 3. Risk kriterleri
        if risk_assessment['risk_level'] == 'high':
            decision_reasons.append("Yüksek risk seviyesi")
            retirement_score += 0.2
        
        if risk_assessment['consecutive_losses'] >= self.criteria.consecutive_loss_threshold:
            decision_reasons.append(f"Çoklu ardışık kayıp ({risk_assessment['consecutive_losses']})")
            retirement_score += 0.25
        
        # 4. Benchmark karşılaştırması
        if benchmark_metrics:
            if current_metrics.sharpe_ratio < benchmark_metrics.sharpe_ratio * 0.8:
                decision_reasons.append("Benchmark'ın altında performans")
                retirement_score += 0.15
        
        # 5. İşlem hacmi kriterleri
        if current_metrics.total_trades < self.criteria.min_trades:
            decision_reasons.append(f"Yetersiz işlem sayısı ({current_metrics.total_trades} < {self.criteria.min_trades})")
            retirement_score += 0.1
        
        # Karar eşiği
        RETIREMENT_THRESHOLD = 0.6
        
        if retirement_score >= RETIREMENT_THRESHOLD:
            decision = "retire"
            confidence = min(1.0, retirement_score)
        elif retirement_score >= 0.3:
            decision = "monitor"
            confidence = retirement_score
        elif current_metrics.sharpe_ratio > self.criteria.min_sharpe_ratio * 1.5:
            decision = "promote"
            confidence = min(1.0, (current_metrics.sharpe_ratio - self.criteria.min_sharpe_ratio) / (self.criteria.min_sharpe_ratio))
        else:
            decision = "continue"
            confidence = 0.8
        
        # Öneri
        if decision == "retire":
            recommendation = "Bu strateji düşük performans ve yüksek risk nedeniyle emekli edilmelidir."
        elif decision == "monitor":
            recommendation = "Strateji izlenmeli ve performansı iyileşmezse emeklilik değerlendirilmeli."
        elif decision == "promote":
            recommendation = "Strateji iyi performans gösteriyor, kapital tahsisi artırılabilir."
        else:
            recommendation = "Strateji kabul edilebilir seviyede performans gösteriyor, mevcut durumunu koruyabilir."
        
        return RetirementDecision(
            strategy_id=strategy_config.strategy_id,
            decision=decision,
            confidence=confidence,
            reasons=decision_reasons,
            metrics_at_decision=current_metrics.to_dict(),
            recommendation=recommendation
        )
    
    def _prepare_archive_data(
        self,
        strategy_config: StrategyConfig,
        current_metrics: StrategyMetrics,
        historical_metrics: List[StrategyMetrics],
        trend_analysis: Dict[str, Any],
        risk_assessment: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Arşiv verilerini hazırla"""
        
        return {
            'strategy_config': strategy_config.__dict__,
            'final_metrics': current_metrics.to_dict(),
            'historical_metrics': [m.to_dict() for m in historical_metrics],
            'trend_analysis': trend_analysis,
            'risk_assessment': risk_assessment,
            'archived_at': datetime.now().isoformat(),
            'data_completeness': len(historical_metrics),
            'performance_summary': {
                'avg_return': np.mean([m.total_return for m in historical_metrics]),
                'avg_sharpe': np.mean([m.sharpe_ratio for m in historical_metrics]),
                'max_drawdown': min([m.max_drawdown for m in historical_metrics]),
                'total_trades': sum([m.total_trades for m in historical_metrics]),
                'win_rate': np.mean([m.win_rate for m in historical_metrics])
            }
        }

class StrategyRetirement:
    """Ana strateji emeklilik yöneticisi"""
    
    def __init__(self, criteria: RetirementCriteria = None):
        self.criteria = criteria or RetirementCriteria()
        self.analyzer = RetirementAnalyzer(self.criteria)
        self.logger = logging.getLogger(__name__)
        
        # Emeklilik kayıtları
        self.retired_strategies = []
        self.monitoring_strategies = []
        self.analysis_history = []
    
    def evaluate_strategy(
        self,
        strategy_config: StrategyConfig,
        current_metrics: StrategyMetrics,
        historical_metrics: List[StrategyMetrics],
        benchmark_metrics: Optional[StrategyMetrics] = None
    ) -> RetirementAnalysis:
        """Strateji değerlendirme ve emeklilik analizi"""
        
        try:
            # Emeklilik analizi yap
            analysis = self.analyzer.analyze_strategy(
                strategy_config, 
                current_metrics, 
                historical_metrics, 
                benchmark_metrics
            )
            
            # Sonuçları kaydet
            self.analysis_history.append(analysis)
            
            # Strateji durumunu güncelle
            self._update_strategy_status(analysis)
            
            self.logger.info(
                f"Strateji değerlendirmesi tamamlandı: {strategy_config.strategy_id} "
                f"KARAR: {analysis.decision.decision}"
            )
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Strateji değerlendirme hatası: {e}")
            raise
    
    def batch_evaluate_strategies(
        self,
        strategies: Dict[str, Tuple[StrategyConfig, StrategyMetrics, List[StrategyMetrics]]],
        benchmark_metrics: Optional[StrategyMetrics] = None
    ) -> List[RetirementAnalysis]:
        """Toplu strateji değerlendirme"""
        
        self.logger.info(f"Toplu strateji değerlendirmesi başlatılıyor: {len(strategies)} strateji")
        
        analyses = []
        
        for strategy_id, (config, current_metrics, historical_metrics) in strategies.items():
            try:
                analysis = self.evaluate_strategy(config, current_metrics, historical_metrics, benchmark_metrics)
                analyses.append(analysis)
            except Exception as e:
                self.logger.error(f"Strateji değerlendirme hatası ({strategy_id}): {e}")
                # Hata durumunda basit analiz
                error_analysis = RetirementAnalysis(
                    strategy_id=strategy_id,
                    current_metrics=current_metrics,
                    historical_performance=historical_metrics,
                    trend_analysis={'trend': 'unknown', 'error': str(e)},
                    risk_assessment={'risk_level': 'unknown'},
                    decision=RetirementDecision(
                        strategy_id=strategy_id,
                        decision="monitor",
                        confidence=0.1,
                        reasons=[f"Analiz hatası: {e}"],
                        metrics_at_decision=current_metrics.to_dict(),
                        recommendation="Hata nedeniyle izlenmeli"
                    )
                )
                analyses.append(error_analysis)
        
        # Özet rapor
        self._generate_batch_summary(analyses)
        
        return analyses
    
    def _update_strategy_status(self, analysis: RetirementAnalysis):
        """Strateji durumunu güncelle"""
        
        decision = analysis.decision.decision
        
        if decision == "retire":
            # Emekli stratejiler listesine ekle
            if analysis.strategy_id not in [s['strategy_id'] for s in self.retired_strategies]:
                self.retired_strategies.append({
                    'strategy_id': analysis.strategy_id,
                    'retirement_date': analysis.retirement_date,
                    'reason': analysis.decision.reasons,
                    'final_performance': analysis.current_metrics.to_dict(),
                    'confidence': analysis.decision.confidence
                })
        
        elif decision == "monitor":
            # İzleme listesine ekle
            if analysis.strategy_id not in [s['strategy_id'] for s in self.monitoring_strategies]:
                self.monitoring_strategies.append({
                    'strategy_id': analysis.strategy_id,
                    'monitoring_start': datetime.now(),
                    'concerns': analysis.decision.reasons,
                    'confidence': analysis.decision.confidence
                })
    
    def _generate_batch_summary(self, analyses: List[RetirementAnalysis]):
        """Toplu değerlendirme özeti"""
        
        decision_counts = {'retire': 0, 'monitor': 0, 'continue': 0, 'promote': 0}
        
        for analysis in analyses:
            decision_counts[analysis.decision.decision] += 1
        
        self.logger.info(
            f"Toplu değerlendirme tamamlandı. "
            f"Emekli et: {decision_counts['retire']}, "
            f"İzle: {decision_counts['monitor']}, "
            f"Devam: {decision_counts['continue']}, "
            f"Terfi: {decision_counts['promote']}"
        )
    
    def get_retirement_report(self, days: int = 30) -> Dict[str, Any]:
        """Emeklilik raporu"""
        
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_analyses = [
            analysis for analysis in self.analysis_history
            if analysis.decision.timestamp >= cutoff_date
        ]
        
        # Karar dağılımı
        decision_summary = {'retire': 0, 'monitor': 0, 'continue': 0, 'promote': 0}
        for analysis in recent_analyses:
            decision_summary[analysis.decision.decision] += 1
        
        # Retired strategies özeti
        recent_retirements = [
            retired for retired in self.retired_strategies
            if retired['retirement_date'] and retired['retirement_date'] >= cutoff_date
        ]
        
        # Monitoring strategies özeti
        current_monitoring = self.monitoring_strategies.copy()
        
        # Performans analizi
        if recent_analyses:
            avg_confidence = np.mean([analysis.decision.confidence for analysis in recent_analyses])
            avg_final_sharpe = np.mean([analysis.current_metrics.sharpe_ratio for analysis in recent_analyses])
            avg_final_drawdown = np.mean([analysis.current_metrics.max_drawdown for analysis in recent_analyses])
        else:
            avg_confidence = avg_final_sharpe = avg_final_drawdown = 0
        
        return {
            'report_period_days': days,
            'total_evaluations': len(recent_analyses),
            'decision_summary': decision_summary,
            'retired_strategies': {
                'count': len(recent_retirements),
                'strategies': recent_retirements[:10],  # İlk 10
                'avg_confidence': np.mean([r['confidence'] for r in recent_retirements]) if recent_retirements else 0
            },
            'monitoring_strategies': {
                'count': len(current_monitoring),
                'strategies': [s['strategy_id'] for s in current_monitoring[:10]]
            },
            'performance_summary': {
                'avg_decision_confidence': avg_confidence,
                'avg_final_sharpe_ratio': avg_final_sharpe,
                'avg_final_drawdown': avg_final_drawdown,
                'total_strategies_processed': len(set(a.strategy_id for a in recent_analyses))
            },
            'top_retirement_reasons': self._analyze_retirement_reasons(),
            'risk_patterns': self._analyze_risk_patterns(recent_analyses)
        }
    
    def _analyze_retirement_reasons(self) -> List[Tuple[str, int]]:
        """En yaygın emeklilik sebeplerini analiz et"""
        
        reason_counts = {}
        
        for analysis in self.analysis_history:
            if analysis.decision.decision == "retire":
                for reason in analysis.decision.reasons:
                    reason_counts[reason] = reason_counts.get(reason, 0) + 1
        
        # En yaygın sebepleri sırala
        sorted_reasons = sorted(reason_counts.items(), key=lambda x: x[1], reverse=True)
        
        return sorted_reasons[:10]  # İlk 10 sebep
    
    def _analyze_risk_patterns(self, analyses: List[RetirementAnalysis]) -> Dict[str, Any]:
        """Risk desenlerini analiz et"""
        
        if not analyses:
            return {}
        
        # Risk seviyeleri
        risk_levels = {'low': 0, 'medium': 0, 'high': 0}
        for analysis in analyses:
            risk_level = analysis.risk_assessment.get('risk_level', 'unknown')
            if risk_level in risk_levels:
                risk_levels[risk_level] += 1
        
        # Ortalama risk skorları
        risk_scores = [
            analysis.risk_assessment.get('current_risk_score', 0) 
            for analysis in analyses 
            if 'current_risk_score' in analysis.risk_assessment
        ]
        
        avg_risk_score = np.mean(risk_scores) if risk_scores else 0
        
        # En yaygın risk faktörleri
        risk_factors = {}
        for analysis in analyses:
            for reason in analysis.decision.reasons:
                if any(keyword in reason.lower() for keyword in ['drawdown', 'risk', 'loss']):
                    risk_factors[reason] = risk_factors.get(reason, 0) + 1
        
        return {
            'risk_level_distribution': risk_levels,
            'average_risk_score': avg_risk_score,
            'top_risk_factors': sorted(risk_factors.items(), key=lambda x: x[1], reverse=True)[:5]
        }
    
    def export_retirement_data(self, filename: str = None) -> Dict[str, Any]:
        """Emeklilik verilerini dışa aktar"""
        
        export_data = {
            'export_timestamp': datetime.now().isoformat(),
            'criteria': self.criteria.__dict__,
            'retired_strategies': self.retired_strategies,
            'monitoring_strategies': self.monitoring_strategies,
            'analysis_history': [
                {
                    'strategy_id': analysis.strategy_id,
                    'decision': analysis.decision.decision,
                    'confidence': analysis.decision.confidence,
                    'reasons': analysis.decision.reasons,
                    'timestamp': analysis.decision.timestamp.isoformat(),
                    'final_metrics': analysis.current_metrics.to_dict()
                }
                for analysis in self.analysis_history
            ],
            'summary_statistics': self.get_retirement_report(days=365)  # Yıllık özet
        }
        
        if filename:
            import json
            with open(filename, 'w') as f:
                json.dump(export_data, f, indent=2, default=str)
        
        return export_data
    
    def cleanup_old_strategies(self, retention_days: int = 365) -> Dict[str, Any]:
        """Eski stratejileri temizle"""
        
        cutoff_date = datetime.now() - timedelta(days=retention_days)
        
        # Eski analizleri temizle
        old_analysis_count = len(self.analysis_history)
        self.analysis_history = [
            analysis for analysis in self.analysis_history
            if analysis.decision.timestamp >= cutoff_date
        ]
        
        # Eski emeklilikleri temizle (aktif kalmak için)
        old_retirement_count = len(self.retired_strategies)
        self.retired_strategies = [
            retired for retired in self.retired_strategies
            if not retired['retirement_date'] or retired['retirement_date'] >= cutoff_date
        ]
        
        cleanup_summary = {
            'retention_days': retention_days,
            'cutoff_date': cutoff_date.isoformat(),
            'cleaned_analysis_count': old_analysis_count - len(self.analysis_history),
            'cleaned_retirement_count': old_retirement_count - len(self.retired_strategies),
            'remaining_analysis_count': len(self.analysis_history),
            'remaining_retired_count': len(self.retired_strategies)
        }
        
        self.logger.info(f"Temizleme tamamlandı: {cleanup_summary}")
        
        return cleanup_summary

class PerformanceMonitor:
    """Performans izleme sistemi"""
    
    def __init__(self, window_size: int = 30):
        self.window_size = window_size
        self.logger = logging.getLogger(__name__)
        self.performance_cache = {}
    
    def monitor_performance_degradation(
        self,
        strategy_id: str,
        current_metrics: StrategyMetrics,
        historical_metrics: List[StrategyMetrics]
    ) -> Dict[str, Any]:
        """Performans bozulması izleme"""
        
        if len(historical_metrics) < self.window_size:
            return {
                'alert_level': 'insufficient_data',
                'message': 'Yeterli geçmiş veri yok',
                'recommendation': 'Daha fazla veri toplanmasını bekleyin'
            }
        
        # Son N günün performansı
        recent_metrics = historical_metrics[-self.window_size:]
        baseline_metrics = historical_metrics[-2*self.window_size:-self.window_size] if len(historical_metrics) >= 2*self.window_size else []
        
        # Performans karşılaştırması
        recent_avg_return = np.mean([m.total_return for m in recent_metrics])
        baseline_avg_return = np.mean([m.total_return for m in baseline_metrics]) if baseline_metrics else recent_avg_return
        
        recent_avg_sharpe = np.mean([m.sharpe_ratio for m in recent_metrics])
        baseline_avg_sharpe = np.mean([m.sharpe_ratio for m in baseline_metrics]) if baseline_metrics else recent_avg_sharpe
        
        recent_avg_drawdown = np.mean([abs(m.max_drawdown) for m in recent_metrics])
        baseline_avg_drawdown = np.mean([abs(m.max_drawdown) for m in baseline_metrics]) if baseline_metrics else recent_avg_drawdown
        
        # Değişim oranları
        return_change = (recent_avg_return - baseline_avg_return) / abs(baseline_avg_return) if baseline_avg_return != 0 else 0
        sharpe_change = (recent_avg_sharpe - baseline_avg_sharpe) / abs(baseline_avg_sharpe) if baseline_avg_sharpe != 0 else 0
        drawdown_change = (recent_avg_drawdown - baseline_avg_drawdown) / baseline_avg_drawdown if baseline_avg_drawdown != 0 else 0
        
        # Alert seviyesi
        degradation_score = 0
        
        if return_change < -0.2:  # %20'den fazla getiri düşüşü
            degradation_score += 0.4
        
        if sharpe_change < -0.3:  # %30'den fazla Sharpe düşüşü
            degradation_score += 0.3
        
        if drawdown_change > 0.5:  # %50'den fazla drawdown artışı
            degradation_score += 0.3
        
        # Alert level belirleme
        if degradation_score >= 0.7:
            alert_level = "critical"
            message = "Kritik performans bozulması tespit edildi"
            recommendation = "Acil strateji gözden geçirmesi gerekli"
        elif degradation_score >= 0.4:
            alert_level = "warning"
            message = "Orta seviye performans bozulması"
            recommendation = "Strateji performansı yakından izlenmeli"
        elif degradation_score >= 0.2:
            alert_level = "caution"
            message = "Hafif performans düşüşü"
            recommendation = "Performans trendi gözlemlenmeli"
        else:
            alert_level = "normal"
            message = "Performans normal aralıkta"
            recommendation = "Mevcut durum korunabilir"
        
        return {
            'strategy_id': strategy_id,
            'alert_level': alert_level,
            'message': message,
            'recommendation': recommendation,
            'degradation_score': degradation_score,
            'performance_changes': {
                'return_change': return_change,
                'sharpe_change': sharpe_change,
                'drawdown_change': drawdown_change
            },
            'window_size': self.window_size,
            'analysis_date': datetime.now().isoformat()
        }