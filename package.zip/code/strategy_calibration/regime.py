"""
Regime-Specific Optimization Modülü
===================================
Piyasa rejimlerine göre özelleştirilmiş strateji optimizasyonu.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging
from abc import ABC, abstractmethod
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.mixture import GaussianMixture
from sklearn.decomposition import PCA
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

from .core import StrategyConfig, StrategyMetrics

@dataclass
class MarketRegime:
    """Piyasa rejimi"""
    regime_id: str
    regime_name: str
    characteristics: Dict[str, float]
    market_conditions: Dict[str, Any]
    confidence: float
    start_date: datetime
    end_date: Optional[datetime] = None
    duration_days: int = 0
    description: str = ""

@dataclass
class RegimeOptimizationResult:
    """Rejim optimizasyon sonucu"""
    regime: MarketRegime
    optimized_strategies: List[StrategyConfig]
    regime_specific_metrics: Dict[str, StrategyMetrics]
    optimization_improvement: float
    regime_performance: Dict[str, float]
    adaptation_strategies: List[Dict[str, Any]]
    timestamp: datetime = field(default_factory=datetime.now)

@dataclass
class RegimeTransition:
    """Rejim geçişi"""
    from_regime: str
    to_regime: str
    transition_date: datetime
    transition_probability: float
    transition_indicators: Dict[str, float]
    warning_indicators: List[str]

class RegimeDetector:
    """Piyasa rejimi tespit sistemi"""
    
    def __init__(self, detection_window: int = 60):
        self.detection_window = detection_window
        self.logger = logging.getLogger(__name__)
        
        # Rejim tanımları
        self.regime_definitions = self._initialize_regime_definitions()
        
        # Geçmiş rejimler
        self.detected_regimes = []
        self.current_regime = None
        
        # Model parametreleri
        self.regime_models = {}
        self.transition_probabilities = {}
    
    def _initialize_regime_definitions(self) -> Dict[str, Dict[str, Any]]:
        """Rejim tanımlarını başlat"""
        
        return {
            'bull': {
                'name': 'Bull Market',
                'characteristics': {
                    'trend_strength': 0.7,
                    'volatility': 0.3,
                    'momentum': 0.8,
                    'volume_trend': 0.6,
                    'sentiment': 0.7
                },
                'criteria': {
                    'price_trend': 'positive',
                    'momentum_indicators': 'strong',
                    'volatility_level': 'low_to_medium',
                    'volume_pattern': 'increasing'
                },
                'description': 'Yükseliş trendi, yüksek momentum, düşük volatilite'
            },
            'bear': {
                'name': 'Bear Market',
                'characteristics': {
                    'trend_strength': -0.7,
                    'volatility': 0.8,
                    'momentum': -0.8,
                    'volume_trend': 0.4,
                    'sentiment': -0.7
                },
                'criteria': {
                    'price_trend': 'negative',
                    'momentum_indicators': 'weak',
                    'volatility_level': 'high',
                    'volume_pattern': 'decreasing'
                },
                'description': 'Düşüş trendi, negatif momentum, yüksek volatilite'
            },
            'volatile': {
                'name': 'High Volatility',
                'characteristics': {
                    'trend_strength': 0.0,
                    'volatility': 0.9,
                    'momentum': 0.0,
                    'volume_trend': 0.8,
                    'sentiment': -0.3
                },
                'criteria': {
                    'price_trend': 'sideways',
                    'momentum_indicators': 'neutral',
                    'volatility_level': 'very_high',
                    'volume_pattern': 'spiky'
                },
                'description': 'Yüksek volatilite, belirsiz trend, yüksek hacim'
            },
            'trending': {
                'name': 'Strong Trend',
                'characteristics': {
                    'trend_strength': 0.8,
                    'volatility': 0.4,
                    'momentum': 0.6,
                    'volume_trend': 0.7,
                    'sentiment': 0.5
                },
                'criteria': {
                    'price_trend': 'strong_directional',
                    'momentum_indicators': 'consistent',
                    'volatility_level': 'medium',
                    'volume_pattern': 'consistent'
                },
                'description': 'Güçlü trend, tutarlı momentum, orta volatilite'
            },
            'ranging': {
                'name': 'Sideways/Ranging',
                'characteristics': {
                    'trend_strength': 0.1,
                    'volatility': 0.5,
                    'momentum': 0.0,
                    'volume_trend': 0.3,
                    'sentiment': 0.0
                },
                'criteria': {
                    'price_trend': 'horizontal',
                    'momentum_indicators': 'weak',
                    'volatility_level': 'medium',
                    'volume_pattern': 'declining'
                },
                'description': 'Yatay hareket, düşük momentum, orta volatilite'
            },
            'low_volatility': {
                'name': 'Low Volatility',
                'characteristics': {
                    'trend_strength': 0.2,
                    'volatility': 0.2,
                    'momentum': 0.1,
                    'volume_trend': 0.4,
                    'sentiment': 0.2
                },
                'criteria': {
                    'price_trend': 'stable',
                    'momentum_indicators': 'weak',
                    'volatility_level': 'very_low',
                    'volume_pattern': 'low'
                },
                'description': 'Düşük volatilite, istikrarlı fiyat, düşük hacim'
            }
        }
    
    def detect_regime(
        self,
        market_data: pd.DataFrame,
        indicators: Optional[Dict[str, pd.Series]] = None
    ) -> MarketRegime:
        """Mevcut piyasa rejimini tespit et"""
        
        try:
            if len(market_data) < self.detection_window:
                raise ValueError(f"Yetersiz veri: {len(market_data)} < {self.detection_window}")
            
            # Son pencere verisini kullan
            recent_data = market_data.iloc[-self.detection_window:]
            
            # Temel piyasa göstergeleri hesapla
            market_indicators = self._calculate_market_indicators(recent_data)
            
            # Rejim skorlarını hesapla
            regime_scores = self._calculate_regime_scores(market_indicators, indicators or {})
            
            # En olası rejimi belirle
            best_regime_id = max(regime_scores.keys(), key=lambda x: regime_scores[x])
            confidence = regime_scores[best_regime_id]
            
            # Rejim karakteristikleri
            characteristics = self.regime_definitions[best_regime_id]['characteristics'].copy()
            
            # Rejim nesnesi oluştur
            current_regime = MarketRegime(
                regime_id=best_regime_id,
                regime_name=self.regime_definitions[best_regime_id]['name'],
                characteristics=characteristics,
                market_conditions=market_indicators,
                confidence=confidence,
                start_date=datetime.now(),
                description=self.regime_definitions[best_regime_id]['description']
            )
            
            # Önceki rejimle karşılaştır
            if self.current_regime and self.current_regime.regime_id != best_regime_id:
                transition = RegimeTransition(
                    from_regime=self.current_regime.regime_id,
                    to_regime=best_regime_id,
                    transition_date=datetime.now(),
                    transition_probability=confidence,
                    transition_indicators=market_indicators,
                    warning_indicators=self._detect_transition_warnings(market_indicators)
                )
                
                self.logger.info(f"Rejim geçişi: {self.current_regime.regime_name} -> {current_regime.regime_name}")
            
            # Güncelle
            self.current_regime = current_regime
            self.detected_regimes.append(current_regime)
            
            self.logger.info(f"Rejim tespit edildi: {current_regime.regime_name} (güven: {confidence:.3f})")
            
            return current_regime
            
        except Exception as e:
            self.logger.error(f"Rejim tespit hatası: {e}")
            # Varsayılan rejim döndür
            return MarketRegime(
                regime_id='unknown',
                regime_name='Unknown',
                characteristics={'confidence': 0},
                market_conditions={},
                confidence=0,
                start_date=datetime.now(),
                description='Rejim tespit edilemedi'
            )
    
    def _calculate_market_indicators(self, market_data: pd.DataFrame) -> Dict[str, float]:
        """Piyasa göstergelerini hesapla"""
        
        if len(market_data) < 2:
            return {}
        
        # Temel göstergeler
        close_prices = market_data['close'] if 'close' in market_data.columns else market_data.iloc[:, -1]
        high_prices = market_data['high'] if 'high' in market_data.columns else close_prices
        low_prices = market_data['low'] if 'low' in market_data.columns else close_prices
        volume = market_data['volume'] if 'volume' in market_data.columns else pd.Series(1000000, index=close_prices.index)
        
        # Fiyat değişimleri
        returns = close_prices.pct_change().dropna()
        
        # Trend gücü
        trend_strength = self._calculate_trend_strength(close_prices)
        
        # Volatilite
        volatility = returns.std() * np.sqrt(252)  # Yıllık volatilite
        
        # Momentum
        momentum = (close_prices.iloc[-1] / close_prices.iloc[0] - 1) * 100
        
        # Hacim trendi
        volume_trend = self._calculate_trend_strength(volume)
        
        # RSI (basitleştirilmiş)
        rsi = self._calculate_rsi(close_prices)
        
        # Average True Range
        atr = self._calculate_atr(high_prices, low_prices, close_prices)
        
        return {
            'trend_strength': trend_strength,
            'volatility': volatility,
            'momentum': momentum,
            'volume_trend': volume_trend,
            'rsi': rsi,
            'atr': atr,
            'price_change': returns.iloc[-1] if len(returns) > 0 else 0,
            'avg_volume': volume.mean(),
            'price_range': (high_prices.max() - low_prices.min()) / close_prices.mean()
        }
    
    def _calculate_trend_strength(self, price_series: pd.Series) -> float:
        """Trend gücü hesapla"""
        
        if len(price_series) < 2:
            return 0.0
        
        # Linear regression slope
        x = np.arange(len(price_series))
        slope, _, r_value, _, _ = stats.linregress(x, price_series.values)
        
        # Normalize et
        trend_strength = slope / price_series.mean() if price_series.mean() != 0 else 0
        
        # R-squared ile ağırlıklandır
        trend_strength *= r_value ** 2
        
        return np.clip(trend_strength, -1, 1)
    
    def _calculate_rsi(self, prices: pd.Series, period: int = 14) -> float:
        """RSI hesapla"""
        
        if len(prices) < period + 1:
            return 50.0  # Neutral
        
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi.iloc[-1] if not pd.isna(rsi.iloc[-1]) else 50.0
    
    def _calculate_atr(self, high: pd.Series, low: pd.Series, close: pd.Series, period: int = 14) -> float:
        """ATR hesapla"""
        
        if len(high) < 2:
            return 0.0
        
        high_low = high - low
        high_close = np.abs(high - close.shift())
        low_close = np.abs(low - close.shift())
        
        true_range = np.maximum(high_low, np.maximum(high_close, low_close))
        atr = true_range.rolling(window=period).mean()
        
        return atr.iloc[-1] if not pd.isna(atr.iloc[-1]) else 0.0
    
    def _calculate_regime_scores(
        self,
        market_indicators: Dict[str, float],
        additional_indicators: Dict[str, pd.Series]
    ) -> Dict[str, float]:
        """Rejim skorlarını hesapla"""
        
        scores = {}
        
        for regime_id, regime_def in self.regime_definitions.items():
            score = 0.0
            total_weight = 0.0
            
            # Karakteristiklere göre skorlama
            for char_name, char_value in regime_def['characteristics'].items():
                if char_name in market_indicators:
                    market_value = market_indicators[char_name]
                    
                    # Benzerlik skoru (cosine similarity benzeri)
                    if abs(char_value) > 0.1:  # Zero karakteristikleri göz ardı et
                        similarity = 1 - abs(char_value - market_value) / 2
                        score += similarity
                        total_weight += 1
            
            # Normalize et
            if total_weight > 0:
                scores[regime_id] = score / total_weight
            else:
                scores[regime_id] = 0.5
        
        return scores
    
    def _detect_transition_warnings(self, market_indicators: Dict[str, float]) -> List[str]:
        """Geçiş uyarılarını tespit et"""
        
        warnings = []
        
        # Volatilite artışı
        if market_indicators.get('volatility', 0) > 0.4:
            warnings.append("Yüksek volatilite tespit edildi")
        
        # Momentum değişimi
        momentum = market_indicators.get('momentum', 0)
        if abs(momentum) > 10:
            warnings.append("Güçlü momentum değişimi")
        
        # Trend zayıflaması
        trend_strength = market_indicators.get('trend_strength', 0)
        if abs(trend_strength) < 0.2:
            warnings.append("Trend zayıflaması")
        
        return warnings

class RegimeSpecificOptimizer:
    """Rejim spesifik optimizasyon sistemi"""
    
    def __init__(self, regime_detector: RegimeDetector):
        self.regime_detector = regime_detector
        self.logger = logging.getLogger(__name__)
        
        # Rejim bazlı optimizasyon sonuçları
        self.regime_optimizations = {}
        self.adaptation_history = []
        
        # Optimizasyon konfigürasyonları
        self.regime_configs = self._initialize_regime_configs()
    
    def _initialize_regime_configs(self) -> Dict[str, Dict[str, Any]]:
        """Rejim bazlı konfigürasyonları başlat"""
        
        return {
            'bull': {
                'preferred_strategies': ['momentum', 'trend_following', 'breakout'],
                'optimization_focus': 'return_maximization',
                'risk_tolerance': 0.8,
                'position_sizing_multiplier': 1.2,
                'rebalancing_frequency': 'weekly'
            },
            'bear': {
                'preferred_strategies': ['mean_reversion', 'short_selling', 'risk_parity'],
                'optimization_focus': 'risk_minimization',
                'risk_tolerance': 0.3,
                'position_sizing_multiplier': 0.7,
                'rebalancing_frequency': 'daily'
            },
            'volatile': {
                'preferred_strategies': ['volatility_trading', 'mean_reversion', 'risk_parity'],
                'optimization_focus': 'stability',
                'risk_tolerance': 0.4,
                'position_sizing_multiplier': 0.6,
                'rebalancing_frequency': 'daily'
            },
            'trending': {
                'preferred_strategies': ['momentum', 'trend_following', 'breakout'],
                'optimization_focus': 'trend_capture',
                'risk_tolerance': 0.7,
                'position_sizing_multiplier': 1.1,
                'rebalancing_frequency': 'weekly'
            },
            'ranging': {
                'preferred_strategies': ['mean_reversion', 'statistical_arbitrage', 'grid_trading'],
                'optimization_focus': 'range_trading',
                'risk_tolerance': 0.6,
                'position_sizing_multiplier': 0.8,
                'rebalancing_frequency': 'bi_weekly'
            },
            'low_volatility': {
                'preferred_strategies': ['carry_trading', 'yield_farming', 'statistical_arbitrage'],
                'optimization_focus': 'yield_maximization',
                'risk_tolerance': 0.5,
                'position_sizing_multiplier': 1.0,
                'rebalancing_frequency': 'monthly'
            }
        }
    
    def optimize_for_regime(
        self,
        strategies: List[StrategyConfig],
        market_data: pd.DataFrame,
        current_regime: Optional[MarketRegime] = None
    ) -> RegimeOptimizationResult:
        """Mevcut rejim için optimizasyon"""
        
        try:
            # Rejim tespit et
            if current_regime is None:
                current_regime = self.regime_detector.detect_regime(market_data)
            
            regime_id = current_regime.regime_id
            self.logger.info(f"Rejim bazlı optimizasyon: {current_regime.regime_name}")
            
            # Rejim konfigürasyonunu al
            regime_config = self.regime_configs.get(regime_id, self._get_default_config())
            
            # Stratejileri rejime göre filtrele ve sırala
            regime_suitable_strategies = self._filter_strategies_for_regime(
                strategies, current_regime, regime_config
            )
            
            # Rejim spesifik parametre optimizasyonu
            optimized_strategies = self._optimize_strategy_parameters(
                regime_suitable_strategies, current_regime, regime_config, market_data
            )
            
            # Rejim performans metrikleri
            regime_metrics = self._calculate_regime_performance(
                optimized_strategies, current_regime, market_data
            )
            
            # Optimizasyon iyileştirme oranı
            improvement = self._calculate_optimization_improvement(
                strategies, optimized_strategies, market_data
            )
            
            # Adaptasyon stratejileri
            adaptation_strategies = self._generate_adaptation_strategies(
                current_regime, regime_config
            )
            
            # Sonuç oluştur
            result = RegimeOptimizationResult(
                regime=current_regime,
                optimized_strategies=optimized_strategies,
                regime_specific_metrics=regime_metrics,
                optimization_improvement=improvement,
                regime_performance=regime_config,
                adaptation_strategies=adaptation_strategies
            )
            
            # Geçmişe kaydet
            self.regime_optimizations[regime_id] = result
            
            self.logger.info(f"Rejim optimizasyonu tamamlandı: {len(optimized_strategies)} strateji optimize edildi")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Rejim optimizasyon hatası: {e}")
            raise
    
    def _filter_strategies_for_regime(
        self,
        strategies: List[StrategyConfig],
        regime: MarketRegime,
        regime_config: Dict[str, Any]
    ) -> List[StrategyConfig]:
        """Stratejileri rejime göre filtrele"""
        
        preferred_types = regime_config['preferred_strategies']
        
        # Uygun stratejileri seç
        suitable_strategies = []
        
        for strategy in strategies:
            # Strateji tipi kontrolü
            if strategy.strategy_type in preferred_types:
                suitable_strategies.append(strategy)
            elif strategy.strategy_type in ['hybrid', 'adaptive']:
                # Hibrit stratejiler her rejimde kullanılabilir
                suitable_strategies.append(strategy)
        
        # Eğer yeterli uygun strateji yoksa, en iyi performanslı olanları seç
        if len(suitable_strategies) < len(strategies) * 0.5:
            remaining_strategies = [s for s in strategies if s not in suitable_strategies]
            # Basit performans bazlı seçim (gerçek uygulamada metriklerle)
            suitable_strategies.extend(remaining_strategies[:len(strategies)//2])
        
        self.logger.info(f"Rejim için uygun stratejiler: {len(suitable_strategies)}/{len(strategies)}")
        
        return suitable_strategies
    
    def _optimize_strategy_parameters(
        self,
        strategies: List[StrategyConfig],
        regime: MarketRegime,
        regime_config: Dict[str, Any],
        market_data: pd.DataFrame
    ) -> List[StrategyConfig]:
        """Strateji parametrelerini rejime göre optimize et"""
        
        optimized_strategies = []
        position_multiplier = regime_config['position_sizing_multiplier']
        
        for strategy in strategies:
            optimized_strategy = self._optimize_single_strategy(
                strategy, regime, regime_config, market_data, position_multiplier
            )
            optimized_strategies.append(optimized_strategy)
        
        return optimized_strategies
    
    def _optimize_single_strategy(
        self,
        strategy: StrategyConfig,
        regime: MarketRegime,
        regime_config: Dict[str, Any],
        market_data: pd.DataFrame,
        position_multiplier: float
    ) -> StrategyConfig:
        """Tek strateji optimizasyonu"""
        
        optimized_params = strategy.parameters.copy()
        
        # Rejim tipine göre parametre ayarlamaları
        regime_id = regime.regime_id
        
        if regime_id == 'bull':
            # Bull market: momentum parametrelerini artır
            if 'momentum_period' in optimized_params:
                optimized_params['momentum_period'] *= 1.1
            if 'position_sizing' in optimized_params:
                optimized_params['position_sizing'] *= position_multiplier
        
        elif regime_id == 'bear':
            # Bear market: risk parametrelerini sıkılaştır
            if 'stop_loss' in optimized_params:
                optimized_params['stop_loss'] *= 0.9  # Daha sıkı stop loss
            if 'position_sizing' in optimized_params:
                optimized_params['position_sizing'] *= position_multiplier
            if 'signal_threshold' in optimized_params:
                optimized_params['signal_threshold'] *= 1.2  # Daha yüksek eşik
        
        elif regime_id == 'volatile':
            # Volatil rejim: volatilite parametrelerini ayarla
            if 'volatility_threshold' in optimized_params:
                optimized_params['volatility_threshold'] *= 1.3
            if 'position_sizing' in optimized_params:
                optimized_params['position_sizing'] *= position_multiplier
            if 'rebalance_frequency' in optimized_params:
                optimized_params['rebalance_frequency'] = 'daily'
        
        elif regime_id == 'trending':
            # Trend rejim: trend takip parametrelerini artır
            if 'trend_strength_threshold' in optimized_params:
                optimized_params['trend_strength_threshold'] *= 0.9
            if 'position_sizing' in optimized_params:
                optimized_params['position_sizing'] *= position_multiplier
        
        elif regime_id == 'ranging':
            # Yatay rejim: mean reversion parametrelerini artır
            if 'reversion_threshold' in optimized_params:
                optimized_params['reversion_threshold'] *= 0.95
            if 'position_sizing' in optimized_params:
                optimized_params['position_sizing'] *= position_multiplier
        
        elif regime_id == 'low_volatility':
            # Düşük volatilite: carry parametrelerini optimize et
            if 'carry_threshold' in optimized_params:
                optimized_params['carry_threshold'] *= 0.9
            if 'position_sizing' in optimized_params:
                optimized_params['position_sizing'] *= position_multiplier
        
        # Risk limitleri rejime göre ayarla
        optimized_risk_limits = strategy.risk_limits.copy()
        risk_tolerance = regime_config['risk_tolerance']
        
        # Risk toleransına göre maksimum pozisyon ayarla
        if 'max_position' in optimized_risk_limits:
            optimized_risk_limits['max_position'] *= risk_tolerance
        
        # Yeni strateji konfigürasyonu
        optimized_strategy = StrategyConfig(
            strategy_id=f"{strategy.strategy_id}_regime_{regime_id}",
            strategy_type=strategy.strategy_type,
            parameters=optimized_params,
            constraints=strategy.constraints,
            risk_limits=optimized_risk_limits,
            optimization_targets=strategy.optimization_targets
        )
        
        return optimized_strategy
    
    def _calculate_regime_performance(
        self,
        strategies: List[StrategyConfig],
        regime: MarketRegime,
        market_data: pd.DataFrame
    ) -> Dict[str, StrategyMetrics]:
        """Rejim performansını hesapla"""
        
        # Basitleştirilmiş performans simülasyonu
        metrics = {}
        
        for strategy in strategies:
            # Rejim tipine göre performans tahmini
            expected_return = self._estimate_regime_performance(strategy, regime)
            
            # Sahte metrikler oluştur (gerçek uygulamada backtest gerekli)
            fake_metrics = StrategyMetrics(
                strategy_id=strategy.strategy_id,
                total_return=expected_return,
                sharpe_ratio=expected_return * 2,  # Basit tahmin
                max_drawdown=-abs(expected_return) * 0.3,
                win_rate=0.6 if expected_return > 0 else 0.4,
                profit_factor=1.5 if expected_return > 0 else 0.8,
                calmar_ratio=expected_return / 0.1,  # Basit tahmin
                sortino_ratio=expected_return * 2,
                var_95=-abs(expected_return) * 0.05,
                expected_shortfall=-abs(expected_return) * 0.08,
                win_loss_ratio=1.5 if expected_return > 0 else 0.7,
                avg_trade_duration=24 * 7,  # 1 hafta
                total_trades=20,
                winning_trades=12 if expected_return > 0 else 8,
                losing_trades=8 if expected_return > 0 else 12
            )
            
            metrics[strategy.strategy_id] = fake_metrics
        
        return metrics
    
    def _estimate_regime_performance(self, strategy: StrategyConfig, regime: MarketRegime) -> float:
        """Rejim performansını tahmin et"""
        
        # Rejim tipine göre baz performans
        regime_performance = {
            'bull': 0.15,
            'bear': -0.05,
            'volatile': 0.02,
            'trending': 0.12,
            'ranging': 0.03,
            'low_volatility': 0.08,
            'unknown': 0.05
        }
        
        base_performance = regime_performance.get(regime.regime_id, 0.05)
        
        # Strateji tipi bonusu
        strategy_bonus = {
            'momentum': 0.02,
            'mean_reversion': 0.01,
            'breakout': 0.015,
            'stat_arb': 0.005,
            'risk_parity': 0.01,
            'ml_strategy': 0.02,
            'hybrid': 0.01
        }
        
        strategy_performance_bonus = strategy_bonus.get(strategy.strategy_type, 0)
        
        # Rejim güven faktörü
        confidence_factor = regime.confidence
        
        # Final performans tahmini
        estimated_performance = (base_performance + strategy_performance_bonus) * confidence_factor
        
        return estimated_performance
    
    def _calculate_optimization_improvement(
        self,
        original_strategies: List[StrategyConfig],
        optimized_strategies: List[StrategyConfig],
        market_data: pd.DataFrame
    ) -> float:
        """Optimizasyon iyileştirmesini hesapla"""
        
        # Basitleştirilmiş iyileştirme hesabı
        # Gerçek uygulamada önceki optimizasyonlarla karşılaştırma yapılır
        
        base_improvement = 0.15  # %15 varsayılan iyileştirme
        
        # Strateji çeşitliliği bonusu
        diversity_bonus = min(0.1, len(optimized_strategies) / len(original_strategies) * 0.1)
        
        return base_improvement + diversity_bonus
    
    def _generate_adaptation_strategies(
        self,
        regime: MarketRegime,
        regime_config: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Adaptasyon stratejileri üret"""
        
        strategies = []
        
        # Risk yönetimi adaptasyonu
        risk_strategy = {
            'type': 'risk_management',
            'action': 'adjust_position_sizes',
            'parameter': 'position_sizing_multiplier',
            'value': regime_config['position_sizing_multiplier'],
            'rationale': f"Rejim {regime.regime_name} için pozisyon boyutu ayarlaması"
        }
        strategies.append(risk_strategy)
        
        # Yeniden dengeleme sıklığı
        rebalance_strategy = {
            'type': 'rebalancing',
            'action': 'change_frequency',
            'parameter': 'rebalancing_frequency',
            'value': regime_config['rebalancing_frequency'],
            'rationale': f"Rejim {regime.regime_name} için yeniden dengeleme sıklığı"
        }
        strategies.append(rebalance_strategy)
        
        # Strateji seçimi
        selection_strategy = {
            'type': 'strategy_selection',
            'action': 'focus_on_types',
            'parameter': 'preferred_strategies',
            'value': regime_config['preferred_strategies'],
            'rationale': f"Rejim {regime.regime_name} için tercih edilen strateji türleri"
        }
        strategies.append(selection_strategy)
        
        return strategies
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Varsayılan konfigürasyon"""
        
        return {
            'preferred_strategies': ['hybrid', 'adaptive'],
            'optimization_focus': 'balanced',
            'risk_tolerance': 0.5,
            'position_sizing_multiplier': 1.0,
            'rebalancing_frequency': 'weekly'
        }
    
    def get_regime_transition_plan(
        self,
        from_regime: str,
        to_regime: str,
        current_strategies: List[StrategyConfig]
    ) -> Dict[str, Any]:
        """Rejim geçiş planı"""
        
        from_config = self.regime_configs.get(from_regime, self._get_default_config())
        to_config = self.regime_configs.get(to_regime, self._get_default_config())
        
        transition_plan = {
            'from_regime': from_regime,
            'to_regime': to_regime,
            'transition_type': 'gradual',  # gradual, immediate, phased
            'estimated_duration_days': 14,
            'required_changes': [],
            'risk_factors': [],
            'success_indicators': []
        }
        
        # Pozisyon boyutu değişiklikleri
        position_change = to_config['position_sizing_multiplier'] / from_config['position_sizing_multiplier']
        if abs(position_change - 1) > 0.1:
            transition_plan['required_changes'].append({
                'type': 'position_sizing',
                'current': from_config['position_sizing_multiplier'],
                'target': to_config['position_sizing_multiplier'],
                'change_magnitude': position_change - 1
            })
        
        # Strateji değişiklikleri
        from_strategies = set(from_config['preferred_strategies'])
        to_strategies = set(to_config['preferred_strategies'])
        
        strategies_to_add = to_strategies - from_strategies
        strategies_to_remove = from_strategies - to_strategies
        
        if strategies_to_add:
            transition_plan['required_changes'].append({
                'type': 'add_strategies',
                'strategies': list(strategies_to_add)
            })
        
        if strategies_to_remove:
            transition_plan['required_changes'].append({
                'type': 'reduce_strategies',
                'strategies': list(strategies_to_remove)
            })
        
        # Risk faktörleri
        if from_config['risk_tolerance'] > to_config['risk_tolerance']:
            transition_plan['risk_factors'].append("Risk toleransı azalıyor - daha muhafazakar yaklaşım gerekli")
        
        if from_config['rebalancing_frequency'] != to_config['rebalancing_frequency']:
            transition_plan['risk_factors'].append("Yeniden dengeleme sıklığı değişiyor - işlem maliyetleri etkilenebilir")
        
        # Başarı göstergeleri
        transition_plan['success_indicators'] = [
            f"Rejim geçiş tamamlandığında {to_regime} konfigürasyonu aktif olmalı",
            "Volatilite seviyesi yeni rejime uygun hale gelmeli",
            "Pozisyon boyutları yeni risk toleransına uygun olmalı"
        ]
        
        return transition_plan
    
    def analyze_regime_performance_history(self, days: int = 90) -> Dict[str, Any]:
        """Rejim performans geçmişi analizi"""
        
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_optimizations = [
            result for result in self.regime_optimizations.values()
            if result.timestamp >= cutoff_date
        ]
        
        if not recent_optimizations:
            return {'error': 'Yeterli rejim optimizasyon verisi bulunamadı'}
        
        # Rejim dağılımı
        regime_distribution = {}
        total_improvement = 0
        regime_improvements = {}
        
        for result in recent_optimizations:
            regime_id = result.regime.regime_id
            
            # Dağılım
            regime_distribution[regime_id] = regime_distribution.get(regime_id, 0) + 1
            
            # İyileştirme
            total_improvement += result.optimization_improvement
            if regime_id not in regime_improvements:
                regime_improvements[regime_id] = []
            regime_improvements[regime_id].append(result.optimization_improvement)
        
        # İstatistikler
        avg_improvement = total_improvement / len(recent_optimizations)
        
        regime_stats = {}
        for regime_id, improvements in regime_improvements.items():
            regime_stats[regime_id] = {
                'count': len(improvements),
                'avg_improvement': np.mean(improvements),
                'best_improvement': max(improvements),
                'worst_improvement': min(improvements),
                'consistency': 1 - (np.std(improvements) / np.mean(improvements)) if np.mean(improvements) > 0 else 0
            }
        
        return {
            'analysis_period_days': days,
            'total_optimizations': len(recent_optimizations),
            'regime_distribution': regime_distribution,
            'overall_performance': {
                'avg_improvement': avg_improvement,
                'best_regime': max(regime_improvements.keys(), key=lambda x: np.mean(regime_improvements[x])),
                'worst_regime': min(regime_improvements.keys(), key=lambda x: np.mean(regime_improvements[x]))
            },
            'regime_specific_stats': regime_stats,
            'optimization_trends': self._calculate_optimization_trends(recent_optimizations)
        }
    
    def _calculate_optimization_trends(self, optimizations: List[RegimeOptimizationResult]) -> Dict[str, Any]:
        """Optimizasyon trendlerini hesapla"""
        
        if len(optimizations) < 2:
            return {'trend': 'insufficient_data'}
        
        # Zaman serisi analizi
        timestamps = [opt.timestamp for opt in optimizations]
        improvements = [opt.optimization_improvement for opt in optimizations]
        
        # Gün index'i oluştur
        days_from_start = [(ts - timestamps[0]).days for ts in timestamps]
        
        # Trend analizi
        if len(set(days_from_start)) > 1:
            slope, _, r_value, p_value, _ = stats.linregress(days_from_start, improvements)
            r_squared = r_value ** 2
            
            if r_squared > 0.5 and p_value < 0.05:
                if slope > 0:
                    trend = "improving"
                else:
                    trend = "declining"
            else:
                trend = "stable"
        else:
            trend = "stable"
            r_squared = 0
        
        return {
            'trend': trend,
            'r_squared': r_squared,
            'slope': slope,
            'improvement_rate': slope * 30  # Aylık iyileştirme hızı
        }