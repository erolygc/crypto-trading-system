"""
Strategy Evolution Engine
========================
Stratejilerin evrimsel gelişimi ve yeni strateji üretimi.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging
from abc import ABC, abstractmethod
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import random
import copy
import warnings
warnings.filterwarnings('ignore')

from .core import StrategyConfig, StrategyMetrics, StrategyEvolution

@dataclass
class Individual:
    """Genetik birey (strateji)"""
    strategy_config: StrategyConfig
    fitness: float = 0.0
    age: int = 0
    generation: int = 0
    parent_ids: List[str] = field(default_factory=list)
    mutations: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    
    def __post_init__(self):
        if not self.strategy_config.strategy_id:
            self.strategy_config.strategy_id = f"ind_{id(self)}"

@dataclass
class EvolutionResult:
    """Evrim sonucu"""
    generation: int
    population: List[Individual]
    best_individual: Individual
    population_fitness: List[float]
    diversity_score: float
    convergence_achieved: bool
    evolution_speed: float
    timestamp: datetime = field(default_factory=datetime.now)

class EvolutionOperator(ABC):
    """Evrim operatörü temel sınıfı"""
    
    def __init__(self, name: str, probability: float):
        self.name = name
        self.probability = probability
        self.logger = logging.getLogger(__name__)
    
    @abstractmethod
    def apply(self, individual: Individual, population: List[Individual]) -> Individual:
        """Operatörü uygula"""
        pass

class MutationOperator(EvolutionOperator):
    """Mutasyon operatörü"""
    
    def __init__(self, mutation_rate: float = 0.1):
        super().__init__("Mutation", mutation_rate)
        self.mutation_rate = mutation_rate
    
    def apply(self, individual: Individual, population: List[Individual]) -> Individual:
        """Mutasyon uygula"""
        
        mutated = copy.deepcopy(individual)
        
        # Mutasyon uygulama kontrolü
        if np.random.random() > self.mutation_rate:
            return mutated
        
        # Parametre mutasyonu
        param_mutations = []
        
        for param_name, param_value in mutated.strategy_config.parameters.items():
            mutation_applied = False
            
            if isinstance(param_value, (int, float)):
                # Sayısal mutasyon
                if np.random.random() < 0.3:  # %30 şans
                    # Gaussian noise
                    noise = np.random.normal(0, abs(param_value) * 0.1 + 0.01)
                    new_value = param_value + noise
                    
                    # Sınır kontrolü
                    if param_name in mutated.strategy_config.constraints:
                        bounds = mutated.strategy_config.constraints[param_name]
                        new_value = np.clip(new_value, bounds.get('min', -np.inf), bounds.get('max', np.inf))
                    
                    mutated.strategy_config.parameters[param_name] = new_value
                    mutation_applied = True
            
            elif isinstance(param_value, bool):
                # Boolean mutasyon
                if np.random.random() < 0.1:  # %10 şans
                    mutated.strategy_config.parameters[param_name] = not param_value
                    mutation_applied = True
            
            elif isinstance(param_value, str):
                # String mutasyon
                if np.random.random() < 0.2:  # %20 şans
                    # Basit modifikasyon
                    if param_value.endswith('_v1'):
                        new_value = param_value.replace('_v1', '_v2')
                    elif param_value.endswith('_v2'):
                        new_value = param_value.replace('_v2', '_v1')
                    else:
                        new_value = f"{param_value}_alt"
                    
                    mutated.strategy_config.parameters[param_name] = new_value
                    mutation_adapted = True
            
            if mutation_applied:
                param_mutations.append(param_name)
        
        mutated.mutations.extend(param_mutations)
        mutated.strategy_id = f"{mutated.strategy_config.strategy_id}_mut"
        
        return mutated

class CrossoverOperator(EvolutionOperator):
    """Çaprazlama operatörü"""
    
    def __init__(self, crossover_rate: float = 0.8):
        super().__init__("Crossover", crossover_rate)
        self.crossover_rate = crossover_rate
    
    def apply(self, parent1: Individual, parent2: Individual) -> Tuple[Individual, Individual]:
        """Çaprazlama uygula"""
        
        if np.random.random() > self.crossover_rate:
            return copy.deepcopy(parent1), copy.deepcopy(parent2)
        
        # Uniform crossover
        child1_config = StrategyConfig(
            strategy_id="",
            strategy_type=parent1.strategy_config.strategy_type,
            parameters={},
            constraints=parent1.strategy_config.constraints,
            risk_limits=parent1.strategy_config.risk_limits,
            optimization_targets=parent1.strategy_config.optimization_targets
        )
        
        child2_config = StrategyConfig(
            strategy_id="",
            strategy_type=parent1.strategy_config.strategy_type,
            parameters={},
            constraints=parent1.strategy_config.constraints,
            risk_limits=parent1.strategy_config.risk_limits,
            optimization_targets=parent1.strategy_config.optimization_targets
        )
        
        # Parametreleri karıştır
        all_params = set(parent1.strategy_config.parameters.keys()) | set(parent2.strategy_config.parameters.keys())
        
        for param_name in all_params:
            # Her parametre için rastgele ebeveyn seç
            if np.random.random() < 0.5:
                child1_config.parameters[param_name] = parent1.strategy_config.parameters.get(param_name)
                child2_config.parameters[param_name] = parent2.strategy_config.parameters.get(param_name)
            else:
                child1_config.parameters[param_name] = parent2.strategy_config.parameters.get(param_name)
                child2_config.parameters[param_name] = parent1.strategy_config.parameters.get(param_name)
        
        # ID'leri ayarla
        child1_config.strategy_id = f"child1_{parent1.strategy_config.strategy_id[:8]}_{parent2.strategy_config.strategy_id[:8]}"
        child2_config.strategy_id = f"child2_{parent1.strategy_config.strategy_id[:8]}_{parent2.strategy_config.strategy_id[:8]}"
        
        # Bireyler oluştur
        child1 = Individual(
            strategy_config=child1_config,
            generation=max(parent1.generation, parent2.generation) + 1,
            parent_ids=[parent1.strategy_config.strategy_id, parent2.strategy_config.strategy_id]
        )
        
        child2 = Individual(
            strategy_config=child2_config,
            generation=max(parent1.generation, parent2.generation) + 1,
            parent_ids=[parent1.strategy_config.strategy_id, parent2.strategy_config.strategy_id]
        )
        
        return child1, child2

class SelectionOperator(ABC):
    """Seçim operatörü"""
    
    def __init__(self, name: str):
        self.name = name
        self.logger = logging.getLogger(__name__)
    
    @abstractmethod
    def select(self, population: List[Individual], selection_size: int) -> List[Individual]:
        """Seçim yap"""
        pass

class TournamentSelection(SelectionOperator):
    """Turnuva seçimi"""
    
    def __init__(self, tournament_size: int = 3):
        super().__init__("TournamentSelection")
        self.tournament_size = tournament_size
    
    def select(self, population: List[Individual], selection_size: int) -> List[Individual]:
        """Turnuva seçimi"""
        
        selected = []
        
        for _ in range(selection_size):
            # Turnuva katılımcılarını seç
            if self.tournament_size > len(population):
                tournament = population.copy()
            else:
                tournament = random.sample(population, self.tournament_size)
            
            # En iyi fitness'a sahip olanı seç
            winner = max(tournament, key=lambda x: x.fitness)
            selected.append(copy.deepcopy(winner))
        
        return selected

class RouletteWheelSelection(SelectionOperator):
    """Roulette wheel seçimi"""
    
    def __init__(self):
        super().__init__("RouletteWheelSelection")
    
    def select(self, population: List[Individual], selection_size: int) -> List[Individual]:
        """Roulette wheel seçimi"""
        
        if not population:
            return []
        
        # Fitness toplamı (negatif değerleri pozitif yap)
        min_fitness = min(ind.fitness for ind in population)
        adjusted_fitness = [ind.fitness - min_fitness + 1e-10 for ind in population]  # Small epsilon
        total_fitness = sum(adjusted_fitness)
        
        if total_fitness <= 0:
            # Eğer tüm fitness değerleri negatifse, rastgele seç
            return random.choices(population, k=selection_size)
        
        # Seçim
        selected = []
        for _ in range(selection_size):
            # Roulette wheel döndür
            r = random.random() * total_fitness
            cumulative = 0
            
            for individual in population:
                cumulative += adjusted_fitness[population.index(individual)]
                if cumulative >= r:
                    selected.append(copy.deepcopy(individual))
                    break
        
        return selected

class DiversityManager:
    """Popülasyon çeşitliliği yöneticisi"""
    
    def __init__(self, diversity_threshold: float = 0.1, max_similarity: float = 0.8):
        self.diversity_threshold = diversity_threshold
        self.max_similarity = max_similarity
        self.logger = logging.getLogger(__name__)
    
    def calculate_diversity_score(self, population: List[Individual]) -> float:
        """Popülasyon çeşitlilik skoru"""
        
        if len(population) < 2:
            return 0.0
        
        # Parametre bazlı benzerlik hesaplama
        similarities = []
        
        for i in range(len(population)):
            for j in range(i + 1, len(population)):
                similarity = self._calculate_similarity(population[i], population[j])
                similarities.append(similarity)
        
        # Ortalama benzerlik
        avg_similarity = np.mean(similarities)
        
        # Çeşitlilik skoru (1 - benzerlik)
        diversity_score = 1 - avg_similarity
        
        return max(0, min(1, diversity_score))
    
    def _calculate_similarity(self, individual1: Individual, individual2: Individual) -> float:
        """İki birey arasındaki benzerlik"""
        
        params1 = individual1.strategy_config.parameters
        params2 = individual2.strategy_config.parameters
        
        # Ortak parametreler
        common_params = set(params1.keys()) & set(params2.keys())
        
        if not common_params:
            return 0.0
        
        similarities = []
        
        for param_name in common_params:
            val1, val2 = params1[param_name], params2[param_name]
            
            if isinstance(val1, (int, float)) and isinstance(val2, (int, float)):
                # Sayısal benzerlik (1 - normalized distance)
                if val1 == val2 == 0:
                    similarity = 1.0
                else:
                    max_val = max(abs(val1), abs(val2))
                    if max_val == 0:
                        similarity = 1.0
                    else:
                        distance = abs(val1 - val2) / max_val
                        similarity = 1 / (1 + distance)
                
                similarities.append(similarity)
            
            elif isinstance(val1, bool) and isinstance(val2, bool):
                # Boolean benzerlik
                similarities.append(1.0 if val1 == val2 else 0.0)
            
            elif isinstance(val1, str) and isinstance(val2, str):
                # String benzerlik
                if val1 == val2:
                    similarities.append(1.0)
                else:
                    # Basit edit distance approximation
                    similarities.append(0.5 if val1[:3] == val2[:3] else 0.0)
        
        return np.mean(similarities) if similarities else 0.0
    
    def ensure_diversity(self, population: List[Individual]) -> List[Individual]:
        """Çeşitlilik sağla"""
        
        diversity_score = self.calculate_diversity_score(population)
        
        if diversity_score >= self.diversity_threshold:
            return population
        
        self.logger.info(f"Düşük çeşitlilik tespit edildi: {diversity_score:.3f}")
        
        # Çeşitliliği artırmak için rastgele mutasyonlar uygula
        diverse_population = population.copy()
        
        # Popülasyonun %30'unu rastgele mutate et
        n_to_mutate = max(1, len(population) // 3)
        indices_to_mutate = random.sample(range(len(population)), n_to_mutate)
        
        mutation_op = MutationOperator(mutation_rate=0.5)
        
        for idx in indices_to_mutate:
            mutated = mutation_op.apply(diverse_population[idx], diverse_population)
            diverse_population[idx] = mutated
        
        new_diversity = self.calculate_diversity_score(diverse_population)
        self.logger.info(f"Düzenleme sonrası çeşitlilik: {new_diversity:.3f}")
        
        return diverse_population

class StrategyEvolutionEngine:
    """Ana strateji evrim motoru"""
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or self._default_config()
        self.logger = logging.getLogger(__name__)
        
        # Evrim parametreleri
        self.population_size = self.config['population_size']
        self.elite_size = self.config['elite_size']
        self.generation_limit = self.config['generation_limit']
        self.fitness_threshold = self.config.get('fitness_threshold', float('inf'))
        
        # Operatörler
        self.mutation_operator = MutationOperator(mutation_rate=self.config['mutation_rate'])
        self.crossover_operator = CrossoverOperator(crossover_rate=self.config['crossover_rate'])
        self.selection_operator = self._initialize_selection_operator()
        
        # Çeşitlilik yöneticisi
        self.diversity_manager = DiversityManager()
        
        # Evrim durumu
        self.current_generation = 0
        self.best_individual = None
        self.evolution_history = []
        self.fitness_history = []
        
    def _default_config(self) -> Dict[str, Any]:
        """Varsayılan konfigürasyon"""
        return {
            'population_size': 50,
            'elite_size': 10,
            'mutation_rate': 0.1,
            'crossover_rate': 0.8,
            'generation_limit': 100,
            'fitness_threshold': float('inf'),
            'selection_method': 'tournament',
            'tournament_size': 3,
            'diversity_threshold': 0.1,
            'convergence_patience': 10
        }
    
    def _initialize_selection_operator(self) -> SelectionOperator:
        """Seçim operatörünü başlat"""
        
        method = self.config.get('selection_method', 'tournament').lower()
        
        if method == 'tournament':
            return TournamentSelection(tournament_size=self.config.get('tournament_size', 3))
        elif method == 'roulette':
            return RouletteWheelSelection()
        else:
            self.logger.warning(f"Bilinmeyen seçim yöntemi: {method}. Tournament kullanılıyor.")
            return TournamentSelection()
    
    async def evolve_population(
        self,
        initial_population: List[Individual],
        fitness_function: Callable,
        market_data: Optional[pd.DataFrame] = None
    ) -> EvolutionResult:
        """Popülasyonu evrimle"""
        
        try:
            self.logger.info(f"Evrim başlatılıyor: {len(initial_population)} birey")
            
            population = initial_population.copy()
            generation = 0
            convergence_counter = 0
            last_best_fitness = float('-inf')
            
            while generation < self.generation_limit:
                self.current_generation = generation
                
                # Fitness değerlendirme
                self.logger.debug(f"Nesil {generation}: Fitness değerlendirme başlıyor")
                await self._evaluate_fitness(population, fitness_function, market_data)
                
                # En iyi bireyi güncelle
                current_best = max(population, key=lambda x: x.fitness)
                
                if current_best.fitness > self.best_individual.fitness if self.best_individual else False:
                    self.best_individual = copy.deepcopy(current_best)
                    convergence_counter = 0
                else:
                    convergence_counter += 1
                
                # Fitness geçmişi
                population_fitness = [ind.fitness for ind in population]
                avg_fitness = np.mean(population_fitness)
                
                self.fitness_history.append({
                    'generation': generation,
                    'best_fitness': current_best.fitness,
                    'average_fitness': avg_fitness,
                    'diversity_score': self.diversity_manager.calculate_diversity_score(population)
                })
                
                self.logger.info(
                    f"Nesil {generation}: En iyi={current_best.fitness:.6f}, "
                    f"Ortalama={avg_fitness:.6f}, "
                    f"Çeşitlilik={self.diversity_manager.calculate_diversity_score(population):.3f}"
                )
                
                # Yakınsama kontrolü
                if current_best.fitness >= self.fitness_threshold:
                    self.logger.info(f"Fitness eşiğine ulaşıldı: {current_best.fitness}")
                    break
                
                if convergence_counter >= self.config['convergence_patience']:
                    self.logger.info(f"Yakınsama sağlandı: {convergence_counter} nesil iyileşme yok")
                    break
                
                # Yeni nesil oluştur
                population = await self._create_next_generation(population)
                
                generation += 1
            
            # Son durumu kaydet
            final_diversity = self.diversity_manager.calculate_diversity_score(population)
            evolution_speed = self._calculate_evolution_speed()
            
            result = EvolutionResult(
                generation=generation,
                population=population,
                best_individual=self.best_individual,
                population_fitness=[ind.fitness for ind in population],
                diversity_score=final_diversity,
                convergence_achieved=convergence_counter > 0,
                evolution_speed=evolution_speed
            )
            
            # Evrim geçmişini kaydet
            self.evolution_history.append(result)
            
            self.logger.info(f"Evrim tamamlandı: {generation} nesil, en iyi fitness={self.best_individual.fitness:.6f}")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Evrim hatası: {e}")
            raise
    
    async def _evaluate_fitness(
        self, 
        population: List[Individual], 
        fitness_function: Callable,
        market_data: Optional[pd.DataFrame] = None
    ):
        """Popülasyon fitness'ını değerlendir"""
        
        for individual in population:
            try:
                # Fitness fonksiyonunu çağır
                if market_data is not None:
                    fitness = await fitness_function(individual.strategy_config, market_data)
                else:
                    fitness = fitness_function(individual.strategy_config)
                
                individual.fitness = fitness
                
            except Exception as e:
                self.logger.warning(f"Fitness değerlendirme hatası ({individual.strategy_config.strategy_id}): {e}")
                individual.fitness = 0.0  # Düşük fitness
    
    async def _create_next_generation(self, current_population: List[Individual]) -> List[Individual]:
        """Yeni nesil oluştur"""
        
        # Elite bireyleri koru (en iyi fitness)
        sorted_population = sorted(current_population, key=lambda x: x.fitness, reverse=True)
        elite = sorted_population[:self.elite_size]
        
        # Seçim havuzu
        selection_pool = self.selection_operator.select(current_population, self.population_size)
        
        # Yeni bireyler üret
        new_population = [copy.deepcopy(ind) for ind in elite]  # Elitleri ekle
        
        while len(new_population) < self.population_size:
            # Ebeveynleri seç
            if len(selection_pool) >= 2:
                parent1, parent2 = random.sample(selection_pool, 2)
            else:
                # Yeterli birey yoksa rastgele seç
                parent1, parent2 = random.choice(current_population), random.choice(current_population)
            
            # Çaprazlama
            child1, child2 = self.crossover_operator.apply(parent1, parent2)
            
            # Mutasyon
            child1 = self.mutation_operator.apply(child1, current_population)
            if len(new_population) < self.population_size - 1:
                child2 = self.mutation_operator.apply(child2, current_population)
                new_population.append(child2)
            
            new_population.append(child1)
        
        # Çeşitlilik sağla
        diverse_population = self.diversity_manager.ensure_diversity(new_population)
        
        # Yaş güncellemesi
        for individual in diverse_population:
            individual.age += 1
        
        return diverse_population[:self.population_size]
    
    def _calculate_evolution_speed(self) -> float:
        """Evrim hızını hesapla"""
        
        if len(self.fitness_history) < 2:
            return 0.0
        
        # Son 5 nesildeki iyileşme hızı
        recent_fitness = [record['best_fitness'] for record in self.fitness_history[-5:]]
        
        if len(recent_fitness) < 2:
            return 0.0
        
        # Linear trend slope
        x = np.arange(len(recent_fitness))
        slope, _, r_value, p_value, std_err = np.polyfit(x, recent_fitness, 1)
        
        return slope  # Fitness iyileşme hızı
    
    def generate_new_strategies(
        self,
        parent_strategies: List[StrategyConfig],
        n_offspring: int = 10,
        generation_method: str = "crossover"
    ) -> List[StrategyConfig]:
        """Yeni stratejiler üret"""
        
        if generation_method == "crossover":
            return self._crossover_generation(parent_strategies, n_offspring)
        elif generation_method == "mutation":
            return self._mutation_generation(parent_strategies, n_offspring)
        elif generation_method == "random":
            return self._random_generation(parent_strategies, n_offspring)
        else:
            raise ValueError(f"Desteklenmeyen üretim yöntemi: {generation_method}")
    
    def _crossover_generation(self, parent_strategies: List[StrategyConfig], n_offspring: int) -> List[StrategyConfig]:
        """Çaprazlama ile yeni stratejiler üret"""
        
        offspring = []
        
        # Bireyler oluştur
        parent_individuals = [
            Individual(strategy_config=strategy) for strategy in parent_strategies
        ]
        
        for _ in range(n_offspring):
            # İki ebeveyn seç
            parent1, parent2 = random.sample(parent_individuals, 2)
            
            # Çaprazlama
            child1, child2 = self.crossover_operator.apply(parent1, parent2)
            
            # Mutasyon uygula
            child1 = self.mutation_operator.apply(child1, parent_individuals)
            
            offspring.append(child1.strategy_config)
        
        return offspring
    
    def _mutation_generation(self, parent_strategies: List[StrategyConfig], n_offspring: int) -> List[StrategyConfig]:
        """Mutasyon ile yeni stratejiler üret"""
        
        offspring = []
        
        # Bireyler oluştur
        parent_individuals = [
            Individual(strategy_config=strategy) for strategy in parent_strategies
        ]
        
        for _ in range(n_offspring):
            # Rastgele ebeveyn seç
            parent = random.choice(parent_individuals)
            
            # Mutasyon
            child = self.mutation_operator.apply(parent, parent_individuals)
            
            offspring.append(child.strategy_config)
        
        return offspring
    
    def _random_generation(self, parent_strategies: List[StrategyConfig], n_offspring: int) -> List[StrategyConfig]:
        """Rastgele yeni stratejiler üret"""
        
        offspring = []
        
        for _ in range(n_offspring):
            # Rastgele ebeveyn seç
            parent_strategy = random.choice(parent_strategies)
            
            # Rastgele değişikliklerle yeni strateji oluştur
            new_strategy = copy.deepcopy(parent_strategy)
            new_strategy.strategy_id = f"random_{parent_strategy.strategy_id}_{random.randint(1000, 9999)}"
            
            # Rastgele parametre değişiklikleri
            for param_name in list(new_strategy.parameters.keys()):
                if isinstance(new_strategy.parameters[param_name], (int, float)):
                    # Gaussian noise
                    noise = np.random.normal(0, 0.2)
                    new_strategy.parameters[param_name] *= (1 + noise)
                
                elif isinstance(new_strategy.parameters[param_name], bool):
                    # Random flip
                    if random.random() < 0.3:
                        new_strategy.parameters[param_name] = not new_strategy.parameters[param_name]
            
            offspring.append(new_strategy)
        
        return offspring
    
    def cluster_strategies(self, population: List[Individual], n_clusters: Optional[int] = None) -> Dict[int, List[Individual]]:
        """Stratejileri kümele"""
        
        if not population:
            return {}
        
        # Parametre vektörlerini çıkar
        all_params = set()
        for individual in population:
            all_params.update(individual.strategy_config.parameters.keys())
        
        if not all_params:
            return {0: population}
        
        # Özellik vektörleri
        feature_vectors = []
        param_names = sorted(all_params)
        
        for individual in population:
            vector = []
            for param_name in param_names:
                value = individual.strategy_config.parameters.get(param_name, 0)
                
                if isinstance(value, (int, float)):
                    vector.append(value)
                elif isinstance(value, bool):
                    vector.append(1 if value else 0)
                else:
                    vector.append(hash(value) % 100)  # String'leri hash'le
            
            feature_vectors.append(vector)
        
        feature_matrix = np.array(feature_vectors)
        
        # Standartlaştır
        scaler = StandardScaler()
        feature_matrix_scaled = scaler.fit_transform(feature_matrix)
        
        # Küme sayısını belirle
        if n_clusters is None:
            n_clusters = min(10, len(population) // 3)
        
        # K-means clustering
        kmeans = KMeans(n_clusters=n_clusters, random_state=42)
        cluster_labels = kmeans.fit_predict(feature_matrix_scaled)
        
        # Kümeleri grupla
        clusters = {}
        for i, label in enumerate(cluster_labels):
            if label not in clusters:
                clusters[label] = []
            clusters[label].append(population[i])
        
        # Silhouette score hesapla
        if len(clusters) > 1:
            silhouette_avg = silhouette_score(feature_matrix_scaled, cluster_labels)
            self.logger.info(f"Kümeleme silhouette skoru: {silhouette_avg:.3f}")
        
        return clusters
    
    def get_evolution_statistics(self) -> Dict[str, Any]:
        """Evrim istatistikleri"""
        
        if not self.fitness_history:
            return {}
        
        recent_history = self.fitness_history[-10:]  # Son 10 nesil
        
        return {
            'current_generation': self.current_generation,
            'total_generations': len(self.fitness_history),
            'best_fitness_history': [h['best_fitness'] for h in self.fitness_history],
            'average_fitness_history': [h['average_fitness'] for h in self.fitness_history],
            'diversity_history': [h['diversity_score'] for h in self.fitness_history],
            'recent_improvements': {
                'best_fitness_change': recent_history[-1]['best_fitness'] - recent_history[0]['best_fitness'] if len(recent_history) > 1 else 0,
                'avg_fitness_change': recent_history[-1]['average_fitness'] - recent_history[0]['average_fitness'] if len(recent_history) > 1 else 0,
                'diversity_change': recent_history[-1]['diversity_score'] - recent_history[0]['diversity_score'] if len(recent_history) > 1 else 0
            },
            'evolution_speed': self._calculate_evolution_speed(),
            'convergence_status': 'converged' if len(self.evolution_history) > 0 and self.evolution_history[-1].convergence_achieved else 'evolving'
        }
    
    def export_evolution_report(self, filename: str = None) -> Dict[str, Any]:
        """Evrim raporu"""
        
        report = {
            'evolution_statistics': self.get_evolution_statistics(),
            'configuration': self.config,
            'best_individual': {
                'strategy_id': self.best_individual.strategy_config.strategy_id if self.best_individual else None,
                'fitness': self.best_individual.fitness if self.best_individual else 0,
                'parameters': self.best_individual.strategy_config.parameters if self.best_individual else {},
                'generation': self.best_individual.generation if self.best_individual else 0,
                'age': self.best_individual.age if self.best_individual else 0
            } if self.best_individual else None,
            'fitness_progression': self.fitness_history,
            'evolution_history': [
                {
                    'generation': result.generation,
                    'best_fitness': result.best_individual.fitness,
                    'diversity_score': result.diversity_score,
                    'population_size': len(result.population),
                    'convergence_achieved': result.convergence_achieved
                }
                for result in self.evolution_history
            ],
            'timestamp': datetime.now()
        }
        
        if filename:
            import json
            with open(filename, 'w') as f:
                json.dump(report, f, indent=2, default=str)
        
        return report