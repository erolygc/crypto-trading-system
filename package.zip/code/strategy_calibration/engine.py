"""
Strategy Calibration Ana Motor
=============================
Tüm strateji kalibrasyon bileşenlerini birleştiren ana motor.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging
import asyncio
import concurrent.futures
from concurrent.futures import ThreadPoolExecutor
import warnings
warnings.filterwarnings('ignore')

# Alt modüller
from .core import StrategyCalibrator, PerformanceEvaluator, ParameterOptimizer, StrategyEvolution
from .ranking import StrategyRanker
from .optimization import BayesianOptimizer, GeneticOptimizer, ParameterTuner
from .bandits import MultiArmedBandit
from .validation import CrossValidator, WalkForwardValidator, ValidationManager
from .evolution import StrategyEvolutionEngine
from .allocation import ResourceAllocator, EqualWeightAllocation, RiskParityAllocation
from .retirement import StrategyRetirement, PerformanceMonitor
from .generation import StrategyGenerator
from .regime import RegimeDetector, RegimeSpecificOptimizer

@dataclass
class CalibrationConfig:
    """Ana kalibrasyon konfigürasyonu"""
    # Strateji yönetimi
    max_strategies: int = 50
    min_strategies: int = 5
    strategy_rotation_interval: int = 30  # gün
    
    # Performans kriterleri
    min_sharpe_ratio: float = 0.5
    max_drawdown_threshold: float = -0.3
    min_trades: int = 20
    min_win_rate: float = 0.3
    
    # Optimizasyon ayarları
    optimization_method: str = "bayesian"
    optimization_frequency: str = "weekly"
    rebalance_threshold: float = 0.05
    
    # Risk yönetimi
    max_position_size: float = 0.2
    portfolio_volatility_target: float = 0.15
    correlation_threshold: float = 0.7
    
    # Rejim yönetimi
    regime_detection_window: int = 60
    adaptation_speed: float = 0.1
    
    # Emeklilik kriterleri
    retirement_threshold: float = 0.6
    monitoring_period: int = 30
    
    # Üretim ayarları
    new_strategy_generation: bool = True
    generation_frequency: int = 7
    target_new_strategies: int = 5

@dataclass
class CalibrationResult:
    """Ana kalibrasyon sonucu"""
    timestamp: datetime
    active_strategies: List[Dict[str, Any]]
    strategy_allocations: Dict[str, float]
    portfolio_metrics: Dict[str, Any]
    optimization_summary: Dict[str, Any]
    regime_status: Dict[str, Any]
    retirement_actions: List[Dict[str, Any]]
    new_strategies: List[Dict[str, Any]]
    performance_report: Dict[str, Any]
    next_actions: List[str]
    execution_time: float

class StrategyCalibrationEngine:
    """Ana strateji kalibrasyon motoru"""
    
    def __init__(self, config: CalibrationConfig = None):
        self.config = config or CalibrationConfig()
        self.logger = logging.getLogger(__name__)
        
        # Alt sistemleri başlat
        self._initialize_components()
        
        # Durum bilgileri
        self.last_calibration = None
        self.calibration_history = []
        self.active_strategy_portfolio = {}
        self.performance_cache = {}
        
        # Thread pool
        self.executor = ThreadPoolExecutor(max_workers=4)
        
        self.logger.info("Strategy Calibration Engine başlatıldı")
    
    def _initialize_components(self):
        """Alt bileşenleri başlat"""
        
        try:
            # Core component
            self.core_calibrator = StrategyCalibrator({
                'optimization_method': self.config.optimization_method
            })
            
            # Ranking system
            self.strategy_ranker = StrategyRanker({
                'weighting_method': 'equal',
                'ranking_horizon': 252,
                'min_trades': self.config.min_trades
            })
            
            # Multi-armed bandit
            self.bandit = MultiArmedBandit(
                algorithm="ucb",
                config={'ucb': {'confidence_level': 2.0}}
            )
            
            # Validation system
            self.validation_manager = ValidationManager()
            self.validation_manager.add_validator(
                "cross_validation",
                CrossValidator()
            )
            self.validation_manager.add_validator(
                "walk_forward",
                WalkForwardValidator()
            )
            
            # Evolution engine
            self.evolution_engine = StrategyEvolutionEngine({
                'population_size': 30,
                'elite_size': 5,
                'generation_limit': 10
            })
            
            # Resource allocator
            self.allocator = ResourceAllocator(
                allocation_strategy="sharpe_ratio",
                config={'constraints': {'max_allocation_per_strategy': self.config.max_position_size}}
            )
            
            # Retirement system
            self.retirement_system = StrategyRetirement()
            self.performance_monitor = PerformanceMonitor(window_size=30)
            
            # Strategy generator
            self.strategy_generator = StrategyGenerator()
            
            # Regime detector and optimizer
            self.regime_detector = RegimeDetector(detection_window=self.config.regime_detection_window)
            self.regime_optimizer = RegimeSpecificOptimizer(self.regime_detector)
            
            self.logger.info("Tüm bileşenler başarıyla başlatıldı")
            
        except Exception as e:
            self.logger.error(f"Bileşen başlatma hatası: {e}")
            raise
    
    async def run_full_calibration(
        self,
        strategies: List[Any],
        market_data: pd.DataFrame,
        benchmark_data: Optional[pd.DataFrame] = None
    ) -> CalibrationResult:
        """Tam kalibrasyon döngüsü çalıştır"""
        
        start_time = datetime.now()
        self.logger.info("Tam kalibrasyon döngüsü başlatılıyor...")
        
        try:
            # 1. Veri hazırlama
            self.logger.info("1. Veri hazırlama...")
            prepared_data = await self._prepare_data(strategies, market_data, benchmark_data)
            
            # 2. Piyasa rejimi tespiti
            self.logger.info("2. Piyasa rejimi tespiti...")
            current_regime = self.regime_detector.detect_regime(market_data)
            
            # 3. Performans değerlendirme ve sıralama
            self.logger.info("3. Performans değerlendirme...")
            performance_results = await self._evaluate_and_rank_strategies(
                strategies, market_data, current_regime
            )
            
            # 4. Cross-validation
            self.logger.info("4. Cross-validation...")
            validation_results = await self._run_validation(strategies, market_data)
            
            # 5. Strateji optimizasyonu
            self.logger.info("5. Strateji optimizasyonu...")
            optimized_strategies = await self._optimize_strategies(
                strategies, market_data, current_regime
            )
            
            # 6. Rejim spesifik optimizasyon
            self.logger.info("6. Rejim spesifik optimizasyon...")
            regime_optimization = await self._optimize_for_regime(
                optimized_strategies, market_data, current_regime
            )
            
            # 7. Kaynak tahsisi
            self.logger.info("7. Kaynak tahsisi...")
            allocation_result = await self._allocate_resources(
                regime_optimization.optimized_strategies,
                regime_optimization.regime_specific_metrics
            )
            
            # 8. Emeklilik değerlendirmesi
            self.logger.info("8. Emeklilik değerlendirmesi...")
            retirement_decisions = await self._evaluate_retirement(
                strategies, market_data
            )
            
            # 9. Yeni strateji üretimi
            self.logger.info("9. Yeni strateji üretimi...")
            new_strategies = await self._generate_new_strategies(
                strategies, market_data, current_regime
            )
            
            # 10. Multi-armed bandit güncelleme
            self.logger.info("10. Multi-armed bandit güncelleme...")
            await self._update_bandit(allocation_result)
            
            # 11. Portfolio metriklerini hesapla
            self.logger.info("11. Portfolio metrikleri...")
            portfolio_metrics = await self._calculate_portfolio_metrics(
                allocation_result, regime_optimization
            )
            
            # 12. Sonraki aksiyonlar belirleme
            self.logger.info("12. Sonraki aksiyonlar...")
            next_actions = self._determine_next_actions(current_regime, retirement_decisions)
            
            # Sonucu hazırla
            execution_time = (datetime.now() - start_time).total_seconds()
            
            result = CalibrationResult(
                timestamp=datetime.now(),
                active_strategies=[
                    {
                        'strategy_id': s.strategy_id,
                        'strategy_type': s.strategy_type,
                        'parameters': s.parameters,
                        'metrics': regime_optimization.regime_specific_metrics.get(s.strategy_id).to_dict() if s.strategy_id in regime_optimization.regime_specific_metrics else {}
                    }
                    for s in regime_optimization.optimized_strategies
                ],
                strategy_allocations=allocation_result.strategy_allocations,
                portfolio_metrics=portfolio_metrics,
                optimization_summary={
                    'optimization_improvement': regime_optimization.optimization_improvement,
                    'regime_specific_gains': regime_optimization.regime_performance,
                    'validation_scores': {k: v.out_of_sample_score for k, v in validation_results.items()}
                },
                regime_status={
                    'current_regime': current_regime.regime_name,
                    'regime_confidence': current_regime.confidence,
                    'regime_characteristics': current_regime.characteristics
                },
                retirement_actions=[
                    {
                        'strategy_id': decision.strategy_id,
                        'action': decision.decision,
                        'confidence': decision.confidence,
                        'reasons': decision.reasons
                    }
                    for decision in retirement_decisions
                ],
                new_strategies=[
                    {
                        'strategy_id': gs.strategy_config.strategy_id,
                        'generation_method': gs.generation_method,
                        'novelty_score': gs.novelty_score,
                        'expected_performance': gs.expected_performance
                    }
                    for gs in new_strategies
                ],
                performance_report=self._generate_performance_report(allocation_result),
                next_actions=next_actions,
                execution_time=execution_time
            )
            
            # Geçmişe kaydet
            self.calibration_history.append(result)
            self.last_calibration = datetime.now()
            
            # Bellek sınırlaması
            if len(self.calibration_history) > 100:
                self.calibration_history = self.calibration_history[-100:]
            
            self.logger.info(f"Tam kalibrasyon tamamlandı. Süre: {execution_time:.2f} saniye")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Kalibrasyon hatası: {e}")
            raise
    
    async def _prepare_data(
        self,
        strategies: List[Any],
        market_data: pd.DataFrame,
        benchmark_data: Optional[pd.DataFrame]
    ) -> Dict[str, Any]:
        """Veri hazırlama"""
        
        # Temel veri kontrolü
        if len(market_data) < 30:
            raise ValueError("Yetersiz piyasa verisi")
        
        # Benchmark metrikleri
        benchmark_metrics = None
        if benchmark_data is not None and len(benchmark_data) > 30:
            # Benchmark için basit metrikler
            returns = benchmark_data['close'].pct_change().dropna()
            benchmark_metrics = PerformanceEvaluator().calculate_metrics(returns)
        
        return {
            'market_data': market_data,
            'benchmark_metrics': benchmark_metrics,
            'data_quality': self._assess_data_quality(market_data)
        }
    
    def _assess_data_quality(self, market_data: pd.DataFrame) -> Dict[str, Any]:
        """Veri kalitesi değerlendirmesi"""
        
        total_rows = len(market_data)
        
        # Null değer kontrolü
        null_counts = market_data.isnull().sum()
        null_ratio = null_counts.max() / total_rows if total_rows > 0 else 0
        
        # Veri sürekliliği
        if total_rows > 1:
            date_gaps = market_data.index.to_series().diff().dt.days.dropna()
            max_gap = date_gaps.max() if len(date_gaps) > 0 else 0
        else:
            max_gap = 0
        
        return {
            'total_rows': total_rows,
            'null_ratio': null_ratio,
            'max_date_gap': max_gap,
            'quality_score': max(0, 1 - null_ratio - (max_gap / 30) * 0.1)
        }
    
    async def _evaluate_and_rank_strategies(
        self,
        strategies: List[Any],
        market_data: pd.DataFrame,
        regime: Any
    ) -> Dict[str, Any]:
        """Stratejileri değerlendir ve sırala"""
        
        # Strateji değerlendirmesi
        evaluation_tasks = []
        for strategy in strategies:
            task = self._evaluate_single_strategy(strategy, market_data)
            evaluation_tasks.append(task)
        
        # Paralel değerlendirme
        metrics_results = await asyncio.gather(*evaluation_tasks, return_exceptions=True)
        
        # Metrikleri organize et
        metrics_dict = {}
        for strategy, result in zip(strategies, metrics_results):
            if isinstance(result, Exception):
                self.logger.warning(f"Strateji değerlendirme hatası: {result}")
                continue
            
            result.strategy_id = strategy.strategy_id
            metrics_dict[strategy.strategy_id] = result
        
        # Sıralama
        if metrics_dict:
            ranking_results = await self.strategy_ranker.rank_strategies(
                strategies, metrics_dict, regime.regime_name
            )
        else:
            ranking_results = []
        
        return {
            'metrics': metrics_dict,
            'rankings': ranking_results
        }
    
    async def _evaluate_single_strategy(self, strategy: Any, market_data: pd.DataFrame) -> Any:
        """Tek strateji değerlendirmesi"""
        
        # Basitleştirilmiş değerlendirme
        # Gerçek uygulamada strateji logic'i çalıştırılır
        
        # Rastgele performans simülasyonu
        np.random.seed(hash(strategy.strategy_id) % 2**32)
        
        returns = np.random.normal(0.001, 0.02, len(market_data))
        returns_series = pd.Series(returns, index=market_data.index)
        
        metrics = PerformanceEvaluator().calculate_metrics(returns_series)
        
        return metrics
    
    async def _run_validation(
        self,
        strategies: List[Any],
        market_data: pd.DataFrame
    ) -> Dict[str, Any]:
        """Cross-validation çalıştır"""
        
        # Evaluation function
        async def evaluation_func(strategy, train_data, test_data):
            # Basitleştirilmiş değerlendirme
            np.random.seed(hash(strategy.strategy_id) % 2**32 + len(train_data))
            test_returns = np.random.normal(0.001, 0.02, len(test_data))
            return np.mean(test_returns)
        
        # Validation tasks
        validation_tasks = []
        for strategy in strategies[:10]:  # İlk 10 strateji için validasyon
            task = asyncio.create_task(
                self.validation_manager.validate_strategy(
                    strategy, market_data, evaluation_func
                )
            )
            validation_tasks.append(task)
        
        validation_results = await asyncio.gather(*validation_tasks, return_exceptions=True)
        
        # Sonuçları organize et
        organized_results = {}
        for strategy, result in zip(strategies[:10], validation_results):
            if not isinstance(result, Exception):
                organized_results[strategy.strategy_id] = result
        
        return organized_results
    
    async def _optimize_strategies(
        self,
        strategies: List[Any],
        market_data: pd.DataFrame,
        regime: Any
    ) -> List[Any]:
        """Stratejileri optimize et"""
        
        # Bayesian optimization kullan
        tuner = ParameterTuner(optimizer_type="bayesian")
        
        optimized_strategies = []
        
        for strategy in strategies:
            try:
                # Optimization function
                async def objective_func(params):
                    test_strategy = type(strategy)(
                        strategy_id=f"test_{strategy.strategy_id}",
                        strategy_type=strategy.strategy_type,
                        parameters=params,
                        constraints=strategy.constraints,
                        risk_limits=strategy.risk_limits,
                        optimization_targets=strategy.optimization_targets
                    )
                    
                    # Basit performans testi
                    np.random.seed(hash(strategy.strategy_id) % 2**32 + hash(str(params)))
                    test_returns = np.random.normal(0.001, 0.02, len(market_data)//4)
                    return np.mean(test_returns)
                
                # Optimize parameters
                result = tuner.tune_strategy_parameters(strategy, objective_func, n_calls=20)
                optimized_strategies.append(result.strategy_config)
                
            except Exception as e:
                self.logger.warning(f"Strateji optimizasyon hatası ({strategy.strategy_id}): {e}")
                optimized_strategies.append(strategy)
        
        return optimized_strategies
    
    async def _optimize_for_regime(
        self,
        strategies: List[Any],
        market_data: pd.DataFrame,
        regime: Any
    ) -> Any:
        """Rejim spesifik optimizasyon"""
        
        result = await asyncio.get_event_loop().run_in_executor(
            self.executor,
            self.regime_optimizer.optimize_for_regime,
            strategies,
            market_data,
            regime
        )
        
        return result
    
    async def _allocate_resources(
        self,
        strategies: List[Any],
        metrics: Dict[str, Any]
    ) -> Any:
        """Kaynak tahsisi"""
        
        result = await asyncio.get_event_loop().run_in_executor(
            self.executor,
            self.allocator.allocate_resources,
            metrics
        )
        
        return result
    
    async def _evaluate_retirement(
        self,
        strategies: List[Any],
        market_data: pd.DataFrame
    ) -> List[Any]:
        """Emeklilik değerlendirmesi"""
        
        retirement_tasks = []
        
        for strategy in strategies:
            task = asyncio.create_task(
                self._evaluate_single_retirement(strategy, market_data)
            )
            retirement_tasks.append(task)
        
        results = await asyncio.gather(*retirement_tasks, return_exceptions=True)
        
        # Sadece başarılı sonuçları al
        decisions = []
        for strategy, result in zip(strategies, results):
            if not isinstance(result, Exception):
                decisions.append(result)
        
        return decisions
    
    async def _evaluate_single_retirement(self, strategy: Any, market_data: pd.DataFrame) -> Any:
        """Tek strateji emeklilik değerlendirmesi"""
        
        # Performans izleme
        monitoring_result = await asyncio.get_event_loop().run_in_executor(
            self.executor,
            self.performance_monitor.monitor_performance_degradation,
            strategy.strategy_id,
            None,  # current_metrics - simüle edilecek
            []     # historical_metrics - simüle edilecek
        )
        
        # Eğer kritik problem varsa emeklilik değerlendirmesi
        if monitoring_result.get('alert_level') == 'critical':
            # Basit emeklilik analizi
            return type('RetirementDecision', (), {
                'strategy_id': strategy.strategy_id,
                'decision': 'monitor',
                'confidence': 0.8,
                'reasons': ['Kritik performans bozulması tespit edildi'],
                'timestamp': datetime.now()
            })()
        
        return None
    
    async def _generate_new_strategies(
        self,
        existing_strategies: List[Any],
        market_data: pd.DataFrame,
        regime: Any
    ) -> List[Any]:
        """Yeni strateji üretimi"""
        
        if not self.config.new_strategy_generation:
            return []
        
        try:
            market_conditions = {
                'regime': regime.regime_name,
                'volatility': regime.characteristics.get('volatility', 0.3),
                'trend_strength': regime.characteristics.get('trend_strength', 0)
            }
            
            generated_strategies = await asyncio.get_event_loop().run_in_executor(
                self.executor,
                self.strategy_generator.generate_strategies,
                existing_strategies,
                market_conditions,
                self.config.target_new_strategies
            )
            
            return generated_strategies
            
        except Exception as e:
            self.logger.error(f"Yeni strateji üretim hatası: {e}")
            return []
    
    async def _update_bandit(self, allocation_result: Any):
        """Multi-armed bandit güncelleme"""
        
        try:
            for strategy_id, allocation in allocation_result.strategy_allocations.items():
                # Simüle edilmiş ödül (allocation'a bağlı)
                reward = allocation * np.random.normal(1.0, 0.2)
                
                await asyncio.get_event_loop().run_in_executor(
                    self.executor,
                    self.bandit.update_performance,
                    strategy_id,
                    reward
                )
        
        except Exception as e:
            self.logger.error(f"Bandit güncelleme hatası: {e}")
    
    async def _calculate_portfolio_metrics(
        self,
        allocation_result: Any,
        regime_optimization: Any
    ) -> Dict[str, Any]:
        """Portfolio metriklerini hesapla"""
        
        # Ağırlıklı ortalama metrikler
        total_weight = sum(allocation_result.strategy_allocations.values())
        
        if total_weight > 0:
            weighted_return = sum(
                allocation_result.strategy_allocations[strategy_id] * 
                regime_optimization.regime_specific_metrics.get(strategy_id, type('Metrics', (), {'total_return': 0})()).total_return
                for strategy_id in allocation_result.strategy_allocations
            ) / total_weight
            
            weighted_sharpe = sum(
                allocation_result.strategy_allocations[strategy_id] * 
                regime_optimization.regime_specific_metrics.get(strategy_id, type('Metrics', (), {'sharpe_ratio': 0})()).sharpe_ratio
                for strategy_id in allocation_result.strategy_allocations
            ) / total_weight
        else:
            weighted_return = weighted_sharpe = 0
        
        return {
            'expected_return': weighted_return,
            'expected_sharpe_ratio': weighted_sharpe,
            'total_strategies': len(allocation_result.strategy_allocations),
            'allocation_concentration': max(allocation_result.strategy_allocations.values()) if allocation_result.strategy_allocations else 0,
            'diversification_ratio': len(allocation_result.strategy_allocations) / max(1, len(allocation_result.strategy_allocations))
        }
    
    def _determine_next_actions(
        self,
        regime: Any,
        retirement_decisions: List[Any]
    ) -> List[str]:
        """Sonraki aksiyonları belirle"""
        
        actions = []
        
        # Rejim bazlı aksiyonlar
        if regime.confidence < 0.7:
            actions.append("Rejim belirsizliği yüksek - daha fazla veri toplanmalı")
        
        if regime.regime_id == 'volatile':
            actions.append("Volatil rejim - risk azaltma önlemleri alınmalı")
        
        # Emeklilik aksiyonları
        retirement_count = len([d for d in retirement_decisions if d and d.decision == 'retire'])
        if retirement_count > 0:
            actions.append(f"{retirement_count} strateji emeklilik değerlendirmesine tabi tutulmalı")
        
        # Optimizasyon aksiyonları
        actions.extend([
            "Düzenli performans izleme yapılmalı",
            "Rejim geçişlerine hazırlıklı olunmalı",
            "Yeni stratejiler sürekli değerlendirilmeli"
        ])
        
        return actions
    
    def _generate_performance_report(self, allocation_result: Any) -> Dict[str, Any]:
        """Performans raporu oluştur"""
        
        return {
            'allocation_summary': {
                'total_allocation': allocation_result.total_allocation,
                'expected_return': allocation_result.expected_return,
                'expected_risk': allocation_result.expected_risk,
                'sharpe_ratio': allocation_result.sharpe_ratio,
                'diversification_ratio': allocation_result.diversification_ratio
            },
            'risk_metrics': {
                'concentration_risk': allocation_result.concentration_risk,
                'transaction_costs': allocation_result.transaction_costs
            },
            'rebalancing_info': {
                'frequency': allocation_result.rebalancing_frequency,
                'last_rebalance': datetime.now().isoformat()
            }
        }
    
    def get_calibration_status(self) -> Dict[str, Any]:
        """Kalibrasyon durumu"""
        
        return {
            'engine_status': 'running',
            'last_calibration': self.last_calibration.isoformat() if self.last_calibration else None,
            'total_calibrations': len(self.calibration_history),
            'active_strategies': len(self.active_strategy_portfolio),
            'current_regime': self.regime_detector.current_regime.regime_name if self.regime_detector.current_regime else 'unknown',
            'uptime_hours': (datetime.now() - (self.last_calibration or datetime.now())).total_seconds() / 3600
        }
    
    def export_calibration_report(self, days: int = 30) -> Dict[str, Any]:
        """Kalibrasyon raporu dışa aktar"""
        
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_calibrations = [
            calibration for calibration in self.calibration_history
            if calibration.timestamp >= cutoff_date
        ]
        
        if not recent_calibrations:
            return {'error': 'Belirtilen dönemde kalibrasyon verisi bulunamadı'}
        
        # Özet istatistikler
        avg_execution_time = np.mean([c.execution_time for c in recent_calibrations])
        total_strategies = sum([len(c.active_strategies) for c in recent_calibrations])
        avg_portfolio_return = np.mean([c.portfolio_metrics.get('expected_return', 0) for c in recent_calibrations])
        
        # Rejim analizi
        regime_analysis = {}
        for calibration in recent_calibrations:
            regime = calibration.regime_status['current_regime']
            if regime not in regime_analysis:
                regime_analysis[regime] = {'count': 0, 'avg_return': []}
            regime_analysis[regime]['count'] += 1
            regime_analysis[regime]['avg_return'].append(calibration.portfolio_metrics.get('expected_return', 0))
        
        # Ortalama getirileri hesapla
        for regime in regime_analysis:
            if regime_analysis[regime]['avg_return']:
                regime_analysis[regime]['avg_return'] = np.mean(regime_analysis[regime]['avg_return'])
        
        return {
            'report_period_days': days,
            'total_calibrations': len(recent_calibrations),
            'performance_summary': {
                'avg_execution_time_seconds': avg_execution_time,
                'avg_portfolio_return': avg_portfolio_return,
                'total_strategies_processed': total_strategies,
                'avg_strategies_per_calibration': total_strategies / len(recent_calibrations)
            },
            'regime_analysis': regime_analysis,
            'recent_performance': [
                {
                    'date': c.timestamp.isoformat(),
                    'regime': c.regime_status['current_regime'],
                    'portfolio_return': c.portfolio_metrics.get('expected_return', 0),
                    'num_strategies': len(c.active_strategies),
                    'optimization_improvement': c.optimization_summary.get('optimization_improvement', 0)
                }
                for c in recent_calibrations[-10:]
            ],
            'system_health': {
                'engine_uptime': self.get_calibration_status()['uptime_hours'],
                'success_rate': len(recent_calibrations) / max(1, len(recent_calibrations)),
                'data_quality': 'good' if recent_calibrations else 'unknown'
            }
        }

# Convenience functions
async def run_strategy_calibration(
    strategies: List[Any],
    market_data: pd.DataFrame,
    config: Optional[CalibrationConfig] = None,
    benchmark_data: Optional[pd.DataFrame] = None
) -> CalibrationResult:
    """Hızlı kalibrasyon fonksiyonu"""
    
    engine = StrategyCalibrationEngine(config)
    return await engine.run_full_calibration(strategies, market_data, benchmark_data)

def create_calibration_config(
    max_strategies: int = 50,
    optimization_frequency: str = "weekly",
    new_strategy_generation: bool = True
) -> CalibrationConfig:
    """Hızlı konfigürasyon oluşturma"""
    
    return CalibrationConfig(
        max_strategies=max_strategies,
        optimization_frequency=optimization_frequency,
        new_strategy_generation=new_strategy_generation
    )