"""
Resource Allocation Modülü
=========================
Performans tabanlı strateji kaynak tahsisi ve portföy optimizasyonu.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging
from abc import ABC, abstractmethod
from scipy.optimize import minimize
from sklearn.covariance import LedoitWolf
import warnings
warnings.filterwarnings('ignore')

from .core import StrategyConfig, StrategyMetrics

@dataclass
class AllocationConstraints:
    """Tahsis kısıtlamaları"""
    max_allocation_per_strategy: float = 0.5  # Maksimum %50
    min_allocation_per_strategy: float = 0.0  # Minimum %0
    max_number_of_strategies: int = 20       # Maksimum 20 strateji
    max_concentration_risk: float = 0.3      # Maksimum konsantrasyon riski
    rebalance_frequency: str = "weekly"      # Yeniden dengeleme sıklığı
    transaction_cost_rate: float = 0.001     # İşlem maliyeti %0.1

@dataclass
class AllocationResult:
    """Tahsis sonucu"""
    strategy_allocations: Dict[str, float]
    total_allocation: float
    expected_return: float
    expected_risk: float
    sharpe_ratio: float
    diversification_ratio: float
    concentration_risk: float
    transaction_costs: float
    rebalancing_frequency: str
    timestamp: datetime = field(default_factory=datetime.now)

@dataclass
class RiskMetrics:
    """Risk metrikleri"""
    volatility: float
    var_95: float
    expected_shortfall: float
    maximum_drawdown: float
    correlation_risk: float
    concentration_risk: float
    tail_risk: float

class AllocationStrategy(ABC):
    """Tahsis stratejisi temel sınıfı"""
    
    def __init__(self, name: str):
        self.name = name
        self.logger = logging.getLogger(__name__)
    
    @abstractmethod
    def allocate(
        self,
        strategies: Dict[str, StrategyMetrics],
        constraints: AllocationConstraints,
        target_return: Optional[float] = None,
        risk_tolerance: Optional[float] = None
    ) -> AllocationResult:
        """Kaynak tahsisi"""
        pass

class EqualWeightAllocation(AllocationStrategy):
    """Eşit ağırlık tahsisi"""
    
    def __init__(self):
        super().__init__("EqualWeight")
    
    def allocate(
        self,
        strategies: Dict[str, StrategyMetrics],
        constraints: AllocationConstraints,
        target_return: Optional[float] = None,
        risk_tolerance: Optional[float] = None
    ) -> AllocationResult:
        
        try:
            strategy_count = min(len(strategies), constraints.max_number_of_strategies)
            
            if strategy_count == 0:
                return AllocationResult({}, 0, 0, 0, 0, 0, 0, 0, constraints.rebalance_frequency)
            
            # Eşit ağırlık
            equal_weight = 1.0 / strategy_count
            
            # Stratejileri seç (en iyi performansa göre)
            sorted_strategies = sorted(
                strategies.items(),
                key=lambda x: x[1].sharpe_ratio,
                reverse=True
            )
            
            selected_strategies = sorted_strategies[:strategy_count]
            
            allocations = {}
            for strategy_id, metrics in selected_strategies:
                allocations[strategy_id] = equal_weight
            
            # Metrikler hesapla
            returns = [metrics.total_return for _, metrics in selected_strategies]
            expected_return = np.mean(returns)
            
            risks = [abs(metrics.max_drawdown) for _, metrics in selected_strategies]
            expected_risk = np.mean(risks)
            
            sharpe_ratio = expected_return / expected_risk if expected_risk > 0 else 0
            
            # Diğer metrikler
            diversification_ratio = 1.0 / strategy_count  # Maksimum çeşitlilik
            concentration_risk = max(allocations.values())  # En yüksek ağırlık
            transaction_costs = len(strategies) * constraints.transaction_cost_rate
            
            return AllocationResult(
                strategy_allocations=allocations,
                total_allocation=sum(allocations.values()),
                expected_return=expected_return,
                expected_risk=expected_risk,
                sharpe_ratio=sharpe_ratio,
                diversification_ratio=diversification_ratio,
                concentration_risk=concentration_risk,
                transaction_costs=transaction_costs,
                rebalancing_frequency=constraints.rebalance_frequency
            )
            
        except Exception as e:
            self.logger.error(f"Eşit ağırlık tahsisi hatası: {e}")
            raise

class RiskParityAllocation(AllocationStrategy):
    """Risk parity tahsisi"""
    
    def __init__(self):
        super().__init__("RiskParity")
    
    def allocate(
        self,
        strategies: Dict[str, StrategyMetrics],
        constraints: AllocationConstraints,
        target_return: Optional[float] = None,
        risk_tolerance: Optional[float] = None
    ) -> AllocationResult:
        
        try:
            if not strategies:
                return AllocationResult({}, 0, 0, 0, 0, 0, 0, 0, constraints.rebalance_frequency)
            
            # Risk ölçümleri
            risks = {}
            for strategy_id, metrics in strategies.items():
                # Volatiliteyi risk olarak kullan
                volatility = abs(metrics.max_drawdown) if metrics.max_drawdown != 0 else 0.1
                risks[strategy_id] = volatility
            
            # Toplam risk
            total_risk = sum(risks.values())
            
            if total_risk == 0:
                # Eşit ağırlık fallback
                equal_alloc = EqualWeightAllocation()
                return equal_alloc.allocate(strategies, constraints, target_return, risk_tolerance)
            
            # Risk parity ağırlıkları
            allocations = {}
            for strategy_id, risk in risks.items():
                allocations[strategy_id] = risk / total_risk
            
            # Kısıtlamaları uygula
            allocations = self._apply_constraints(allocations, constraints)
            
            # Metrikler hesapla
            selected_strategies = {k: strategies[k] for k in allocations.keys() if k in strategies}
            
            returns = [metrics.total_return for metrics in selected_strategies.values()]
            expected_return = np.mean(returns)
            
            risks = [abs(metrics.max_drawdown) for metrics in selected_strategies.values()]
            expected_risk = np.mean(risks)
            
            sharpe_ratio = expected_return / expected_risk if expected_risk > 0 else 0
            
            diversification_ratio = len(selected_strategies) / len(strategies)
            concentration_risk = max(allocations.values()) if allocations else 0
            transaction_costs = len(allocations) * constraints.transaction_cost_rate
            
            return AllocationResult(
                strategy_allocations=allocations,
                total_allocation=sum(allocations.values()),
                expected_return=expected_return,
                expected_risk=expected_risk,
                sharpe_ratio=sharpe_ratio,
                diversification_ratio=diversification_ratio,
                concentration_risk=concentration_risk,
                transaction_costs=transaction_costs,
                rebalancing_frequency=constraints.rebalance_frequency
            )
            
        except Exception as e:
            self.logger.error(f"Risk parity tahsisi hatası: {e}")
            raise
    
    def _apply_constraints(self, allocations: Dict[str, float], constraints: AllocationConstraints) -> Dict[str, float]:
        """Kısıtlamaları uygula"""
        
        # Maksimum ağırlık sınırı
        for strategy_id in allocations:
            allocations[strategy_id] = min(allocations[strategy_id], constraints.max_allocation_per_strategy)
        
        # Normalize et
        total = sum(allocations.values())
        if total > 0:
            for strategy_id in allocations:
                allocations[strategy_id] /= total
        
        return allocations

class SharpeRatioAllocation(AllocationStrategy):
    """Sharpe ratio tabanlı tahsis"""
    
    def __init__(self):
        super().__init__("SharpeRatio")
    
    def allocate(
        self,
        strategies: Dict[str, StrategyMetrics],
        constraints: AllocationConstraints,
        target_return: Optional[float] = None,
        risk_tolerance: Optional[float] = None
    ) -> AllocationResult:
        
        try:
            if not strategies:
                return AllocationResult({}, 0, 0, 0, 0, 0, 0, 0, constraints.rebalance_frequency)
            
            # Sharpe oranları
            sharpe_ratios = {}
            for strategy_id, metrics in strategies.items():
                if metrics.sharpe_ratio > 0:  # Sadece pozitif Sharpe
                    sharpe_ratios[strategy_id] = metrics.sharpe_ratio
                else:
                    sharpe_ratios[strategy_id] = 0.01  # Düşük ağırlık
            
            if not sharpe_ratios:
                return AllocationResult({}, 0, 0, 0, 0, 0, 0, 0, constraints.rebalance_frequency)
            
            # En iyi Sharpe oranına sahip stratejileri seç
            sorted_sharpe = sorted(sharpe_ratios.items(), key=lambda x: x[1], reverse=True)
            top_strategies = sorted_sharpe[:constraints.max_number_of_strategies]
            
            # Ağırlıkları Sharpe oranlarına göre hesapla
            total_sharpe = sum(sharpe for _, sharpe in top_strategies)
            
            allocations = {}
            for strategy_id, sharpe in top_strategies:
                allocations[strategy_id] = sharpe / total_sharpe if total_sharpe > 0 else 0
            
            # Kısıtlamaları uygula
            allocations = self._apply_constraints(allocations, constraints)
            
            # Metrikler hesapla
            selected_strategies = {k: strategies[k] for k in allocations.keys() if k in strategies}
            
            returns = [metrics.total_return for metrics in selected_strategies.values()]
            expected_return = np.mean(returns)
            
            risks = [abs(metrics.max_drawdown) for metrics in selected_strategies.values()]
            expected_risk = np.mean(risks)
            
            sharpe_ratio = np.mean([metrics.sharpe_ratio for metrics in selected_strategies.values()])
            
            diversification_ratio = len(selected_strategies) / len(strategies)
            concentration_risk = max(allocations.values()) if allocations else 0
            transaction_costs = len(allocations) * constraints.transaction_cost_rate
            
            return AllocationResult(
                strategy_allocations=allocations,
                total_allocation=sum(allocations.values()),
                expected_return=expected_return,
                expected_risk=expected_risk,
                sharpe_ratio=sharpe_ratio,
                diversification_ratio=diversification_ratio,
                concentration_risk=concentration_risk,
                transaction_costs=transaction_costs,
                rebalancing_frequency=constraints.rebalance_frequency
            )
            
        except Exception as e:
            self.logger.error(f"Sharpe ratio tahsisi hatası: {e}")
            raise
    
    def _apply_constraints(self, allocations: Dict[str, float], constraints: AllocationConstraints) -> Dict[str, float]:
        """Kısıtlamaları uygula"""
        
        # Maksimum ağırlık sınırı
        for strategy_id in allocations:
            allocations[strategy_id] = min(allocations[strategy_id], constraints.max_allocation_per_strategy)
        
        # Normalize et
        total = sum(allocations.values())
        if total > 0:
            for strategy_id in allocations:
                allocations[strategy_id] /= total
        
        return allocations

class MarkowitzOptimization(AllocationStrategy):
    """Markowitz modern portföy teorisi optimizasyonu"""
    
    def __init__(self):
        super().__init__("Markowitz")
        self.logger = logging.getLogger(__name__)
    
    def allocate(
        self,
        strategies: Dict[str, StrategyMetrics],
        constraints: AllocationConstraints,
        target_return: Optional[float] = None,
        risk_tolerance: Optional[float] = None
    ) -> AllocationResult:
        
        try:
            if len(strategies) < 2:
                # 2'den az strateji varsa eşit ağırlık
                equal_alloc = EqualWeightAllocation()
                return equal_alloc.allocate(strategies, constraints, target_return, risk_tolerance)
            
            strategy_list = list(strategies.keys())
            n_strategies = len(strategy_list)
            
            # Getiriler ve riskler
            returns = np.array([strategies[sid].total_return for sid in strategy_list])
            risks = np.array([abs(strategies[sid].max_drawdown) for sid in strategy_list])
            
            # Kovaryans matrisi (basitleştirilmiş)
            correlation_matrix = self._estimate_correlation_matrix(strategies)
            cov_matrix = np.outer(risks, risks) * correlation_matrix
            
            # Amaç fonksiyonu: risk minimizasyonu
            def objective(weights):
                portfolio_risk = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
                return portfolio_risk
            
            # Kısıtlamalar
            constraints_list = [
                {'type': 'eq', 'fun': lambda x: np.sum(x) - 1.0},  # Ağırlıklar toplamı = 1
            ]
            
            # Bounds (kısıtlamalar)
            bounds = []
            for _ in range(n_strategies):
                bounds.append((constraints.min_allocation_per_strategy, constraints.max_allocation_per_strategy))
            
            # Başlangıç değerleri (eşit ağırlık)
            x0 = np.full(n_strategies, 1.0 / n_strategies)
            
            # Optimizasyon
            result = minimize(
                objective,
                x0,
                method='SLSQP',
                bounds=bounds,
                constraints=constraints_list,
                options={'maxiter': 1000}
            )
            
            if result.success:
                optimal_weights = result.x
            else:
                self.logger.warning("Optimizasyon başarısız, eşit ağırlık kullanılıyor")
                optimal_weights = np.full(n_strategies, 1.0 / n_strategies)
            
            # Sonuçları organize et
            allocations = {}
            for i, strategy_id in enumerate(strategy_list):
                allocations[strategy_id] = max(0, optimal_weights[i])  # Negatif değerleri 0'a çevir
            
            # Normalize et
            total_weight = sum(allocations.values())
            if total_weight > 0:
                for strategy_id in allocations:
                    allocations[strategy_id] /= total_weight
            
            # Metrikler hesapla
            expected_return = np.dot(optimal_weights, returns)
            portfolio_risk = np.sqrt(np.dot(optimal_weights.T, np.dot(cov_matrix, optimal_weights)))
            sharpe_ratio = expected_return / portfolio_risk if portfolio_risk > 0 else 0
            
            diversification_ratio = 1 / n_strategies
            concentration_risk = max(optimal_weights)
            transaction_costs = n_strategies * constraints.transaction_cost_rate
            
            return AllocationResult(
                strategy_allocations=allocations,
                total_allocation=sum(allocations.values()),
                expected_return=expected_return,
                expected_risk=portfolio_risk,
                sharpe_ratio=sharpe_ratio,
                diversification_ratio=diversification_ratio,
                concentration_risk=concentration_risk,
                transaction_costs=transaction_costs,
                rebalancing_frequency=constraints.rebalance_frequency
            )
            
        except Exception as e:
            self.logger.error(f"Markowitz optimizasyon hatası: {e}")
            raise
    
    def _estimate_correlation_matrix(self, strategies: Dict[str, StrategyMetrics]) -> np.ndarray:
        """Korelasyon matrisini tahmin et"""
        
        strategy_list = list(strategies.keys())
        n = len(strategy_list)
        
        # Basitleştirilmiş korelasyon tahmini
        # Gerçek uygulamada geçmiş getiri serileri kullanılır
        correlation_matrix = np.eye(n)
        
        for i in range(n):
            for j in range(i + 1, n):
                # Win rate'lere dayalı basit korelasyon
                win_rate_i = strategies[strategy_list[i]].win_rate
                win_rate_j = strategies[strategy_list[j]].win_rate
                
                # Korelasyonu win rate'ler arası benzerlikle tahmin et
                correlation = 1 - abs(win_rate_i - win_rate_j)
                correlation = max(0.1, min(0.9, correlation))  # 0.1-0.9 aralığında sınırla
                
                correlation_matrix[i, j] = correlation
                correlation_matrix[j, i] = correlation
        
        return correlation_matrix

class DynamicAllocation(AllocationStrategy):
    """Dinamik tahsis stratejisi"""
    
    def __init__(self, lookback_window: int = 30, adaptation_rate: float = 0.1):
        super().__init__("Dynamic")
        self.lookback_window = lookback_window
        self.adaptation_rate = adaptation_rate
        self.allocation_history = []
        self.performance_history = {}
    
    def allocate(
        self,
        strategies: Dict[str, StrategyMetrics],
        constraints: AllocationConstraints,
        target_return: Optional[float] = None,
        risk_tolerance: Optional[float] = None
    ) -> AllocationResult:
        
        try:
            # Geçmiş performansları güncelle
            self._update_performance_history(strategies)
            
            # Geçmiş tahsisler
            if self.allocation_history:
                previous_allocation = self.allocation_history[-1]
            else:
                previous_allocation = None
            
            # Adaptif tahsis hesapla
            adaptive_allocation = self._calculate_adaptive_allocation(
                strategies, previous_allocation, target_return, risk_tolerance
            )
            
            # Kısıtlamaları uygula
            constrained_allocation = self._apply_constraints(adaptive_allocation, constraints)
            
            # Tahsis geçmişine ekle
            self.allocation_history.append(constrained_allocation)
            
            # Sonuçları hesapla
            selected_strategies = {k: strategies[k] for k in constrained_allocation.keys() if k in strategies}
            
            returns = [metrics.total_return for metrics in selected_strategies.values()]
            expected_return = np.mean(returns)
            
            risks = [abs(metrics.max_drawdown) for metrics in selected_strategies.values()]
            expected_risk = np.mean(risks)
            
            sharpe_ratio = expected_return / expected_risk if expected_risk > 0 else 0
            diversification_ratio = len(selected_strategies) / len(strategies)
            concentration_risk = max(constrained_allocation.values()) if constrained_allocation else 0
            
            # İşlem maliyetleri (değişim maliyetleri)
            transaction_costs = 0
            if previous_allocation:
                for strategy_id, new_weight in constrained_allocation.items():
                    old_weight = previous_allocation.get(strategy_id, 0)
                    weight_change = abs(new_weight - old_weight)
                    transaction_costs += weight_change * constraints.transaction_cost_rate
            
            return AllocationResult(
                strategy_allocations=constrained_allocation,
                total_allocation=sum(constrained_allocation.values()),
                expected_return=expected_return,
                expected_risk=expected_risk,
                sharpe_ratio=sharpe_ratio,
                diversification_ratio=diversification_ratio,
                concentration_risk=concentration_risk,
                transaction_costs=transaction_costs,
                rebalancing_frequency=constraints.rebalance_frequency
            )
            
        except Exception as e:
            self.logger.error(f"Dinamik tahsis hatası: {e}")
            raise
    
    def _update_performance_history(self, strategies: Dict[str, StrategyMetrics]):
        """Performans geçmişini güncelle"""
        
        current_time = datetime.now()
        
        for strategy_id, metrics in strategies.items():
            if strategy_id not in self.performance_history:
                self.performance_history[strategy_id] = []
            
            self.performance_history[strategy_id].append({
                'timestamp': current_time,
                'return': metrics.total_return,
                'sharpe_ratio': metrics.sharpe_ratio,
                'max_drawdown': metrics.max_drawdown,
                'win_rate': metrics.win_rate
            })
            
            # Geçmiş penceresini sınırla
            if len(self.performance_history[strategy_id]) > self.lookback_window:
                self.performance_history[strategy_id] = self.performance_history[strategy_id][-self.lookback_window:]
    
    def _calculate_adaptive_allocation(
        self,
        strategies: Dict[str, StrategyMetrics],
        previous_allocation: Optional[Dict[str, float]],
        target_return: Optional[float],
        risk_tolerance: Optional[float]
    ) -> Dict[str, float]:
        """Adaptif tahsis hesapla"""
        
        # Performans skorları
        performance_scores = {}
        
        for strategy_id, metrics in strategies.items():
            # Çoklu kriterli skor
            score = (
                0.3 * metrics.sharpe_ratio +
                0.25 * metrics.total_return +
                0.2 * (1 + metrics.max_drawdown) +  # Düşük drawdown daha iyi
                0.15 * metrics.win_rate +
                0.1 * metrics.profit_factor
            )
            performance_scores[strategy_id] = max(0, score)
        
        # Adaptasyon uygula
        if previous_allocation:
            adaptive_scores = {}
            for strategy_id in strategies.keys():
                base_score = performance_scores.get(strategy_id, 0)
                
                # Geçmiş tahsisi koruma faktörü
                momentum_factor = 0.5
                if strategy_id in previous_allocation:
                    momentum_score = previous_allocation[strategy_id] * momentum_factor
                    base_score = base_score * (1 - self.adaptation_rate) + momentum_score * self.adaptation_rate
                
                adaptive_scores[strategy_id] = base_score
        else:
            adaptive_scores = performance_scores
        
        # Tahsisleri normalize et
        total_score = sum(adaptive_scores.values())
        if total_score > 0:
            allocation = {sid: score / total_score for sid, score in adaptive_scores.items()}
        else:
            # Eşit dağıtım
            equal_weight = 1.0 / len(strategies)
            allocation = {sid: equal_weight for sid in strategies.keys()}
        
        return allocation
    
    def _apply_constraints(self, allocations: Dict[str, float], constraints: AllocationConstraints) -> Dict[str, float]:
        """Kısıtlamaları uygula"""
        
        # Maksimum ağırlık sınırı
        for strategy_id in allocations:
            allocations[strategy_id] = min(allocations[strategy_id], constraints.max_allocation_per_strategy)
        
        # En iyi performanslı stratejileri seç
        sorted_strategies = sorted(allocations.items(), key=lambda x: x[1], reverse=True)
        selected_strategies = sorted_strategies[:constraints.max_number_of_strategies]
        
        # Sadece seçilen stratejileri koru
        filtered_allocation = {sid: weight for sid, weight in selected_strategies}
        
        # Normalize et
        total_weight = sum(filtered_allocation.values())
        if total_weight > 0:
            for strategy_id in filtered_allocation:
                filtered_allocation[strategy_id] /= total_weight
        
        return filtered_allocation

class ResourceAllocator:
    """Ana kaynak tahsis yöneticisi"""
    
    def __init__(self, allocation_strategy: str = "sharpe_ratio", config: Dict[str, Any] = None):
        self.config = config or {}
        self.logger = logging.getLogger(__name__)
        
        # Tahsis stratejisini başlat
        if allocation_strategy.lower() == "equal_weight":
            self.strategy = EqualWeightAllocation()
        elif allocation_strategy.lower() == "risk_parity":
            self.strategy = RiskParityAllocation()
        elif allocation_strategy.lower() == "sharpe_ratio":
            self.strategy = SharpeRatioAllocation()
        elif allocation_strategy.lower() == "markowitz":
            self.strategy = MarkowitzOptimization()
        elif allocation_strategy.lower() == "dynamic":
            self.strategy = DynamicAllocation()
        else:
            raise ValueError(f"Desteklenmeyen tahsis stratejisi: {allocation_strategy}")
        
        # Kısıtlamalar
        self.constraints = AllocationConstraints(**self.config.get('constraints', {}))
        
        # Tahsis geçmişi
        self.allocation_history = []
    
    def allocate_resources(
        self,
        strategies: Dict[str, StrategyMetrics],
        target_return: Optional[float] = None,
        risk_tolerance: Optional[float] = None,
        rebalance: bool = False
    ) -> AllocationResult:
        """Kaynak tahsisi"""
        
        try:
            self.logger.info(f"Kaynak tahsisi başlatılıyor: {len(strategies)} strateji, strateji: {self.strategy.name}")
            
            # Tahsis hesapla
            result = self.strategy.allocate(
                strategies, 
                self.constraints, 
                target_return, 
                risk_tolerance
            )
            
            # Geçmişe ekle
            self.allocation_history.append(result)
            
            # Geçmiş boyutunu sınırla
            if len(self.allocation_history) > 100:
                self.allocation_history = self.allocation_history[-100:]
            
            self.logger.info(
                f"Tahsis tamamlandı: {result.strategy_allocations}, "
                f"Beklenen getiri: {result.expected_return:.4f}, "
                f"Beklenen risk: {result.expected_risk:.4f}"
            )
            
            return result
            
        except Exception as e:
            self.logger.error(f"Kaynak tahsisi hatası: {e}")
            raise
    
    def rebalance_portfolio(
        self,
        current_allocation: Dict[str, float],
        target_allocation: Dict[str, float],
        rebalancing_threshold: float = 0.05
    ) -> Dict[str, Any]:
        """Portföy yeniden dengelemesi"""
        
        rebalancing_actions = []
        total_rebalancing_cost = 0
        
        for strategy_id in target_allocation.keys():
            current_weight = current_allocation.get(strategy_id, 0)
            target_weight = target_allocation[strategy_id]
            
            weight_diff = target_weight - current_weight
            
            if abs(weight_diff) > rebalancing_threshold:
                rebalancing_actions.append({
                    'strategy_id': strategy_id,
                    'current_weight': current_weight,
                    'target_weight': target_weight,
                    'weight_change': weight_diff,
                    'action': 'buy' if weight_diff > 0 else 'sell',
                    'confidence': min(1.0, abs(weight_diff) / rebalancing_threshold)
                })
                
                # İşlem maliyeti
                transaction_cost = abs(weight_diff) * self.constraints.transaction_cost_rate
                total_rebalancing_cost += transaction_cost
        
        return {
            'rebalancing_required': len(rebalancing_actions) > 0,
            'actions': rebalancing_actions,
            'total_actions': len(rebalancing_actions),
            'estimated_cost': total_rebalancing_cost,
            'rebalancing_threshold': rebalancing_threshold
        }
    
    def analyze_allocation_risk(self, allocation_result: AllocationResult) -> RiskMetrics:
        """Tahsis riski analizi"""
        
        allocations = allocation_result.strategy_allocations
        if not allocations:
            return RiskMetrics(0, 0, 0, 0, 0, 0, 0)
        
        # Volatilite (ağırlıklı ortalama)
        volatility = allocation_result.expected_risk
        
        # VaR (basitleştirilmiş)
        var_95 = np.percentile(list(allocations.values()), 5) if len(allocations) > 1 else 0
        
        # Expected Shortfall
        tail_allocations = [w for w in allocations.values() if w <= var_95]
        expected_shortfall = np.mean(tail_allocations) if tail_allocations else 0
        
        # Maksimum Drawdown
        max_drawdown = allocation_result.expected_risk
        
        # Korelasyon riski (ağırlıklarına dayalı)
        concentration_risk = allocation_result.concentration_risk
        
        # Konsantrasyon riski
        hhi = sum(w**2 for w in allocations.values())  # Herfindahl-Hirschman Index
        diversification_benefit = 1 - hhi
        
        # Tail risk (beta dağılımı ile basitleştirilmiş)
        tail_risk = max(0, allocation_result.expected_risk - np.mean(list(allocations.values())))
        
        return RiskMetrics(
            volatility=volatility,
            var_95=var_95,
            expected_shortfall=expected_shortfall,
            maximum_drawdown=max_drawdown,
            correlation_risk=concentration_risk,
            concentration_risk=hhi,
            tail_risk=tail_risk
        )
    
    def get_allocation_performance_report(self, days: int = 30) -> Dict[str, Any]:
        """Tahsis performans raporu"""
        
        if not self.allocation_history:
            return {'error': 'Tahsis geçmişi bulunamadı'}
        
        # Son N günün verilerini filtrele
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_allocations = [
            allocation for allocation in self.allocation_history
            if allocation.timestamp >= cutoff_date
        ]
        
        if not recent_allocations:
            return {'error': 'Belirtilen dönemde tahsis verisi bulunamadı'}
        
        # Performans metrikleri
        returns = [allocation.expected_return for allocation in recent_allocations]
        risks = [allocation.expected_risk for allocation in recent_allocations]
        sharpe_ratios = [allocation.sharpe_ratio for allocation in recent_allocations]
        
        # Trend analizi
        if len(returns) > 1:
            return_trend = "improving" if returns[-1] > returns[0] else "declining"
            risk_trend = "increasing" if risks[-1] > risks[0] else "decreasing"
        else:
            return_trend = risk_trend = "stable"
        
        # En iyi ve en kötü tahsisler
        best_allocation = max(recent_allocations, key=lambda x: x.sharpe_ratio)
        worst_allocation = min(recent_allocations, key=lambda x: x.sharpe_ratio)
        
        return {
            'period_days': days,
            'total_rebalancing_actions': len(recent_allocations),
            'performance_summary': {
                'avg_return': np.mean(returns),
                'avg_risk': np.mean(risks),
                'avg_sharpe_ratio': np.mean(sharpe_ratios),
                'return_volatility': np.std(returns),
                'risk_volatility': np.std(risks)
            },
            'trends': {
                'return_trend': return_trend,
                'risk_trend': risk_trend,
                'return_change': returns[-1] - returns[0] if len(returns) > 1 else 0,
                'risk_change': risks[-1] - risks[0] if len(risks) > 1 else 0
            },
            'extremes': {
                'best_sharpe_ratio': best_allocation.sharpe_ratio,
                'worst_sharpe_ratio': worst_allocation.sharpe_ratio,
                'best_return': best_allocation.expected_return,
                'worst_return': worst_allocation.expected_return
            },
            'strategy_concentration': self._analyze_strategy_concentration(recent_allocations),
            'rebalancing_frequency': self._calculate_rebalancing_frequency(recent_allocations)
        }
    
    def _analyze_strategy_concentration(self, allocations: List[AllocationResult]) -> Dict[str, float]:
        """Strateji konsantrasyon analizi"""
        
        # Son tahsisleri analiz et
        latest_allocation = allocations[-1] if allocations else None
        if not latest_allocation:
            return {}
        
        allocations_dict = latest_allocation.strategy_allocations
        if not allocations_dict:
            return {}
        
        # Herfindahl-Hirschman Index
        hhi = sum(w**2 for w in allocations_dict.values())
        
        # Effective number of strategies
        effective_strategies = 1 / hhi if hhi > 0 else 0
        
        # Top 3 stratejinin payı
        top_strategies = sorted(allocations_dict.items(), key=lambda x: x[1], reverse=True)[:3]
        top_3_concentration = sum(weight for _, weight in top_strategies)
        
        return {
            'hhi': hhi,
            'effective_number_strategies': effective_strategies,
            'top_3_concentration': top_3_concentration,
            'max_single_allocation': max(allocations_dict.values()),
            'num_strategies': len(allocations_dict)
        }
    
    def _calculate_rebalancing_frequency(self, allocations: List[AllocationResult]) -> float:
        """Yeniden dengeleme sıklığı hesapla"""
        
        if len(allocations) < 2:
            return 0.0
        
        # Tahsis değişikliklerini say
        changes = 0
        for i in range(1, len(allocations)):
            current = allocations[i].strategy_allocations
            previous = allocations[i-1].strategy_allocations
            
            # Her strateji için değişim kontrolü
            for strategy_id in current.keys():
                current_weight = current[strategy_id]
                previous_weight = previous.get(strategy_id, 0)
                
                if abs(current_weight - previous_weight) > 0.01:  # %1'den fazla değişim
                    changes += 1
                    break  # Sadece bir strateji değişikliği say
        
        # Günlük ortalama değişiklik sayısı
        period_days = (allocations[-1].timestamp - allocations[0].timestamp).days
        if period_days > 0:
            return changes / period_days
        else:
            return 0.0