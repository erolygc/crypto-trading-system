"""
Validation Modülü
================
Cross-validation ve Walk-Forward optimizasyon teknikleri.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging
from abc import ABC, abstractmethod
from sklearn.model_selection import TimeSeriesSplit
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

from .core import StrategyConfig, StrategyMetrics, PerformanceEvaluator

@dataclass
class ValidationResult:
    """Doğrulama sonucu"""
    strategy_id: str
    validation_method: str
    out_of_sample_score: float
    in_sample_score: float
    stability_score: float
    overfitting_indicator: float
    confidence_interval: Tuple[float, float]
    cross_validation_scores: List[float]
    walk_forward_scores: List[float]
    validation_period: str
    timestamp: datetime = field(default_factory=datetime.now)

@dataclass
class CrossValidationConfig:
    """Cross-validation konfigürasyonu"""
    n_splits: int = 5
    test_size: float = 0.2
    method: str = "time_series"  # time_series, expanding, rolling
    min_train_size: int = 252  # Minimum eğitim veri boyutu
    max_train_size: Optional[int] = None
    shuffle: bool = False

@dataclass
class WalkForwardConfig:
    """Walk-forward optimizasyon konfigürasyonu"""
    rebalancing_frequency: str = "monthly"  # daily, weekly, monthly, quarterly
    lookback_window: int = 252  # Geçmişte bakılacak pencere boyutu
    forward_window: int = 21  # İleri test penceresi boyutu
    step_size: int = 21  # Pencere kaydırma adımı
    min_lookback: int = 126  # Minimum bakış penceresi

class ValidationStrategy(ABC):
    """Doğrulama stratejisi temel sınıfı"""
    
    def __init__(self, name: str):
        self.name = name
        self.logger = logging.getLogger(__name__)
    
    @abstractmethod
    def validate(
        self,
        strategy_config: StrategyConfig,
        market_data: pd.DataFrame,
        evaluation_function: Callable
    ) -> ValidationResult:
        """Doğrulama işlemini gerçekleştir"""
        pass

class CrossValidator(ValidationStrategy):
    """Cross-validation doğrulayıcısı"""
    
    def __init__(self, config: CrossValidationConfig = None):
        super().__init__("CrossValidation")
        self.config = config or CrossValidationConfig()
        self.evaluator = PerformanceEvaluator()
    
    def validate(
        self,
        strategy_config: StrategyConfig,
        market_data: pd.DataFrame,
        evaluation_function: Callable
    ) -> ValidationResult:
        """Cross-validation doğrulaması"""
        
        try:
            self.logger.info(f"Cross-validation başlatılıyor: {strategy_config.strategy_id}")
            
            # Veri bölünmesi
            train_data, test_data = self._split_data(market_data)
            
            # Cross-validation skorları
            cv_scores = self._cross_validate(strategy_config, train_data, evaluation_function)
            
            # Out-of-sample test
            oos_score = self._out_of_sample_test(strategy_config, train_data, test_data, evaluation_function)
            
            # In-sample (train) skoru
            in_sample_score = self._in_sample_test(strategy_config, train_data, evaluation_function)
            
            # İstatistikler
            stability_score = self._calculate_stability(cv_scores)
            overfitting_indicator = self._calculate_overfitting(in_sample_score, cv_scores)
            confidence_interval = self._calculate_confidence_interval(cv_scores)
            
            return ValidationResult(
                strategy_id=strategy_config.strategy_id,
                validation_method=self.config.method,
                out_of_sample_score=oos_score,
                in_sample_score=in_sample_score,
                stability_score=stability_score,
                overfitting_indicator=overfitting_indicator,
                confidence_interval=confidence_interval,
                cross_validation_scores=cv_scores,
                walk_forward_scores=[],  # Cross-validation için boş
                validation_period=f"{len(train_data)}/{len(test_data)}"
            )
            
        except Exception as e:
            self.logger.error(f"Cross-validation hatası: {e}")
            raise
    
    def _split_data(self, market_data: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Veri bölünmesi"""
        
        split_idx = int(len(market_data) * (1 - self.config.test_size))
        train_data = market_data.iloc[:split_idx].copy()
        test_data = market_data.iloc[split_idx:].copy()
        
        self.logger.debug(f"Veri bölünmesi: Train={len(train_data)}, Test={len(test_data)}")
        
        return train_data, test_data
    
    def _cross_validate(
        self,
        strategy_config: StrategyConfig,
        train_data: pd.DataFrame,
        evaluation_function: Callable
    ) -> List[float]:
        """Cross-validation skoru hesaplama"""
        
        if self.config.method == "time_series":
            return self._time_series_cv(strategy_config, train_data, evaluation_function)
        elif self.config.method == "expanding":
            return self._expanding_window_cv(strategy_config, train_data, evaluation_function)
        elif self.config.method == "rolling":
            return self._rolling_window_cv(strategy_config, train_data, evaluation_function)
        else:
            raise ValueError(f"Desteklenmeyen CV methodu: {self.config.method}")
    
    def _time_series_cv(
        self,
        strategy_config: StrategyConfig,
        train_data: pd.DataFrame,
        evaluation_function: Callable
    ) -> List[float]:
        """Time series cross-validation"""
        
        scores = []
        
        # TimeSeriesSplit kullan
        tscv = TimeSeriesSplit(
            n_splits=self.config.n_splits,
            max_train_size=self.config.max_train_size,
            test_size=max(1, len(train_data) // (self.config.n_splits + 1))
        )
        
        for train_idx, val_idx in tscv.split(train_data):
            # Eğitim ve validasyon setleri
            cv_train = train_data.iloc[train_idx]
            cv_val = train_data.iloc[val_idx]
            
            # Model eğitimi ve değerlendirme
            try:
                score = evaluation_function(strategy_config, cv_train, cv_val)
                scores.append(score)
            except Exception as e:
                self.logger.warning(f"CV fold hatası: {e}")
                scores.append(0.0)
        
        self.logger.debug(f"Time series CV skorları: {scores}")
        return scores
    
    def _expanding_window_cv(
        self,
        strategy_config: StrategyConfig,
        train_data: pd.DataFrame,
        evaluation_function: Callable
    ) -> List[float]:
        """Expanding window cross-validation"""
        
        scores = []
        min_train = self.config.min_train_size
        step_size = len(train_data) // (self.config.n_splits + 1)
        
        for i in range(self.config.n_splits):
            train_end = min_train + i * step_size
            val_end = train_end + step_size
            
            if val_end > len(train_data):
                break
            
            cv_train = train_data.iloc[:train_end]
            cv_val = train_data.iloc[train_end:val_end]
            
            try:
                score = evaluation_function(strategy_config, cv_train, cv_val)
                scores.append(score)
            except Exception as e:
                self.logger.warning(f"Expanding window CV fold hatası: {e}")
                scores.append(0.0)
        
        return scores
    
    def _rolling_window_cv(
        self,
        strategy_config: StrategyConfig,
        train_data: pd.DataFrame,
        evaluation_function: Callable
    ) -> List[float]:
        """Rolling window cross-validation"""
        
        scores = []
        train_size = min(self.config.max_train_size or len(train_data) // 2, len(train_data) // 2)
        step_size = len(train_data) // (self.config.n_splits + 1)
        
        for i in range(self.config.n_splits):
            start = i * step_size
            train_end = start + train_size
            val_start = train_end
            val_end = val_start + step_size
            
            if val_end > len(train_data):
                break
            
            cv_train = train_data.iloc[start:train_end]
            cv_val = train_data.iloc[val_start:val_end]
            
            try:
                score = evaluation_function(strategy_config, cv_train, cv_val)
                scores.append(score)
            except Exception as e:
                self.logger.warning(f"Rolling window CV fold hatası: {e}")
                scores.append(0.0)
        
        return scores
    
    def _out_of_sample_test(
        self,
        strategy_config: StrategyConfig,
        train_data: pd.DataFrame,
        test_data: pd.DataFrame,
        evaluation_function: Callable
    ) -> float:
        """Out-of-sample test"""
        
        try:
            score = evaluation_function(strategy_config, train_data, test_data)
            self.logger.debug(f"Out-of-sample skor: {score}")
            return score
        except Exception as e:
            self.logger.error(f"Out-of-sample test hatası: {e}")
            return 0.0
    
    def _in_sample_test(
        self,
        strategy_config: StrategyConfig,
        train_data: pd.DataFrame,
        evaluation_function: Callable
    ) -> float:
        """In-sample test"""
        
        try:
            # Basit in-sample değerlendirme (aynı veri üzerinde)
            score = evaluation_function(strategy_config, train_data, train_data)
            self.logger.debug(f"In-sample skor: {score}")
            return score
        except Exception as e:
            self.logger.error(f"In-sample test hatası: {e}")
            return 0.0
    
    def _calculate_stability(self, scores: List[float]) -> float:
        """Stabilite skoru hesaplama"""
        
        if not scores or len(scores) < 2:
            return 0.0
        
        # Coefficient of variation tersi
        mean_score = np.mean(scores)
        std_score = np.std(scores)
        
        if mean_score <= 0:
            return 0.0
        
        stability = 1 / (1 + std_score / abs(mean_score))
        return max(0, min(1, stability))
    
    def _calculate_overfitting(self, in_sample_score: float, cv_scores: List[float]) -> float:
        """Overfitting göstergesi"""
        
        if not cv_scores:
            return 0.0
        
        # In-sample vs out-of-sample farkı
        cv_mean = np.mean(cv_scores)
        overfitting = (in_sample_score - cv_mean) / abs(cv_mean) if cv_mean != 0 else 0
        
        # 0-1 aralığına normalize et
        overfitting_normalized = max(0, min(1, overfitting))
        return overfitting_normalized
    
    def _calculate_confidence_interval(self, scores: List[float]) -> Tuple[float, float]:
        """Güven aralığı hesaplama"""
        
        if not scores:
            return (0.0, 0.0)
        
        mean_score = np.mean(scores)
        std_score = stats.sem(scores)  # Standard error of mean
        
        # 95% güven aralığı
        confidence_interval = stats.t.interval(
            0.95, 
            len(scores) - 1, 
            loc=mean_score, 
            scale=std_score
        )
        
        return confidence_interval

class WalkForwardValidator(ValidationStrategy):
    """Walk-forward optimizasyon doğrulayıcısı"""
    
    def __init__(self, config: WalkForwardConfig = None):
        super().__init__("WalkForward")
        self.config = config or WalkForwardConfig()
        self.evaluator = PerformanceEvaluator()
    
    def validate(
        self,
        strategy_config: StrategyConfig,
        market_data: pd.DataFrame,
        evaluation_function: Callable
    ) -> ValidationResult:
        """Walk-forward doğrulaması"""
        
        try:
            self.logger.info(f"Walk-forward başlatılıyor: {strategy_config.strategy_id}")
            
            # Walk-forward analizi
            forward_scores = self._walk_forward_analysis(strategy_config, market_data, evaluation_function)
            
            # İstatistikler
            if forward_scores:
                out_of_sample_score = np.mean(forward_scores)
                in_sample_score = np.mean(forward_scores)  # Walk-forward için benzer
                stability_score = self._calculate_stability(forward_scores)
                overfitting_indicator = 0.1  # Walk-forward için düşük overfitting beklenir
                confidence_interval = self._calculate_confidence_interval(forward_scores)
            else:
                out_of_sample_score = in_sample_score = stability_score = overfitting_indicator = 0.0
                confidence_interval = (0.0, 0.0)
            
            return ValidationResult(
                strategy_id=strategy_config.strategy_id,
                validation_method="walk_forward",
                out_of_sample_score=out_of_sample_score,
                in_sample_score=in_sample_score,
                stability_score=stability_score,
                overfitting_indicator=overfitting_indicator,
                confidence_interval=confidence_interval,
                cross_validation_scores=[],  # Walk-forward için boş
                walk_forward_scores=forward_scores,
                validation_period=f"{len(market_data)} days"
            )
            
        except Exception as e:
            self.logger.error(f"Walk-forward hatası: {e}")
            raise
    
    def _walk_forward_analysis(
        self,
        strategy_config: StrategyConfig,
        market_data: pd.DataFrame,
        evaluation_function: Callable
    ) -> List[float]:
        """Walk-forward analizi"""
        
        scores = []
        
        # Pencere boyutları
        lookback = self.config.lookback_window
        forward = self.config.forward_window
        step = self.config.step_size
        
        # İlk pencere
        start_idx = lookback
        
        # Son pencereye kadar devam et
        while start_idx + forward <= len(market_data):
            # Eğitim penceresi (geçmiş)
            train_data = market_data.iloc[start_idx - lookback:start_idx]
            
            # Test penceresi (gelecek)
            test_data = market_data.iloc[start_idx:start_idx + forward]
            
            # Model eğitimi ve test
            try:
                score = evaluation_function(strategy_config, train_data, test_data)
                scores.append(score)
                
                self.logger.debug(f"WF window {len(scores)}: score={score:.4f}")
                
            except Exception as e:
                self.logger.warning(f"Walk-forward window hatası: {e}")
                scores.append(0.0)
            
            # Sonraki pencere
            start_idx += step
        
        self.logger.info(f"Walk-forward tamamlandı: {len(scores)} windows")
        return scores
    
    def _calculate_stability(self, scores: List[float]) -> float:
        """Stabilite skoru hesaplama"""
        
        if not scores or len(scores) < 2:
            return 0.0
        
        # Trend analizi
        x = np.arange(len(scores))
        slope, _, r_value, p_value, _ = stats.linregress(x, scores)
        
        # Stabilite = yüksek R² + düşük volatility
        r_squared = r_value ** 2
        volatility = np.std(scores)
        
        # Normalize edilmiş stabilite skoru
        stability = r_squared / (1 + volatility)
        return max(0, min(1, stability))
    
    def _calculate_confidence_interval(self, scores: List[float]) -> Tuple[float, float]:
        """Güven aralığı hesaplama"""
        
        if not scores:
            return (0.0, 0.0)
        
        mean_score = np.mean(scores)
        std_score = stats.sem(scores)
        
        confidence_interval = stats.t.interval(
            0.95,
            len(scores) - 1,
            loc=mean_score,
            scale=std_score
        )
        
        return confidence_interval

class RegimeAwareValidator(ValidationStrategy):
    """Rejim farkında doğrulayıcı"""
    
    def __init__(self, regime_classifier: Callable, base_validator: ValidationStrategy):
        super().__init__("RegimeAware")
        self.regime_classifier = regime_classifier
        self.base_validator = base_validator
        self.logger = logging.getLogger(__name__)
    
    def validate(
        self,
        strategy_config: StrategyConfig,
        market_data: pd.DataFrame,
        evaluation_function: Callable
    ) -> ValidationResult:
        """Rejim farkında doğrulama"""
        
        try:
            self.logger.info(f"Regime-aware validation başlatılıyor: {strategy_config.strategy_id}")
            
            # Veriyi rejimlere böl
            regime_data = self._segment_by_regimes(market_data)
            
            # Her rejim için doğrulama
            regime_scores = {}
            regime_results = {}
            
            for regime_name, regime_periods in regime_data.items():
                if len(regime_periods) < self.config.min_train_size:
                    self.logger.warning(f"Yetersiz veri regime için: {regime_name}")
                    continue
                
                # Bu rejim için veri birleştir
                combined_data = pd.concat(regime_periods, ignore_index=True)
                
                if len(combined_data) >= self.config.min_train_size:
                    try:
                        result = self.base_validator.validate(strategy_config, combined_data, evaluation_function)
                        regime_results[regime_name] = result
                        regime_scores[regime_name] = result.out_of_sample_score
                    except Exception as e:
                        self.logger.warning(f"Regime validation hatası ({regime_name}): {e}")
            
            # Genel skor hesaplama (ağırlıklı ortalama)
            if regime_scores:
                weights = [len(periods) for periods in regime_data.values()]
                scores = list(regime_scores.values())
                weighted_score = np.average(scores, weights=weights)
                
                # En iyi performans gösteren rejim
                best_regime = max(regime_scores.keys(), key=lambda x: regime_scores[x])
                worst_regime = min(regime_scores.keys(), key=lambda x: regime_scores[x])
                
                # Rejim tutarlılığı
                regime_consistency = 1 - (np.std(scores) / np.mean(scores)) if np.mean(scores) > 0 else 0
            else:
                weighted_score = 0.0
                best_regime = worst_regime = None
                regime_consistency = 0.0
            
            return ValidationResult(
                strategy_id=strategy_config.strategy_id,
                validation_method="regime_aware",
                out_of_sample_score=weighted_score,
                in_sample_score=weighted_score,
                stability_score=regime_consistency,
                overfitting_indicator=0.1,  # Rejim-aware için düşük overfitting
                confidence_interval=(weighted_score, weighted_score),
                cross_validation_scores=[],
                walk_forward_scores=[],
                validation_period=f"{len(market_data)} days, {len(regime_scores)} regimes"
            )
            
        except Exception as e:
            self.logger.error(f"Regime-aware validation hatası: {e}")
            raise
    
    def _segment_by_regimes(self, market_data: pd.DataFrame) -> Dict[str, List[pd.DataFrame]]:
        """Veriyi rejimlere böl"""
        
        regimes = {}
        current_regime = None
        current_period = []
        
        # Her gün için rejim sınıflandırması
        for idx, row in market_data.iterrows():
            try:
                daily_regime = self.regime_classifier(market_data.loc[:idx])
            except Exception:
                daily_regime = "unknown"
            
            # Rejim değişimi
            if current_regime != daily_regime:
                # Önceki rejim periyodunu kaydet
                if current_regime and current_period:
                    if current_regime not in regimes:
                        regimes[current_regime] = []
                    regimes[current_regime].append(pd.concat(current_period, ignore_index=True))
                
                # Yeni rejim başlat
                current_regime = daily_regime
                current_period = [market_data.loc[[idx]]]
            else:
                # Aynı rejimde devam et
                current_period.append(market_data.loc[[idx]])
        
        # Son rejim periyodunu kaydet
        if current_regime and current_period:
            if current_regime not in regimes:
                regimes[current_regime] = []
            regimes[current_regime].append(pd.concat(current_period, ignore_index=True))
        
        return regimes

class EnsembleValidator(ValidationStrategy):
    """Ensemble doğrulayıcı"""
    
    def __init__(self, validators: List[ValidationStrategy]):
        super().__init__("Ensemble")
        self.validators = validators
        self.logger = logging.getLogger(__name__)
    
    def validate(
        self,
        strategy_config: StrategyConfig,
        market_data: pd.DataFrame,
        evaluation_function: Callable
    ) -> ValidationResult:
        """Ensemble doğrulama"""
        
        try:
            self.logger.info(f"Ensemble validation başlatılıyor: {strategy_config.strategy_id}")
            
            # Her doğrulayıcıyı çalıştır
            individual_results = []
            
            for validator in self.validators:
                try:
                    result = validator.validate(strategy_config, market_data, evaluation_function)
                    individual_results.append(result)
                    self.logger.debug(f"{validator.name} sonucu: {result.out_of_sample_score:.4f}")
                except Exception as e:
                    self.logger.warning(f"Validator hatası ({validator.name}): {e}")
            
            if not individual_results:
                raise ValueError("Hiçbir validator başarılı olmadı")
            
            # Ensemble sonucu hesapla
            ensemble_score = np.mean([r.out_of_sample_score for r in individual_results])
            ensemble_stability = np.mean([r.stability_score for r in individual_results])
            ensemble_overfitting = np.mean([r.overfitting_indicator for r in individual_results])
            
            # Güven aralığı (validatorlar arası varyans)
            scores = [r.out_of_sample_score for r in individual_results]
            confidence_interval = (np.mean(scores) - np.std(scores), np.mean(scores) + np.std(scores))
            
            return ValidationResult(
                strategy_id=strategy_config.strategy_id,
                validation_method="ensemble",
                out_of_sample_score=ensemble_score,
                in_sample_score=ensemble_score,
                stability_score=ensemble_stability,
                overfitting_indicator=ensemble_overfitting,
                confidence_interval=confidence_interval,
                cross_validation_scores=[],  # Ensemble için özet
                walk_forward_scores=[],
                validation_period=f"{len(market_data)} days, {len(validators)} validators"
            )
            
        except Exception as e:
            self.logger.error(f"Ensemble validation hatası: {e}")
            raise

class ValidationManager:
    """Doğrulama yöneticisi"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.validation_history = []
        self.active_validators = {}
    
    def add_validator(self, name: str, validator: ValidationStrategy):
        """Doğrulayıcı ekle"""
        
        self.active_validators[name] = validator
        self.logger.info(f"Doğrulayıcı eklendi: {name}")
    
    def validate_strategy(
        self,
        strategy_config: StrategyConfig,
        market_data: pd.DataFrame,
        evaluation_function: Callable,
        validator_names: Optional[List[str]] = None
    ) -> Dict[str, ValidationResult]:
        """Strateji doğrulaması"""
        
        if validator_names is None:
            validator_names = list(self.active_validators.keys())
        
        results = {}
        
        for validator_name in validator_names:
            if validator_name not in self.active_validators:
                self.logger.warning(f"Bilinmeyen validator: {validator_name}")
                continue
            
            validator = self.active_validators[validator_name]
            
            try:
                result = validator.validate(strategy_config, market_data, evaluation_function)
                results[validator_name] = result
                
                self.logger.info(f"Validation tamamlandı ({validator_name}): score={result.out_of_sample_score:.4f}")
                
            except Exception as e:
                self.logger.error(f"Validation hatası ({validator_name}): {e}")
        
        # Sonuçları kaydet
        self.validation_history.append({
            'timestamp': datetime.now(),
            'strategy_id': strategy_config.strategy_id,
            'results': results
        })
        
        return results
    
    def compare_strategies(
        self,
        strategies: List[StrategyConfig],
        market_data: pd.DataFrame,
        evaluation_function: Callable,
        validator_names: Optional[List[str]] = None
    ) -> pd.DataFrame:
        """Stratejileri karşılaştır"""
        
        comparison_results = []
        
        for strategy in strategies:
            results = self.validate_strategy(strategy, market_data, evaluation_function, validator_names)
            
            # En iyi validator skorunu al
            best_score = 0
            best_validator = None
            avg_stability = 0
            
            for validator_name, result in results.items():
                if result.out_of_sample_score > best_score:
                    best_score = result.out_of_sample_score
                    best_validator = validator_name
                
                avg_stability += result.stability_score
            
            if results:
                avg_stability /= len(results)
            
            comparison_results.append({
                'strategy_id': strategy.strategy_id,
                'best_score': best_score,
                'best_validator': best_validator,
                'avg_stability': avg_stability,
                'n_validators': len(results)
            })
        
        # DataFrame'e çevir
        comparison_df = pd.DataFrame(comparison_results)
        comparison_df = comparison_df.sort_values('best_score', ascending=False)
        
        return comparison_df
    
    def get_validation_report(self, strategy_id: str) -> Dict[str, Any]:
        """Doğrulama raporu"""
        
        # Stratejinin tüm doğrulama sonuçları
        strategy_validations = [
            record for record in self.validation_history
            if record['strategy_id'] == strategy_id
        ]
        
        if not strategy_validations:
            return {'error': f'Strateji için doğrulama bulunamadı: {strategy_id}'}
        
        # En son sonuç
        latest_validation = strategy_validations[-1]
        
        # İstatistikler
        all_scores = []
        for validation in strategy_validations:
            for result in validation['results'].values():
                all_scores.append(result.out_of_sample_score)
        
        report = {
            'strategy_id': strategy_id,
            'total_validations': len(strategy_validations),
            'latest_validation': latest_validation['timestamp'],
            'score_statistics': {
                'mean': np.mean(all_scores),
                'std': np.std(all_scores),
                'min': np.min(all_scores),
                'max': np.max(all_scores),
                'latest': all_scores[-1] if all_scores else 0
            },
            'validator_performance': {},
            'validation_trend': self._calculate_validation_trend(strategy_validations)
        }
        
        # Validator performansı
        for validator_name in self.active_validators.keys():
            validator_scores = []
            for validation in strategy_validations:
                if validator_name in validation['results']:
                    validator_scores.append(validation['results'][validator_name].out_of_sample_score)
            
            if validator_scores:
                report['validator_performance'][validator_name] = {
                    'mean_score': np.mean(validator_scores),
                    'n_evaluations': len(validator_scores),
                    'consistency': 1 - (np.std(validator_scores) / np.mean(validator_scores)) if np.mean(validator_scores) > 0 else 0
                }
        
        return report
    
    def _calculate_validation_trend(self, validations: List[Dict[str, Any]]) -> str:
        """Doğrulama trendi"""
        
        if len(validations) < 3:
            return "insufficient_data"
        
        # Son 3 doğrulamanın skorları
        recent_scores = []
        for validation in validations[-3:]:
            if validation['results']:
                avg_score = np.mean([r.out_of_sample_score for r in validation['results'].values()])
                recent_scores.append(avg_score)
        
        if len(recent_scores) < 3:
            return "insufficient_data"
        
        # Trend analizi
        if recent_scores[0] < recent_scores[1] < recent_scores[2]:
            return "improving"
        elif recent_scores[0] > recent_scores[1] > recent_scores[2]:
            return "declining"
        else:
            return "stable"