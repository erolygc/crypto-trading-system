"""
Optimization Modülü
==================
Bayesian ve genetik algoritma tabanlı strateji optimizasyonu.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime
import logging
from abc import ABC, abstractmethod
from scipy.optimize import minimize
from scipy.stats import norm
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import Matern, ConstantKernel
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

from .core import StrategyConfig, StrategyMetrics

@dataclass
class OptimizationResult:
    """Optimizasyon sonucu"""
    best_params: Dict[str, Any]
    best_score: float
    optimization_history: List[Dict[str, Any]]
    convergence_achieved: bool
    n_evaluations: int
    execution_time: float
    timestamp: datetime = field(default_factory=datetime.now)

@dataclass
class ParameterBounds:
    """Parametre sınırları"""
    name: str
    min_value: float
    max_value: float
    parameter_type: str  # 'continuous', 'discrete', 'categorical'
    categories: Optional[List[Any]] = None

class BayesianOptimizer:
    """Gaussian Process tabanlı Bayesian optimizasyon"""
    
    def __init__(self, acquisition_function: str = "ei", n_initial_points: int = 5):
        self.acquisition_function = acquisition_function
        self.n_initial_points = n_initial_points
        self.logger = logging.getLogger(__name__)
        
        # Gaussian Process modeli
        self.gp_model = None
        self.X_observed = []
        self.y_observed = []
        
        # Acquisition function
        self.acquisition_funcs = {
            'ei': self._expected_improvement,
            'pi': self._probability_of_improvement,
            'ucb': self._upper_confidence_bound
        }
        
        # Hyperparameters
        self.kappa = 2.576  # UCB için confidence level
        self.xi = 0.01      # EI için exploration parameter
    
    def optimize(
        self,
        objective_function: Callable,
        parameter_bounds: List[ParameterBounds],
        n_calls: int = 100,
        n_initial_points: Optional[int] = None,
        random_state: int = 42
    ) -> OptimizationResult:
        """Bayesian optimizasyon çalıştır"""
        
        start_time = datetime.now()
        n_initial_points = n_initial_points or self.n_initial_points
        
        try:
            self.logger.info(f"Bayesian optimizasyon başlıyor: {n_calls} değerlendirme")
            
            # Başlangıç noktalarını oluştur
            X_init = self._generate_initial_points(parameter_bounds, n_initial_points, random_state)
            
            # İlk değerlendirmeler
            self.X_observed = []
            self.y_observed = []
            
            for x in X_init:
                try:
                    score = objective_function(self._decode_parameters(x, parameter_bounds))
                    self.X_observed.append(x)
                    self.y_observed.append(score)
                except Exception as e:
                    self.logger.error(f"İlk değerlendirme hatası: {e}")
                    self.y_observed.append(-np.inf)
            
            # GP modelini eğit
            self._train_gp_model()
            
            # Ana optimizasyon döngüsü
            optimization_history = []
            
            for i in range(n_calls - n_initial_points):
                # Sonraki noktayı seç
                x_next = self._select_next_point(parameter_bounds)
                
                # Değerlendir
                y_next = objective_function(self._decode_parameters(x_next, parameter_bounds))
                
                # Verileri güncelle
                self.X_observed.append(x_next)
                self.y_observed.append(y_next)
                
                # GP'yi güncelle
                self._train_gp_model()
                
                # Geçmişi kaydet
                optimization_history.append({
                    'iteration': i + 1,
                    'parameters': self._decode_parameters(x_next, parameter_bounds),
                    'score': y_next,
                    'best_score': max(self.y_observed)
                })
                
                self.logger.debug(f"İterasyon {i+1}: score={y_next:.6f}, best={max(self.y_observed):.6f}")
                
                # Yakınsama kontrolü
                if self._check_convergence(i, optimization_history):
                    self.logger.info("Bayesian optimizasyon yakınsama sağladı")
                    break
            
            # En iyi sonucu bul
            best_idx = np.argmax(self.y_observed)
            best_params = self._decode_parameters(self.X_observed[best_idx], parameter_bounds)
            best_score = self.y_observed[best_idx]
            
            execution_time = (datetime.now() - start_time).total_seconds()
            
            return OptimizationResult(
                best_params=best_params,
                best_score=best_score,
                optimization_history=optimization_history,
                convergence_achieved=self._check_convergence(len(optimization_history), optimization_history),
                n_evaluations=len(self.X_observed),
                execution_time=execution_time
            )
            
        except Exception as e:
            self.logger.error(f"Bayesian optimizasyon hatası: {e}")
            raise
    
    def _generate_initial_points(
        self, 
        parameter_bounds: List[ParameterBounds], 
        n_points: int, 
        random_state: int
    ) -> List[np.ndarray]:
        """Başlangıç noktalarını oluştur"""
        
        np.random.seed(random_state)
        initial_points = []
        
        for _ in range(n_points):
            point = []
            for bound in parameter_bounds:
                if bound.parameter_type == 'continuous':
                    point.append(np.random.uniform(bound.min_value, bound.max_value))
                elif bound.parameter_type == 'discrete':
                    n_values = int(bound.max_value - bound.min_value + 1)
                    discrete_values = np.linspace(bound.min_value, bound.max_value, n_values)
                    point.append(np.random.choice(discrete_values))
                elif bound.parameter_type == 'categorical':
                    point.append(np.random.choice(range(len(bound.categories))))
            
            initial_points.append(np.array(point))
        
        return initial_points
    
    def _train_gp_model(self):
        """Gaussian Process modelini eğit"""
        
        if len(self.X_observed) < 2:
            return
        
        X = np.array(self.X_observed)
        y = np.array(self.y_observed)
        
        # Y değerlerini normalize et
        y_normalized = (y - np.mean(y)) / (np.std(y) + 1e-8)
        
        # GP modelini oluştur
        kernel = ConstantKernel(1.0) * Matern(length_scale=1.0, nu=2.5)
        self.gp_model = GaussianProcessRegressor(
            kernel=kernel,
            alpha=1e-6,
            n_restarts_optimizer=5,
            random_state=42
        )
        
        try:
            self.gp_model.fit(X, y_normalized)
        except Exception as e:
            self.logger.warning(f"GP model eğitim hatası: {e}")
            # Basit model kullan
            self.gp_model = GaussianProcessRegressor(random_state=42)
            self.gp_model.fit(X, y)
    
    def _select_next_point(self, parameter_bounds: List[ParameterBounds]) -> np.ndarray:
        """Sonraki değerlendirme noktasını seç"""
        
        if self.gp_model is None:
            # Rastgele nokta
            return self._generate_initial_points(parameter_bounds, 1, np.random.randint(0, 1000))[0]
        
        # Acquisition function hesapla
        acquisition_func = self.acquisition_funcs[self.acquisition_function]
        
        # grid search ile en iyi noktayı bul
        n_candidates = 1000
        candidates = []
        
        for _ in range(n_candidates):
            candidate = []
            for bound in parameter_bounds:
                if bound.parameter_type == 'continuous':
                    candidate.append(np.random.uniform(bound.min_value, bound.max_value))
                elif bound.parameter_type == 'discrete':
                    n_values = int(bound.max_value - bound.min_value + 1)
                    discrete_values = np.linspace(bound.min_value, bound.max_value, n_values)
                    candidate.append(np.random.choice(discrete_values))
                elif bound.parameter_type == 'categorical':
                    candidate.append(np.random.choice(range(len(bound.categories))))
            
            candidates.append(np.array(candidate))
        
        candidates = np.array(candidates)
        
        # Acquisition fonksiyonunu değerlendir
        acq_values = []
        for candidate in candidates:
            try:
                acq_value = acquisition_func(candidate)
                acq_values.append(acq_value)
            except Exception:
                acq_values.append(-np.inf)
        
        # En iyi adayı seç
        best_idx = np.argmax(acq_values)
        return candidates[best_idx]
    
    def _expected_improvement(self, x: np.ndarray) -> float:
        """Expected Improvement acquisition function"""
        
        if self.gp_model is None:
            return 0
        
        # GP tahminleri
        mu, sigma = self.gp_model.predict(x.reshape(1, -1), return_std=True)
        mu = mu[0]
        sigma = sigma[0] if hasattr(sigma, '__len__') else sigma
        
        if sigma < 1e-6:
            return 0
        
        # En iyi mevcut değer
        best_y = max(self.y_observed)
        
        # EI hesapla
        z = (mu - best_y - self.xi) / sigma
        ei = (mu - best_y - self.xi) * norm.cdf(z) + sigma * norm.pdf(z)
        
        return ei
    
    def _probability_of_improvement(self, x: np.ndarray) -> float:
        """Probability of Improvement acquisition function"""
        
        if self.gp_model is None:
            return 0
        
        mu, sigma = self.gp_model.predict(x.reshape(1, -1), return_std=True)
        mu = mu[0]
        sigma = sigma[0] if hasattr(sigma, '__len__') else sigma
        
        if sigma < 1e-6:
            return 0
        
        best_y = max(self.y_observed)
        z = (mu - best_y - self.xi) / sigma
        pi = norm.cdf(z)
        
        return pi
    
    def _upper_confidence_bound(self, x: np.ndarray) -> float:
        """Upper Confidence Bound acquisition function"""
        
        if self.gp_model is None:
            return 0
        
        mu, sigma = self.gp_model.predict(x.reshape(1, -1), return_std=True)
        mu = mu[0]
        sigma = sigma[0] if hasattr(sigma, '__len__') else sigma
        
        ucb = mu + self.kappa * sigma
        
        return ucb
    
    def _decode_parameters(self, x: np.ndarray, parameter_bounds: List[ParameterBounds]) -> Dict[str, Any]:
        """Kodlanmış parametreleri decode et"""
        
        params = {}
        for i, bound in enumerate(parameter_bounds):
            if bound.parameter_type == 'categorical' and bound.categories:
                params[bound.name] = bound.categories[int(x[i])]
            else:
                params[bound.name] = x[i]
        
        return params
    
    def _check_convergence(self, iteration: int, history: List[Dict[str, Any]]) -> bool:
        """Yakınsama kontrolü"""
        
        # En az 10 iterasyon gerekli
        if iteration < 10:
            return False
        
        # Son 5 iterasyonda iyileşme var mı?
        recent_scores = [h['best_score'] for h in history[-5:]]
        score_improvement = max(recent_scores) - min(recent_scores)
        
        # Küçük iyileşme = yakınsama
        return score_improvement < 1e-6

class GeneticOptimizer:
    """Genetik algoritma tabanlı optimizasyon"""
    
    def __init__(self, population_size: int = 50, elite_size: int = 10):
        self.population_size = population_size
        self.elite_size = elite_size
        self.mutation_rate = 0.1
        self.crossover_rate = 0.8
        self.logger = logging.getLogger(__name__)
        
        # GA parametreleri
        self.generation = 0
        self.best_individual = None
        self.best_fitness = -np.inf
    
    def optimize(
        self,
        objective_function: Callable,
        parameter_bounds: List[ParameterBounds],
        n_generations: int = 100,
        fitness_threshold: Optional[float] = None
    ) -> OptimizationResult:
        """Genetik algoritma optimizasyonu"""
        
        start_time = datetime.now()
        
        try:
            self.logger.info(f"GA optimizasyon başlıyor: {n_generations} nesil, {self.population_size} popülasyon")
            
            # İlk popülasyonu oluştur
            population = self._initialize_population(parameter_bounds)
            fitness_history = []
            
            for generation in range(n_generations):
                self.generation = generation
                
                # Fitness değerlendirme
                fitness_scores = []
                for individual in population:
                    try:
                        params = self._decode_individual(individual, parameter_bounds)
                        fitness = objective_function(params)
                        fitness_scores.append(fitness)
                    except Exception as e:
                        self.logger.warning(f"Fitness değerlendirme hatası: {e}")
                        fitness_scores.append(-np.inf)
                
                # En iyi bireyi güncelle
                max_fitness_idx = np.argmax(fitness_scores)
                if fitness_scores[max_fitness_idx] > self.best_fitness:
                    self.best_fitness = fitness_scores[max_fitness_idx]
                    self.best_individual = population[max_fitness_idx].copy()
                
                fitness_history.append({
                    'generation': generation,
                    'best_fitness': self.best_fitness,
                    'average_fitness': np.mean(fitness_scores),
                    'worst_fitness': np.min(fitness_scores)
                })
                
                self.logger.debug(f"Nesil {generation}: en iyi={self.best_fitness:.6f}, ortalama={np.mean(fitness_scores):.6f}")
                
                # Yakınsama kontrolü
                if fitness_threshold and self.best_fitness >= fitness_threshold:
                    self.logger.info(f"GA optimizasyon fitness eşiğine ulaştı: {self.best_fitness}")
                    break
                
                # Yeni nesil oluştur
                population = self._evolve_population(population, fitness_scores, parameter_bounds)
            
            # Sonuçları hazırla
            best_params = self._decode_individual(self.best_individual, parameter_bounds)
            execution_time = (datetime.now() - start_time).total_seconds()
            
            return OptimizationResult(
                best_params=best_params,
                best_score=self.best_fitness,
                optimization_history=fitness_history,
                convergence_achieved=self._check_ga_convergence(fitness_history),
                n_evaluations=self.generation * self.population_size,
                execution_time=execution_time
            )
            
        except Exception as e:
            self.logger.error(f"GA optimizasyon hatası: {e}")
            raise
    
    def _initialize_population(self, parameter_bounds: List[ParameterBounds]) -> List[np.ndarray]:
        """İlk popülasyonu oluştur"""
        
        population = []
        
        for _ in range(self.population_size):
            individual = []
            for bound in parameter_bounds:
                if bound.parameter_type == 'continuous':
                    individual.append(np.random.uniform(bound.min_value, bound.max_value))
                elif bound.parameter_type == 'discrete':
                    n_values = int(bound.max_value - bound.min_value + 1)
                    discrete_values = np.linspace(bound.min_value, bound.max_value, n_values)
                    individual.append(np.random.choice(discrete_values))
                elif bound.parameter_type == 'categorical':
                    individual.append(np.random.choice(range(len(bound.categories))))
            
            population.append(np.array(individual))
        
        return population
    
    def _decode_individual(self, individual: np.ndarray, parameter_bounds: List[ParameterBounds]) -> Dict[str, Any]:
        """Bireyi decode et"""
        
        params = {}
        for i, bound in enumerate(parameter_bounds):
            if bound.parameter_type == 'categorical' and bound.categories:
                params[bound.name] = bound.categories[int(individual[i])]
            else:
                params[bound.name] = individual[i]
        
        return params
    
    def _evolve_population(
        self, 
        population: List[np.ndarray], 
        fitness_scores: List[float],
        parameter_bounds: List[ParameterBounds]
    ) -> List[np.ndarray]:
        """Popülasyonu evrimle"""
        
        # Seçim
        selected = self._tournament_selection(population, fitness_scores, self.elite_size)
        
        # Yeni popülasyon
        new_population = selected.copy()
        
        # Çaprazlama ve mutasyon
        while len(new_population) < self.population_size:
            # Ebeveynleri seç
            parent1, parent2 = self._select_parents(selected)
            
            # Çaprazlama
            if np.random.random() < self.crossover_rate:
                child1, child2 = self._crossover(parent1, parent2, parameter_bounds)
            else:
                child1, child2 = parent1.copy(), parent2.copy()
            
            # Mutasyon
            child1 = self._mutate(child1, parameter_bounds)
            if len(new_population) < self.population_size - 1:
                child2 = self._mutate(child2, parameter_bounds)
                new_population.append(child2)
            
            new_population.append(child1)
        
        return new_population[:self.population_size]
    
    def _tournament_selection(
        self, 
        population: List[np.ndarray], 
        fitness_scores: List[float], 
        tournament_size: int
    ) -> List[np.ndarray]:
        """Turnuva seçimi"""
        
        selected = []
        
        for _ in range(self.elite_size):
            # Turnuva katılımcılarını seç
            tournament_indices = np.random.choice(len(population), tournament_size, replace=False)
            tournament_fitness = [fitness_scores[i] for i in tournament_indices]
            
            # En iyi olanı seç
            winner_idx = tournament_indices[np.argmax(tournament_fitness)]
            selected.append(population[winner_idx].copy())
        
        return selected
    
    def _select_parents(self, selected: List[np.ndarray]) -> Tuple[np.ndarray, np.ndarray]:
        """Ebeveyn seçimi"""
        
        parent1 = selected[np.random.randint(0, len(selected))].copy()
        parent2 = selected[np.random.randint(0, len(selected))].copy()
        
        return parent1, parent2
    
    def _crossover(
        self, 
        parent1: np.ndarray, 
        parent2: np.ndarray, 
        parameter_bounds: List[ParameterBounds]
    ) -> Tuple[np.ndarray, np.ndarray]:
        """Çaprazlama operatörü"""
        
        child1 = parent1.copy()
        child2 = parent2.copy()
        
        # Tek nokta çaprazlama
        crossover_point = np.random.randint(1, len(parent1))
        
        # Çaprazlama noktasından sonrasını değiştir
        child1[crossover_point:] = parent2[crossover_point:]
        child2[crossover_point:] = parent1[crossover_point:]
        
        return child1, child2
    
    def _mutate(self, individual: np.ndarray, parameter_bounds: List[ParameterBounds]) -> np.ndarray:
        """Mutasyon operatörü"""
        
        mutated = individual.copy()
        
        for i, bound in enumerate(parameter_bounds):
            if np.random.random() < self.mutation_rate:
                if bound.parameter_type == 'continuous':
                    # Gaussian mutasyon
                    noise = np.random.normal(0, (bound.max_value - bound.min_value) * 0.1)
                    mutated[i] = np.clip(
                        mutated[i] + noise, 
                        bound.min_value, 
                        bound.max_value
                    )
                elif bound.parameter_type == 'discrete':
                    # Rastgele yeni değer
                    n_values = int(bound.max_value - bound.min_value + 1)
                    discrete_values = np.linspace(bound.min_value, bound.max_value, n_values)
                    mutated[i] = np.random.choice(discrete_values)
                elif bound.parameter_type == 'categorical':
                    # Yeni kategori
                    mutated[i] = np.random.randint(0, len(bound.categories))
        
        return mutated
    
    def _check_ga_convergence(self, fitness_history: List[Dict[str, Any]]) -> bool:
        """GA yakınsama kontrolü"""
        
        if len(fitness_history) < 10:
            return False
        
        # Son 10 nesilde iyileşme var mı?
        recent_fitness = [h['best_fitness'] for h in fitness_history[-10:]]
        improvement = max(recent_fitness) - min(recent_fitness)
        
        return improvement < 1e-6

class ParameterTuner:
    """Genel parametre ayarlama sınıfı"""
    
    def __init__(self, optimizer_type: str = "bayesian"):
        self.optimizer_type = optimizer_type
        self.logger = logging.getLogger(__name__)
        
        if optimizer_type == "bayesian":
            self.optimizer = BayesianOptimizer()
        elif optimizer_type == "genetic":
            self.optimizer = GeneticOptimizer()
        else:
            raise ValueError(f"Desteklenmeyen optimizer türü: {optimizer_type}")
    
    def tune_strategy_parameters(
        self,
        strategy_config: StrategyConfig,
        objective_function: Callable,
        n_calls: int = 50
    ) -> OptimizationResult:
        """Strateji parametrelerini ayarla"""
        
        try:
            # Parametre uzayını oluştur
            parameter_bounds = self._create_parameter_bounds(strategy_config)
            
            # Optimizasyon çalıştır
            if self.optimizer_type == "bayesian":
                result = self.optimizer.optimize(
                    objective_function=objective_function,
                    parameter_bounds=parameter_bounds,
                    n_calls=n_calls
                )
            else:  # genetic
                result = self.optimizer.optimize(
                    objective_function=objective_function,
                    parameter_bounds=parameter_bounds,
                    n_generations=n_calls // self.optimizer.population_size
                )
            
            # Sonuçları strateji konfigürasyonuna uygula
            strategy_config.parameters.update(result.best_params)
            strategy_config.last_updated = datetime.now()
            
            self.logger.info(f"Parametre ayarlama tamamlandı. En iyi skor: {result.best_score:.6f}")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Parametre ayarlama hatası: {e}")
            raise
    
    def _create_parameter_bounds(self, strategy_config: StrategyConfig) -> List[ParameterBounds]:
        """Strateji konfigürasyonundan parametre sınırları oluştur"""
        
        bounds = []
        
        for param_name, param_value in strategy_config.parameters.items():
            if isinstance(param_value, (int, float)):
                # Sürekli parametre
                bounds.append(ParameterBounds(
                    name=param_name,
                    min_value=param_value * 0.1,
                    max_value=param_value * 10.0,
                    parameter_type='continuous'
                ))
            elif isinstance(param_value, bool):
                # Boolean parametre
                bounds.append(ParameterBounds(
                    name=param_name,
                    min_value=0,
                    max_value=1,
                    parameter_type='categorical',
                    categories=[False, True]
                ))
            elif isinstance(param_value, str):
                # Kategorik parametre
                bounds.append(ParameterBounds(
                    name=param_name,
                    min_value=0,
                    max_value=len(param_value) - 1,
                    parameter_type='categorical',
                    categories=[param_value, f"{param_value}_alt"]
                ))
        
        return bounds

class DynamicParameterOptimizer:
    """Dinamik parametre optimizasyonu"""
    
    def __init__(self, adaptation_rate: float = 0.1):
        self.adaptation_rate = adaptation_rate
        self.logger = logging.getLogger(__name__)
        self.parameter_history = {}
    
    def adapt_parameters(
        self,
        strategy_config: StrategyConfig,
        performance_feedback: StrategyMetrics,
        market_conditions: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Performans geri bildirimine göre parametreleri adapt et"""
        
        try:
            # Mevcut parametreler
            current_params = strategy_config.parameters.copy()
            strategy_id = strategy_config.strategy_id
            
            # Parametre geçmişini güncelle
            if strategy_id not in self.parameter_history:
                self.parameter_history[strategy_id] = []
            
            self.parameter_history[strategy_id].append({
                'timestamp': datetime.now(),
                'parameters': current_params.copy(),
                'performance': performance_feedback.to_dict(),
                'market_conditions': market_conditions.copy()
            })
            
            # Adaptasyon stratejisi seç
            adaptation_strategy = self._select_adaptation_strategy(
                performance_feedback, market_conditions
            )
            
            # Parametreleri güncelle
            adapted_params = self._apply_adaptations(
                current_params, 
                performance_feedback, 
                market_conditions,
                adaptation_strategy
            )
            
            # Değişiklikleri sınırla (güvenlik için)
            bounded_params = self._apply_parameter_bounds(
                adapted_params, 
                current_params
            )
            
            self.logger.info(f"Parametre adaptasyonu tamamlandı: {strategy_id}")
            
            return bounded_params
            
        except Exception as e:
            self.logger.error(f"Parametre adaptasyonu hatası: {e}")
            return strategy_config.parameters
    
    def _select_adaptation_strategy(
        self, 
        performance: StrategyMetrics, 
        market_conditions: Dict[str, Any]
    ) -> str:
        """Adaptasyon stratejisi seç"""
        
        # Düşük Sharpe ratio = risk azaltma
        if performance.sharpe_ratio < 0.5:
            return "risk_reduction"
        
        # Yüksek drawdown = konservatifleşme
        if performance.max_drawdown < -0.2:
            return "conservative_shift"
        
        # Düşük win rate = sinyal kalitesi artırma
        if performance.win_rate < 0.4:
            return "signal_quality"
        
        # Trend piyasa = momentum stratejisi
        if market_conditions.get('trend_strength', 0) > 0.7:
            return "momentum_boost"
        
        return "balanced"
    
    def _apply_adaptations(
        self,
        current_params: Dict[str, Any],
        performance: StrategyMetrics,
        market_conditions: Dict[str, Any],
        strategy: str
    ) -> Dict[str, Any]:
        """Adaptasyonları uygula"""
        
        adapted_params = current_params.copy()
        
        if strategy == "risk_reduction":
            # Pozisyon boyutunu azalt
            if 'position_size' in adapted_params:
                adapted_params['position_size'] *= (1 - self.adaptation_rate)
            
            # Stop loss'u sıkılaştır
            if 'stop_loss' in adapted_params:
                adapted_params['stop_loss'] *= (1 - self.adaptation_rate * 0.5)
        
        elif strategy == "conservative_shift":
            # Daha az agresif parametreler
            for param_name in adapted_params:
                if 'threshold' in param_name.lower() or 'sensitivity' in param_name.lower():
                    if isinstance(adapted_params[param_name], (int, float)):
                        adapted_params[param_name] *= (1 + self.adaptation_rate)
        
        elif strategy == "signal_quality":
            # Sinyal filtrelerini sıkılaştır
            if 'signal_threshold' in adapted_params:
                adapted_params['signal_threshold'] *= (1 + self.adaptation_rate)
            
            # Min confidence artır
            if 'min_confidence' in adapted_params:
                adapted_params['min_confidence'] = min(
                    adapted_params['min_confidence'] + self.adaptation_rate, 1.0
                )
        
        elif strategy == "momentum_boost":
            # Momentum parametrelerini artır
            if 'momentum_period' in adapted_params:
                adapted_params['momentum_period'] *= (1 + self.adaptation_rate)
            
            # Trend takip katsayısını artır
            if 'trend_following_strength' in adapted_params:
                adapted_params['trend_following_strength'] *= (1 + self.adaptation_rate)
        
        # Balanced: küçük rastgele ayarlamalar
        elif strategy == "balanced":
            for param_name, param_value in adapted_params.items():
                if isinstance(param_value, (int, float)):
                    # Küçük Gaussian noise
                    noise = np.random.normal(0, self.adaptation_rate * 0.1)
                    adapted_params[param_name] = param_value * (1 + noise)
        
        return adapted_params
    
    def _apply_parameter_bounds(
        self, 
        adapted_params: Dict[str, Any], 
        reference_params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Parametre sınırlarını uygula"""
        
        bounded_params = {}
        
        for param_name, param_value in adapted_params.items():
            if isinstance(param_value, (int, float)):
                # Makul sınırlar
                max_change = abs(reference_params[param_name]) * 0.5
                min_val = reference_params[param_name] - max_change
                max_val = reference_params[param_name] + max_change
                
                bounded_params[param_name] = np.clip(param_value, min_val, max_val)
            else:
                bounded_params[param_name] = param_value
        
        return bounded_params