"""
Strategy Ranking Modülü
======================
Stratejilerin performans tabanlı sıralamasını yapan bileşen.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

from .core import StrategyMetrics, StrategyConfig

@dataclass
class RankingCriteria:
    """Sıralama kriterleri"""
    metric_name: str
    weight: float
    ascending: bool = False  # False = yüksek değer daha iyi
    min_threshold: Optional[float] = None
    max_threshold: Optional[float] = None

@dataclass
class RankingResult:
    """Sıralama sonucu"""
    strategy_id: str
    rank: int
    score: float
    metrics: StrategyMetrics
    percentile: float
    risk_adjusted_score: float
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()

class StrategyRanker:
    """Strateji performans sıralama motoru"""
    
    def __init__(self, ranking_config: Dict[str, Any] = None):
        self.config = ranking_config or self._default_config()
        self.logger = logging.getLogger(__name__)
        
        # Kriter tanımları
        self.criteria = self._initialize_criteria()
        
        # Kaydedilen sıralamalar
        self.ranking_history = []
        self.performance_percentiles = {}
        
    def _default_config(self) -> Dict[str, Any]:
        """Varsayılan sıralama konfigürasyonu"""
        return {
            'weighting_method': 'equal',  # equal, performance_based, risk_adjusted
            'ranking_horizon': 252,  # gün
            'min_trades': 10,
            'outlier_detection': True,
            'percentile_ranking': True,
            'risk_adjustment': True,
            'stability_weight': 0.1
        }
    
    def _initialize_criteria(self) -> List[RankingCriteria]:
        """Sıralama kriterlerini başlat"""
        criteria = [
            RankingCriteria('sharpe_ratio', 0.25, ascending=False),
            RankingCriteria('total_return', 0.20, ascending=False),
            RankingCriteria('calmar_ratio', 0.15, ascending=False),
            RankingCriteria('max_drawdown', 0.10, ascending=True),
            RankingCriteria('win_rate', 0.10, ascending=False),
            RankingCriteria('profit_factor', 0.08, ascending=False),
            RankingCriteria('sortino_ratio', 0.07, ascending=False),
            RankingCriteria('var_95', 0.05, ascending=True)
        ]
        return criteria
    
    async def rank_strategies(
        self, 
        strategies: List[StrategyConfig],
        metrics: Dict[str, StrategyMetrics],
        market_regime: Optional[str] = None,
        benchmark_metrics: Optional[Dict[str, float]] = None
    ) -> List[RankingResult]:
        """Stratejileri performansa göre sırala"""
        
        try:
            self.logger.info(f"{len(strategies)} strateji sıralanıyor...")
            
            # 1. Veri temizleme ve filtreleme
            filtered_strategies, filtered_metrics = self._filter_strategies(strategies, metrics)
            
            # 2. Performans hesaplama
            scores = self._calculate_composite_scores(filtered_metrics, market_regime, benchmark_metrics)
            
            # 3. Risk ayarlaması
            risk_adjusted_scores = self._apply_risk_adjustment(scores, filtered_metrics)
            
            # 4. Yüzdelik hesaplama
            percentiles = self._calculate_percentiles(scores)
            
            # 5. Sıralama
            strategy_rankings = []
            for i, (strategy_id, score) in enumerate(scores.items()):
                if strategy_id in filtered_metrics:
                    ranking = RankingResult(
                        strategy_id=strategy_id,
                        rank=i + 1,
                        score=score,
                        metrics=filtered_metrics[strategy_id],
                        percentile=percentiles[strategy_id],
                        risk_adjusted_score=risk_adjusted_scores[strategy_id]
                    )
                    strategy_rankings.append(ranking)
            
            # 6. Sıralama sonuçlarını kaydet
            self.ranking_history.append({
                'timestamp': datetime.now(),
                'rankings': strategy_rankings,
                'market_regime': market_regime,
                'total_strategies': len(strategy_rankings)
            })
            
            # 7. Yüzdelik verilerini güncelle
            self._update_percentile_database(scores)
            
            self.logger.info(f"Sıralama tamamlandı. En iyi performans: {strategy_rankings[0].score:.4f}")
            
            return sorted(strategy_rankings, key=lambda x: x.score, reverse=True)
            
        except Exception as e:
            self.logger.error(f"Sıralama hatası: {e}")
            return []
    
    def _filter_strategies(
        self, 
        strategies: List[StrategyConfig], 
        metrics: Dict[str, StrategyMetrics]
    ) -> Tuple[List[StrategyConfig], Dict[str, StrategyMetrics]]:
        """Stratejileri filtrele ve temizle"""
        
        filtered_strategies = []
        filtered_metrics = {}
        
        for strategy in strategies:
            if strategy.strategy_id not in metrics:
                continue
            
            strategy_metrics = metrics[strategy.strategy_id]
            
            # Minimum trade sayısı kontrolü
            if strategy_metrics.total_trades < self.config['min_trades']:
                self.logger.debug(f"Strateji {strategy.strategy_id} filtrelendi: yetersiz trade sayısı")
                continue
            
            # Veri kalitesi kontrolü
            if not self._validate_metrics_quality(strategy_metrics):
                self.logger.debug(f"Strateji {strategy.strategy_id} filtrelendi: düşük veri kalitesi")
                continue
            
            # Outlier detection
            if self.config['outlier_detection'] and self._is_outlier(strategy_metrics):
                self.logger.debug(f"Strateji {strategy.strategy_id} filtrelendi: outlier tespit edildi")
                continue
            
            filtered_strategies.append(strategy)
            filtered_metrics[strategy.strategy_id] = strategy_metrics
        
        self.logger.info(f"Filtreleme sonucu: {len(filtered_strategies)}/{len(strategies)} strateji kaldı")
        
        return filtered_strategies, filtered_metrics
    
    def _validate_metrics_quality(self, metrics: StrategyMetrics) -> bool:
        """Metrik veri kalitesini doğrula"""
        
        # Temel doğrulamalar
        if abs(metrics.total_return) > 10:  # %1000'den fazla getiri şüpheli
            return False
        
        if abs(metrics.max_drawdown) > 0.95:  # %95'ten fazla kayıp şüpheli
            return False
        
        if metrics.total_trades <= 0:
            return False
        
        # NaN/Inf kontrolü
        for field_name, field_value in metrics.__dict__.items():
            if isinstance(field_value, (int, float)) and (np.isnan(field_value) or np.isinf(field_value)):
                return False
        
        return True
    
    def _is_outlier(self, metrics: StrategyMetrics) -> bool:
        """Outlier tespiti"""
        
        # Z-score tabanlı outlier detection
        metric_values = [
            metrics.sharpe_ratio,
            metrics.total_return,
            metrics.max_drawdown,
            metrics.win_rate
        ]
        
        # Null değerleri temizle
        clean_values = [v for v in metric_values if not (np.isnan(v) or np.isinf(v))]
        
        if len(clean_values) < 2:
            return False
        
        # Z-score hesapla
        mean_val = np.mean(clean_values)
        std_val = np.std(clean_values)
        
        if std_val == 0:
            return False
        
        z_scores = [abs((v - mean_val) / std_val) for v in clean_values]
        
        # 3 sigma kuralı
        return any(z > 3 for z in z_scores)
    
    def _calculate_composite_scores(
        self, 
        metrics: Dict[str, StrategyMetrics],
        market_regime: Optional[str] = None,
        benchmark_metrics: Optional[Dict[str, float]] = None
    ) -> Dict[str, float]:
        """Bileşik performans skorları hesapla"""
        
        scores = {}
        
        # Rejim özel ağırlıklar
        regime_weights = self._get_regime_weights(market_regime)
        
        for strategy_id, strategy_metrics in metrics.items():
            composite_score = 0
            total_weight = 0
            
            for criterion in self.criteria:
                metric_value = getattr(strategy_metrics, criterion.metric_name, 0)
                
                # Rejim ağırlığını uygula
                weight = criterion.weight * regime_weights.get(criterion.metric_name, 1.0)
                
                # Benchmark karşılaştırması
                if benchmark_metrics and criterion.metric_name in benchmark_metrics:
                    benchmark_value = benchmark_metrics[criterion.metric_name]
                    if metric_value > benchmark_value:
                        weight *= 1.1  # Benchmark'ı geçenlere bonus
                
                # Kriter değerini normalize et
                normalized_value = self._normalize_metric_value(
                    criterion.metric_name, metric_value, criterion.ascending
                )
                
                composite_score += normalized_value * weight
                total_weight += weight
            
            # Normalize et
            if total_weight > 0:
                scores[strategy_id] = composite_score / total_weight
            else:
                scores[strategy_id] = 0
        
        return scores
    
    def _get_regime_weights(self, market_regime: Optional[str]) -> Dict[str, float]:
        """Piyasa rejimine göre ağırlıklar"""
        
        if market_regime is None:
            return {c.metric_name: 1.0 for c in self.criteria}
        
        # Rejim özel ağırlıklar
        regime_adjustments = {
            'bull': {
                'total_return': 1.3,
                'sharpe_ratio': 1.1,
                'win_rate': 1.2,
                'max_drawdown': 0.8
            },
            'bear': {
                'max_drawdown': 1.4,
                'calmar_ratio': 1.3,
                'sortino_ratio': 1.2,
                'var_95': 1.1
            },
            'volatile': {
                'max_drawdown': 1.5,
                'sharpe_ratio': 1.2,
                'calmar_ratio': 1.1,
                'var_95': 1.3
            },
            'trending': {
                'sharpe_ratio': 1.2,
                'calmar_ratio': 1.3,
                'total_return': 1.1,
                'profit_factor': 1.2
            },
            'ranging': {
                'win_rate': 1.3,
                'profit_factor': 1.2,
                'sharpe_ratio': 1.1,
                'sortino_ratio': 1.1
            }
        }
        
        return regime_adjustments.get(market_regime, {c.metric_name: 1.0 for c in self.criteria})
    
    def _normalize_metric_value(self, metric_name: str, value: float, ascending: bool) -> float:
        """Metrik değerini normalize et"""
        
        if np.isnan(value) or np.isinf(value):
            return 0
        
        # Tarihsel verileri kullanarak normalize et
        historical_values = self.performance_percentiles.get(metric_name, [])
        
        if not historical_values:
            # Basit normalization (0-1 aralığında)
            if metric_name in ['sharpe_ratio', 'total_return', 'calmar_ratio']:
                return min(max((value + 2) / 4, 0), 1)  # -2 ile 2 aralığını 0-1'e çevir
            elif metric_name in ['max_drawdown', 'var_95']:
                return 1 - min(max(abs(value), 0), 1)  # Kayıpları ters çevir
            elif metric_name in ['win_rate', 'profit_factor']:
                return min(max(value, 0), 1)
            else:
                return min(max(value, 0), 1)
        
        else:
            # Percentile tabanlı normalization
            percentile = stats.percentileofscore(historical_values, value)
            normalized = percentile / 100
            
            # Eğer ascending=True ise (düşük değer daha iyi), ters çevir
            if ascending:
                normalized = 1 - normalized
            
            return normalized
    
    def _apply_risk_adjustment(
        self, 
        scores: Dict[str, float], 
        metrics: Dict[str, StrategyMetrics]
    ) -> Dict[str, float]:
        """Risk ayarlaması uygula"""
        
        if not self.config['risk_adjustment']:
            return scores
        
        risk_adjusted_scores = {}
        stability_weight = self.config['stability_weight']
        
        for strategy_id, base_score in scores.items():
            strategy_metrics = metrics[strategy_id]
            
            # Risk faktörleri
            drawdown_penalty = max(0, abs(strategy_metrics.max_drawdown) * 0.5)
            volatility_penalty = abs(strategy_metrics.sharpe_ratio - base_score) * 0.1
            
            # Consistency bonus
            consistency_bonus = min(strategy_metrics.win_rate, 0.2)
            
            # Risk ayarlı skor
            risk_adjusted_score = base_score - drawdown_penalty - volatility_penalty + consistency_bonus
            
            # Stability weight uygula
            final_score = base_score * (1 - stability_weight) + risk_adjusted_score * stability_weight
            
            risk_adjusted_scores[strategy_id] = max(0, final_score)
        
        return risk_adjusted_scores
    
    def _calculate_percentiles(self, scores: Dict[str, float]) -> Dict[str, float]:
        """Yüzdelik değerleri hesapla"""
        
        if not self.config['percentile_ranking'] or not scores:
            return {k: 0.5 for k in scores.keys()}
        
        score_values = list(scores.values())
        percentiles = {}
        
        for strategy_id, score in scores.items():
            percentile = stats.percentileofscore(score_values, score) / 100
            percentiles[strategy_id] = percentile
        
        return percentiles
    
    def _update_percentile_database(self, scores: Dict[str, float]):
        """Yüzdelik veritabanını güncelle"""
        
        # Her metrik için yüzdelik verilerini güncelle
        for ranking_record in self.ranking_history[-1:]:
            for ranking in ranking_record['rankings']:
                metric_value = ranking.score
                if 'total_return' not in self.performance_percentiles:
                    self.performance_percentiles['total_return'] = []
                self.performance_percentiles['total_return'].append(metric_value)
        
        # Bellek sınırlaması (sadece son 1000 veri)
        for metric_name in self.performance_percentiles:
            if len(self.performance_percentiles[metric_name]) > 1000:
                self.performance_percentiles[metric_name] = self.performance_percentiles[metric_name][-1000:]
    
    def get_top_strategies(
        self, 
        n: int = 10, 
        criteria: Optional[List[str]] = None,
        market_regime: Optional[str] = None
    ) -> List[RankingResult]:
        """En iyi N stratejiyi getir"""
        
        if not self.ranking_history:
            return []
        
        latest_ranking = self.ranking_history[-1]['rankings']
        
        # Kriter filtresi
        if criteria:
            filtered_ranking = []
            for ranking in latest_ranking:
                meets_criteria = all(
                    hasattr(ranking.metrics, criterion) for criterion in criteria
                )
                if meets_criteria:
                    filtered_ranking.append(ranking)
            latest_ranking = filtered_ranking
        
        # En iyi N'ini seç
        top_strategies = sorted(latest_ranking, key=lambda x: x.score, reverse=True)[:n]
        
        return top_strategies
    
    def get_ranking_trends(self, strategy_id: str, days: int = 30) -> Dict[str, Any]:
        """Stratejinin sıralama trendini getir"""
        
        if len(self.ranking_history) < 2:
            return {}
        
        # Son N günün verilerini al
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_rankings = [
            record for record in self.ranking_history 
            if record['timestamp'] >= cutoff_date
        ]
        
        if not recent_rankings:
            return {}
        
        # Stratejinin sıralama geçmişi
        ranking_history = []
        score_history = []
        
        for record in recent_rankings:
            for ranking in record['rankings']:
                if ranking.strategy_id == strategy_id:
                    ranking_history.append(ranking.rank)
                    score_history.append(ranking.score)
        
        if len(ranking_history) < 2:
            return {}
        
        # Trend analizi
        rank_trend = "stable"
        if len(ranking_history) >= 3:
            recent_ranks = ranking_history[-3:]
            if recent_ranks[0] > recent_ranks[1] > recent_ranks[2]:
                rank_trend = "improving"
            elif recent_ranks[0] < recent_ranks[1] < recent_ranks[2]:
                rank_trend = "declining"
        
        # Score trend
        score_change = score_history[-1] - score_history[0] if len(score_history) >= 2 else 0
        
        return {
            'strategy_id': strategy_id,
            'ranking_history': ranking_history,
            'score_history': score_history,
            'current_rank': ranking_history[-1] if ranking_history else None,
            'rank_trend': rank_trend,
            'score_change': score_change,
            'data_points': len(ranking_history)
        }
    
    def export_ranking_report(self, filename: str = None) -> Dict[str, Any]:
        """Sıralama raporunu dışa aktar"""
        
        if not self.ranking_history:
            return {}
        
        latest_ranking = self.ranking_history[-1]
        
        report = {
            'timestamp': latest_ranking['timestamp'],
            'total_strategies': latest_ranking['total_strategies'],
            'market_regime': latest_ranking['market_regime'],
            'ranking_criteria': [
                {
                    'metric': c.metric_name,
                    'weight': c.weight,
                    'ascending': c.ascending
                } for c in self.criteria
            ],
            'top_strategies': [
                {
                    'strategy_id': r.strategy_id,
                    'rank': r.rank,
                    'score': r.score,
                    'percentile': r.percentile,
                    'risk_adjusted_score': r.risk_adjusted_score,
                    'key_metrics': {
                        'total_return': r.metrics.total_return,
                        'sharpe_ratio': r.metrics.sharpe_ratio,
                        'max_drawdown': r.metrics.max_drawdown,
                        'win_rate': r.metrics.win_rate
                    }
                } for r in latest_ranking['rankings'][:20]
            ],
            'ranking_trends': self._get_ranking_trends_summary(),
            'statistics': self._get_ranking_statistics()
        }
        
        if filename:
            import json
            with open(filename, 'w') as f:
                json.dump(report, f, indent=2, default=str)
        
        return report
    
    def _get_ranking_trends_summary(self) -> Dict[str, Any]:
        """Sıralama trend özetini getir"""
        
        if len(self.ranking_history) < 2:
            return {}
        
        trends = {}
        
        # Tüm stratejiler için trend analizi
        latest_ranking = self.ranking_history[-1]['rankings']
        
        for ranking in latest_ranking[:10]:  # İlk 10 strateji
            strategy_id = ranking.strategy_id
            trends[strategy_id] = self.get_ranking_trends(strategy_id, days=30)
        
        return trends
    
    def _get_ranking_statistics(self) -> Dict[str, Any]:
        """Sıralama istatistikleri"""
        
        if not self.ranking_history:
            return {}
        
        latest_ranking = self.ranking_history[-1]['rankings']
        
        scores = [r.score for r in latest_ranking]
        percentiles = [r.percentile for r in latest_ranking]
        
        return {
            'score_distribution': {
                'mean': np.mean(scores),
                'median': np.median(scores),
                'std': np.std(scores),
                'min': np.min(scores),
                'max': np.max(scores),
                'q25': np.percentile(scores, 25),
                'q75': np.percentile(scores, 75)
            },
            'percentile_distribution': {
                'mean': np.mean(percentiles),
                'median': np.median(percentiles),
                'std': np.std(percentiles)
            },
            'top_performer': latest_ranking[0].strategy_id if latest_ranking else None,
            'most_improved': self._find_most_improved_strategy(),
            'consistent_performers': self._find_consistent_performers()
        }
    
    def _find_most_improved_strategy(self) -> Optional[str]:
        """En çok gelişen stratejiyi bul"""
        
        if len(self.ranking_history) < 2:
            return None
        
        latest = self.ranking_history[-1]['rankings']
        previous = self.ranking_history[-2]['rankings']
        
        improvements = {}
        
        for ranking in latest:
            strategy_id = ranking.strategy_id
            
            # Önceki sıralamayı bul
            prev_rank = None
            for prev_ranking in previous:
                if prev_ranking.strategy_id == strategy_id:
                    prev_rank = prev_ranking.rank
                    break
            
            if prev_rank:
                improvement = prev_rank - ranking.rank  # Pozitif = gelişme
                improvements[strategy_id] = improvement
        
        if improvements:
            return max(improvements.keys(), key=lambda x: improvements[x])
        
        return None
    
    def _find_consistent_performers(self) -> List[str]:
        """Tutarlı performans gösteren stratejileri bul"""
        
        if len(self.ranking_history) < 5:
            return []
        
        # Son 5 sıralamada ilk 20'de olan stratejiler
        consistent_count = {}
        
        for record in self.ranking_history[-5:]:
            for ranking in record['rankings'][:20]:
                strategy_id = ranking.strategy_id
                consistent_count[strategy_id] = consistent_count.get(strategy_id, 0) + 1
        
        # En az 3 kez ilk 20'de olanlar
        consistent_performers = [
            strategy_id for strategy_id, count in consistent_count.items() 
            if count >= 3
        ]
        
        return consistent_performers