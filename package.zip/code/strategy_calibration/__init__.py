"""
Otomatik Strateji Kalibrasyon Algoritması
=====================================

Bu paket, trading stratejilerinin otomatik kalibrasyonunu ve optimizasyonunu sağlar.

Ana Bileşenler:
- Strategy Performance Ranking
- Dynamic Parameter Optimization  
- Genetic Algorithm for Strategy Evolution
- Bayesian Optimization
- Multi-Armed Bandit Algorithms
- Ensemble Method Optimization
- Cross-Validation Based Calibration
- Walk-Forward Optimization
- Regime-Specific Optimization
- Automated Strategy Retirement
- New Strategy Generation
- Performance-Based Resource Allocation

Yazar: AI Assistant
Tarih: 2025-10-30
"""

from .core import (
    StrategyCalibrator,
    PerformanceEvaluator,
    ParameterOptimizer,
    StrategyEvolution
)

from .ranking import StrategyRanker
from .optimization import (
    BayesianOptimizer,
    GeneticOptimizer,
    ParameterTuner
)

from .bandits import MultiArmedBandit
from .validation import (
    CrossValidator,
    WalkForwardValidator
)

from .evolution import StrategyEvolutionEngine
from .allocation import ResourceAllocator
from .retirement import StrategyRetirement
from .generation import StrategyGenerator
from .regime import RegimeSpecificOptimizer

__version__ = "1.0.0"
__all__ = [
    "StrategyCalibrator",
    "PerformanceEvaluator", 
    "ParameterOptimizer",
    "StrategyEvolution",
    "StrategyRanker",
    "BayesianOptimizer",
    "GeneticOptimizer", 
    "ParameterTuner",
    "MultiArmedBandit",
    "CrossValidator",
    "WalkForwardValidator",
    "StrategyEvolutionEngine",
    "ResourceAllocator",
    "StrategyRetirement",
    "StrategyGenerator",
    "RegimeSpecificOptimizer"
]