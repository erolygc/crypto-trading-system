"""
Strategy Generation Modülü
=========================
Yeni stratejilerin otomatik üretimi ve keşfi.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging
from abc import ABC, abstractmethod
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import random
import copy
import warnings
warnings.filterwarnings('ignore')

from .core import StrategyConfig, StrategyMetrics

@dataclass
class GenerationConfig:
    """Strateji üretim konfigürasyonu"""
    population_size: int = 20
    diversity_threshold: float = 0.3
    novelty_threshold: float = 0.5
    performance_threshold: float = 0.3
    max_generations: int = 5
    crossover_probability: float = 0.7
    mutation_probability: float = 0.3
    feature_space_size: int = 50
    target_strategies: int = 10

@dataclass
class GeneratedStrategy:
    """Üretilen strateji"""
    strategy_config: StrategyConfig
    generation_method: str
    parent_strategies: List[str]
    novelty_score: float
    diversity_score: float
    expected_performance: float
    feature_vector: np.ndarray
    created_at: datetime = field(default_factory=datetime.now)

class StrategyGenerator:
    """Ana strateji üretim motoru"""
    
    def __init__(self, config: GenerationConfig = None):
        self.config = config or GenerationConfig()
        self.logger = logging.getLogger(__name__)
        
        # Üretim modülleri
        self.template_generator = TemplateBasedGenerator()
        self.evolutionary_generator = EvolutionaryGenerator()
        self.hybrid_generator = HybridGenerator()
        self.novelty_generator = NoveltyBasedGenerator()
        
        # Bilgi tabanı
        self.strategy_templates = self._initialize_strategy_templates()
        self.performance_patterns = {}
        self.feature_space = self._initialize_feature_space()
        
        # Üretim geçmişi
        self.generation_history = []
        self.best_strategies = []
    
    def generate_strategies(
        self,
        existing_strategies: List[StrategyConfig],
        market_conditions: Optional[Dict[str, Any]] = None,
        target_count: Optional[int] = None
    ) -> List[GeneratedStrategy]:
        """Yeni stratejiler üret"""
        
        try:
            target_count = target_count or self.config.target_strategies
            self.logger.info(f"Strateji üretimi başlatılıyor: {target_count} hedef, {len(existing_strategies)} mevcut")
            
            generated_strategies = []
            
            # 1. Şablon tabanlı üretim
            self.logger.info("Şablon tabanlı üretim...")
            template_strategies = self.template_generator.generate(
                self.strategy_templates,
                market_conditions,
                target_count // 4
            )
            generated_strategies.extend(template_strategies)
            
            # 2. Evrimsel üretim
            self.logger.info("Evrimsel üretim...")
            evolutionary_strategies = self.evolutionary_generator.generate(
                existing_strategies,
                self.config,
                target_count // 4
            )
            generated_strategies.extend(evolutionary_strategies)
            
            # 3. Hibrit üretim
            self.logger.info("Hibrit üretim...")
            hybrid_strategies = self.hybrid_generator.generate(
                existing_strategies,
                self.strategy_templates,
                target_count // 4
            )
            generated_strategies.extend(hybrid_strategies)
            
            # 4. Novellik tabanlı üretim
            self.logger.info("Novellik tabanlı üretim...")
            novelty_strategies = self.novelty_generator.generate(
                existing_strategies,
                self.feature_space,
                target_count // 4
            )
            generated_strategies.extend(novelty_strategies)
            
            # 5. Çeşitlilik ve kalite filtreleme
            filtered_strategies = self._filter_and_rank_strategies(
                generated_strategies,
                existing_strategies
            )
            
            # 6. En iyi N stratejiyi seç
            final_strategies = filtered_strategies[:target_count]
            
            # 7. Üretim geçmişine ekle
            self.generation_history.append({
                'timestamp': datetime.now(),
                'target_count': target_count,
                'generated_count': len(generated_strategies),
                'final_count': len(final_strategies),
                'market_conditions': market_conditions
            })
            
            self.logger.info(f"Strateji üretimi tamamlandı: {len(final_strategies)} strateji")
            
            return final_strategies
            
        except Exception as e:
            self.logger.error(f"Strateji üretim hatası: {e}")
            raise
    
    def _initialize_strategy_templates(self) -> Dict[str, Dict[str, Any]]:
        """Strateji şablonlarını başlat"""
        
        templates = {
            'momentum': {
                'type': 'momentum',
                'base_params': {
                    'lookback_period': 20,
                    'momentum_threshold': 0.02,
                    'signal_sensitivity': 0.7,
                    'position_sizing': 1.0,
                    'stop_loss': 0.05,
                    'take_profit': 0.10
                },
                'parameter_ranges': {
                    'lookback_period': (10, 60),
                    'momentum_threshold': (0.005, 0.05),
                    'signal_sensitivity': (0.3, 1.0),
                    'position_sizing': (0.5, 2.0),
                    'stop_loss': (0.02, 0.15),
                    'take_profit': (0.05, 0.25)
                },
                'suitable_markets': ['trending', 'volatile']
            },
            'mean_reversion': {
                'type': 'mean_reversion',
                'base_params': {
                    'reversion_period': 30,
                    'deviation_threshold': 2.0,
                    'signal_threshold': 0.7,
                    'position_sizing': 0.8,
                    'stop_loss': 0.03,
                    'take_profit': 0.08
                },
                'parameter_ranges': {
                    'reversion_period': (15, 60),
                    'deviation_threshold': (1.0, 3.5),
                    'signal_threshold': (0.5, 0.9),
                    'position_sizing': (0.3, 1.5),
                    'stop_loss': (0.01, 0.08),
                    'take_profit': (0.03, 0.15)
                },
                'suitable_markets': ['ranging', 'low_volatility']
            },
            'breakout': {
                'type': 'breakout',
                'base_params': {
                    'breakout_period': 14,
                    'volume_threshold': 1.5,
                    'price_threshold': 0.02,
                    'position_sizing': 1.2,
                    'stop_loss': 0.04,
                    'take_profit': 0.12
                },
                'parameter_ranges': {
                    'breakout_period': (7, 28),
                    'volume_threshold': (1.0, 3.0),
                    'price_threshold': (0.01, 0.05),
                    'position_sizing': (0.5, 2.0),
                    'stop_loss': (0.02, 0.10),
                    'take_profit': (0.05, 0.20)
                },
                'suitable_markets': ['volatile', 'trending']
            },
            'statistical_arbitrage': {
                'type': 'stat_arb',
                'base_params': {
                    'pair_lookback': 252,
                    'z_score_threshold': 2.0,
                    'mean_reversion_speed': 0.1,
                    'position_sizing': 0.6,
                    'stop_loss': 0.02,
                    'take_profit': 0.04
                },
                'parameter_ranges': {
                    'pair_lookback': (126, 504),
                    'z_score_threshold': (1.5, 3.0),
                    'mean_reversion_speed': (0.05, 0.3),
                    'position_sizing': (0.3, 1.0),
                    'stop_loss': (0.01, 0.05),
                    'take_profit': (0.02, 0.08)
                },
                'suitable_markets': ['stable', 'low_volatility']
            },
            'risk_parity': {
                'type': 'risk_parity',
                'base_params': {
                    'risk_horizon': 30,
                    'volatility_target': 0.15,
                    'correlation_lookback': 60,
                    'rebalancing_frequency': 'weekly',
                    'max_leverage': 2.0,
                    'risk_budget': 0.1
                },
                'parameter_ranges': {
                    'risk_horizon': (20, 60),
                    'volatility_target': (0.10, 0.25),
                    'correlation_lookback': (30, 120),
                    'max_leverage': (1.0, 3.0),
                    'risk_budget': (0.05, 0.20)
                },
                'suitable_markets': ['any']
            },
            'machine_learning': {
                'type': 'ml_strategy',
                'base_params': {
                    'model_type': 'random_forest',
                    'feature_window': 30,
                    'prediction_horizon': 5,
                    'confidence_threshold': 0.6,
                    'position_sizing': 1.0,
                    'stop_loss': 0.03
                },
                'parameter_ranges': {
                    'feature_window': (10, 60),
                    'prediction_horizon': (1, 20),
                    'confidence_threshold': (0.4, 0.9),
                    'position_sizing': (0.5, 1.5),
                    'stop_loss': (0.01, 0.08)
                },
                'suitable_markets': ['any']
            }
        }
        
        return templates
    
    def _initialize_feature_space(self) -> np.ndarray:
        """Özellik uzayını başlat"""
        
        # Temel piyasa özellikleri
        base_features = np.random.randn(self.config.feature_space_size, self.config.feature_space_size)
        return base_features
    
    def _filter_and_rank_strategies(
        self,
        strategies: List[GeneratedStrategy],
        existing_strategies: List[StrategyConfig]
    ) -> List[GeneratedStrategy]:
        """Stratejileri filtrele ve sırala"""
        
        if not strategies:
            return []
        
        # 1. Çeşitlilik filtresi
        diverse_strategies = self._ensure_diversity(strategies, existing_strategies)
        
        # 2. Kalite skorlaması
        scored_strategies = []
        for strategy in diverse_strategies:
            quality_score = self._calculate_quality_score(strategy, existing_strategies)
            strategy.expected_performance = quality_score
            scored_strategies.append(strategy)
        
        # 3. Performansa göre sırala
        scored_strategies.sort(key=lambda x: x.expected_performance, reverse=True)
        
        return scored_strategies
    
    def _ensure_diversity(
        self,
        strategies: List[GeneratedStrategy],
        existing_strategies: List[StrategyConfig]
    ) -> List[GeneratedStrategy]:
        """Çeşitlilik sağla"""
        
        if len(strategies) <= 1:
            return strategies
        
        # Mevcut stratejilerle benzerlik kontrolü
        existing_vectors = [self._strategy_to_vector(s) for s in existing_strategies]
        
        diverse_strategies = []
        
        for strategy in strategies:
            strategy_vector = strategy.feature_vector
            
            # En yakın komşu benzerliği
            if existing_vectors:
                distances = [np.linalg.norm(strategy_vector - existing_vec) for existing_vec in existing_vectors]
                min_distance = min(distances) if distances else 0
                
                # Minimum mesafe eşiğini sağla
                if min_distance >= self.config.diversity_threshold:
                    diverse_strategies.append(strategy)
            else:
                diverse_strategies.append(strategy)
        
        # Eğer çok az çeşitli strateji varsa, en iyi N tanesini al
        if len(diverse_strategies) < len(strategies) * 0.5:
            remaining_strategies = [s for s in strategies if s not in diverse_strategies]
            remaining_strategies.sort(key=lambda x: x.expected_performance, reverse=True)
            diverse_strategies.extend(remaining_strategies[:len(strategies)//2])
        
        return diverse_strategies[:self.config.target_strategies]
    
    def _calculate_quality_score(
        self,
        strategy: GeneratedStrategy,
        existing_strategies: List[StrategyConfig]
    ) -> float:
        """Strateji kalite skoru"""
        
        base_score = 0.5  # Temel skor
        
        # Novellik bonusu
        novelty_bonus = strategy.novelty_score * 0.3
        
        # Çeşitlilik bonusu
        diversity_bonus = strategy.diversity_score * 0.2
        
        # Performans tahmini
        performance_score = min(1.0, max(0, strategy.expected_performance))
        
        # Şablon uygunluk bonusu
        template_bonus = self._assess_template_quality(strategy)
        
        final_score = base_score + novelty_bonus + diversity_bonus + performance_score * 0.3 + template_bonus * 0.2
        
        return min(1.0, max(0, final_score))
    
    def _assess_template_quality(self, strategy: GeneratedStrategy) -> float:
        """Şablon kalite değerlendirmesi"""
        
        template_quality = 0.5  # Varsayılan
        
        config = strategy.strategy_config
        strategy_type = config.strategy_type
        
        if strategy_type in self.strategy_templates:
            template = self.strategy_templates[strategy_type]
            params = config.parameters
            
            # Parametrelerin mantıklı aralıkta olup olmadığı
            valid_params = 0
            total_params = 0
            
            for param_name, value in params.items():
                total_params += 1
                if param_name in template['parameter_ranges']:
                    min_val, max_val = template['parameter_ranges'][param_name]
                    if min_val <= value <= max_val:
                        valid_params += 1
            
            template_quality = valid_params / total_params if total_params > 0 else 0.5
        
        return template_quality
    
    def _strategy_to_vector(self, strategy_config: StrategyConfig) -> np.ndarray:
        """Stratejiyi vektöre çevir"""
        
        # Basit encoding
        vector_size = self.config.feature_space_size // 4
        vector = np.zeros(vector_size)
        
        # Parametreleri ekle
        param_values = list(strategy_config.parameters.values())
        
        for i, value in enumerate(param_values[:vector_size]):
            if isinstance(value, (int, float)):
                vector[i] = value
            elif isinstance(value, bool):
                vector[i] = 1 if value else 0
            elif isinstance(value, str):
                vector[i] = hash(value) % 1000 / 1000
        
        return vector
    
    def export_generation_report(self, filename: str = None) -> Dict[str, Any]:
        """Üretim raporu"""
        
        if not self.generation_history:
            return {'error': 'Üretim geçmişi bulunamadı'}
        
        latest_generation = self.generation_history[-1]
        
        report = {
            'generation_statistics': {
                'total_generations': len(self.generation_history),
                'latest_generation': latest_generation,
                'templates_used': list(self.strategy_templates.keys())
            },
            'template_performance': self._analyze_template_performance(),
            'generation_methods': self._analyze_generation_methods(),
            'quality_trends': self._analyze_quality_trends()
        }
        
        if filename:
            import json
            with open(filename, 'w') as f:
                json.dump(report, f, indent=2, default=str)
        
        return report
    
    def _analyze_template_performance(self) -> Dict[str, Any]:
        """Şablon performans analizi"""
        
        template_stats = {}
        
        for template_name in self.strategy_templates.keys():
            template_stats[template_name] = {
                'usage_count': 0,
                'avg_quality': 0,
                'success_rate': 0
            }
        
        return template_stats
    
    def _analyze_generation_methods(self) -> Dict[str, Any]:
        """Üretim yöntemleri analizi"""
        
        return {
            'template_based': {'usage': 0, 'success': 0},
            'evolutionary': {'usage': 0, 'success': 0},
            'hybrid': {'usage': 0, 'success': 0},
            'novelty_based': {'usage': 0, 'success': 0}
        }
    
    def _analyze_quality_trends(self) -> Dict[str, Any]:
        """Kalite trend analizi"""
        
        return {
            'trend': 'stable',
            'improvement_rate': 0,
            'quality_distribution': {},
            'best_generation': None
        }

class TemplateBasedGenerator:
    """Şablon tabanlı strateji üreticisi"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def generate(
        self,
        templates: Dict[str, Dict[str, Any]],
        market_conditions: Optional[Dict[str, Any]] = None,
        target_count: int = 5
    ) -> List[GeneratedStrategy]:
        """Şablonlardan strateji üret"""
        
        generated = []
        
        for i in range(target_count):
            # Uygun şablon seç
            template_name, template = self._select_appropriate_template(templates, market_conditions)
            
            # Şablondan parametre üret
            strategy_params = self._generate_parameters_from_template(template)
            
            # Strateji konfigürasyonu oluştur
            strategy_config = StrategyConfig(
                strategy_id=f"template_{template_name}_{i}_{random.randint(1000, 9999)}",
                strategy_type=template['type'],
                parameters=strategy_params,
                constraints={},
                risk_limits={'max_drawdown': 0.2, 'max_position': 1.0},
                optimization_targets=['sharpe_ratio', 'total_return']
            )
            
            # Feature vector oluştur
            feature_vector = self._generate_feature_vector(strategy_params)
            
            generated_strategy = GeneratedStrategy(
                strategy_config=strategy_config,
                generation_method="template_based",
                parent_strategies=[template_name],
                novelty_score=0.5,  # Şablon tabanlı için orta novellik
                diversity_score=0.7,  # Şablon çeşitliliği
                expected_performance=0.6,
                feature_vector=feature_vector
            )
            
            generated.append(generated_strategy)
        
        return generated
    
    def _select_appropriate_template(
        self,
        templates: Dict[str, Dict[str, Any]],
        market_conditions: Optional[Dict[str, Any]] = None
    ) -> Tuple[str, Dict[str, Any]]:
        """Uygun şablon seç"""
        
        if not market_conditions:
            # Rastgele şablon seç
            template_name = random.choice(list(templates.keys()))
            return template_name, templates[template_name]
        
        # Piyasa koşullarına göre şablon seç
        market_regime = market_conditions.get('regime', 'unknown')
        
        suitable_templates = []
        for name, template in templates.items():
            suitable_markets = template.get('suitable_markets', ['any'])
            if 'any' in suitable_markets or market_regime in suitable_markets:
                suitable_templates.append(name)
        
        if not suitable_templates:
            suitable_templates = list(templates.keys())
        
        template_name = random.choice(suitable_templates)
        return template_name, templates[template_name]
    
    def _generate_parameters_from_template(self, template: Dict[str, Any]) -> Dict[str, Any]:
        """Şablondan parametre üret"""
        
        base_params = template['base_params'].copy()
        param_ranges = template['parameter_ranges']
        
        for param_name, (min_val, max_val) in param_ranges.items():
            if param_name in base_params:
                # Aralık içinde rastgele değer
                if isinstance(min_val, int) and isinstance(max_val, int):
                    base_params[param_name] = random.randint(int(min_val), int(max_val))
                else:
                    base_params[param_name] = random.uniform(min_val, max_val)
        
        return base_params
    
    def _generate_feature_vector(self, params: Dict[str, Any]) -> np.ndarray:
        """Özellik vektörü oluştur"""
        
        vector_size = 20
        feature_vector = np.zeros(vector_size)
        
        param_values = list(params.values())
        
        for i, value in enumerate(param_values[:vector_size]):
            if isinstance(value, (int, float)):
                feature_vector[i] = value
            elif isinstance(value, bool):
                feature_vector[i] = 1 if value else 0
            else:
                feature_vector[i] = hash(str(value)) % 1000 / 1000
        
        return feature_vector

class EvolutionaryGenerator:
    """Evrimsel strateji üreticisi"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def generate(
        self,
        parent_strategies: List[StrategyConfig],
        config: GenerationConfig,
        target_count: int = 5
    ) -> List[GeneratedStrategy]:
        """Evrimsel yöntemle strateji üret"""
        
        generated = []
        
        if len(parent_strategies) < 2:
            return generated
        
        for i in range(target_count):
            # Ebeveynleri seç
            parent1, parent2 = random.sample(parent_strategies, 2)
            
            # Çaprazlama
            child_config = self._crossover_strategies(parent1, parent2)
            
            # Mutasyon
            child_config = self._mutate_strategy(child_config)
            
            # Feature vector
            feature_vector = self._strategy_to_feature_vector(child_config)
            
            generated_strategy = GeneratedStrategy(
                strategy_config=child_config,
                generation_method="evolutionary",
                parent_strategies=[parent1.strategy_id, parent2.strategy_id],
                novelty_score=0.7,  # Evrimsel için yüksek novellik
                diversity_score=0.8,  # Yüksek çeşitlilik
                expected_performance=0.65,
                feature_vector=feature_vector
            )
            
            generated.append(generated_strategy)
        
        return generated
    
    def _crossover_strategies(self, parent1: StrategyConfig, parent2: StrategyConfig) -> StrategyConfig:
        """Strateji çaprazlaması"""
        
        # Parametreleri birleştir
        child_params = {}
        all_params = set(parent1.parameters.keys()) | set(parent2.parameters.keys())
        
        for param_name in all_params:
            # Rastgele ebeveyn seç
            if random.random() < 0.5:
                child_params[param_name] = parent1.parameters.get(param_name)
            else:
                child_params[param_name] = parent2.parameters.get(param_name)
        
        # Çocuk konfigürasyonu oluştur
        child_config = StrategyConfig(
            strategy_id=f"evo_child_{random.randint(1000, 9999)}",
            strategy_type=parent1.strategy_type if random.random() < 0.7 else parent2.strategy_type,
            parameters=child_params,
            constraints={},
            risk_limits={'max_drawdown': 0.2, 'max_position': 1.0},
            optimization_targets=['sharpe_ratio', 'total_return']
        )
        
        return child_config
    
    def _mutate_strategy(self, strategy_config: StrategyConfig) -> StrategyConfig:
        """Strateji mutasyonu"""
        
        mutated_params = strategy_config.parameters.copy()
        
        for param_name, param_value in mutated_params.items():
            if random.random() < 0.2:  # %20 mutasyon oranı
                if isinstance(param_value, (int, float)):
                    # Gaussian mutasyon
                    noise = random.gauss(0, abs(param_value) * 0.1 + 0.01)
                    mutated_params[param_name] = param_value + noise
                elif isinstance(param_value, bool):
                    mutated_params[param_name] = not param_value
        
        strategy_config.parameters = mutated_params
        strategy_config.strategy_id = f"{strategy_config.strategy_id}_mut"
        
        return strategy_config
    
    def _strategy_to_feature_vector(self, strategy_config: StrategyConfig) -> np.ndarray:
        """Strateji özellik vektörü"""
        
        vector_size = 20
        vector = np.zeros(vector_size)
        
        param_values = list(strategy_config.parameters.values())
        
        for i, value in enumerate(param_values[:vector_size]):
            if isinstance(value, (int, float)):
                vector[i] = value
            elif isinstance(value, bool):
                vector[i] = 1 if value else 0
            else:
                vector[i] = hash(str(value)) % 1000 / 1000
        
        return vector

class HybridGenerator:
    """Hibrit strateji üreticisi"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def generate(
        self,
        existing_strategies: List[StrategyConfig],
        templates: Dict[str, Dict[str, Any]],
        target_count: int = 5
    ) -> List[GeneratedStrategy]:
        """Hibrit yöntemle strateji üret"""
        
        generated = []
        
        for i in range(target_count):
            # Bir şablon ve bir mevcut strateji seç
            template_name = random.choice(list(templates.keys()))
            parent_strategy = random.choice(existing_strategies) if existing_strategies else None
            
            # Hibrit parametreler
            if parent_strategy:
                hybrid_params = self._create_hybrid_parameters(
                    templates[template_name], 
                    parent_strategy
                )
            else:
                # Sadece şablon tabanlı
                hybrid_params = templates[template_name]['base_params'].copy()
            
            # Strateji konfigürasyonu
            strategy_config = StrategyConfig(
                strategy_id=f"hybrid_{template_name}_{i}_{random.randint(1000, 9999)}",
                strategy_type=templates[template_name]['type'],
                parameters=hybrid_params,
                constraints={},
                risk_limits={'max_drawdown': 0.2, 'max_position': 1.0},
                optimization_targets=['sharpe_ratio', 'total_return']
            )
            
            # Feature vector
            feature_vector = self._create_hybrid_feature_vector(strategy_config)
            
            generated_strategy = GeneratedStrategy(
                strategy_config=strategy_config,
                generation_method="hybrid",
                parent_strategies=[template_name] + ([parent_strategy.strategy_id] if parent_strategy else []),
                novelty_score=0.8,  # Hibrit için yüksek novellik
                diversity_score=0.75,
                expected_performance=0.7,
                feature_vector=feature_vector
            )
            
            generated.append(generated_strategy)
        
        return generated
    
    def _create_hybrid_parameters(
        self,
        template: Dict[str, Any],
        parent_strategy: StrategyConfig
    ) -> Dict[str, Any]:
        """Hibrit parametreler oluştur"""
        
        base_params = template['base_params'].copy()
        param_ranges = template['parameter_ranges']
        
        for param_name in param_ranges.keys():
            min_val, max_val = param_ranges[param_name]
            
            if param_name in parent_strategy.parameters:
                # Ebeveyn değerini aralıkta sınırla
                parent_value = parent_strategy.parameters[param_name]
                if isinstance(parent_value, (int, float)):
                    bounded_value = np.clip(parent_value, min_val, max_val)
                    
                    # Şablon değeri ile karıştır
                    template_value = base_params[param_name]
                    mixed_value = 0.6 * template_value + 0.4 * bounded_value
                    
                    base_params[param_name] = mixed_value
            else:
                # Yeni parametre için şablon tabanlı değer
                if isinstance(min_val, int) and isinstance(max_val, int):
                    base_params[param_name] = random.randint(int(min_val), int(max_val))
                else:
                    base_params[param_name] = random.uniform(min_val, max_val)
        
        return base_params
    
    def _create_hybrid_feature_vector(self, strategy_config: StrategyConfig) -> np.ndarray:
        """Hibrit özellik vektörü"""
        
        vector_size = 20
        vector = np.zeros(vector_size)
        
        param_values = list(strategy_config.parameters.values())
        
        for i, value in enumerate(param_values[:vector_size]):
            if isinstance(value, (int, float)):
                vector[i] = value
            elif isinstance(value, bool):
                vector[i] = 1 if value else 0
            else:
                vector[i] = hash(str(value)) % 1000 / 1000
        
        return vector

class NoveltyBasedGenerator:
    """Novellik tabanlı strateji üreticisi"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def generate(
        self,
        existing_strategies: List[StrategyConfig],
        feature_space: np.ndarray,
        target_count: int = 5
    ) -> List[GeneratedStrategy]:
        """Novellik tabanlı strateji üret"""
        
        generated = []
        
        for i in range(target_count):
            # En az explore edilen bölgede yeni strateji üret
            novel_strategy = self._generate_novel_strategy(existing_strategies, feature_space)
            
            if novel_strategy:
                generated.append(novel_strategy)
        
        return generated
    
    def _generate_novel_strategy(
        self,
        existing_strategies: List[StrategyConfig],
        feature_space: np.ndarray
    ) -> Optional[GeneratedStrategy]:
        """Novellik tabanlı yeni strateji"""
        
        # Mevcut stratejilerin feature vektörleri
        existing_vectors = [self._strategy_to_vector(s) for s in existing_strategies]
        
        if not existing_vectors:
            return None
        
        # En az doldurulmuş bölgeyi bul
        novel_region = self._find_novel_region(existing_vectors, feature_space)
        
        # Yeni strateji oluştur
        strategy_config = self._create_strategy_from_region(novel_region)
        
        if strategy_config:
            feature_vector = self._strategy_to_vector(strategy_config)
            
            return GeneratedStrategy(
                strategy_config=strategy_config,
                generation_method="novelty_based",
                parent_strategies=[],
                novelty_score=0.9,  # Novellik için en yüksek skor
                diversity_score=0.9,
                expected_performance=0.55,
                feature_vector=feature_vector
            )
        
        return None
    
    def _find_novel_region(
        self,
        existing_vectors: List[np.ndarray],
        feature_space: np.ndarray
    ) -> Optional[np.ndarray]:
        """Novellik bölgesi bul"""
        
        # Basitleştirilmiş: rastgele novel nokta seç
        # Gerçek uygulamada density estimation kullanılır
        
        if len(existing_vectors) == 0:
            return np.random.randn(feature_space.shape[1])
        
        # En uzak nokta
        center = np.mean(existing_vectors, axis=0)
        distances = [np.linalg.norm(vec - center) for vec in existing_vectors]
        farthest_idx = np.argmax(distances)
        
        # Farklı yönde novel nokta
        direction = existing_vectors[farthest_idx] - center
        norm_direction = direction / (np.linalg.norm(direction) + 1e-8)
        
        # Novel nokta: center + 2 * direction + noise
        novel_point = center + 2 * norm_direction + np.random.randn(len(center)) * 0.5
        
        return novel_point
    
    def _create_strategy_from_region(self, region_point: np.ndarray) -> Optional[StrategyConfig]:
        """Bölgeden strateji oluştur"""
        
        try:
            # Region point'ten parametre çıkar
            params = self._region_to_parameters(region_point)
            
            strategy_config = StrategyConfig(
                strategy_id=f"novel_{random.randint(1000, 9999)}",
                strategy_type="hybrid",  # Novel için hibrit tip
                parameters=params,
                constraints={},
                risk_limits={'max_drawdown': 0.2, 'max_position': 1.0},
                optimization_targets=['sharpe_ratio', 'total_return']
            )
            
            return strategy_config
            
        except Exception as e:
            self.logger.error(f"Region'dan strateji oluşturma hatası: {e}")
            return None
    
    def _region_to_parameters(self, region_point: np.ndarray) -> Dict[str, Any]:
        """Bölge noktasından parametre çıkar"""
        
        # Basit mapping
        params = {
            'period_1': int(abs(region_point[0]) * 20 + 10),
            'period_2': int(abs(region_point[1]) * 30 + 15),
            'threshold_1': abs(region_point[2]) * 0.05 + 0.01,
            'threshold_2': abs(region_point[3]) * 0.03 + 0.005,
            'sensitivity': np.clip(abs(region_point[4]), 0.1, 1.0),
            'position_size': np.clip(abs(region_point[5]), 0.5, 2.0),
            'stop_loss': np.clip(abs(region_point[6]), 0.01, 0.1),
            'take_profit': np.clip(abs(region_point[7]) * 2, 0.02, 0.2)
        }
        
        return params
    
    def _strategy_to_vector(self, strategy_config: StrategyConfig) -> np.ndarray:
        """Strateji özellik vektörü"""
        
        vector_size = 20
        vector = np.zeros(vector_size)
        
        param_values = list(strategy_config.parameters.values())
        
        for i, value in enumerate(param_values[:vector_size]):
            if isinstance(value, (int, float)):
                vector[i] = value
            elif isinstance(value, bool):
                vector[i] = 1 if value else 0
            else:
                vector[i] = hash(str(value)) % 1000 / 1000
        
        return vector