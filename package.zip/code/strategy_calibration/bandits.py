"""
Multi-Armed Bandit Modülü
========================
Strateji seçimi için çok kollu bandit algoritmaları.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging
from abc import ABC, abstractmethod
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

from .core import StrategyConfig, StrategyMetrics

@dataclass
class BanditArm:
    """Bandit kolu (strateji)"""
    strategy_id: str
    strategy_config: StrategyConfig
    n_pulls: int = 0
    total_reward: float = 0.0
    confidence: float = 0.0
    last_updated: datetime = field(default_factory=datetime.now)
    exploration_score: float = 0.0
    exploitation_score: float = 0.0

@dataclass
class BanditDecision:
    """Bandit karar sonucu"""
    selected_strategy: str
    confidence: float
    exploration_ratio: float
    expected_reward: float
    alternative_strategies: List[Dict[str, Any]]
    timestamp: datetime = field(default_factory=datetime.now)

class BanditAlgorithm(ABC):
    """Bandit algoritması temel sınıfı"""
    
    def __init__(self, name: str):
        self.name = name
        self.logger = logging.getLogger(__name__)
    
    @abstractmethod
    def select_arm(self, arms: List[BanditArm], context: Optional[Dict[str, Any]] = None) -> str:
        """En iyi kolu seç"""
        pass
    
    @abstractmethod
    def update_arm(self, arm: BanditArm, reward: float):
        """Kolu güncelle"""
        pass

class EpsilonGreedy(BanditAlgorithm):
    """Epsilon-greedy bandit algoritması"""
    
    def __init__(self, epsilon: float = 0.1, decay_rate: float = 0.995):
        super().__init__("EpsilonGreedy")
        self.epsilon = epsilon
        self.decay_rate = decay_rate
        self.total_decisions = 0
    
    def select_arm(self, arms: List[BanditArm], context: Optional[Dict[str, Any]] = None) -> str:
        """Kol seçimi"""
        
        self.total_decisions += 1
        
        # Epsilon decay
        current_epsilon = self.epsilon * (self.decay_rate ** self.total_decisions)
        
        # Exploration vs Exploitation
        if np.random.random() < current_epsilon:
            # Rastgele seçim (exploration)
            selected_arm = np.random.choice(arms)
            self.logger.debug(f"Exploration seçimi: {selected_arm.strategy_id}")
        else:
            # En iyi ortalama ödül (exploitation)
            if arms and all(arm.n_pulls > 0 for arm in arms):
                avg_rewards = [arm.total_reward / arm.n_pulls for arm in arms]
                best_idx = np.argmax(avg_rewards)
                selected_arm = arms[best_idx]
                self.logger.debug(f"Exploitation seçimi: {selected_arm.strategy_id}")
            else:
                # İlk stratejiyi seç
                selected_arm = arms[0] if arms else None
        
        return selected_arm.strategy_id if selected_arm else None
    
    def update_arm(self, arm: BanditArm, reward: float):
        """Kolu güncelle"""
        arm.n_pulls += 1
        arm.total_reward += reward
        arm.last_updated = datetime.now()

class UpperConfidenceBound(BanditAlgorithm):
    """UCB (Upper Confidence Bound) algoritması"""
    
    def __init__(self, confidence_level: float = 2.0):
        super().__init__("UCB")
        self.confidence_level = confidence_level
    
    def select_arm(self, arms: List[BanditArm], context: Optional[Dict[str, Any]] = None) -> str:
        """UCB kol seçimi"""
        
        if not arms:
            return None
        
        # Henüz çekilmemiş kolları kontrol et
        unplayed_arms = [arm for arm in arms if arm.n_pulls == 0]
        if unplayed_arms:
            selected_arm = np.random.choice(unplayed_arms)
            self.logger.debug(f"UCB exploration (unplayed): {selected_arm.strategy_id}")
            return selected_arm.strategy_id
        
        # UCB değerlerini hesapla
        total_pulls = sum(arm.n_pulls for arm in arms)
        ucb_values = []
        
        for arm in arms:
            if arm.n_pulls > 0:
                avg_reward = arm.total_reward / arm.n_pulls
                confidence_bonus = self.confidence_level * np.sqrt(
                    np.log(total_pulls) / arm.n_pulls
                )
                ucb_value = avg_reward + confidence_bonus
                ucb_values.append(ucb_value)
            else:
                ucb_values.append(float('inf'))
        
        # En yüksek UCB değerine sahip kolu seç
        best_idx = np.argmax(ucb_values)
        selected_arm = arms[best_idx]
        
        self.logger.debug(f"UCB seçimi: {selected_arm.strategy_id} (UCB: {ucb_values[best_idx]:.4f})")
        return selected_arm.strategy_id
    
    def update_arm(self, arm: BanditArm, reward: float):
        """Kolu güncelle"""
        arm.n_pulls += 1
        arm.total_reward += reward
        arm.last_updated = datetime.now()

class ThompsonSampling(BanditAlgorithm):
    """Thompson Sampling (Bayesian) algoritması"""
    
    def __init__(self, prior_alpha: float = 1.0, prior_beta: float = 1.0):
        super().__init__("ThompsonSampling")
        self.prior_alpha = prior_alpha
        self.prior_beta = prior_beta
        self.arm_posteriors = {}
    
    def select_arm(self, arms: List[BanditArm], context: Optional[Dict[str, Any]] = None) -> str:
        """Thompson Sampling kol seçimi"""
        
        sampled_rewards = []
        
        for arm in arms:
            # Posterior parametreleri
            if arm.strategy_id not in self.arm_posteriors:
                self.arm_posteriors[arm.strategy_id] = {
                    'alpha': self.prior_alpha,
                    'beta': self.prior_beta
                }
            
            posterior = self.arm_posteriors[arm.strategy_id]
            
            # Beta dağılımından örnek çek
            sample = np.random.beta(posterior['alpha'], posterior['beta'])
            sampled_rewards.append(sample)
        
        # En yüksek örneği veren kolu seç
        best_idx = np.argmax(sampled_rewards)
        selected_arm = arms[best_idx]
        
        self.logger.debug(f"Thompson Sampling seçimi: {selected_arm.strategy_id}")
        return selected_arm.strategy_id
    
    def update_arm(self, arm: BanditArm, reward: float):
        """Kolu güncelle ve posterioru güncelle"""
        arm.n_pulls += 1
        arm.total_reward += reward
        arm.last_updated = datetime.now()
        
        # Posterior güncelleme (Beta prior için)
        if arm.strategy_id not in self.arm_posteriors:
            self.arm_posteriors[arm.strategy_id] = {
                'alpha': self.prior_alpha,
                'beta': self.prior_beta
            }
        
        posterior = self.arm_posteriors[arm.strategy_id]
        
        # 0-1 reward için conjugate update
        if reward >= 0:
            posterior['alpha'] += reward
        else:
            posterior['beta'] += abs(reward)
        
        # Sınırlandırma
        posterior['alpha'] = max(0.1, posterior['alpha'])
        posterior['beta'] = max(0.1, posterior['beta'])

class ContextualBandit(BanditAlgorithm):
    """Bağlama duyarlı bandit algoritması"""
    
    def __init__(self, algorithm_type: str = "ucb", feature_dim: int = 10):
        super().__init__(f"Contextual{algorithm_type}")
        self.algorithm_type = algorithm_type
        self.feature_dim = feature_dim
        
        # Lineer model parametreleri
        self.theta = {}  # Her strateji için ağırlık vektörü
        self.feature_history = {}
        self.reward_history = {}
    
    def select_arm(self, arms: List[BanditArm], context: Optional[Dict[str, Any]] = None) -> str:
        """Bağlamlı kol seçimi"""
        
        if not context:
            # Bağlam yoksa normal UCB kullan
            ucb = UpperConfidenceBound()
            return ucb.select_arm(arms, context)
        
        # Bağlam vektörünü oluştur
        context_vector = self._encode_context(context)
        
        # Her kol için beklenen ödülü tahmin et
        predicted_rewards = {}
        
        for arm in arms:
            if arm.strategy_id not in self.theta:
                # İlk kez görülen strateji için rastgele ağırlıklar
                self.theta[arm.strategy_id] = np.random.normal(0, 0.1, self.feature_dim)
            
            # Tahmin edilen ödül
            predicted_reward = np.dot(self.theta[arm.strategy_id], context_vector)
            predicted_rewards[arm.strategy_id] = predicted_reward
        
        # En yüksek tahmini ödüle sahip kolu seç
        best_strategy = max(predicted_rewards.keys(), key=lambda x: predicted_rewards[x])
        
        self.logger.debug(f"Contextual seçimi: {best_strategy}")
        return best_strategy
    
    def update_arm(self, arm: BanditArm, reward: float):
        """Kolu güncelle"""
        arm.n_pulls += 1
        arm.total_reward += reward
        arm.last_updated = datetime.now()
        
        # Son bağlam ve ödülü kaydet
        if not hasattr(arm, 'last_context') or arm.last_context is None:
            return
        
        context_vector = self._encode_context(arm.last_context)
        
        if arm.strategy_id not in self.feature_history:
            self.feature_history[arm.strategy_id] = []
            self.reward_history[arm.strategy_id] = []
        
        self.feature_history[arm.strategy_id].append(context_vector)
        self.reward_history[arm.strategy_id].append(reward)
        
        # Basit gradyan inişi ile parametre güncelleme
        if len(self.feature_history[arm.strategy_id]) > 1:
            self._update_theta(arm.strategy_id)
    
    def _encode_context(self, context: Dict[str, Any]) -> np.ndarray:
        """Bağlamı vektöre dönüştür"""
        
        # Basit encoding
        features = []
        
        # Trend bilgileri
        features.append(context.get('trend_strength', 0))
        features.append(context.get('volatility', 0))
        features.append(context.get('volume_ratio', 1))
        
        # Piyasa rejimi
        regime_features = [0] * 5  # bull, bear, volatile, trending, ranging
        regime = context.get('market_regime', 'unknown')
        regime_map = {'bull': 0, 'bear': 1, 'volatile': 2, 'trending': 3, 'ranging': 4}
        if regime in regime_map:
            regime_features[regime_map[regime]] = 1
        features.extend(regime_features)
        
        # Zaman özellikleri
        features.append(context.get('hour_of_day', 12) / 24)
        features.append(context.get('day_of_week', 1) / 7)
        
        # Boyut tamamlama
        while len(features) < self.feature_dim:
            features.append(0)
        
        return np.array(features[:self.feature_dim])
    
    def _update_theta(self, strategy_id: str):
        """Model parametrelerini güncelle"""
        
        if len(self.feature_history[strategy_id]) < 2:
            return
        
        # Son birkaç gözlemi kullan
        n_recent = min(10, len(self.feature_history[strategy_id]))
        X = np.array(self.feature_history[strategy_id][-n_recent:])
        y = np.array(self.reward_history[strategy_id][-n_recent:])
        
        # Ridge regression
        try:
            lambda_reg = 0.1
            XTX = X.T @ X + lambda_reg * np.eye(self.feature_dim)
            XTy = X.T @ y
            
            # Çözüm
            theta_new = np.linalg.solve(XTX, XTy)
            
            # Update
            self.theta[strategy_id] = theta_new
            
        except np.linalg.LinAlgError:
            # SVD ile pseudo-inverse kullan
            U, s, Vt = np.linalg.svd(X, full_matrices=False)
            s_inv = np.where(s > 1e-10, 1/s, 0)
            theta_new = Vt.T @ np.diag(s_inv) @ U.T @ y
            self.theta[strategy_id] = theta_new

class MultiArmedBandit:
    """Ana Multi-Armed Bandit sınıfı"""
    
    def __init__(self, algorithm: str = "ucb", config: Dict[str, Any] = None):
        self.config = config or {}
        self.logger = logging.getLogger(__name__)
        
        # Algoritma seçimi
        if algorithm.lower() == "epsilon_greedy":
            self.algorithm = EpsilonGreedy(**self.config.get('epsilon_greedy', {}))
        elif algorithm.lower() == "ucb":
            self.algorithm = UpperConfidenceBound(**self.config.get('ucb', {}))
        elif algorithm.lower() == "thompson_sampling":
            self.algorithm = ThompsonSampling(**self.config.get('thompson_sampling', {}))
        elif algorithm.lower() == "contextual":
            self.algorithm = ContextualBandit(**self.config.get('contextual', {}))
        else:
            raise ValueError(f"Desteklenmeyen algoritma: {algorithm}")
        
        # Strateji kolları
        self.arms: Dict[str, BanditArm] = {}
        self.decision_history = []
        self.performance_history = []
        
        # Metrikler
        self.total_decisions = 0
        self.total_reward = 0.0
        self.cumulative_regret = 0.0
    
    def add_strategy(self, strategy_config: StrategyConfig):
        """Yeni strateji ekle"""
        
        if strategy_config.strategy_id not in self.arms:
            self.arms[strategy_config.strategy_id] = BanditArm(
                strategy_id=strategy_config.strategy_id,
                strategy_config=strategy_config
            )
            self.logger.info(f"Strateji bandit'e eklendi: {strategy_config.strategy_id}")
    
    def remove_strategy(self, strategy_id: str):
        """Stratejiyi kaldır"""
        
        if strategy_id in self.arms:
            del self.arms[strategy_id]
            self.logger.info(f"Strateji bandit'den kaldırıldı: {strategy_id}")
    
    def select_strategy(
        self, 
        context: Optional[Dict[str, Any]] = None
    ) -> BanditDecision:
        """Strateji seç"""
        
        if not self.arms:
            raise ValueError("Bandit'de strateji bulunmuyor")
        
        # Arm listesi
        arm_list = list(self.arms.values())
        
        # En iyi stratejiyi seç
        selected_strategy_id = self.algorithm.select_arm(arm_list, context)
        
        # Güven skoru hesapla
        confidence = self._calculate_confidence(selected_strategy_id)
        
        # Exploration ratio
        exploration_ratio = self._calculate_exploration_ratio()
        
        # Beklenen ödül tahmini
        expected_reward = self._estimate_expected_reward(selected_strategy_id)
        
        # Alternatif stratejiler
        alternatives = self._get_alternative_strategies(selected_strategy_id, confidence)
        
        # Karar kaydet
        decision = BanditDecision(
            selected_strategy=selected_strategy_id,
            confidence=confidence,
            exploration_ratio=exploration_ratio,
            expected_reward=expected_reward,
            alternative_strategies=alternatives
        )
        
        self.decision_history.append(decision)
        self.total_decisions += 1
        
        self.logger.info(f"Strateji seçildi: {selected_strategy_id} (güven: {confidence:.3f})")
        
        return decision
    
    def update_performance(self, strategy_id: str, reward: float):
        """Performans güncelle"""
        
        if strategy_id not in self.arms:
            self.logger.warning(f"Bilinmeyen strateji güncelleme: {strategy_id}")
            return
        
        arm = self.arms[strategy_id]
        
        # Önceki en iyi ödülü tahmin et
        best_expected = self._get_best_expected_reward()
        current_expected = arm.total_reward / max(arm.n_pulls, 1)
        
        regret = max(0, best_expected - reward)
        self.cumulative_regret += regret
        
        # Algoritmayı güncelle
        self.algorithm.update_arm(arm, reward)
        
        # Toplam ödül
        self.total_reward += reward
        
        # Geçmiş kaydet
        self.performance_history.append({
            'timestamp': datetime.now(),
            'strategy_id': strategy_id,
            'reward': reward,
            'cumulative_regret': self.cumulative_regret,
            'regret': regret
        })
        
        self.logger.debug(f"Performans güncellendi: {strategy_id} (ödül: {reward:.4f})")
    
    def _calculate_confidence(self, strategy_id: str) -> float:
        """Seçim güven skorunu hesapla"""
        
        if strategy_id not in self.arms:
            return 0.0
        
        arm = self.arms[strategy_id]
        
        if arm.n_pulls == 0:
            return 0.0
        
        # Beta dağılımının güven aralığı
        total_pulls = sum(a.n_pulls for a in self.arms.values())
        
        if total_pulls == 0:
            return 0.0
        
        # Wilson score interval approximation
        p = arm.total_reward / arm.n_pulls
        n = arm.n_pulls
        z = 1.96  # 95% confidence
        
        denominator = 1 + (z**2 / n)
        center = (p + (z**2 / (2*n))) / denominator
        margin = (z * np.sqrt((p*(1-p)/n) + (z**2/(4*n**2)))) / denominator
        
        confidence = max(0, min(1, center - margin))
        
        # Hacim bonusu (daha fazla data = daha yüksek güven)
        volume_bonus = min(arm.n_pulls / 100, 0.3)
        
        return min(1.0, confidence + volume_bonus)
    
    def _calculate_exploration_ratio(self) -> float:
        """Exploration oranını hesapla"""
        
        if not self.arms:
            return 0.0
        
        # Son 20 kararda exploration yapılan oran
        recent_decisions = self.decision_history[-20:] if len(self.decision_history) >= 20 else self.decision_history
        
        if not recent_decisions:
            return 1.0
        
        # Eksploration'un tanımı algoritmaya göre değişir
        if isinstance(self.algorithm, EpsilonGreedy):
            # Rastgele seçim oranı
            random_selections = 0
            for decision in recent_decisions:
                if decision.confidence < 0.5:  # Düşük güven = büyük ihtimalle exploration
                    random_selections += 1
            return random_selections / len(recent_decisions)
        
        elif isinstance(self.algorithm, UpperConfidenceBound):
            # Henüz oynanmamış stratejilere öncelik verme
            exploration_selections = 0
            for decision in recent_decisions:
                selected_arm = self.arms.get(decision.selected_strategy)
                if selected_arm and selected_arm.n_pulls <= 2:
                    exploration_selections += 1
            return exploration_selections / len(recent_decisions)
        
        else:
            # Diğer algoritmalar için basit tahmin
            return 0.2  # %20 exploration varsayımı
    
    def _estimate_expected_reward(self, strategy_id: str) -> float:
        """Beklenen ödül tahmini"""
        
        if strategy_id not in self.arms:
            return 0.0
        
        arm = self.arms[strategy_id]
        
        if arm.n_pulls == 0:
            # İlk kez seçilen strateji için öngörü
            return np.mean([a.total_reward / max(a.n_pulls, 1) for a in self.arms.values() if a.n_pulls > 0])
        
        # Ortalama ödül + güven aralığı
        avg_reward = arm.total_reward / arm.n_pulls
        
        # Güven aralığı
        if arm.n_pulls > 1:
            reward_std = np.std([
                a.total_reward / max(a.n_pulls, 1) 
                for a in self.arms.values() 
                if a.n_pulls > 0
            ])
            confidence_interval = 1.96 * reward_std / np.sqrt(arm.n_pulls)
        else:
            confidence_interval = 0.1
        
        return avg_reward + confidence_interval * 0.5
    
    def _get_alternative_strategies(self, selected_strategy_id: str, confidence: float) -> List[Dict[str, Any]]:
        """Alternatif stratejileri getir"""
        
        alternatives = []
        
        for arm in self.arms.values():
            if arm.strategy_id == selected_strategy_id:
                continue
            
            alt_info = {
                'strategy_id': arm.strategy_id,
                'expected_reward': arm.total_reward / max(arm.n_pulls, 1) if arm.n_pulls > 0 else 0,
                'confidence': self._calculate_confidence(arm.strategy_id),
                'n_pulls': arm.n_pulls
            }
            alternatives.append(alt_info)
        
        # En iyi 3 alternatifi seç
        alternatives.sort(key=lambda x: x['expected_reward'], reverse=True)
        return alternatives[:3]
    
    def _get_best_expected_reward(self) -> float:
        """En iyi beklenen ödül"""
        
        if not self.arms:
            return 0.0
        
        expected_rewards = []
        for arm in self.arms.values():
            if arm.n_pulls > 0:
                expected_rewards.append(arm.total_reward / arm.n_pulls)
        
        return max(expected_rewards) if expected_rewards else 0.0
    
    def get_bandit_statistics(self) -> Dict[str, Any]:
        """Bandit istatistikleri"""
        
        if not self.arms:
            return {}
        
        # Strateji performansları
        strategy_stats = {}
        for arm in self.arms.values():
            avg_reward = arm.total_reward / max(arm.n_pulls, 1)
            strategy_stats[arm.strategy_id] = {
                'n_pulls': arm.n_pulls,
                'total_reward': arm.total_reward,
                'avg_reward': avg_reward,
                'confidence': self._calculate_confidence(arm.strategy_id)
            }
        
        # Genel istatistikler
        total_pulls = sum(arm.n_pulls for arm in self.arms.values())
        avg_total_reward = self.total_reward / max(self.total_decisions, 1)
        
        return {
            'algorithm': self.algorithm.name,
            'total_strategies': len(self.arms),
            'total_decisions': self.total_decisions,
            'total_reward': self.total_reward,
            'avg_reward_per_decision': avg_total_reward,
            'cumulative_regret': self.cumulative_regret,
            'avg_regret_per_decision': self.cumulative_regret / max(self.total_decisions, 1),
            'strategy_statistics': strategy_stats,
            'exploration_ratio': self._calculate_exploration_ratio()
        }
    
    def get_performance_report(self, days: int = 30) -> Dict[str, Any]:
        """Performans raporu"""
        
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_performance = [
            record for record in self.performance_history
            if record['timestamp'] >= cutoff_date
        ]
        
        if not recent_performance:
            return {'error': 'Yeterli performans verisi bulunamadı'}
        
        # Günlük performans
        daily_rewards = {}
        for record in recent_performance:
            date = record['timestamp'].date()
            if date not in daily_rewards:
                daily_rewards[date] = []
            daily_rewards[date].append(record['reward'])
        
        daily_stats = {}
        for date, rewards in daily_rewards.items():
            daily_stats[date] = {
                'total_reward': sum(rewards),
                'avg_reward': np.mean(rewards),
                'n_decisions': len(rewards)
            }
        
        # Strateji karşılaştırması
        strategy_comparison = {}
        for record in recent_performance:
            strategy_id = record['strategy_id']
            if strategy_id not in strategy_comparison:
                strategy_comparison[strategy_id] = {
                    'total_reward': 0,
                    'rewards': [],
                    'n_selections': 0
                }
            
            strategy_comparison[strategy_id]['total_reward'] += record['reward']
            strategy_comparison[strategy_id]['rewards'].append(record['reward'])
            strategy_comparison[strategy_id]['n_selections'] += 1
        
        # Ortalama hesapla
        for strategy_id in strategy_comparison:
            rewards = strategy_comparison[strategy_id]['rewards']
            strategy_comparison[strategy_id]['avg_reward'] = np.mean(rewards)
            strategy_comparison[strategy_id]['std_reward'] = np.std(rewards)
        
        return {
            'period_days': days,
            'total_decisions': len(recent_performance),
            'total_reward': sum(record['reward'] for record in recent_performance),
            'daily_performance': daily_stats,
            'strategy_comparison': strategy_comparison,
            'best_strategy': max(
                strategy_comparison.keys(), 
                key=lambda x: strategy_comparison[x]['avg_reward']
            ) if strategy_comparison else None,
            'regret_analysis': {
                'total_regret': sum(record['regret'] for record in recent_performance),
                'avg_regret_per_decision': np.mean([record['regret'] for record in recent_performance])
            }
        }
    
    def export_bandit_state(self) -> Dict[str, Any]:
        """Bandit durumunu dışa aktar"""
        
        return {
            'algorithm': self.algorithm.name,
            'config': self.config,
            'arms': {
                strategy_id: {
                    'strategy_config': arm.strategy_config.__dict__,
                    'n_pulls': arm.n_pulls,
                    'total_reward': arm.total_reward,
                    'confidence': self._calculate_confidence(strategy_id),
                    'last_updated': arm.last_updated.isoformat()
                }
                for strategy_id, arm in self.arms.items()
            },
            'statistics': self.get_bandit_statistics(),
            'decision_history': [
                {
                    'selected_strategy': decision.selected_strategy,
                    'confidence': decision.confidence,
                    'exploration_ratio': decision.exploration_ratio,
                    'timestamp': decision.timestamp.isoformat()
                }
                for decision in self.decision_history
            ],
            'performance_history': [
                {
                    'strategy_id': record['strategy_id'],
                    'reward': record['reward'],
                    'timestamp': record['timestamp'].isoformat()
                }
                for record in self.performance_history
            ]
        }