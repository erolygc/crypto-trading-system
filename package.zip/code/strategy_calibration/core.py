"""
Core Modülü - Strateji Kalibrasyon Sisteminin Ana Bileşenleri
==========================================================
"""

import numpy as np
import pandas as pd
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging
import asyncio
import concurrent.futures
from sklearn.metrics import mean_squared_error, mean_absolute_error
import warnings
warnings.filterwarnings('ignore')

@dataclass
class StrategyMetrics:
    """Strateji performans metriklerini tutan sınıf"""
    strategy_id: str
    total_return: float
    sharpe_ratio: float
    max_drawdown: float
    win_rate: float
    profit_factor: float
    calmar_ratio: float
    sortino_ratio: float
    var_95: float
    expected_shortfall: float
    win_loss_ratio: float
    avg_trade_duration: float
    total_trades: int
    winning_trades: int
    losing_trades: int
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        """Metrikleri sözlük formatına çevir"""
        return {
            'strategy_id': self.strategy_id,
            'total_return': self.total_return,
            'sharpe_ratio': self.sharpe_ratio,
            'max_drawdown': self.max_drawdown,
            'win_rate': self.win_rate,
            'profit_factor': self.profit_factor,
            'calmar_ratio': self.calmar_ratio,
            'sortino_ratio': self.sortino_ratio,
            'var_95': self.var_95,
            'expected_shortfall': self.expected_shortfall,
            'win_loss_ratio': self.win_loss_ratio,
            'avg_trade_duration': self.avg_trade_duration,
            'total_trades': self.total_trades,
            'winning_trades': self.winning_trades,
            'losing_trades': self.losing_trades,
            'timestamp': self.timestamp
        }

@dataclass
class StrategyConfig:
    """Strateji konfigürasyon parametreleri"""
    strategy_id: str
    strategy_type: str
    parameters: Dict[str, Any]
    constraints: Dict[str, Any]
    risk_limits: Dict[str, float]
    optimization_targets: List[str]
    active: bool = True
    created_at: datetime = field(default_factory=datetime.now)
    last_updated: datetime = field(default_factory=datetime.now)

class PerformanceEvaluator:
    """Strateji performansını değerlendiren sınıf"""
    
    def __init__(self, risk_free_rate: float = 0.02):
        self.risk_free_rate = risk_free_rate
        self.logger = logging.getLogger(__name__)
    
    def calculate_metrics(self, returns: pd.Series, trades: Optional[pd.DataFrame] = None) -> StrategyMetrics:
        """Kapsamlı performans metriklerini hesapla"""
        
        # Temel metrikler
        total_return = (1 + returns).prod() - 1
        
        # Risk metrikleri
        annual_return = (1 + total_return) ** (252 / len(returns)) - 1
        annual_volatility = returns.std() * np.sqrt(252)
        
        # Sharpe ratio
        sharpe_ratio = (annual_return - self.risk_free_rate) / annual_volatility if annual_volatility > 0 else 0
        
        # Maximum drawdown
        cumulative = (1 + returns).cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        max_drawdown = drawdown.min()
        
        # Sortino ratio
        downside_returns = returns[returns < 0]
        downside_std = downside_returns.std() * np.sqrt(252) if len(downside_returns) > 0 else 0
        sortino_ratio = (annual_return - self.risk_free_rate) / downside_std if downside_std > 0 else 0
        
        # Calmar ratio
        calmar_ratio = annual_return / abs(max_drawdown) if max_drawdown != 0 else 0
        
        # VaR ve Expected Shortfall
        var_95 = np.percentile(returns, 5)
        expected_shortfall = returns[returns <= var_95].mean()
        
        # Trade metrikleri (eğer trade verisi varsa)
        if trades is not None and len(trades) > 0:
            winning_trades = trades[trades['pnl'] > 0]
            losing_trades = trades[trades['pnl'] <= 0]
            
            win_rate = len(winning_trades) / len(trades)
            profit_factor = abs(winning_trades['pnl'].sum() / losing_trades['pnl'].sum()) if len(losing_trades) > 0 else np.inf
            win_loss_ratio = winning_trades['pnl'].mean() / abs(losing_trades['pnl'].mean()) if len(losing_trades) > 0 and losing_trades['pnl'].mean() != 0 else np.inf
            
            avg_trade_duration = (trades['exit_time'] - trades['entry_time']).dt.total_seconds().mean()
            total_trades = len(trades)
            winning_trades_count = len(winning_trades)
            losing_trades_count = len(losing_trades)
        else:
            win_rate = profit_factor = win_loss_ratio = 0
            avg_trade_duration = 0
            total_trades = winning_trades_count = losing_trades_count = 0
        
        return StrategyMetrics(
            strategy_id="",
            total_return=total_return,
            sharpe_ratio=sharpe_ratio,
            max_drawdown=max_drawdown,
            win_rate=win_rate,
            profit_factor=profit_factor,
            calmar_ratio=calmar_ratio,
            sortino_ratio=sortino_ratio,
            var_95=var_95,
            expected_shortfall=expected_shortfall,
            win_loss_ratio=win_loss_ratio,
            avg_trade_duration=avg_trade_duration,
            total_trades=total_trades,
            winning_trades=winning_trades_count,
            losing_trades=losing_trades_count
        )

class ParameterOptimizer:
    """Dinamik parametre optimizasyonu"""
    
    def __init__(self, optimization_method: str = "bayesian"):
        self.optimization_method = optimization_method
        self.logger = logging.getLogger(__name__)
        self.optimization_history = []
    
    async def optimize_parameters(
        self, 
        strategy_func: callable, 
        parameter_space: Dict[str, Any],
        evaluation_period: int = 252,
        n_trials: int = 100
    ) -> Dict[str, Any]:
        """Parametre optimizasyonu"""
        
        try:
            if self.optimization_method == "bayesian":
                return await self._bayesian_optimization(strategy_func, parameter_space, n_trials)
            elif self.optimization_method == "genetic":
                return await self._genetic_optimization(strategy_func, parameter_space, n_trials)
            else:
                return await self._grid_search_optimization(strategy_func, parameter_space)
                
        except Exception as e:
            self.logger.error(f"Parametre optimizasyonu hatası: {e}")
            return parameter_space
    
    async def _bayesian_optimization(self, strategy_func, parameter_space, n_trials):
        """Bayesyen optimizasyon"""
        # Basitleştirilmiş Bayesyen optimizasyon
        best_params = {}
        best_score = -np.inf
        
        for trial in range(n_trials):
            # Rastgele parametre örnekleme
            trial_params = {}
            for param_name, param_config in parameter_space.items():
                if param_config['type'] == 'uniform':
                    trial_params[param_name] = np.random.uniform(
                        param_config['low'], param_config['high']
                    )
                elif param_config['type'] == 'choice':
                    trial_params[param_name] = np.random.choice(param_config['choices'])
            
            # Strateji değerlendirme
            score = await self._evaluate_strategy_params(strategy_func, trial_params)
            
            if score > best_score:
                best_score = score
                best_params = trial_params.copy()
        
        return best_params
    
    async def _genetic_optimization(self, strategy_func, parameter_space, n_trials):
        """Genetik algoritma optimizasyonu"""
        # Genetik algoritma implementasyonu
        population_size = 20
        generations = n_trials // population_size
        
        # Başlangıç popülasyonu
        population = [self._random_params(parameter_space) for _ in range(population_size)]
        
        for generation in range(generations):
            # Fitness değerlendirme
            fitness_scores = []
            for params in population:
                score = await self._evaluate_strategy_params(strategy_func, params)
                fitness_scores.append(score)
            
            # En iyi parametreleri seç
            best_indices = np.argsort(fitness_scores)[-population_size//2:]
            survivors = [population[i] for i in best_indices]
            
            # Yeni nesil oluştur
            new_population = survivors.copy()
            while len(new_population) < population_size:
                parent1, parent2 = np.random.choice(survivors, 2, replace=False)
                child = self._crossover_mutate(parent1, parent2, parameter_space)
                new_population.append(child)
            
            population = new_population
        
        # En iyi parametreyi döndür
        final_scores = [await self._evaluate_strategy_params(strategy_func, p) for p in population]
        best_idx = np.argmax(final_scores)
        return population[best_idx]
    
    async def _grid_search_optimization(self, strategy_func, parameter_space):
        """Grid search optimizasyon"""
        # Grid search implementasyonu
        return parameter_space  # Simplified
    
    def _random_params(self, parameter_space):
        """Rastgele parametre oluştur"""
        params = {}
        for param_name, param_config in parameter_space.items():
            if param_config['type'] == 'uniform':
                params[param_name] = np.random.uniform(
                    param_config['low'], param_config['high']
                )
            elif param_config['type'] == 'choice':
                params[param_name] = np.random.choice(param_config['choices'])
        return params
    
    def _crossover_mutate(self, parent1, parent2, parameter_space):
        """Çaprazlama ve mutasyon"""
        child = {}
        for param_name in parameter_space.keys():
            if np.random.random() < 0.5:
                child[param_name] = parent1[param_name]
            else:
                child[param_name] = parent2[param_name]
            
            # Mutasyon
            if np.random.random() < 0.1:  # %10 mutasyon oranı
                param_config = parameter_space[param_name]
                if param_config['type'] == 'uniform':
                    child[param_name] = np.random.uniform(
                        param_config['low'], param_config['high']
                    )
                elif param_config['type'] == 'choice':
                    child[param_name] = np.random.choice(param_config['choices'])
        
        return child
    
    async def _evaluate_strategy_params(self, strategy_func, params):
        """Parametreler için strateji performansını değerlendir"""
        try:
            # Paralel değerlendirme
            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(strategy_func, params)
                result = await asyncio.wrap_future(future)
                return result.get('score', 0)
        except Exception as e:
            self.logger.error(f"Parametre değerlendirme hatası: {e}")
            return 0

class StrategyEvolution:
    """Strateji evrim yönetimi"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.evolution_history = []
        self.generation = 0
    
    async def evolve_strategies(
        self, 
        strategies: List[StrategyConfig], 
        evaluation_func: callable,
        generation_size: int = 50,
        elite_size: int = 10
    ) -> List[StrategyConfig]:
        """Stratejileri evrimsel süreçle geliştir"""
        
        try:
            self.generation += 1
            self.logger.info(f"Generation {self.generation} başlatılıyor...")
            
            # Mevcut stratejileri değerlendir
            evaluated_strategies = []
            for strategy in strategies:
                performance = await evaluation_func(strategy)
                evaluated_strategies.append((strategy, performance))
            
            # Performansa göre sırala
            evaluated_strategies.sort(key=lambda x: x[1].get('score', 0), reverse=True)
            
            # Elite stratejileri koru
            elite_strategies = [s[0] for s in evaluated_strategies[:elite_size]]
            
            # Yeni stratejiler üret
            new_strategies = await self._generate_new_strategies(
                elite_strategies, 
                generation_size - len(elite_strategies)
            )
            
            # Sonuç stratejileri
            evolved_strategies = elite_strategies + new_strategies
            
            # Evrim geçmişini kaydet
            self.evolution_history.append({
                'generation': self.generation,
                'best_score': evaluated_strategies[0][1].get('score', 0) if evaluated_strategies else 0,
                'strategies_count': len(evolved_strategies),
                'timestamp': datetime.now()
            })
            
            self.logger.info(f"Generation {self.generation} tamamlandı. En iyi skor: {evaluated_strategies[0][1].get('score', 0) if evaluated_strategies else 0}")
            
            return evolved_strategies
            
        except Exception as e:
            self.logger.error(f"Strateji evrimi hatası: {e}")
            return strategies
    
    async def _generate_new_strategies(
        self, 
        elite_strategies: List[StrategyConfig], 
        count: int
    ) -> List[StrategyConfig]:
        """Yeni stratejiler üret"""
        
        new_strategies = []
        
        for _ in range(count):
            # Rastgele elite stratejileri seç
            parent1, parent2 = np.random.choice(elite_strategies, 2, replace=False)
            
            # Çaprazlama
            new_strategy = self._crossover_strategies(parent1, parent2)
            
            # Mutasyon
            new_strategy = self._mutate_strategy(new_strategy)
            
            new_strategies.append(new_strategy)
        
        return new_strategies
    
    def _crossover_strategies(self, parent1: StrategyConfig, parent2: StrategyConfig) -> StrategyConfig:
        """Strateji çaprazlaması"""
        new_params = {}
        
        # Parametreleri karıştır
        for param_name in parent1.parameters.keys():
            if np.random.random() < 0.5:
                new_params[param_name] = parent1.parameters[param_name]
            else:
                new_params[param_name] = parent2.parameters[param_name]
        
        return StrategyConfig(
            strategy_id=f"gen_{self.generation}_{len(new_strategies)}",
            strategy_type=parent1.strategy_type,
            parameters=new_params,
            constraints=parent1.constraints,
            risk_limits=parent1.risk_limits,
            optimization_targets=parent1.optimization_targets
        )
    
    def _mutate_strategy(self, strategy: StrategyConfig) -> StrategyConfig:
        """Strateji mutasyonu"""
        
        mutated_params = strategy.parameters.copy()
        
        # Rastgele parametreleri mutasyona uğrat
        for param_name, param_value in mutated_params.items():
            if np.random.random() < 0.1:  # %10 mutasyon oranı
                if isinstance(param_value, (int, float)):
                    # Sayısal parametreler için küçük değişim
                    mutation_factor = np.random.normal(1.0, 0.1)
                    mutated_params[param_name] = param_value * mutation_factor
                elif isinstance(param_value, str):
                    # Kategorik parametreler için değişim
                    mutated_params[param_name] = f"{param_value}_mutated"
        
        strategy.parameters = mutated_params
        strategy.strategy_id = f"{strategy.strategy_id}_mutated"
        
        return strategy

class StrategyCalibrator:
    """Ana strateji kalibrasyon sınıfı"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Alt bileşenler
        self.performance_evaluator = PerformanceEvaluator()
        self.parameter_optimizer = ParameterOptimizer(
            config.get('optimization_method', 'bayesian')
        )
        self.strategy_evolution = StrategyEvolution()
        
        # Durum
        self.active_strategies = {}
        self.strategy_history = []
        self.calibration_status = "ready"
    
    async def calibrate_strategies(
        self, 
        strategies: List[StrategyConfig],
        market_data: pd.DataFrame,
        evaluation_period: int = 252
    ) -> Dict[str, StrategyMetrics]:
        """Ana kalibrasyon fonksiyonu"""
        
        try:
            self.logger.info(f"{len(strategies)} strateji kalibrasyona başlıyor...")
            self.calibration_status = "calibrating"
            
            # 1. Strateji performans değerlendirme
            self.logger.info("1. Strateji performansları değerlendiriliyor...")
            strategy_metrics = await self._evaluate_strategies(strategies, market_data)
            
            # 2. Dinamik parametre optimizasyonu
            self.logger.info("2. Parametreler optimize ediliyor...")
            optimized_strategies = await self._optimize_strategy_parameters(
                strategies, market_data
            )
            
            # 3. Strateji evrimi
            self.logger.info("3. Strateji evrimi uygulanıyor...")
            evolved_strategies = await self._evolve_strategies(
                optimized_strategies, market_data
            )
            
            # 4. Performans tabanlı kaynak tahsisi
            self.logger.info("4. Kaynak tahsisi yapılıyor...")
            allocation_plan = await self._allocate_resources(evolved_strategies, strategy_metrics)
            
            # Sonuçları güncelle
            self.active_strategies = {
                s.strategy_id: s for s in evolved_strategies
            }
            
            self.calibration_status = "completed"
            
            self.logger.info("Strateji kalibrasyonu tamamlandı.")
            
            return {
                'metrics': strategy_metrics,
                'allocation': allocation_plan,
                'evolved_strategies': evolved_strategies
            }
            
        except Exception as e:
            self.logger.error(f"Kalibrasyon hatası: {e}")
            self.calibration_status = "error"
            raise
    
    async def _evaluate_strategies(
        self, 
        strategies: List[StrategyConfig], 
        market_data: pd.DataFrame
    ) -> Dict[str, StrategyMetrics]:
        """Stratejileri değerlendir"""
        
        metrics = {}
        
        # Paralel değerlendirme
        tasks = []
        for strategy in strategies:
            task = self._evaluate_single_strategy(strategy, market_data)
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        for strategy, result in zip(strategies, results):
            if isinstance(result, Exception):
                self.logger.error(f"Strateji {strategy.strategy_id} değerlendirme hatası: {result}")
                metrics[strategy.strategy_id] = self._create_default_metrics(strategy)
            else:
                result.strategy_id = strategy.strategy_id
                metrics[strategy.strategy_id] = result
        
        return metrics
    
    async def _evaluate_single_strategy(
        self, 
        strategy: StrategyConfig, 
        market_data: pd.DataFrame
    ) -> StrategyMetrics:
        """Tek strateji değerlendirmesi"""
        
        try:
            # Basitleştirilmiş backtest simülasyonu
            returns = await self._simulate_strategy_returns(strategy, market_data)
            
            # Trade simülasyonu (basitleştirilmiş)
            trades = await self._simulate_trades(strategy, market_data)
            
            # Metrikleri hesapla
            metrics = self.performance_evaluator.calculate_metrics(returns, trades)
            
            return metrics
            
        except Exception as e:
            self.logger.error(f"Strateji değerlendirme hatası: {e}")
            return self._create_default_metrics(strategy)
    
    async def _simulate_strategy_returns(
        self, 
        strategy: StrategyConfig, 
        market_data: pd.DataFrame
    ) -> pd.Series:
        """Strateji için getiri simülasyonu"""
        
        # Basitleştirilmiş strateji simülasyonu
        np.random.seed(hash(strategy.strategy_id) % 2**32)
        
        # Rastgele getiri simülasyonu (gerçek implementasyonda strateji logic'i olacak)
        n_periods = len(market_data)
        returns = np.random.normal(0.001, 0.02, n_periods)  # Günlük getiri
        
        # Parametrelere göre ayarlama
        if 'volatility_target' in strategy.parameters:
            vol_target = strategy.parameters['volatility_target']
            returns = returns * (vol_target / np.std(returns)) * np.sqrt(252)
        
        return pd.Series(returns, index=market_data.index)
    
    async def _simulate_trades(
        self, 
        strategy: StrategyConfig, 
        market_data: pd.DataFrame
    ) -> pd.DataFrame:
        """Trade simülasyonu"""
        
        # Basitleştirilmiş trade simülasyonu
        n_trades = np.random.poisson(5)  # Ortalama 5 trade/gün
        
        trades = []
        for i in range(n_trades):
            entry_time = market_data.index[np.random.randint(0, len(market_data))]
            exit_time = market_data.index[min(
                np.random.randint(len(market_data)), 
                len(market_data) - 1
            )]
            
            pnl = np.random.normal(0.001, 0.01)  # Trade kar/zarar
            
            trades.append({
                'entry_time': entry_time,
                'exit_time': exit_time,
                'pnl': pnl
            })
        
        if trades:
            return pd.DataFrame(trades)
        else:
            return pd.DataFrame(columns=['entry_time', 'exit_time', 'pnl'])
    
    def _create_default_metrics(self, strategy: StrategyConfig) -> StrategyMetrics:
        """Varsayılan metrikler oluştur"""
        return StrategyMetrics(
            strategy_id=strategy.strategy_id,
            total_return=0.0,
            sharpe_ratio=0.0,
            max_drawdown=0.0,
            win_rate=0.0,
            profit_factor=0.0,
            calmar_ratio=0.0,
            sortino_ratio=0.0,
            var_95=0.0,
            expected_shortfall=0.0,
            win_loss_ratio=0.0,
            avg_trade_duration=0.0,
            total_trades=0,
            winning_trades=0,
            losing_trades=0
        )
    
    async def _optimize_strategy_parameters(
        self, 
        strategies: List[StrategyConfig], 
        market_data: pd.DataFrame
    ) -> List[StrategyConfig]:
        """Strateji parametrelerini optimize et"""
        
        optimized_strategies = []
        
        for strategy in strategies:
            try:
                # Parametre uzayını tanımla
                parameter_space = self._define_parameter_space(strategy)
                
                # Optimizasyon fonksiyonu
                async def eval_func(params):
                    test_strategy = StrategyConfig(
                        strategy_id=strategy.strategy_id,
                        strategy_type=strategy.strategy_type,
                        parameters=params,
                        constraints=strategy.constraints,
                        risk_limits=strategy.risk_limits,
                        optimization_targets=strategy.optimization_targets
                    )
                    
                    metrics = await self._evaluate_single_strategy(test_strategy, market_data)
                    return {'score': metrics.sharpe_ratio}
                
                # Optimizasyon çalıştır
                best_params = await self.parameter_optimizer.optimize_parameters(
                    eval_func, parameter_space
                )
                
                # Optimized strateji oluştur
                optimized_strategy = StrategyConfig(
                    strategy_id=strategy.strategy_id,
                    strategy_type=strategy.strategy_type,
                    parameters=best_params,
                    constraints=strategy.constraints,
                    risk_limits=strategy.risk_limits,
                    optimization_targets=strategy.optimization_targets
                )
                
                optimized_strategies.append(optimized_strategy)
                
            except Exception as e:
                self.logger.error(f"Parametre optimizasyonu hatası {strategy.strategy_id}: {e}")
                optimized_strategies.append(strategy)
        
        return optimized_strategies
    
    def _define_parameter_space(self, strategy: StrategyConfig) -> Dict[str, Any]:
        """Parametre uzayını tanımla"""
        
        # Basit parameter space tanımı
        parameter_space = {}
        
        for param_name, param_value in strategy.parameters.items():
            if isinstance(param_value, (int, float)):
                parameter_space[param_name] = {
                    'type': 'uniform',
                    'low': param_value * 0.5,
                    'high': param_value * 2.0
                }
            else:
                parameter_space[param_name] = {
                    'type': 'choice',
                    'choices': [param_value, f"{param_value}_alt"]
                }
        
        return parameter_space
    
    async def _evolve_strategies(
        self, 
        strategies: List[StrategyConfig], 
        market_data: pd.DataFrame
    ) -> List[StrategyConfig]:
        """Stratejileri evrimle"""
        
        try:
            # Değerlendirme fonksiyonu
            async def evaluation_func(strategy):
                metrics = await self._evaluate_single_strategy(strategy, market_data)
                return {
                    'score': metrics.sharpe_ratio,
                    'total_return': metrics.total_return,
                    'max_drawdown': metrics.max_drawdown
                }
            
            # Evrim uygula
            evolved_strategies = await self.strategy_evolution.evolve_strategies(
                strategies, evaluation_func
            )
            
            return evolved_strategies
            
        except Exception as e:
            self.logger.error(f"Strateji evrimi hatası: {e}")
            return strategies
    
    async def _allocate_resources(
        self, 
        strategies: List[StrategyConfig], 
        metrics: Dict[str, StrategyMetrics]
    ) -> Dict[str, float]:
        """Kaynak tahsisi planı"""
        
        # Performans tabanlı ağırlıklandırma
        total_score = 0
        scores = {}
        
        for strategy in strategies:
            strategy_metrics = metrics.get(strategy.strategy_id)
            if strategy_metrics:
                # Çoklu kriterli skor
                score = (
                    0.4 * strategy_metrics.sharpe_ratio +
                    0.3 * strategy_metrics.total_return +
                    0.2 * (1 + strategy_metrics.max_drawdown) +  # Düşük drawdown daha iyi
                    0.1 * strategy_metrics.win_rate
                )
                scores[strategy.strategy_id] = max(0, score)
                total_score += scores[strategy.strategy_id]
        
        # Normalize et ve kaynak tahsisi yap
        allocation = {}
        if total_score > 0:
            for strategy_id, score in scores.items():
                allocation[strategy_id] = score / total_score
        else:
            # Eşit dağıtım
            allocation = {s.strategy_id: 1.0 / len(strategies) for s in strategies}
        
        return allocation
    
    def get_calibration_status(self) -> Dict[str, Any]:
        """Kalibrasyon durumunu döndür"""
        return {
            'status': self.calibration_status,
            'active_strategies': len(self.active_strategies),
            'generation': self.strategy_evolution.generation,
            'last_update': datetime.now()
        }
    
    def get_strategy_history(self) -> List[Dict[str, Any]]:
        """Strateji geçmişini döndür"""
        return self.strategy_evolution.evolution_history