#!/usr/bin/env python3
"""
Sample Data Generator for Performance Monitoring System
Bu script sistemin test edilmesi için örnek veri oluşturur.
"""

import asyncio
import random
import json
from datetime import datetime, timezone, timedelta
from typing import List, Dict, Any
import logging

from database import get_database
from models import *
from analytics.performance_analyzer import get_performance_analyzer

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SampleDataGenerator:
    def __init__(self):
        self.db = None
        self.start_date = datetime.now(timezone.utc) - timedelta(days=30)
        self.performance_analyzer = get_performance_analyzer()
        
        # Sample data
        self.portfolios = ["portfolio_001", "portfolio_002", "portfolio_003"]
        self.strategies = [
            {"id": "momentum_001", "name": "Momentum Strategy", "type": "trend_following"},
            {"id": "mean_reversion_001", "name": "Mean Reversion", "type": "contrarian"},
            {"id": "pairs_trading_001", "name": "Pairs Trading", "type": "statistical_arbitrage"},
            {"id": "momentum_002", "name": "Short Term Momentum", "type": "intraday"},
        ]
        
    async def generate_all_data(self):
        """Tüm örnek verileri oluştur"""
        try:
            logger.info("Sample data generation başlatılıyor...")
            
            await self.create_tables()
            
            # Veri oluşturma sırası
            await self.generate_benchmark_data()
            await self.generate_pnl_data()
            await self.generate_portfolio_health_data()
            await self.generate_risk_metrics_data()
            await self.generate_strategy_performance_data()
            await self.generate_system_health_data()
            await self.generate_alert_rules()
            await self.generate_performance_attribution_data()
            await self.generate_latency_metrics()
            
            logger.info("✅ Sample data generation tamamlandı!")
            
        except Exception as e:
            logger.error(f"❌ Sample data generation hatası: {e}")
            raise

    async def create_tables(self):
        """Veritabanı tablolarını oluştur"""
        from database import create_tables
        await create_tables()
        logger.info("📊 Veritabanı tabloları oluşturuldu")

    async def generate_benchmark_data(self):
        """Benchmark verilerini oluştur"""
        logger.info("📈 Benchmark verileri oluşturuluyor...")
        
        benchmarks = ["SPY", "QQQ", "BTC-USD", "ETH-USD"]
        base_values = {"SPY": 450.0, "QQQ": 380.0, "BTC-USD": 45000.0, "ETH-USD": 3000.0}
        
        for i in range(30):  # 30 günlük veri
            timestamp = self.start_date + timedelta(days=i)
            
            for benchmark in benchmarks:
                # Random walk ile değer oluştur
                base_value = base_values[benchmark]
                change_percent = random.uniform(-3.0, 3.0)  # -3% ile +3% arası
                value = base_value * (1 + change_percent / 100)
                
                benchmark_data = BenchmarkData(
                    name=benchmark,
                    value=round(value, 2),
                    change_percent=round(change_percent, 2),
                    timestamp=timestamp
                )
                
                await self.save_benchmark_data(benchmark_data)
        
        logger.info(f"✅ {len(benchmarks)} * 30 = {len(benchmarks) * 30} benchmark verisi oluşturuldu")

    async def generate_pnl_data(self):
        """P&L verilerini oluştur"""
        logger.info("💰 P&L verileri oluşturuluyor...")
        
        total_records = 0
        
        for portfolio_id in self.portfolios:
            for strategy in self.strategies:
                strategy_id = strategy["id"]
                
                # Her strateji için son 30 günlük P&L verisi
                cumulative_pnl = 0
                
                for i in range(30):
                    timestamp = self.start_date + timedelta(days=i, hours=random.randint(9, 16))
                    
                    # Realistic P&L simulation
                    daily_return = random.uniform(-0.05, 0.08)  # -5% ile +8% arası
                    realized_pnl = random.uniform(500, 5000)
                    unrealized_pnl = random.uniform(-2000, 2000)
                    
                    cumulative_pnl += realized_pnl + unrealized_pnl
                    
                    pnl_data = PnLData(
                        portfolio_id=portfolio_id,
                        strategy_id=strategy_id,
                        realized_pnl=round(realized_pnl, 2),
                        unrealized_pnl=round(unrealized_pnl, 2),
                        total_pnl=round(realized_pnl + unrealized_pnl, 2),
                        daily_pnl=round(cumulative_pnl, 2),
                        percentage_change=round(daily_return * 100, 2),
                        timestamp=timestamp
                    )
                    
                    await self.save_pnl_data(pnl_data)
                    total_records += 1
        
        logger.info(f"✅ {total_records} P&L verisi oluşturuldu")

    async def generate_portfolio_health_data(self):
        """Portfolio sağlık verilerini oluştur"""
        logger.info("🏥 Portfolio sağlık verileri oluşturuluyor...")
        
        total_records = 0
        
        for portfolio_id in self.portfolios:
            base_value = random.uniform(800000, 1200000)  # $800K - $1.2M
            
            for i in range(30):
                timestamp = self.start_date + timedelta(days=i, hours=12)
                
                # Değer varyasyonu
                value_variation = random.uniform(-0.1, 0.1)  # ±10% varyasyon
                total_value = base_value * (1 + value_variation)
                
                # Balanced allocation simulation
                utilization_rate = random.uniform(0.2, 0.8)  # %20-%80 kullanım
                used_balance = total_value * utilization_rate
                available_balance = total_value - used_balance
                
                # Risk score calculation
                risk_factors = [
                    utilization_rate * 30,  # Yüksek kullanım = yüksek risk
                    abs(value_variation) * 50,  # Volatilite riski
                    random.uniform(0, 20)  # Diğer faktörler
                ]
                risk_score = sum(risk_factors)
                
                # Health status determination
                if risk_score < 30:
                    health_status = RiskLevel.LOW
                elif risk_score < 60:
                    health_status = RiskLevel.MEDIUM
                else:
                    health_status = RiskLevel.HIGH
                
                health_data = PortfolioHealth(
                    portfolio_id=portfolio_id,
                    total_value=round(total_value, 2),
                    available_balance=round(available_balance, 2),
                    used_balance=round(used_balance, 2),
                    utilization_rate=round(utilization_rate, 3),
                    risk_score=round(risk_score, 1),
                    health_status=health_status,
                    timestamp=timestamp
                )
                
                await self.save_portfolio_health_data(health_data)
                total_records += 1
        
        logger.info(f"✅ {total_records} portfolio sağlık verisi oluşturuldu")

    async def generate_risk_metrics_data(self):
        """Risk metriklerini oluştur"""
        logger.info("⚠️ Risk metrikleri oluşturuluyor...")
        
        total_records = 0
        
        for portfolio_id in self.portfolios:
            for i in range(30):
                timestamp = self.start_date + timedelta(days=i, hours=12)
                
                # Realistic risk metrics
                var_1d = random.uniform(5000, 25000)  # $5K - $25K
                var_5d = var_1d * random.uniform(2.0, 3.0)  # 5-günlük VaR
                
                beta = random.uniform(0.7, 1.5)  # Market'e duyarlılık
                alpha = random.uniform(-0.05, 0.08)  # Excess return
                
                sharpe_ratio = random.uniform(0.3, 2.5)
                sortino_ratio = sharpe_ratio * random.uniform(1.1, 1.8)
                
                max_drawdown = random.uniform(0.05, 0.25)  # %5 - %25
                volatility = random.uniform(0.15, 0.45)  # %15 - %45
                
                risk_metrics = RiskMetrics(
                    portfolio_id=portfolio_id,
                    var_1d=round(var_1d, 2),
                    var_5d=round(var_5d, 2),
                    beta=round(beta, 3),
                    alpha=round(alpha, 4),
                    sharpe_ratio=round(sharpe_ratio, 3),
                    sortino_ratio=round(sortino_ratio, 3),
                    max_drawdown=round(max_drawdown, 4),
                    volatility=round(volatility, 4),
                    timestamp=timestamp
                )
                
                await self.save_risk_metrics_data(risk_metrics)
                total_records += 1
        
        logger.info(f"✅ {total_records} risk metriği oluşturuldu")

    async def generate_strategy_performance_data(self):
        """Strateji performans verilerini oluştur"""
        logger.info("🎯 Strateji performans verileri oluşturuluyor...")
        
        total_records = 0
        
        for strategy in self.strategies:
            strategy_id = strategy["id"]
            
            # Strateji türüne göre performans karakteristikleri
            if strategy["type"] == "trend_following":
                total_return = random.uniform(0.10, 0.25)
                volatility = random.uniform(0.20, 0.35)
                win_rate = random.uniform(0.45, 0.60)
            elif strategy["type"] == "contrarian":
                total_return = random.uniform(0.05, 0.20)
                volatility = random.uniform(0.15, 0.30)
                win_rate = random.uniform(0.55, 0.70)
            elif strategy["type"] == "statistical_arbitrage":
                total_return = random.uniform(0.08, 0.18)
                volatility = random.uniform(0.10, 0.25)
                win_rate = random.uniform(0.60, 0.75)
            else:  # intraday
                total_return = random.uniform(0.15, 0.35)
                volatility = random.uniform(0.25, 0.50)
                win_rate = random.uniform(0.50, 0.65)
            
            # Calculate derived metrics
            annual_return = total_return * random.uniform(0.8, 1.2)
            sharpe_ratio = (annual_return / volatility) if volatility > 0 else 0
            max_drawdown = random.uniform(0.05, 0.20)
            profit_factor = win_rate / (1 - win_rate) * random.uniform(0.8, 1.4)
            
            # Trade statistics
            total_trades = random.randint(50, 500)
            winning_trades = int(total_trades * win_rate)
            losing_trades = total_trades - winning_trades
            
            # Random status (mostly active)
            status_options = [StrategyStatus.ACTIVE, StrategyStatus.ACTIVE, StrategyStatus.PAUSED]
            status = random.choice(status_options)
            
            performance_data = StrategyPerformance(
                strategy_id=strategy_id,
                name=strategy["name"],
                status=status,
                total_return=round(total_return, 4),
                annual_return=round(annual_return, 4),
                volatility=round(volatility, 4),
                sharpe_ratio=round(sharpe_ratio, 3),
                max_drawdown=round(max_drawdown, 4),
                win_rate=round(win_rate, 3),
                profit_factor=round(profit_factor, 2),
                total_trades=total_trades,
                winning_trades=winning_trades,
                losing_trades=losing_trades,
                timestamp=datetime.now(timezone.utc)
            )
            
            await self.save_strategy_performance_data(performance_data)
            total_records += 1
        
        logger.info(f"✅ {total_records} strateji performans verisi oluşturuldu")

    async def generate_system_health_data(self):
        """Sistem sağlık verilerini oluştur"""
        logger.info("🔧 Sistem sağlık verileri oluşturuluyor...")
        
        services = ["api_gateway", "database", "redis", "trading_engine", "risk_management", "data_feeds"]
        total_records = 0
        
        for service in services:
            for i in range(7):  # Son 7 gün
                timestamp = self.start_date + timedelta(days=i, hours=random.randint(0, 23))
                
                # Service-specific metrics
                if service == "database":
                    cpu_usage = random.uniform(30, 80)
                    memory_usage = random.uniform(40, 90)
                    network_latency = random.uniform(10, 100)
                elif service == "api_gateway":
                    cpu_usage = random.uniform(20, 60)
                    memory_usage = random.uniform(25, 70)
                    network_latency = random.uniform(50, 500)
                else:
                    cpu_usage = random.uniform(10, 50)
                    memory_usage = random.uniform(20, 60)
                    network_latency = random.uniform(20, 200)
                
                disk_usage = random.uniform(30, 70)
                error_rate = random.uniform(0, 5)
                uptime = random.uniform(86400, 604800)  # 1 day to 1 week
                
                # Status determination
                if cpu_usage > 90 or memory_usage > 95 or error_rate > 5:
                    status = "critical"
                elif cpu_usage > 70 or memory_usage > 80 or error_rate > 1:
                    status = "warning"
                else:
                    status = "healthy"
                
                health_data = SystemHealth(
                    service_name=service,
                    status=status,
                    cpu_usage=round(cpu_usage, 1),
                    memory_usage=round(memory_usage, 1),
                    disk_usage=round(disk_usage, 1),
                    network_latency=round(network_latency, 2),
                    error_rate=round(error_rate, 2),
                    uptime=round(uptime, 1),
                    timestamp=timestamp
                )
                
                await self.save_system_health_data(health_data)
                total_records += 1
        
        logger.info(f"✅ {total_records} sistem sağlık verisi oluşturuldu")

    async def generate_alert_rules(self):
        """Uyarı kurallarını oluştur"""
        logger.info("🚨 Uyarı kuralları oluşturuluyor...")
        
        alert_rules = [
            AlertRule(
                name="Yüksek Günlük Kayıp",
                description="Portfolio günlük kayıp eşiği aşıldı",
                metric_type=MetricType.PNL,
                threshold_value=-5.0,
                operator="lt",
                severity=AlertSeverity.HIGH,
                portfolio_id="*"
            ),
            AlertRule(
                name="Yüksek Volatilite",
                description="Portfolio volatilite eşiği aşıldı",
                metric_type=MetricType.VOLATILITY,
                threshold_value=0.30,
                operator="gt",
                severity=AlertSeverity.MEDIUM,
                portfolio_id="*"
            ),
            AlertRule(
                name="Yüksek VaR",
                description="1-günlük VaR eşiği aşıldı",
                metric_type=MetricType.VAR,
                threshold_value=10000.0,
                operator="gt",
                severity=AlertSeverity.HIGH,
                portfolio_id="*"
            ),
            AlertRule(
                name="Kritik Drawdown",
                description="Maksimum çekilme eşiği aşıldı",
                metric_type=MetricType.DRAWDOWN,
                threshold_value=0.20,
                operator="gt",
                severity=AlertSeverity.CRITICAL,
                portfolio_id="*"
            ),
            AlertRule(
                name="Yüksek Gecikme",
                description="Sistem gecikme eşiği aşıldı",
                metric_type=MetricType.LATENCY,
                threshold_value=1000.0,
                operator="gt",
                severity=AlertSeverity.MEDIUM
            ),
            AlertRule(
                name="Düşük Sharpe Oranı",
                description="Strateji Sharpe oranı düşük",
                metric_type=MetricType.SHARPE_RATIO,
                threshold_value=0.5,
                operator="lt",
                severity=AlertSeverity.MEDIUM,
                strategy_id="*"
            ),
            AlertRule(
                name="Yüksek Korelasyon",
                description="Asset korelasyon eşiği aşıldı",
                metric_type=MetricType.CORRELATION,
                threshold_value=0.9,
                operator="gt",
                severity=AlertSeverity.MEDIUM,
                portfolio_id="*"
            )
        ]
        
        for rule in alert_rules:
            await self.save_alert_rule(rule)
        
        logger.info(f"✅ {len(alert_rules)} uyarı kuralı oluşturuldu")

    async def generate_performance_attribution_data(self):
        """Performans katkı verilerini oluştur"""
        logger.info("📊 Performans katkı verileri oluşturuluyor...")
        
        for portfolio_id in self.portfolios:
            timestamp = datetime.now(timezone.utc)
            
            # Strategy contribution
            strategy_contribution = {}
            for strategy in self.strategies:
                contribution = random.uniform(-0.02, 0.05)
                strategy_contribution[strategy["id"]] = round(contribution, 4)
            
            # Sector contribution
            sector_contribution = {
                "Technology": round(random.uniform(-0.01, 0.03), 4),
                "Finance": round(random.uniform(-0.02, 0.02), 4),
                "Healthcare": round(random.uniform(-0.01, 0.04), 4),
                "Energy": round(random.uniform(-0.03, 0.01), 4)
            }
            
            # Asset contribution
            asset_contribution = {
                "AAPL": round(random.uniform(-0.01, 0.02), 4),
                "MSFT": round(random.uniform(-0.005, 0.025), 4),
                "GOOGL": round(random.uniform(-0.02, 0.015), 4),
                "AMZN": round(random.uniform(-0.015, 0.02), 4)
            }
            
            attribution_data = PerformanceAttribution(
                portfolio_id=portfolio_id,
                strategy_contribution=strategy_contribution,
                sector_contribution=sector_contribution,
                asset_contribution=asset_contribution,
                timing_contribution=round(random.uniform(-0.01, 0.02), 4),
                selection_contribution=round(random.uniform(-0.005, 0.025), 4),
                interaction_contribution=round(random.uniform(-0.005, 0.005), 4),
                total_return=round(random.uniform(0.05, 0.20), 4),
                benchmark_return=round(random.uniform(0.03, 0.15), 4),
                excess_return=round(random.uniform(-0.02, 0.10), 4),
                timestamp=timestamp
            )
            
            await self.save_performance_attribution_data(attribution_data)
        
        logger.info(f"✅ {len(self.portfolios)} performans katkı verisi oluşturuldu")

    async def generate_latency_metrics(self):
        """Latency metriklerini oluştur"""
        logger.info("⚡ Latency metrikleri oluşturuluyor...")
        
        services = ["api_gateway", "database", "trading_engine"]
        endpoints = ["health_check", "pnl_data", "portfolio_health", "risk_metrics"]
        
        total_records = 0
        
        for service in services:
            for endpoint in endpoints:
                for i in range(24):  # 24 saatlik veri
                    timestamp = datetime.now(timezone.utc) - timedelta(hours=i)
                    
                    base_latency = {
                        "api_gateway": {"health_check": 50, "pnl_data": 200, "portfolio_health": 150, "risk_metrics": 300},
                        "database": {"health_check": 10, "pnl_data": 100, "portfolio_health": 80, "risk_metrics": 120},
                        "trading_engine": {"health_check": 20, "pnl_data": 150, "portfolio_health": 100, "risk_metrics": 200}
                    }
                    
                    base = base_latency[service][endpoint]
                    variance = base * 0.5
                    
                    avg_latency = random.uniform(base - variance, base + variance)
                    
                    latency_data = LatencyMetrics(
                        service_name=service,
                        endpoint=endpoint,
                        avg_latency=round(avg_latency, 2),
                        p50_latency=round(avg_latency * 0.8, 2),
                        p95_latency=round(avg_latency * 1.3, 2),
                        p99_latency=round(avg_latency * 1.8, 2),
                        throughput_rps=round(random.uniform(10, 100), 2),
                        error_rate=round(random.uniform(0, 2), 2),
                        timestamp=timestamp
                    )
                    
                    await self.save_latency_metrics(latency_data)
                    total_records += 1
        
        logger.info(f"✅ {total_records} latency metriği oluşturuldu")

    # Database save methods
    async def save_pnl_data(self, data: PnLData):
        db = get_database()
        await db.execute("""
            INSERT INTO pnl_data (portfolio_id, strategy_id, realized_pnl, unrealized_pnl, 
                                total_pnl, daily_pnl, percentage_change, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.portfolio_id, data.strategy_id, data.realized_pnl,
            data.unrealized_pnl, data.total_pnl, data.daily_pnl,
            data.percentage_change, data.timestamp
        ))

    async def save_portfolio_health_data(self, data: PortfolioHealth):
        db = get_database()
        await db.execute("""
            INSERT INTO portfolio_health (portfolio_id, total_value, available_balance, 
                                        used_balance, utilization_rate, risk_score, 
                                        health_status, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.portfolio_id, data.total_value, data.available_balance,
            data.used_balance, data.utilization_rate, data.risk_score,
            data.health_status, data.timestamp
        ))

    async def save_risk_metrics_data(self, data: RiskMetrics):
        db = get_database()
        await db.execute("""
            INSERT INTO risk_metrics (portfolio_id, var_1d, var_5d, beta, alpha, 
                                    sharpe_ratio, sortino_ratio, max_drawdown, 
                                    volatility, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.portfolio_id, data.var_1d, data.var_5d,
            data.beta, data.alpha, data.sharpe_ratio,
            data.sortino_ratio, data.max_drawdown,
            data.volatility, data.timestamp
        ))

    async def save_strategy_performance_data(self, data: StrategyPerformance):
        db = get_database()
        await db.execute("""
            INSERT INTO strategy_performance (strategy_id, name, status, total_return,
                                            annual_return, volatility, sharpe_ratio,
                                            max_drawdown, win_rate, profit_factor,
                                            total_trades, winning_trades, losing_trades, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.strategy_id, data.name, data.status,
            data.total_return, data.annual_return, data.volatility,
            data.sharpe_ratio, data.max_drawdown, data.win_rate,
            data.profit_factor, data.total_trades, data.winning_trades,
            data.losing_trades, data.timestamp
        ))

    async def save_system_health_data(self, data: SystemHealth):
        db = get_database()
        await db.execute("""
            INSERT INTO system_health (service_name, status, cpu_usage, memory_usage,
                                     disk_usage, network_latency, error_rate, uptime, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.service_name, data.status, data.cpu_usage,
            data.memory_usage, data.disk_usage, data.network_latency,
            data.error_rate, data.uptime, data.timestamp
        ))

    async def save_alert_rule(self, data: AlertRule):
        db = get_database()
        await db.execute("""
            INSERT INTO alert_rules (name, description, metric_type, threshold_value,
                                   operator, severity, enabled, strategy_id, portfolio_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.name, data.description, data.metric_type, data.threshold_value,
            data.operator, data.severity, data.enabled, data.strategy_id,
            data.portfolio_id, data.created_at
        ))

    async def save_performance_attribution_data(self, data: PerformanceAttribution):
        db = get_database()
        await db.execute("""
            INSERT INTO performance_attribution (portfolio_id, strategy_contribution, sector_contribution,
                                               asset_contribution, timing_contribution, selection_contribution,
                                               interaction_contribution, total_return, benchmark_return,
                                               excess_return, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.portfolio_id, json.dumps(data.strategy_contribution),
            json.dumps(data.sector_contribution), json.dumps(data.asset_contribution),
            data.timing_contribution, data.selection_contribution,
            data.interaction_contribution, data.total_return, data.benchmark_return,
            data.excess_return, data.timestamp
        ))

    async def save_latency_metrics(self, data: LatencyMetrics):
        db = get_database()
        await db.execute("""
            INSERT INTO latency_metrics (service_name, endpoint, avg_latency, p50_latency,
                                       p95_latency, p99_latency, throughput_rps, error_rate, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.service_name, data.endpoint, data.avg_latency, data.p50_latency,
            data.p95_latency, data.p99_latency, data.throughput_rps, data.error_rate,
            data.timestamp
        ))

    async def save_benchmark_data(self, data: BenchmarkData):
        db = get_database()
        await db.execute("""
            INSERT INTO benchmark_data (name, value, change_percent, timestamp)
            VALUES (?, ?, ?, ?)
        """, (data.name, data.value, data.change_percent, data.timestamp))

async def main():
    """Ana fonksiyon"""
    generator = SampleDataGenerator()
    await generator.generate_all_data()
    
    print("\n🎉 Sample data generation completed successfully!")
    print("📊 Oluşturulan veriler:")
    print("   • 4 benchmark * 30 gün = 120 benchmark kaydı")
    print("   • 3 portfolio * 4 strateji * 30 gün = 360 P&L kaydı")
    print("   • 3 portfolio * 30 gün = 90 portfolio sağlık kaydı")
    print("   • 3 portfolio * 30 gün = 90 risk metriği kaydı")
    print("   • 4 strateji performans kaydı")
    print("   • 6 servis * 7 gün = 42 sistem sağlık kaydı")
    print("   • 7 uyarı kuralı")
    print("   • 3 performans katkı kaydı")
    print("   • 3 servis * 4 endpoint * 24 saat = 288 latency kaydı")
    print("\n🚀 Dashboard'a erişim: http://localhost:8000/dashboard")

if __name__ == "__main__":
    asyncio.run(main())