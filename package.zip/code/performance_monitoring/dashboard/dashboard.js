// Real-time Performance Monitoring Dashboard JavaScript

class PerformanceDashboard {
    constructor() {
        this.apiBaseUrl = 'http://localhost:8000';
        this.websocket = null;
        this.updateInterval = 5000; // 5 seconds
        this.charts = {};
        this.data = {
            pnlData: [],
            portfolioData: [],
            strategyData: [],
            riskData: [],
            systemData: [],
            alerts: []
        };
        
        this.init();
    }

    init() {
        this.connectWebSocket();
        this.setupEventListeners();
        this.initializeCharts();
        this.loadInitialData();
        
        // Set up periodic data refresh
        setInterval(() => this.refreshData(), this.updateInterval);
    }

    connectWebSocket() {
        try {
            this.websocket = new WebSocket('ws://localhost:8000/ws/realtime');
            
            this.websocket.onopen = (event) => {
                console.log('WebSocket connected');
                this.updateConnectionStatus(true);
            };
            
            this.websocket.onmessage = (event) => {
                const data = JSON.parse(event.data);
                if (data.type === 'real_time_update') {
                    this.updateDashboard(data.data);
                }
            };
            
            this.websocket.onclose = (event) => {
                console.log('WebSocket disconnected');
                this.updateConnectionStatus(false);
                
                // Attempt to reconnect after 5 seconds
                setTimeout(() => this.connectWebSocket(), 5000);
            };
            
            this.websocket.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.updateConnectionStatus(false);
            };
            
        } catch (error) {
            console.error('Failed to connect WebSocket:', error);
            this.updateConnectionStatus(false);
        }
    }

    updateConnectionStatus(connected) {
        const statusElement = document.getElementById('systemStatus');
        if (statusElement) {
            if (connected) {
                statusElement.innerHTML = `
                    <span class="status-indicator status-healthy"></span>
                    <span>WebSocket Bağlı</span>
                `;
            } else {
                statusElement.innerHTML = `
                    <span class="status-indicator status-warning"></span>
                    <span>WebSocket Bağlantısı Kesildi</span>
                `;
            }
        }
    }

    setupEventListeners() {
        // Tab change event
        document.querySelectorAll('[data-bs-toggle="tab"]').forEach(tab => {
            tab.addEventListener('shown.bs.tab', (event) => {
                const targetId = event.target.getAttribute('data-bs-target').substring(1);
                this.onTabChange(targetId);
            });
        });

        // Strategy filter
        const strategyFilter = document.getElementById('strategyFilter');
        if (strategyFilter) {
            strategyFilter.addEventListener('change', () => {
                this.filterStrategyData(strategyFilter.value);
            });
        }
    }

    async loadInitialData() {
        try {
            await Promise.all([
                this.loadPNLData(),
                this.loadPortfolioData(),
                this.loadStrategyData(),
                this.loadRiskData(),
                this.loadSystemData(),
                this.loadAlerts()
            ]);
        } catch (error) {
            console.error('Error loading initial data:', error);
        }
    }

    async loadPNLData() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/api/v1/pnl/test_portfolio`);
            if (response.ok) {
                this.data.pnlData = await response.json();
                this.updatePnLCard();
                this.updatePnLChart();
            }
        } catch (error) {
            console.error('Error loading P&L data:', error);
        }
    }

    async loadPortfolioData() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/api/v1/portfolio/test_portfolio/health`);
            if (response.ok) {
                this.data.portfolioData = await response.json();
                this.updatePortfolioCards();
                this.updatePortfolioCharts();
            }
        } catch (error) {
            console.error('Error loading portfolio data:', error);
        }
    }

    async loadStrategyData() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/api/v1/strategy/performance`);
            if (response.ok) {
                this.data.strategyData = await response.json();
                this.updateStrategyFilter();
                this.updateStrategyCharts();
                this.updateStrategyCards();
            }
        } catch (error) {
            console.error('Error loading strategy data:', error);
        }
    }

    async loadRiskData() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/api/v1/risk/metrics/test_portfolio`);
            if (response.ok) {
                this.data.riskData = await response.json();
                this.updateRiskCards();
                this.updateRiskCharts();
            }
        } catch (error) {
            console.error('Error loading risk data:', error);
        }
    }

    async loadSystemData() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/api/v1/system/health`);
            if (response.ok) {
                this.data.systemData = await response.json();
                this.updateSystemCards();
                this.updateSystemCharts();
            }
        } catch (error) {
            console.error('Error loading system data:', error);
        }
    }

    async loadAlerts() {
        try {
            const response = await fetch(`${this.apiBaseUrl}/api/v1/alerts?limit=50`);
            if (response.ok) {
                this.data.alerts = await response.json();
                this.renderAlerts();
            }
        } catch (error) {
            console.error('Error loading alerts:', error);
        }
    }

    updateDashboard(data) {
        if (data.pnl_data) {
            this.updateKeyMetrics(data);
            this.updateCharts(data);
        }
        
        this.updateLastUpdateTime();
    }

    updateKeyMetrics(data) {
        // Update daily P&L
        if (data.pnl_data && data.pnl_data.length > 0) {
            const latestPnL = data.pnl_data[0];
            const dailyPnL = latestPnL.data.daily_pnl || 0;
            const dailyChange = latestPnL.data.percentage_change || 0;
            
            document.getElementById('dailyPnL').textContent = this.formatCurrency(dailyPnL);
            document.getElementById('dailyPnLChange').textContent = `${dailyChange >= 0 ? '+' : ''}${dailyChange.toFixed(2)}%`;
            document.getElementById('dailyPnL').className = `performance-indicator ${dailyPnL >= 0 ? 'positive' : 'negative'}`;
        }

        // Update portfolio value
        if (data.portfolio_health && data.portfolio_health.length > 0) {
            const portfolio = data.portfolio_health[0];
            const totalValue = portfolio.data.total_value || 0;
            
            document.getElementById('portfolioValue').textContent = this.formatCurrency(totalValue);
        }

        // Update risk score
        if (data.risk_metrics) {
            const riskScore = data.risk_metrics.risk_score || 0;
            document.getElementById('riskScore').textContent = riskScore.toFixed(1);
            
            const riskStatus = document.getElementById('riskStatus');
            if (riskScore < 30) {
                riskStatus.textContent = 'Düşük';
                riskStatus.className = 'text-success';
            } else if (riskScore < 60) {
                riskStatus.textContent = 'Orta';
                riskStatus.className = 'text-warning';
            } else {
                riskStatus.textContent = 'Yüksek';
                riskStatus.className = 'text-danger';
            }
        }

        // Update system status
        if (data.system_health && data.system_health.length > 0) {
            const system = data.system_health[0];
            const status = system.status || 'unknown';
            const uptime = system.uptime || 0;
            
            const statusElement = document.getElementById('systemStatus');
            const statusClass = status === 'healthy' ? 'status-healthy' : 'status-warning';
            const statusText = status === 'healthy' ? 'Sistem Sağlıklı' : 'Sistem Uyarı';
            
            statusElement.innerHTML = `
                <span class="status-indicator ${statusClass}"></span>
                <span>${statusText}</span>
            `;
            
            document.getElementById('systemUptime').textContent = `Çalışma Süresi: ${this.formatUptime(uptime)}`;
        }
    }

    updateLastUpdateTime() {
        const now = new Date();
        document.getElementById('lastUpdate').textContent = `Son Güncelleme: ${now.toLocaleTimeString('tr-TR')}`;
    }

    updatePnLCard() {
        // Implementation for P&L card updates
    }

    updatePortfolioCards() {
        const portfolio = this.data.portfolioData;
        if (portfolio) {
            document.getElementById('availableBalance').textContent = this.formatCurrency(portfolio.available_balance);
            document.getElementById('usedBalance').textContent = this.formatCurrency(portfolio.used_balance);
            
            const utilization = (portfolio.utilization_rate * 100).toFixed(1);
            document.getElementById('utilizationBar').style.width = `${utilization}%`;
            document.getElementById('utilizationText').textContent = `${utilization}%`;
            
            // Set progress bar color based on utilization
            const bar = document.getElementById('utilizationBar');
            bar.className = 'progress-bar';
            if (utilization < 70) {
                bar.classList.add('bg-success');
            } else if (utilization < 90) {
                bar.classList.add('bg-warning');
            } else {
                bar.classList.add('bg-danger');
            }
        }
    }

    updateRiskCards() {
        const risk = this.data.riskData;
        if (risk) {
            document.getElementById('var1d').textContent = this.formatCurrency(risk.var_1d);
            document.getElementById('var5d').textContent = this.formatCurrency(risk.var_5d);
            document.getElementById('maxDrawdown').textContent = `${(risk.max_drawdown * 100).toFixed(2)}%`;
            document.getElementById('currentDrawdown').textContent = `${(risk.max_drawdown * 0.5 * 100).toFixed(2)}%`; // Mock current drawdown
        }
    }

    updateSystemCards() {
        const system = this.data.systemData;
        if (system && system.length > 0) {
            const latest = system[0];
            document.getElementById('systemUptime').textContent = `Çalışma Süresi: ${this.formatUptime(latest.uptime)}`;
        }
    }

    updateStrategyCards() {
        const strategies = this.data.strategyData;
        if (strategies && strategies.length > 0) {
            const container = document.getElementById('strategyDetailsRow');
            container.innerHTML = '';
            
            strategies.slice(0, 4).forEach(strategy => {
                const card = document.createElement('div');
                card.className = 'col-md-3';
                card.innerHTML = `
                    <div class="card">
                        <div class="card-body">
                            <h6>${strategy.name}</h6>
                            <div class="row">
                                <div class="col-6">
                                    <small>Toplam Getiri</small>
                                    <div class="text-${strategy.total_return >= 0 ? 'success' : 'danger'}">
                                        ${(strategy.total_return * 100).toFixed(2)}%
                                    </div>
                                </div>
                                <div class="col-6">
                                    <small>Sharpe Ratio</small>
                                    <div>${strategy.sharpe_ratio.toFixed(2)}</div>
                                </div>
                            </div>
                            <div class="mt-2">
                                <small>Durum: <span class="badge bg-${strategy.status === 'active' ? 'success' : 'secondary'}">
                                    ${strategy.status === 'active' ? 'Aktif' : 'Pasif'}
                                </span></small>
                            </div>
                        </div>
                    </div>
                `;
                container.appendChild(card);
            });
        }
    }

    initializeCharts() {
        // Initialize all charts
        this.initPnLChart();
        this.initRiskChart();
        this.initPortfolioHealthChart();
        this.initStrategyPerformanceChart();
        this.initVarChart();
        this.initDrawdownChart();
        this.initCorrelationMatrix();
        this.initSystemHealthChart();
        this.initLatencyChart();
        this.initResourceUsageChart();
    }

    initPnLChart() {
        const layout = {
            title: 'P&L Trendi',
            xaxis: { title: 'Zaman' },
            yaxis: { title: 'P&L ($)' },
            showlegend: false
        };
        
        Plotly.newPlot('pnlChart', [], layout, {responsive: true});
        this.charts.pnl = document.getElementById('pnlChart');
    }

    initRiskChart() {
        const layout = {
            title: 'Risk Metrikleri',
            xaxis: { title: 'Metrik' },
            yaxis: { title: 'Değer' },
            showlegend: true
        };
        
        Plotly.newPlot('riskChart', [], layout, {responsive: true});
        this.charts.risk = document.getElementById('riskChart');
    }

    initPortfolioHealthChart() {
        const data = [{
            type: 'indicator',
            mode: 'gauge+number',
            value: 0,
            domain: {x: [0, 1], y: [0, 1]},
            title: {text: 'Portföy Sağlık Skoru'},
            gauge: {
                axis: {range: [null, 100]},
                bar: {color: '#28a745'},
                steps: [
                    {range: [0, 50], color: '#dc3545'},
                    {range: [50, 80], color: '#ffc107'},
                    {range: [80, 100], color: '#28a745'}
                ],
                threshold: {
                    line: {color: 'red', width: 4},
                    thickness: 0.75,
                    value: 90
                }
            }
        }];
        
        const layout = {width: 300, height: 300};
        Plotly.newPlot('portfolioHealthChart', data, layout, {responsive: true});
        this.charts.portfolioHealth = document.getElementById('portfolioHealthChart');
    }

    initStrategyPerformanceChart() {
        const layout = {
            title: 'Strateji Performans Karşılaştırması',
            xaxis: { title: 'Strateji' },
            yaxis: { title: 'Toplam Getiri (%)' },
            barmode: 'group'
        };
        
        Plotly.newPlot('strategyPerformanceChart', [], layout, {responsive: true});
        this.charts.strategy = document.getElementById('strategyPerformanceChart');
    }

    initVarChart() {
        const data = [{
            type: 'bar',
            x: ['1 Günlük VaR', '5 Günlük VaR', 'Expected Shortfall'],
            y: [0, 0, 0],
            marker: {color: '#dc3545'}
        }];
        
        const layout = {
            title: 'VaR Analizi',
            xaxis: { title: 'Metrik' },
            yaxis: { title: 'Değer ($)' }
        };
        
        Plotly.newPlot('varChart', data, layout, {responsive: true});
        this.charts.var = document.getElementById('varChart');
    }

    initDrawdownChart() {
        const layout = {
            title: 'Drawdown Analizi',
            xaxis: { title: 'Zaman' },
            yaxis: { title: 'Drawdown (%)' },
            showlegend: false
        };
        
        Plotly.newPlot('drawdownChart', [], layout, {responsive: true});
        this.charts.drawdown = document.getElementById('drawdownChart');
    }

    initCorrelationMatrix() {
        const data = [{
            type: 'heatmap',
            z: [[0]], // Will be updated with real data
            colorscale: 'RdBu'
        }];
        
        const layout = {
            title: 'Korelasyon Matrisi',
            xaxis: {title: 'Varlıklar'},
            yaxis: {title: 'Varlıklar'}
        };
        
        Plotly.newPlot('correlationMatrix', data, layout, {responsive: true});
        this.charts.correlation = document.getElementById('correlationMatrix');
    }

    initSystemHealthChart() {
        const layout = {
            title: 'Sistem Sağlık Durumu',
            xaxis: { title: 'Servis' },
            yaxis: { title: 'Durum' }
        };
        
        Plotly.newPlot('systemHealthChart', [], layout, {responsive: true});
        this.charts.system = document.getElementById('systemHealthChart');
    }

    initLatencyChart() {
        const layout = {
            title: 'Latency Analizi',
            xaxis: { title: 'Endpoint' },
            yaxis: { title: 'Gecikme (ms)' }
        };
        
        Plotly.newPlot('latencyChart', [], layout, {responsive: true});
        this.charts.latency = document.getElementById('latencyChart');
    }

    initResourceUsageChart() {
        const data = [
            {x: [], y: [], type: 'bar', name: 'CPU (%)'},
            {x: [], y: [], type: 'bar', name: 'Memory (%)'},
            {x: [], y: [], type: 'bar', name: 'Disk (%)'}
        ];
        
        const layout = {
            title: 'Kaynak Kullanımı',
            xaxis: { title: 'Servis' },
            yaxis: { title: 'Kullanım (%)' }
        };
        
        Plotly.newPlot('resourceUsageChart', data, layout, {responsive: true});
        this.charts.resource = document.getElementById('resourceUsageChart');
    }

    updateCharts(data) {
        this.updatePnLChart();
        this.updateRiskChart();
    }

    updatePnLChart() {
        // Mock P&L data - would be replaced with real data
        const times = [];
        const values = [];
        const now = new Date();
        
        for (let i = 23; i >= 0; i--) {
            const time = new Date(now.getTime() - i * 60 * 60 * 1000);
            times.push(time.toLocaleTimeString('tr-TR', {hour: '2-digit', minute: '2-digit'}));
            values.push(Math.random() * 10000 - 5000); // Random P&L values
        }
        
        const trace = {
            x: times,
            y: values,
            type: 'scatter',
            mode: 'lines+markers',
            marker: {color: values.map(v => v >= 0 ? '#28a745' : '#dc3545')},
            line: {color: '#007bff'}
        };
        
        Plotly.react('pnlChart', [trace], this.charts.pnl.layout);
    }

    updateRiskChart() {
        const metrics = ['Sharpe', 'Sortino', 'Calmar', 'VaR', 'Max DD'];
        const values = [0.8, 0.6, 0.4, 0.7, 0.3]; // Mock risk values
        
        const trace = {
            x: metrics,
            y: values,
            type: 'bar',
            marker: {color: values.map(v => v >= 0.5 ? '#28a745' : '#ffc107')}
        };
        
        Plotly.react('riskChart', [trace], this.charts.risk.layout);
    }

    updatePortfolioCharts() {
        // Update portfolio performance chart
        const times = [];
        const values = [];
        const now = new Date();
        
        for (let i = 29; i >= 0; i--) {
            const time = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
            times.push(time.toLocaleDateString('tr-TR'));
            values.push(1000000 + Math.random() * 100000 - 50000);
        }
        
        const trace = {
            x: times,
            y: values,
            type: 'scatter',
            mode: 'lines',
            line: {color: '#007bff'}
        };
        
        Plotly.react('portfolioPerformanceChart', [trace], {responsive: true});
    }

    updateStrategyCharts() {
        const strategies = this.data.strategyData;
        if (strategies && strategies.length > 0) {
            const trace = {
                x: strategies.map(s => s.name),
                y: strategies.map(s => s.total_return * 100),
                type: 'bar',
                marker: {
                    color: strategies.map(s => s.total_return >= 0 ? '#28a745' : '#dc3545')
                }
            };
            
            Plotly.react('strategyPerformanceChart', [trace], this.charts.strategy.layout);
        }
    }

    updateRiskCharts() {
        // Update VaR chart
        if (this.data.riskData) {
            const varData = [{
                x: ['1 Günlük VaR', '5 Günlük VaR', 'Expected Shortfall'],
                y: [
                    this.data.riskData.var_1d,
                    this.data.riskData.var_5d,
                    this.data.riskData.var_1d * 1.5 // Mock ES
                ],
                type: 'bar',
                marker: {color: '#dc3545'}
            }];
            
            Plotly.react('varChart', varData, this.charts.var.layout);
        }
        
        // Update drawdown chart
        const times = [];
        const drawdowns = [];
        const now = new Date();
        
        for (let i = 29; i >= 0; i--) {
            const time = new Date(now.getTime() - i * 24 * 60 * 60 * 1000);
            times.push(time.toLocaleDateString('tr-TR'));
            drawdowns.push(Math.random() * -15); // Negative drawdown values
        }
        
        const drawdownTrace = {
            x: times,
            y: drawdowns,
            type: 'scatter',
            mode: 'lines',
            fill: 'tonexty',
            line: {color: '#dc3545'}
        };
        
        Plotly.react('drawdownChart', [drawdownTrace], this.charts.drawdown.layout);
    }

    updateSystemCharts() {
        const system = this.data.systemData;
        if (system && system.length > 0) {
            const services = system.map(s => s.service_name);
            const cpuUsage = system.map(s => s.cpu_usage);
            const memoryUsage = system.map(s => s.memory_usage);
            const diskUsage = system.map(s => s.disk_usage);
            
            const traces = [
                {
                    x: services,
                    y: cpuUsage,
                    type: 'bar',
                    name: 'CPU (%)',
                    marker: {color: '#007bff'}
                },
                {
                    x: services,
                    y: memoryUsage,
                    type: 'bar',
                    name: 'Memory (%)',
                    marker: {color: '#28a745'}
                },
                {
                    x: services,
                    y: diskUsage,
                    type: 'bar',
                    name: 'Disk (%)',
                    marker: {color: '#ffc107'}
                }
            ];
            
            Plotly.react('resourceUsageChart', traces, this.charts.resource.layout);
        }
    }

    updateStrategyFilter() {
        const filter = document.getElementById('strategyFilter');
        if (filter && this.data.strategyData) {
            // Clear existing options except the first one
            while (filter.children.length > 1) {
                filter.removeChild(filter.lastChild);
            }
            
            // Add strategy options
            this.data.strategyData.forEach(strategy => {
                const option = document.createElement('option');
                option.value = strategy.strategy_id;
                option.textContent = strategy.name;
                filter.appendChild(option);
            });
        }
    }

    filterStrategyData(strategyId) {
        // Implementation for filtering strategy data
        console.log('Filtering strategies by:', strategyId);
    }

    renderAlerts() {
        const container = document.getElementById('alertsList');
        if (!container) return;
        
        if (!this.data.alerts || this.data.alerts.length === 0) {
            container.innerHTML = '<div class="alert alert-success">Aktif uyarı bulunmuyor.</div>';
            return;
        }
        
        let html = '';
        this.data.alerts.forEach(alert => {
            const severityClass = {
                'low': 'alert-info',
                'medium': 'alert-warning',
                'high': 'alert-danger',
                'critical': 'alert-danger'
            }[alert.severity] || 'alert-secondary';
            
            const time = new Date(alert.created_at).toLocaleString('tr-TR');
            
            html += `
                <div class="alert ${severityClass} alert-dismissible fade show" role="alert">
                    <strong>${alert.severity.toUpperCase()}:</strong> ${alert.message}
                    <br><small class="text-muted">${time}</small>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            `;
        });
        
        container.innerHTML = html;
    }

    onTabChange(tabId) {
        // Initialize charts when tab becomes visible
        switch (tabId) {
            case 'portfolio':
                if (this.data.portfolioData) {
                    this.updatePortfolioCharts();
                }
                break;
            case 'strategies':
                if (this.data.strategyData) {
                    this.updateStrategyCharts();
                }
                break;
            case 'risk':
                if (this.data.riskData) {
                    this.updateRiskCharts();
                }
                break;
            case 'system':
                if (this.data.systemData) {
                    this.updateSystemCharts();
                }
                break;
        }
    }

    formatCurrency(value) {
        return new Intl.NumberFormat('tr-TR', {
            style: 'currency',
            currency: 'USD'
        }).format(value);
    }

    formatUptime(seconds) {
        const hours = Math.floor(seconds / 3600);
        const minutes = Math.floor((seconds % 3600) / 60);
        return `${hours}s ${minutes}d`;
    }
}

// Global functions
function refreshAlerts() {
    if (window.dashboard) {
        window.dashboard.loadAlerts();
    }
}

// Initialize dashboard when page loads
document.addEventListener('DOMContentLoaded', function() {
    window.dashboard = new PerformanceDashboard();
});