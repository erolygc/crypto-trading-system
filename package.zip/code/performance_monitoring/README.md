# Real-Time Performance Monitoring Sistemi

**🚀 Kapsamlı Trading Portföy İzleme ve Analiz Platformu**

## 📊 Hızlı Bakış

Bu sistem, trading portföylerinin ve stratejilerin performansını gerçek zamanlı olarak izleyen, risk metriklerini analiz eden ve sistem sağlığını monitör eden entegre bir platformdur.

### ✨ Ana Özellikler

- 🔄 **Real-time P&L Tracking** - Anlık kar/zarar takibi
- 💹 **Portfolio Health Monitoring** - Portföy sağlık durumu izleme  
- 📈 **Strategy Performance Dashboards** - Strateji performans panoları
- ⚠️ **Risk Metrics Monitoring** - Kapsamlı risk analizi
- 🔧 **System Health Monitoring** - Sistem sağlık göstergeleri
- 🚨 **Smart Alert Management** - Akıllı uyarı sistemi
- 📊 **Performance Attribution** - Performans katkı analizi
- 📊 **Benchmark Comparison** - Benchmark karşılaştırmaları
- 📉 **Volatility & Drawdown Tracking** - Volatilite ve çekilme takibi
- 🔗 **Correlation Analysis** - Korelasyon analizi
- ⚡ **Latency Monitoring** - Gecikme ve throughput izleme

## 🚀 Hızlı Başlangıç

### Gereksinimler
```bash
Python 3.8+
Redis Server
```

### Kurulum
```bash
# Repository'yi klonlayın
git clone <repository-url>
cd performance_monitoring

# Bağımlılıkları yükleyin
pip install -r requirements.txt

# Veritabanını kurun
python run.py db migrate

# Sistem testini çalıştırın
python run.py test

# API sunucusunu başlatın
python run.py server

# Monitoring servislerini başlatın (yeni terminal)
python run.py monitor
```

### Dashboard Erişimi
Tarayıcınızda `http://localhost:8000/dashboard` adresine gidin.

## 📁 Proje Yapısı

```
performance_monitoring/
├── 📡 api/                    # FastAPI backend
├── 🗃️ models/                 # Veri modelleri  
├── 💾 database/               # Veritabanı işlemleri
├── 🚨 alerts/                 # Uyarı yönetimi
├── 📊 analytics/              # Analiz motorları
├── 🖥️ dashboard/              # Web dashboard
├── 🛠️ utils/                  # Yardımcı araçlar
├── 🧪 tests/                  # Test dosyaları
├── ⚙️ config.py               # Konfigürasyon
└── 🏃 run.py                  # Ana çalıştırma scripti
```

## 📡 API Örnekleri

### P&L Verisi Oluşturma
```bash
curl -X POST "http://localhost:8000/api/v1/pnl" \
  -H "Content-Type: application/json" \
  -d '{
    "portfolio_id": "portfolio_001",
    "strategy_id": "momentum_001",
    "realized_pnl": 1000.0,
    "unrealized_pnl": 500.0,
    "total_pnl": 1500.0,
    "daily_pnl": 1500.0,
    "percentage_change": 1.5
  }'
```

### Portfolio Sağlık Kontrolü
```bash
curl "http://localhost:8000/api/v1/portfolio/portfolio_001/health"
```

### Risk Metrikleri
```bash
curl "http://localhost:8000/api/v1/risk/metrics/portfolio_001"
```

## 🔌 WebSocket Bağlantısı

```javascript
// Real-time veri akışı
const ws = new WebSocket('ws://localhost:8000/ws/realtime');

ws.onmessage = function(event) {
    const data = JSON.parse(event.data);
    console.log('Real-time update:', data);
};

// Strateji-specific veri
const strategyWs = new WebSocket('ws://localhost:8000/ws/strategy/momentum_001');
```

## 📊 Dashboard Özellikleri

- **📈 Real-time Charts** - Canlı grafikler
- **🎯 KPI Widgets** - Anahtar performans göstergeleri  
- **⚠️ Alert Center** - Uyarı merkezi
- **📱 Responsive Design** - Mobil uyumlu tasarım
- **🎨 Interactive Visualizations** - Etkileşimli görselleştirmeler

## ⚠️ Uyarı Sistemi

Sistem aşağıdaki durumlar için otomatik uyarılar oluşturur:

- **🔴 Yüksek Günlük Kayıp** - %5+ günlük kayıp
- **📊 Yüksek Volatilite** - %30+ yıllık volatilite  
- **💰 Yüksek VaR** - $10,000+ 1-günlük VaR
- **📉 Kritik Drawdown** - %20+ maksimum çekilme
- **⚡ Yüksek Gecikme** - 1s+ sistem gecikmesi
- **📈 Düşük Sharpe** - 0.5 altı Sharpe oranı

## 🧪 Test

```bash
# Tüm testleri çalıştır
python run.py test

# Belirli test kategorisi
pytest tests/test_performance_monitoring.py::TestPerformanceAnalyzer -v

# Coverage raporu
pytest --cov=api tests/ --cov-report=html
```

## ⚙️ Konfigürasyon

### Environment Variables
```bash
# API Ayarları
API_HOST=0.0.0.0
API_PORT=8000
API_DEBUG=true

# Veritabanı
DATABASE_URL=sqlite:///./performance_monitoring.db

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379

# Uyarı Eşikleri
VAR_THRESHOLD=10000.0
MAX_DRAWDOWN_THRESHOLD=0.20
DAILY_LOSS_CRITICAL_THRESHOLD=5.0

# Sistem İzleme
MONITORING_INTERVAL=60
DATA_RETENTION_DAYS=90
```

## 📈 Performance Metrikleri

### Hesaplanan Metrikler
- **📊 Sharpe Ratio** - Risk-adjusted return
- **📉 Sortino Ratio** - Downside risk adjusted return
- **📈 Calmar Ratio** - Return vs maximum drawdown
- **💰 Value at Risk (VaR)** - Potential loss estimation
- **📊 Expected Shortfall** - Conditional VaR
- **📉 Maximum Drawdown** - Peak-to-trough decline
- **🔗 Beta & Alpha** - Risk and excess return
- **📊 Information Ratio** - Active return vs tracking error

## 🔧 Troubleshooting

### Yaygın Sorunlar

**Database Connection Error:**
```bash
# Veritabanını yeniden oluştur
python run.py db migrate
```

**Redis Connection Failed:**
```bash
# Redis servisini başlat
redis-server
```

**High Memory Usage:**
```python
# config.py'de ayarları değiştirin
MONITORING_INTERVAL = 120  # 2 dakika
DATA_RETENTION_DAYS = 30   # 30 gün
```

### Log Analizi
```bash
# Hataları bul
grep "ERROR" performance_monitoring.log

# WebSocket sorunlarını bul  
grep "WebSocket" performance_monitoring.log

# Performance sorunlarını bul
grep "slow" performance_monitoring.log
```

## 📚 Dokümantasyon

Detaylı dokümantasyon için [`docs/performance_monitoring.md`](docs/performance_monitoring.md) dosyasını inceleyin.

## 🎯 Kullanım Senaryoları

### Portfolio Manager
- Günlük P&L takibi
- Risk metrikleri izleme  
- Strateji performans karşılaştırması
- Benchmark analizi

### Risk Manager
- VaR ve Expected Shortfall hesaplama
- Korelasyon analizi
- Drawdown monitoring
- Risk alert yönetimi

### System Administrator
- Sistem sağlığı izleme
- API performance monitoring
- Latency ve throughput analizi
- Resource utilization tracking

## 🔮 Roadmap

### v1.1.0 (Gelecek)
- [ ] Machine Learning entegrasyonu
- [ ] Anomali tespiti
- [ ] Mobile app desteği
- [ ] Cloud deployment

### v1.2.0 
- [ ] Advanced analytics
- [ ] Factor analysis
- [ ] Stress testing
- [ ] Third-party integrations

## 🤝 Katkıda Bulunma

1. Repository'yi fork edin
2. Feature branch oluşturun (`git checkout -b feature/amazing-feature`)
3. Değişikliklerinizi commit edin (`git commit -m 'Add amazing feature'`)
4. Branch'inizi push edin (`git push origin feature/amazing-feature`)
5. Pull Request oluşturun

## 📄 Lisans

Bu proje MIT lisansı altında lisanslanmıştır.

## 📞 İletişim

- **GitHub**: [Repository Link](https://github.com/your-username/performance-monitoring)
- **Email**: support@your-company.com
- **Documentation**: [Detaylı Dokümantasyon](docs/performance_monitoring.md)

---

**⭐ Bu projeyi beğendiyseniz yıldız vermeyi unutmayın!**