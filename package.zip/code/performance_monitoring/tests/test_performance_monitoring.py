import pytest
import asyncio
import json
from datetime import datetime, timezone
from fastapi.testclient import TestClient
from unittest.mock import patch, MagicMock

# Import our modules
from api.main import app
from models import *
from database import get_database, create_tables
from alerts.alert_manager import AlertManager
from analytics.performance_analyzer import PerformanceAnalyzer
from analytics.risk_analyzer import RiskAnalyzer
from analytics.system_monitor import SystemMonitor

# Test client
client = TestClient(app)

class TestPerformanceMonitoringAPI:
    @pytest.fixture
    async def setup_test_db(self):
        """Setup test database"""
        await create_tables()
        yield
        # Cleanup would go here
    
    def test_health_check(self):
        """Test health check endpoint"""
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"
        assert "timestamp" in data
    
    def test_get_pnl_data(self):
        """Test P&L data retrieval"""
        response = client.get("/api/v1/pnl/test_portfolio")
        # Should return empty list initially
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
    
    def test_get_portfolio_health(self):
        """Test portfolio health retrieval"""
        response = client.get("/api/v1/portfolio/test_portfolio/health")
        # Should return 404 initially
        assert response.status_code == 404
    
    def test_get_risk_metrics(self):
        """Test risk metrics retrieval"""
        response = client.get("/api/v1/risk/metrics/test_portfolio")
        # Should return 404 initially
        assert response.status_code == 404
    
    def test_get_system_health(self):
        """Test system health retrieval"""
        response = client.get("/api/v1/system/health")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
    
    def test_get_strategy_performance(self):
        """Test strategy performance retrieval"""
        response = client.get("/api/v1/strategy/performance")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
    
    def test_get_alert_rules(self):
        """Test alert rules retrieval"""
        response = client.get("/api/v1/alerts/rules")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
    
    def test_get_alerts(self):
        """Test alerts retrieval"""
        response = client.get("/api/v1/alerts?limit=10")
        assert response.status_code == 200
        data = response.json()
        assert isinstance(data, list)
    
    @pytest.mark.asyncio
    async def test_create_pnl_data(self):
        """Test P&L data creation"""
        pnl_data = {
            "portfolio_id": "test_portfolio",
            "strategy_id": "test_strategy",
            "realized_pnl": 1000.0,
            "unrealized_pnl": 500.0,
            "total_pnl": 1500.0,
            "daily_pnl": 1500.0,
            "percentage_change": 1.5
        }
        
        response = client.post("/api/v1/pnl", json=pnl_data)
        assert response.status_code == 200
        data = response.json()
        assert data["portfolio_id"] == "test_portfolio"
        assert data["total_pnl"] == 1500.0
    
    @pytest.mark.asyncio
    async def test_create_portfolio_health(self):
        """Test portfolio health data creation"""
        health_data = {
            "portfolio_id": "test_portfolio",
            "total_value": 1000000.0,
            "available_balance": 700000.0,
            "used_balance": 300000.0,
            "utilization_rate": 0.3,
            "risk_score": 25.0,
            "health_status": "low"
        }
        
        response = client.post("/api/v1/portfolio/health", json=health_data)
        assert response.status_code == 200
        data = response.json()
        assert data["portfolio_id"] == "test_portfolio"
        assert data["total_value"] == 1000000.0
    
    @pytest.mark.asyncio
    async def test_create_risk_metrics(self):
        """Test risk metrics creation"""
        risk_data = {
            "portfolio_id": "test_portfolio",
            "var_1d": 10000.0,
            "var_5d": 25000.0,
            "beta": 1.2,
            "alpha": 0.05,
            "sharpe_ratio": 1.5,
            "sortino_ratio": 2.0,
            "max_drawdown": 0.15,
            "volatility": 0.25
        }
        
        response = client.post("/api/v1/risk/metrics", json=risk_data)
        assert response.status_code == 200
        data = response.json()
        assert data["portfolio_id"] == "test_portfolio"
        assert data["var_1d"] == 10000.0
    
    @pytest.mark.asyncio
    async def test_create_strategy_performance(self):
        """Test strategy performance creation"""
        perf_data = {
            "strategy_id": "test_strategy",
            "name": "Test Strategy",
            "status": "active",
            "total_return": 0.15,
            "annual_return": 0.12,
            "volatility": 0.20,
            "sharpe_ratio": 1.0,
            "max_drawdown": 0.10,
            "win_rate": 0.60,
            "profit_factor": 1.5,
            "total_trades": 100,
            "winning_trades": 60,
            "losing_trades": 40
        }
        
        response = client.post("/api/v1/strategy/performance", json=perf_data)
        assert response.status_code == 200
        data = response.json()
        assert data["strategy_id"] == "test_strategy"
        assert data["total_return"] == 0.15
    
    @pytest.mark.asyncio
    async def test_create_alert_rule(self):
        """Test alert rule creation"""
        alert_rule = {
            "name": "Test Alert",
            "description": "Test alert rule",
            "metric_type": "pnl",
            "threshold_value": -5.0,
            "operator": "lt",
            "severity": "high"
        }
        
        response = client.post("/api/v1/alerts/rules", json=alert_rule)
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "Test Alert"
        assert data["threshold_value"] == -5.0

class TestPerformanceAnalyzer:
    def setup_method(self):
        self.analyzer = PerformanceAnalyzer()
    
    def test_calculate_sharpe_ratio(self):
        """Test Sharpe ratio calculation"""
        returns = [0.01, 0.02, -0.01, 0.03, 0.00, -0.02, 0.01, 0.02]
        sharpe = asyncio.run(self.analyzer.calculate_sharpe_ratio(returns))
        assert isinstance(sharpe, float)
        assert not (sharpe == 0 and len(returns) > 1)
    
    def test_calculate_sortino_ratio(self):
        """Test Sortino ratio calculation"""
        returns = [0.01, 0.02, -0.01, 0.03, 0.00, -0.02, 0.01, 0.02]
        sortino = asyncio.run(self.analyzer.calculate_sortino_ratio(returns))
        assert isinstance(sortino, float)
    
    def test_calculate_max_drawdown(self):
        """Test max drawdown calculation"""
        returns = [0.01, 0.02, -0.05, 0.03, -0.02, 0.01, 0.02]
        drawdown = asyncio.run(self.analyzer.calculate_max_drawdown(returns))
        assert isinstance(drawdown, float)
        assert drawdown >= 0
        assert drawdown <= 1
    
    def test_calculate_volatility(self):
        """Test volatility calculation"""
        returns = [0.01, 0.02, -0.01, 0.03, 0.00, -0.02, 0.01, 0.02]
        volatility = asyncio.run(self.analyzer.calculate_volatility(returns))
        assert isinstance(volatility, float)
        assert volatility >= 0
    
    def test_calculate_var(self):
        """Test Value at Risk calculation"""
        returns = [0.01, 0.02, -0.01, 0.03, 0.00, -0.02, 0.01, 0.02, -0.03, -0.04] * 10
        var = asyncio.run(self.analyzer.calculate_var(returns))
        assert isinstance(var, float)
        assert var >= 0
    
    def test_calculate_beta(self):
        """Test beta calculation"""
        portfolio_returns = [0.01, 0.02, -0.01, 0.03, 0.00, -0.02, 0.01, 0.02]
        benchmark_returns = [0.01, 0.015, -0.005, 0.025, 0.005, -0.015, 0.01, 0.015]
        beta = asyncio.run(self.analyzer.calculate_beta(portfolio_returns, benchmark_returns))
        assert isinstance(beta, float)
    
    def test_calculate_alpha(self):
        """Test alpha calculation"""
        portfolio_returns = [0.01, 0.02, -0.01, 0.03, 0.00, -0.02, 0.01, 0.02]
        benchmark_returns = [0.01, 0.015, -0.005, 0.025, 0.005, -0.015, 0.01, 0.015]
        alpha = asyncio.run(self.analyzer.calculate_alpha(portfolio_returns, benchmark_returns))
        assert isinstance(alpha, float)

class TestRiskAnalyzer:
    def setup_method(self):
        self.analyzer = RiskAnalyzer()
    
    def test_calculate_portfolio_var(self):
        """Test portfolio VaR calculation"""
        returns = [0.01, 0.02, -0.01, 0.03, 0.00, -0.02, 0.01, 0.02] * 10
        var_data = asyncio.run(self.analyzer.calculate_portfolio_var(returns))
        assert "historical_var" in var_data
        assert "parametric_var" in var_data
        assert var_data["historical_var"] >= 0
    
    def test_calculate_expected_shortfall(self):
        """Test expected shortfall calculation"""
        returns = [0.01, 0.02, -0.05, -0.03, 0.00, -0.02, 0.01, 0.02] * 5
        es = asyncio.run(self.analyzer.calculate_expected_shortfall(returns))
        assert isinstance(es, float)
        assert es >= 0
    
    def test_calculate_correlation_matrix(self):
        """Test correlation matrix calculation"""
        asset_returns = {
            "asset1": [0.01, 0.02, -0.01, 0.03] * 10,
            "asset2": [0.01, 0.025, -0.005, 0.035] * 10,
            "asset3": [0.005, 0.015, -0.015, 0.025] * 10
        }
        corr_data = asyncio.run(self.analyzer.calculate_correlation_matrix(asset_returns))
        assert "correlation_matrix" in corr_data
        assert "average_correlation" in corr_data
    
    def test_calculate_drawdown_series(self):
        """Test drawdown series calculation"""
        portfolio_values = [1000000, 1020000, 1010000, 980000, 1050000, 1030000, 1070000]
        drawdown_data = asyncio.run(self.analyzer.calculate_drawdown_series(portfolio_values))
        assert "max_drawdown" in drawdown_data
        assert "current_drawdown" in drawdown_data
        assert drawdown_data["max_drawdown"] >= 0

class TestAlertManager:
    def setup_method(self):
        self.alert_manager = AlertManager()
    
    @pytest.mark.asyncio
    async def test_create_default_alerts(self):
        """Test default alert creation"""
        await self.alert_manager.create_default_alerts()
        assert len(self.alert_manager.active_rules) > 0
    
    @pytest.mark.asyncio
    async def test_should_trigger_alert(self):
        """Test alert triggering logic"""
        rule = AlertRule(
            name="Test Alert",
            description="Test alert",
            metric_type=MetricType.PNL,
            threshold_value=-5.0,
            operator="lt",
            severity=AlertSeverity.HIGH
        )
        
        # Should trigger for value below threshold
        should_trigger = self.alert_manager._should_trigger_alert(rule, -10.0)
        assert should_trigger
        
        # Should not trigger for value above threshold
        should_trigger = self.alert_manager._should_trigger_alert(rule, -2.0)
        assert not should_trigger
    
    def test_alert_severity_evaluation(self):
        """Test different alert severity levels"""
        rule_high = AlertRule(
            name="High Alert",
            description="High severity alert",
            metric_type=MetricType.PNL,
            threshold_value=-10.0,
            operator="lt",
            severity=AlertSeverity.HIGH
        )
        
        rule_critical = AlertRule(
            name="Critical Alert",
            description="Critical severity alert",
            metric_type=MetricType.DRAWDOWN,
            threshold_value=0.2,
            operator="gt",
            severity=AlertSeverity.CRITICAL
        )
        
        assert rule_high.severity == AlertSeverity.HIGH
        assert rule_critical.severity == AlertSeverity.CRITICAL

class TestSystemMonitor:
    def setup_method(self):
        self.monitor = SystemMonitor()
    
    @pytest.mark.asyncio
    async def test_health_score_calculation(self):
        """Test system health score calculation"""
        score = self.monitor._calculate_system_health_score(50, 60, 70)
        assert isinstance(score, float)
        assert 0 <= score <= 1
    
    @pytest.mark.asyncio
    async def test_calculate_system_health_score_boundaries(self):
        """Test health score boundaries"""
        # Perfect system
        score = self.monitor._calculate_system_health_score(10, 20, 30)
        assert score > 0.8
        
        # Poor system
        score = self.monitor._calculate_system_health_score(95, 98, 99)
        assert score < 0.2

class TestModels:
    def test_performance_metric_model(self):
        """Test PerformanceMetric model"""
        metric = PerformanceMetric(
            metric_type=MetricType.SHARPE_RATIO,
            value=1.5,
            portfolio_id="test_portfolio"
        )
        
        assert metric.metric_type == MetricType.SHARPE_RATIO
        assert metric.value == 1.5
        assert metric.portfolio_id == "test_portfolio"
        assert metric.timestamp is not None
    
    def test_portfolio_health_model(self):
        """Test PortfolioHealth model"""
        health = PortfolioHealth(
            portfolio_id="test_portfolio",
            total_value=1000000.0,
            available_balance=700000.0,
            used_balance=300000.0,
            utilization_rate=0.3,
            risk_score=25.0,
            health_status=RiskLevel.LOW
        )
        
        assert health.portfolio_id == "test_portfolio"
        assert health.utilization_rate == 0.3
        assert health.health_status == RiskLevel.LOW
    
    def test_risk_metrics_model(self):
        """Test RiskMetrics model"""
        risk = RiskMetrics(
            portfolio_id="test_portfolio",
            var_1d=10000.0,
            beta=1.2,
            sharpe_ratio=1.5,
            max_drawdown=0.15
        )
        
        assert risk.portfolio_id == "test_portfolio"
        assert risk.var_1d == 10000.0
        assert risk.beta == 1.2
    
    def test_alert_model(self):
        """Test Alert model"""
        alert = Alert(
            rule_id=1,
            message="Test alert message",
            severity=AlertSeverity.HIGH,
            triggered_value=-10.0
        )
        
        assert alert.rule_id == 1
        assert alert.severity == AlertSeverity.HIGH
        assert alert.triggered_value == -10.0
        assert not alert.resolved
    
    def test_strategy_performance_model(self):
        """Test StrategyPerformance model"""
        strategy = StrategyPerformance(
            strategy_id="test_strategy",
            name="Test Strategy",
            status=StrategyStatus.ACTIVE,
            total_return=0.15,
            win_rate=0.60
        )
        
        assert strategy.strategy_id == "test_strategy"
        assert strategy.status == StrategyStatus.ACTIVE
        assert strategy.total_return == 0.15

class TestWebSocketEndpoint:
    """Test WebSocket functionality"""
    
    def test_websocket_connection(self):
        """Test WebSocket connection establishment"""
        with TestClient(app).websocket_connect("/ws/realtime") as websocket:
            data = websocket.receive_json()
            assert "type" in data
            assert "timestamp" in data
    
    def test_strategy_websocket_connection(self):
        """Test strategy-specific WebSocket connection"""
        with TestClient(app).websocket_connect("/ws/strategy/test_strategy") as websocket:
            data = websocket.receive_json()
            assert "type" in data
            assert "strategy_id" in data

class TestEdgeCases:
    """Test edge cases and error handling"""
    
    def test_empty_data_handling(self):
        """Test handling of empty data"""
        analyzer = PerformanceAnalyzer()
        
        # Test with empty returns
        sharpe = asyncio.run(analyzer.calculate_sharpe_ratio([]))
        assert sharpe == 0.0
        
        # Test with single return
        sharpe = asyncio.run(analyzer.calculate_sharpe_ratio([0.01]))
        assert sharpe == 0.0
    
    def test_extreme_values(self):
        """Test handling of extreme values"""
        analyzer = PerformanceAnalyzer()
        
        # Test with extremely large returns
        extreme_returns = [100.0, -50.0, 200.0, -100.0] * 5
        sharpe = asyncio.run(analyzer.calculate_sharpe_ratio(extreme_returns))
        assert isinstance(sharpe, float)
        
        # Test with zero variance
        constant_returns = [0.01] * 20
        sharpe = asyncio.run(analyzer.calculate_sharpe_ratio(constant_returns))
        assert sharpe == 0.0
    
    def test_invalid_inputs(self):
        """Test handling of invalid inputs"""
        analyzer = PerformanceAnalyzer()
        
        # Test with None values
        with pytest.raises((TypeError, ValueError)):
            asyncio.run(analyzer.calculate_sharpe_ratio(None))
        
        # Test with NaN values
        nan_returns = [0.01, float('nan'), 0.02]
        sharpe = asyncio.run(analyzer.calculate_sharpe_ratio(nan_returns))
        assert isinstance(sharpe, float)  # Should handle gracefully

if __name__ == "__main__":
    pytest.main([__file__])