import aiosqlite
import asyncio
import logging
from typing import Optional
from datetime import datetime

class Database:
    def __init__(self, db_path: str = "performance_monitoring.db"):
        self.db_path = db_path
        self._connection = None

    async def connect(self):
        """Connect to the database"""
        self._connection = await aiosqlite.connect(self.db_path)
        await self._connection.execute("PRAGMA journal_mode=WAL")
        await self._connection.execute("PRAGMA foreign_keys=ON")
        return self._connection

    async def disconnect(self):
        """Disconnect from the database"""
        if self._connection:
            await self._connection.close()
            self._connection = None

    async def execute(self, query: str, params: tuple = None):
        """Execute a query"""
        if not self._connection:
            await self.connect()
        
        async with self._connection.cursor() as cursor:
            if params:
                await cursor.execute(query, params)
            else:
                await cursor.execute(query)
            await self._connection.commit()
            return cursor.rowcount

    async def fetch_one(self, query: str, params: tuple = None):
        """Fetch a single row"""
        if not self._connection:
            await self.connect()
        
        async with self._connection.cursor() as cursor:
            if params:
                await cursor.execute(query, params)
            else:
                await cursor.execute(query)
            row = await cursor.fetchone()
            if row:
                return dict(zip([desc[0] for desc in cursor.description], row))
            return None

    async def fetch_all(self, query: str, params: tuple = None):
        """Fetch multiple rows"""
        if not self._connection:
            await self.connect()
        
        async with self._connection.cursor() as cursor:
            if params:
                await cursor.execute(query, params)
            else:
                await cursor.execute(query)
            rows = await cursor.fetchall()
            if rows:
                columns = [desc[0] for desc in cursor.description]
                return [dict(zip(columns, row)) for row in rows]
            return []

# Global database instance
db_instance = None

def get_database() -> Database:
    """Get database instance"""
    global db_instance
    if db_instance is None:
        db_instance = Database()
    return db_instance

async def create_tables():
    """Create all necessary tables"""
    db = get_database()
    
    # P&L data table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS pnl_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            portfolio_id TEXT NOT NULL,
            strategy_id TEXT NOT NULL,
            realized_pnl REAL NOT NULL,
            unrealized_pnl REAL NOT NULL,
            total_pnl REAL NOT NULL,
            daily_pnl REAL NOT NULL,
            percentage_change REAL NOT NULL,
            timestamp DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Portfolio health table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS portfolio_health (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            portfolio_id TEXT NOT NULL,
            total_value REAL NOT NULL,
            available_balance REAL NOT NULL,
            used_balance REAL NOT NULL,
            utilization_rate REAL NOT NULL,
            risk_score REAL NOT NULL,
            health_status TEXT NOT NULL,
            timestamp DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Risk metrics table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS risk_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            portfolio_id TEXT NOT NULL,
            var_1d REAL NOT NULL,
            var_5d REAL NOT NULL,
            beta REAL NOT NULL,
            alpha REAL NOT NULL,
            sharpe_ratio REAL NOT NULL,
            sortino_ratio REAL NOT NULL,
            max_drawdown REAL NOT NULL,
            volatility REAL NOT NULL,
            timestamp DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # System health table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS system_health (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            service_name TEXT NOT NULL,
            status TEXT NOT NULL,
            cpu_usage REAL NOT NULL,
            memory_usage REAL NOT NULL,
            disk_usage REAL NOT NULL,
            network_latency REAL NOT NULL,
            error_rate REAL NOT NULL,
            uptime REAL NOT NULL,
            timestamp DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Strategy performance table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS strategy_performance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            strategy_id TEXT NOT NULL,
            name TEXT NOT NULL,
            status TEXT NOT NULL,
            total_return REAL NOT NULL,
            annual_return REAL NOT NULL,
            volatility REAL NOT NULL,
            sharpe_ratio REAL NOT NULL,
            max_drawdown REAL NOT NULL,
            win_rate REAL NOT NULL,
            profit_factor REAL NOT NULL,
            total_trades INTEGER NOT NULL,
            winning_trades INTEGER NOT NULL,
            losing_trades INTEGER NOT NULL,
            timestamp DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Alert rules table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS alert_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            metric_type TEXT NOT NULL,
            threshold_value REAL NOT NULL,
            operator TEXT NOT NULL,
            severity TEXT NOT NULL,
            enabled BOOLEAN DEFAULT TRUE,
            strategy_id TEXT,
            portfolio_id TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Alerts table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            rule_id INTEGER NOT NULL,
            message TEXT NOT NULL,
            severity TEXT NOT NULL,
            triggered_value REAL NOT NULL,
            resolved BOOLEAN DEFAULT FALSE,
            resolved_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (rule_id) REFERENCES alert_rules (id)
        )
    """)
    
    # Benchmark data table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS benchmark_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            value REAL NOT NULL,
            change_percent REAL NOT NULL,
            timestamp DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Correlation matrix table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS correlation_matrix (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            assets TEXT NOT NULL, -- JSON array of asset names
            correlation_matrix TEXT NOT NULL, -- JSON array of arrays
            timestamp DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Latency metrics table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS latency_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            service_name TEXT NOT NULL,
            endpoint TEXT NOT NULL,
            avg_latency REAL NOT NULL,
            p50_latency REAL NOT NULL,
            p95_latency REAL NOT NULL,
            p99_latency REAL NOT NULL,
            throughput_rps REAL NOT NULL,
            error_rate REAL NOT NULL,
            timestamp DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Performance attribution table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS performance_attribution (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            portfolio_id TEXT NOT NULL,
            strategy_contribution TEXT NOT NULL, -- JSON object
            sector_contribution TEXT NOT NULL, -- JSON object
            asset_contribution TEXT NOT NULL, -- JSON object
            timing_contribution REAL NOT NULL,
            selection_contribution REAL NOT NULL,
            interaction_contribution REAL NOT NULL,
            total_return REAL NOT NULL,
            benchmark_return REAL NOT NULL,
            excess_return REAL NOT NULL,
            timestamp DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Performance metrics table
    await db.execute("""
        CREATE TABLE IF NOT EXISTS performance_metrics (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            metric_type TEXT NOT NULL,
            value REAL NOT NULL,
            timestamp DATETIME NOT NULL,
            strategy_id TEXT,
            portfolio_id TEXT,
            metadata TEXT, -- JSON object
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Create indexes for better performance
    await create_indexes()
    
    logging.info("Database tables created successfully")

async def create_indexes():
    """Create database indexes for better performance"""
    db = get_database()
    
    # P&L data indexes
    await db.execute("CREATE INDEX IF NOT EXISTS idx_pnl_portfolio_timestamp ON pnl_data (portfolio_id, timestamp)")
    await db.execute("CREATE INDEX IF NOT EXISTS idx_pnl_strategy_timestamp ON pnl_data (strategy_id, timestamp)")
    
    # Portfolio health indexes
    await db.execute("CREATE INDEX IF NOT EXISTS idx_portfolio_health_timestamp ON portfolio_health (portfolio_id, timestamp)")
    
    # Risk metrics indexes
    await db.execute("CREATE INDEX IF NOT EXISTS idx_risk_metrics_timestamp ON risk_metrics (portfolio_id, timestamp)")
    
    # System health indexes
    await db.execute("CREATE INDEX IF NOT EXISTS idx_system_health_timestamp ON system_health (service_name, timestamp)")
    
    # Strategy performance indexes
    await db.execute("CREATE INDEX IF NOT EXISTS idx_strategy_performance_timestamp ON strategy_performance (strategy_id, timestamp)")
    
    # Alert indexes
    await db.execute("CREATE INDEX IF NOT EXISTS idx_alerts_created_at ON alerts (created_at)")
    await db.execute("CREATE INDEX IF NOT EXISTS idx_alerts_rule_id ON alerts (rule_id)")
    
    # Benchmark indexes
    await db.execute("CREATE INDEX IF NOT EXISTS idx_benchmark_timestamp ON benchmark_data (timestamp)")
    
    # Correlation matrix indexes
    await db.execute("CREATE INDEX IF NOT EXISTS idx_correlation_timestamp ON correlation_matrix (timestamp)")
    
    # Latency metrics indexes
    await db.execute("CREATE INDEX IF NOT EXISTS idx_latency_service_timestamp ON latency_metrics (service_name, timestamp)")
    
    # Performance attribution indexes
    await db.execute("CREATE INDEX IF NOT EXISTS idx_perf_attribution_timestamp ON performance_attribution (portfolio_id, timestamp)")
    
    # Performance metrics indexes
    await db.execute("CREATE INDEX IF NOT EXISTS idx_perf_metrics_timestamp ON performance_metrics (timestamp)")
    await db.execute("CREATE INDEX IF NOT EXISTS idx_perf_metrics_strategy ON performance_metrics (strategy_id)")
    await db.execute("CREATE INDEX IF NOT EXISTS idx_perf_metrics_portfolio ON performance_metrics (portfolio_id)")
    
    logging.info("Database indexes created successfully")

async def cleanup_old_data():
    """Clean up old data based on retention policy"""
    db = get_database()
    
    # Keep last 30 days of P&L data
    await db.execute("""
        DELETE FROM pnl_data 
        WHERE timestamp < datetime('now', '-30 days')
    """)
    
    # Keep last 30 days of portfolio health
    await db.execute("""
        DELETE FROM portfolio_health 
        WHERE timestamp < datetime('now', '-30 days')
    """)
    
    # Keep last 30 days of risk metrics
    await db.execute("""
        DELETE FROM risk_metrics 
        WHERE timestamp < datetime('now', '-30 days')
    """)
    
    # Keep last 7 days of system health
    await db.execute("""
        DELETE FROM system_health 
        WHERE timestamp < datetime('now', '-7 days')
    """)
    
    # Keep last 90 days of strategy performance
    await db.execute("""
        DELETE FROM strategy_performance 
        WHERE timestamp < datetime('now', '-90 days')
    """)
    
    # Keep last 90 days of alerts
    await db.execute("""
        DELETE FROM alerts 
        WHERE created_at < datetime('now', '-90 days')
    """)
    
    # Keep last 7 days of correlation matrix
    await db.execute("""
        DELETE FROM correlation_matrix 
        WHERE timestamp < datetime('now', '-7 days')
    """)
    
    # Keep last 7 days of latency metrics
    await db.execute("""
        DELETE FROM latency_metrics 
        WHERE timestamp < datetime('now', '-7 days')
    """)
    
    # Keep last 30 days of performance attribution
    await db.execute("""
        DELETE FROM performance_attribution 
        WHERE timestamp < datetime('now', '-30 days')
    """)
    
    # Keep last 7 days of performance metrics
    await db.execute("""
        DELETE FROM performance_metrics 
        WHERE timestamp < datetime('now', '-7 days')
    """)
    
    logging.info("Old data cleanup completed")