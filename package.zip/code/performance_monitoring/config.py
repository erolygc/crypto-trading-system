import os
from typing import Dict, List, Any
from pydantic import BaseSettings
from enum import Enum

class LogLevel(str, Enum):
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

class Settings(BaseSettings):
    # API Configuration
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8000
    API_DEBUG: bool = False
    API_RELOAD: bool = False
    
    # Database Configuration
    DATABASE_URL: str = "sqlite:///./performance_monitoring.db"
    DATABASE_ECHO: bool = False
    
    # Redis Configuration
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_DB: int = 0
    REDIS_PASSWORD: str = ""
    
    # WebSocket Configuration
    WS_HEARTBEAT_INTERVAL: int = 30
    WS_MAX_CONNECTIONS: int = 100
    
    # Monitoring Configuration
    MONITORING_INTERVAL: int = 60  # seconds
    DATA_RETENTION_DAYS: int = 90
    ALERT_COOLDOWN_MINUTES: int = 5
    
    # Risk Thresholds
    VAR_THRESHOLD: float = 10000.0  # $10,000
    MAX_DRAWDOWN_THRESHOLD: float = 0.20  # 20%
    HIGH_VOLATILITY_THRESHOLD: float = 0.30  # 30%
    SHARPE_RATIO_WARNING: float = 0.5
    
    # System Thresholds
    CPU_WARNING_THRESHOLD: float = 70.0  # %
    CPU_CRITICAL_THRESHOLD: float = 90.0  # %
    MEMORY_WARNING_THRESHOLD: float = 80.0  # %
    MEMORY_CRITICAL_THRESHOLD: float = 95.0  # %
    DISK_WARNING_THRESHOLD: float = 80.0  # %
    DISK_CRITICAL_THRESHOLD: float = 95.0  # %
    
    # Latency Thresholds (milliseconds)
    LATENCY_WARNING_THRESHOLD: float = 1000.0
    LATENCY_CRITICAL_THRESHOLD: float = 5000.0
    API_LATENCY_THRESHOLD: float = 500.0
    
    # P&L Thresholds (percentages)
    DAILY_LOSS_WARNING_THRESHOLD: float = 2.0  # %
    DAILY_LOSS_CRITICAL_THRESHOLD: float = 5.0  # %
    DAILY_GAIN_WARNING_THRESHOLD: float = 5.0  # %
    
    # Logging Configuration
    LOG_LEVEL: LogLevel = LogLevel.INFO
    LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    LOG_FILE: str = "performance_monitoring.log"
    
    # Dashboard Configuration
    DASHBOARD_UPDATE_INTERVAL: int = 5  # seconds
    MAX_CHART_DATA_POINTS: int = 100
    DASHBOARD_THEME: str = "bootstrap"
    
    # Benchmark Configuration
    DEFAULT_BENCHMARKS: List[str] = ["SPY", "QQQ", "BTC-USD"]
    BENCHMARK_UPDATE_INTERVAL: int = 300  # 5 minutes
    
    # Performance Calculation
    DEFAULT_LOOKBACK_DAYS: int = 30
    MIN_DATA_POINTS_FOR_ANALYSIS: int = 30
    RISK_FREE_RATE: float = 0.02  # 2%
    
    # Correlation Analysis
    CORRELATION_LOOKBACK_DAYS: int = 60
    HIGH_CORRELATION_THRESHOLD: float = 0.8
    CORRELATION_UPDATE_INTERVAL: int = 3600  # 1 hour
    
    # Notification Configuration
    EMAIL_ENABLED: bool = False
    EMAIL_SMTP_SERVER: str = "smtp.gmail.com"
    EMAIL_SMTP_PORT: int = 587
    EMAIL_USERNAME: str = ""
    EMAIL_PASSWORD: str = ""
    EMAIL_RECIPIENTS: List[str] = []
    
    SLACK_ENABLED: bool = False
    SLACK_WEBHOOK_URL: str = ""
    
    # Security Configuration
    JWT_SECRET_KEY: str = "your-secret-key-here"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRE_MINUTES: int = 30
    
    # Rate Limiting
    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_REQUESTS_PER_MINUTE: int = 100
    
    # Caching Configuration
    CACHE_TTL_SECONDS: int = 300  # 5 minutes
    CACHE_MAX_SIZE: int = 1000
    
    # Background Tasks
    CELERY_BROKER_URL: str = "redis://localhost:6379/1"
    CELERY_RESULT_BACKEND: str = "redis://localhost:6379/2"
    
    class Config:
        env_file = ".env"
        case_sensitive = True

# Global settings instance
settings = Settings()

# Configuration for different environments
ENVIRONMENT_CONFIGS = {
    "development": {
        "API_DEBUG": True,
        "API_RELOAD": True,
        "DATABASE_ECHO": True,
        "LOG_LEVEL": LogLevel.DEBUG,
        "MONITORING_INTERVAL": 30,
    },
    "staging": {
        "API_DEBUG": True,
        "LOG_LEVEL": LogLevel.INFO,
        "DATA_RETENTION_DAYS": 30,
    },
    "production": {
        "API_DEBUG": False,
        "API_RELOAD": False,
        "DATABASE_ECHO": False,
        "LOG_LEVEL": LogLevel.WARNING,
        "DATA_RETENTION_DAYS": 365,
        "RATE_LIMIT_ENABLED": True,
    }
}

# Metric thresholds configuration
METRIC_THRESHOLDS = {
    "pnl": {
        "daily_loss_warning": settings.DAILY_LOSS_WARNING_THRESHOLD,
        "daily_loss_critical": settings.DAILY_LOSS_CRITICAL_THRESHOLD,
        "daily_gain_warning": settings.DAILY_GAIN_WARNING_THRESHOLD,
    },
    "risk": {
        "var_threshold": settings.VAR_THRESHOLD,
        "max_drawdown_threshold": settings.MAX_DRAWDOWN_THRESHOLD,
        "volatility_threshold": settings.HIGH_VOLATILITY_THRESHOLD,
        "sharpe_warning": settings.SHARPE_RATIO_WARNING,
    },
    "system": {
        "cpu_warning": settings.CPU_WARNING_THRESHOLD,
        "cpu_critical": settings.CPU_CRITICAL_THRESHOLD,
        "memory_warning": settings.MEMORY_WARNING_THRESHOLD,
        "memory_critical": settings.MEMORY_CRITICAL_THRESHOLD,
        "disk_warning": settings.DISK_WARNING_THRESHOLD,
        "disk_critical": settings.DISK_CRITICAL_THRESHOLD,
        "latency_warning": settings.LATENCY_WARNING_THRESHOLD,
        "latency_critical": settings.LATENCY_CRITICAL_THRESHOLD,
    }
}

# Alert severity configuration
ALERT_SEVERITY_CONFIG = {
    "low": {
        "color": "info",
        "icon": "info-circle",
        "actions": ["log"],
        "cooldown_minutes": 15,
    },
    "medium": {
        "color": "warning", 
        "icon": "exclamation-triangle",
        "actions": ["log", "email"],
        "cooldown_minutes": 10,
    },
    "high": {
        "color": "danger",
        "icon": "exclamation-circle", 
        "actions": ["log", "email", "slack"],
        "cooldown_minutes": 5,
    },
    "critical": {
        "color": "danger",
        "icon": "ban",
        "actions": ["log", "email", "slack", "sms"],
        "cooldown_minutes": 1,
    }
}

# Dashboard configuration
DASHBOARD_CONFIG = {
    "theme": settings.DASHBOARD_THEME,
    "update_interval": settings.DASHBOARD_UPDATE_INTERVAL,
    "max_data_points": settings.MAX_CHART_DATA_POINTS,
    "charts": {
        "pnl_trend": {
            "type": "line",
            "height": 400,
            "y_axis": "currency",
            "colors": ["#007bff", "#28a745", "#dc3545"],
        },
        "risk_metrics": {
            "type": "bar",
            "height": 350,
            "y_axis": "percentage",
            "colors": ["#ffc107", "#17a2b8", "#6f42c1"],
        },
        "correlation_matrix": {
            "type": "heatmap",
            "height": 400,
            "color_scale": "RdBu",
        },
        "system_health": {
            "type": "gauge",
            "height": 300,
            "ranges": {
                "good": [80, 100],
                "warning": [50, 80], 
                "critical": [0, 50],
            },
        }
    }
}

# Database schema configuration
DATABASE_SCHEMA = {
    "performance_monitoring.db": {
        "tables": [
            "pnl_data",
            "portfolio_health", 
            "risk_metrics",
            "system_health",
            "strategy_performance",
            "alert_rules",
            "alerts",
            "benchmark_data",
            "correlation_matrix",
            "latency_metrics",
            "performance_attribution",
            "performance_metrics"
        ],
        "indexes": [
            "idx_pnl_portfolio_timestamp",
            "idx_pnl_strategy_timestamp",
            "idx_portfolio_health_timestamp", 
            "idx_risk_metrics_timestamp",
            "idx_system_health_timestamp",
            "idx_strategy_performance_timestamp",
            "idx_alerts_created_at",
            "idx_alerts_rule_id",
            "idx_benchmark_timestamp",
            "idx_correlation_timestamp",
            "idx_latency_service_timestamp",
            "idx_perf_attribution_timestamp",
            "idx_perf_metrics_timestamp",
            "idx_perf_metrics_strategy",
            "idx_perf_metrics_portfolio"
        ],
        "views": [
            "v_portfolio_summary",
            "v_strategy_performance_summary", 
            "v_risk_dashboard",
            "v_system_health_summary"
        ]
    }
}

# Performance calculation defaults
PERFORMANCE_CONFIG = {
    "default_lookback_days": settings.DEFAULT_LOOKBACK_DAYS,
    "min_data_points": settings.MIN_DATA_POINTS_FOR_ANALYSIS,
    "risk_free_rate": settings.RISK_FREE_RATE,
    "var_confidence_levels": [0.05, 0.01],  # 95%, 99%
    "volatility_windows": [5, 10, 20, 60],  # days
    "correlation_windows": [30, 60, 90],  # days
    "drawdown_minimum_trough": 0.01,  # 1% minimum drawdown
    "sharpe_ratio_lookback": 252,  # 1 year for annualization
}

# API endpoints configuration
API_ENDPOINTS = {
    "health": {
        "path": "/health",
        "methods": ["GET"],
        "rate_limit": "100/minute",
        "cache_ttl": 60,
    },
    "real_time_ws": {
        "path": "/ws/realtime",
        "methods": ["WS"],
        "max_connections": settings.WS_MAX_CONNECTIONS,
        "heartbeat_interval": settings.WS_HEARTBEAT_INTERVAL,
    },
    "pnl": {
        "base_path": "/api/v1/pnl",
        "methods": ["GET", "POST"],
        "rate_limit": "200/minute",
        "cache_ttl": 30,
    },
    "portfolio_health": {
        "base_path": "/api/v1/portfolio/{portfolio_id}/health", 
        "methods": ["GET", "POST"],
        "rate_limit": "150/minute",
        "cache_ttl": 60,
    },
    "risk_metrics": {
        "base_path": "/api/v1/risk/metrics/{portfolio_id}",
        "methods": ["GET", "POST"],
        "rate_limit": "100/minute", 
        "cache_ttl": 300,
    },
    "strategy_performance": {
        "base_path": "/api/v1/strategy/performance",
        "methods": ["GET", "POST"],
        "rate_limit": "100/minute",
        "cache_ttl": 120,
    },
    "alerts": {
        "base_path": "/api/v1/alerts",
        "methods": ["GET", "POST"],
        "rate_limit": "50/minute",
        "cache_ttl": 30,
    },
}

def get_environment_config() -> Dict[str, Any]:
    """Get configuration for current environment"""
    env = os.getenv("ENVIRONMENT", "development")
    return ENVIRONMENT_CONFIGS.get(env, ENVIRONMENT_CONFIGS["development"])

def apply_environment_config():
    """Apply environment-specific configuration"""
    env_config = get_environment_config()
    for key, value in env_config.items():
        if hasattr(settings, key):
            setattr(settings, key, value)

def get_database_config() -> Dict[str, Any]:
    """Get database configuration"""
    return {
        "url": settings.DATABASE_URL,
        "echo": settings.DATABASE_ECHO,
        "pool_size": 10,
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }

def get_redis_config() -> Dict[str, Any]:
    """Get Redis configuration"""
    return {
        "host": settings.REDIS_HOST,
        "port": settings.REDIS_PORT,
        "db": settings.REDIS_DB,
        "password": settings.REDIS_PASSWORD or None,
        "decode_responses": True,
        "socket_connect_timeout": 5,
        "socket_timeout": 5,
        "retry_on_timeout": True,
        "health_check_interval": 30,
    }

def get_alert_thresholds() -> Dict[str, Any]:
    """Get alert thresholds configuration"""
    return METRIC_THRESHOLDS

def get_dashboard_config() -> Dict[str, Any]:
    """Get dashboard configuration"""
    return DASHBOARD_CONFIG

# Apply environment configuration on import
apply_environment_config()