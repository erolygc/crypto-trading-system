from datetime import datetime, timezone
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
from enum import Enum

class AlertSeverity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class MetricType(str, Enum):
    PNL = "pnl"
    PORTFOLIO_VALUE = "portfolio_value"
    VOLATILITY = "volatility"
    DRAWDOWN = "drawdown"
    CORRELATION = "correlation"
    LATENCY = "latency"
    THROUGHPUT = "throughput"
    SHARPE_RATIO = "sharpe_ratio"
    VAR = "var"
    BETA = "beta"
    ALPHA = "alpha"

class StrategyStatus(str, Enum):
    ACTIVE = "active"
    PAUSED = "paused"
    STOPPED = "stopped"
    ERROR = "error"

class RiskLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    EXTREME = "extreme"

class PerformanceMetric(BaseModel):
    id: Optional[int] = None
    metric_type: MetricType
    value: float
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    strategy_id: Optional[str] = None
    portfolio_id: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

class PortfolioHealth(BaseModel):
    id: Optional[int] = None
    portfolio_id: str
    total_value: float
    available_balance: float
    used_balance: float
    utilization_rate: float
    risk_score: float
    health_status: RiskLevel
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class PnLData(BaseModel):
    id: Optional[int] = None
    portfolio_id: str
    strategy_id: str
    realized_pnl: float
    unrealized_pnl: float
    total_pnl: float
    daily_pnl: float
    percentage_change: float
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class RiskMetrics(BaseModel):
    id: Optional[int] = None
    portfolio_id: str
    var_1d: float
    var_5d: float
    beta: float
    alpha: float
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown: float
    volatility: float
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class SystemHealth(BaseModel):
    id: Optional[int] = None
    service_name: str
    status: str
    cpu_usage: float
    memory_usage: float
    disk_usage: float
    network_latency: float
    error_rate: float
    uptime: float
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class AlertRule(BaseModel):
    id: Optional[int] = None
    name: str
    description: str
    metric_type: MetricType
    threshold_value: float
    operator: str  # gt, lt, eq, gte, lte
    severity: AlertSeverity
    enabled: bool = True
    strategy_id: Optional[str] = None
    portfolio_id: Optional[str] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class Alert(BaseModel):
    id: Optional[int] = None
    rule_id: int
    message: str
    severity: AlertSeverity
    triggered_value: float
    resolved: bool = False
    resolved_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class StrategyPerformance(BaseModel):
    id: Optional[int] = None
    strategy_id: str
    name: str
    status: StrategyStatus
    total_return: float
    annual_return: float
    volatility: float
    sharpe_ratio: float
    max_drawdown: float
    win_rate: float
    profit_factor: float
    total_trades: int
    winning_trades: int
    losing_trades: int
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class BenchmarkData(BaseModel):
    id: Optional[int] = None
    name: str
    value: float
    change_percent: float
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class CorrelationMatrix(BaseModel):
    id: Optional[int] = None
    assets: List[str]
    correlation_matrix: List[List[float]]
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class LatencyMetrics(BaseModel):
    id: Optional[int] = None
    service_name: str
    endpoint: str
    avg_latency: float
    p50_latency: float
    p95_latency: float
    p99_latency: float
    throughput_rps: float
    error_rate: float
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

class PerformanceAttribution(BaseModel):
    id: Optional[int] = None
    portfolio_id: str
    strategy_contribution: Dict[str, float]
    sector_contribution: Dict[str, float]
    asset_contribution: Dict[str, float]
    timing_contribution: float
    selection_contribution: float
    interaction_contribution: float
    total_return: float
    benchmark_return: float
    excess_return: float
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))