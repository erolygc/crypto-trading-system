from fastapi import FastAPI, HTTPException, Depends, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from typing import List, Dict, Any
import asyncio
import json
from datetime import datetime, timezone
import redis
import logging

from models import *
from database import get_database, create_tables
from alerts.alert_manager import AlertManager
from analytics.performance_analyzer import PerformanceAnalyzer
from analytics.risk_analyzer import RiskAnalyzer
from analytics.system_monitor import SystemMonitor

# FastAPI app initialization
app = FastAPI(
    title="Real-time Performance Monitoring API",
    description="Comprehensive performance monitoring system for trading portfolios",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Redis connection
redis_client = redis.Redis(host='localhost', port=6379, db=0)

# Initialize components
alert_manager = AlertManager()
performance_analyzer = PerformanceAnalyzer()
risk_analyzer = RiskAnalyzer()
system_monitor = SystemMonitor()

# WebSocket connections manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.subscribers: Dict[str, List[WebSocket]] = {}  # strategy_id -> connections

    async def connect(self, websocket: WebSocket, strategy_id: str = None):
        await websocket.accept()
        self.active_connections.append(websocket)
        
        if strategy_id:
            if strategy_id not in self.subscribers:
                self.subscribers[strategy_id] = []
            self.subscribers[strategy_id].append(websocket)

    def disconnect(self, websocket: WebSocket, strategy_id: str = None):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        
        if strategy_id and strategy_id in self.subscribers:
            if websocket in self.subscribers[strategy_id]:
                self.subscribers[strategy_id].remove(websocket)
            if not self.subscribers[strategy_id]:
                del self.subscribers[strategy_id]

    async def broadcast(self, message: dict):
        if self.active_connections:
            await asyncio.gather(
                *[connection.send_text(json.dumps(message)) for connection in self.active_connections],
                return_exceptions=True
            )

    async def send_to_strategy(self, strategy_id: str, message: dict):
        if strategy_id in self.subscribers:
            await asyncio.gather(
                *[connection.send_text(json.dumps(message)) for connection in self.subscribers[strategy_id]],
                return_exceptions=True
            )

manager = ConnectionManager()

@app.on_event("startup")
async def startup_event():
    await create_tables()
    logging.info("Performance Monitoring API started")

@app.on_event("shutdown")
async def shutdown_event():
    logging.info("Performance Monitoring API shutting down")

# Health check endpoint
@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.now(timezone.utc)}

# Real-time data streaming endpoint
@app.websocket("/ws/realtime")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            # Send real-time updates every 5 seconds
            await asyncio.sleep(5)
            
            # Get latest metrics from Redis
            metrics_data = {
                "pnl_data": await get_latest_pnl_data(),
                "portfolio_health": await get_latest_portfolio_health(),
                "risk_metrics": await get_latest_risk_metrics(),
                "system_health": await get_latest_system_health(),
                "strategy_performance": await get_latest_strategy_performance()
            }
            
            await websocket.send_text(json.dumps({
                "type": "real_time_update",
                "data": metrics_data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }))
            
    except WebSocketDisconnect:
        manager.disconnect(websocket)

# Strategy-specific WebSocket
@app.websocket("/ws/strategy/{strategy_id}")
async def strategy_websocket(websocket: WebSocket, strategy_id: str):
    await manager.connect(websocket, strategy_id)
    try:
        while True:
            await asyncio.sleep(3)  # More frequent updates for strategy-specific data
            
            strategy_data = {
                "strategy_performance": await get_strategy_performance(strategy_id),
                "strategy_pnl": await get_strategy_pnl(strategy_id),
                "strategy_risk": await get_strategy_risk(strategy_id)
            }
            
            await websocket.send_text(json.dumps({
                "type": "strategy_update",
                "strategy_id": strategy_id,
                "data": strategy_data,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }))
            
    except WebSocketDisconnect:
        manager.disconnect(websocket, strategy_id)

# API Endpoints for P&L Data
@app.post("/api/v1/pnl", response_model=PnLData)
async def create_pnl_data(pnl_data: PnLData):
    try:
        # Store in database
        db = get_database()
        await db.execute("""
            INSERT INTO pnl_data (portfolio_id, strategy_id, realized_pnl, unrealized_pnl, 
                                total_pnl, daily_pnl, percentage_change, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            pnl_data.portfolio_id, pnl_data.strategy_id, pnl_data.realized_pnl,
            pnl_data.unrealized_pnl, pnl_data.total_pnl, pnl_data.daily_pnl,
            pnl_data.percentage_change, pnl_data.timestamp
        ))
        
        # Cache in Redis
        redis_key = f"pnl:{pnl_data.portfolio_id}:{pnl_data.strategy_id}"
        redis_client.hmset(redis_key, {
            "realized_pnl": pnl_data.realized_pnl,
            "unrealized_pnl": pnl_data.unrealized_pnl,
            "total_pnl": pnl_data.total_pnl,
            "daily_pnl": pnl_data.daily_pnl,
            "percentage_change": pnl_data.percentage_change,
            "timestamp": pnl_data.timestamp.isoformat()
        })
        redis_client.expire(redis_key, 3600)  # 1 hour expiry
        
        # Check for alert rules
        await alert_manager.check_pnl_alerts(pnl_data)
        
        return pnl_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/pnl/{portfolio_id}", response_model=List[PnLData])
async def get_pnl_data(portfolio_id: str, limit: int = 100):
    try:
        db = get_database()
        result = await db.fetch_all("""
            SELECT * FROM pnl_data WHERE portfolio_id = ? 
            ORDER BY timestamp DESC LIMIT ?
        """, portfolio_id, limit)
        
        return [PnLData(**row) for row in result]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Portfolio Health endpoints
@app.post("/api/v1/portfolio/health", response_model=PortfolioHealth)
async def create_portfolio_health(health_data: PortfolioHealth):
    try:
        db = get_database()
        await db.execute("""
            INSERT INTO portfolio_health (portfolio_id, total_value, available_balance, 
                                        used_balance, utilization_rate, risk_score, 
                                        health_status, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            health_data.portfolio_id, health_data.total_value, health_data.available_balance,
            health_data.used_balance, health_data.utilization_rate, health_data.risk_score,
            health_data.health_status, health_data.timestamp
        ))
        
        # Cache in Redis
        redis_key = f"portfolio_health:{health_data.portfolio_id}"
        redis_client.hmset(redis_key, {
            "total_value": health_data.total_value,
            "available_balance": health_data.available_balance,
            "used_balance": health_data.used_balance,
            "utilization_rate": health_data.utilization_rate,
            "risk_score": health_data.risk_score,
            "health_status": health_data.health_status,
            "timestamp": health_data.timestamp.isoformat()
        })
        redis_client.expire(redis_key, 1800)  # 30 minutes expiry
        
        return health_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/portfolio/{portfolio_id}/health", response_model=PortfolioHealth)
async def get_portfolio_health(portfolio_id: str):
    try:
        # Try Redis first
        redis_key = f"portfolio_health:{portfolio_id}"
        cached_data = redis_client.hgetall(redis_key)
        
        if cached_data:
            return PortfolioHealth(
                portfolio_id=portfolio_id,
                total_value=float(cached_data[b'total_value']),
                available_balance=float(cached_data[b'available_balance']),
                used_balance=float(cached_data[b'used_balance']),
                utilization_rate=float(cached_data[b'utilization_rate']),
                risk_score=float(cached_data[b'risk_score']),
                health_status=cached_data[b'health_status'].decode(),
                timestamp=datetime.fromisoformat(cached_data[b'timestamp'].decode())
            )
        
        # Fallback to database
        db = get_database()
        result = await db.fetch_one("""
            SELECT * FROM portfolio_health WHERE portfolio_id = ?
            ORDER BY timestamp DESC LIMIT 1
        """, portfolio_id)
        
        if result:
            return PortfolioHealth(**result)
        else:
            raise HTTPException(status_code=404, detail="Portfolio health data not found")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Risk Metrics endpoints
@app.post("/api/v1/risk/metrics", response_model=RiskMetrics)
async def create_risk_metrics(risk_data: RiskMetrics):
    try:
        db = get_database()
        await db.execute("""
            INSERT INTO risk_metrics (portfolio_id, var_1d, var_5d, beta, alpha, 
                                    sharpe_ratio, sortino_ratio, max_drawdown, 
                                    volatility, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            risk_data.portfolio_id, risk_data.var_1d, risk_data.var_5d,
            risk_data.beta, risk_data.alpha, risk_data.sharpe_ratio,
            risk_data.sortino_ratio, risk_data.max_drawdown,
            risk_data.volatility, risk_data.timestamp
        ))
        
        return risk_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/risk/metrics/{portfolio_id}", response_model=RiskMetrics)
async def get_risk_metrics(portfolio_id: str):
    try:
        db = get_database()
        result = await db.fetch_one("""
            SELECT * FROM risk_metrics WHERE portfolio_id = ?
            ORDER BY timestamp DESC LIMIT 1
        """, portfolio_id)
        
        if result:
            return RiskMetrics(**result)
        else:
            raise HTTPException(status_code=404, detail="Risk metrics not found")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# System Health endpoints
@app.post("/api/v1/system/health", response_model=SystemHealth)
async def create_system_health(health_data: SystemHealth):
    try:
        db = get_database()
        await db.execute("""
            INSERT INTO system_health (service_name, status, cpu_usage, memory_usage,
                                     disk_usage, network_latency, error_rate, uptime, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            health_data.service_name, health_data.status, health_data.cpu_usage,
            health_data.memory_usage, health_data.disk_usage, health_data.network_latency,
            health_data.error_rate, health_data.uptime, health_data.timestamp
        ))
        
        return health_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/system/health", response_model=List[SystemHealth])
async def get_system_health():
    try:
        db = get_database()
        results = await db.fetch_all("""
            SELECT DISTINCT service_name, 
                   (SELECT * FROM system_health sh2 WHERE sh2.service_name = sh1.service_name 
                    ORDER BY timestamp DESC LIMIT 1) as latest_health
            FROM system_health sh1
        """)
        
        return [SystemHealth(**row) for row in results]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Strategy Performance endpoints
@app.post("/api/v1/strategy/performance", response_model=StrategyPerformance)
async def create_strategy_performance(perf_data: StrategyPerformance):
    try:
        db = get_database()
        await db.execute("""
            INSERT INTO strategy_performance (strategy_id, name, status, total_return,
                                            annual_return, volatility, sharpe_ratio,
                                            max_drawdown, win_rate, profit_factor,
                                            total_trades, winning_trades, losing_trades, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            perf_data.strategy_id, perf_data.name, perf_data.status,
            perf_data.total_return, perf_data.annual_return, perf_data.volatility,
            perf_data.sharpe_ratio, perf_data.max_drawdown, perf_data.win_rate,
            perf_data.profit_factor, perf_data.total_trades, perf_data.winning_trades,
            perf_data.losing_trades, perf_data.timestamp
        ))
        
        # Update Redis cache
        redis_key = f"strategy_performance:{perf_data.strategy_id}"
        redis_client.hmset(redis_key, {
            "total_return": perf_data.total_return,
            "annual_return": perf_data.annual_return,
            "volatility": perf_data.volatility,
            "sharpe_ratio": perf_data.sharpe_ratio,
            "status": perf_data.status,
            "timestamp": perf_data.timestamp.isoformat()
        })
        redis_client.expire(redis_key, 900)  # 15 minutes expiry
        
        return perf_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/strategy/performance", response_model=List[StrategyPerformance])
async def get_all_strategy_performance():
    try:
        db = get_database()
        results = await db.fetch_all("""
            SELECT DISTINCT strategy_id,
                   (SELECT * FROM strategy_performance sp2 WHERE sp2.strategy_id = sp1.strategy_id 
                    ORDER BY timestamp DESC LIMIT 1) as latest_performance
            FROM strategy_performance sp1
        """)
        
        return [StrategyPerformance(**row) for row in results]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/strategy/{strategy_id}/performance", response_model=StrategyPerformance)
async def get_strategy_performance(strategy_id: str):
    try:
        # Try Redis first
        redis_key = f"strategy_performance:{strategy_id}"
        cached_data = redis_client.hgetall(redis_key)
        
        if cached_data:
            db = get_database()
            result = await db.fetch_one("""
                SELECT * FROM strategy_performance WHERE strategy_id = ?
                ORDER BY timestamp DESC LIMIT 1
            """, strategy_id)
            
            if result:
                return StrategyPerformance(**result)
        
        # Fallback to database
        db = get_database()
        result = await db.fetch_one("""
            SELECT * FROM strategy_performance WHERE strategy_id = ?
            ORDER BY timestamp DESC LIMIT 1
        """, strategy_id)
        
        if result:
            return StrategyPerformance(**result)
        else:
            raise HTTPException(status_code=404, detail="Strategy performance not found")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Alert Management endpoints
@app.post("/api/v1/alerts/rules", response_model=AlertRule)
async def create_alert_rule(rule: AlertRule):
    try:
        db = get_database()
        await db.execute("""
            INSERT INTO alert_rules (name, description, metric_type, threshold_value,
                                   operator, severity, enabled, strategy_id, portfolio_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            rule.name, rule.description, rule.metric_type, rule.threshold_value,
            rule.operator, rule.severity, rule.enabled, rule.strategy_id,
            rule.portfolio_id, rule.created_at
        ))
        
        return rule
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/alerts/rules", response_model=List[AlertRule])
async def get_alert_rules():
    try:
        db = get_database()
        results = await db.fetch_all("""
            SELECT * FROM alert_rules ORDER BY created_at DESC
        """)
        
        return [AlertRule(**row) for row in results]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/alerts", response_model=List[Alert])
async def get_alerts(limit: int = 50):
    try:
        db = get_database()
        results = await db.fetch_all("""
            SELECT * FROM alerts ORDER BY created_at DESC LIMIT ?
        """, limit)
        
        return [Alert(**row) for row in results]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Benchmark endpoints
@app.post("/api/v1/benchmark", response_model=BenchmarkData)
async def create_benchmark_data(benchmark: BenchmarkData):
    try:
        db = get_database()
        await db.execute("""
            INSERT INTO benchmark_data (name, value, change_percent, timestamp)
            VALUES (?, ?, ?, ?)
        """, (benchmark.name, benchmark.value, benchmark.change_percent, benchmark.timestamp))
        
        return benchmark
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/benchmark", response_model=List[BenchmarkData])
async def get_benchmarks():
    try:
        db = get_database()
        results = await db.fetch_all("""
            SELECT * FROM benchmark_data ORDER BY timestamp DESC
        """)
        
        return [BenchmarkData(**row) for row in results]
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Helper functions
async def get_latest_pnl_data():
    """Get latest P&L data from Redis"""
    try:
        keys = redis_client.keys("pnl:*")
        if not keys:
            return []
        
        pnl_data = []
        for key in keys[:10]:  # Limit to 10 items
            data = redis_client.hgetall(key)
            if data:
                pnl_data.append({
                    "key": key.decode(),
                    "data": {k.decode(): v.decode() for k, v in data.items()}
                })
        return pnl_data
    except:
        return []

async def get_latest_portfolio_health():
    """Get latest portfolio health data"""
    try:
        keys = redis_client.keys("portfolio_health:*")
        health_data = []
        for key in keys[:10]:
            data = redis_client.hgetall(key)
            if data:
                health_data.append({
                    "portfolio_id": key.decode().replace("portfolio_health:", ""),
                    "data": {k.decode(): v.decode() for k, v in data.items()}
                })
        return health_data
    except:
        return []

async def get_latest_risk_metrics():
    """Get latest risk metrics"""
    # Implementation would fetch from database
    return []

async def get_latest_system_health():
    """Get latest system health data"""
    # Implementation would fetch from database
    return []

async def get_latest_strategy_performance():
    """Get latest strategy performance"""
    try:
        keys = redis_client.keys("strategy_performance:*")
        perf_data = []
        for key in keys:
            data = redis_client.hgetall(key)
            if data:
                perf_data.append({
                    "strategy_id": key.decode().replace("strategy_performance:", ""),
                    "data": {k.decode(): v.decode() for k, v in data.items()}
                })
        return perf_data
    except:
        return []

async def get_strategy_performance(strategy_id: str):
    """Get strategy-specific performance data"""
    redis_key = f"strategy_performance:{strategy_id}"
    data = redis_client.hgetall(redis_key)
    return {k.decode(): v.decode() for k, v in data.items()} if data else {}

async def get_strategy_pnl(strategy_id: str):
    """Get strategy-specific P&L data"""
    # Implementation would fetch P&L data for strategy
    return {}

async def get_strategy_risk(strategy_id: str):
    """Get strategy-specific risk data"""
    # Implementation would fetch risk data for strategy
    return {}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)