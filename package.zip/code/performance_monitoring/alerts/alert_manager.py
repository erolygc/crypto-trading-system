import asyncio
import logging
from datetime import datetime, timezone
from typing import Dict, List, Any, Optional
from database import get_database
from models import AlertRule, Alert, AlertSeverity, MetricType

class AlertManager:
    def __init__(self):
        self.active_rules: List[AlertRule] = []
        self.alert_history: List[Alert] = []
        self.alert_cooldown = {}  # rule_id -> last_triggered_time
        self.cooldown_period = 300  # 5 minutes

    async def load_rules(self):
        """Load alert rules from database"""
        try:
            db = get_database()
            results = await db.fetch_all("""
                SELECT * FROM alert_rules WHERE enabled = 1
            """)
            
            self.active_rules = [AlertRule(**row) for row in results]
            logging.info(f"Loaded {len(self.active_rules)} active alert rules")
            
        except Exception as e:
            logging.error(f"Error loading alert rules: {e}")

    async def check_pnl_alerts(self, pnl_data):
        """Check P&L related alerts"""
        await self._check_metric_alerts(
            MetricType.PNL, 
            pnl_data.total_pnl, 
            pnl_data.portfolio_id,
            pnl_data.strategy_id
        )

    async def check_volatility_alerts(self, volatility_data):
        """Check volatility related alerts"""
        await self._check_metric_alerts(
            MetricType.VOLATILITY,
            volatility_data.volatility,
            volatility_data.portfolio_id
        )

    async def check_risk_alerts(self, risk_data):
        """Check risk-related alerts"""
        # VaR alerts
        await self._check_metric_alerts(
            MetricType.VAR,
            risk_data.var_1d,
            risk_data.portfolio_id
        )
        
        # Max drawdown alerts
        await self._check_metric_alerts(
            MetricType.DRAWDOWN,
            risk_data.max_drawdown,
            risk_data.portfolio_id
        )

    async def check_system_health_alerts(self, health_data):
        """Check system health alerts"""
        await self._check_metric_alerts(
            MetricType.LATENCY,
            health_data.network_latency,
            portfolio_id=health_data.service_name
        )

    async def _check_metric_alerts(self, metric_type: MetricType, value: float, 
                                  portfolio_id: str = None, strategy_id: str = None):
        """Generic metric alert checker"""
        try:
            for rule in self.active_rules:
                if (rule.metric_type == metric_type and
                    (not rule.portfolio_id or rule.portfolio_id == portfolio_id) and
                    (not rule.strategy_id or rule.strategy_id == strategy_id)):
                    
                    if self._should_trigger_alert(rule, value):
                        await self._trigger_alert(rule, value)
                        
        except Exception as e:
            logging.error(f"Error checking metric alerts: {e}")

    def _should_trigger_alert(self, rule: AlertRule, value: float) -> bool:
        """Check if alert should be triggered based on threshold"""
        # Check cooldown period
        if rule.id in self.alert_cooldown:
            last_triggered = self.alert_cooldown[rule.id]
            if (datetime.now(timezone.utc) - last_triggered).seconds < self.cooldown_period:
                return False

        # Evaluate threshold condition
        try:
            if rule.operator == "gt" and value > rule.threshold_value:
                return True
            elif rule.operator == "lt" and value < rule.threshold_value:
                return True
            elif rule.operator == "gte" and value >= rule.threshold_value:
                return True
            elif rule.operator == "lte" and value <= rule.threshold_value:
                return True
            elif rule.operator == "eq" and abs(value - rule.threshold_value) < 0.001:
                return True
        except Exception as e:
            logging.error(f"Error evaluating alert condition: {e}")
        
        return False

    async def _trigger_alert(self, rule: AlertRule, value: float):
        """Trigger an alert"""
        try:
            # Create alert
            alert = Alert(
                rule_id=rule.id,
                message=f"{rule.description}: Value {value:.4f} {rule.operator} {rule.threshold_value}",
                severity=rule.severity,
                triggered_value=value
            )
            
            # Save to database
            db = get_database()
            await db.execute("""
                INSERT INTO alerts (rule_id, message, severity, triggered_value, created_at)
                VALUES (?, ?, ?, ?, ?)
            """, (
                rule.id, alert.message, alert.severity, 
                alert.triggered_value, alert.created_at
            ))
            
            # Add to history
            self.alert_history.append(alert)
            
            # Set cooldown
            self.alert_cooldown[rule.id] = datetime.now(timezone.utc)
            
            logging.warning(f"Alert triggered: {alert.message}")
            
            # Send notification (implement based on requirements)
            await self._send_notification(alert)
            
        except Exception as e:
            logging.error(f"Error triggering alert: {e}")

    async def _send_notification(self, alert: Alert):
        """Send alert notification (email, Slack, etc.)"""
        try:
            # Implement notification logic here
            # For now, just log the alert
            logging.info(f"Alert Notification - {alert.severity}: {alert.message}")
            
        except Exception as e:
            logging.error(f"Error sending notification: {e}")

    async def resolve_alert(self, alert_id: int):
        """Mark an alert as resolved"""
        try:
            db = get_database()
            await db.execute("""
                UPDATE alerts SET resolved = 1, resolved_at = ?
                WHERE id = ?
            """, (datetime.now(timezone.utc), alert_id))
            
            logging.info(f"Alert {alert_id} marked as resolved")
            
        except Exception as e:
            logging.error(f"Error resolving alert: {e}")

    async def get_active_alerts(self) -> List[Alert]:
        """Get all active (unresolved) alerts"""
        try:
            db = get_database()
            results = await db.fetch_all("""
                SELECT * FROM alerts WHERE resolved = 0 
                ORDER BY created_at DESC
            """)
            
            return [Alert(**row) for row in results]
            
        except Exception as e:
            logging.error(f"Error getting active alerts: {e}")
            return []

    async def get_alert_statistics(self) -> Dict[str, Any]:
        """Get alert statistics"""
        try:
            db = get_database()
            
            # Total alerts by severity
            severity_stats = await db.fetch_all("""
                SELECT severity, COUNT(*) as count
                FROM alerts
                WHERE created_at >= datetime('now', '-24 hours')
                GROUP BY severity
            """)
            
            # Alerts by rule
            rule_stats = await db.fetch_all("""
                SELECT ar.name, ar.metric_type, COUNT(*) as count
                FROM alerts a
                JOIN alert_rules ar ON a.rule_id = ar.id
                WHERE a.created_at >= datetime('now', '-24 hours')
                GROUP BY ar.id, ar.name, ar.metric_type
            """)
            
            return {
                "severity_distribution": {row["severity"]: row["count"] for row in severity_stats},
                "rule_triggers": rule_stats,
                "total_alerts_24h": sum(row["count"] for row in severity_stats)
            }
            
        except Exception as e:
            logging.error(f"Error getting alert statistics: {e}")
            return {}

    async def create_default_alerts(self):
        """Create default alert rules"""
        default_rules = [
            AlertRule(
                name="High Daily Loss",
                description="Portfolio daily loss exceeds threshold",
                metric_type=MetricType.PNL,
                threshold_value=-5.0,  # -5%
                operator="lt",
                severity=AlertSeverity.HIGH,
                portfolio_id="*"
            ),
            AlertRule(
                name="High Volatility",
                description="Portfolio volatility exceeds threshold",
                metric_type=MetricType.VOLATILITY,
                threshold_value=0.3,  # 30%
                operator="gt",
                severity=AlertSeverity.MEDIUM,
                portfolio_id="*"
            ),
            AlertRule(
                name="High VaR",
                description="1-day VaR exceeds threshold",
                metric_type=MetricType.VAR,
                threshold_value=10.0,  # $10,000
                operator="gt",
                severity=AlertSeverity.HIGH,
                portfolio_id="*"
            ),
            AlertRule(
                name="Critical Max Drawdown",
                description="Maximum drawdown exceeds threshold",
                metric_type=MetricType.DRAWDOWN,
                threshold_value=20.0,  # 20%
                operator="gt",
                severity=AlertSeverity.CRITICAL,
                portfolio_id="*"
            ),
            AlertRule(
                name="High Latency",
                description="System latency exceeds threshold",
                metric_type=MetricType.LATENCY,
                threshold_value=1000.0,  # 1000ms
                operator="gt",
                severity=AlertSeverity.MEDIUM
            ),
            AlertRule(
                name="Low Sharpe Ratio",
                description="Strategy Sharpe ratio below threshold",
                metric_type=MetricType.SHARPE_RATIO,
                threshold_value=0.5,
                operator="lt",
                severity=AlertSeverity.MEDIUM,
                strategy_id="*"
            ),
            AlertRule(
                name="High Correlation",
                description="Asset correlation exceeds threshold",
                metric_type=MetricType.CORRELATION,
                threshold_value=0.9,  # 90%
                operator="gt",
                severity=AlertSeverity.MEDIUM,
                portfolio_id="*"
            )
        ]
        
        try:
            db = get_database()
            
            for rule in default_rules:
                # Check if rule already exists
                existing = await db.fetch_one("""
                    SELECT id FROM alert_rules WHERE name = ?
                """, rule.name)
                
                if not existing:
                    await db.execute("""
                        INSERT INTO alert_rules (name, description, metric_type, threshold_value,
                                               operator, severity, enabled, created_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (
                        rule.name, rule.description, rule.metric_type,
                        rule.threshold_value, rule.operator, rule.severity,
                        rule.enabled, rule.created_at
                    ))
                    
            logging.info("Default alert rules created")
            
        except Exception as e:
            logging.error(f"Error creating default alerts: {e}")

# Global alert manager instance
alert_manager = None

def get_alert_manager() -> AlertManager:
    """Get alert manager instance"""
    global alert_manager
    if alert_manager is None:
        alert_manager = AlertManager()
    return alert_manager