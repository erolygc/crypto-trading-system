import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import json
import logging
from dataclasses import dataclass
from enum import Enum

class DataQuality(Enum):
    EXCELLENT = "excellent"
    GOOD = "good"
    FAIR = "fair"
    POOR = "poor"
    INVALID = "invalid"

@dataclass
class DataQualityMetrics:
    completeness: float  # 0-1
    accuracy: float      # 0-1
    consistency: float   # 0-1
    timeliness: float    # 0-1
    overall: DataQuality

class DataValidator:
    """Data validation and quality assessment utilities"""
    
    @staticmethod
    def validate_pnl_data(pnl_records: List[Dict[str, Any]]) -> Tuple[bool, List[str]]:
        """Validate P&L data records"""
        errors = []
        
        for i, record in enumerate(pnl_records):
            # Required fields check
            required_fields = ['portfolio_id', 'strategy_id', 'total_pnl', 'daily_pnl', 'timestamp']
            for field in required_fields:
                if field not in record:
                    errors.append(f"Record {i}: Missing required field '{field}'")
            
            # Value validation
            if 'total_pnl' in record and not isinstance(record['total_pnl'], (int, float)):
                errors.append(f"Record {i}: total_pnl must be numeric")
            
            if 'daily_pnl' in record and not isinstance(record['daily_pnl'], (int, float)):
                errors.append(f"Record {i}: daily_pnl must be numeric")
            
            # Timestamp validation
            if 'timestamp' in record:
                try:
                    datetime.fromisoformat(record['timestamp'].replace('Z', '+00:00'))
                except (ValueError, AttributeError):
                    errors.append(f"Record {i}: Invalid timestamp format")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def validate_portfolio_health(health_records: List[Dict[str, Any]]) -> Tuple[bool, List[str]]:
        """Validate portfolio health records"""
        errors = []
        
        for i, record in enumerate(health_records):
            # Required fields
            required_fields = ['portfolio_id', 'total_value', 'available_balance', 'used_balance']
            for field in required_fields:
                if field not in record:
                    errors.append(f"Record {i}: Missing required field '{field}'")
            
            # Balance consistency check
            if all(field in record for field in ['total_value', 'available_balance', 'used_balance']):
                total = record['total_value']
                available = record['available_balance']
                used = record['used_balance']
                
                if abs(total - (available + used)) > 0.01:  # Allow for small rounding errors
                    errors.append(f"Record {i}: Balance inconsistency - total != available + used")
            
            # Utilization rate check
            if 'utilization_rate' in record:
                rate = record['utilization_rate']
                if not (0 <= rate <= 1):
                    errors.append(f"Record {i}: utilization_rate must be between 0 and 1")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def assess_data_quality(records: List[Dict[str, Any]], 
                          expected_fields: List[str]) -> DataQualityMetrics:
        """Assess overall data quality"""
        if not records:
            return DataQualityMetrics(0, 0, 0, 0, DataQuality.INVALID)
        
        total_records = len(records)
        
        # Completeness - percentage of records with all expected fields
        complete_records = 0
        for record in records:
            if all(field in record and record[field] is not None for field in expected_fields):
                complete_records += 1
        
        completeness = complete_records / total_records
        
        # Accuracy - assume high if completeness is high (would need domain knowledge for real validation)
        accuracy = min(1.0, completeness * 1.2)
        
        # Consistency - check for logical consistency in the data
        consistency = 1.0
        # Add specific consistency checks here
        
        # Timeliness - assume recent data is timely
        timely_records = 0
        now = datetime.now()
        for record in records:
            if 'timestamp' in record:
                try:
                    record_time = datetime.fromisoformat(record['timestamp'].replace('Z', '+00:00'))
                    if (now - record_time).days <= 1:  # Data within last day
                        timely_records += 1
                except (ValueError, AttributeError):
                    pass
        
        timeliness = timely_records / total_records if total_records > 0 else 0
        
        # Overall quality score
        overall_score = (completeness + accuracy + consistency + timeliness) / 4
        
        if overall_score >= 0.9:
            overall = DataQuality.EXCELLENT
        elif overall_score >= 0.75:
            overall = DataQuality.GOOD
        elif overall_score >= 0.6:
            overall = DataQuality.FAIR
        elif overall_score >= 0.4:
            overall = DataQuality.POOR
        else:
            overall = DataQuality.INVALID
        
        return DataQualityMetrics(completeness, accuracy, consistency, timeliness, overall)

class DataAggregator:
    """Data aggregation utilities"""
    
    @staticmethod
    def aggregate_pnl_by_portfolio(pnl_records: List[Dict[str, Any]]) -> Dict[str, Dict[str, float]]:
        """Aggregate P&L data by portfolio"""
        portfolio_aggregates = {}
        
        for record in pnl_records:
            portfolio_id = record['portfolio_id']
            
            if portfolio_id not in portfolio_aggregates:
                portfolio_aggregates[portfolio_id] = {
                    'total_realized_pnl': 0.0,
                    'total_unrealized_pnl': 0.0,
                    'total_pnl': 0.0,
                    'daily_pnl': 0.0,
                    'record_count': 0,
                    'latest_timestamp': None
                }
            
            agg = portfolio_aggregates[portfolio_id]
            agg['total_realized_pnl'] += record.get('realized_pnl', 0)
            agg['total_unrealized_pnl'] += record.get('unrealized_pnl', 0)
            agg['total_pnl'] += record.get('total_pnl', 0)
            agg['daily_pnl'] += record.get('daily_pnl', 0)
            agg['record_count'] += 1
            
            if agg['latest_timestamp'] is None or record.get('timestamp', '') > agg['latest_timestamp']:
                agg['latest_timestamp'] = record.get('timestamp')
        
        return portfolio_aggregates
    
    @staticmethod
    def aggregate_risk_metrics_by_portfolio(risk_records: List[Dict[str, Any]]) -> Dict[str, Dict[str, float]]:
        """Aggregate risk metrics by portfolio"""
        portfolio_risk = {}
        
        for record in risk_records:
            portfolio_id = record['portfolio_id']
            
            if portfolio_id not in portfolio_risk:
                portfolio_risk[portfolio_id] = {
                    'var_1d_values': [],
                    'var_5d_values': [],
                    'beta_values': [],
                    'sharpe_ratios': [],
                    'max_drawdowns': [],
                    'latest_record': None
                }
            
            risk_data = portfolio_risk[portfolio_id]
            risk_data['var_1d_values'].append(record.get('var_1d', 0))
            risk_data['var_5d_values'].append(record.get('var_5d', 0))
            risk_data['beta_values'].append(record.get('beta', 0))
            risk_data['sharpe_ratios'].append(record.get('sharpe_ratio', 0))
            risk_data['max_drawdowns'].append(record.get('max_drawdown', 0))
            
            # Keep latest record
            if (risk_data['latest_record'] is None or 
                record.get('timestamp', '') > risk_data['latest_record'].get('timestamp', '')):
                risk_data['latest_record'] = record
        
        # Calculate summary statistics
        for portfolio_id, data in portfolio_risk.items():
            if data['var_1d_values']:
                data['avg_var_1d'] = np.mean(data['var_1d_values'])
                data['avg_var_5d'] = np.mean(data['var_5d_values'])
                data['avg_beta'] = np.mean(data['beta_values'])
                data['avg_sharpe'] = np.mean(data['sharpe_ratios'])
                data['avg_max_drawdown'] = np.mean(data['max_drawdowns'])
        
        return portfolio_risk

class TimeSeriesProcessor:
    """Time series data processing utilities"""
    
    @staticmethod
    def resample_time_series(data: List[Dict[str, Any]], 
                           time_column: str,
                           value_column: str,
                           frequency: str = '1H') -> List[Dict[str, Any]]:
        """Resample time series data to specified frequency"""
        if not data:
            return []
        
        # Convert to DataFrame
        df = pd.DataFrame(data)
        df[time_column] = pd.to_datetime(df[time_column])
        df = df.set_index(time_column)
        
        # Resample based on frequency
        if frequency == '1H':
            resampled = df[value_column].resample('1H').mean()
        elif frequency == '1D':
            resampled = df[value_column].resample('1D').mean()
        elif frequency == '1W':
            resampled = df[value_column].resample('1W').mean()
        else:
            resampled = df[value_column].resample(frequency).mean()
        
        # Convert back to list of dicts
        result = []
        for timestamp, value in resampled.items():
            result.append({
                time_column: timestamp.isoformat(),
                value_column: value
            })
        
        return result
    
    @staticmethod
    def calculate_moving_averages(data: List[Dict[str, Any]], 
                                time_column: str,
                                value_column: str,
                                window_sizes: List[int] = [5, 10, 20]) -> List[Dict[str, Any]]:
        """Calculate moving averages for time series data"""
        if not data:
            return []
        
        df = pd.DataFrame(data)
        df[time_column] = pd.to_datetime(df[time_column])
        df = df.sort_values(time_column)
        
        result = []
        for _, row in df.iterrows():
            record = row.to_dict()
            
            # Calculate moving averages
            for window in window_sizes:
                ma_key = f'ma_{window}'
                
                # Get window of data up to current point
                current_time = row[time_column]
                window_data = df[df[time_column] <= current_time][value_column]
                
                if len(window_data) >= window:
                    record[ma_key] = window_data.tail(window).mean()
                else:
                    record[ma_key] = window_data.mean() if len(window_data) > 0 else None
            
            result.append(record)
        
        return result
    
    @staticmethod
    def detect_anomalies(data: List[Dict[str, Any]], 
                        time_column: str,
                        value_column: str,
                        method: str = 'zscore',
                        threshold: float = 3.0) -> List[Dict[str, Any]]:
        """Detect anomalies in time series data"""
        if not data:
            return []
        
        df = pd.DataFrame(data)
        values = df[value_column].values
        
        anomalies = []
        
        if method == 'zscore':
            # Z-score based anomaly detection
            mean_val = np.mean(values)
            std_val = np.std(values)
            
            for i, (_, row) in enumerate(df.iterrows()):
                z_score = abs((row[value_column] - mean_val) / std_val) if std_val > 0 else 0
                
                anomaly_record = row.to_dict()
                anomaly_record['anomaly_score'] = z_score
                anomaly_record['is_anomaly'] = z_score > threshold
                anomalies.append(anomaly_record)
        
        elif method == 'iqr':
            # Interquartile Range based anomaly detection
            Q1 = np.percentile(values, 25)
            Q3 = np.percentile(values, 75)
            IQR = Q3 - Q1
            
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            
            for _, row in df.iterrows():
                value = row[value_column]
                
                anomaly_record = row.to_dict()
                anomaly_record['is_anomaly'] = value < lower_bound or value > upper_bound
                anomaly_record['anomaly_score'] = max(lower_bound - value, value - upper_bound, 0)
                anomalies.append(anomaly_record)
        
        return anomalies

class DataExporter:
    """Data export utilities"""
    
    @staticmethod
    def export_to_json(data: List[Dict[str, Any]], filename: str) -> bool:
        """Export data to JSON file"""
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False, default=str)
            return True
        except Exception as e:
            logging.error(f"Error exporting to JSON: {e}")
            return False
    
    @staticmethod
    def export_to_csv(data: List[Dict[str, Any]], filename: str) -> bool:
        """Export data to CSV file"""
        try:
            if not data:
                return False
            
            df = pd.DataFrame(data)
            df.to_csv(filename, index=False)
            return True
        except Exception as e:
            logging.error(f"Error exporting to CSV: {e}")
            return False
    
    @staticmethod
    def export_performance_summary(portfolio_summaries: Dict[str, Dict[str, Any]], 
                                 filename: str) -> bool:
        """Export performance summary to formatted report"""
        try:
            report_lines = []
            report_lines.append("PORTFOLIO PERFORMANCE SUMMARY")
            report_lines.append("=" * 50)
            report_lines.append(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            report_lines.append("")
            
            for portfolio_id, summary in portfolio_summaries.items():
                report_lines.append(f"Portfolio ID: {portfolio_id}")
                report_lines.append("-" * 30)
                
                if 'total_return' in summary:
                    report_lines.append(f"Total Return: {summary['total_return']:.2%}")
                
                if 'annual_return' in summary:
                    report_lines.append(f"Annual Return: {summary['annual_return']:.2%}")
                
                if 'volatility' in summary:
                    report_lines.append(f"Volatility: {summary['volatility']:.2%}")
                
                if 'sharpe_ratio' in summary:
                    report_lines.append(f"Sharpe Ratio: {summary['sharpe_ratio']:.2f}")
                
                if 'max_drawdown' in summary:
                    report_lines.append(f"Max Drawdown: {summary['max_drawdown']:.2%}")
                
                report_lines.append("")
            
            with open(filename, 'w', encoding='utf-8') as f:
                f.write('\n'.join(report_lines))
            
            return True
        except Exception as e:
            logging.error(f"Error exporting performance summary: {e}")
            return False

class PerformanceBenchmark:
    """Performance benchmarking utilities"""
    
    @staticmethod
    def compare_to_benchmark(portfolio_returns: List[float], 
                           benchmark_returns: List[float]) -> Dict[str, float]:
        """Compare portfolio performance to benchmark"""
        if len(portfolio_returns) != len(benchmark_returns):
            raise ValueError("Portfolio and benchmark return series must have same length")
        
        portfolio_array = np.array(portfolio_returns)
        benchmark_array = np.array(benchmark_returns)
        
        # Calculate correlation
        correlation = np.corrcoef(portfolio_array, benchmark_array)[0, 1]
        
        # Calculate tracking error
        tracking_error = np.std(portfolio_array - benchmark_array) * np.sqrt(252)
        
        # Calculate information ratio
        excess_returns = portfolio_array - benchmark_array
        information_ratio = np.mean(excess_returns) * 252 / tracking_error if tracking_error > 0 else 0
        
        # Calculate beta
        covariance = np.cov(portfolio_array, benchmark_array)[0, 1]
        benchmark_variance = np.var(benchmark_array)
        beta = covariance / benchmark_variance if benchmark_variance > 0 else 1.0
        
        # Calculate alpha
        portfolio_annual = np.mean(portfolio_array) * 252
        benchmark_annual = np.mean(benchmark_array) * 252
        alpha = portfolio_annual - (0.02 + beta * (benchmark_annual - 0.02))  # Assuming 2% risk-free rate
        
        return {
            'correlation': float(correlation),
            'tracking_error': float(tracking_error),
            'information_ratio': float(information_ratio),
            'beta': float(beta),
            'alpha': float(alpha)
        }
    
    @staticmethod
    def calculate_risk_adjusted_performance(returns: List[float]) -> Dict[str, float]:
        """Calculate various risk-adjusted performance metrics"""
        if len(returns) < 2:
            return {'error': 'Insufficient data'}
        
        returns_array = np.array(returns)
        
        # Basic metrics
        mean_return = np.mean(returns_array)
        volatility = np.std(returns_array) * np.sqrt(252)
        
        # Risk-adjusted metrics
        sharpe_ratio = (mean_return * 252) / volatility if volatility > 0 else 0
        
        # Sortino ratio
        downside_returns = returns_array[returns_array < 0]
        downside_std = np.std(downside_returns) * np.sqrt(252) if len(downside_returns) > 0 else 0
        sortino_ratio = (mean_return * 252) / downside_std if downside_std > 0 else 0
        
        # Maximum drawdown
        cumulative_returns = np.cumprod(1 + returns_array)
        running_max = np.maximum.accumulate(cumulative_returns)
        drawdowns = (cumulative_returns - running_max) / running_max
        max_drawdown = abs(np.min(drawdowns))
        
        # Calmar ratio
        calmar_ratio = (mean_return * 252) / max_drawdown if max_drawdown > 0 else 0
        
        return {
            'annual_return': float(mean_return * 252),
            'annual_volatility': float(volatility),
            'sharpe_ratio': float(sharpe_ratio),
            'sortino_ratio': float(sortino_ratio),
            'max_drawdown': float(max_drawdown),
            'calmar_ratio': float(calmar_ratio)
        }