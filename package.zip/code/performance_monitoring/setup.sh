#!/bin/bash

# Performance Monitoring System Setup Script
# Bu script sistemi kurar, test eder ve çalıştırır

set -e

echo "🚀 Performance Monitoring System Setup"
echo "======================================"

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check Python version
check_python() {
    print_status "Checking Python version..."
    if command -v python3 &> /dev/null; then
        PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
        print_success "Python $PYTHON_VERSION found"
    else
        print_error "Python 3 not found. Please install Python 3.8+"
        exit 1
    fi
}

# Check pip
check_pip() {
    print_status "Checking pip..."
    if command -v pip3 &> /dev/null; then
        print_success "pip found"
    else
        print_error "pip not found. Please install pip"
        exit 1
    fi
}

# Install dependencies
install_dependencies() {
    print_status "Installing dependencies..."
    pip3 install -r requirements.txt
    print_success "Dependencies installed successfully"
}

# Setup database
setup_database() {
    print_status "Setting up database..."
    python3 run.py db migrate
    print_success "Database setup completed"
}

# Generate sample data
generate_sample_data() {
    print_status "Generating sample data for testing..."
    python3 generate_sample_data.py
    print_success "Sample data generated"
}

# Run tests
run_tests() {
    print_status "Running system tests..."
    if python3 run.py test; then
        print_success "All tests passed"
    else
        print_warning "Some tests failed, but this may be expected"
    fi
}

# Check system status
check_status() {
    print_status "Checking system status..."
    python3 run.py status
}

# Start services
start_services() {
    print_status "Starting Performance Monitoring System..."
    
    # Start API server in background
    print_status "Starting API server on port 8000..."
    python3 run.py server &
    API_PID=$!
    
    # Wait for server to start
    sleep 3
    
    # Test API connectivity
    if curl -s http://localhost:8000/health > /dev/null; then
        print_success "API server started successfully (PID: $API_PID)"
        print_success "Dashboard available at: http://localhost:8000/dashboard"
        print_success "API docs available at: http://localhost:8000/docs"
        echo ""
        echo "🎯 Quick Access URLs:"
        echo "   📊 Dashboard: http://localhost:8000/dashboard"
        echo "   📖 API Docs: http://localhost:8000/docs"
        echo "   ❤️  Health: http://localhost:8000/health"
        echo ""
        print_status "Press Ctrl+C to stop the server"
        
        # Wait for interrupt
        trap "print_status 'Stopping API server...'; kill $API_PID; exit" INT
        wait $API_PID
    else
        print_error "API server failed to start"
        kill $API_PID 2>/dev/null || true
        exit 1
    fi
}

# Show usage
show_usage() {
    echo "Usage: $0 [COMMAND]"
    echo ""
    echo "Commands:"
    echo "  setup     - Full setup (install, database, sample data, tests)"
    echo "  start     - Start the system"
    echo "  test      - Run tests only"
    echo "  data      - Generate sample data only"
    echo "  clean     - Clean up and restart"
    echo "  status    - Check system status"
    echo "  help      - Show this help"
    echo ""
    echo "Examples:"
    echo "  $0 setup    # Full setup"
    echo "  $0 start    # Start services"
    echo "  $0 test     # Run tests"
}

# Main script
main() {
    cd "$(dirname "$0")"
    
    case "${1:-}" in
        "setup")
            print_status "Starting full setup..."
            check_python
            check_pip
            install_dependencies
            setup_database
            generate_sample_data
            run_tests
            print_success "Setup completed! Use '$0 start' to launch the system"
            ;;
        "start")
            start_services
            ;;
        "test")
            run_tests
            ;;
        "data")
            generate_sample_data
            ;;
        "clean")
            print_status "Cleaning up..."
            rm -f performance_monitoring.db
            rm -f *.log
            rm -rf __pycache__
            find . -name "*.pyc" -delete
            find . -name "__pycache__" -type d -exec rm -rf {} + 2>/dev/null || true
            print_success "Cleanup completed"
            print_status "Run '$0 setup' to restart"
            ;;
        "status")
            check_status
            ;;
        "help"|"-h"|"--help")
            show_usage
            ;;
        "")
            print_status "No command specified. Running full setup..."
            $0 setup
            ;;
        *)
            print_error "Unknown command: $1"
            show_usage
            exit 1
            ;;
    esac
}

# Run main function with all arguments
main "$@"