#!/usr/bin/env python3
"""
Performance Monitoring System Runner
"""

import argparse
import asyncio
import logging
import sys
import uvicorn
from pathlib import Path

# Add the current directory to Python path
sys.path.insert(0, str(Path(__file__).parent))

from api.main import app
from database import create_tables, cleanup_old_data
from alerts.alert_manager import get_alert_manager
from analytics.system_monitor import get_system_monitor
from utils.data_utils import DataValidator
from config import settings, get_environment_config

# Configure logging
def setup_logging():
    """Setup logging configuration"""
    logging.basicConfig(
        level=getattr(logging, settings.LOG_LEVEL.value),
        format=settings.LOG_FORMAT,
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(settings.LOG_FILE) if settings.LOG_FILE else logging.NullHandler()
        ]
    )
    
    # Set specific logger levels
    logging.getLogger("uvicorn").setLevel(logging.INFO)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)

def run_migrations():
    """Run database migrations and setup"""
    async def _run_migrations():
        try:
            logging.info("Creating database tables...")
            await create_tables()
            
            logging.info("Creating default alert rules...")
            alert_manager = get_alert_manager()
            await alert_manager.create_default_alerts()
            
            logging.info("Database setup completed successfully")
        except Exception as e:
            logging.error(f"Error during database setup: {e}")
            sys.exit(1)
    
    asyncio.run(_run_migrations())

def start_api_server():
    """Start the FastAPI server"""
    logging.info(f"Starting API server on {settings.API_HOST}:{settings.API_PORT}")
    logging.info(f"Environment: {get_environment_config()}")
    
    uvicorn.run(
        "api.main:app",
        host=settings.API_HOST,
        port=settings.API_PORT,
        reload=settings.API_RELOAD and settings.API_DEBUG,
        log_level=settings.LOG_LEVEL.value.lower(),
        access_log=True
    )

def start_monitoring_services():
    """Start background monitoring services"""
    async def _start_monitoring():
        try:
            logging.info("Starting monitoring services...")
            
            # Start system monitor
            system_monitor = get_system_monitor()
            await system_monitor.start_monitoring()
            
            # Start periodic data cleanup
            async def cleanup_task():
                while True:
                    try:
                        await asyncio.sleep(24 * 3600)  # Daily cleanup
                        logging.info("Running scheduled data cleanup...")
                        await cleanup_old_data()
                    except Exception as e:
                        logging.error(f"Error during cleanup task: {e}")
            
            cleanup_task_coro = asyncio.create_task(cleanup_task())
            
            # Keep the services running
            try:
                await asyncio.Future()  # Run forever
            except KeyboardInterrupt:
                logging.info("Shutting down monitoring services...")
                await system_monitor.stop_monitoring()
                cleanup_task_coro.cancel()
                
        except Exception as e:
            logging.error(f"Error starting monitoring services: {e}")
            sys.exit(1)
    
    asyncio.run(_start_monitoring())

def validate_data():
    """Validate system data quality"""
    logging.info("Validating data quality...")
    
    # This would be implemented to validate existing data
    validation_results = {
        "data_quality": "good",
        "missing_fields": [],
        "anomalies": [],
        "recommendations": [
            "Ensure all portfolios have consistent P&L data",
            "Verify risk metrics are calculated correctly",
            "Check for data gaps in time series"
        ]
    }
    
    logging.info(f"Data validation results: {validation_results}")
    return validation_results

def test_system():
    """Run system tests"""
    logging.info("Running system tests...")
    
    # Import test modules
    try:
        from tests.test_performance_monitoring import *
        
        # Run pytest programmatically
        import pytest
        exit_code = pytest.main([
            "tests/test_performance_monitoring.py",
            "-v",
            "--tb=short"
        ])
        
        if exit_code == 0:
            logging.info("All tests passed successfully!")
        else:
            logging.error("Some tests failed!")
            
        return exit_code
        
    except ImportError as e:
        logging.error(f"Could not import test modules: {e}")
        return 1

def show_status():
    """Show system status"""
    logging.info("Checking system status...")
    
    status_info = {
        "database": "connected" if settings.DATABASE_URL else "not configured",
        "redis": f"{settings.REDIS_HOST}:{settings.REDIS_PORT}",
        "api_host": f"{settings.API_HOST}:{settings.API_PORT}",
        "monitoring_interval": f"{settings.MONITORING_INTERVAL}s",
        "data_retention": f"{settings.DATA_RETENTION_DAYS} days",
        "log_level": settings.LOG_LEVEL.value
    }
    
    for component, status in status_info.items():
        logging.info(f"{component}: {status}")

def create_sample_data():
    """Create sample data for testing"""
    logging.info("Creating sample data...")
    
    # This would create sample P&L, risk, and other data
    sample_data_created = True
    
    if sample_data_created:
        logging.info("Sample data created successfully")
    else:
        logging.error("Failed to create sample data")
    
    return sample_data_created

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="Performance Monitoring System")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Server commands
    server_parser = subparsers.add_parser("server", help="Start API server")
    server_parser.add_argument("--host", default=settings.API_HOST, help="Host to bind to")
    server_parser.add_argument("--port", type=int, default=settings.API_PORT, help="Port to bind to")
    
    # Monitoring commands
    monitor_parser = subparsers.add_parser("monitor", help="Start monitoring services")
    
    # Database commands
    db_parser = subparsers.add_parser("db", help="Database operations")
    db_subparsers = db_parser.add_subparsers(dest="db_command")
    db_subparsers.add_parser("migrate", help="Run database migrations")
    db_subparsers.add_parser("cleanup", help="Clean up old data")
    
    # Utility commands
    subparsers.add_parser("validate", help="Validate data quality")
    subparsers.add_parser("test", help="Run system tests")
    subparsers.add_parser("status", help="Show system status")
    subparsers.add_parser("sample", help="Create sample data")
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging()
    
    if not args.command:
        parser.print_help()
        return
    
    try:
        if args.command == "server":
            if args.host:
                settings.API_HOST = args.host
            if args.port:
                settings.API_PORT = args.port
            start_api_server()
            
        elif args.command == "monitor":
            start_monitoring_services()
            
        elif args.command == "db":
            if args.db_command == "migrate":
                run_migrations()
            elif args.db_command == "cleanup":
                asyncio.run(cleanup_old_data())
            else:
                db_parser.print_help()
                
        elif args.command == "validate":
            validate_data()
            
        elif args.command == "test":
            exit_code = test_system()
            sys.exit(exit_code)
            
        elif args.command == "status":
            show_status()
            
        elif args.command == "sample":
            create_sample_data()
            
        else:
            parser.print_help()
            
    except KeyboardInterrupt:
        logging.info("Received interrupt signal, shutting down...")
        sys.exit(0)
    except Exception as e:
        logging.error(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()