import numpy as np
import pandas as pd
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Any
import asyncio
import logging
from database import get_database
from models import PerformanceMetric, MetricType

class PerformanceAnalyzer:
    def __init__(self):
        self.calculation_cache = {}
        self.cache_ttl = 300  # 5 minutes

    async def calculate_sharpe_ratio(self, returns: List[float], risk_free_rate: float = 0.02) -> float:
        """Calculate Sharpe ratio"""
        try:
            if len(returns) < 2:
                return 0.0
            
            returns_array = np.array(returns)
            excess_returns = returns_array - risk_free_rate / 252  # Daily risk-free rate
            
            if np.std(excess_returns) == 0:
                return 0.0
            
            sharpe_ratio = np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252)
            return float(sharpe_ratio)
            
        except Exception as e:
            logging.error(f"Error calculating Sharpe ratio: {e}")
            return 0.0

    async def calculate_sortino_ratio(self, returns: List[float], risk_free_rate: float = 0.02) -> float:
        """Calculate Sortino ratio"""
        try:
            if len(returns) < 2:
                return 0.0
            
            returns_array = np.array(returns)
            excess_returns = returns_array - risk_free_rate / 252
            
            # Only consider negative returns for downside deviation
            downside_returns = excess_returns[excess_returns < 0]
            
            if len(downside_returns) == 0:
                return float('inf')  # No downside deviation
            
            downside_deviation = np.std(downside_returns)
            
            if downside_deviation == 0:
                return 0.0
            
            sortino_ratio = np.mean(excess_returns) / downside_deviation * np.sqrt(252)
            return float(sortino_ratio)
            
        except Exception as e:
            logging.error(f"Error calculating Sortino ratio: {e}")
            return 0.0

    async def calculate_max_drawdown(self, returns: List[float]) -> float:
        """Calculate maximum drawdown"""
        try:
            if len(returns) < 2:
                return 0.0
            
            cumulative_returns = np.cumprod(1 + np.array(returns))
            running_max = np.maximum.accumulate(cumulative_returns)
            drawdown = (cumulative_returns - running_max) / running_max
            
            max_drawdown = np.min(drawdown)
            return float(abs(max_drawdown))
            
        except Exception as e:
            logging.error(f"Error calculating max drawdown: {e}")
            return 0.0

    async def calculate_calmar_ratio(self, returns: List[float]) -> float:
        """Calculate Calmar ratio (annual return / max drawdown)"""
        try:
            max_dd = await self.calculate_max_drawdown(returns)
            if max_dd == 0:
                return 0.0
            
            annual_return = np.mean(returns) * 252
            calmar_ratio = annual_return / max_dd
            return float(calmar_ratio)
            
        except Exception as e:
            logging.error(f"Error calculating Calmar ratio: {e}")
            return 0.0

    async def calculate_volatility(self, returns: List[float]) -> float:
        """Calculate annualized volatility"""
        try:
            if len(returns) < 2:
                return 0.0
            
            returns_array = np.array(returns)
            volatility = np.std(returns_array) * np.sqrt(252)
            return float(volatility)
            
        except Exception as e:
            logging.error(f"Error calculating volatility: {e}")
            return 0.0

    async def calculate_win_rate(self, trades_data: Dict[str, Any]) -> float:
        """Calculate win rate from trades data"""
        try:
            total_trades = trades_data.get('total_trades', 0)
            winning_trades = trades_data.get('winning_trades', 0)
            
            if total_trades == 0:
                return 0.0
            
            win_rate = winning_trades / total_trades
            return float(win_rate)
            
        except Exception as e:
            logging.error(f"Error calculating win rate: {e}")
            return 0.0

    async def calculate_profit_factor(self, trades_data: Dict[str, Any]) -> float:
        """Calculate profit factor"""
        try:
            total_profit = trades_data.get('total_profit', 0)
            total_loss = abs(trades_data.get('total_loss', 0))
            
            if total_loss == 0:
                return float('inf') if total_profit > 0 else 1.0
            
            profit_factor = total_profit / total_loss
            return float(profit_factor)
            
        except Exception as e:
            logging.error(f"Error calculating profit factor: {e}")
            return 1.0

    async def calculate_var(self, returns: List[float], confidence_level: float = 0.05) -> float:
        """Calculate Value at Risk"""
        try:
            if len(returns) < 30:  # Need sufficient data
                return 0.0
            
            returns_array = np.array(returns)
            var = np.percentile(returns_array, confidence_level * 100)
            return float(abs(var))  # Return as positive value
            
        except Exception as e:
            logging.error(f"Error calculating VaR: {e}")
            return 0.0

    async def calculate_beta(self, portfolio_returns: List[float], 
                           benchmark_returns: List[float]) -> float:
        """Calculate portfolio beta against benchmark"""
        try:
            if len(portfolio_returns) != len(benchmark_returns) or len(portfolio_returns) < 2:
                return 1.0
            
            portfolio_array = np.array(portfolio_returns)
            benchmark_array = np.array(benchmark_returns)
            
            covariance = np.cov(portfolio_array, benchmark_array)[0, 1]
            benchmark_variance = np.var(benchmark_array)
            
            if benchmark_variance == 0:
                return 1.0
            
            beta = covariance / benchmark_variance
            return float(beta)
            
        except Exception as e:
            logging.error(f"Error calculating beta: {e}")
            return 1.0

    async def calculate_alpha(self, portfolio_returns: List[float], 
                            benchmark_returns: List[float], 
                            risk_free_rate: float = 0.02) -> float:
        """Calculate portfolio alpha"""
        try:
            if len(portfolio_returns) != len(benchmark_returns):
                return 0.0
            
            # Calculate average returns
            portfolio_avg_return = np.mean(portfolio_returns)
            benchmark_avg_return = np.mean(benchmark_returns)
            
            # Calculate beta
            beta = await self.calculate_beta(portfolio_returns, benchmark_returns)
            
            # Calculate alpha
            portfolio_annual_return = portfolio_avg_return * 252
            benchmark_annual_return = benchmark_avg_return * 252
            risk_free_annual = risk_free_rate
            
            alpha = portfolio_annual_return - (risk_free_annual + beta * (benchmark_annual_return - risk_free_annual))
            
            return float(alpha)
            
        except Exception as e:
            logging.error(f"Error calculating alpha: {e}")
            return 0.0

    async def calculate_information_ratio(self, portfolio_returns: List[float], 
                                        benchmark_returns: List[float]) -> float:
        """Calculate Information Ratio"""
        try:
            if len(portfolio_returns) != len(benchmark_returns):
                return 0.0
            
            excess_returns = np.array(portfolio_returns) - np.array(benchmark_returns)
            
            if np.std(excess_returns) == 0:
                return 0.0
            
            information_ratio = np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252)
            return float(information_ratio)
            
        except Exception as e:
            logging.error(f"Error calculating information ratio: {e}")
            return 0.0

    async def analyze_portfolio_performance(self, portfolio_id: str, 
                                          lookback_days: int = 30) -> Dict[str, Any]:
        """Comprehensive portfolio performance analysis"""
        try:
            # Get P&L data for the period
            db = get_database()
            start_date = datetime.now(timezone.utc) - timedelta(days=lookback_days)
            
            pnl_results = await db.fetch_all("""
                SELECT * FROM pnl_data 
                WHERE portfolio_id = ? AND timestamp >= ?
                ORDER BY timestamp ASC
            """, portfolio_id, start_date)
            
            if len(pnl_results) < 2:
                return {"error": "Insufficient data for analysis"}
            
            # Convert to DataFrame for easier analysis
            df = pd.DataFrame(pnl_results)
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            
            # Calculate daily returns
            df['daily_return'] = df['total_pnl'].pct_change().fillna(0)
            
            # Calculate performance metrics
            returns = df['daily_return'].tolist()
            
            performance_metrics = {
                "total_return": float(df['total_pnl'].iloc[-1] / df['total_pnl'].iloc[0] - 1),
                "annualized_return": float(np.mean(returns) * 252),
                "volatility": await self.calculate_volatility(returns),
                "sharpe_ratio": await self.calculate_sharpe_ratio(returns),
                "sortino_ratio": await self.calculate_sortino_ratio(returns),
                "max_drawdown": await self.calculate_max_drawdown(returns),
                "calmar_ratio": await self.calculate_calmar_ratio(returns),
                "var_1d": await self.calculate_var(returns, 0.05),
                "var_5d": await self.calculate_var(returns * np.sqrt(5), 0.05),  # 5-day VaR
                "win_rate": float((df['daily_return'] > 0).mean()),
                "total_trades": len(df)
            }
            
            # Get benchmark comparison if available
            benchmark_data = await db.fetch_all("""
                SELECT * FROM benchmark_data 
                WHERE timestamp >= ?
                ORDER BY timestamp ASC
            """, start_date)
            
            if benchmark_data:
                benchmark_df = pd.DataFrame(benchmark_data)
                benchmark_df['timestamp'] = pd.to_datetime(benchmark_df['timestamp'])
                benchmark_df['daily_return'] = benchmark_df['value'].pct_change().fillna(0)
                
                benchmark_returns = benchmark_df['daily_return'].tolist()
                if len(benchmark_returns) == len(returns):
                    performance_metrics.update({
                        "beta": await self.calculate_beta(returns, benchmark_returns),
                        "alpha": await self.calculate_alpha(returns, benchmark_returns),
                        "information_ratio": await self.calculate_information_ratio(returns, benchmark_returns)
                    })
            
            return performance_metrics
            
        except Exception as e:
            logging.error(f"Error in portfolio performance analysis: {e}")
            return {"error": str(e)}

    async def analyze_strategy_performance(self, strategy_id: str) -> Dict[str, Any]:
        """Analyze strategy performance metrics"""
        try:
            db = get_database()
            
            # Get latest strategy performance data
            perf_result = await db.fetch_one("""
                SELECT * FROM strategy_performance 
                WHERE strategy_id = ?
                ORDER BY timestamp DESC LIMIT 1
            """, strategy_id)
            
            if not perf_result:
                return {"error": "Strategy performance data not found"}
            
            # Calculate additional metrics
            trades_data = {
                'total_trades': perf_result['total_trades'],
                'winning_trades': perf_result['winning_trades'],
                'total_profit': perf_result['total_return'] * 1000000,  # Assuming $1M portfolio
                'total_loss': perf_result['total_return'] * -500000 if perf_result['total_return'] < 0 else 500000
            }
            
            # Performance attribution
            attribution = await self.calculate_performance_attribution(strategy_id)
            
            return {
                **perf_result,
                "profit_factor": await self.calculate_profit_factor(trades_data),
                "performance_attribution": attribution
            }
            
        except Exception as e:
            logging.error(f"Error analyzing strategy performance: {e}")
            return {"error": str(e)}

    async def calculate_performance_attribution(self, strategy_id: str) -> Dict[str, float]:
        """Calculate performance attribution analysis"""
        try:
            # This is a simplified implementation
            # In practice, this would involve detailed breakdown by asset, sector, etc.
            
            db = get_database()
            
            # Get recent performance data
            results = await db.fetch_all("""
                SELECT * FROM pnl_data 
                WHERE strategy_id = ?
                ORDER BY timestamp DESC LIMIT 10
            """, strategy_id)
            
            if not results:
                return {
                    "timing_contribution": 0.0,
                    "selection_contribution": 0.0,
                    "interaction_contribution": 0.0,
                    "total_attribution": 0.0
                }
            
            # Simplified attribution calculation
            total_pnl = sum(r['total_pnl'] for r in results)
            
            return {
                "timing_contribution": total_pnl * 0.4,  # 40% timing
                "selection_contribution": total_pnl * 0.5,  # 50% selection
                "interaction_contribution": total_pnl * 0.1,  # 10% interaction
                "total_attribution": total_pnl
            }
            
        except Exception as e:
            logging.error(f"Error calculating performance attribution: {e}")
            return {"error": str(e)}

    async def get_performance_summary(self, portfolio_ids: List[str]) -> Dict[str, Any]:
        """Get performance summary for multiple portfolios"""
        try:
            summaries = {}
            
            for portfolio_id in portfolio_ids:
                performance = await self.analyze_portfolio_performance(portfolio_id)
                summaries[portfolio_id] = performance
            
            # Calculate portfolio-level metrics
            total_value = sum(p.get('total_value', 0) for p in summaries.values() if 'total_value' in p)
            total_pnl = sum(p.get('total_return', 0) * (p.get('total_value', 1) / total_value if total_value > 0 else 0) 
                          for p in summaries.values() if 'total_return' in p)
            
            return {
                "individual_portfolios": summaries,
                "portfolio_summary": {
                    "total_value": total_value,
                    "total_return": total_pnl,
                    "total_portfolios": len(portfolio_ids)
                }
            }
            
        except Exception as e:
            logging.error(f"Error getting performance summary: {e}")
            return {"error": str(e)}

# Global performance analyzer instance
performance_analyzer = None

def get_performance_analyzer() -> PerformanceAnalyzer:
    """Get performance analyzer instance"""
    global performance_analyzer
    if performance_analyzer is None:
        performance_analyzer = PerformanceAnalyzer()
    return performance_analyzer