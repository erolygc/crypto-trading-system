import numpy as np
import pandas as pd
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Any, Tuple
import asyncio
import logging
from database import get_database
from models import RiskMetrics, MetricType

class RiskAnalyzer:
    def __init__(self):
        self.risk_cache = {}
        self.cache_ttl = 600  # 10 minutes

    async def calculate_portfolio_var(self, portfolio_returns: List[float], 
                                    confidence_level: float = 0.05) -> Dict[str, float]:
        """Calculate Value at Risk using different methods"""
        try:
            if len(portfolio_returns) < 30:
                return {"error": "Insufficient data for VaR calculation"}
            
            returns_array = np.array(portfolio_returns)
            
            # Historical VaR
            historical_var = np.percentile(returns_array, confidence_level * 100)
            
            # Parametric VaR (assuming normal distribution)
            mean_return = np.mean(returns_array)
            std_return = np.std(returns_array)
            parametric_var = mean_return - (std_return * np.sqrt(252) * 2.326)  # 99% confidence
            
            # Monte Carlo VaR (simplified)
            np.random.seed(42)  # For reproducibility
            simulated_returns = np.random.normal(mean_return, std_return, 10000)
            monte_carlo_var = np.percentile(simulated_returns, confidence_level * 100)
            
            return {
                "historical_var": float(abs(historical_var)),
                "parametric_var": float(abs(parametric_var)),
                "monte_carlo_var": float(abs(monte_carlo_var)),
                "mean_return": float(mean_return),
                "volatility": float(std_return * np.sqrt(252))
            }
            
        except Exception as e:
            logging.error(f"Error calculating portfolio VaR: {e}")
            return {"error": str(e)}

    async def calculate_expected_shortfall(self, portfolio_returns: List[float],
                                         confidence_level: float = 0.05) -> float:
        """Calculate Expected Shortfall (Conditional VaR)"""
        try:
            if len(portfolio_returns) < 30:
                return 0.0
            
            returns_array = np.array(portfolio_returns)
            var_threshold = np.percentile(returns_array, confidence_level * 100)
            
            # Expected shortfall is the average of returns below VaR
            tail_returns = returns_array[returns_array <= var_threshold]
            
            if len(tail_returns) == 0:
                return abs(var_threshold)
            
            expected_shortfall = np.mean(tail_returns)
            return float(abs(expected_shortfall))
            
        except Exception as e:
            logging.error(f"Error calculating Expected Shortfall: {e}")
            return 0.0

    async def calculate_correlation_matrix(self, asset_returns: Dict[str, List[float]]) -> Dict[str, Any]:
        """Calculate correlation matrix for assets"""
        try:
            if len(asset_returns) < 2:
                return {"error": "Need at least 2 assets for correlation analysis"}
            
            # Ensure all return series have the same length
            min_length = min(len(returns) for returns in asset_returns.values())
            if min_length < 30:
                return {"error": "Insufficient data for correlation analysis"}
            
            # Create DataFrame with aligned data
            aligned_data = {}
            for asset, returns in asset_returns.items():
                aligned_data[asset] = returns[-min_length:]  # Use last min_length points
            
            df = pd.DataFrame(aligned_data)
            correlation_matrix = df.corr()
            
            # Calculate eigenvalues for diversification analysis
            eigenvalues = np.linalg.eigvals(correlation_matrix.values)
            
            # Identify high correlation pairs
            high_correlations = []
            for i in range(len(correlation_matrix.columns)):
                for j in range(i + 1, len(correlation_matrix.columns)):
                    corr_value = correlation_matrix.iloc[i, j]
                    if abs(corr_value) > 0.8:  # High correlation threshold
                        high_correlations.append({
                            "asset1": correlation_matrix.columns[i],
                            "asset2": correlation_matrix.columns[j],
                            "correlation": float(corr_value)
                        })
            
            return {
                "correlation_matrix": correlation_matrix.to_dict(),
                "eigenvalues": eigenvalues.tolist(),
                "diversification_ratio": float(np.min(eigenvalues) / np.max(eigenvalues)),
                "high_correlations": high_correlations,
                "average_correlation": float(correlation_matrix.values[np.triu_indices_from(correlation_matrix.values, k=1)].mean())
            }
            
        except Exception as e:
            logging.error(f"Error calculating correlation matrix: {e}")
            return {"error": str(e)}

    async def calculate_drawdown_series(self, portfolio_values: List[float]) -> Dict[str, Any]:
        """Calculate detailed drawdown analysis"""
        try:
            if len(portfolio_values) < 2:
                return {"error": "Insufficient data for drawdown analysis"}
            
            values_array = np.array(portfolio_values)
            
            # Calculate running maximum
            running_max = np.maximum.accumulate(values_array)
            
            # Calculate drawdowns
            drawdowns = (values_array - running_max) / running_max
            
            # Find peak and trough points
            is_peak = np.concatenate(([True], drawdowns[1:] >= drawdowns[:-1], [True]))
            is_trough = np.concatenate(([True], drawdowns[1:] < drawdowns[:-1], [True]))
            
            # Calculate drawdown periods
            peak_indices = np.where(is_peak)[0]
            trough_indices = np.where(is_trough)[0]
            
            drawdown_periods = []
            for i in range(len(peak_indices) - 1):
                start_idx = peak_indices[i]
                end_idx = trough_indices[i] if i < len(trough_indices) else len(values_array) - 1
                
                peak_value = values_array[start_idx]
                trough_value = values_array[start_idx:end_idx+1].min()
                max_drawdown = (trough_value - peak_value) / peak_value
                
                duration = end_idx - start_idx
                recovery_duration = 0
                
                # Find recovery point
                for j in range(end_idx + 1, len(values_array)):
                    if values_array[j] >= peak_value:
                        recovery_duration = j - end_idx
                        break
                
                drawdown_periods.append({
                    "start_peak": float(peak_value),
                    "end_trough": float(trough_value),
                    "max_drawdown": float(abs(max_drawdown)),
                    "duration": int(duration),
                    "recovery_duration": int(recovery_duration)
                })
            
            return {
                "max_drawdown": float(abs(np.min(drawdowns))),
                "average_drawdown": float(abs(np.mean(drawdowns[drawdowns < 0]))),
                "current_drawdown": float(abs(drawdowns[-1])),
                "drawdown_periods": drawdown_periods,
                "underwater_periods": int(np.sum(drawdowns < 0))
            }
            
        except Exception as e:
            logging.error(f"Error calculating drawdown series: {e}")
            return {"error": str(e)}

    async def calculate_risk_adjusted_metrics(self, returns: List[float],
                                           benchmark_returns: List[float] = None) -> Dict[str, float]:
        """Calculate various risk-adjusted performance metrics"""
        try:
            if len(returns) < 30:
                return {"error": "Insufficient data for risk metrics"}
            
            returns_array = np.array(returns)
            
            # Basic metrics
            mean_return = np.mean(returns_array)
            volatility = np.std(returns_array) * np.sqrt(252)
            max_drawdown = await self.calculate_max_drawdown_percentage(returns_array)
            
            # Sharpe ratio
            sharpe_ratio = mean_return * 252 / volatility if volatility > 0 else 0
            
            # Sortino ratio
            downside_returns = returns_array[returns_array < 0]
            downside_std = np.std(downside_returns) * np.sqrt(252) if len(downside_returns) > 0 else 0
            sortino_ratio = mean_return * 252 / downside_std if downside_std > 0 else 0
            
            # Calmar ratio
            calmar_ratio = (mean_return * 252) / max_drawdown if max_drawdown > 0 else 0
            
            # Information ratio (if benchmark provided)
            information_ratio = 0
            if benchmark_returns and len(benchmark_returns) == len(returns):
                excess_returns = returns_array - np.array(benchmark_returns)
                tracking_error = np.std(excess_returns) * np.sqrt(252)
                information_ratio = np.mean(excess_returns) * 252 / tracking_error if tracking_error > 0 else 0
            
            return {
                "sharpe_ratio": float(sharpe_ratio),
                "sortino_ratio": float(sortino_ratio),
                "calmar_ratio": float(calmar_ratio),
                "information_ratio": float(information_ratio),
                "annual_return": float(mean_return * 252),
                "annual_volatility": float(volatility),
                "max_drawdown": float(max_drawdown)
            }
            
        except Exception as e:
            logging.error(f"Error calculating risk-adjusted metrics: {e}")
            return {"error": str(e)}

    async def calculate_max_drawdown_percentage(self, returns: np.ndarray) -> float:
        """Calculate maximum drawdown as percentage"""
        try:
            cumulative_returns = np.cumprod(1 + returns)
            running_max = np.maximum.accumulate(cumulative_returns)
            drawdowns = (cumulative_returns - running_max) / running_max
            max_drawdown = abs(np.min(drawdowns))
            return float(max_drawdown)
            
        except Exception as e:
            logging.error(f"Error calculating max drawdown percentage: {e}")
            return 0.0

    async def calculate_beta_and_alpha(self, portfolio_returns: List[float],
                                     benchmark_returns: List[float],
                                     risk_free_rate: float = 0.02) -> Dict[str, float]:
        """Calculate beta and alpha with statistical significance"""
        try:
            if len(portfolio_returns) != len(benchmark_returns) or len(portfolio_returns) < 30:
                return {"error": "Insufficient or mismatched data for beta/alpha calculation"}
            
            portfolio_array = np.array(portfolio_returns)
            benchmark_array = np.array(benchmark_returns)
            
            # Remove any NaN values
            valid_mask = ~(np.isnan(portfolio_array) | np.isnan(benchmark_array))
            portfolio_clean = portfolio_array[valid_mask]
            benchmark_clean = benchmark_array[valid_mask]
            
            if len(portfolio_clean) < 30:
                return {"error": "Insufficient clean data for calculation"}
            
            # Calculate beta
            covariance = np.cov(portfolio_clean, benchmark_clean)[0, 1]
            benchmark_variance = np.var(benchmark_clean)
            beta = covariance / benchmark_variance if benchmark_variance > 0 else 1.0
            
            # Calculate alpha
            portfolio_mean = np.mean(portfolio_clean)
            benchmark_mean = np.mean(benchmark_clean)
            
            portfolio_annual = portfolio_mean * 252
            benchmark_annual = benchmark_mean * 252
            risk_free_annual = risk_free_rate
            
            alpha = portfolio_annual - (risk_free_annual + beta * (benchmark_annual - risk_free_annual))
            
            # Calculate R-squared
            portfolio_centered = portfolio_clean - portfolio_mean
            benchmark_centered = benchmark_clean - benchmark_mean
            
            correlation = np.corrcoef(portfolio_centered, benchmark_centered)[0, 1]
            r_squared = correlation ** 2
            
            return {
                "beta": float(beta),
                "alpha": float(alpha),
                "r_squared": float(r_squared),
                "correlation": float(correlation)
            }
            
        except Exception as e:
            logging.error(f"Error calculating beta and alpha: {e}")
            return {"error": str(e)}

    async def analyze_portfolio_risk(self, portfolio_id: str, 
                                   lookback_days: int = 30) -> Dict[str, Any]:
        """Comprehensive portfolio risk analysis"""
        try:
            db = get_database()
            start_date = datetime.now(timezone.utc) - timedelta(days=lookback_days)
            
            # Get P&L data for the period
            pnl_results = await db.fetch_all("""
                SELECT * FROM pnl_data 
                WHERE portfolio_id = ? AND timestamp >= ?
                ORDER BY timestamp ASC
            """, portfolio_id, start_date)
            
            if len(pnl_results) < 30:
                return {"error": "Insufficient data for risk analysis"}
            
            # Convert to daily returns
            portfolio_values = [r['total_pnl'] + 1000000 for r in pnl_results]  # Assuming $1M base
            returns = [0.0] + [(portfolio_values[i] - portfolio_values[i-1]) / portfolio_values[i-1] 
                              for i in range(1, len(portfolio_values))]
            
            # Get benchmark data for comparison
            benchmark_results = await db.fetch_all("""
                SELECT * FROM benchmark_data 
                WHERE timestamp >= ?
                ORDER BY timestamp ASC
            """, start_date)
            
            benchmark_returns = None
            if benchmark_results:
                benchmark_values = [r['value'] for r in benchmark_results]
                benchmark_returns = [0.0] + [(benchmark_values[i] - benchmark_values[i-1]) / benchmark_values[i-1]
                                           for i in range(1, len(benchmark_values))]
            
            # Calculate comprehensive risk metrics
            risk_analysis = {
                "var_analysis": await self.calculate_portfolio_var(returns),
                "expected_shortfall": await self.calculate_expected_shortfall(returns),
                "drawdown_analysis": await self.calculate_drawdown_series(portfolio_values),
                "risk_adjusted_metrics": await self.calculate_risk_adjusted_metrics(returns, benchmark_returns)
            }
            
            # Calculate beta and alpha if benchmark available
            if benchmark_returns and len(benchmark_returns) == len(returns):
                beta_alpha = await self.calculate_beta_and_alpha(returns, benchmark_returns)
                risk_analysis["beta_alpha_analysis"] = beta_alpha
            
            # Correlation analysis (would need asset-level data)
            risk_analysis["correlation_analysis"] = {"note": "Asset-level correlation analysis requires individual asset returns"}
            
            return risk_analysis
            
        except Exception as e:
            logging.error(f"Error in portfolio risk analysis: {e}")
            return {"error": str(e)}

    async def get_risk_dashboard_data(self, portfolio_ids: List[str]) -> Dict[str, Any]:
        """Get consolidated risk dashboard data"""
        try:
            dashboard_data = {}
            aggregate_metrics = {
                "total_portfolio_value": 0,
                "weighted_var": 0,
                "portfolio_sharpe": 0,
                "aggregate_drawdown": 0
            }
            
            total_weight = 0
            weighted_returns = []
            
            for portfolio_id in portfolio_ids:
                risk_analysis = await self.analyze_portfolio_risk(portfolio_id)
                dashboard_data[portfolio_id] = risk_analysis
                
                # Aggregate metrics (simplified)
                if "risk_adjusted_metrics" in risk_analysis and "total_value" in risk_analysis:
                    value = risk_analysis.get("total_value", 0)
                    weight = value / sum(p.get("total_value", 1) for p in dashboard_data.values() if "total_value" in p)
                    
                    aggregate_metrics["total_portfolio_value"] += value
                    aggregate_metrics["weighted_var"] += weight * risk_analysis.get("var_analysis", {}).get("historical_var", 0)
                    weighted_returns.append(risk_analysis["risk_adjusted_metrics"].get("annual_return", 0) * weight)
            
            if weighted_returns:
                aggregate_metrics["portfolio_sharpe"] = sum(weighted_returns)
                aggregate_metrics["aggregate_drawdown"] = max(p.get("drawdown_analysis", {}).get("max_drawdown", 0) 
                                                            for p in dashboard_data.values() 
                                                            if "drawdown_analysis" in p)
            
            dashboard_data["aggregate_metrics"] = aggregate_metrics
            return dashboard_data
            
        except Exception as e:
            logging.error(f"Error getting risk dashboard data: {e}")
            return {"error": str(e)}

    async def create_risk_metrics_record(self, portfolio_id: str, 
                                       risk_data: Dict[str, Any]) -> RiskMetrics:
        """Create RiskMetrics record from analysis"""
        try:
            # Extract relevant metrics
            var_1d = risk_data.get("var_analysis", {}).get("historical_var", 0)
            var_5d = var_1d * np.sqrt(5)  # 5-day VaR approximation
            
            risk_metrics = risk_data.get("risk_adjusted_metrics", {})
            beta_alpha = risk_data.get("beta_alpha_analysis", {})
            
            return RiskMetrics(
                portfolio_id=portfolio_id,
                var_1d=var_1d,
                var_5d=var_5d,
                beta=beta_alpha.get("beta", 1.0),
                alpha=beta_alpha.get("alpha", 0.0),
                sharpe_ratio=risk_metrics.get("sharpe_ratio", 0.0),
                sortino_ratio=risk_metrics.get("sortino_ratio", 0.0),
                max_drawdown=risk_metrics.get("max_drawdown", 0.0),
                volatility=risk_metrics.get("annual_volatility", 0.0),
                timestamp=datetime.now(timezone.utc)
            )
            
        except Exception as e:
            logging.error(f"Error creating risk metrics record: {e}")
            raise

# Global risk analyzer instance
risk_analyzer = None

def get_risk_analyzer() -> RiskAnalyzer:
    """Get risk analyzer instance"""
    global risk_analyzer
    if risk_analyzer is None:
        risk_analyzer = RiskAnalyzer()
    return risk_analyzer