import asyncio
import psutil
import time
import logging
import requests
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Any
from database import get_database
from models import SystemHealth, LatencyMetrics

class SystemMonitor:
    def __init__(self):
        self.monitoring_active = False
        self.services_to_monitor = [
            "api_gateway",
            "trading_engine",
            "risk_management",
            "data_feeds",
            "order_execution",
            "database",
            "redis"
        ]
        self.health_thresholds = {
            "cpu_warning": 70.0,
            "cpu_critical": 90.0,
            "memory_warning": 80.0,
            "memory_critical": 95.0,
            "disk_warning": 80.0,
            "disk_critical": 90.0,
            "latency_warning": 1000.0,
            "latency_critical": 5000.0,
            "error_rate_warning": 1.0,
            "error_rate_critical": 5.0
        }

    async def start_monitoring(self):
        """Start continuous system monitoring"""
        self.monitoring_active = True
        logging.info("System monitoring started")
        
        # Start monitoring tasks
        asyncio.create_task(self._system_health_monitor())
        asyncio.create_task(self._latency_monitor())
        asyncio.create_task(self._service_health_monitor())

    async def stop_monitoring(self):
        """Stop system monitoring"""
        self.monitoring_active = False
        logging.info("System monitoring stopped")

    async def _system_health_monitor(self):
        """Monitor overall system health"""
        while self.monitoring_active:
            try:
                # Get system metrics
                cpu_usage = psutil.cpu_percent(interval=1)
                memory = psutil.virtual_memory()
                disk = psutil.disk_usage('/')
                
                # Calculate system health score
                health_score = self._calculate_system_health_score(
                    cpu_usage, memory.percent, disk.percent
                )
                
                # Determine status
                status = "healthy"
                if health_score < 0.7:
                    status = "warning"
                if health_score < 0.5:
                    status = "critical"
                
                # Create health record
                health_record = SystemHealth(
                    service_name="system",
                    status=status,
                    cpu_usage=cpu_usage,
                    memory_usage=memory.percent,
                    disk_usage=(disk.percent),
                    network_latency=0.0,  # Would need network monitoring
                    error_rate=self._calculate_error_rate(),
                    uptime=time.time() - psutil.boot_time()
                )
                
                # Store in database
                await self._store_system_health(health_record)
                
                await asyncio.sleep(60)  # Monitor every minute
                
            except Exception as e:
                logging.error(f"Error in system health monitoring: {e}")
                await asyncio.sleep(60)

    async def _latency_monitor(self):
        """Monitor API and service latency"""
        while self.monitoring_active:
            try:
                # Define endpoints to monitor
                endpoints = [
                    {"name": "health_check", "url": "http://localhost:8000/health"},
                    {"name": "api_pnl", "url": "http://localhost:8000/api/v1/pnl/test"},
                    {"name": "api_portfolio", "url": "http://localhost:8000/api/v1/portfolio/test/health"}
                ]
                
                for endpoint in endpoints:
                    latency_metrics = await self._measure_endpoint_latency(endpoint)
                    
                    if latency_metrics:
                        await self._store_latency_metrics(latency_metrics)
                
                await asyncio.sleep(30)  # Monitor every 30 seconds
                
            except Exception as e:
                logging.error(f"Error in latency monitoring: {e}")
                await asyncio.sleep(30)

    async def _service_health_monitor(self):
        """Monitor individual service health"""
        while self.monitoring_active:
            try:
                for service in self.services_to_monitor:
                    service_health = await self._check_service_health(service)
                    
                    if service_health:
                        await self._store_system_health(service_health)
                
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                logging.error(f"Error in service health monitoring: {e}")
                await asyncio.sleep(30)

    async def _measure_endpoint_latency(self, endpoint: Dict[str, str]) -> Optional[LatencyMetrics]:
        """Measure latency metrics for an endpoint"""
        try:
            start_time = time.time()
            
            # Make request
            response = requests.get(endpoint["url"], timeout=10)
            
            end_time = time.time()
            latency_ms = (end_time - start_time) * 1000
            
            # Determine service name from URL
            service_name = self._extract_service_from_url(endpoint["url"])
            
            return LatencyMetrics(
                service_name=service_name,
                endpoint=endpoint["name"],
                avg_latency=latency_ms,
                p50_latency=latency_ms,  # Simplified - would need historical data
                p95_latency=latency_ms * 1.5,  # Estimated
                p99_latency=latency_ms * 2.0,  # Estimated
                throughput_rps=1.0,  # Would need request counting
                error_rate=0.0 if response.status_code == 200 else 100.0,
                timestamp=datetime.now(timezone.utc)
            )
            
        except Exception as e:
            logging.error(f"Error measuring latency for {endpoint['url']}: {e}")
            
            # Return error metrics
            service_name = self._extract_service_from_url(endpoint["url"])
            return LatencyMetrics(
                service_name=service_name,
                endpoint=endpoint["name"],
                avg_latency=5000.0,  # High latency for errors
                p50_latency=5000.0,
                p95_latency=10000.0,
                p99_latency=15000.0,
                throughput_rps=0.0,
                error_rate=100.0,
                timestamp=datetime.now(timezone.utc)
            )

    async def _check_service_health(self, service_name: str) -> Optional[SystemHealth]:
        """Check health of individual service"""
        try:
            # This would be customized based on service type
            if service_name == "database":
                return await self._check_database_health()
            elif service_name == "redis":
                return await self._check_redis_health()
            elif service_name == "api_gateway":
                return await self._check_api_health()
            else:
                # Generic service check - would be customized per service
                return await self._check_generic_service_health(service_name)
                
        except Exception as e:
            logging.error(f"Error checking health of {service_name}: {e}")
            return None

    async def _check_database_health(self) -> SystemHealth:
        """Check database service health"""
        try:
            start_time = time.time()
            db = get_database()
            
            # Simple query to test database
            await db.execute("SELECT 1")
            
            end_time = time.time()
            query_latency = (end_time - start_time) * 1000
            
            return SystemHealth(
                service_name="database",
                status="healthy" if query_latency < 100 else "warning",
                cpu_usage=psutil.cpu_percent(),
                memory_usage=psutil.virtual_memory().percent,
                disk_usage=psutil.disk_usage('/').percent,
                network_latency=query_latency,
                error_rate=0.0,
                uptime=time.time() - psutil.boot_time()
            )
            
        except Exception as e:
            logging.error(f"Database health check failed: {e}")
            return SystemHealth(
                service_name="database",
                status="critical",
                cpu_usage=psutil.cpu_percent(),
                memory_usage=psutil.virtual_memory().percent,
                disk_usage=psutil.disk_usage('/').percent,
                network_latency=5000.0,
                error_rate=100.0,
                uptime=time.time() - psutil.boot_time()
            )

    async def _check_redis_health(self) -> SystemHealth:
        """Check Redis service health"""
        try:
            import redis as redis_client
            
            start_time = time.time()
            r = redis_client.Redis(host='localhost', port=6379, db=0)
            r.ping()
            end_time = time.time()
            
            redis_latency = (end_time - start_time) * 1000
            
            return SystemHealth(
                service_name="redis",
                status="healthy" if redis_latency < 10 else "warning",
                cpu_usage=psutil.cpu_percent(),
                memory_usage=psutil.virtual_memory().percent,
                disk_usage=psutil.disk_usage('/').percent,
                network_latency=redis_latency,
                error_rate=0.0,
                uptime=time.time() - psutil.boot_time()
            )
            
        except Exception as e:
            logging.error(f"Redis health check failed: {e}")
            return SystemHealth(
                service_name="redis",
                status="critical",
                cpu_usage=psutil.cpu_percent(),
                memory_usage=psutil.virtual_memory().percent,
                disk_usage=psutil.disk_usage('/').percent,
                network_latency=5000.0,
                error_rate=100.0,
                uptime=time.time() - psutil.boot_time()
            )

    async def _check_api_health(self) -> SystemHealth:
        """Check API Gateway health"""
        try:
            start_time = time.time()
            response = requests.get("http://localhost:8000/health", timeout=5)
            end_time = time.time()
            
            api_latency = (end_time - start_time) * 1000
            
            return SystemHealth(
                service_name="api_gateway",
                status="healthy" if response.status_code == 200 else "warning",
                cpu_usage=psutil.cpu_percent(),
                memory_usage=psutil.virtual_memory().percent,
                disk_usage=psutil.disk_usage('/').percent,
                network_latency=api_latency,
                error_rate=0.0 if response.status_code == 200 else 100.0,
                uptime=time.time() - psutil.boot_time()
            )
            
        except Exception as e:
            logging.error(f"API health check failed: {e}")
            return SystemHealth(
                service_name="api_gateway",
                status="critical",
                cpu_usage=psutil.cpu_percent(),
                memory_usage=psutil.virtual_memory().percent,
                disk_usage=psutil.disk_usage('/').percent,
                network_latency=5000.0,
                error_rate=100.0,
                uptime=time.time() - psutil.boot_time()
            )

    async def _check_generic_service_health(self, service_name: str) -> SystemHealth:
        """Generic service health check"""
        # This would be customized based on service type
        return SystemHealth(
            service_name=service_name,
            status="healthy",
            cpu_usage=psutil.cpu_percent(),
            memory_usage=psutil.virtual_memory().percent,
            disk_usage=psutil.disk_usage('/').percent,
            network_latency=0.0,
            error_rate=0.0,
            uptime=time.time() - psutil.boot_time()
        )

    def _calculate_system_health_score(self, cpu_usage: float, memory_usage: float, 
                                     disk_usage: float) -> float:
        """Calculate overall system health score (0-1)"""
        # CPU score (inverted - lower usage is better)
        cpu_score = max(0, (100 - cpu_usage) / 100)
        
        # Memory score
        memory_score = max(0, (100 - memory_usage) / 100)
        
        # Disk score
        disk_score = max(0, (100 - disk_usage) / 100)
        
        # Weighted average
        total_score = (cpu_score * 0.4 + memory_score * 0.4 + disk_score * 0.2)
        
        return total_score

    def _calculate_error_rate(self) -> float:
        """Calculate system error rate"""
        # This would be implemented with actual error logging/monitoring
        # For now, return a simulated rate
        return 0.5  # 0.5% error rate

    def _extract_service_from_url(self, url: str) -> str:
        """Extract service name from URL"""
        if "localhost:8000" in url:
            return "api_gateway"
        elif "database" in url.lower():
            return "database"
        else:
            return "unknown_service"

    async def _store_system_health(self, health_record: SystemHealth):
        """Store system health record in database"""
        try:
            db = get_database()
            await db.execute("""
                INSERT INTO system_health (service_name, status, cpu_usage, memory_usage,
                                         disk_usage, network_latency, error_rate, uptime, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                health_record.service_name, health_record.status,
                health_record.cpu_usage, health_record.memory_usage,
                health_record.disk_usage, health_record.network_latency,
                health_record.error_rate, health_record.uptime,
                health_record.timestamp
            ))
            
        except Exception as e:
            logging.error(f"Error storing system health record: {e}")

    async def _store_latency_metrics(self, latency_record: LatencyMetrics):
        """Store latency metrics in database"""
        try:
            db = get_database()
            await db.execute("""
                INSERT INTO latency_metrics (service_name, endpoint, avg_latency, p50_latency,
                                           p95_latency, p99_latency, throughput_rps, error_rate, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                latency_record.service_name, latency_record.endpoint,
                latency_record.avg_latency, latency_record.p50_latency,
                latency_record.p95_latency, latency_record.p99_latency,
                latency_record.throughput_rps, latency_record.error_rate,
                latency_record.timestamp
            ))
            
        except Exception as e:
            logging.error(f"Error storing latency metrics: {e}")

    async def get_system_status(self) -> Dict[str, Any]:
        """Get current system status summary"""
        try:
            db = get_database()
            
            # Get latest health for each service
            services = await db.fetch_all("""
                SELECT DISTINCT service_name FROM system_health
                ORDER BY service_name
            """)
            
            service_status = {}
            for service in services:
                service_name = service["service_name"]
                
                latest_health = await db.fetch_one("""
                    SELECT * FROM system_health 
                    WHERE service_name = ?
                    ORDER BY timestamp DESC LIMIT 1
                """, service_name)
                
                if latest_health:
                    service_status[service_name] = {
                        "status": latest_health["status"],
                        "cpu_usage": latest_health["cpu_usage"],
                        "memory_usage": latest_health["memory_usage"],
                        "network_latency": latest_health["network_latency"],
                        "last_check": latest_health["timestamp"]
                    }
            
            # Calculate overall health
            healthy_services = sum(1 for s in service_status.values() if s["status"] == "healthy")
            total_services = len(service_status)
            overall_health = healthy_services / total_services if total_services > 0 else 0
            
            return {
                "overall_health": overall_health,
                "service_count": total_services,
                "healthy_services": healthy_services,
                "services": service_status,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            
        except Exception as e:
            logging.error(f"Error getting system status: {e}")
            return {"error": str(e)}

    async def get_latency_summary(self, lookback_hours: int = 1) -> Dict[str, Any]:
        """Get latency summary for recent period"""
        try:
            db = get_database()
            since_time = datetime.now(timezone.utc) - timedelta(hours=lookback_hours)
            
            latency_summary = await db.fetch_all("""
                SELECT service_name, endpoint,
                       AVG(avg_latency) as avg_latency,
                       MAX(avg_latency) as max_latency,
                       AVG(error_rate) as avg_error_rate,
                       COUNT(*) as request_count
                FROM latency_metrics
                WHERE timestamp >= ?
                GROUP BY service_name, endpoint
                ORDER BY avg_latency DESC
            """, since_time)
            
            return {
                "summary_period": f"{lookback_hours} hours",
                "endpoint_metrics": latency_summary,
                "total_endpoints": len(latency_summary)
            }
            
        except Exception as e:
            logging.error(f"Error getting latency summary: {e}")
            return {"error": str(e)}

    async def get_performance_trends(self, service_name: str = None, 
                                   lookback_hours: int = 24) -> Dict[str, Any]:
        """Get performance trends for services"""
        try:
            db = get_database()
            since_time = datetime.now(timezone.utc) - timedelta(hours=lookback_hours)
            
            query = """
                SELECT service_name, 
                       DATE(timestamp) as date,
                       AVG(cpu_usage) as avg_cpu,
                       AVG(memory_usage) as avg_memory,
                       AVG(error_rate) as avg_error_rate
                FROM system_health
                WHERE timestamp >= ?
            """
            params = [since_time]
            
            if service_name:
                query += " AND service_name = ?"
                params.append(service_name)
            
            query += """
                GROUP BY service_name, DATE(timestamp)
                ORDER BY date DESC, service_name
            """
            
            trends = await db.fetch_all(query, params)
            
            return {
                "service_name": service_name or "all",
                "lookback_period": f"{lookback_hours} hours",
                "trends": trends
            }
            
        except Exception as e:
            logging.error(f"Error getting performance trends: {e}")
            return {"error": str(e)}

# Global system monitor instance
system_monitor = None

def get_system_monitor() -> SystemMonitor:
    """Get system monitor instance"""
    global system_monitor
    if system_monitor is None:
        system_monitor = SystemMonitor()
    return system_monitor