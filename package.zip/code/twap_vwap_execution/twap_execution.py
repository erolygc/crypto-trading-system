"""
TWAP (Time-Weighted Average Price) Execution Algorithm

Bu modül TWAP execution algoritmasını implement eder.
TWAP büyük emirleri eşit zaman dilimlerine böler.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging

@dataclass
class TWAPOrder:
    """TWAP order bilgileri"""
    symbol: str
    side: str  # 'BUY' or 'SELL'
    total_quantity: float
    start_time: datetime
    end_time: datetime
    max_participation_rate: float = 0.10  # %10'a kadar katılım
    slice_count: Optional[int] = None
    slice_interval_minutes: Optional[int] = None

@dataclass
class ExecutionSlice:
    """Execution slice bilgileri"""
    order_id: str
    slice_number: int
    quantity: float
    target_time: datetime
    executed_quantity: float = 0.0
    execution_price: float = 0.0
    timestamp: Optional[datetime] = None
    status: str = 'PENDING'  # PENDING, EXECUTED, FAILED

class TWAPExecutor:
    """
    Time-Weighted Average Price (TWAP) Execution Algorithm
    
    TWAP büyük emirleri eşit zaman dilimlerine böler.
    Her zaman diliminde eşit miktarda pozisyon alınır.
    """
    
    def __init__(self, 
                 min_slice_quantity: float = 1000.0,
                 max_slice_quantity: float = 100000.0,
                 slice_timeout_seconds: int = 60):
        """
        Args:
            min_slice_quantity: Minimum slice miktarı
            max_slice_quantity: Maximum slice miktarı  
            slice_timeout_seconds: Slice timeout süresi
        """
        self.min_slice_quantity = min_slice_quantity
        self.max_slice_quantity = max_slice_quantity
        self.slice_timeout_seconds = slice_timeout_seconds
        self.logger = logging.getLogger(__name__)
        
        # Execution state
        self.active_orders: Dict[str, TWAPOrder] = {}
        self.execution_slices: Dict[str, List[ExecutionSlice]] = {}
        self.completed_executions: List[Dict] = []
        
    def create_twap_order(self, 
                         symbol: str,
                         side: str,
                         total_quantity: float,
                         start_time: datetime,
                         end_time: datetime,
                         slice_count: Optional[int] = None,
                         slice_interval_minutes: Optional[int] = None,
                         max_participation_rate: float = 0.10) -> str:
        """
        Yeni TWAP order oluştur
        
        Args:
            symbol: Sembol
            side: Alış (BUY) veya Satış (SELL)
            total_quantity: Toplam miktar
            start_time: Başlangıç zamanı
            end_time: Bitiş zamanı
            slice_count: Slice sayısı (belirtilmezse otomatik hesaplanır)
            slice_interval_minutes: Slice aralığı dakika cinsinden
            max_participation_rate: Maksimum katılım oranı
            
        Returns:
            order_id: Oluşturulan order ID
        """
        
        # Order validation
        if end_time <= start_time:
            raise ValueError("Bitiş zamanı başlangıç zamanından sonra olmalı")
            
        if total_quantity <= 0:
            raise ValueError("Miktar pozitif olmalı")
            
        order_id = f"TWAP_{symbol}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # TWAP order oluştur
        twap_order = TWAPOrder(
            symbol=symbol,
            side=side.upper(),
            total_quantity=total_quantity,
            start_time=start_time,
            end_time=end_time,
            max_participation_rate=max_participation_rate,
            slice_count=slice_count,
            slice_interval_minutes=slice_interval_minutes
        )
        
        self.active_orders[order_id] = twap_order
        
        # Execution slice'ları oluştur
        slices = self._create_execution_slices(order_id, twap_order)
        self.execution_slices[order_id] = slices
        
        self.logger.info(f"TWAP order oluşturuldu: {order_id}, Slices: {len(slices)}")
        return order_id
        
    def _create_execution_slices(self, 
                               order_id: str, 
                               twap_order: TWAPOrder) -> List[ExecutionSlice]:
        """
        Execution slice'ları oluştur
        
        Args:
            order_id: Order ID
            twap_order: TWAP order bilgileri
            
        Returns:
            List[ExecutionSlice]: Execution slice listesi
        """
        
        # Slice sayısını hesapla
        if twap_order.slice_count:
            slice_count = twap_order.slice_count
        elif twap_order.slice_interval_minutes:
            total_duration = (twap_order.end_time - twap_order.start_time).total_seconds()
            slice_count = int(total_duration / (twap_order.slice_interval_minutes * 60))
        else:
            # Otomatik slice sayısı hesaplama
            slice_count = self._calculate_optimal_slice_count(twap_order)
            
        # Her slice miktarını hesapla
        slice_quantity = twap_order.total_quantity / slice_count
        
        # Slice timeout kontrolü
        if slice_quantity < self.min_slice_quantity:
            self.logger.warning(f"Slice miktarı çok küçük: {slice_quantity:.0f}, Minimum: {self.min_slice_quantity:.0f}")
            
        if slice_quantity > self.max_slice_quantity:
            self.logger.warning(f"Slice miktarı çok büyük: {slice_quantity:.0f}, Maximum: {self.max_slice_quantity:.0f}")
        
        slices = []
        time_step = (twap_order.end_time - twap_order.start_time) / slice_count
        
        for i in range(slice_count):
            target_time = twap_order.start_time + (time_step * (i + 0.5))  # Orta nokta
            
            execution_slice = ExecutionSlice(
                order_id=order_id,
                slice_number=i + 1,
                quantity=slice_quantity,
                target_time=target_time
            )
            
            slices.append(execution_slice)
            
        return slices
        
    def _calculate_optimal_slice_count(self, twap_order: TWAPOrder) -> int:
        """
        Optimal slice sayısını hesapla
        
        Args:
            twap_order: TWAP order bilgileri
            
        Returns:
            int: Optimal slice sayısı
        """
        
        # Zaman bazlı hesaplama
        total_duration_minutes = (twap_order.end_time - twap_order.start_time).total_seconds() / 60
        
        # Minimum 5 dakikada bir slice
        max_slices = int(total_duration_minutes / 5)
        
        # Her slice için minimum miktar kontrolü
        min_slices_by_quantity = int(twap_order.total_quantity / self.max_slice_quantity)
        
        # Optimal slice sayısını belirle
        optimal_slices = max(min_slices_by_quantity, min(max_slices, 50))  # Max 50 slice
        
        return max(1, optimal_slices)
        
    def execute_slice(self, 
                     order_id: str, 
                     slice_number: int,
                     current_time: datetime,
                     current_price: float,
                     available_liquidity: float) -> Dict:
        """
        Belirli bir slice'ı execute et
        
        Args:
            order_id: Order ID
            slice_number: Slice numarası
            current_time: Mevcut zaman
            current_price: Mevcut fiyat
            available_liquidity: Mevcut likidite
            
        Returns:
            Dict: Execution sonucu
        """
        
        if order_id not in self.execution_slices:
            raise ValueError(f"Order bulunamadı: {order_id}")
            
        slices = self.execution_slices[order_id]
        if slice_number > len(slices) or slice_number < 1:
            raise ValueError(f"Geçersiz slice numarası: {slice_number}")
            
        slice_obj = slices[slice_number - 1]
        
        # Zaman kontrolü (demo için daha toleranslı)
        time_diff = (current_time - slice_obj.target_time).total_seconds()
        if abs(time_diff) > self.slice_timeout_seconds:
            # Demo amaçlı timeout durumunda da execution yapmaya devam et
            self.logger.info(f"Slice timeout aşıldı ({time_diff:.0f}s) ama demo için yine de execute ediliyor, Order: {order_id}, Slice: {slice_number}")
            # Timeout durumunda da execution yapmaya devam et (demo için)
            # slice_obj.status = 'TIMEOUT'
            # return {'status': 'TIMEOUT', 'quantity': 0, 'price': current_price}
            
        # Katılım oranı kontrolü
        twap_order = self.active_orders[order_id]
        participation_limit = current_price * available_liquidity * twap_order.max_participation_rate
        
        # Execute edilebilir miktar
        executable_quantity = min(slice_obj.quantity, available_liquidity)
        
        # Katılım limitini aşmıyorsa execute et
        if executable_quantity * current_price <= participation_limit:
            slice_obj.executed_quantity = executable_quantity
            slice_obj.execution_price = current_price
            slice_obj.timestamp = current_time
            slice_obj.status = 'EXECUTED'
            
            result = {
                'status': 'EXECUTED',
                'quantity': executable_quantity,
                'price': current_price,
                'slice': slice_number
            }
            
            self.logger.info(f"Slice execute edildi: Order {order_id}, Slice {slice_number}, "
                           f"Quantity: {executable_quantity:.0f}, Price: {current_price:.4f}")
            
            return result
        else:
            # Katılım limiti aşıldı
            allowed_quantity = participation_limit / current_price
            slice_obj.executed_quantity = allowed_quantity
            slice_obj.execution_price = current_price
            slice_obj.timestamp = current_time
            slice_obj.status = 'PARTIAL'
            
            result = {
                'status': 'PARTIAL',
                'quantity': allowed_quantity,
                'price': current_price,
                'slice': slice_number
            }
            
            self.logger.info(f"Slice kısmi execute edildi: Order {order_id}, Slice {slice_number}, "
                           f"Quantity: {allowed_quantity:.0f}, Price: {current_price:.4f}")
            
            return result
            
    def get_order_status(self, order_id: str) -> Dict:
        """
        Order durumunu getir
        
        Args:
            order_id: Order ID
            
        Returns:
            Dict: Order durum bilgileri
        """
        
        if order_id not in self.active_orders:
            raise ValueError(f"Order bulunamadı: {order_id}")
            
        order = self.active_orders[order_id]
        slices = self.execution_slices[order_id]
        
        # İstatistikleri hesapla
        executed_quantity = sum(s.executed_quantity for s in slices if s.status in ['EXECUTED', 'PARTIAL'])
        total_cost = sum(s.executed_quantity * s.execution_price for s in slices if s.status in ['EXECUTED', 'PARTIAL'])
        avg_price = total_cost / executed_quantity if executed_quantity > 0 else 0
        
        # Status dağılımı
        status_counts = {}
        for slice_obj in slices:
            status = slice_obj.status
            status_counts[status] = status_counts.get(status, 0) + 1
            
        # Tamamlanma oranı
        completion_rate = executed_quantity / order.total_quantity
        
        return {
            'order_id': order_id,
            'symbol': order.symbol,
            'side': order.side,
            'total_quantity': order.total_quantity,
            'executed_quantity': executed_quantity,
            'remaining_quantity': order.total_quantity - executed_quantity,
            'completion_rate': completion_rate,
            'average_price': avg_price,
            'total_cost': total_cost,
            'slice_count': len(slices),
            'status_distribution': status_counts,
            'start_time': order.start_time,
            'end_time': order.end_time
        }
        
    def cancel_order(self, order_id: str) -> bool:
        """
        Order'ı iptal et
        
        Args:
            order_id: Order ID
            
        Returns:
            bool: İptal başarılı ise True
        """
        
        if order_id not in self.active_orders:
            return False
            
        # Order'ı active_orders'dan kaldır
        del self.active_orders[order_id]
        
        # Execution state'i kaydet
        if order_id in self.execution_slices:
            slices = self.execution_slices[order_id]
            
            execution_record = {
                'order_id': order_id,
                'cancellation_time': datetime.now(),
                'executed_slices': len([s for s in slices if s.status in ['EXECUTED', 'PARTIAL']]),
                'total_slices': len(slices)
            }
            
            self.completed_executions.append(execution_record)
            
            # Execution slices'i kaldır
            del self.execution_slices[order_id]
            
        self.logger.info(f"Order iptal edildi: {order_id}")
        return True
        
    def get_performance_metrics(self) -> Dict:
        """
        Performance metriklerini getir
        
        Returns:
            Dict: Performance metrikleri
        """
        
        total_orders = len(self.active_orders) + len(self.completed_executions)
        
        if not self.completed_executions:
            return {'total_orders': total_orders, 'message': 'Henüz tamamlanan order yok'}
            
        # Tamamlanan order'lardan metrikleri hesapla
        total_slices_executed = sum(r['executed_slices'] for r in self.completed_executions)
        total_slices_planned = sum(r['total_slices'] for r in self.completed_executions)
        
        slice_completion_rate = total_slices_executed / total_slices_planned if total_slices_planned > 0 else 0
        
        return {
            'total_orders': total_orders,
            'active_orders': len(self.active_orders),
            'completed_orders': len(self.completed_executions),
            'slice_completion_rate': slice_completion_rate,
            'avg_slices_per_order': total_slices_planned / len(self.completed_executions) if self.completed_executions else 0
        }