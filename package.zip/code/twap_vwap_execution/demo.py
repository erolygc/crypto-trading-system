"""
TWAP/VWAP Execution Algorithms Demo

Bu dosya tüm TWAP/VWAP execution algoritmalarının demo'sunu içerir.
Sistem bileşenlerini test etmek ve örnek kullanım göstermek için hazırlanmıştır.
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import logging
import sys
import os

# Import all modules
from twap_execution import TWAPExecutor, TWAPOrder, ExecutionSlice
from vwap_execution import VWAPExecutor, VWAPOrder, VWAPSlice, VolumeProfileAnalyzer
from adaptive_scheduling import AdaptiveScheduler, MarketConditionAnalyzer, MarketConditions
from market_impact import MarketImpactPredictor, AlmgrenChrissModel, LiquidityAnalyzer
from participation_rate import ParticipationOptimizer, MarketContext, ParticipationConstraints
from time_of_day import TimeOfDayAnalyzer, TimeOfDayAnalysis
from volume_curve import VolumeCurveAnalyzer
from iceberg_integration import IcebergDetector
from implementation_shortfall import ShortfallMinimizer
from monitoring import ExecutionMonitor, AlertLevel

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class TWAPVWAPDemo:
    """TWAP/VWAP Execution Demo Class"""
    
    def __init__(self):
        self.twap_executor = TWAPExecutor()
        self.vwap_executor = VWAPExecutor()
        self.adaptive_scheduler = AdaptiveScheduler()
        self.market_impact_predictor = MarketImpactPredictor()
        self.participation_optimizer = ParticipationOptimizer()
        self.time_of_day_analyzer = TimeOfDayAnalyzer()
        self.volume_curve_analyzer = VolumeCurveAnalyzer()
        self.iceberg_detector = IcebergDetector()
        self.shortfall_minimizer = ShortfallMinimizer()
        self.execution_monitor = ExecutionMonitor()
        
        # Generate sample data
        self.sample_market_data = self._generate_sample_data()
        
    def _generate_sample_data(self) -> dict:
        """Sample market data oluştur"""
        return {
            'current_price': 150.25,
            'volatility': 0.25,
            'volume': 750000,
            'spread': 0.05,
            'market_cap': 10000000000,
            'order_book': {
                'bids': [
                    {'price': 150.20, 'quantity': 5000, 'order_count': 15},
                    {'price': 150.15, 'quantity': 8000, 'order_count': 12},
                    {'price': 150.10, 'quantity': 12000, 'order_count': 8},
                ],
                'asks': [
                    {'price': 150.30, 'quantity': 6000, 'order_count': 18},
                    {'price': 150.35, 'quantity': 9000, 'order_count': 14},
                    {'price': 150.40, 'quantity': 15000, 'order_count': 10},
                ]
            },
            'historical_prices': pd.Series(np.random.normal(150, 2, 1000)),
            'historical_volumes': pd.Series(np.random.normal(500000, 100000, 1000)),
            'spread_history': np.random.uniform(0.03, 0.08, 50)
        }
    
    def demo_twap_execution(self):
        """TWAP execution demo"""
        print("\n" + "="*50)
        print("TWAP EXECUTION DEMO")
        print("="*50)
        
        # Create TWAP order
        start_time = datetime.now()
        end_time = start_time + timedelta(hours=4)
        
        order_id = self.twap_executor.create_twap_order(
            symbol="AAPL",
            side="BUY",
            total_quantity=100000,
            start_time=start_time,
            end_time=end_time,
            max_participation_rate=0.10,
            slice_count=20
        )
        
        print(f"TWAP Order created: {order_id}")
        print(f"Order details:")
        print(f"  Symbol: AAPL")
        print(f"  Side: BUY")
        print(f"  Total quantity: 100,000")
        print(f"  Time horizon: 4 hours")
        print(f"  Max participation: 10%")
        
        # Simulate slice execution
        print(f"\nSimulating slice execution:")
        executed_quantity = 0
        current_price = 150.25
        
        for slice_num in range(1, 21):  # 20 slices
            # Simulate market conditions
            price_change = np.random.normal(0, 0.5)
            current_price += price_change
            available_liquidity = np.random.uniform(30000, 80000)
            
            # Execute slice
            result = self.twap_executor.execute_slice(
                order_id=order_id,
                slice_number=slice_num,
                current_time=start_time + timedelta(minutes=slice_num * 12),
                current_price=current_price,
                available_liquidity=available_liquidity
            )
            
            executed_quantity += result['quantity']
            
            if slice_num <= 5 or slice_num % 5 == 0:  # Print first 5 and every 5th
                print(f"  Slice {slice_num:2d}: {result['quantity']:7.0f} @ ${result['price']:7.2f} "
                      f"(Status: {result['status']})")
        
        # Get final status
        status = self.twap_executor.get_order_status(order_id)
        print(f"\nFinal Order Status:")
        print(f"  Executed quantity: {status['executed_quantity']:,.0f}")
        print(f"  Completion rate: {status['completion_rate']:.1%}")
        print(f"  Average price: ${status['average_price']:.2f}")
        print(f"  Total cost: ${status['total_cost']:,.2f}")
        
        return order_id, status
    
    def demo_vwap_execution(self):
        """VWAP execution demo"""
        print("\n" + "="*50)
        print("VWAP EXECUTION DEMO")
        print("="*50)
        
        # Create sample volume profile
        hours = list(range(24))
        volume_weights = {
            9: 1.4, 10: 1.3, 11: 1.1, 12: 0.8, 13: 0.7, 14: 1.2, 15: 1.3, 16: 1.1
        }
        
        volume_profile = pd.Series({
            hour: volume_weights.get(hour, 0.6) for hour in hours
        })
        
        # Normalize
        volume_profile = volume_profile / volume_profile.sum()
        
        # Create VWAP order
        start_time = datetime.now()
        end_time = start_time + timedelta(hours=6)
        
        order_id = self.vwap_executor.create_vwap_order(
            symbol="MSFT",
            side="SELL",
            total_quantity=75000,
            start_time=start_time,
            end_time=end_time,
            volume_profile=volume_profile,
            max_participation_rate=0.15
        )
        
        print(f"VWAP Order created: {order_id}")
        print(f"Order details:")
        print(f"  Symbol: MSFT")
        print(f"  Side: SELL")
        print(f"  Total quantity: 75,000")
        print(f"  Time horizon: 6 hours")
        print(f"  Max participation: 15%")
        
        # Get actual slice count
        actual_slice_count = len(self.vwap_executor.execution_slices.get(order_id, []))
        print(f"\nSimulating VWAP slice execution (Actual slices: {actual_slice_count}):")
        executed_quantity = 0
        current_price = 300.50
        
        for slice_num in range(1, actual_slice_count + 1):
            # Simulate market volume (higher during peak hours)
            current_hour = (start_time + timedelta(minutes=slice_num * 24)).hour
            expected_volume = volume_profile.get(current_hour, 0.04) * 1000000
            market_volume = np.random.normal(expected_volume, expected_volume * 0.2)
            market_volume = max(market_volume, expected_volume * 0.5)  # Minimum volume
            
            # Simulate price
            price_change = np.random.normal(0, 0.8)
            current_price += price_change
            
            # Execute slice
            result = self.vwap_executor.execute_vwap_slice(
                order_id=order_id,
                slice_number=slice_num,
                current_time=start_time + timedelta(minutes=slice_num * 24),
                current_price=current_price,
                current_market_volume=market_volume,
                total_daily_volume=5000000
            )
            
            executed_quantity += result['quantity']
            
            if slice_num <= 3 or slice_num % 3 == 0:  # Print first 3 and every 3rd
                print(f"  Slice {slice_num:2d}: {result['quantity']:7.0f} @ ${result['price']:7.2f} "
                      f"(Vol: {market_volume/1000:6.0f}K, Part: {result['participation_rate']:.1%})")
        
        # Get performance
        performance = self.vwap_executor.get_vwap_performance(order_id)
        print(f"\nVWAP Performance:")
        print(f"  Executed quantity: {performance['executed_quantity']:,.0f}")
        print(f"  Completion rate: {performance['completion_rate']:.1%}")
        print(f"  Actual VWAP: ${performance['actual_vwap']:.2f}")
        print(f"  Volume accuracy: {performance['volume_accuracy']:.1%}")
        print(f"  Avg participation: {performance['avg_participation_rate']:.1%}")
        
        return order_id, performance
    
    def demo_adaptive_scheduling(self):
        """Adaptive scheduling demo"""
        print("\n" + "="*50)
        print("ADAPTIVE SCHEDULING DEMO")
        print("="*50)
        
        # Create base slices
        base_slices = []
        for i in range(15):
            base_slices.append({
                'quantity': 10000,
                'target_time': datetime.now() + timedelta(minutes=i * 30)
            })
        
        # Create adaptive plan
        order_id = "ADAPTIVE_001"
        adaptive_slices = self.adaptive_scheduler.create_adaptive_plan(
            order_id=order_id,
            base_slices=base_slices,
            symbol="GOOGL"
        )
        
        print(f"Adaptive plan created for {order_id}")
        print(f"Base slices: {len(base_slices)}")
        
        # Simulate different market conditions
        market_scenarios = [
            {"name": "Volatile Market", "volatility": 0.8, "volume": 200000, "spread": 0.08},
            {"name": "Low Liquidity", "volatility": 0.4, "volume": 80000, "spread": 0.12},
            {"name": "High Liquidity", "volatility": 0.2, "volume": 900000, "spread": 0.03},
            {"name": "Trending Market", "volatility": 0.6, "volume": 500000, "spread": 0.05}
        ]
        
        for scenario in market_scenarios:
            print(f"\n{scenario['name']}:")
            
            # Create market data
            market_data = {
                'current_price': 2750.00,
                'price_history': pd.Series(np.random.normal(2750, 20, 100)),
                'volume_history': pd.Series([scenario['volume']] * 100),
                'spread_data': [scenario['spread']] * 20
            }
            
            # Adapt plan
            adapted_slices = self.adaptive_scheduler.analyze_and_adapt(
                order_id=order_id,
                current_time=datetime.now(),
                market_data=market_data
            )
            
            # Show adaptation summary
            priorities = self.adaptive_scheduler.get_execution_priorities(order_id)
            adaptation_summary = self.adaptive_scheduler.get_adaptation_summary(order_id)
            
            print(f"  Active slices: {len([s for s in adapted_slices if s.adaptation_reason != 'INITIAL'])}")
            print(f"  High priority slices: {len(priorities.get(5, []))}")
            print(f"  Adaptation frequency: {adaptation_summary.get('adaptation_frequency', 0):.2f}/hour")
            
            # Show a sample slice adaptation
            sample_slice = next((s for s in adapted_slices if s.adaptation_reason != 'INITIAL'), None)
            if sample_slice:
                print(f"  Sample adaptation: Slice {sample_slice.original_slice_number} "
                      f"({sample_slice.original_quantity:.0f} → {sample_slice.adapted_quantity:.0f}, "
                      f"Reason: {sample_slice.adaptation_reason})")
        
        return order_id
    
    def demo_market_impact_prediction(self):
        """Market impact prediction demo"""
        print("\n" + "="*50)
        print("MARKET IMPACT PREDICTION DEMO")
        print("="*50)
        
        # Test different order sizes and market conditions
        test_scenarios = [
            {"size": 10000, "volatility": 0.2, "volume": 1000000, "spread": 0.03},
            {"size": 50000, "volatility": 0.4, "volume": 500000, "spread": 0.05},
            {"size": 100000, "volatility": 0.6, "volume": 200000, "spread": 0.08},
            {"size": 200000, "volatility": 0.8, "volume": 100000, "spread": 0.12}
        ]
        
        for i, scenario in enumerate(test_scenarios):
            print(f"\nScenario {i+1} - Order size: {scenario['size']:,}")
            
            # Prepare market data
            market_data = {
                'current_price': 150.25,
                'volatility': scenario['volatility'],
                'volume': scenario['volume'],
                'spread': scenario['spread'],
                'market_cap': 1000000000
            }
            
            order_book_data = self.sample_market_data['order_book']
            
            # Predict impact
            prediction = self.market_impact_predictor.predict_market_impact(
                order_quantity=scenario['size'],
                symbol="TEST",
                order_book_data=order_book_data,
                market_data=market_data
            )
            
            print(f"  Predicted impact: {prediction.predicted_impact:.4f} ({prediction.predicted_impact*100:.2f}%)")
            print(f"  Temporary impact: {prediction.temporary_impact:.4f}")
            print(f"  Permanent impact: {prediction.permanent_impact:.4f}")
            print(f"  Risk level: {prediction.risk_level}")
            print(f"  Execution advice: {prediction.execution_advice}")
        
        # Show impact statistics
        stats = self.market_impact_predictor.get_impact_statistics()
        print(f"\nImpact Statistics:")
        print(f"  Total predictions: {stats.get('total_trades', 0)}")
        print(f"  Average total impact: {stats.get('avg_total_impact', 0):.4f}")
        print(f"  Maximum impact: {stats.get('max_impact', 0):.4f}")
    
    def demo_participation_optimization(self):
        """Participation rate optimization demo"""
        print("\n" + "="*50)
        print("PARTICIPATION RATE OPTIMIZATION DEMO")
        print("="*50)
        
        # Test different market contexts
        market_contexts = [
            {
                "name": "Normal Market",
                "context": MarketContext(
                    symbol="AAPL",
                    current_price=150.25,
                    daily_volume=5000000,
                    volatility=0.25,
                    spread=0.05,
                    order_book_depth=100000,
                    market_regime="RANGING",
                    time_of_day="MIDDAY",
                    news_events=[]
                )
            },
            {
                "name": "Volatile Open",
                "context": MarketContext(
                    symbol="AAPL",
                    current_price=150.25,
                    daily_volume=8000000,
                    volatility=0.8,
                    spread=0.12,
                    order_book_depth=150000,
                    market_regime="VOLATILE",
                    time_of_day="OPEN",
                    news_events=["earnings"]
                )
            },
            {
                "name": "Low Liquidity",
                "context": MarketContext(
                    symbol="AAPL",
                    current_price=150.25,
                    daily_volume=1000000,
                    volatility=0.15,
                    spread=0.20,
                    order_book_depth=20000,
                    market_regime="RANGING",
                    time_of_day="AFTER_HOURS",
                    news_events=[]
                )
            }
        ]
        
        for scenario in market_contexts:
            print(f"\n{scenario['name']}:")
            
            optimization = self.participation_optimizer.optimize_participation_rate(
                order_size=50000,
                market_context=scenario['context'],
                time_remaining_hours=4.0,
                risk_tolerance=0.5
            )
            
            print(f"  Optimal participation rate: {optimization.optimal_rate:.2%}")
            print(f"  Expected cost: ${optimization.expected_cost:,.2f}")
            print(f"  Risk score: {optimization.risk_score:.2f}")
            print(f"  Confidence: {optimization.confidence:.2f}")
            
            print(f"  Recommendations:")
            for rec in optimization.recommendations:
                print(f"    - {rec}")
            
            print(f"  Trade-offs:")
            for key, value in optimization.trade_offs.items():
                if isinstance(value, float):
                    print(f"    {key}: {value:.4f}")
        
        # Show optimization statistics
        stats = self.participation_optimizer.get_optimization_statistics()
        print(f"\nOptimization Statistics:")
        print(f"  Total optimizations: {stats['total_optimizations']}")
        print(f"  Average optimal rate: {stats['avg_optimal_rate']:.2%}")
    
    def demo_time_of_day_analysis(self):
        """Time-of-day analysis demo"""
        print("\n" + "="*50)
        print("TIME-OF-DAY ANALYSIS DEMO")
        print("="*50)
        
        # Generate sample historical data
        dates = pd.date_range('2024-01-01', '2024-01-30', freq='D')
        sample_data = []
        
        for date in dates:
            # Generate intraday data
            for hour in range(9, 17):  # Trading hours
                for minute in [0, 30]:  # 30-minute intervals
                    timestamp = date.replace(hour=hour, minute=minute)
                    
                    # Simulate volume pattern (higher at open/close)
                    if hour in [9, 10, 16]:
                        base_volume = 1500000
                    elif hour in [12, 13]:
                        base_volume = 600000
                    else:
                        base_volume = 900000
                    
                    volume = np.random.normal(base_volume, base_volume * 0.3)
                    volume = max(volume, 100000)  # Minimum volume
                    
                    volatility = np.random.uniform(0.15, 0.45)
                    spread = np.random.uniform(0.02, 0.10)
                    
                    sample_data.append({
                        'timestamp': timestamp,
                        'volume': volume,
                        'volatility': volatility,
                        'spread': spread
                    })
        
        historical_data = pd.DataFrame(sample_data)
        
        # Analyze time-of-day patterns
        analysis = self.time_of_day_analyzer.analyze_historical_data(
            market_data=historical_data,
            symbol="AAPL"
        )
        
        print(f"Time-of-Day Analysis Results:")
        print(f"  Sessions analyzed: {len(analysis.session_profiles)}")
        print(f"  Hourly profiles: {len(analysis.hourly_profiles)}")
        
        # Show session characteristics
        print(f"\nSession Characteristics:")
        for session_name, session in analysis.session_profiles.items():
            liquidity = session.characteristics.get('liquidity', 0)
            volatility = session.characteristics.get('volatility', 0)
            print(f"  {session_name:12}: Liquidity={liquidity:.2f}, Volatility={volatility:.2f}")
        
        # Show optimal execution windows
        print(f"\nOptimal Execution Windows:")
        for i, (start_time, end_time) in enumerate(analysis.optimal_execution_windows):
            print(f"  Window {i+1}: {start_time.strftime('%H:%M')} - {end_time.strftime('%H:%M')}")
        
        # Show current session prediction
        current_session = self.time_of_day_analyzer.predict_current_session(datetime.now())
        print(f"\nCurrent Session Prediction:")
        print(f"  Current hour: {current_session['current_hour']}")
        print(f"  Session: {current_session['current_session']}")
        print(f"  Recommendation: {current_session['execution_recommendation']}")
        print(f"  Risk level: {current_session['risk_level']}")
        
        return analysis
    
    def demo_volume_curve_analysis(self):
        """Volume curve analysis demo"""
        print("\n" + "="*50)
        print("VOLUME CURVE ANALYSIS DEMO")
        print("="*50)
        
        # Generate sample daily volume data
        dates = ['2024-01-15', '2024-01-16', '2024-01-17']
        
        daily_curves = {}
        for date in dates:
            # Generate intraday volume curve (U-shaped pattern)
            volumes = []
            timestamps = []
            
            for hour in range(9, 17):
                for minute in [0, 30]:
                    timestamp = pd.to_datetime(f"{date} {hour:02d}:{minute:02d}:00")
                    
                    # U-shaped pattern
                    if hour in [9, 10, 16]:
                        base_volume = 2000000
                    elif hour in [12, 13]:
                        base_volume = 800000
                    else:
                        base_volume = 1200000
                    
                    # Add randomness
                    volume = np.random.normal(base_volume, base_volume * 0.4)
                    volume = max(volume, 100000)
                    
                    volumes.append(volume)
                    timestamps.append(timestamp)
            
            volume_data = pd.DataFrame({
                'timestamp': timestamps,
                'volume': volumes
            })
            
            # Analyze daily pattern
            curve = self.volume_curve_analyzer.analyze_daily_volume_pattern(
                volume_data=volume_data,
                symbol="AAPL",
                date=date
            )
            
            daily_curves[date] = curve
            print(f"\n{date} Volume Pattern:")
            print(f"  Pattern type: {curve.pattern.pattern_type}")
            print(f"  Pattern confidence: {curve.pattern.pattern_confidence:.2f}")
            print(f"  Morning ratio: {curve.pattern.morning_volume_ratio:.2%}")
            print(f"  Afternoon ratio: {curve.pattern.afternoon_volume_ratio:.2%}")
            print(f"  Peak hours: {curve.pattern.peak_hours}")
            print(f"  Valley hours: {curve.pattern.valley_hours}")
        
        # Show aggregated pattern
        volume_stats = self.volume_curve_analyzer.get_volume_statistics()
        print(f"\nAggregated Volume Statistics:")
        print(f"  Total days analyzed: {volume_stats['total_days_analyzed']}")
        
        pattern_dist = volume_stats['pattern_distribution']
        print(f"  Pattern distribution:")
        for pattern, count in pattern_dist.items():
            print(f"    {pattern}: {count} days")
        
        # Test volume prediction
        print(f"\nVolume Prediction Test:")
        target_time = pd.to_datetime('2024-01-18 10:30:00')
        prediction = self.volume_curve_analyzer.predict_volume_at_time(
            target_time=target_time,
            prediction_method='pattern_based'
        )
        
        print(f"  Predicted volume: {prediction.predicted_volume:,.0f}")
        print(f"  Confidence interval: ({prediction.confidence_interval[0]:,.0f}, {prediction.confidence_interval[1]:,.0f})")
        print(f"  Method: {prediction.prediction_method}")
        print(f"  Historical accuracy: {prediction.historical_accuracy:.2f}")
        
        return daily_curves
    
    def demo_iceberg_detection(self):
        """Iceberg detection demo"""
        print("\n" + "="*50)
        print("ICEBERG DETECTION DEMO")
        print("="*50)
        
        # Generate sample order book snapshots with iceberg patterns
        order_book_snapshots = []
        
        for i in range(20):
            snapshot = {
                'timestamp': datetime.now() + timedelta(minutes=i),
                'bid': {
                    'levels': [
                        {'price': 150.20, 'size': 5000, 'order_count': 15},  # Constant iceberg
                        {'price': 150.15, 'size': 8000, 'order_count': 12},
                        {'price': 150.10, 'size': 12000, 'order_count': 8},
                    ]
                },
                'ask': {
                    'levels': [
                        {'price': 150.30, 'size': 6000, 'order_count': 18},
                        {'price': 150.35, 'size': 9000, 'order_count': 14},
                        {'price': 150.40, 'size': 15000, 'order_count': 10},
                    ]
                }
            }
            
            # Add some iceberg patterns
            if 5 <= i <= 15:  # Iceberg period
                snapshot['ask']['levels'][0]['size'] = 6000  # Consistent size
            
            order_book_snapshots.append(snapshot)
        
        # Detect icebergs
        detected_icebergs = self.iceberg_detector.pattern_analyzer.detect_iceberg_patterns(
            order_book_data=order_book_snapshots,
            current_time=datetime.now()
        )
        
        print(f"Detected Icebergs: {len(detected_icebergs)}")
        
        for iceberg in detected_icebergs:
            print(f"  {iceberg.side} iceberg:")
            print(f"    Displayed quantity: {iceberg.displayed_quantity:,.0f}")
            print(f"    Estimated hidden: {iceberg.estimated_hidden_quantity:,.0f}")
            print(f"    Confidence: {iceberg.confidence_score:.2f}")
            print(f"    Pattern type: {iceberg.pattern_type}")
            print(f"    Execution rate: {iceberg.execution_rate:.2f} shares/sec")
        
        # Test integration with TWAP
        print(f"\nTWAP Integration Test:")
        adjusted_slice = self.iceberg_detector.integrate_with_twap(
            order_book_data=order_book_snapshots,
            symbol="AAPL",
            current_time=datetime.now(),
            twap_slice={
                'quantity': 10000,
                'target_time': datetime.now(),
                'slice_number': 1
            }
        )
        
        print(f"  Original quantity: 10,000")
        print(f"  Adjusted quantity: {adjusted_slice['quantity']:,.0f}")
        print(f"  Adjustment reason: {adjusted_slice.get('adjustment_reason', 'N/A')}")
        print(f"  Iceberg confidence: {adjusted_slice.get('iceberg_confidence', 0):.2f}")
        
        # Test impact on execution
        impact = self.iceberg_detector.get_iceberg_impact_on_execution(
            symbol="AAPL",
            execution_size=50000,
            execution_horizon=timedelta(hours=4)
        )
        
        print(f"\nExecution Impact Analysis:")
        print(f"  Iceberg impact: {impact.iceberg_impact_on_execution:.2%}")
        print(f"  Optimal adjustment: {impact.optimal_slice_adjustment:.2%}")
        print(f"  Risk adjustment: {impact.risk_adjustment:.2f}")
        print(f"  Recommendation: {impact.timing_recommendation}")
        
        return detected_icebergs
    
    def demo_implementation_shortfall(self):
        """Implementation shortfall demo"""
        print("\n" + "="*50)
        print("IMPLEMENTATION SHORTFALL DEMO")
        print("="*50)
        
        # Generate sample execution data
        execution_data = pd.DataFrame({
            'timestamp': pd.date_range('2024-01-15 09:30', periods=20, freq='12min'),
            'price': np.random.normal(150, 1, 20).cumsum() + 150,
            'quantity': np.random.randint(1000, 10000, 20)
        })
        
        # Sample benchmark info
        benchmark_info = {
            'type': 'DECISION_PRICE',
            'value': 149.80,
            'timestamp': pd.to_datetime('2024-01-15 09:00:00'),
            'description': 'Price at order decision time'
        }
        
        decision_time = pd.to_datetime('2024-01-15 09:00:00')
        
        # Calculate implementation shortfall
        shortfall = self.shortfall_minimizer.shortfall_calculator.calculate_implementation_shortfall(
            execution_data=execution_data,
            benchmark_info=benchmark_info,
            decision_time=decision_time
        )
        
        print(f"Implementation Shortfall Analysis:")
        print(f"  Total shortfall: ${shortfall.total_shortfall:,.2f}")
        print(f"  Shortfall percentage: {shortfall.total_shortfall_pct:.2%}")
        print(f"  Execution price: ${shortfall.execution_price:.2f}")
        print(f"  Benchmark price: ${shortfall.benchmark_price:.2f}")
        print(f"  Benchmark type: {shortfall.benchmark_type}")
        
        print(f"\nShortfall Components:")
        for component in shortfall.components:
            print(f"  {component.component_name:15}: ${component.cost_value:8.2f} ({component.cost_percentage:5.2f}%)")
        
        # Develop optimal strategy
        market_data = {
            'price_data': pd.DataFrame({
                'timestamp': pd.date_range('2024-01-15', periods=100, freq='1H'),
                'price': np.random.normal(150, 2, 100)
            }),
            'volatility': 0.25,
            'volume': 500000,
            'spread': 0.05,
            'order_book_depth': 100000
        }
        
        strategy = self.shortfall_minimizer.develop_optimal_strategy(
            order_size=100000,
            symbol="AAPL",
            market_data=market_data,
            execution_horizon=timedelta(hours=6),
            risk_tolerance=0.6
        )
        
        print(f"\nOptimal Execution Strategy:")
        print(f"  Strategy name: {strategy.strategy_name}")
        print(f"  Expected shortfall: ${strategy.expected_shortfall:,.2f}")
        print(f"  Confidence score: {strategy.confidence_score:.2f}")
        
        print(f"  Slice schedule: {len(strategy.slice_schedule)} slices")
        print(f"  Participation rates: {len(strategy.participation_rates)} values")
        
        print(f"  Timing recommendations:")
        for rec in strategy.timing_recommendations:
            print(f"    - {rec}")
        
        return shortfall, strategy
    
    def demo_real_time_monitoring(self):
        """Real-time monitoring demo"""
        print("\n" + "="*50)
        print("REAL-TIME MONITORING DEMO")
        print("="*50)
        
        # Start monitoring
        self.execution_monitor.start_monitoring(update_interval_seconds=10)
        
        # Register orders
        order_ids = []
        
        # TWAP order
        twap_order_id = "TWAP_MONITOR_001"
        self.execution_monitor.register_order(
            order_id=twap_order_id,
            symbol="AAPL",
            total_quantity=100000,
            benchmark_price=150.00,
            expected_completion_time=datetime.now() + timedelta(hours=4)
        )
        order_ids.append(twap_order_id)
        
        # VWAP order
        vwap_order_id = "VWAP_MONITOR_002"
        self.execution_monitor.register_order(
            order_id=vwap_order_id,
            symbol="MSFT",
            total_quantity=75000,
            benchmark_price=300.00,
            expected_completion_time=datetime.now() + timedelta(hours=6)
        )
        order_ids.append(vwap_order_id)
        
        print(f"Monitoring started with {len(order_ids)} orders")
        
        # Simulate execution updates
        for i in range(10):
            # Update TWAP order
            executed_qty = (i + 1) * 5000
            avg_price = 150.00 + np.random.normal(0, 0.5)
            current_price = 150.00 + np.random.normal(0, 0.3)
            
            self.execution_monitor.update_order_metrics(
                order_id=twap_order_id,
                executed_quantity=executed_qty,
                average_execution_price=avg_price,
                current_market_price=current_price
            )
            
            # Update VWAP order
            vwap_executed = (i + 1) * 3750
            vwap_avg_price = 300.00 + np.random.normal(0, 1.0)
            vwap_current_price = 300.00 + np.random.normal(0, 0.8)
            
            self.execution_monitor.update_order_metrics(
                order_id=vwap_order_id,
                executed_quantity=vwap_executed,
                average_execution_price=vwap_avg_price,
                current_market_price=vwap_current_price
            )
            
            # Wait a bit
            import time
            time.sleep(1)
            
            # Show status every 3 iterations
            if (i + 1) % 3 == 0:
                status = self.execution_monitor.get_monitoring_status()
                print(f"\nMonitoring Status (Update {i+1}):")
                print(f"  Active orders: {status['active_orders']}")
                print(f"  Total alerts: {status['recent_alerts_24h']}")
                print(f"  Critical alerts: {status['critical_alerts']}")
        
        # Show final monitoring status
        final_status = self.execution_monitor.get_monitoring_status()
        print(f"\nFinal Monitoring Status:")
        print(f"  Total orders: {final_status['total_orders']}")
        print(f"  Active orders: {final_status['active_orders']}")
        print(f"  Recent alerts: {final_status['recent_alerts_24h']}")
        
        # Show alerts summary
        alerts_summary = self.execution_monitor.get_alerts_summary()
        print(f"\nAlerts Summary:")
        print(f"  Total alerts: {alerts_summary['total_alerts']}")
        print(f"  By level: {alerts_summary['alerts_by_level']}")
        
        # Show individual order status
        for order_id in order_ids:
            order_status = self.execution_monitor.get_order_status(order_id)
            if order_status:
                metrics = order_status['metrics']
                print(f"\nOrder {order_id}:")
                print(f"  Symbol: {metrics['symbol']}")
                print(f"  Progress: {metrics['execution_progress']:.1%}")
                print(f"  Status: {metrics['status'].value}")
                print(f"  Shortfall: {metrics['implementation_shortfall']:.2%}")
        
        # Stop monitoring
        self.execution_monitor.stop_monitoring()
        print(f"\nMonitoring stopped")
        
        return final_status
    
    def run_complete_demo(self):
        """Tüm demo'ları sırayla çalıştır"""
        print("TWAP/VWAP EXECUTION ALGORITHMS - COMPLETE DEMO")
        print("=" * 60)
        
        try:
            # 1. TWAP Execution
            twap_order_id, twap_status = self.demo_twap_execution()
            
            # 2. VWAP Execution
            vwap_order_id, vwap_performance = self.demo_vwap_execution()
            
            # 3. Adaptive Scheduling
            adaptive_order_id = self.demo_adaptive_scheduling()
            
            # 4. Market Impact Prediction
            self.demo_market_impact_prediction()
            
            # 5. Participation Rate Optimization
            self.demo_participation_optimization()
            
            # 6. Time-of-Day Analysis
            tod_analysis = self.demo_time_of_day_analysis()
            
            # 7. Volume Curve Analysis
            volume_curves = self.demo_volume_curve_analysis()
            
            # 8. Iceberg Detection
            detected_icebergs = self.demo_iceberg_detection()
            
            # 9. Implementation Shortfall
            shortfall, strategy = self.demo_implementation_shortfall()
            
            # 10. Real-Time Monitoring
            monitoring_status = self.demo_real_time_monitoring()
            
            print("\n" + "="*60)
            print("DEMO COMPLETED SUCCESSFULLY!")
            print("="*60)
            
            print(f"\nSummary:")
            print(f"  TWAP Order: {twap_order_id} (Progress: {twap_status['completion_rate']:.1%})")
            print(f"  VWAP Order: {vwap_order_id} (Progress: {vwap_performance['completion_rate']:.1%})")
            print(f"  Adaptive Order: {adaptive_order_id}")
            print(f"  Detected Icebergs: {len(detected_icebergs)}")
            print(f"  Optimal Strategy: {strategy.strategy_name}")
            print(f"  Implementation Shortfall: {shortfall.total_shortfall_pct:.2%}")
            print(f"  Monitoring Active Orders: {monitoring_status['active_orders']}")
            
        except Exception as e:
            print(f"\nDemo error: {e}")
            logger.error(f"Demo failed: {e}", exc_info=True)

def main():
    """Main demo function"""
    demo = TWAPVWAPDemo()
    demo.run_complete_demo()

if __name__ == "__main__":
    main()