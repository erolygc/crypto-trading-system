"""
Time-of-Day Effects Analysis

Bu modül günün farklı saatlerindeki piyasa davranışlarını analiz eden algoritmaları implement eder.
Volume patterns, volatility cycles, spread dynamics ve optimal execution timing'i belirler.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, time, timedelta
import logging
from collections import defaultdict
from scipy import stats
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

@dataclass
class TimeOfDayProfile:
    """Günün farklı saatlerindeki profil bilgileri"""
    hour: int
    avg_volume: float
    avg_volatility: float
    avg_spread: float
    volume_cv: float  # Coefficient of variation
    volatility_cv: float
    spread_cv: float
    liquidity_score: float  # 0-1 arası
    execution_score: float  # 0-1 arası
    sample_count: int

@dataclass
class MarketSession:
    """Piyasa session bilgileri"""
    name: str  # 'PRE_MARKET', 'OPEN', 'MIDDAY', 'CLOSE', 'AFTER_HOURS'
    start_time: time
    end_time: time
    characteristics: Dict[str, float]
    optimal_conditions: List[str]
    risk_factors: List[str]

@dataclass
class TimeOfDayAnalysis:
    """Time-of-day analiz sonuçları"""
    session_profiles: Dict[str, MarketSession]
    hourly_profiles: Dict[int, TimeOfDayProfile]
    optimal_execution_windows: List[Tuple[time, time]]
    risk_periods: List[Tuple[time, time]]
    volume_curve: List[float]  # 24 saatlik hacim eğrisi
    volatility_curve: List[float]  # 24 saatlik volatilite eğrisi
    execution_recommendations: Dict[str, List[str]]

class TimeOfDayAnalyzer:
    """
    Time-of-Day Effects Analysis Engine
    
    Piyasa davranışının gün içi pattern'lerini analiz eder:
    1. Volume patterns
    2. Volatility cycles
    3. Spread dynamics
    4. Liquidity patterns
    5. Optimal execution timing
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Market sessions definition
        self.market_sessions = self._define_market_sessions()
        
        # Analysis results
        self.hourly_profiles: Dict[int, TimeOfDayProfile] = {}
        self.session_profiles: Dict[str, MarketSession] = {}
        self.volume_curve: List[float] = []
        self.volatility_curve: List[float] = []
        
        # Historical data
        self.historical_data: pd.DataFrame = pd.DataFrame()
        
    def _define_market_sessions(self) -> Dict[str, MarketSession]:
        """
        Market session'ları tanımla
        
        Returns:
            Dict[str, MarketSession]: Session definitions
        """
        
        return {
            'PRE_MARKET': MarketSession(
                name='PRE_MARKET',
                start_time=time(4, 0),
                end_time=time(9, 30),
                characteristics={'volume': 0.1, 'volatility': 0.3, 'spread': 0.8, 'liquidity': 0.1},
                optimal_conditions=['Small order execution', 'Information discovery'],
                risk_factors=['Low liquidity', 'Wide spreads', 'News gaps']
            ),
            'OPEN': MarketSession(
                name='OPEN',
                start_time=time(9, 30),
                end_time=time(11, 0),
                characteristics={'volume': 1.0, 'volatility': 0.9, 'spread': 0.3, 'liquidity': 1.0},
                optimal_conditions=['Large volume execution', 'Price discovery'],
                risk_factors=['High volatility', 'Gap opening', 'News reactions']
            ),
            'MIDDAY': MarketSession(
                name='MIDDAY',
                start_time=time(11, 0),
                end_time=time(14, 0),
                characteristics={'volume': 0.4, 'volatility': 0.3, 'spread': 0.5, 'liquidity': 0.6},
                optimal_conditions=['Steady execution', 'Low impact'],
                risk_factors=['Low volume', 'Stale prices', 'Reduced activity']
            ),
            'CLOSE': MarketSession(
                name='CLOSE',
                start_time=time(14, 0),
                end_time=time(16, 0),
                characteristics={'volume': 0.8, 'volatility': 0.7, 'spread': 0.4, 'liquidity': 0.9},
                optimal_conditions=['Volume participation', 'Rebalancing', 'End-of-day positioning'],
                risk_factors=['High volatility', 'Momentum swings', 'EOD manipulation']
            ),
            'AFTER_HOURS': MarketSession(
                name='AFTER_HOURS',
                start_time=time(16, 0),
                end_time=time(20, 0),
                characteristics={'volume': 0.2, 'volatility': 0.5, 'spread': 0.9, 'liquidity': 0.2},
                optimal_conditions=['Small adjustments', 'News-based trading'],
                risk_factors=['Very low liquidity', 'Wide spreads', 'Limited venues']
            )
        }
        
    def analyze_historical_data(self,
                               market_data: pd.DataFrame,
                               symbol: str = 'UNKNOWN') -> TimeOfDayAnalysis:
        """
        Historical piyasa verilerini analiz et
        
        Args:
            market_data: Historical market data
            symbol: Sembol
            
        Returns:
            TimeOfDayAnalysis: Analiz sonuçları
        """
        
        if market_data.empty:
            raise ValueError("Market data boş olamaz")
            
        # Data validation
        required_columns = ['timestamp', 'volume', 'volatility', 'spread']
        if not all(col in market_data.columns for col in required_columns):
            raise ValueError(f"Eksik columns: {required_columns}")
            
        self.historical_data = market_data.copy()
        
        # Extract hour from timestamp
        market_data['hour'] = pd.to_datetime(market_data['timestamp']).dt.hour
        
        # Calculate hourly profiles
        self._calculate_hourly_profiles(market_data)
        
        # Analyze sessions
        self._analyze_market_sessions(market_data)
        
        # Create curves
        self._create_time_curves()
        
        # Find optimal windows
        optimal_windows = self._find_optimal_execution_windows()
        risk_periods = self._find_risk_periods()
        
        # Generate recommendations
        recommendations = self._generate_time_based_recommendations()
        
        return TimeOfDayAnalysis(
            session_profiles=self.session_profiles,
            hourly_profiles=self.hourly_profiles,
            optimal_execution_windows=optimal_windows,
            risk_periods=risk_periods,
            volume_curve=self.volume_curve,
            volatility_curve=self.volatility_curve,
            execution_recommendations=recommendations
        )
        
    def _calculate_hourly_profiles(self, market_data: pd.DataFrame) -> None:
        """
        Saatlik profilleri hesapla
        
        Args:
            market_data: Market data with hour column
        """
        
        hourly_stats = market_data.groupby('hour').agg({
            'volume': ['mean', 'std', 'count'],
            'volatility': ['mean', 'std'],
            'spread': ['mean', 'std']
        }).round(4)
        
        # Flatten column names
        hourly_stats.columns = ['_'.join(col).strip() for col in hourly_stats.columns.values]
        
        for hour in range(24):
            if hour in hourly_stats.index:
                row = hourly_stats.loc[hour]
                
                # Coefficient of variations
                volume_cv = row['volume_std'] / row['volume_mean'] if row['volume_mean'] > 0 else 0
                volatility_cv = row['volatility_std'] / row['volatility_mean'] if row['volatility_mean'] > 0 else 0
                spread_cv = row['spread_std'] / row['spread_mean'] if row['spread_mean'] > 0 else 0
                
                # Scores (0-1)
                liquidity_score = self._calculate_liquidity_score(
                    row['volume_mean'], row['spread_mean']
                )
                execution_score = self._calculate_execution_score(
                    liquidity_score, row['volatility_mean']
                )
                
                self.hourly_profiles[hour] = TimeOfDayProfile(
                    hour=hour,
                    avg_volume=row['volume_mean'],
                    avg_volatility=row['volatility_mean'],
                    avg_spread=row['spread_mean'],
                    volume_cv=volume_cv,
                    volatility_cv=volatility_cv,
                    spread_cv=spread_cv,
                    liquidity_score=liquidity_score,
                    execution_score=execution_score,
                    sample_count=int(row['volume_count'])
                )
            else:
                # No data for this hour
                self.hourly_profiles[hour] = TimeOfDayProfile(
                    hour=hour,
                    avg_volume=0.0,
                    avg_volatility=0.0,
                    avg_spread=0.0,
                    volume_cv=0.0,
                    volatility_cv=0.0,
                    spread_cv=0.0,
                    liquidity_score=0.0,
                    execution_score=0.0,
                    sample_count=0
                )
                
        self.logger.info(f"24 saatlik profile hesaplandı, {len(self.hourly_profiles)} saat")
        
    def _calculate_liquidity_score(self, avg_volume: float, avg_spread: float) -> float:
        """
        Likidite skorunu hesapla
        
        Args:
            avg_volume: Ortalama hacim
            avg_spread: Ortalama spread
            
        Returns:
            float: Likidite skoru (0-1)
        """
        
        # Volume score (normalize to 0-1)
        volume_score = min(1.0, avg_volume / 1000000)  # 1M volume = perfect score
        
        # Spread score (inverse relationship)
        spread_score = max(0, 1 - (avg_spread / 0.1))  # 10% spread = 0 score
        
        # Combined score
        liquidity_score = (volume_score * 0.7 + spread_score * 0.3)
        
        return liquidity_score
        
    def _calculate_execution_score(self, liquidity_score: float, volatility: float) -> float:
        """
        Execution skorunu hesapla
        
        Args:
            liquidity_score: Likidite skoru
            volatility: Volatilite
            
        Returns:
            float: Execution skoru (0-1)
        """
        
        # High volatility = harder execution
        volatility_penalty = min(0.5, volatility)
        
        execution_score = liquidity_score * (1 - volatility_penalty)
        
        return execution_score
        
    def _analyze_market_sessions(self, market_data: pd.DataFrame) -> None:
        """
        Market session'larını analiz et
        
        Args:
            market_data: Market data with hour column
        """
        
        for session_name, session in self.market_sessions.items():
            
            # Filter data for this session
            session_data = market_data[
                (market_data['hour'] >= session.start_time.hour) &
                (market_data['hour'] < session.end_time.hour)
            ]
            
            if not session_data.empty:
                # Calculate session characteristics
                avg_volume = session_data['volume'].mean()
                avg_volatility = session_data['volatility'].mean()
                avg_spread = session_data['spread'].mean()
                
                # Update session characteristics
                session.characteristics.update({
                    'volume': avg_volume / market_data['volume'].mean(),
                    'volatility': avg_volatility / market_data['volatility'].mean(),
                    'spread': avg_spread / market_data['spread'].mean(),
                    'liquidity': self._calculate_liquidity_score(avg_volume, avg_spread)
                })
                
                # Update optimal conditions and risk factors based on data
                self._update_session_assessment(session, avg_volume, avg_volatility, avg_spread)
                
                self.session_profiles[session_name] = session
                
        self.logger.info(f"{len(self.session_profiles)} market session analiz edildi")
        
    def _update_session_assessment(self,
                                 session: MarketSession,
                                 avg_volume: float,
                                 avg_volatility: float,
                                 avg_spread: float) -> None:
        """
        Session assessment'ini veriye göre güncelle
        
        Args:
            session: Market session
            avg_volume: Ortalama hacim
            avg_volatility: Ortalama volatilite
            avg_spread: Ortalama spread
        """
        
        # Volume-based assessment
        if avg_volume > 800000:
            session.optimal_conditions.append('High volume execution')
        elif avg_volume < 200000:
            session.risk_factors.append('Low volume risk')
            
        # Volatility-based assessment
        if avg_volatility > 0.8:
            session.risk_factors.append('High volatility risk')
            session.optimal_conditions.append('Momentum trading')
        elif avg_volatility < 0.3:
            session.optimal_conditions.append('Stable price discovery')
            
        # Spread-based assessment
        if avg_spread > 0.05:  # 5% spread
            session.risk_factors.append('Wide spread cost')
        elif avg_spread < 0.01:  # 1% spread
            session.optimal_conditions.append('Tight spread advantage')
            
    def _create_time_curves(self) -> None:
        """24 saatlik hacim ve volatilite eğrilerini oluştur"""
        
        # Volume curve
        self.volume_curve = [0.0] * 24
        for hour in range(24):
            if hour in self.hourly_profiles:
                self.volume_curve[hour] = self.hourly_profiles[hour].avg_volume
            else:
                self.volume_curve[hour] = 0.0
                
        # Volatility curve
        self.volatility_curve = [0.0] * 24
        for hour in range(24):
            if hour in self.hourly_profiles:
                self.volatility_curve[hour] = self.hourly_profiles[hour].avg_volatility
            else:
                self.volatility_curve[hour] = 0.0
                
    def _find_optimal_execution_windows(self) -> List[Tuple[time, time]]:
        """
        Optimal execution zaman pencerelerini bul
        
        Returns:
            List[Tuple[time, time]]: Optimal time windows
        """
        
        # Execution score'a göre en iyi saatleri bul
        hour_scores = [(hour, profile.execution_score) 
                      for hour, profile in self.hourly_profiles.items() 
                      if profile.sample_count > 10]  # Yeterli veri olan saatler
        
        # En iyi execution score'a sahip saatleri sırala
        hour_scores.sort(key=lambda x: x[1], reverse=True)
        
        # En iyi 4 saati al (4 saatlik continuous window için)
        top_hours = [hour for hour, score in hour_scores[:4]]
        top_hours.sort()
        
        # Continuous window bul veya multiple windows
        optimal_windows = []
        
        if len(top_hours) >= 2:
            # Single continuous window
            start_hour = top_hours[0]
            end_hour = top_hours[-1] + 1
            optimal_windows.append((time(start_hour, 0), time(end_hour, 0)))
            
        return optimal_windows
        
    def _find_risk_periods(self) -> List[Tuple[time, time]]:
        """
        Yüksek risk zaman pencerelerini bul
        
        Returns:
            List[Tuple[time, time]]: Risk time windows
        """
        
        risk_periods = []
        
        for hour, profile in self.hourly_profiles.items():
            # Risk factors
            risk_factors = []
            
            if profile.avg_volatility > 0.8:
                risk_factors.append('HIGH_VOL')
            if profile.avg_spread > 0.05:
                risk_factors.append('WIDE_SPREAD')
            if profile.liquidity_score < 0.3:
                risk_factors.append('LOW_LIQ')
            if profile.sample_count < 5:
                risk_factors.append('LOW_DATA')
                
            if len(risk_factors) >= 2:  # 2+ risk factor = high risk period
                risk_periods.append((time(hour, 0), time(hour + 1, 0)))
                
        return risk_periods
        
    def _generate_time_based_recommendations(self) -> Dict[str, List[str]]:
        """
        Zaman bazlı öneriler oluştur
        
        Returns:
            Dict[str, List[str]]: Recommendations by category
        """
        
        recommendations = {
            'execution_timing': [],
            'risk_management': [],
            'optimal_conditions': [],
            'avoid_periods': []
        }
        
        # Execution timing recommendations
        if self.volume_curve:
            peak_volume_hour = np.argmax(self.volume_curve)
            recommendations['execution_timing'].append(
                f"En yüksek hacim saat {peak_volume_hour}:00 civarında"
            )
            
        # Session-based recommendations
        for session_name, session in self.session_profiles.items():
            liquidity = session.characteristics.get('liquidity', 0)
            
            if liquidity > 0.8:
                recommendations['optimal_conditions'].append(
                    f"{session_name}: Yüksek likidite - Büyük emirler için ideal"
                )
            elif liquidity < 0.3:
                recommendations['avoid_periods'].append(
                    f"{session_name}: Düşük likidite - Büyük emirlerden kaçının"
                )
                
        # Risk management
        high_vol_sessions = [name for name, session in self.session_profiles.items() 
                           if session.characteristics.get('volatility', 0) > 0.7]
        if high_vol_sessions:
            recommendations['risk_management'].append(
                f"Yüksek volatilite dönemleri: {', '.join(high_vol_sessions)} - Slice boyutlarını küçültün"
            )
            
        return recommendations
        
    def predict_current_session(self, current_time: datetime) -> Dict:
        """
        Mevcut zaman için session characteristics tahmin et
        
        Args:
            current_time: Mevcut zaman
            
        Returns:
            Dict: Session prediction
        """
        
        current_hour = current_time.hour
        
        # Current hour profile
        current_profile = self.hourly_profiles.get(current_hour)
        
        # Current session
        current_session = None
        for session_name, session in self.market_sessions.items():
            if (current_hour >= session.start_time.hour and 
                current_hour < session.end_time.hour):
                current_session = session
                break
                
        result = {
            'current_hour': current_hour,
            'current_session': current_session.name if current_session else 'UNKNOWN',
            'session_characteristics': current_session.characteristics if current_session else {},
            'hourly_profile': current_profile.__dict__ if current_profile else {},
            'execution_recommendation': self._get_execution_recommendation(current_profile, current_session),
            'risk_level': self._assess_current_risk(current_profile, current_session)
        }
        
        return result
        
    def _get_execution_recommendation(self, 
                                    profile: Optional[TimeOfDayProfile],
                                    session: Optional[MarketSession]) -> str:
        """
        Execution önerisi oluştur
        
        Args:
            profile: Hourly profile
            session: Market session
            
        Returns:
            str: Execution recommendation
        """
        
        if not profile or not session:
            return "Insufficient data for recommendation"
            
        # Combined assessment
        execution_score = profile.execution_score
        liquidity_score = profile.liquidity_score
        
        if execution_score > 0.7 and liquidity_score > 0.6:
            return "Optimal execution conditions - Full participation recommended"
        elif execution_score > 0.5:
            return "Good execution conditions - Moderate participation"
        elif execution_score > 0.3:
            return "Fair execution conditions - Reduced participation, longer execution"
        else:
            return "Poor execution conditions - Avoid large orders, consider alternative timing"
            
    def _assess_current_risk(self,
                           profile: Optional[TimeOfDayProfile],
                           session: Optional[MarketSession]) -> str:
        """
        Mevcut risk seviyesini değerlendir
        
        Args:
            profile: Hourly profile
            session: Market session
            
        Returns:
            str: Risk level
        """
        
        if not profile or not session:
            return "UNKNOWN"
            
        risk_factors = 0
        
        if profile.avg_volatility > 0.8:
            risk_factors += 1
        if profile.avg_spread > 0.05:
            risk_factors += 1
        if profile.liquidity_score < 0.3:
            risk_factors += 1
        if profile.sample_count < 5:
            risk_factors += 1
            
        if risk_factors >= 3:
            return "HIGH"
        elif risk_factors >= 2:
            return "MEDIUM"
        else:
            return "LOW"
            
    def get_time_based_metrics(self) -> Dict:
        """
        Time-based metrikleri getir
        
        Returns:
            Dict: Time-based metrics
        """
        
        if not self.hourly_profiles:
            return {'message': 'Henüz time-of-day analizi yapılmadı'}
            
        # Calculate summary statistics
        all_liquidity_scores = [profile.liquidity_score for profile in self.hourly_profiles.values()]
        all_execution_scores = [profile.execution_score for profile in self.hourly_profiles.values()]
        all_volumes = [profile.avg_volume for profile in self.hourly_profiles.values()]
        
        return {
            'avg_liquidity_score': np.mean(all_liquidity_scores),
            'liquidity_std': np.std(all_liquidity_scores),
            'avg_execution_score': np.mean(all_execution_scores),
            'execution_std': np.std(all_execution_scores),
            'peak_volume_hour': np.argmax(all_volumes),
            'peak_execution_hour': np.argmax(all_execution_scores),
            'lowest_risk_hours': self._find_lowest_risk_hours(),
            'highest_liquidity_hours': self._find_highest_liquidity_hours()
        }
        
    def _find_lowest_risk_hours(self) -> List[int]:
        """En düşük risk saatlerini bul"""
        
        risk_scores = []
        for hour, profile in self.hourly_profiles.items():
            risk_score = (1 - profile.execution_score) + profile.volume_cv + profile.volatility_cv
            risk_scores.append((hour, risk_score))
            
        risk_scores.sort(key=lambda x: x[1])
        return [hour for hour, score in risk_scores[:3]]
        
    def _find_highest_liquidity_hours(self) -> List[int]:
        """En yüksek likidite saatlerini bul"""
        
        liquidity_scores = [(hour, profile.liquidity_score) 
                          for hour, profile in self.hourly_profiles.items()]
        liquidity_scores.sort(key=lambda x: x[1], reverse=True)
        return [hour for hour, score in liquidity_scores[:3]]
        
    def update_with_real_time_data(self,
                                  current_time: datetime,
                                  volume: float,
                                  volatility: float,
                                  spread: float) -> None:
        """
        Real-time data ile profilleri güncelle
        
        Args:
            current_time: Mevcut zaman
            volume: Mevcut hacim
            volatility: Mevcut volatilite
            spread: Mevcut spread
        """
        
        hour = current_time.hour
        
        if hour in self.hourly_profiles:
            profile = self.hourly_profiles[hour]
            
            # Exponential moving average update
            alpha = 0.1  # Learning rate
            profile.avg_volume = (1 - alpha) * profile.avg_volume + alpha * volume
            profile.avg_volatility = (1 - alpha) * profile.avg_volatility + alpha * volatility
            profile.avg_spread = (1 - alpha) * profile.avg_spread + alpha * spread
            
            # Recalculate scores
            profile.liquidity_score = self._calculate_liquidity_score(profile.avg_volume, profile.avg_spread)
            profile.execution_score = self._calculate_execution_score(profile.liquidity_score, profile.avg_volatility)
            
            # Increment sample count
            profile.sample_count += 1
            
        self.logger.debug(f"Real-time data güncellendi: {current_time}, Hour {hour}")
        
    def export_time_profiles(self, filepath: str) -> None:
        """
        Time profile'larını dosyaya export et
        
        Args:
            filepath: Export dosya yolu
        """
        
        if not self.hourly_profiles:
            self.logger.warning("Export edilecek profile verisi yok")
            return
            
        # Create DataFrame
        data = []
        for hour, profile in self.hourly_profiles.items():
            data.append({
                'hour': hour,
                'avg_volume': profile.avg_volume,
                'avg_volatility': profile.avg_volatility,
                'avg_spread': profile.avg_spread,
                'volume_cv': profile.volume_cv,
                'volatility_cv': profile.volatility_cv,
                'spread_cv': profile.spread_cv,
                'liquidity_score': profile.liquidity_score,
                'execution_score': profile.execution_score,
                'sample_count': profile.sample_count
            })
            
        df = pd.DataFrame(data)
        df.to_csv(filepath, index=False)
        
        self.logger.info(f"Time profiles export edildi: {filepath}")
        
    def load_time_profiles(self, filepath: str) -> None:
        """
        Time profile'larını dosyadan yükle
        
        Args:
            filepath: Import dosya yolu
        """
        
        try:
            df = pd.read_csv(filepath)
            
            for _, row in df.iterrows():
                hour = int(row['hour'])
                self.hourly_profiles[hour] = TimeOfDayProfile(
                    hour=hour,
                    avg_volume=row['avg_volume'],
                    avg_volatility=row['avg_volatility'],
                    avg_spread=row['avg_spread'],
                    volume_cv=row['volume_cv'],
                    volatility_cv=row['volatility_cv'],
                    spread_cv=row['spread_cv'],
                    liquidity_score=row['liquidity_score'],
                    execution_score=row['execution_score'],
                    sample_count=int(row['sample_count'])
                )
                
            # Recreate curves
            self._create_time_curves()
            
            self.logger.info(f"Time profiles yüklendi: {filepath}")
            
        except FileNotFoundError:
            self.logger.warning(f"Time profiles dosyası bulunamadı: {filepath}")
        except Exception as e:
            self.logger.error(f"Time profiles yüklenemedi: {e}")