"""
VWAP (Volume-Weighted Average Price) Execution Algorithm

Bu modül VWAP execution algoritmasını implement eder.
VWAP büyük emirleri günlük hacim profiline göre böler.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, time, timedelta
import logging
from scipy.interpolate import interp1d

@dataclass
class VWAPOrder:
    """VWAP order bilgileri"""
    symbol: str
    side: str  # 'BUY' or 'SELL'
    total_quantity: float
    start_time: datetime
    end_time: datetime
    max_participation_rate: float = 0.15  # %15'e kadar katılım
    volume_profile: Optional[pd.Series] = None  # Hacim profili (zaman -> hacim)

@dataclass
class VWAPSlice:
    """VWAP execution slice bilgileri"""
    order_id: str
    slice_number: int
    quantity: float
    target_time: datetime
    expected_market_volume: float
    actual_executed_quantity: float = 0.0
    execution_price: float = 0.0
    timestamp: Optional[datetime] = None
    market_volume_observed: float = 0.0
    status: str = 'PENDING'  # PENDING, EXECUTED, FAILED

class VolumeProfileAnalyzer:
    """Hacim profili analiz sınıfı"""
    
    @staticmethod
    def create_typical_volume_profile(sessions_data: pd.DataFrame) -> pd.Series:
        """
        Tipik günlük hacim profili oluştur
        
        Args:
            sessions_data: Geçmiş session verileri (DateTimeIndex, Volume)
            
        Returns:
            pd.Series: Normalize edilmiş hacim profili
        """
        
        # Zaman dilimlerini saat/dakika formatına çevir
        hourly_data = sessions_data.groupby(sessions_data.index.hour).agg({
            'Volume': 'mean'
        })
        
        # Saat içinde dakika bazında dağıtım (varsayılan)
        minute_profile = {}
        for hour in range(24):
            if hour in hourly_data.index:
                hour_volume = hourly_data.loc[hour, 'Volume']
                
                # Saat içinde tipik dağılım (açılış ve kapanışta yüksek)
                if 9 <= hour <= 11:  # Açılış saatleri
                    weight = 1.5
                elif 14 <= hour <= 16:  # Kapanış hazırlığı
                    weight = 1.3
                elif 12 <= hour <= 13:  # Öğle arası
                    weight = 0.7
                else:
                    weight = 1.0
                    
                minute_profile[hour] = weight
            else:
                minute_profile[hour] = 1.0
        
        # Normalize et
        total_weight = sum(minute_profile.values())
        normalized_profile = {hour: weight/total_weight for hour, weight in minute_profile.items()}
        
        return pd.Series(normalized_profile)
        
    @staticmethod
    def adjust_for_market_conditions(volume_profile: pd.Series, 
                                   market_volatility: float,
                                   news_events: List[str]) -> pd.Series:
        """
        Piyasa koşullarına göre hacim profilini ayarla
        
        Args:
            volume_profile: Temel hacim profili
            market_volatility: Piyasa volatilitesi (0.0-1.0)
            news_events: Haber olayları listesi
            
        Returns:
            pd.Series: Ayarlanmış hacim profili
        """
        
        adjusted_profile = volume_profile.copy()
        
        # Volatilite artışı -> hacim artışı
        if market_volatility > 0.7:  # Yüksek volatilite
            # Açılış ve kapanışta daha yüksek hacim
            for hour in [9, 10, 11, 14, 15, 16]:
                if hour in adjusted_profile.index:
                    adjusted_profile[hour] *= 1.2
            
        elif market_volatility < 0.3:  # Düşük volatilite
            # Hacim daha düzgün dağılır
            max_volume = adjusted_profile.max()
            min_volume = adjusted_profile.min()
            if max_volume > min_volume:
                # Değişkenliği azalt
                adjusted_profile = (adjusted_profile - adjusted_profile.mean()) * 0.5 + adjusted_profile.mean()
        
        # Haber olaylarına göre ayarlama
        news_time_adjustments = {
            'earnings': [9, 15],  # Kazanç duyuruları
            'fed_announcement': [14],  # Fed açıklamaları
            'economic_data': [8, 10, 12, 14, 16]  # Ekonomik veriler
        }
        
        for event_type, affected_hours in news_time_adjustments.items():
            if any(event_type in news for news in news_events):
                for hour in affected_hours:
                    if hour in adjusted_profile.index:
                        adjusted_profile[hour] *= 1.1
        
        return adjusted_profile

class VWAPExecutor:
    """
    Volume-Weighted Average Price (VWAP) Execution Algorithm
    
    VWAP büyük emirleri günlük hacim profiline göre dağıtır.
    Hacmin yüksek olduğu zamanlarda daha fazla işlem yapılır.
    """
    
    def __init__(self, 
                 min_slice_quantity: float = 500.0,
                 max_slice_quantity: float = 200000.0,
                 participation_buffer: float = 0.05):  # %5 buffer
        """
        Args:
            min_slice_quantity: Minimum slice miktarı
            max_slice_quantity: Maximum slice miktarı
            participation_buffer: Katılım oranı buffer'ı
        """
        self.min_slice_quantity = min_slice_quantity
        self.max_slice_quantity = max_slice_quantity
        self.participation_buffer = participation_buffer
        self.volume_analyzer = VolumeProfileAnalyzer()
        self.logger = logging.getLogger(__name__)
        
        # Execution state
        self.active_orders: Dict[str, VWAPOrder] = {}
        self.execution_slices: Dict[str, List[VWAPSlice]] = {}
        self.completed_executions: List[Dict] = []
        
        # Performance tracking
        self.vwap_tracking: Dict[str, Dict] = {}
        
    def create_vwap_order(self,
                         symbol: str,
                         side: str,
                         total_quantity: float,
                         start_time: datetime,
                         end_time: datetime,
                         volume_profile: Optional[pd.Series] = None,
                         max_participation_rate: float = 0.15) -> str:
        """
        Yeni VWAP order oluştur
        
        Args:
            symbol: Sembol
            side: Alış (BUY) veya Satış (SELL)
            total_quantity: Toplam miktar
            start_time: Başlangıç zamanı
            end_time: Bitiş zamanı
            volume_profile: Hacim profili (belirtilmezse tipik profil kullanılır)
            max_participation_rate: Maksimum katılım oranı
            
        Returns:
            order_id: Oluşturulan order ID
        """
        
        # Order validation
        if end_time <= start_time:
            raise ValueError("Bitiş zamanı başlangıç zamanından sonra olmalı")
            
        if total_quantity <= 0:
            raise ValueError("Miktar pozitif olmalı")
            
        order_id = f"VWAP_{symbol}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # Hacim profilini oluştur veya ayarla
        if volume_profile is None:
            # Tipik hacim profili oluştur (varsayılan)
            volume_profile = self._create_default_volume_profile(start_time, end_time)
        else:
            # Verilen profili normalize et
            volume_profile = self._normalize_volume_profile(volume_profile)
            
        # VWAP order oluştur
        vwap_order = VWAPOrder(
            symbol=symbol,
            side=side.upper(),
            total_quantity=total_quantity,
            start_time=start_time,
            end_time=end_time,
            max_participation_rate=max_participation_rate,
            volume_profile=volume_profile
        )
        
        self.active_orders[order_id] = vwap_order
        
        # Execution slice'ları oluştur
        slices = self._create_vwap_slices(order_id, vwap_order)
        self.execution_slices[order_id] = slices
        
        # VWAP tracking başlat
        self.vwap_tracking[order_id] = {
            'cumulative_volume': 0.0,
            'cumulative_cost': 0.0,
            'target_vwap': 0.0,
            'slippage': 0.0
        }
        
        self.logger.info(f"VWAP order oluşturuldu: {order_id}, Slices: {len(slices)}")
        return order_id
        
    def _create_default_volume_profile(self, start_time: datetime, end_time: datetime) -> pd.Series:
        """
        Varsayılan hacim profili oluştur
        
        Args:
            start_time: Başlangıç zamanı
            end_time: Bitiş zamanı
            
        Returns:
            pd.Series: Varsayılan hacim profili
        """
        
        # Zaman aralığını hesapla
        duration = end_time - start_time
        
        # Tipik borsa saatleri (09:30-16:00)
        trading_hours = pd.date_range(
            start=start_time.replace(hour=9, minute=30, second=0),
            end=end_time if end_time.hour < 16 else end_time.replace(hour=16, minute=0, second=0),
            freq='1H'
        )
        
        # Varsayılan hacim profili
        default_weights = {}
        for hour in range(24):
            if 9 <= hour <= 11:  # Açılış
                default_weights[hour] = 1.4
            elif 12 <= hour <= 13:  # Öğle
                default_weights[hour] = 0.8
            elif 14 <= hour <= 16:  # Kapanış
                default_weights[hour] = 1.2
            else:  # Diğer saatler
                default_weights[hour] = 0.6
                
        return pd.Series(default_weights)
        
    def _normalize_volume_profile(self, volume_profile: pd.Series) -> pd.Series:
        """
        Hacim profilini normalize et
        
        Args:
            volume_profile: Ham hacim profili
            
        Returns:
            pd.Series: Normalize edilmiş hacim profili
        """
        
        # Sıfır değerleri kontrol et
        if (volume_profile <= 0).any():
            # Sıfır değerleri minimum pozitif değerle değiştir
            min_positive = volume_profile[volume_profile > 0].min()
            volume_profile = volume_profile.fillna(min_positive)
            volume_profile = volume_profile.replace(0, min_positive)
            
        # Toplamı 1'e normalize et
        return volume_profile / volume_profile.sum()
        
    def _create_vwap_slices(self, order_id: str, vwap_order: VWAPOrder) -> List[VWAPSlice]:
        """
        VWAP execution slice'ları oluştur
        
        Args:
            order_id: Order ID
            vwap_order: VWAP order bilgileri
            
        Returns:
            List[VWAPSlice]: VWAP slice listesi
        """
        
        # Zaman aralığını hesapla
        total_duration = vwap_order.end_time - vwap_order.start_time
        duration_hours = total_duration.total_seconds() / 3600
        
        # Saatlik slice oluştur
        slices = []
        current_time = vwap_order.start_time
        
        slice_interval = timedelta(hours=1)  # 1 saatlik aralıklar
        
        slice_number = 1
        while current_time < vwap_order.end_time:
            # Slice son zamanı
            slice_end = min(current_time + slice_interval, vwap_order.end_time)
            
            # Bu zaman dilimindeki beklenen hacim ağırlığı
            hour = current_time.hour
            volume_weight = vwap_order.volume_profile.get(hour, 1.0 / len(vwap_order.volume_profile))
            
            # Expected market volume (varsayılan 1M share)
            expected_market_volume = volume_weight * 1000000  # 1M varsayılan
            
            # Slice miktarı
            slice_quantity = vwap_order.total_quantity * volume_weight
            
            # Miktar limitlerini kontrol et
            slice_quantity = max(self.min_slice_quantity, 
                               min(slice_quantity, self.max_slice_quantity))
            
            vwap_slice = VWAPSlice(
                order_id=order_id,
                slice_number=slice_number,
                quantity=slice_quantity,
                target_time=current_time + (slice_end - current_time) / 2,
                expected_market_volume=expected_market_volume
            )
            
            slices.append(vwap_slice)
            
            # Sonraki slice'a geç
            current_time = slice_end
            slice_number += 1
            
        return slices
        
    def execute_vwap_slice(self,
                          order_id: str,
                          slice_number: int,
                          current_time: datetime,
                          current_price: float,
                          current_market_volume: float,
                          total_daily_volume: Optional[float] = None) -> Dict:
        """
        VWAP slice'ı execute et
        
        Args:
            order_id: Order ID
            slice_number: Slice numarası
            current_time: Mevcut zaman
            current_price: Mevcut fiyat
            current_market_volume: Son 1 dakikadaki piyasa hacmi
            total_daily_volume: Toplam günlük hacim (varsayılan: 10M)
            
        Returns:
            Dict: Execution sonucu
        """
        
        if order_id not in self.execution_slices:
            raise ValueError(f"Order bulunamadı: {order_id}")
            
        if total_daily_volume is None:
            total_daily_volume = 10000000  # 10M varsayılan
            
        slices = self.execution_slices[order_id]
        if slice_number > len(slices) or slice_number < 1:
            raise ValueError(f"Geçersiz slice numarası: {slice_number}")
            
        slice_obj = slices[slice_number - 1]
        vwap_order = self.active_orders[order_id]
        
        # Beklenen hacim vs gerçek hacim farkını hesapla
        volume_deviation = current_market_volume / slice_obj.expected_market_volume if slice_obj.expected_market_volume > 0 else 1.0
        
        # Dinamik katılım oranı hesapla
        base_participation_rate = vwap_order.max_participation_rate
        dynamic_participation_rate = self._calculate_dynamic_participation_rate(
            volume_deviation, base_participation_rate, current_time, slice_obj.target_time
        )
        
        # Execute edilebilir miktar hesapla
        max_executable = current_market_volume * dynamic_participation_rate
        executable_quantity = min(slice_obj.quantity, max_executable)
        
        # Miktar limitlerini kontrol et
        executable_quantity = max(self.min_slice_quantity,
                                min(executable_quantity, self.max_slice_quantity))
        
        # Execution yap
        slice_obj.actual_executed_quantity = executable_quantity
        slice_obj.execution_price = current_price
        slice_obj.timestamp = current_time
        slice_obj.market_volume_observed = current_market_volume
        slice_obj.status = 'EXECUTED'
        
        # VWAP tracking güncelle
        tracking = self.vwap_tracking[order_id]
        tracking['cumulative_volume'] += executable_quantity
        tracking['cumulative_cost'] += executable_quantity * current_price
        
        result = {
            'status': 'EXECUTED',
            'quantity': executable_quantity,
            'price': current_price,
            'slice': slice_number,
            'participation_rate': dynamic_participation_rate,
            'volume_deviation': volume_deviation,
            'expected_volume': slice_obj.expected_market_volume,
            'actual_volume': current_market_volume
        }
        
        self.logger.info(f"VWAP slice execute edildi: Order {order_id}, Slice {slice_number}, "
                        f"Quantity: {executable_quantity:.0f}, Price: {current_price:.4f}, "
                        f"Part. Rate: {dynamic_participation_rate:.3f}")
        
        return result
        
    def _calculate_dynamic_participation_rate(self,
                                            volume_deviation: float,
                                            base_rate: float,
                                            current_time: datetime,
                                            target_time: datetime) -> float:
        """
        Dinamik katılım oranı hesapla
        
        Args:
            volume_deviation: Hacim sapması
            base_rate: Temel katılım oranı
            current_time: Mevcut zaman
            target_time: Hedef zaman
            
        Returns:
            float: Dinamik katılım oranı
        """
        
        # Zaman farkı (dakika cinsinden)
        time_diff_minutes = abs((current_time - target_time).total_seconds()) / 60
        
        # Hacim bazlı ayarlama
        if volume_deviation > 1.5:  # Yüksek hacim
            volume_adjustment = 1.2
        elif volume_deviation < 0.5:  # Düşük hacim
            volume_adjustment = 0.8
        else:  # Normal hacim
            volume_adjustment = 1.0
            
        # Zaman bazlı ayarlama
        if time_diff_minutes <= 15:  # Hedef zamana yakın
            time_adjustment = 1.1
        elif time_diff_minutes > 60:  # Hedef zamandan uzak
            time_adjustment = 0.9
        else:
            time_adjustment = 1.0
            
        # Final katılım oranı
        adjusted_rate = base_rate * volume_adjustment * time_adjustment
        
        # Limitlere sığdır
        return max(0.01, min(adjusted_rate, 0.30))  # %1-30 arası
        
    def update_volume_forecast(self, order_id: str, observed_volume: Dict[str, float]) -> None:
        """
        Hacim tahminini güncelle
        
        Args:
            order_id: Order ID
            observed_volume: Gözlemlenen hacimler (zaman -> hacim)
        """
        
        if order_id not in self.execution_slices:
            return
            
        slices = self.execution_slices[order_id]
        
        # Slice'lardaki expected volume'ları güncelle
        for slice_obj in slices:
            slice_time = slice_obj.target_time
            hour_key = slice_time.hour
            
            if hour_key in observed_volume:
                # Basit exponential smoothing
                alpha = 0.3  # Smoothing parameter
                new_expected = observed_volume[hour_key]
                old_expected = slice_obj.expected_market_volume
                
                slice_obj.expected_market_volume = alpha * new_expected + (1 - alpha) * old_expected
                
        self.logger.info(f"Volume forecast güncellendi: Order {order_id}")
        
    def get_vwap_performance(self, order_id: str) -> Dict:
        """
        VWAP performance metriklerini getir
        
        Args:
            order_id: Order ID
            
        Returns:
            Dict: VWAP performance metrikleri
        """
        
        if order_id not in self.active_orders:
            raise ValueError(f"Order bulunamadı: {order_id}")
            
        order = self.active_orders[order_id]
        slices = self.execution_slices[order_id]
        tracking = self.vwap_tracking[order_id]
        
        # Temel metrikler
        executed_quantity = sum(s.actual_executed_quantity for s in slices if s.status == 'EXECUTED')
        total_cost = sum(s.actual_executed_quantity * s.execution_price for s in slices if s.status == 'EXECUTED')
        actual_vwap = total_cost / executed_quantity if executed_quantity > 0 else 0
        
        # Hacim metrikleri
        total_expected_volume = sum(s.expected_market_volume for s in slices)
        total_observed_volume = sum(s.market_volume_observed for s in slices if s.market_volume_observed > 0)
        
        volume_accuracy = total_observed_volume / total_expected_volume if total_expected_volume > 0 else 1.0
        
        # Zamanlama metrikleri
        time_deviations = []
        for slice_obj in slices:
            if slice_obj.timestamp:
                deviation = abs((slice_obj.timestamp - slice_obj.target_time).total_seconds()) / 60
                time_deviations.append(deviation)
        
        avg_time_deviation = np.mean(time_deviations) if time_deviations else 0
        
        # Katılım oranı istatistikleri
        participation_rates = []
        current_time = datetime.now()
        for slice_obj in slices:
            if slice_obj.status == 'EXECUTED' and slice_obj.market_volume_observed > 0:
                participation_rate = slice_obj.actual_executed_quantity / slice_obj.market_volume_observed
                participation_rates.append(participation_rate)
        
        avg_participation_rate = np.mean(participation_rates) if participation_rates else 0
        
        return {
            'order_id': order_id,
            'symbol': order.symbol,
            'side': order.side,
            'total_quantity': order.total_quantity,
            'executed_quantity': executed_quantity,
            'completion_rate': executed_quantity / order.total_quantity,
            'actual_vwap': actual_vwap,
            'cumulative_volume': tracking['cumulative_volume'],
            'cumulative_cost': tracking['cumulative_cost'],
            'volume_accuracy': volume_accuracy,
            'avg_time_deviation_minutes': avg_time_deviation,
            'avg_participation_rate': avg_participation_rate,
            'slice_count': len(slices),
            'executed_slices': len([s for s in slices if s.status == 'EXECUTED'])
        }
        
    def get_market_vwap_benchmark(self, 
                                symbol: str,
                                start_time: datetime,
                                end_time: datetime,
                                current_prices: List[float],
                                current_volumes: List[float]) -> float:
        """
        Market VWAP benchmark hesapla
        
        Args:
            symbol: Sembol
            start_time: Başlangıç zamanı
            end_time: Bitiş zamanı
            current_prices: Mevcut fiyatlar listesi
            current_volumes: Mevcut hacimler listesi
            
        Returns:
            float: Market VWAP
        """
        
        if len(current_prices) != len(current_volumes) or len(current_prices) == 0:
            return 0.0
            
        # VWAP hesapla
        total_value = sum(price * volume for price, volume in zip(current_prices, current_volumes))
        total_volume = sum(current_volumes)
        
        return total_value / total_volume if total_volume > 0 else 0.0
        
    def cancel_order(self, order_id: str) -> bool:
        """
        Order'ı iptal et
        
        Args:
            order_id: Order ID
            
        Returns:
            bool: İptal başarılı ise True
        """
        
        if order_id not in self.active_orders:
            return False
            
        # Final performance hesapla
        if order_id in self.vwap_tracking:
            final_performance = self.get_vwap_performance(order_id)
            
            # Order'ı active_orders'dan kaldır
            del self.active_orders[order_id]
            
            # Execution state'i kaydet
            if order_id in self.execution_slices:
                execution_record = {
                    'order_id': order_id,
                    'cancellation_time': datetime.now(),
                    'performance': final_performance,
                    'executed_slices': len([s for s in self.execution_slices[order_id] if s.status == 'EXECUTED']),
                    'total_slices': len(self.execution_slices[order_id])
                }
                
                self.completed_executions.append(execution_record)
                
                # Execution slices'i kaldır
                del self.execution_slices[order_id]
            
            # VWAP tracking'i kaldır
            del self.vwap_tracking[order_id]
            
        self.logger.info(f"VWAP order iptal edildi: {order_id}")
        return True