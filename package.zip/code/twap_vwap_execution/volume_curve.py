"""
Volume Curve Analysis

Bu modül günlük hacim pattern'lerini analiz eden algoritmaları implement eder.
U-shaped, L-shaped ve diğer hacim dağılımlarını tespit eder, execution optimization için kullanır.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime, time, timedelta
import logging
from collections import defaultdict
from scipy import optimize
from scipy.interpolate import UnivariateSpline, interp1d
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
import warnings
warnings.filterwarnings('ignore')

@dataclass
class VolumePattern:
    """Hacim pattern bilgileri"""
    pattern_type: str  # 'U_SHAPED', 'L_SHAPED', 'FLAT', 'PEAKED', 'IRREGULAR'
    pattern_confidence: float  # 0-1 arası confidence
    morning_volume_ratio: float  # Sabah hacim oranı
    afternoon_volume_ratio: float  # Öğleden sonra hacim oranı
    peak_hours: List[int]  # Peak saatler
    valley_hours: List[int]  # Valley saatler
    volume_slope_morning: float  # Sabah trendi
    volume_slope_afternoon: float  # Öğleden sonra trendi

@dataclass
class VolumeCurve:
    """Hacim eğrisi"""
    timestamps: List[datetime]
    volumes: List[float]
    smoothed_volumes: List[float]
    pattern: VolumePattern
    trend_components: Dict[str, float]  # Seasonal, trend, cyclical
    outliers: List[int]  # Outlier indices

@dataclass
class VolumePrediction:
    """Hacim tahmini"""
    predicted_volume: float
    confidence_interval: Tuple[float, float]
    prediction_method: str
    historical_accuracy: float
    seasonal_factors: Dict[str, float]
    trend_adjustments: Dict[str, float]

class VolumeCurveAnalyzer:
    """
    Volume Curve Analysis Engine
    
    Günlük hacim pattern'lerini analiz eder:
    1. Pattern detection (U-shaped, L-shaped, etc.)
    2. Trend analysis
    3. Seasonal decomposition
    4. Outlier detection
    5. Volume forecasting
    """
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Historical volume data
        self.daily_volume_data: Dict[str, pd.DataFrame] = {}  # date -> volume data
        self.volume_patterns: Dict[str, VolumePattern] = {}  # date -> pattern
        self.aggregated_curve: Optional[np.ndarray] = None
        self.seasonal_components: Dict[str, np.ndarray] = {}
        self.trend_components: Dict[str, np.ndarray] = {}
        
        # Pattern recognition parameters
        self.pattern_tolerance = 0.15  # %15 tolerance for pattern recognition
        self.outlier_threshold = 2.5  # Standard deviations for outlier detection
        
        # Time intervals (5-minute intervals from 9:30 to 16:00)
        self.time_intervals = self._create_time_intervals()
        
    def _create_time_intervals(self) -> List[time]:
        """
        5-dakika aralıklı zaman listesi oluştur (9:30-16:00)
        
        Returns:
            List[time]: Time intervals
        """
        
        intervals = []
        current_time = time(9, 30)  # Market open
        
        while current_time < time(16, 0):  # Market close
            intervals.append(current_time)
            
            # 5 dakika ekle
            current_dt = datetime.combine(datetime.today(), current_time)
            current_dt += timedelta(minutes=5)
            current_time = current_dt.time()
            
        return intervals
        
    def analyze_daily_volume_pattern(self,
                                   volume_data: pd.DataFrame,
                                   symbol: str,
                                   date: str) -> VolumeCurve:
        """
        Günlük hacim pattern'ini analiz et
        
        Args:
            volume_data: Hacim verisi (timestamp, volume)
            symbol: Sembol
            date: Tarih
            
        Returns:
            VolumeCurve: Analiz sonucu
        """
        
        # Data validation
        if volume_data.empty:
            raise ValueError("Volume data boş olamaz")
            
        required_columns = ['timestamp', 'volume']
        if not all(col in volume_data.columns for col in required_columns):
            raise ValueError(f"Eksik columns: {required_columns}")
            
        # Preprocess data
        processed_data = self._preprocess_volume_data(volume_data, date)
        
        # Pattern detection
        pattern = self._detect_volume_pattern(processed_data)
        
        # Smooth the curve
        smoothed_volumes = self._smooth_volume_curve(processed_data['volume'].values)
        
        # Decompose components
        trend_components = self._decompose_volume_components(processed_data)
        
        # Detect outliers
        outliers = self._detect_volume_outliers(processed_data['volume'].values)
        
        volume_curve = VolumeCurve(
            timestamps=processed_data['timestamp'].tolist(),
            volumes=processed_data['volume'].tolist(),
            smoothed_volumes=smoothed_volumes.tolist(),
            pattern=pattern,
            trend_components=trend_components,
            outliers=outliers
        )
        
        # Store results
        self.daily_volume_data[date] = processed_data
        self.volume_patterns[date] = pattern
        
        self.logger.info(f"Daily volume pattern analiz edildi: {symbol} {date}, Pattern: {pattern.pattern_type}")
        
        return volume_curve
        
    def _preprocess_volume_data(self,
                              volume_data: pd.DataFrame,
                              date: str) -> pd.DataFrame:
        """
        Volume data'yı preprocess et
        
        Args:
            volume_data: Ham volume data
            date: Tarih
            
        Returns:
            pd.DataFrame: Preprocessed data
        """
        
        # Convert timestamp to datetime if needed
        if volume_data['timestamp'].dtype == 'object':
            volume_data['timestamp'] = pd.to_datetime(volume_data['timestamp'])
            
        # Add time column
        volume_data['time'] = volume_data['timestamp'].dt.time
        
        # Filter trading hours (9:30 - 16:00)
        trading_start = time(9, 30)
        trading_end = time(16, 0)
        
        volume_data = volume_data[
            (volume_data['time'] >= trading_start) &
            (volume_data['time'] <= trading_end)
        ].copy()
        
        # Resample to 5-minute intervals
        volume_data.set_index('timestamp', inplace=True)
        volume_data_resampled = volume_data.resample('5T').agg({
            'volume': 'sum',
            'time': 'first'
        }).fillna(0)
        
        # Reset index
        volume_data_resampled.reset_index(inplace=True)
        
        return volume_data_resampled
        
    def _detect_volume_pattern(self, data: pd.DataFrame) -> VolumePattern:
        """
        Volume pattern'ini tespit et
        
        Args:
            data: Preprocessed volume data
            
        Returns:
            VolumePattern: Detected pattern
        """
        
        volumes = data['volume'].values
        timestamps = data['timestamp']
        
        # Calculate hour-based aggregations
        data['hour'] = timestamps.dt.hour
        
        morning_volumes = data[data['hour'].isin([9, 10, 11])]['volume'].mean()
        afternoon_volumes = data[data['hour'].isin([12, 13, 14, 15])]['volume'].mean()
        
        # Calculate ratios
        total_volume = volumes.sum()
        morning_ratio = morning_volumes / total_volume if total_volume > 0 else 0
        afternoon_ratio = afternoon_volumes / total_volume if total_volume > 0 else 0
        
        # Pattern detection logic
        pattern_type, confidence = self._classify_pattern_type(volumes, morning_ratio, afternoon_ratio)
        
        # Find peak and valley hours
        peak_hours, valley_hours = self._find_peak_valley_hours(data)
        
        # Calculate slopes
        morning_slope = self._calculate_volume_slope(data, [9, 10, 11])
        afternoon_slope = self._calculate_volume_slope(data, [12, 13, 14, 15])
        
        return VolumePattern(
            pattern_type=pattern_type,
            pattern_confidence=confidence,
            morning_volume_ratio=morning_ratio,
            afternoon_volume_ratio=afternoon_ratio,
            peak_hours=peak_hours,
            valley_hours=valley_hours,
            volume_slope_morning=morning_slope,
            volume_slope_afternoon=afternoon_slope
        )
        
    def _classify_pattern_type(self,
                             volumes: np.ndarray,
                             morning_ratio: float,
                             afternoon_ratio: float) -> Tuple[str, float]:
        """
        Pattern type'ını sınıflandır
        
        Args:
            volumes: Volume array
            morning_ratio: Sabah hacim oranı
            afternoon_ratio: Öğleden sonra hacim oranı
            
        Returns:
            Tuple[str, float]: (pattern_type, confidence)
        """
        
        # Normalize volumes
        normalized_volumes = volumes / volumes.max() if volumes.max() > 0 else volumes
        
        # Calculate pattern metrics
        cv = np.std(normalized_volumes) / np.mean(normalized_volumes) if np.mean(normalized_volumes) > 0 else 0
        
        # Pattern classification
        if morning_ratio > 0.6 and afternoon_ratio < 0.4:
            # U-shaped pattern (high morning, low afternoon)
            pattern_type = 'U_SHAPED'
            confidence = min(1.0, (morning_ratio - afternoon_ratio) / 0.3)
            
        elif morning_ratio < 0.4 and afternoon_ratio > 0.6:
            # L-shaped pattern (low morning, high afternoon)
            pattern_type = 'L_SHAPED'
            confidence = min(1.0, (afternoon_ratio - morning_ratio) / 0.3)
            
        elif cv < 0.3:
            # Flat pattern
            pattern_type = 'FLAT'
            confidence = 1.0 - cv
            
        elif cv > 0.8:
            # Irregular pattern
            pattern_type = 'IRREGULAR'
            confidence = min(1.0, cv / 1.5)
            
        else:
            # Peaked pattern
            pattern_type = 'PEAKED'
            confidence = cv * 0.8
            
        return pattern_type, confidence
        
    def _find_peak_valley_hours(self, data: pd.DataFrame) -> Tuple[List[int], List[int]]:
        """
        Peak ve valley saatlerini bul
        
        Args:
            data: Volume data with hour column
            
        Returns:
            Tuple[List[int], List[int]]: (peak_hours, valley_hours)
        """
        
        hourly_volumes = data.groupby('hour')['volume'].mean()
        
        if len(hourly_volumes) == 0:
            return [], []
            
        # Find peaks (top 20% of hours)
        threshold_peak = hourly_volumes.quantile(0.8)
        peak_hours = hourly_volumes[hourly_volumes >= threshold_peak].index.tolist()
        
        # Find valleys (bottom 20% of hours)
        threshold_valley = hourly_volumes.quantile(0.2)
        valley_hours = hourly_volumes[hourly_volumes <= threshold_valley].index.tolist()
        
        return peak_hours, valley_hours
        
    def _calculate_volume_slope(self, data: pd.DataFrame, hours: List[int]) -> float:
        """
        Belirli saatler için volume trendini hesapla
        
        Args:
            data: Volume data
            hours: Analiz edilecek saatler
            
        Returns:
            float: Volume slope
        """
        
        hour_data = data[data['hour'].isin(hours)].copy()
        
        if len(hour_data) < 2:
            return 0.0
            
        # Simple linear regression for slope
        x = np.array(hours[:len(hour_data)])
        y = hour_data['volume'].values
        
        if len(x) < 2:
            return 0.0
            
        # Calculate slope
        slope = np.polyfit(x, y, 1)[0]
        
        return slope
        
    def _smooth_volume_curve(self, volumes: np.ndarray) -> np.ndarray:
        """
        Volume curve'ü smooth'la
        
        Args:
            volumes: Ham volume array
            
        Returns:
            np.ndarray: Smoothed volume array
        """
        
        if len(volumes) < 5:
            return volumes
            
        # Use Savitzky-Golay filter for smoothing
        try:
            from scipy.signal import savgol_filter
            window_length = min(21, len(volumes) if len(volumes) % 2 == 1 else len(volumes) - 1)
            if window_length < 5:
                window_length = 5
            smoothed = savgol_filter(volumes, window_length, 3)
        except:
            # Fallback to simple moving average
            window_size = min(7, len(volumes))
            smoothed = np.convolve(volumes, np.ones(window_size)/window_size, mode='same')
            
        return smoothed
        
    def _decompose_volume_components(self, data: pd.DataFrame) -> Dict[str, float]:
        """
        Volume component'lerini decompose et (trend, seasonal)
        
        Args:
            data: Volume data
            
        Returns:
            Dict[str, float]: Component values
        """
        
        volumes = data['volume'].values
        
        if len(volumes) < 10:
            return {'trend': 0.0, 'seasonal': 0.0, 'cyclical': 0.0}
            
        # Simple trend calculation (linear regression)
        x = np.arange(len(volumes))
        trend_coef = np.polyfit(x, volumes, 1)[0]
        
        # Seasonal component (hour-of-day effect)
        data['hour'] = pd.to_datetime(data['timestamp']).dt.hour
        hourly_avg = data.groupby('hour')['volume'].mean()
        overall_avg = hourly_avg.mean()
        seasonal_effect = hourly_avg.std() / overall_avg if overall_avg > 0 else 0
        
        # Cyclical component (residuals)
        detrended = volumes - np.polyval([trend_coef, volumes[0]], x)
        cyclical_strength = np.std(detrended) / np.mean(volumes) if np.mean(volumes) > 0 else 0
        
        return {
            'trend': trend_coef,
            'seasonal': seasonal_effect,
            'cyclical': cyclical_strength,
            'overall_trend': 'INCREASING' if trend_coef > 0 else 'DECREASING' if trend_coef < 0 else 'STABLE'
        }
        
    def _detect_volume_outliers(self, volumes: np.ndarray) -> List[int]:
        """
        Volume outlier'larını tespit et
        
        Args:
            volumes: Volume array
            
        Returns:
            List[int]: Outlier indices
        """
        
        if len(volumes) < 3:
            return []
            
        # Z-score based outlier detection
        z_scores = np.abs((volumes - np.mean(volumes)) / np.std(volumes))
        outlier_indices = np.where(z_scores > self.outlier_threshold)[0].tolist()
        
        return outlier_indices
        
    def analyze_multiple_days(self,
                            volume_data_list: List[Tuple[str, pd.DataFrame]],
                            symbol: str) -> Dict[str, VolumeCurve]:
        """
        Birden fazla günün volume pattern'lerini analiz et
        
        Args:
            volume_data_list: (date, volume_data) tuples
            symbol: Sembol
            
        Returns:
            Dict[str, VolumeCurve]: Date -> VolumeCurve mapping
        """
        
        daily_curves = {}
        
        for date, volume_data in volume_data_list:
            try:
                curve = self.analyze_daily_volume_pattern(volume_data, symbol, date)
                daily_curves[date] = curve
            except Exception as e:
                self.logger.error(f"Volume analysis failed for {date}: {e}")
                continue
                
        # Create aggregated pattern
        if daily_curves:
            self._create_aggregated_pattern(daily_curves)
            
        self.logger.info(f"Multiple days volume analysis completed: {len(daily_curves)} days")
        
        return daily_curves
        
    def _create_aggregated_pattern(self, daily_curves: Dict[str, VolumeCurve]) -> None:
        """
        Günlük pattern'lerden aggregated pattern oluştur
        
        Args:
            daily_curves: Daily volume curves
        """
        
        # Aggregate volumes across all days
        all_volumes = []
        max_length = max(len(curve.volumes) for curve in daily_curves.values())
        
        for i in range(max_length):
            day_volumes = []
            for curve in daily_curves.values():
                if i < len(curve.volumes):
                    day_volumes.append(curve.volumes[i])
            if day_volumes:
                all_volumes.append(np.mean(day_volumes))
                
        self.aggregated_curve = np.array(all_volumes)
        
        # Calculate aggregated pattern
        if len(self.aggregated_curve) > 0:
            pattern = self._detect_volume_pattern_from_array(self.aggregated_curve)
            self.aggregated_pattern = pattern
            
    def _detect_volume_pattern_from_array(self, volumes: np.ndarray) -> VolumePattern:
        """
        Array'den volume pattern'i tespit et
        
        Args:
            volumes: Volume array
            
        Returns:
            VolumePattern: Detected pattern
        """
        
        # Time mapping for array indices
        if len(volumes) == len(self.time_intervals):
            time_mapping = {i: self.time_intervals[i].hour for i in range(len(self.time_intervals))}
        else:
            time_mapping = {i: 9 + (i // 12) for i in range(len(volumes))}  # Approximate mapping
            
        # Calculate morning/afternoon ratios
        morning_indices = [i for i, hour in time_mapping.items() if hour in [9, 10, 11]]
        afternoon_indices = [i for i, hour in time_mapping.items() if hour in [12, 13, 14, 15]]
        
        morning_volume = np.mean([volumes[i] for i in morning_indices if i < len(volumes)]) if morning_indices else 0
        afternoon_volume = np.mean([volumes[i] for i in afternoon_indices if i < len(volumes)]) if afternoon_indices else 0
        
        total_volume = morning_volume + afternoon_volume
        morning_ratio = morning_volume / total_volume if total_volume > 0 else 0
        afternoon_ratio = afternoon_volume / total_volume if total_volume > 0 else 0
        
        # Pattern classification
        pattern_type, confidence = self._classify_pattern_type(volumes, morning_ratio, afternoon_ratio)
        
        # Peak/valley hours
        if volumes.size > 0:
            peak_threshold = np.percentile(volumes, 80)
            valley_threshold = np.percentile(volumes, 20)
            
            peak_indices = np.where(volumes >= peak_threshold)[0]
            valley_indices = np.where(volumes <= valley_threshold)[0]
            
            peak_hours = [time_mapping.get(i, 14) for i in peak_indices]
            valley_hours = [time_mapping.get(i, 12) for i in valley_indices]
        else:
            peak_hours = []
            valley_hours = []
            
        return VolumePattern(
            pattern_type=pattern_type,
            pattern_confidence=confidence,
            morning_volume_ratio=morning_ratio,
            afternoon_volume_ratio=afternoon_ratio,
            peak_hours=peak_hours,
            valley_hours=valley_hours,
            volume_slope_morning=0.0,
            volume_slope_afternoon=0.0
        )
        
    def predict_volume_at_time(self,
                             target_time: datetime,
                             prediction_method: str = 'pattern_based') -> VolumePrediction:
        """
        Belirli bir zaman için volume tahmini yap
        
        Args:
            target_time: Hedef zaman
            prediction_method: Tahmin metodu
            
        Returns:
            VolumePrediction: Volume tahmini
        """
        
        if not self.aggregated_curve is not None:
            # Use historical average if no aggregated data
            predicted_volume = 100000.0  # Default volume
            confidence = 0.3
            method = 'DEFAULT'
        else:
            # Map time to curve index
            target_hour = target_time.hour
            target_minute = target_time.minute
            
            # Find closest time interval
            closest_index = self._find_closest_time_index(target_hour, target_minute)
            
            if closest_index < len(self.aggregated_curve):
                predicted_volume = self.aggregated_curve[closest_index]
                confidence = self._calculate_prediction_confidence(closest_index)
                method = prediction_method
            else:
                predicted_volume = np.mean(self.aggregated_curve)
                confidence = 0.5
                method = 'INTERPOLATION'
                
        # Calculate confidence interval
        std_dev = np.std(self.aggregated_curve) if self.aggregated_curve is not None else predicted_volume * 0.3
        lower_bound = max(0, predicted_volume - 1.96 * std_dev)
        upper_bound = predicted_volume + 1.96 * std_dev
        
        # Seasonal adjustments
        seasonal_factors = self._calculate_seasonal_factors(target_time)
        
        # Trend adjustments
        trend_adjustments = self._calculate_trend_adjustments(target_time)
        
        return VolumePrediction(
            predicted_volume=predicted_volume,
            confidence_interval=(lower_bound, upper_bound),
            prediction_method=method,
            historical_accuracy=confidence,
            seasonal_factors=seasonal_factors,
            trend_adjustments=trend_adjustments
        )
        
    def _find_closest_time_index(self, hour: int, minute: int) -> int:
        """
        Verilen saat için en yakın time index'ini bul
        
        Args:
            hour: Saat
            minute: Dakika
            
        Returns:
            int: Time index
        """
        
        target_minutes = hour * 60 + minute
        
        closest_index = 0
        min_diff = float('inf')
        
        for i, time_point in enumerate(self.time_intervals):
            time_minutes = time_point.hour * 60 + time_point.minute
            diff = abs(time_minutes - target_minutes)
            
            if diff < min_diff:
                min_diff = diff
                closest_index = i
                
        return closest_index
        
    def _calculate_prediction_confidence(self, index: int) -> float:
        """
        Tahmin confidence'ını hesapla
        
        Args:
            index: Curve index
            
        Returns:
            float: Confidence score (0-1)
        """
        
        if self.aggregated_curve is None or len(self.aggregated_curve) == 0:
            return 0.5
            
        # Confidence based on pattern strength and data quality
        curve_std = np.std(self.aggregated_curve)
        curve_mean = np.mean(self.aggregated_curve)
        
        # Lower coefficient of variation = higher confidence
        if curve_mean > 0:
            cv = curve_std / curve_mean
            confidence = max(0.1, min(1.0, 1 - cv))
        else:
            confidence = 0.5
            
        return confidence
        
    def _calculate_seasonal_factors(self, target_time: datetime) -> Dict[str, float]:
        """
        Seasonal faktörleri hesapla
        
        Args:
            target_time: Hedef zaman
            
        Returns:
            Dict[str, float]: Seasonal factors
        """
        
        hour = target_time.hour
        day_of_week = target_time.weekday()
        
        # Hour-of-day factor
        if hasattr(self, 'aggregated_pattern'):
            if hour in self.aggregated_pattern.peak_hours:
                hour_factor = 1.2
            elif hour in self.aggregated_pattern.valley_hours:
                hour_factor = 0.8
            else:
                hour_factor = 1.0
        else:
            hour_factor = 1.0
            
        # Day-of-week factor
        if day_of_week < 5:  # Weekday
            dow_factor = 1.0
        else:  # Weekend
            dow_factor = 0.7
            
        return {
            'hour_factor': hour_factor,
            'day_of_week_factor': dow_factor,
            'combined_factor': hour_factor * dow_factor
        }
        
    def _calculate_trend_adjustments(self, target_time: datetime) -> Dict[str, float]:
        """
        Trend adjustments hesapla
        
        Args:
            target_time: Hedef zaman
            
        Returns:
            Dict[str, float]: Trend adjustments
        """
        
        # Simple trend based on current market conditions
        # In real implementation, this would use more sophisticated trend analysis
        
        return {
            'momentum_factor': 1.0,  # Placeholder
            'volatility_adjustment': 1.0,  # Placeholder
            'liquidity_adjustment': 1.0  # Placeholder
        }
        
    def get_volume_statistics(self) -> Dict:
        """
        Volume istatistiklerini getir
        
        Returns:
            Dict: Volume statistics
        """
        
        stats = {
            'total_days_analyzed': len(self.daily_volume_data),
            'pattern_distribution': {},
            'aggregated_pattern': None
        }
        
        # Pattern distribution
        pattern_counts = defaultdict(int)
        for pattern in self.volume_patterns.values():
            pattern_counts[pattern.pattern_type] += 1
            
        stats['pattern_distribution'] = dict(pattern_counts)
        
        # Aggregated pattern
        if hasattr(self, 'aggregated_pattern'):
            stats['aggregated_pattern'] = {
                'type': self.aggregated_pattern.pattern_type,
                'confidence': self.aggregated_pattern.pattern_confidence,
                'morning_ratio': self.aggregated_pattern.morning_volume_ratio,
                'afternoon_ratio': self.aggregated_pattern.afternoon_volume_ratio
            }
            
        return stats
        
    def export_volume_analysis(self, filepath: str) -> None:
        """
        Volume analysis'ini export et
        
        Args:
            filepath: Export dosya yolu
        """
        
        export_data = {
            'volume_statistics': self.get_volume_statistics(),
            'daily_patterns': {},
            'aggregated_curve': self.aggregated_curve.tolist() if self.aggregated_curve is not None else None
        }
        
        # Export daily patterns
        for date, pattern in self.volume_patterns.items():
            export_data['daily_patterns'][date] = {
                'pattern_type': pattern.pattern_type,
                'pattern_confidence': pattern.pattern_confidence,
                'morning_ratio': pattern.morning_volume_ratio,
                'afternoon_ratio': pattern.afternoon_volume_ratio,
                'peak_hours': pattern.peak_hours,
                'valley_hours': pattern.valley_hours
            }
            
        # Save to file (simplified - in practice would use proper serialization)
        import json
        with open(filepath, 'w') as f:
            json.dump(export_data, f, indent=2, default=str)
            
        self.logger.info(f"Volume analysis exported: {filepath}")