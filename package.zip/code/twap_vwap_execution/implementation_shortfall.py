"""
Implementation Shortfall Minimization

Bu modül implementation shortfall'ı minimize eden execution algoritmalarını implement eder.
Cost components analizi, benchmark selection ve optimal execution strategy geliştirme.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging
from collections import defaultdict, deque
from scipy import optimize
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

@dataclass
class ShortfallComponent:
    """Implementation shortfall bileşeni"""
    component_name: str  # 'TEMPORARY_IMPACT', 'PERMANENT_IMPACT', 'TIMING', 'OPPORTUNITY'
    cost_value: float  # Cost in currency units
    cost_percentage: float  # Cost as percentage of order value
    weight_in_total: float  # Weight in total shortfall
    benchmark_value: float  # Benchmark value for comparison

@dataclass
class ShortfallMetrics:
    """Implementation shortfall metrikleri"""
    total_shortfall: float
    total_shortfall_pct: float
    components: List[ShortfallComponent]
    benchmark_price: float
    execution_price: float
    decision_price: float
    benchmark_type: str
    analysis_timestamp: datetime

@dataclass
class OptimizationConstraints:
    """Optimization kısıtları"""
    max_participation_rate: float = 0.30
    min_slice_size: float = 500.0
    max_slice_size: float = 500000.0
    max_execution_time_hours: float = 8.0
    regulatory_limit: float = 0.20
    venue_limit: float = 0.10
    risk_limit: float = 0.25

@dataclass
class OptimalExecutionStrategy:
    """Optimal execution stratejisi"""
    strategy_name: str
    expected_shortfall: float
    confidence_score: float
    slice_schedule: List[Dict]
    participation_rates: List[float]
    timing_recommendations: List[str]
    risk_factors: List[str]
    expected_benefits: Dict[str, float]

class BenchmarkSelector:
    """Benchmark selection sınıfı"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    def select_optimal_benchmark(self,
                               execution_start: datetime,
                               execution_end: datetime,
                               symbol: str,
                               price_data: pd.DataFrame,
                               execution_data: Optional[pd.DataFrame] = None) -> Dict:
        """
        Optimal benchmark'i seç
        
        Args:
            execution_start: Execution başlangıç zamanı
            execution_end: Execution bitiş zamanı
            symbol: Sembol
            price_data: Historical price data
            execution_data: Historical execution data (optional)
            
        Returns:
            Dict: Benchmark selection result
        """
        
        candidates = self._get_benchmark_candidates(execution_start, execution_end, price_data)
        
        if not candidates:
            # Fallback to simple benchmarks
            return self._fallback_benchmark_selection(price_data, execution_start, execution_end)
            
        # Evaluate candidates
        evaluated_benchmarks = self._evaluate_benchmark_candidates(candidates, execution_data)
        
        # Select optimal benchmark
        optimal_benchmark = self._select_best_benchmark(evaluated_benchmarks)
        
        return optimal_benchmark
        
    def _get_benchmark_candidates(self,
                                execution_start: datetime,
                                execution_end: datetime,
                                price_data: pd.DataFrame) -> List[Dict]:
        """
        Benchmark candidate'larını getir
        
        Args:
            execution_start: Execution start
            execution_end: Execution end
            price_data: Price data
            
        Returns:
            List[Dict]: Benchmark candidates
        """
        
        candidates = []
        
        # Convert to datetime if needed
        if not isinstance(execution_start, datetime):
            execution_start = pd.to_datetime(execution_start)
        if not isinstance(execution_end, datetime):
            execution_end = pd.to_datetime(execution_end)
            
        # 1. Decision price (price when order was decided)
        decision_time = execution_start - timedelta(minutes=30)  # 30 minutes before
        decision_price = self._get_price_at_time(price_data, decision_time)
        
        if decision_price > 0:
            candidates.append({
                'type': 'DECISION_PRICE',
                'value': decision_price,
                'timestamp': decision_time,
                'description': 'Price at order decision time'
            })
            
        # 2. Opening price
        open_time = execution_start.replace(hour=9, minute=30, second=0, microsecond=0)
        open_price = self._get_price_at_time(price_data, open_time)
        
        if open_price > 0:
            candidates.append({
                'type': 'OPENING_PRICE',
                'value': open_price,
                'timestamp': open_time,
                'description': 'Market opening price'
            })
            
        # 3. Volume-weighted average price (VWAP)
        vwap = self._calculate_vwap(price_data, execution_start, execution_end)
        
        if vwap > 0:
            candidates.append({
                'type': 'EXECUTION_VWAP',
                'value': vwap,
                'timestamp': execution_start,
                'description': 'Volume-weighted average price during execution'
            })
            
        # 4. Time-weighted average price (TWAP)
        twap = self._calculate_twap(price_data, execution_start, execution_end)
        
        if twap > 0:
            candidates.append({
                'type': 'EXECUTION_TWAP',
                'value': twap,
                'timestamp': execution_start,
                'description': 'Time-weighted average price during execution'
            })
            
        # 5. Arrival price (price at arrival to market)
        arrival_price = self._get_price_at_time(price_data, execution_start)
        
        if arrival_price > 0:
            candidates.append({
                'type': 'ARRIVAL_PRICE',
                'value': arrival_price,
                'timestamp': execution_start,
                'description': 'Price at arrival to market'
            })
            
        return candidates
        
    def _get_price_at_time(self, price_data: pd.DataFrame, target_time: datetime) -> float:
        """
        Belirli bir zamandaki fiyatı al
        
        Args:
            price_data: Price data
            target_time: Target time
            
        Returns:
            float: Price at target time
        """
        
        # Find closest price before target time
        price_data_sorted = price_data.sort_values('timestamp')
        
        before_prices = price_data_sorted[price_data_sorted['timestamp'] <= target_time]
        
        if not before_prices.empty:
            return before_prices.iloc[-1]['price']
            
        # If no price before target time, use first available price
        if not price_data_sorted.empty:
            return price_data_sorted.iloc[0]['price']
            
        return 0.0
        
    def _calculate_vwap(self,
                       price_data: pd.DataFrame,
                       start_time: datetime,
                       end_time: datetime) -> float:
        """
        VWAP hesapla
        
        Args:
            price_data: Price and volume data
            start_time: Start time
            end_time: End time
            
        Returns:
            float: VWAP
        """
        
        # Filter data for execution period
        period_data = price_data[
            (price_data['timestamp'] >= start_time) &
            (price_data['timestamp'] <= end_time)
        ]
        
        if period_data.empty or 'volume' not in period_data.columns:
            return 0.0
            
        # Calculate VWAP
        total_value = (period_data['price'] * period_data['volume']).sum()
        total_volume = period_data['volume'].sum()
        
        return total_value / total_volume if total_volume > 0 else 0.0
        
    def _calculate_twap(self,
                       price_data: pd.DataFrame,
                       start_time: datetime,
                       end_time: datetime) -> float:
        """
        TWAP hesapla
        
        Args:
            price_data: Price data
            start_time: Start time
            end_time: End time
            
        Returns:
            float: TWAP
        """
        
        # Filter data for execution period
        period_data = price_data[
            (price_data['timestamp'] >= start_time) &
            (price_data['timestamp'] <= end_time)
        ]
        
        if period_data.empty:
            return 0.0
            
        return period_data['price'].mean()
        
    def _evaluate_benchmark_candidates(self,
                                     candidates: List[Dict],
                                     execution_data: Optional[pd.DataFrame] = None) -> List[Dict]:
        """
        Benchmark candidate'larını değerlendir
        
        Args:
            candidates: Benchmark candidates
            execution_data: Historical execution data
            
        Returns:
            List[Dict]: Evaluated candidates
        """
        
        evaluated = []
        
        for candidate in candidates:
            # Calculate evaluation metrics
            score = self._calculate_benchmark_score(candidate, execution_data)
            candidate['evaluation_score'] = score
            candidate['suitability_factors'] = self._assess_suitability(candidate)
            evaluated.append(candidate)
            
        return evaluated
        
    def _calculate_benchmark_score(self,
                                 candidate: Dict,
                                 execution_data: Optional[pd.DataFrame] = None) -> float:
        """
        Benchmark score hesapla
        
        Args:
            candidate: Benchmark candidate
            execution_data: Historical execution data
            
        Returns:
            float: Benchmark score
        """
        
        base_score = 0.5  # Base score
        
        # Type-based scoring
        type_scores = {
            'DECISION_PRICE': 0.9,
            'ARRIVAL_PRICE': 0.8,
            'EXECUTION_VWAP': 0.7,
            'EXECUTION_TWAP': 0.6,
            'OPENING_PRICE': 0.5
        }
        
        score = type_scores.get(candidate['type'], 0.5)
        
        # Adjust based on data availability
        if candidate['value'] > 0:
            score += 0.1
            
        # Historical performance adjustment (if execution_data available)
        if execution_data is not None:
            historical_score = self._assess_historical_benchmark_performance(
                candidate['type'], execution_data
            )
            score = (score + historical_score) / 2
            
        return min(1.0, score)
        
    def _assess_suitability(self, candidate: Dict) -> Dict[str, float]:
        """
        Benchmark uygunluğunu değerlendir
        
        Args:
            candidate: Benchmark candidate
            
        Returns:
            Dict[str, float]: Suitability factors
        """
        
        factors = {
            'availability': 1.0 if candidate['value'] > 0 else 0.0,
            'timeliness': 1.0,  # Assume timely
            'relevance': 0.8,  # Assume relevant
            'benchmark_quality': 0.7  # Assume good quality
        }
        
        return factors
        
    def _assess_historical_benchmark_performance(self,
                                               benchmark_type: str,
                                               execution_data: pd.DataFrame) -> float:
        """
        Historical benchmark performance'ını değerlendir
        
        Args:
            benchmark_type: Benchmark type
            execution_data: Historical execution data
            
        Returns:
            float: Historical performance score
        """
        
        # Simplified historical assessment
        # In practice, would analyze actual execution vs benchmark correlation
        
        if benchmark_type == 'DECISION_PRICE':
            return 0.85  # Generally good for implementation shortfall
        elif benchmark_type == 'ARRIVAL_PRICE':
            return 0.75  # Good for market arrival analysis
        elif benchmark_type == 'EXECUTION_VWAP':
            return 0.80  # Good for volume-based analysis
        else:
            return 0.65  # Default score
            
    def _select_best_benchmark(self, evaluated_candidates: List[Dict]) -> Dict:
        """
        En iyi benchmark'i seç
        
        Args:
            evaluated_candidates: Evaluated candidates
            
        Returns:
            Dict: Best benchmark
        """
        
        if not evaluated_candidates:
            return {'type': 'DECISION_PRICE', 'value': 0.0, 'description': 'Fallback benchmark'}
            
        # Select candidate with highest score
        best_candidate = max(evaluated_candidates, key=lambda x: x['evaluation_score'])
        
        return best_candidate
        
    def _fallback_benchmark_selection(self,
                                    price_data: pd.DataFrame,
                                    execution_start: datetime,
                                    execution_end: datetime) -> Dict:
        """
        Fallback benchmark selection
        
        Args:
            price_data: Price data
            execution_start: Execution start
            execution_end: Execution end
            
        Returns:
            Dict: Fallback benchmark
        """
        
        # Use arrival price as fallback
        arrival_price = self._get_price_at_time(price_data, execution_start)
        
        return {
            'type': 'ARRIVAL_PRICE',
            'value': arrival_price,
            'timestamp': execution_start,
            'description': 'Fallback: Price at execution start'
        }

class ShortfallCalculator:
    """Implementation shortfall hesaplama sınıfı"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    def calculate_implementation_shortfall(self,
                                         execution_data: pd.DataFrame,
                                         benchmark_info: Dict,
                                         decision_time: datetime) -> ShortfallMetrics:
        """
        Implementation shortfall hesapla
        
        Args:
            execution_data: Execution data (timestamp, price, quantity)
            benchmark_info: Benchmark information
            decision_time: Order decision time
            
        Returns:
            ShortfallMetrics: Shortfall calculation result
        """
        
        if execution_data.empty:
            raise ValueError("Execution data boş olamaz")
            
        # Calculate weighted average execution price
        total_value = (execution_data['price'] * execution_data['quantity']).sum()
        total_quantity = execution_data['quantity'].sum()
        execution_price = total_value / total_quantity if total_quantity > 0 else 0
        
        # Get benchmark price
        benchmark_price = benchmark_info['value']
        
        # Calculate total shortfall
        total_shortfall = (execution_price - benchmark_price) * total_quantity
        
        # Calculate shortfall as percentage
        total_order_value = benchmark_price * total_quantity
        total_shortfall_pct = total_shortfall / total_order_value if total_order_value > 0 else 0
        
        # Calculate components
        components = self._calculate_shortfall_components(
            execution_data, benchmark_info, decision_time
        )
        
        return ShortfallMetrics(
            total_shortfall=total_shortfall,
            total_shortfall_pct=total_shortfall_pct,
            components=components,
            benchmark_price=benchmark_price,
            execution_price=execution_price,
            decision_price=benchmark_info['value'],  # Assume decision price = benchmark
            benchmark_type=benchmark_info['type'],
            analysis_timestamp=datetime.now()
        )
        
    def _calculate_shortfall_components(self,
                                      execution_data: pd.DataFrame,
                                      benchmark_info: Dict,
                                      decision_time: datetime) -> List[ShortfallComponent]:
        """
        Shortfall bileşenlerini hesapla
        
        Args:
            execution_data: Execution data
            benchmark_info: Benchmark info
            decision_time: Decision time
            
        Returns:
            List[ShortfallComponent]: Shortfall components
        """
        
        components = []
        
        total_quantity = execution_data['quantity'].sum()
        total_value = (execution_data['price'] * execution_data['quantity']).sum()
        benchmark_price = benchmark_info['value']
        
        # 1. Temporary Impact Component
        temp_impact = self._calculate_temporary_impact(execution_data, benchmark_price)
        temp_impact_pct = temp_impact / (benchmark_price * total_quantity) if total_quantity > 0 else 0
        temp_weight = abs(temp_impact) / abs((execution_data['price'].mean() - benchmark_price) * total_quantity) if total_quantity > 0 else 0
        
        components.append(ShortfallComponent(
            component_name='TEMPORARY_IMPACT',
            cost_value=temp_impact,
            cost_percentage=temp_impact_pct * 100,
            weight_in_total=temp_weight,
            benchmark_value=benchmark_price
        ))
        
        # 2. Permanent Impact Component
        perm_impact = self._calculate_permanent_impact(execution_data, benchmark_price)
        perm_impact_pct = perm_impact / (benchmark_price * total_quantity) if total_quantity > 0 else 0
        perm_weight = abs(perm_impact) / abs((execution_data['price'].mean() - benchmark_price) * total_quantity) if total_quantity > 0 else 0
        
        components.append(ShortfallComponent(
            component_name='PERMANENT_IMPACT',
            cost_value=perm_impact,
            cost_percentage=perm_impact_pct * 100,
            weight_in_total=perm_weight,
            benchmark_value=benchmark_price
        ))
        
        # 3. Timing Component
        timing_cost = self._calculate_timing_cost(execution_data, benchmark_info, decision_time)
        timing_pct = timing_cost / (benchmark_price * total_quantity) if total_quantity > 0 else 0
        timing_weight = abs(timing_cost) / abs((execution_data['price'].mean() - benchmark_price) * total_quantity) if total_quantity > 0 else 0
        
        components.append(ShortfallComponent(
            component_name='TIMING',
            cost_value=timing_cost,
            cost_percentage=timing_pct * 100,
            weight_in_total=timing_weight,
            benchmark_value=benchmark_price
        ))
        
        # 4. Opportunity Cost Component
        opportunity_cost = self._calculate_opportunity_cost(execution_data, benchmark_info)
        opportunity_pct = opportunity_cost / (benchmark_price * total_quantity) if total_quantity > 0 else 0
        opportunity_weight = abs(opportunity_cost) / abs((execution_data['price'].mean() - benchmark_price) * total_quantity) if total_quantity > 0 else 0
        
        components.append(ShortfallComponent(
            component_name='OPPORTUNITY',
            cost_value=opportunity_cost,
            cost_percentage=opportunity_pct * 100,
            weight_in_total=opportunity_weight,
            benchmark_value=benchmark_price
        ))
        
        return components
        
    def _calculate_temporary_impact(self,
                                  execution_data: pd.DataFrame,
                                  benchmark_price: float) -> float:
        """
        Temporary impact hesapla
        
        Args:
            execution_data: Execution data
            benchmark_price: Benchmark price
            
        Returns:
            float: Temporary impact cost
        """
        
        # Temporary impact = price improvement after execution
        # This is a simplified calculation
        
        if len(execution_data) < 2:
            return 0.0
            
        # Price recovery after execution
        last_price = execution_data['price'].iloc[-1]
        price_recovery = last_price - benchmark_price
        
        # Weight by execution quantity
        total_quantity = execution_data['quantity'].sum()
        
        return price_recovery * total_quantity
        
    def _calculate_permanent_impact(self,
                                  execution_data: pd.DataFrame,
                                  benchmark_price: float) -> float:
        """
        Permanent impact hesapla
        
        Args:
            execution_data: Execution data
            benchmark_price: Benchmark price
            
        Returns:
            float: Permanent impact cost
        """
        
        # Permanent impact = long-term price change
        # Simplified: use difference between first and last price
        
        if len(execution_data) < 2:
            return 0.0
            
        first_price = execution_data['price'].iloc[0]
        last_price = execution_data['price'].iloc[-1]
        
        price_change = last_price - first_price
        total_quantity = execution_data['quantity'].sum()
        
        return price_change * total_quantity
        
    def _calculate_timing_cost(self,
                             execution_data: pd.DataFrame,
                             benchmark_info: Dict,
                             decision_time: datetime) -> float:
        """
        Timing cost hesapla
        
        Args:
            execution_data: Execution data
            benchmark_info: Benchmark info
            decision_time: Decision time
            
        Returns:
            float: Timing cost
        """
        
        # Timing cost = cost of delayed execution
        # Simplified: use execution delay penalty
        
        if execution_data.empty:
            return 0.0
            
        # Calculate execution delay
        first_execution_time = pd.to_datetime(execution_data['timestamp'].iloc[0])
        delay_hours = (first_execution_time - decision_time).total_seconds() / 3600
        
        # Penalty for delay (assume 0.01% per hour)
        delay_penalty = delay_hours * 0.0001
        
        total_quantity = execution_data['quantity'].sum()
        benchmark_price = benchmark_info['value']
        
        return delay_penalty * benchmark_price * total_quantity
        
    def _calculate_opportunity_cost(self,
                                  execution_data: pd.DataFrame,
                                  benchmark_info: Dict) -> float:
        """
        Opportunity cost hesapla
        
        Args:
            execution_data: Execution data
            benchmark_info: Benchmark info
            
        Returns:
            float: Opportunity cost
        """
        
        # Opportunity cost = cost of not executing at better prices
        # Simplified: compare to best possible execution
        
        if execution_data.empty:
            return 0.0
            
        # Find best price in execution data
        best_price = execution_data['price'].min()
        total_quantity = execution_data['quantity'].sum()
        benchmark_price = benchmark_info['value']
        
        # If we could have executed all at best price
        best_possible_value = best_price * total_quantity
        actual_value = (execution_data['price'] * execution_data['quantity']).sum()
        
        opportunity_cost = best_possible_value - actual_value
        
        return opportunity_cost

class ShortfallMinimizer:
    """
    Implementation Shortfall Minimization Engine
    
    Optimal execution strategy geliştirerek implementation shortfall'ı minimize eder.
    """
    
    def __init__(self,
                 constraints: Optional[OptimizationConstraints] = None,
                 benchmark_selector: Optional[BenchmarkSelector] = None,
                 shortfall_calculator: Optional[ShortfallCalculator] = None):
        """
        Args:
            constraints: Optimization constraints
            benchmark_selector: Benchmark selector
            shortfall_calculator: Shortfall calculator
        """
        
        self.constraints = constraints or OptimizationConstraints()
        self.benchmark_selector = benchmark_selector or BenchmarkSelector()
        self.shortfall_calculator = shortfall_calculator or ShortfallCalculator()
        self.logger = logging.getLogger(__name__)
        
        # Optimization history
        self.optimization_history: List[Dict] = []
        self.performance_data: Dict = {}
        
    def develop_optimal_strategy(self,
                               order_size: float,
                               symbol: str,
                               market_data: Dict,
                               execution_horizon: timedelta,
                               risk_tolerance: float = 0.5) -> OptimalExecutionStrategy:
        """
        Optimal execution stratejisi geliştir
        
        Args:
            order_size: Order size
            symbol: Sembol
            market_data: Market data
            execution_horizon: Execution time horizon
            risk_tolerance: Risk tolerance (0-1)
            
        Returns:
            OptimalExecutionStrategy: Optimal strategy
        """
        
        # 1. Select optimal benchmark
        execution_start = datetime.now()
        execution_end = execution_start + execution_horizon
        
        benchmark_info = self.benchmark_selector.select_optimal_benchmark(
            execution_start, execution_end, symbol, market_data.get('price_data', pd.DataFrame())
        )
        
        # 2. Develop execution strategies
        strategies = self._develop_execution_strategies(
            order_size, symbol, market_data, execution_horizon, risk_tolerance
        )
        
        # 3. Evaluate and select best strategy
        best_strategy = self._select_optimal_strategy(strategies, benchmark_info, market_data)
        
        # 4. Create detailed implementation plan
        implementation_plan = self._create_implementation_plan(best_strategy, market_data)
        
        # Store optimization result
        optimization_record = {
            'timestamp': datetime.now(),
            'symbol': symbol,
            'order_size': order_size,
            'strategy': best_strategy.strategy_name,
            'expected_shortfall': best_strategy.expected_shortfall,
            'benchmark_type': benchmark_info['type'],
            'risk_tolerance': risk_tolerance
        }
        
        self.optimization_history.append(optimization_record)
        
        self.logger.info(f"Optimal strategy developed: {symbol}, Order: {order_size:.0f}, "
                        f"Strategy: {best_strategy.strategy_name}, Expected shortfall: {best_strategy.expected_shortfall:.4f}")
        
        return best_strategy
        
    def _develop_execution_strategies(self,
                                    order_size: float,
                                    symbol: str,
                                    market_data: Dict,
                                    execution_horizon: timedelta,
                                    risk_tolerance: float) -> List[OptimalExecutionStrategy]:
        """
        Execution stratejileri geliştir
        
        Args:
            order_size: Order size
            symbol: Sembol
            market_data: Market data
            execution_horizon: Execution horizon
            risk_tolerance: Risk tolerance
            
        Returns:
            List[OptimalExecutionStrategy]: Execution strategies
        """
        
        strategies = []
        
        # 1. TWAP Strategy
        twap_strategy = self._create_twap_strategy(order_size, market_data, execution_horizon)
        strategies.append(twap_strategy)
        
        # 2. VWAP Strategy
        vwap_strategy = self._create_vwap_strategy(order_size, market_data, execution_horizon)
        strategies.append(vwap_strategy)
        
        # 3. Adaptive Strategy
        adaptive_strategy = self._create_adaptive_strategy(order_size, market_data, execution_horizon, risk_tolerance)
        strategies.append(adaptive_strategy)
        
        # 4. Risk-Averse Strategy
        risk_averse_strategy = self._create_risk_averse_strategy(order_size, market_data, execution_horizon)
        strategies.append(risk_averse_strategy)
        
        # 5. Aggressive Strategy
        aggressive_strategy = self._create_aggressive_strategy(order_size, market_data, execution_horizon, risk_tolerance)
        strategies.append(aggressive_strategy)
        
        return strategies
        
    def _create_twap_strategy(self,
                            order_size: float,
                            market_data: Dict,
                            execution_horizon: timedelta) -> OptimalExecutionStrategy:
        """
        TWAP stratejisi oluştur
        
        Args:
            order_size: Order size
            market_data: Market data
            execution_horizon: Execution horizon
            
        Returns:
            OptimalExecutionStrategy: TWAP strategy
        """
        
        # Calculate optimal slice count
        total_minutes = execution_horizon.total_seconds() / 60
        slice_count = min(50, max(5, int(total_minutes / 15)))  # 15-minute intervals
        
        slice_size = order_size / slice_count
        
        # Create slice schedule
        slice_schedule = []
        participation_rates = []
        
        for i in range(slice_count):
            slice_info = {
                'slice_number': i + 1,
                'quantity': slice_size,
                'target_time': f"Slice {i + 1}",
                'execution_window': '15 minutes'
            }
            slice_schedule.append(slice_info)
            participation_rates.append(0.05)  # 5% participation rate
            
        # Estimate expected shortfall
        expected_shortfall = order_size * 0.001 * market_data.get('volatility', 0.02)  # 0.1% * volatility
        
        timing_recommendations = [
            "Execute in equal time intervals",
            "Maintain consistent participation rate",
            "Monitor market conditions for adjustments"
        ]
        
        risk_factors = [
            "Market timing risk",
            "Volatility exposure",
            "Opportunity cost risk"
        ]
        
        return OptimalExecutionStrategy(
            strategy_name='TWAP',
            expected_shortfall=expected_shortfall,
            confidence_score=0.7,
            slice_schedule=slice_schedule,
            participation_rates=participation_rates,
            timing_recommendations=timing_recommendations,
            risk_factors=risk_factors,
            expected_benefits={'cost_predictability': 0.8, 'execution_quality': 0.7}
        )
        
    def _create_vwap_strategy(self,
                            order_size: float,
                            market_data: Dict,
                            execution_horizon: timedelta) -> OptimalExecutionStrategy:
        """
        VWAP stratejisi oluştur
        
        Args:
            order_size: Order size
            market_data: Market data
            execution_horizon: Execution horizon
            
        Returns:
            OptimalExecutionStrategy: VWAP strategy
        """
        
        # Volume-based slice distribution
        volume_profile = market_data.get('volume_profile', {})
        
        slice_schedule = []
        participation_rates = []
        
        # Create volume-weighted slices
        base_slice_size = order_size / 20  # 20 slices
        
        for i in range(20):
            # Volume weight (simplified)
            volume_weight = 1.0  # Would use actual volume profile
            
            slice_size = base_slice_size * volume_weight
            slice_info = {
                'slice_number': i + 1,
                'quantity': slice_size,
                'target_time': f"Slice {i + 1}",
                'volume_weight': volume_weight
            }
            slice_schedule.append(slice_info)
            participation_rates.append(0.08)  # 8% participation rate
            
        expected_shortfall = order_size * 0.0008 * market_data.get('volatility', 0.02)  # 0.08% * volatility
        
        timing_recommendations = [
            "Adjust execution to market volume patterns",
            "Increase participation during high volume periods",
            "Reduce participation during low volume periods"
        ]
        
        risk_factors = [
            "Volume prediction risk",
            "Market impact risk",
            "Benchmark tracking risk"
        ]
        
        return OptimalExecutionStrategy(
            strategy_name='VWAP',
            expected_shortfall=expected_shortfall,
            confidence_score=0.75,
            slice_schedule=slice_schedule,
            participation_rates=participation_rates,
            timing_recommendations=timing_recommendations,
            risk_factors=risk_factors,
            expected_benefits={'benchmark_tracking': 0.8, 'liquidity_optimization': 0.9}
        )
        
    def _create_adaptive_strategy(self,
                                order_size: float,
                                market_data: Dict,
                                execution_horizon: timedelta,
                                risk_tolerance: float) -> OptimalExecutionStrategy:
        """
        Adaptive stratejisi oluştur
        
        Args:
            order_size: Order size
            market_data: Market data
            execution_horizon: Execution horizon
            risk_tolerance: Risk tolerance
            
        Returns:
            OptimalExecutionStrategy: Adaptive strategy
        """
        
        # Dynamic participation rate based on market conditions
        volatility = market_data.get('volatility', 0.02)
        volume = market_data.get('volume', 100000)
        
        # Adaptive parameters
        base_participation = 0.06 + (risk_tolerance - 0.5) * 0.04  # 4%-8% range
        
        slice_schedule = []
        participation_rates = []
        
        for i in range(15):  # 15 slices
            # Adaptive adjustment based on volatility and volume
            vol_adjustment = min(2.0, volume / 100000)  # Volume factor
            volatility_adjustment = 1 + volatility  # Volatility factor
            
            current_participation = base_participation * vol_adjustment / volatility_adjustment
            current_participation = min(self.constraints.max_participation_rate, current_participation)
            
            slice_size = order_size / 15
            slice_info = {
                'slice_number': i + 1,
                'quantity': slice_size,
                'target_time': f"Adaptive slice {i + 1}",
                'volatility_adjustment': volatility_adjustment,
                'volume_adjustment': vol_adjustment
            }
            slice_schedule.append(slice_info)
            participation_rates.append(current_participation)
            
        expected_shortfall = order_size * 0.0006 * volatility * (2 - risk_tolerance)  # Lower shortfall with higher risk tolerance
        
        timing_recommendations = [
            "Monitor market conditions continuously",
            "Adjust participation rate based on volatility",
            "Increase execution speed during favorable conditions"
        ]
        
        risk_factors = [
            "Model prediction risk",
            "Market regime change risk",
            "Parameter estimation risk"
        ]
        
        return OptimalExecutionStrategy(
            strategy_name='ADAPTIVE',
            expected_shortfall=expected_shortfall,
            confidence_score=0.8,
            slice_schedule=slice_schedule,
            participation_rates=participation_rates,
            timing_recommendations=timing_recommendations,
            risk_factors=risk_factors,
            expected_benefits={'market_responsiveness': 0.9, 'shortfall_minimization': 0.8}
        )
        
    def _create_risk_averse_strategy(self,
                                   order_size: float,
                                   market_data: Dict,
                                   execution_horizon: timedelta) -> OptimalExecutionStrategy:
        """
        Risk-averse stratejisi oluştur
        
        Args:
            order_size: Order size
            market_data: Market data
            execution_horizon: Execution horizon
            
        Returns:
            OptimalExecutionStrategy: Risk-averse strategy
        """
        
        # Conservative execution with low participation rates
        slice_schedule = []
        participation_rates = []
        
        # More slices with smaller sizes
        slice_count = 40
        slice_size = order_size / slice_count
        
        for i in range(slice_count):
            slice_info = {
                'slice_number': i + 1,
                'quantity': slice_size,
                'target_time': f"Conservative slice {i + 1}",
                'execution_window': '10 minutes'
            }
            slice_schedule.append(slice_info)
            participation_rates.append(0.03)  # 3% participation rate
            
        expected_shortfall = order_size * 0.0005 * market_data.get('volatility', 0.02)  # Low expected shortfall
        
        timing_recommendations = [
            "Execute very slowly to minimize market impact",
            "Use minimum participation rates",
            "Extend execution time if market conditions deteriorate"
        ]
        
        risk_factors = [
            "Opportunity cost risk (high)",
            "Timing risk (low)",
            "Market impact risk (low)"
        ]
        
        return OptimalExecutionStrategy(
            strategy_name='RISK_AVERSE',
            expected_shortfall=expected_shortfall,
            confidence_score=0.9,
            slice_schedule=slice_schedule,
            participation_rates=participation_rates,
            timing_recommendations=timing_recommendations,
            risk_factors=risk_factors,
            expected_benefits={'risk_minimization': 0.95, 'predictability': 0.9}
        )
        
    def _create_aggressive_strategy(self,
                                  order_size: float,
                                  market_data: Dict,
                                  execution_horizon: timedelta,
                                  risk_tolerance: float) -> OptimalExecutionStrategy:
        """
        Aggressive stratejisi oluştur
        
        Args:
            order_size: Order size
            market_data: Market data
            execution_horizon: Execution horizon
            risk_tolerance: Risk tolerance
            
        Returns:
            OptimalExecutionStrategy: Aggressive strategy
        """
        
        # Fast execution with higher participation rates
        slice_schedule = []
        participation_rates = []
        
        # Fewer slices with larger sizes
        slice_count = 8
        slice_size = order_size / slice_count
        
        for i in range(slice_count):
            slice_info = {
                'slice_number': i + 1,
                'quantity': slice_size,
                'target_time': f"Aggressive slice {i + 1}",
                'execution_window': '45 minutes'
            }
            slice_schedule.append(slice_info)
            participation_rates.append(0.15)  # 15% participation rate
            
        expected_shortfall = order_size * 0.0015 * market_data.get('volatility', 0.02)  # Higher expected shortfall
        
        timing_recommendations = [
            "Execute quickly to minimize timing risk",
            "Use higher participation rates",
            "Monitor for execution opportunities"
        ]
        
        risk_factors = [
            "Market impact risk (high)",
            "Timing risk (low)",
            "Opportunity cost risk (low)"
        ]
        
        return OptimalExecutionStrategy(
            strategy_name='AGGRESSIVE',
            expected_shortfall=expected_shortfall,
            confidence_score=0.6,
            slice_schedule=slice_schedule,
            participation_rates=participation_rates,
            timing_recommendations=timing_recommendations,
            risk_factors=risk_factors,
            expected_benefits={'speed': 0.9, 'opportunity_capture': 0.8}
        )
        
    def _select_optimal_strategy(self,
                               strategies: List[OptimalExecutionStrategy],
                               benchmark_info: Dict,
                               market_data: Dict) -> OptimalExecutionStrategy:
        """
        Optimal stratejiyi seç
        
        Args:
            strategies: Candidate strategies
            benchmark_info: Benchmark info
            market_data: Market data
            
        Returns:
            OptimalExecutionStrategy: Selected strategy
        """
        
        # Scoring criteria
        criteria_weights = {
            'shortfall_expectation': 0.4,
            'confidence_score': 0.3,
            'risk_alignment': 0.3
        }
        
        scored_strategies = []
        
        for strategy in strategies:
            # Calculate overall score
            shortfall_score = 1.0 / (1.0 + strategy.expected_shortfall)  # Lower shortfall = higher score
            confidence_score = strategy.confidence_score
            risk_score = self._assess_risk_alignment(strategy, market_data)
            
            overall_score = (criteria_weights['shortfall_expectation'] * shortfall_score +
                           criteria_weights['confidence_score'] * confidence_score +
                           criteria_weights['risk_alignment'] * risk_score)
            
            scored_strategies.append((strategy, overall_score))
            
        # Select strategy with highest score
        best_strategy, best_score = max(scored_strategies, key=lambda x: x[1])
        
        self.logger.info(f"Optimal strategy selected: {best_strategy.strategy_name} (Score: {best_score:.3f})")
        
        return best_strategy
        
    def _assess_risk_alignment(self,
                             strategy: OptimalExecutionStrategy,
                             market_data: Dict) -> float:
        """
        Strategy'nin risk alignment'ını değerlendir
        
        Args:
            strategy: Execution strategy
            market_data: Market data
            
        Returns:
            float: Risk alignment score
        """
        
        volatility = market_data.get('volatility', 0.02)
        
        # High volatility favors conservative strategies
        if volatility > 0.6:
            if strategy.strategy_name == 'RISK_AVERSE':
                return 0.9
            elif strategy.strategy_name == 'ADAPTIVE':
                return 0.8
            else:
                return 0.5
        else:  # Low volatility
            if strategy.strategy_name == 'AGGRESSIVE':
                return 0.8
            elif strategy.strategy_name == 'VWAP':
                return 0.7
            else:
                return 0.6
                
    def _create_implementation_plan(self,
                                  strategy: OptimalExecutionStrategy,
                                  market_data: Dict) -> Dict:
        """
        Implementation plan oluştur
        
        Args:
            strategy: Selected strategy
            market_data: Market data
            
        Returns:
            Dict: Implementation plan
        """
        
        return {
            'strategy_name': strategy.strategy_name,
            'implementation_steps': self._generate_implementation_steps(strategy),
            'monitoring_requirements': self._define_monitoring_requirements(strategy),
            'adjustment_triggers': self._define_adjustment_triggers(strategy),
            'success_metrics': self._define_success_metrics(strategy)
        }
        
    def _generate_implementation_steps(self, strategy: OptimalExecutionStrategy) -> List[str]:
        """
        Implementation steps oluştur
        
        Args:
            strategy: Execution strategy
            
        Returns:
            List[str]: Implementation steps
        """
        
        steps = [
            f"Initialize {strategy.strategy_name} execution algorithm",
            "Set up real-time market data feeds",
            "Configure slice execution parameters",
            "Start monitoring market conditions"
        ]
        
        if strategy.strategy_name == 'ADAPTIVE':
            steps.extend([
                "Enable adaptive parameter adjustment",
                "Set up volatility monitoring"
            ])
        elif strategy.strategy_name == 'VWAP':
            steps.extend([
                "Load volume profile data",
                "Configure volume-based timing"
            ])
            
        return steps
        
    def _define_monitoring_requirements(self, strategy: OptimalExecutionStrategy) -> List[str]:
        """
        Monitoring requirements tanımla
        
        Args:
            strategy: Execution strategy
            
        Returns:
            List[str]: Monitoring requirements
        """
        
        requirements = [
            "Real-time price monitoring",
            "Execution quantity tracking",
            "Market impact assessment",
            "Implementation shortfall calculation"
        ]
        
        if strategy.strategy_name == 'VWAP':
            requirements.append("Volume profile tracking")
        elif strategy.strategy_name == 'ADAPTIVE':
            requirements.append("Volatility and liquidity monitoring")
            
        return requirements
        
    def _define_adjustment_triggers(self, strategy: OptimalExecutionStrategy) -> List[Dict]:
        """
        Adjustment triggers tanımla
        
        Args:
            strategy: Execution strategy
            
        Returns:
            List[Dict]: Adjustment triggers
        """
        
        triggers = [
            {
                'condition': 'High volatility detected',
                'action': 'Reduce participation rate by 20%',
                'threshold': 'volatility > 0.8'
            },
            {
                'condition': 'Low liquidity detected',
                'action': 'Extend execution time by 50%',
                'threshold': 'volume < 50% of average'
            }
        ]
        
        return triggers
        
    def _define_success_metrics(self, strategy: OptimalExecutionStrategy) -> List[str]:
        """
        Success metrics tanımla
        
        Args:
            strategy: Execution strategy
            
        Returns:
            List[str]: Success metrics
        """
        
        metrics = [
            "Implementation shortfall < benchmark",
            "Execution completion within time horizon",
            "Market impact < predefined threshold",
            "Risk metrics within acceptable ranges"
        ]
        
        return metrics
        
    def get_optimization_performance(self) -> Dict:
        """
        Optimization performance'ını getir
        
        Returns:
            Dict: Performance metrics
        """
        
        if not self.optimization_history:
            return {'message': 'Henüz optimization verisi yok'}
            
        recent_optimizations = self.optimization_history[-50:]  # Last 50 optimizations
        
        # Calculate performance metrics
        avg_shortfall = np.mean([opt['expected_shortfall'] for opt in recent_optimizations])
        strategy_distribution = {}
        for opt in recent_optimizations:
            strategy = opt['strategy']
            strategy_distribution[strategy] = strategy_distribution.get(strategy, 0) + 1
            
        return {
            'total_optimizations': len(self.optimization_history),
            'recent_optimizations': len(recent_optimizations),
            'average_expected_shortfall': avg_shortfall,
            'most_used_strategy': max(strategy_distribution.keys(), key=lambda k: strategy_distribution[k]) if strategy_distribution else None,
            'strategy_distribution': strategy_distribution,
            'optimization_frequency': len(recent_optimizations) / max(1, (datetime.now() - pd.to_datetime(recent_optimizations[0]['timestamp'])).days)
        }
        
    def update_performance_data(self,
                              execution_result: pd.DataFrame,
                              benchmark_info: Dict,
                              strategy_used: str) -> None:
        """
        Performance data'sını güncelle
        
        Args:
            execution_result: Actual execution result
            benchmark_info: Benchmark information
            strategy_used: Strategy that was used
        """
        
        # Calculate actual shortfall
        actual_shortfall = self.shortfall_calculator.calculate_implementation_shortfall(
            execution_result, benchmark_info, datetime.now() - timedelta(hours=1)
        )
        
        # Store performance data
        performance_record = {
            'timestamp': datetime.now(),
            'strategy_used': strategy_used,
            'expected_shortfall': None,  # Would be from optimization
            'actual_shortfall': actual_shortfall.total_shortfall,
            'shortfall_percentage': actual_shortfall.total_shortfall_pct,
            'benchmark_type': benchmark_info['type']
        }
        
        symbol = execution_result.iloc[0]['symbol'] if 'symbol' in execution_result.columns else 'UNKNOWN'
        if symbol not in self.performance_data:
            self.performance_data[symbol] = []
        self.performance_data[symbol].append(performance_record)
        
        self.logger.info(f"Performance data updated: {strategy_used}, Actual shortfall: {actual_shortfall.total_shortfall:.4f}")