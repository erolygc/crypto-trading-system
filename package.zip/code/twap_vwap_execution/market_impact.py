"""
Market Impact Prediction Algorithm

Bu modül emirlerin piyasa fiyatına etkisini tahmin eden algoritmaları implement eder.
Temporary ve permanent impact ayrımı, likidite analizi ve Almgren-Chriss modeli kullanılır.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging
from scipy.optimize import minimize
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
import warnings
warnings.filterwarnings('ignore')

@dataclass
class TradeImpact:
    """İşlem etkisi bilgileri"""
    trade_id: str
    timestamp: datetime
    quantity: float
    price: float
    market_price_before: float
    market_price_after: float
    temporary_impact: float
    permanent_impact: float
    spread_cost: float
    total_impact: float

@dataclass
class OrderBookLevel:
    """Order book seviye bilgileri"""
    price: float
    quantity: float
    side: str  # 'BID' or 'ASK'
    order_count: int

@dataclass
class MarketImpactPrediction:
    """Market impact tahmini"""
    predicted_impact: float
    confidence_interval: Tuple[float, float]
    temporary_impact: float
    permanent_impact: float
    execution_advice: str
    risk_level: str  # 'LOW', 'MEDIUM', 'HIGH'

class AlmgrenChrissModel:
    """
    Almgren-Chriss permanent/temporary impact modeli
    """
    
    def __init__(self):
        self.temporary_impact_coefficient = 0.01  # Temporary impact katsayısı
        self.permanent_impact_coefficient = 0.001  # Permanent impact katsayısı
        self.volatility = 0.02  # Günlük volatilite
        self.risk_aversion = 0.0001  # Risk aversion parameter
        
    def calculate_optimal_trajectory(self,
                                   total_quantity: float,
                                   time_horizon: float,
                                   current_price: float,
                                   volatility: float) -> Dict:
        """
        Optimal execution trajectory hesapla (Almgren-Chriss)
        
        Args:
            total_quantity: Toplam miktar
            time_horizon: Zaman ufkı (gün)
            current_price: Mevcut fiyat
            volatility: Volatilite
            
        Returns:
            Dict: Optimal trajectory
        """
        
        # Model parametrelerini ayarla
        self.volatility = volatility
        
        # Optimal slice count hesapla
        eta = self.temporary_impact_coefficient
        gamma = self.permanent_impact_coefficient
        sigma = volatility
        
        # Optimal N hesapla
        optimal_N = int(np.sqrt((eta * total_quantity**2) / (gamma * sigma**2)) + 0.5)
        optimal_N = max(1, min(optimal_N, 100))  # 1-100 arası sınırla
        
        # Optimal slice size
        slice_size = total_quantity / optimal_N
        
        # Time step
        dt = time_horizon / optimal_N
        
        # Expected cost ve risk hesapla
        expected_cost = (gamma * total_quantity**2 / (2 * time_horizon)) + \
                       (eta * total_quantity**2) / (2 * optimal_N)
                      
        expected_risk = (sigma**2 * eta * total_quantity**2) / (2 * gamma * time_horizon)
        
        # Optimal participation rate
        participation_rate = slice_size / (1000000 * dt)  # 1M varsayılan günlük hacim
        
        return {
            'optimal_slice_count': optimal_N,
            'slice_size': slice_size,
            'time_step': dt,
            'expected_cost': expected_cost,
            'expected_risk': expected_risk,
            'expected_total_cost': expected_cost + expected_risk,
            'optimal_participation_rate': participation_rate,
            'recommended_strategy': 'ALMGREN_CHRISS'
        }
        
    def predict_impact(self,
                      order_quantity: float,
                      current_volume: float,
                      volatility: float,
                      spread: float) -> Tuple[float, float]:
        """
        Market impact'i tahmin et
        
        Args:
            order_quantity: Emir miktarı
            current_volume: Mevcut hacim
            volatility: Volatilite
            spread: Spread
            
        Returns:
            Tuple[float, float]: (temporary_impact, permanent_impact)
        """
        
        # Participation rate
        participation_rate = order_quantity / current_volume if current_volume > 0 else 0.5
        
        # Temporary impact (volatilite ve likiditeye bağlı)
        temp_impact = self.temporary_impact_coefficient * participation_rate * volatility
        
        # Permanent impact (miktara bağlı)
        perm_impact = self.permanent_impact_coefficient * participation_rate
        
        # Spread'i de ekle
        total_temp_impact = temp_impact + spread / current_price if 'current_price' in locals() else temp_impact
        
        return (total_temp_impact, perm_impact)
        
    def estimate_execution_cost(self,
                              order_quantity: float,
                              time_horizon: float,
                              current_price: float,
                              current_volume: float,
                              volatility: float,
                              spread: float) -> Dict:
        """
        Execution maliyeti tahmin et
        
        Args:
            order_quantity: Emir miktarı
            time_horizon: Zaman ufkı (gün)
            current_price: Mevcut fiyat
            current_volume: Mevcut hacim
            volatility: Volatilite
            spread: Spread
            
        Returns:
            Dict: Execution cost tahmini
        """
        
        # Optimal trajectory hesapla
        optimal = self.calculate_optimal_trajectory(
            order_quantity, time_horizon, current_price, volatility
        )
        
        # Impact tahminleri
        temp_impact, perm_impact = self.predict_impact(
            order_quantity, current_volume, volatility, spread
        )
        
        # Toplam maliyet
        impact_cost = (temp_impact + perm_impact) * current_price
        spread_cost = spread
        timing_cost = optimal['expected_total_cost'] * current_price
        
        total_cost = impact_cost + spread_cost + timing_cost
        
        return {
            'optimal_slices': optimal['optimal_slice_count'],
            'slice_size': optimal['slice_size'],
            'temp_impact_pct': temp_impact * 100,
            'perm_impact_pct': perm_impact * 100,
            'impact_cost': impact_cost,
            'spread_cost': spread_cost,
            'timing_cost': timing_cost,
            'total_cost': total_cost,
            'cost_per_share': total_cost / order_quantity,
            'execution_time_hours': time_horizon * 24
        }

class LiquidityAnalyzer:
    """Likidite analiz sınıfı"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    def analyze_order_book(self,
                          bid_levels: List[OrderBookLevel],
                          ask_levels: List[OrderBookLevel],
                          market_cap: float) -> Dict:
        """
        Order book likidite analizi
        
        Args:
            bid_levels: Bid seviyeleri
            ask_levels: Ask seviyeleri
            market_cap: Piyasa değeri
            
        Returns:
            Dict: Likidite analiz sonuçları
        """
        
        # Order book depth
        bid_depth = sum(level.quantity for level in bid_levels[:10])  # İlk 10 seviye
        ask_depth = sum(level.quantity for level in ask_levels[:10])
        total_depth = bid_depth + ask_depth
        
        # Weighted average prices
        bid_wap = np.average([level.price for level in bid_levels[:5]],
                            weights=[level.quantity for level in bid_levels[:5]]) if bid_levels else 0
        ask_wap = np.average([level.price for level in ask_levels[:5]],
                            weights=[level.quantity for level in ask_levels[:5]]) if ask_levels else 0
        
        # Spread
        if bid_levels and ask_levels:
            spread = ask_levels[0].price - bid_levels[0].price
            spread_pct = (spread / ((bid_levels[0].price + ask_levels[0].price) / 2)) * 100
        else:
            spread = 0
            spread_pct = 0
            
        # Liquidity ratio
        liquidity_ratio = total_depth / market_cap if market_cap > 0 else 0
        
        # Price levels (5% impact için gerekli miktar)
        mid_price = (bid_levels[0].price + ask_levels[0].price) / 2 if bid_levels and ask_levels else mid_price
        
        # Impact analysis
        impact_1pct = self._estimate_market_impact(bid_levels, ask_levels, mid_price, 0.01)
        impact_5pct = self._estimate_market_impact(bid_levels, ask_levels, mid_price, 0.05)
        
        return {
            'bid_depth': bid_depth,
            'ask_depth': ask_depth,
            'total_depth': total_depth,
            'bid_wap': bid_wap,
            'ask_wap': ask_wap,
            'spread': spread,
            'spread_pct': spread_pct,
            'liquidity_ratio': liquidity_ratio,
            'impact_1pct': impact_1pct,
            'impact_5pct': impact_5pct,
            'liquidity_score': self._calculate_liquidity_score(bid_depth, ask_depth, spread_pct)
        }
        
    def _estimate_market_impact(self,
                              bid_levels: List[OrderBookLevel],
                              ask_levels: List[OrderBookLevel],
                              mid_price: float,
                              price_change_pct: float) -> float:
        """
        Belirli bir fiyat değişimi için gerekli miktarı tahmin et
        
        Args:
            bid_levels: Bid seviyeleri
            ask_levels: Ask seviyeleri
            mid_price: Orta fiyat
            price_change_pct: Fiyat değişimi yüzdesi
            
        Returns:
            float: Gerekli miktar
        """
        
        target_price = mid_price * (1 + price_change_pct)
        required_quantity = 0
        
        # Ask seviyelerinden hedef fiyatı karşılamak için gerekli miktarı hesapla
        for level in ask_levels:
            if level.price <= target_price:
                required_quantity += level.quantity
            else:
                # Kısmi karşılama
                remaining_price_diff = target_price - level.price
                total_price_diff = ask_levels[0].price - level.price if ask_levels else 1
                partial_quantity = level.quantity * (remaining_price_diff / total_price_diff)
                required_quantity += partial_quantity
                break
                
        return required_quantity
        
    def _calculate_liquidity_score(self,
                                  bid_depth: float,
                                  ask_depth: float,
                                  spread_pct: float) -> float:
        """
        Likidite skorunu hesapla (0-1 arası)
        
        Args:
            bid_depth: Bid derinliği
            ask_depth: Ask derinliği
            spread_pct: Spread yüzdesi
            
        Returns:
            float: Likidite skoru
        """
        
        # Depth score (0-1)
        depth_score = min(1.0, (bid_depth + ask_depth) / 100000)  # 100K = 1.0 score
        
        # Spread score (spread düşükse yüksek skor)
        spread_score = max(0, 1 - spread_pct / 0.1)  # 0.1% spread = 0 score
        
        # Weighted average
        liquidity_score = (depth_score * 0.7 + spread_score * 0.3)
        
        return liquidity_score

class MarketImpactPredictor:
    """
    Market Impact Prediction Engine
    
    Multiple models kullanarak market impact'i tahmin eder:
    1. Almgren-Chriss model
    2. Liquidity-based models
    3. Historical pattern analysis
    4. Machine learning models
    """
    
    def __init__(self,
                 almgren_chriss_model: Optional[AlmgrenChrissModel] = None,
                 liquidity_analyzer: Optional[LiquidityAnalyzer] = None):
        """
        Args:
            almgren_chriss_model: Almgren-Chriss model instance
            liquidity_analyzer: Liquidity analyzer instance
        """
        
        self.ac_model = almgren_chriss_model or AlmgrenChrissModel()
        self.liquidity_analyzer = liquidity_analyzer or LiquidityAnalyzer()
        self.logger = logging.getLogger(__name__)
        
        # Historical data storage
        self.trade_impacts: List[TradeImpact] = []
        self.impact_history: pd.DataFrame = pd.DataFrame()
        
        # Machine learning models
        self.ml_model_temporary = None
        self.ml_model_permanent = None
        
        # Performance tracking
        self.prediction_errors: List[float] = []
        
    def predict_market_impact(self,
                            order_quantity: float,
                            symbol: str,
                            order_book_data: Dict,
                            market_data: Dict) -> MarketImpactPrediction:
        """
        Market impact'i tahmin et
        
        Args:
            order_quantity: Emir miktarı
            symbol: Sembol
            order_book_data: Order book verileri
            market_data: Piyasa verileri
            
        Returns:
            MarketImpactPrediction: Impact tahmini
        """
        
        current_price = market_data.get('current_price', 100.0)
        volatility = market_data.get('volatility', 0.02)
        current_volume = market_data.get('volume', 100000)
        spread = market_data.get('spread', 0.01)
        market_cap = market_data.get('market_cap', 1000000000)
        
        # 1. Almgren-Chriss model
        ac_prediction = self._predict_with_almgren_chriss(
            order_quantity, current_price, volatility, current_volume, spread
        )
        
        # 2. Likidite tabanlı model
        liquidity_prediction = self._predict_with_liquidity_analysis(
            order_quantity, order_book_data, market_data
        )
        
        # 3. ML model (eğer eğitilmişse)
        ml_prediction = self._predict_with_ml_model(
            order_quantity, market_data
        )
        
        # 4. Ensemble prediction
        ensemble_prediction = self._combine_predictions(
            ac_prediction, liquidity_prediction, ml_prediction, volatility, current_volume
        )
        
        # Risk level belirleme
        risk_level = self._assess_risk_level(ensemble_prediction, volatility, current_volume)
        
        # Execution advice
        advice = self._generate_execution_advice(
            ensemble_prediction, risk_level, current_volume, spread
        )
        
        result = MarketImpactPrediction(
            predicted_impact=ensemble_prediction['total_impact'],
            confidence_interval=ensemble_prediction['confidence_interval'],
            temporary_impact=ensemble_prediction['temporary_impact'],
            permanent_impact=ensemble_prediction['permanent_impact'],
            execution_advice=advice,
            risk_level=risk_level
        )
        
        self.logger.info(f"Market impact tahmini: {symbol}, Order: {order_quantity:.0f}, "
                        f"Impact: {ensemble_prediction['total_impact']:.4f}, Risk: {risk_level}")
        
        return result
        
    def _predict_with_almgren_chriss(self,
                                   order_quantity: float,
                                   current_price: float,
                                   volatility: float,
                                   current_volume: float,
                                   spread: float) -> Dict:
        """
        Almgren-Chriss ile impact tahmini
        
        Args:
            order_quantity: Emir miktarı
            current_price: Mevcut fiyat
            volatility: Volatilite
            current_volume: Mevcut hacim
            spread: Spread
            
        Returns:
            Dict: Almgren-Chriss tahmini
        """
        
        # Time horizon: 1 gün varsayılan
        time_horizon = 1.0
        
        # Cost estimate
        cost_estimate = self.ac_model.estimate_execution_cost(
            order_quantity, time_horizon, current_price, current_volume, volatility, spread
        )
        
        return {
            'temporary_impact': cost_estimate['temp_impact_pct'] / 100,
            'permanent_impact': cost_estimate['perm_impact_pct'] / 100,
            'total_impact': cost_estimate['impact_cost'] / current_price,
            'confidence': 0.8,  # Model confidence
            'method': 'ALMGREN_CHRISS'
        }
        
    def _predict_with_liquidity_analysis(self,
                                       order_quantity: float,
                                       order_book_data: Dict,
                                       market_data: Dict) -> Dict:
        """
        Likidite analizi ile impact tahmini
        
        Args:
            order_quantity: Emir miktarı
            order_book_data: Order book verileri
            market_data: Piyasa verileri
            
        Returns:
            Dict: Likidite tabanlı tahmin
        """
        
        bid_levels = order_book_data.get('bids', [])
        ask_levels = order_book_data.get('asks', [])
        market_cap = market_data.get('market_cap', 1000000000)
        
        # Likidite analizi
        liquidity_analysis = self.liquidity_analyzer.analyze_order_book(
            bid_levels, ask_levels, market_cap
        )
        
        # Liquidity score'a göre impact tahmini
        liquidity_score = liquidity_analysis['liquidity_score']
        spread_pct = liquidity_analysis['spread_pct']
        
        # High liquidity -> Low impact
        # Low liquidity -> High impact
        impact_multiplier = (2.0 - liquidity_score)  # 1.0-2.0 arası
        
        # Base impact (spread + small buffer)
        base_impact = (spread_pct / 100) * impact_multiplier
        
        # Order size impact
        size_ratio = order_quantity / liquidity_analysis['total_depth'] if liquidity_analysis['total_depth'] > 0 else 0
        size_impact = size_ratio * 0.5  # Size factor
        
        # Total impact
        total_impact = base_impact + size_impact
        
        # Temporary vs Permanent split
        temp_impact = total_impact * 0.7  # 70% temporary
        perm_impact = total_impact * 0.3  # 30% permanent
        
        return {
            'temporary_impact': temp_impact,
            'permanent_impact': perm_impact,
            'total_impact': total_impact,
            'confidence': liquidity_score,  # Liquidity score as confidence
            'method': 'LIQUIDITY_ANALYSIS',
            'liquidity_score': liquidity_score
        }
        
    def _predict_with_ml_model(self,
                             order_quantity: float,
                             market_data: Dict) -> Dict:
        """
        ML model ile impact tahmini
        
        Args:
            order_quantity: Emir miktarı
            market_data: Piyasa verileri
            
        Returns:
            Dict: ML model tahmini
        """
        
        if self.ml_model_temporary is None or self.ml_model_permanent is None:
            # Model eğitilmemişse basit heuristics kullan
            return self._heuristic_prediction(order_quantity, market_data)
            
        # Feature vector oluştur
        features = self._create_feature_vector(order_quantity, market_data)
        
        # Prediction
        temp_pred = self.ml_model_temporary.predict([features])[0]
        perm_pred = self.ml_model_permanent.predict([features])[0]
        
        total_impact = temp_pred + perm_pred
        
        return {
            'temporary_impact': max(0, temp_pred),
            'permanent_impact': max(0, perm_pred),
            'total_impact': max(0, total_impact),
            'confidence': 0.7,
            'method': 'ML_MODEL'
        }
        
    def _heuristic_prediction(self,
                            order_quantity: float,
                            market_data: Dict) -> Dict:
        """
        Basit heuristic impact tahmini
        
        Args:
            order_quantity: Emir miktarı
            market_data: Piyasa verileri
            
        Returns:
            Dict: Heuristic tahmin
        """
        
        volatility = market_data.get('volatility', 0.02)
        spread_pct = market_data.get('spread', 0.01)
        
        # Base impact from volatility and spread
        base_impact = volatility + (spread_pct / 100)
        
        # Order size factor
        volume = market_data.get('volume', 100000)
        size_factor = min(2.0, order_quantity / volume)
        
        total_impact = base_impact * (1 + size_factor * 0.5)
        
        return {
            'temporary_impact': total_impact * 0.6,
            'permanent_impact': total_impact * 0.4,
            'total_impact': total_impact,
            'confidence': 0.5,
            'method': 'HEURISTIC'
        }
        
    def _create_feature_vector(self,
                             order_quantity: float,
                             market_data: Dict) -> List[float]:
        """
        ML model için feature vector oluştur
        
        Args:
            order_quantity: Emir miktarı
            market_data: Piyasa verileri
            
        Returns:
            List[float]: Feature vector
        """
        
        return [
            order_quantity,
            market_data.get('volatility', 0.02),
            market_data.get('spread', 0.01),
            market_data.get('volume', 100000),
            market_data.get('current_price', 100.0),
            order_quantity / market_data.get('volume', 100000),  # Size ratio
            np.log(order_quantity + 1),  # Log order size
        ]
        
    def _combine_predictions(self,
                           ac_pred: Dict,
                           liquidity_pred: Dict,
                           ml_pred: Dict,
                           volatility: float,
                           current_volume: float) -> Dict:
        """
        Multiple predictions'ları birleştir
        
        Args:
            ac_pred: Almgren-Chriss prediction
            liquidity_pred: Liquidity prediction
            ml_pred: ML prediction
            volatility: Volatilite
            current_volume: Mevcut hacim
            
        Returns:
            Dict: Combined prediction
        """
        
        # Weight'leri belirle
        weights = self._calculate_model_weights(volatility, current_volume)
        
        # Weighted average
        total_impact = (weights['ac'] * ac_pred['total_impact'] +
                       weights['liquidity'] * liquidity_pred['total_impact'] +
                       weights['ml'] * ml_pred['total_impact'])
        
        temp_impact = (weights['ac'] * ac_pred['temporary_impact'] +
                      weights['liquidity'] * liquidity_pred['temporary_impact'] +
                      weights['ml'] * ml_pred['temporary_impact'])
        
        perm_impact = (weights['ac'] * ac_pred['permanent_impact'] +
                      weights['liquidity'] * liquidity_pred['permanent_impact'] +
                      weights['ml'] * ml_pred['permanent_impact'])
        
        # Confidence interval
        predictions = [ac_pred['total_impact'], liquidity_pred['total_impact'], ml_pred['total_impact']]
        std_dev = np.std(predictions)
        confidence_interval = (total_impact - 1.96 * std_dev, total_impact + 1.96 * std_dev)
        
        return {
            'total_impact': max(0, total_impact),
            'temporary_impact': max(0, temp_impact),
            'permanent_impact': max(0, perm_impact),
            'confidence_interval': confidence_interval,
            'model_weights': weights
        }
        
    def _calculate_model_weights(self,
                               volatility: float,
                               current_volume: float) -> Dict[str, float]:
        """
        Model ağırlıklarını hesapla
        
        Args:
            volatility: Volatilite
            current_volume: Mevcut hacim
            
        Returns:
            Dict[str, float]: Model weights
        """
        
        # Volatility'ye göre ağırlıklar
        if volatility > 0.8:  # Yüksek volatilite
            # ML model daha iyi performans gösterir
            return {'ac': 0.3, 'liquidity': 0.3, 'ml': 0.4}
        elif volatility < 0.3:  # Düşük volatilite
            # Almgren-Chriss daha güvenilir
            return {'ac': 0.5, 'liquidity': 0.3, 'ml': 0.2}
        else:  # Orta volatilite
            return {'ac': 0.4, 'liquidity': 0.3, 'ml': 0.3}
            
    def _assess_risk_level(self,
                          prediction: Dict,
                          volatility: float,
                          current_volume: float) -> str:
        """
        Risk seviyesini değerlendir
        
        Args:
            prediction: Impact tahmini
            volatility: Volatilite
            current_volume: Mevcut hacim
            
        Returns:
            str: Risk level
        """
        
        impact_pct = prediction['total_impact'] * 100
        
        # Risk factors
        high_impact = impact_pct > 0.5
        high_volatility = volatility > 0.6
        low_volume = current_volume < 50000
        
        risk_score = sum([high_impact, high_volatility, low_volume])
        
        if risk_score >= 2:
            return 'HIGH'
        elif risk_score >= 1:
            return 'MEDIUM'
        else:
            return 'LOW'
            
    def _generate_execution_advice(self,
                                 prediction: Dict,
                                 risk_level: str,
                                 current_volume: float,
                                 spread: float) -> str:
        """
        Execution advice oluştur
        
        Args:
            prediction: Impact tahmini
            risk_level: Risk seviyesi
            current_volume: Mevcut hacim
            spread: Spread
            
        Returns:
            str: Execution advice
        """
        
        if risk_level == 'HIGH':
            return ("Yüksek risk: Slice boyutlarını küçült, execution'ı uzat, "
                   "alternatif execution venue'ları değerlendir")
        elif risk_level == 'MEDIUM':
            return ("Orta risk: Moderate slice boyutları kullan, piyasa saatlerinde execute et")
        else:
            return ("Düşük risk: Normal execution stratejisi kullan, optimal zamanlamaya odaklan")
            
    def train_ml_models(self, training_data: pd.DataFrame) -> None:
        """
        ML model'leri eğit
        
        Args:
            training_data: Eğitim verisi
        """
        
        if training_data.empty:
            self.logger.warning("Eğitim verisi boş, ML model eğitilemez")
            return
            
        # Feature columns
        feature_cols = ['order_size', 'volatility', 'spread', 'volume', 'price', 'size_ratio']
        
        if not all(col in training_data.columns for col in feature_cols):
            self.logger.warning("Eksik feature columns")
            return
            
        X = training_data[feature_cols]
        y_temp = training_data['temp_impact']
        y_perm = training_data['perm_impact']
        
        # Model training
        self.ml_model_temporary = RandomForestRegressor(n_estimators=100, random_state=42)
        self.ml_model_permanent = RandomForestRegressor(n_estimators=100, random_state=42)
        
        self.ml_model_temporary.fit(X, y_temp)
        self.ml_model_permanent.fit(X, y_perm)
        
        self.logger.info("ML modelleri eğitildi")
        
    def update_with_execution_data(self, trade_impact: TradeImpact) -> None:
        """
        Execution data'sını güncelle
        
        Args:
            trade_impact: Trade impact bilgileri
        """
        
        self.trade_impacts.append(trade_impact)
        
        # DataFrame'e ekle
        new_row = pd.DataFrame({
            'timestamp': [trade_impact.timestamp],
            'quantity': [trade_impact.quantity],
            'price': [trade_impact.price],
            'market_price_before': [trade_impact.market_price_before],
            'market_price_after': [trade_impact.market_price_after],
            'temp_impact': [trade_impact.temporary_impact],
            'perm_impact': [trade_impact.permanent_impact],
            'total_impact': [trade_impact.total_impact]
        })
        
        if self.impact_history.empty:
            self.impact_history = new_row
        else:
            self.impact_history = pd.concat([self.impact_history, new_row], ignore_index=True)
            
        self.logger.debug(f"Execution data güncellendi: {trade_impact.trade_id}")
        
    def get_impact_statistics(self) -> Dict:
        """
        Impact istatistiklerini getir
        
        Returns:
            Dict: Impact statistics
        """
        
        if self.impact_history.empty:
            return {'message': 'Henüz impact verisi yok'}
            
        stats = {
            'total_trades': len(self.impact_history),
            'avg_temp_impact': self.impact_history['temp_impact'].mean(),
            'avg_perm_impact': self.impact_history['perm_impact'].mean(),
            'avg_total_impact': self.impact_history['total_impact'].mean(),
            'max_impact': self.impact_history['total_impact'].max(),
            'min_impact': self.impact_history['total_impact'].min(),
            'impact_std': self.impact_history['total_impact'].std()
        }
        
        return stats