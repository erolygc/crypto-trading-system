"""
Real-Time Execution Monitoring

Bu modül TWAP/VWAP execution'ını real-time izleyen ve kontrol eden sistemi implement eder.
Performance tracking, alert system ve adaptive control sağlar.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Callable, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging
from collections import defaultdict, deque
from enum import Enum
import json
import threading
import time
from concurrent.futures import ThreadPoolExecutor
import warnings
warnings.filterwarnings('ignore')

class ExecutionStatus(Enum):
    """Execution durum türleri"""
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    PAUSED = "PAUSED"
    COMPLETED = "COMPLETED"
    CANCELLED = "CANCELLED"
    FAILED = "FAILED"
    THRESHOLD_BREACH = "THRESHOLD_BREACH"

class AlertLevel(Enum):
    """Alert seviyeleri"""
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

@dataclass
class ExecutionMetrics:
    """Real-time execution metrikleri"""
    order_id: str
    symbol: str
    total_quantity: float
    executed_quantity: float
    remaining_quantity: float
    execution_progress: float  # 0-1
    average_execution_price: float
    current_market_price: float
    benchmark_price: float
    implementation_shortfall: float
    expected_completion_time: datetime
    execution_rate: float  # Quantity per minute
    slice_execution_rate: float
    status: ExecutionStatus
    timestamp: datetime

@dataclass
class Alert:
    """Alert bilgileri"""
    alert_id: str
    level: AlertLevel
    message: str
    order_id: str
    metric_name: str
    current_value: float
    threshold_value: float
    timestamp: datetime
    acknowledged: bool = False
    resolved: bool = False

@dataclass
class ControlAction:
    """Kontrol aksiyonu"""
    action_id: str
    order_id: str
    action_type: str  # 'PAUSE', 'RESUME', 'ADJUST_SLICE', 'CANCEL'
    parameters: Dict[str, Any]
    timestamp: datetime
    executed: bool = False
    success: bool = False

class ThresholdManager:
    """Threshold yönetim sınıfı"""
    
    def __init__(self):
        self.thresholds = {
            'implementation_shortfall': {
                'warning': 0.02,  # 2%
                'critical': 0.05   # 5%
            },
            'execution_progress': {
                'min_rate': 0.1,   # 10% per hour minimum
                'max_stagnation': 0.05  # 5% stagnation threshold
            },
            'price_deviation': {
                'warning': 0.015,  # 1.5%
                'critical': 0.03   # 3%
            },
            'execution_rate': {
                'min_rate': 0.05,   # Minimum execution rate
                'max_rate': 0.5     # Maximum execution rate
            },
            'slice_completion': {
                'timeout': 30       # 30 minutes slice timeout
            }
        }
        
    def check_thresholds(self, metrics: ExecutionMetrics) -> List[Alert]:
        """
        Threshold kontrolleri yap
        
        Args:
            metrics: Current execution metrics
            
        Returns:
            List[Alert]: Generated alerts
        """
        
        alerts = []
        
        # Implementation shortfall check
        if metrics.implementation_shortfall > self.thresholds['implementation_shortfall']['critical']:
            alerts.append(Alert(
                alert_id=f"SF_CRITICAL_{metrics.order_id}_{int(time.time())}",
                level=AlertLevel.CRITICAL,
                message=f"Critical implementation shortfall: {metrics.implementation_shortfall:.2%}",
                order_id=metrics.order_id,
                metric_name="implementation_shortfall",
                current_value=metrics.implementation_shortfall,
                threshold_value=self.thresholds['implementation_shortfall']['critical'],
                timestamp=datetime.now()
            ))
        elif metrics.implementation_shortfall > self.thresholds['implementation_shortfall']['warning']:
            alerts.append(Alert(
                alert_id=f"SF_WARNING_{metrics.order_id}_{int(time.time())}",
                level=AlertLevel.WARNING,
                message=f"Implementation shortfall exceeded: {metrics.implementation_shortfall:.2%}",
                order_id=metrics.order_id,
                metric_name="implementation_shortfall",
                current_value=metrics.implementation_shortfall,
                threshold_value=self.thresholds['implementation_shortfall']['warning'],
                timestamp=datetime.now()
            ))
            
        # Execution progress check
        expected_progress = self._calculate_expected_progress(metrics)
        if metrics.execution_progress < expected_progress * 0.8:  # 20% behind schedule
            alerts.append(Alert(
                alert_id=f"PROGRESS_SLOW_{metrics.order_id}_{int(time.time())}",
                level=AlertLevel.WARNING,
                message=f"Execution progress behind schedule: {metrics.execution_progress:.1%} vs {expected_progress:.1%}",
                order_id=metrics.order_id,
                metric_name="execution_progress",
                current_value=metrics.execution_progress,
                threshold_value=expected_progress * 0.8,
                timestamp=datetime.now()
            ))
            
        # Price deviation check
        price_deviation = abs(metrics.average_execution_price - metrics.current_market_price) / metrics.current_market_price
        if price_deviation > self.thresholds['price_deviation']['critical']:
            alerts.append(Alert(
                alert_id=f"PRICE_CRITICAL_{metrics.order_id}_{int(time.time())}",
                level=AlertLevel.CRITICAL,
                message=f"Critical price deviation: {price_deviation:.2%}",
                order_id=metrics.order_id,
                metric_name="price_deviation",
                current_value=price_deviation,
                threshold_value=self.thresholds['price_deviation']['critical'],
                timestamp=datetime.now()
            ))
        elif price_deviation > self.thresholds['price_deviation']['warning']:
            alerts.append(Alert(
                alert_id=f"PRICE_WARNING_{metrics.order_id}_{int(time.time())}",
                level=AlertLevel.WARNING,
                message=f"Price deviation exceeded: {price_deviation:.2%}",
                order_id=metrics.order_id,
                metric_name="price_deviation",
                current_value=price_deviation,
                threshold_value=self.thresholds['price_deviation']['warning'],
                timestamp=datetime.now()
            ))
            
        return alerts
        
    def _calculate_expected_progress(self, metrics: ExecutionMetrics) -> float:
        """
        Beklenen execution progress'i hesapla
        
        Args:
            metrics: Current metrics
            
        Returns:
            float: Expected progress (0-1)
        """
        
        if metrics.expected_completion_time <= datetime.now():
            return 1.0
            
        total_time = (metrics.expected_completion_time - (metrics.expected_completion_time - timedelta(hours=1))).total_seconds()
        elapsed_time = (datetime.now() - (metrics.expected_completion_time - timedelta(hours=1))).total_seconds()
        
        return min(1.0, elapsed_time / total_time)

class PerformanceTracker:
    """Performance tracking sınıfı"""
    
    def __init__(self, window_size: int = 100):
        """
        Args:
            window_size: Performance tracking window size
        """
        
        self.window_size = window_size
        self.logger = logging.getLogger(__name__)
        
        # Performance history
        self.performance_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=window_size))
        self.metrics_history: Dict[str, List[ExecutionMetrics]] = defaultdict(list)
        
    def update_performance(self, metrics: ExecutionMetrics) -> None:
        """
        Performance'i güncelle
        
        Args:
            metrics: Current execution metrics
        """
        
        # Update metrics history
        self.metrics_history[metrics.order_id].append(metrics)
        
        # Calculate performance indicators
        performance_indicators = self._calculate_performance_indicators(metrics)
        
        # Store performance data
        self.performance_history[metrics.order_id].append(performance_indicators)
        
        self.logger.debug(f"Performance updated for order {metrics.order_id}")
        
    def _calculate_performance_indicators(self, metrics: ExecutionMetrics) -> Dict[str, float]:
        """
        Performance indicator'larını hesapla
        
        Args:
            metrics: Current metrics
            
        Returns:
            Dict[str, float]: Performance indicators
        """
        
        indicators = {
            'execution_efficiency': metrics.execution_progress / max(1, (datetime.now() - (metrics.expected_completion_time - timedelta(hours=1))).total_seconds() / 3600),
            'shortfall_performance': -metrics.implementation_shortfall,  # Negative shortfall is good
            'price_quality': 1 - abs(metrics.average_execution_price - metrics.benchmark_price) / metrics.benchmark_price,
            'completion_rate': metrics.executed_quantity / metrics.total_quantity
        }
        
        return indicators
        
    def get_performance_summary(self, order_id: str) -> Dict:
        """
        Performance özetini getir
        
        Args:
            order_id: Order ID
            
        Returns:
            Dict: Performance summary
        """
        
        if order_id not in self.performance_history:
            return {'message': f'Order {order_id} için performance verisi yok'}
            
        recent_metrics = list(self.metrics_history[order_id])[-10:]  # Last 10 metrics
        recent_indicators = list(self.performance_history[order_id])[-10:]
        
        if not recent_indicators:
            return {'message': 'Yeterli performance verisi yok'}
            
        # Calculate averages
        avg_efficiency = np.mean([ind['execution_efficiency'] for ind in recent_indicators])
        avg_shortfall_performance = np.mean([ind['shortfall_performance'] for ind in recent_indicators])
        avg_price_quality = np.mean([ind['price_quality'] for ind in recent_indicators])
        avg_completion_rate = np.mean([ind['completion_rate'] for ind in recent_indicators])
        
        # Calculate trends
        efficiency_trend = self._calculate_trend([ind['execution_efficiency'] for ind in recent_indicators])
        shortfall_trend = self._calculate_trend([ind['shortfall_performance'] for ind in recent_indicators])
        
        return {
            'order_id': order_id,
            'avg_execution_efficiency': avg_efficiency,
            'avg_shortfall_performance': avg_shortfall_performance,
            'avg_price_quality': avg_price_quality,
            'avg_completion_rate': avg_completion_rate,
            'efficiency_trend': efficiency_trend,
            'shortfall_trend': shortfall_trend,
            'latest_metrics': recent_metrics[-1].__dict__ if recent_metrics else {},
            'data_points': len(recent_indicators)
        }
        
    def _calculate_trend(self, values: List[float]) -> str:
        """
        Trend hesapla
        
        Args:
            values: Value sequence
            
        Returns:
            str: Trend direction ('IMPROVING', 'STABLE', 'DECLINING')
        """
        
        if len(values) < 3:
            return 'STABLE'
            
        # Simple trend calculation using linear regression slope
        x = np.arange(len(values))
        slope = np.polyfit(x, values, 1)[0]
        
        if slope > 0.01:
            return 'IMPROVING'
        elif slope < -0.01:
            return 'DECLINING'
        else:
            return 'STABLE'

class AdaptiveController:
    """Adaptive control sınıfı"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
        # Control parameters
        self.control_rules = {
            'shortfall_adjustment': {
                'threshold': 0.03,  # 3%
                'action': 'reduce_participation_rate',
                'adjustment_factor': 0.8
            },
            'progress_adjustment': {
                'threshold': 0.2,  # 20% behind
                'action': 'increase_participation_rate',
                'adjustment_factor': 1.2
            },
            'volatility_adjustment': {
                'threshold': 0.8,  # High volatility
                'action': 'reduce_slice_size',
                'adjustment_factor': 0.7
            }
        }
        
    def generate_control_actions(self,
                               metrics: ExecutionMetrics,
                               alerts: List[Alert],
                               market_conditions: Dict) -> List[ControlAction]:
        """
        Kontrol aksiyonları oluştur
        
        Args:
            metrics: Current metrics
            alerts: Current alerts
            market_conditions: Market conditions
            
        Returns:
            List[ControlAction]: Control actions to execute
        """
        
        actions = []
        
        # Process alerts for control actions
        for alert in alerts:
            if alert.level in [AlertLevel.WARNING, AlertLevel.CRITICAL]:
                action = self._generate_action_from_alert(alert, metrics)
                if action:
                    actions.append(action)
                    
        # Generate proactive adjustments based on performance
        proactive_actions = self._generate_proactive_adjustments(metrics, market_conditions)
        actions.extend(proactive_actions)
        
        return actions
        
    def _generate_action_from_alert(self, alert: Alert, metrics: ExecutionMetrics) -> Optional[ControlAction]:
        """
        Alert'ten aksiyon oluştur
        
        Args:
            alert: Alert information
            metrics: Current metrics
            
        Returns:
            Optional[ControlAction]: Generated action
        """
        
        action_type = None
        parameters = {}
        
        if alert.metric_name == 'implementation_shortfall':
            action_type = 'ADJUST_PARTICIPATION_RATE'
            current_rate = getattr(metrics, 'current_participation_rate', 0.1)  # Default 10%
            new_rate = max(0.01, current_rate * 0.8)  # Reduce by 20%
            parameters = {'new_participation_rate': new_rate}
            
        elif alert.metric_name == 'execution_progress':
            action_type = 'INCREASE_EXECUTION_SPEED'
            parameters = {'speed_multiplier': 1.5}
            
        elif alert.metric_name == 'price_deviation':
            action_type = 'PAUSE_EXECUTION'
            parameters = {'pause_duration_minutes': 15}
            
        if action_type:
            return ControlAction(
                action_id=f"ACTION_{alert.order_id}_{int(time.time())}",
                order_id=alert.order_id,
                action_type=action_type,
                parameters=parameters,
                timestamp=datetime.now()
            )
            
        return None
        
    def _generate_proactive_adjustments(self,
                                      metrics: ExecutionMetrics,
                                      market_conditions: Dict) -> List[ControlAction]:
        """
        Proaktif ayarlamalar oluştur
        
        Args:
            metrics: Current metrics
            market_conditions: Market conditions
            
        Returns:
            List[ControlAction]: Proactive actions
        """
        
        actions = []
        
        # Check for high volatility
        volatility = market_conditions.get('volatility', 0.02)
        if volatility > self.control_rules['volatility_adjustment']['threshold']:
            action = ControlAction(
                action_id=f"PROACTIVE_VOL_{metrics.order_id}_{int(time.time())}",
                order_id=metrics.order_id,
                action_type='ADJUST_SLICE_SIZE',
                parameters={'size_multiplier': self.control_rules['volatility_adjustment']['adjustment_factor']},
                timestamp=datetime.now()
            )
            actions.append(action)
            
        # Check for execution stagnation
        if metrics.execution_rate < 0.05:  # Low execution rate
            action = ControlAction(
                action_id=f"PROACTIVE_RATE_{metrics.order_id}_{int(time.time())}",
                order_id=metrics.order_id,
                action_type='ACCELERATE_EXECUTION',
                parameters={'acceleration_factor': 1.3},
                timestamp=datetime.now()
            )
            actions.append(action)
            
        return actions

class ExecutionMonitor:
    """
    Real-Time Execution Monitoring Engine
    
    TWAP/VWAP execution'ını real-time izler ve kontrol eder.
    """
    
    def __init__(self,
                 threshold_manager: Optional[ThresholdManager] = None,
                 performance_tracker: Optional[PerformanceTracker] = None,
                 adaptive_controller: Optional[AdaptiveController] = None):
        """
        Args:
            threshold_manager: Threshold manager
            performance_tracker: Performance tracker
            adaptive_controller: Adaptive controller
        """
        
        self.threshold_manager = threshold_manager or ThresholdManager()
        self.performance_tracker = performance_tracker or PerformanceTracker()
        self.adaptive_controller = adaptive_controller or AdaptiveController()
        self.logger = logging.getLogger(__name__)
        
        # Monitoring state
        self.active_orders: Dict[str, ExecutionMetrics] = {}
        self.alerts: List[Alert] = []
        self.control_actions: List[ControlAction] = []
        self.monitoring_active = False
        
        # Threading
        self.monitor_thread = None
        self.stop_event = threading.Event()
        
        # Callbacks
        self.alert_callbacks: List[Callable] = []
        self.control_callbacks: List[Callable] = []
        
    def start_monitoring(self, update_interval_seconds: int = 30) -> None:
        """
        Monitoring'i başlat
        
        Args:
            update_interval_seconds: Update interval in seconds
        """
        
        if self.monitoring_active:
            self.logger.warning("Monitoring zaten aktif")
            return
            
        self.monitoring_active = True
        self.stop_event.clear()
        
        # Start monitoring thread
        self.monitor_thread = threading.Thread(
            target=self._monitoring_loop,
            args=(update_interval_seconds,),
            daemon=True
        )
        self.monitor_thread.start()
        
        self.logger.info(f"Real-time monitoring başlatıldı (interval: {update_interval_seconds}s)")
        
    def stop_monitoring(self) -> None:
        """Monitoring'i durdur"""
        
        if not self.monitoring_active:
            return
            
        self.monitoring_active = False
        self.stop_event.set()
        
        if self.monitor_thread and self.monitor_thread.is_alive():
            self.monitor_thread.join(timeout=5)
            
        self.logger.info("Real-time monitoring durduruldu")
        
    def register_order(self,
                      order_id: str,
                      symbol: str,
                      total_quantity: float,
                      benchmark_price: float,
                      expected_completion_time: datetime,
                      **kwargs) -> None:
        """
        Order'ı monitoring'e kaydet
        
        Args:
            order_id: Order ID
            symbol: Sembol
            total_quantity: Toplam miktar
            benchmark_price: Benchmark fiyat
            expected_completion_time: Beklenen tamamlanma zamanı
            **kwargs: Ek parametreler
        """
        
        # Create initial metrics
        initial_metrics = ExecutionMetrics(
            order_id=order_id,
            symbol=symbol,
            total_quantity=total_quantity,
            executed_quantity=0.0,
            remaining_quantity=total_quantity,
            execution_progress=0.0,
            average_execution_price=0.0,
            current_market_price=kwargs.get('current_market_price', benchmark_price),
            benchmark_price=benchmark_price,
            implementation_shortfall=0.0,
            expected_completion_time=expected_completion_time,
            execution_rate=0.0,
            slice_execution_rate=0.0,
            status=ExecutionStatus.PENDING,
            timestamp=datetime.now()
        )
        
        self.active_orders[order_id] = initial_metrics
        
        self.logger.info(f"Order monitoring'e kaydedildi: {order_id}, Symbol: {symbol}")
        
    def update_order_metrics(self,
                           order_id: str,
                           executed_quantity: float,
                           average_execution_price: float,
                           current_market_price: float,
                           **kwargs) -> None:
        """
        Order metriklerini güncelle
        
        Args:
            order_id: Order ID
            executed_quantity: Execute edilen miktar
            average_execution_price: Ortalama execution fiyatı
            current_market_price: Mevcut piyasa fiyatı
            **kwargs: Ek metrikler
        """
        
        if order_id not in self.active_orders:
            self.logger.warning(f"Order bulunamadı: {order_id}")
            return
            
        metrics = self.active_orders[order_id]
        
        # Update metrics
        metrics.executed_quantity = executed_quantity
        metrics.remaining_quantity = metrics.total_quantity - executed_quantity
        metrics.execution_progress = executed_quantity / metrics.total_quantity
        metrics.average_execution_price = average_execution_price
        metrics.current_market_price = current_market_price
        metrics.timestamp = datetime.now()
        
        # Calculate implementation shortfall
        metrics.implementation_shortfall = (average_execution_price - metrics.benchmark_price) / metrics.benchmark_price
        
        # Calculate execution rate
        if hasattr(metrics, 'last_update_time'):
            time_diff = (metrics.timestamp - metrics.last_update_time).total_seconds() / 60  # minutes
            quantity_diff = executed_quantity - getattr(metrics, 'last_executed_quantity', 0)
            if time_diff > 0:
                metrics.execution_rate = quantity_diff / time_diff
                
        metrics.last_update_time = metrics.timestamp
        metrics.last_executed_quantity = executed_quantity
        
        # Update status
        if metrics.execution_progress >= 1.0:
            metrics.status = ExecutionStatus.COMPLETED
        elif metrics.execution_progress > 0:
            metrics.status = ExecutionStatus.RUNNING
            
        # Update performance tracking
        self.performance_tracker.update_performance(metrics)
        
        self.logger.debug(f"Order metrics güncellendi: {order_id}, Progress: {metrics.execution_progress:.1%}")
        
    def _monitoring_loop(self, update_interval_seconds: int) -> None:
        """
        Ana monitoring loop
        
        Args:
            update_interval_seconds: Update interval
        """
        
        while self.monitoring_active and not self.stop_event.is_set():
            try:
                # Process all active orders
                for order_id in list(self.active_orders.keys()):
                    if self.stop_event.is_set():
                        break
                        
                    metrics = self.active_orders[order_id]
                    
                    # Check thresholds
                    alerts = self.threshold_manager.check_thresholds(metrics)
                    
                    # Generate control actions
                    market_conditions = {'volatility': 0.02}  # Simplified market conditions
                    actions = self.adaptive_controller.generate_control_actions(
                        metrics, alerts, market_conditions
                    )
                    
                    # Process alerts
                    for alert in alerts:
                        self._process_alert(alert)
                        
                    # Process control actions
                    for action in actions:
                        self._process_control_action(action)
                        
                # Wait for next update
                self.stop_event.wait(update_interval_seconds)
                
            except Exception as e:
                self.logger.error(f"Monitoring loop error: {e}")
                time.sleep(5)  # Wait before retrying
                
    def _process_alert(self, alert: Alert) -> None:
        """
        Alert'i işle
        
        Args:
            alert: Alert to process
        """
        
        self.alerts.append(alert)
        
        # Call alert callbacks
        for callback in self.alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                self.logger.error(f"Alert callback error: {e}")
                
        self.logger.warning(f"Alert oluşturuldu: {alert.level.value} - {alert.message}")
        
    def _process_control_action(self, action: ControlAction) -> None:
        """
        Kontrol aksiyonunu işle
        
        Args:
            action: Control action to process
        """
        
        self.control_actions.append(action)
        
        # Call control callbacks
        for callback in self.control_callbacks:
            try:
                callback(action)
            except Exception as e:
                self.logger.error(f"Control callback error: {e}")
                
        self.logger.info(f"Kontrol aksiyonu oluşturuldu: {action.action_type} for order {action.order_id}")
        
    def add_alert_callback(self, callback: Callable[[Alert], None]) -> None:
        """
        Alert callback ekle
        
        Args:
            callback: Alert callback function
        """
        
        self.alert_callbacks.append(callback)
        
    def add_control_callback(self, callback: Callable[[ControlAction], None]) -> None:
        """
        Control callback ekle
        
        Args:
            callback: Control callback function
        """
        
        self.control_callbacks.append(callback)
        
    def get_monitoring_status(self) -> Dict:
        """
        Monitoring status'unu getir
        
        Returns:
            Dict: Monitoring status
        """
        
        active_count = len([m for m in self.active_orders.values() if m.status in [ExecutionStatus.RUNNING, ExecutionStatus.PENDING]])
        completed_count = len([m for m in self.active_orders.values() if m.status == ExecutionStatus.COMPLETED])
        
        # Recent alerts (last 24 hours)
        cutoff_time = datetime.now() - timedelta(hours=24)
        recent_alerts = [a for a in self.alerts if a.timestamp >= cutoff_time]
        
        # Critical alerts
        critical_alerts = [a for a in recent_alerts if a.level == AlertLevel.CRITICAL]
        
        return {
            'monitoring_active': self.monitoring_active,
            'total_orders': len(self.active_orders),
            'active_orders': active_count,
            'completed_orders': completed_count,
            'recent_alerts_24h': len(recent_alerts),
            'critical_alerts': len(critical_alerts),
            'pending_control_actions': len([a for a in self.control_actions if not a.executed]),
            'uptime': datetime.now().isoformat() if self.monitoring_active else None
        }
        
    def get_order_status(self, order_id: str) -> Optional[Dict]:
        """
        Order status'unu getir
        
        Args:
            order_id: Order ID
            
        Returns:
            Optional[Dict]: Order status
        """
        
        if order_id not in self.active_orders:
            return None
            
        metrics = self.active_orders[order_id]
        performance_summary = self.performance_tracker.get_performance_summary(order_id)
        
        return {
            'metrics': metrics.__dict__,
            'performance': performance_summary,
            'alerts': [a.__dict__ for a in self.alerts if a.order_id == order_id][-5:],  # Last 5 alerts
            'control_actions': [a.__dict__ for a in self.control_actions if a.order_id == order_id][-3:]  # Last 3 actions
        }
        
    def get_alerts_summary(self, level_filter: Optional[AlertLevel] = None) -> Dict:
        """
        Alerts özetini getir
        
        Args:
            level_filter: Filter by alert level
            
        Returns:
            Dict: Alerts summary
        """
        
        filtered_alerts = self.alerts
        if level_filter:
            filtered_alerts = [a for a in self.alerts if a.level == level_filter]
            
        # Summary by level
        level_counts = {}
        for alert in filtered_alerts:
            level = alert.level.value
            level_counts[level] = level_counts.get(level, 0) + 1
            
        # Recent alerts (last 100)
        recent_alerts = sorted(filtered_alerts, key=lambda x: x.timestamp, reverse=True)[:100]
        
        return {
            'total_alerts': len(filtered_alerts),
            'alerts_by_level': level_counts,
            'recent_alerts': [a.__dict__ for a in recent_alerts],
            'unacknowledged_alerts': len([a for a in filtered_alerts if not a.acknowledged]),
            'resolved_alerts': len([a for a in filtered_alerts if a.resolved])
        }
        
    def acknowledge_alert(self, alert_id: str) -> bool:
        """
        Alert'i acknowledge et
        
        Args:
            alert_id: Alert ID
            
        Returns:
            bool: Success status
        """
        
        for alert in self.alerts:
            if alert.alert_id == alert_id:
                alert.acknowledged = True
                self.logger.info(f"Alert acknowledged: {alert_id}")
                return True
                
        return False
        
    def resolve_alert(self, alert_id: str) -> bool:
        """
        Alert'i resolve et
        
        Args:
            alert_id: Alert ID
            
        Returns:
            bool: Success status
        """
        
        for alert in self.alerts:
            if alert.alert_id == alert_id:
                alert.resolved = True
                alert.acknowledged = True
                self.logger.info(f"Alert resolved: {alert_id}")
                return True
                
        return False
        
    def cancel_order(self, order_id: str) -> bool:
        """
        Order'ı iptal et
        
        Args:
            order_id: Order ID
            
        Returns:
            bool: Success status
        """
        
        if order_id in self.active_orders:
            metrics = self.active_orders[order_id]
            metrics.status = ExecutionStatus.CANCELLED
            metrics.timestamp = datetime.now()
            
            self.logger.info(f"Order cancelled: {order_id}")
            return True
            
        return False
        
    def export_monitoring_data(self, filepath: str) -> None:
        """
        Monitoring data'sını export et
        
        Args:
            filepath: Export file path
        """
        
        export_data = {
            'export_timestamp': datetime.now().isoformat(),
            'monitoring_status': self.get_monitoring_status(),
            'active_orders': {oid: metrics.__dict__ for oid, metrics in self.active_orders.items()},
            'recent_alerts': [alert.__dict__ for alert in self.alerts[-100:]],
            'control_actions': [action.__dict__ for action in self.control_actions[-50:]],
            'performance_summaries': {
                oid: self.performance_tracker.get_performance_summary(oid)
                for oid in self.active_orders.keys()
            }
        }
        
        with open(filepath, 'w') as f:
            json.dump(export_data, f, indent=2, default=str)
            
        self.logger.info(f"Monitoring data exported: {filepath}")
        
    def clear_old_data(self, retention_days: int = 30) -> None:
        """
        Eski data'yı temizle
        
        Args:
            retention_days: Data retention period
        """
        
        cutoff_time = datetime.now() - timedelta(days=retention_days)
        
        # Clear old alerts
        self.alerts = [alert for alert in self.alerts if alert.timestamp >= cutoff_time]
        
        # Clear old control actions
        self.control_actions = [action for action in self.control_actions if action.timestamp >= cutoff_time]
        
        # Clear old performance data
        for order_id in list(self.performance_tracker.metrics_history.keys()):
            self.performance_tracker.metrics_history[order_id] = [
                metrics for metrics in self.performance_tracker.metrics_history[order_id]
                if metrics.timestamp >= cutoff_time
            ]
            
        self.logger.info(f"Old monitoring data cleared (retention: {retention_days} days)")
        
    def get_performance_metrics(self) -> Dict:
        """
        Overall performance metrics'i getir
        
        Returns:
            Dict: Performance metrics
        """
        
        all_performance = []
        for order_id in self.active_orders.keys():
            summary = self.performance_tracker.get_performance_summary(order_id)
            if 'avg_execution_efficiency' in summary:
                all_performance.append(summary)
                
        if not all_performance:
            return {'message': 'Performance data yok'}
            
        # Aggregate metrics
        avg_efficiency = np.mean([p['avg_execution_efficiency'] for p in all_performance])
        avg_shortfall = np.mean([p['avg_shortfall_performance'] for p in all_performance])
        avg_price_quality = np.mean([p['avg_price_quality'] for p in all_performance])
        
        return {
            'total_monitored_orders': len(self.active_orders),
            'avg_execution_efficiency': avg_efficiency,
            'avg_shortfall_performance': avg_shortfall,
            'avg_price_quality': avg_price_quality,
            'orders_with_issues': len([p for p in all_performance if p.get('efficiency_trend') == 'DECLINING']),
            'data_quality_score': min(1.0, len(all_performance) / 10)  # Score based on data availability
        }