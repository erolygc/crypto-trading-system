"""
Participation Rate Optimization Algorithm

Bu modül optimal execution participation rate'ini hesaplayan algoritmaları implement eder.
Market impact, timing risk ve opportunity cost arasında denge kurarak optimal katılım oranını bulur.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging
from scipy.optimize import minimize_scalar, minimize
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor

@dataclass
class ParticipationConstraints:
    """Katılım oranı kısıtları"""
    min_rate: float = 0.01  # Minimum %1
    max_rate: float = 0.30  # Maximum %30
    regulatory_limit: float = 0.20  # Regulatory limit %20
    venue_limit: float = 0.10  # Venue specific limit %10
    risk_limit: float = 0.25  # Risk limit %25

@dataclass
class MarketContext:
    """Market bağlamı"""
    symbol: str
    current_price: float
    daily_volume: float
    volatility: float
    spread: float
    order_book_depth: float
    market_regime: str  # 'TRENDING', 'RANGING', 'VOLATILE'
    time_of_day: str  # 'OPEN', 'MIDDAY', 'CLOSE'
    news_events: List[str]

@dataclass
class ParticipationOptimization:
    """Katılım optimizasyon sonucu"""
    optimal_rate: float
    expected_cost: float
    risk_score: float
    confidence: float
    trade_offs: Dict[str, float]
    recommendations: List[str]

class CostModel:
    """Execution cost modeli"""
    
    def __init__(self):
        self.temporary_impact_coeff = 0.01
        self.permanent_impact_coeff = 0.001
        self.timing_risk_coeff = 0.0001
        self.opportunity_cost_coeff = 0.0002
        
    def calculate_total_cost(self,
                           participation_rate: float,
                           order_size: float,
                           market_context: MarketContext) -> float:
        """
        Toplam execution maliyeti hesapla
        
        Args:
            participation_rate: Katılım oranı
            order_size: Emir boyutu
            market_context: Market bağlamı
            
        Returns:
            float: Toplam maliyet
        """
        
        # Temporary impact cost
        temp_impact = self.temporary_impact_coeff * participation_rate * market_context.volatility
        temp_cost = temp_impact * order_size * market_context.current_price
        
        # Permanent impact cost
        perm_impact = self.permanent_impact_coeff * participation_rate * (order_size / market_context.daily_volume)
        perm_cost = perm_impact * order_size * market_context.current_price
        
        # Timing risk cost
        # Düşük katılım oranı = yüksek timing risk
        timing_risk = self.timing_risk_coeff * (1 - participation_rate) * order_size * market_context.volatility * market_context.current_price
        
        # Opportunity cost
        # Spread ödeme maliyeti
        opportunity_cost = self.opportunity_cost_coeff * participation_rate * market_context.spread * order_size * market_context.current_price
        
        total_cost = temp_cost + perm_cost + timing_risk + opportunity_cost
        
        return total_cost
        
    def calculate_marginal_cost(self,
                              participation_rate: float,
                              order_size: float,
                              market_context: MarketContext) -> float:
        """
        Marjinal maliyet hesapla
        
        Args:
            participation_rate: Katılım oranı
            order_size: Emir boyutu
            market_context: Market bağlamı
            
        Returns:
            float: Marjinal maliyet
        """
        
        delta_rate = 0.001  # Small increment
        cost_high = self.calculate_total_cost(participation_rate + delta_rate, order_size, market_context)
        cost_low = self.calculate_total_cost(participation_rate - delta_rate, order_size, market_context)
        
        return (cost_high - cost_low) / (2 * delta_rate)

class RiskModel:
    """Risk değerlendirme modeli"""
    
    def __init__(self):
        self.volatility_risk_weight = 0.4
        self.liquidity_risk_weight = 0.3
        self.timing_risk_weight = 0.2
        self.market_risk_weight = 0.1
        
    def calculate_risk_score(self,
                           participation_rate: float,
                           market_context: MarketContext,
                           time_remaining: float) -> float:
        """
        Risk skorunu hesapla
        
        Args:
            participation_rate: Katılım oranı
            market_context: Market bağlamı
            time_remaining: Kalan zaman (saat)
            
        Returns:
            float: Risk skoru (0-1)
        """
        
        # Volatility risk
        volatility_risk = min(1.0, market_context.volatility * 2)
        
        # Liquidity risk
        # Yüksek katılım oranı = yüksek likidite riski
        liquidity_risk = min(1.0, participation_rate * 5)
        
        # Timing risk
        # Az kalan zaman = yüksek timing risk
        timing_risk = max(0, 1 - (time_remaining / 24))  # 24 saat varsayılan
        
        # Market regime risk
        regime_risk_map = {
            'VOLATILE': 0.8,
            'TRENDING': 0.6,
            'RANGING': 0.3
        }
        market_risk = regime_risk_map.get(market_context.market_regime, 0.5)
        
        # Weighted average
        total_risk = (volatility_risk * self.volatility_risk_weight +
                     liquidity_risk * self.liquidity_risk_weight +
                     timing_risk * self.timing_risk_weight +
                     market_risk * self.market_risk_weight)
        
        return min(1.0, total_risk)
        
    def get_risk_breakdown(self,
                          participation_rate: float,
                          market_context: MarketContext,
                          time_remaining: float) -> Dict[str, float]:
        """
        Risk bileşenlerini detaylandır
        
        Args:
            participation_rate: Katılım oranı
            market_context: Market bağlamı
            time_remaining: Kalan zaman
            
        Returns:
            Dict[str, float]: Risk breakdown
        """
        
        return {
            'volatility_risk': min(1.0, market_context.volatility * 2),
            'liquidity_risk': min(1.0, participation_rate * 5),
            'timing_risk': max(0, 1 - (time_remaining / 24)),
            'market_regime_risk': 0.8 if market_context.market_regime == 'VOLATILE' else 0.3
        }

class MachineLearningOptimizer:
    """Machine Learning tabanlı participation rate optimizer"""
    
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.is_trained = False
        self.logger = logging.getLogger(__name__)
        
    def prepare_features(self,
                        participation_rate: float,
                        market_context: MarketContext,
                        order_size: float,
                        time_remaining: float) -> np.ndarray:
        """
        ML model için feature vector hazırla
        
        Args:
            participation_rate: Katılım oranı
            market_context: Market bağlamı
            order_size: Emir boyutu
            time_remaining: Kalan zaman
            
        Returns:
            np.ndarray: Feature vector
        """
        
        features = np.array([
            participation_rate,
            market_context.volatility,
            market_context.spread,
            market_context.daily_volume,
            order_size,
            time_remaining,
            participation_rate * market_context.volatility,  # Interaction
            order_size / market_context.daily_volume,  # Size ratio
            market_context.volatility * time_remaining  # Volatility-time interaction
        ])
        
        return features.reshape(1, -1)
        
    def predict_optimal_rate(self,
                           market_context: MarketContext,
                           order_size: float,
                           time_remaining: float) -> float:
        """
        ML model ile optimal rate tahmin et
        
        Args:
            market_context: Market bağlamı
            order_size: Emir boyutu
            time_remaining: Kalan zaman
            
        Returns:
            float: Tahmin edilen optimal rate
        """
        
        if not self.is_trained:
            # Model eğitilmemişse basit heuristic döndür
            return self._heuristic_optimal_rate(market_context, order_size)
            
        # Range of participation rates to test
        test_rates = np.linspace(0.01, 0.30, 30)
        costs = []
        
        for rate in test_rates:
            features = self.prepare_features(rate, market_context, order_size, time_remaining)
            scaled_features = self.scaler.transform(features)
            predicted_cost = self.model.predict(scaled_features)[0]
            costs.append(predicted_cost)
            
        # En düşük maliyetli rate'i döndür
        min_cost_idx = np.argmin(costs)
        return test_rates[min_cost_idx]
        
    def _heuristic_optimal_rate(self,
                              market_context: MarketContext,
                              order_size: float) -> float:
        """
        Heuristic optimal rate hesaplama
        
        Args:
            market_context: Market bağlamı
            order_size: Emir boyutu
            
        Returns:
            float: Heuristic optimal rate
        """
        
        # Base rate
        base_rate = 0.10
        
        # Volatility adjustment
        if market_context.volatility > 0.8:  # Yüksek volatilite
            volatility_adj = -0.03
        elif market_context.volatility < 0.3:  # Düşük volatilite
            volatility_adj = 0.02
        else:
            volatility_adj = 0
            
        # Time of day adjustment
        time_adj = {
            'OPEN': 0.02,  # Açılışta daha yüksek likidite
            'MIDDAY': -0.01,  # Öğlen arası düşük likidite
            'CLOSE': 0.015  # Kapanışta yüksek likidite
        }.get(market_context.time_of_day, 0)
        
        # Order size adjustment
        size_ratio = order_size / market_context.daily_volume
        if size_ratio > 0.1:  # %10'dan büyük emirler
            size_adj = -0.02
        elif size_ratio < 0.01:  # %1'den küçük emirler
            size_adj = 0.01
        else:
            size_adj = 0
            
        optimal_rate = base_rate + volatility_adj + time_adj + size_adj
        
        return max(0.01, min(0.30, optimal_rate))
        
    def train_model(self, training_data: pd.DataFrame) -> None:
        """
        ML model'i eğit
        
        Args:
            training_data: Eğitim verisi
        """
        
        if training_data.empty:
            self.logger.warning("Eğitim verisi boş")
            return
            
        # Feature columns
        feature_cols = [
            'participation_rate', 'volatility', 'spread', 'daily_volume',
            'order_size', 'time_remaining', 'rate_vol_interaction',
            'size_ratio', 'vol_time_interaction'
        ]
        
        if not all(col in training_data.columns for col in feature_cols):
            self.logger.warning("Eksik feature columns")
            return
            
        X = training_data[feature_cols]
        y = training_data['optimal_rate']
        
        # Feature scaling
        X_scaled = self.scaler.fit_transform(X)
        
        # Model training
        self.model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.model.fit(X_scaled, y)
        
        self.is_trained = True
        self.logger.info("ML model eğitildi")

class ParticipationOptimizer:
    """
    Participation Rate Optimization Engine
    
    Optimal execution participation rate'ini hesaplar.
    Multiple algorithms kullanır: cost optimization, risk management, ML-based prediction.
    """
    
    def __init__(self,
                 constraints: Optional[ParticipationConstraints] = None,
                 cost_model: Optional[CostModel] = None,
                 risk_model: Optional[RiskModel] = None,
                 ml_optimizer: Optional[MachineLearningOptimizer] = None):
        """
        Args:
            constraints: Katılım kısıtları
            cost_model: Cost model
            risk_model: Risk model
            ml_optimizer: ML optimizer
        """
        
        self.constraints = constraints or ParticipationConstraints()
        self.cost_model = cost_model or CostModel()
        self.risk_model = risk_model or RiskModel()
        self.ml_optimizer = ml_optimizer or MachineLearningOptimizer()
        self.logger = logging.getLogger(__name__)
        
        # Optimization history
        self.optimization_history: List[Dict] = []
        
    def optimize_participation_rate(self,
                                  order_size: float,
                                  market_context: MarketContext,
                                  time_remaining_hours: float,
                                  risk_tolerance: float = 0.5) -> ParticipationOptimization:
        """
        Optimal participation rate'i optimize et
        
        Args:
            order_size: Emir boyutu
            market_context: Market bağlamı
            time_remaining_hours: Kalan zaman (saat)
            risk_tolerance: Risk toleransı (0.0-1.0)
            
        Returns:
            ParticipationOptimization: Optimizasyon sonucu
        """
        
        # 1. Cost optimization
        cost_optimal_rate = self._optimize_for_cost(order_size, market_context, time_remaining_hours)
        
        # 2. Risk-constrained optimization
        risk_optimal_rate = self._optimize_with_risk_constraints(
            order_size, market_context, time_remaining_hours, risk_tolerance
        )
        
        # 3. ML-based prediction
        ml_optimal_rate = self.ml_optimizer.predict_optimal_rate(
            market_context, order_size, time_remaining_hours
        )
        
        # 4. Ensemble result
        ensemble_rate = self._combine_optimization_results(
            cost_optimal_rate, risk_optimal_rate, ml_optimal_rate, market_context
        )
        
        # 5. Apply constraints
        final_rate = self._apply_constraints(ensemble_rate)
        
        # 6. Calculate metrics
        metrics = self._calculate_optimization_metrics(
            final_rate, order_size, market_context, time_remaining_hours
        )
        
        # 7. Generate recommendations
        recommendations = self._generate_recommendations(final_rate, metrics, market_context)
        
        # 8. Trade-off analysis
        trade_offs = self._analyze_trade_offs(final_rate, order_size, market_context, time_remaining_hours)
        
        result = ParticipationOptimization(
            optimal_rate=final_rate,
            expected_cost=metrics['expected_cost'],
            risk_score=metrics['risk_score'],
            confidence=metrics['confidence'],
            trade_offs=trade_offs,
            recommendations=recommendations
        )
        
        # History'ye ekle
        optimization_record = {
            'timestamp': datetime.now(),
            'symbol': market_context.symbol,
            'order_size': order_size,
            'optimal_rate': final_rate,
            'cost_optimal': cost_optimal_rate,
            'risk_optimal': risk_optimal_rate,
            'ml_optimal': ml_optimal_rate,
            'risk_tolerance': risk_tolerance,
            'market_context': market_context.__dict__
        }
        
        self.optimization_history.append(optimization_record)
        
        self.logger.info(f"Participation rate optimize edildi: {market_context.symbol}, "
                        f"Order: {order_size:.0f}, Optimal Rate: {final_rate:.3f}")
        
        return result
        
    def _optimize_for_cost(self,
                         order_size: float,
                         market_context: MarketContext,
                         time_remaining_hours: float) -> float:
        """
        Cost minimization için optimal rate bul
        
        Args:
            order_size: Emir boyutu
            market_context: Market bağlamı
            time_remaining_hours: Kalan zaman
            
        Returns:
            float: Cost-optimal rate
        """
        
        def objective(rate):
            return self.cost_model.calculate_total_cost(rate, order_size, market_context)
            
        # Constraints
        bounds = (self.constraints.min_rate, self.constraints.max_rate)
        
        # Optimize
        result = minimize_scalar(objective, bounds=bounds, method='bounded')
        
        return result.x
        
    def _optimize_with_risk_constraints(self,
                                      order_size: float,
                                      market_context: MarketContext,
                                      time_remaining_hours: float,
                                      risk_tolerance: float) -> float:
        """
        Risk kısıtları ile optimal rate bul
        
        Args:
            order_size: Emir boyutu
            market_context: Market bağlamı
            time_remaining_hours: Kalan zaman
            risk_tolerance: Risk toleransı
            
        Returns:
            float: Risk-constrained optimal rate
        """
        
        def objective(rate):
            # Cost + risk penalty
            cost = self.cost_model.calculate_total_cost(rate, order_size, market_context)
            risk = self.risk_model.calculate_risk_score(rate, market_context, time_remaining_hours)
            
            # Risk penalty (higher risk = higher penalty)
            risk_penalty = risk * 1000 * (1 - risk_tolerance)  # Scale risk penalty
            
            return cost + risk_penalty
            
        bounds = (self.constraints.min_rate, self.constraints.max_rate)
        
        result = minimize_scalar(objective, bounds=bounds, method='bounded')
        
        return result.x
        
    def _combine_optimization_results(self,
                                    cost_rate: float,
                                    risk_rate: float,
                                    ml_rate: float,
                                    market_context: MarketContext) -> float:
        """
        Multiple optimization sonuçlarını birleştir
        
        Args:
            cost_rate: Cost-optimal rate
            risk_rate: Risk-optimal rate
            ml_rate: ML-predicted rate
            market_context: Market bağlamı
            
        Returns:
            float: Combined optimal rate
        """
        
        # Market regime'e göre weight'ler
        if market_context.market_regime == 'VOLATILE':
            # Volatil piyasada risk daha önemli
            weights = {'cost': 0.3, 'risk': 0.5, 'ml': 0.2}
        elif market_context.market_regime == 'TRENDING':
            # Trend'de ML daha iyi performans gösterir
            weights = {'cost': 0.4, 'risk': 0.3, 'ml': 0.3}
        else:  # RANGING
            # Range'de cost optimization daha önemli
            weights = {'cost': 0.5, 'risk': 0.3, 'ml': 0.2}
            
        combined_rate = (weights['cost'] * cost_rate +
                        weights['risk'] * risk_rate +
                        weights['ml'] * ml_rate)
        
        return combined_rate
        
    def _apply_constraints(self, rate: float) -> float:
        """
        Kısıtları uygula
        
        Args:
            rate: Raw optimal rate
            
        Returns:
            float: Constrained rate
        """
        
        # Apply all constraints
        constrained_rate = rate
        constrained_rate = max(constrained_rate, self.constraints.min_rate)
        constrained_rate = min(constrained_rate, self.constraints.max_rate)
        constrained_rate = min(constrained_rate, self.constraints.regulatory_limit)
        constrained_rate = min(constrained_rate, self.constraints.venue_limit)
        constrained_rate = min(constrained_rate, self.constraints.risk_limit)
        
        return constrained_rate
        
    def _calculate_optimization_metrics(self,
                                      rate: float,
                                      order_size: float,
                                      market_context: MarketContext,
                                      time_remaining_hours: float) -> Dict[str, float]:
        """
        Optimizasyon metriklerini hesapla
        
        Args:
            rate: Optimal rate
            order_size: Emir boyutu
            market_context: Market bağlamı
            time_remaining_hours: Kalan zaman
            
        Returns:
            Dict[str, float]: Metrics
        """
        
        # Expected cost
        expected_cost = self.cost_model.calculate_total_cost(rate, order_size, market_context)
        
        # Risk score
        risk_score = self.risk_model.calculate_risk_score(rate, market_context, time_remaining_hours)
        
        # Confidence (model confidence + market condition confidence)
        volatility_confidence = 1.0 - abs(market_context.volatility - 0.5) * 2  # 0.5 volatility = max confidence
        liquidity_confidence = min(1.0, market_context.order_book_depth / 10000)  # 10K depth = max confidence
        time_confidence = min(1.0, time_remaining_hours / 8)  # 8+ hours = max confidence
        
        confidence = (volatility_confidence + liquidity_confidence + time_confidence) / 3
        
        return {
            'expected_cost': expected_cost,
            'risk_score': risk_score,
            'confidence': confidence,
            'cost_per_share': expected_cost / order_size if order_size > 0 else 0,
            'risk_adjusted_cost': expected_cost * (1 + risk_score)
        }
        
    def _generate_recommendations(self,
                                rate: float,
                                metrics: Dict[str, float],
                                market_context: MarketContext) -> List[str]:
        """
        Execution önerileri oluştur
        
        Args:
            rate: Optimal rate
            metrics: Optimization metrics
            market_context: Market bağlamı
            
        Returns:
            List[str]: Recommendations
        """
        
        recommendations = []
        
        # Rate-based recommendations
        if rate > 0.20:
            recommendations.append("Yüksek katılım oranı: Market impact riskini izleyin")
        elif rate < 0.05:
            recommendations.append("Düşük katılım oranı: Timing riskini yönetin")
        else:
            recommendations.append("Optimal katılım oranı: Balanced approach kullanın")
            
        # Risk-based recommendations
        if metrics['risk_score'] > 0.7:
            recommendations.append("Yüksek risk: Slice boyutlarını küçültün")
        if metrics['confidence'] < 0.5:
            recommendations.append("Düşük güven: Execution'ı daha uzun süreye yayın")
            
        # Market condition recommendations
        if market_context.market_regime == 'VOLATILE':
            recommendations.append("Volatil piyasa: Conservative execution strategy")
        elif market_context.time_of_day == 'CLOSE':
            recommendations.append("Kapanış saati: Liquidity artışını değerlendirin")
            
        return recommendations
        
    def _analyze_trade_offs(self,
                          rate: float,
                          order_size: float,
                          market_context: MarketContext,
                          time_remaining_hours: float) -> Dict[str, float]:
        """
        Trade-off analizi
        
        Args:
            rate: Optimal rate
            order_size: Emir boyutu
            market_context: Market bağlamı
            time_remaining_hours: Kalan zaman
            
        Returns:
            Dict[str, float]: Trade-off analysis
        """
        
        # Compare different rate scenarios
        low_rate = max(self.constraints.min_rate, rate * 0.7)
        high_rate = min(self.constraints.max_rate, rate * 1.3)
        
        # Cost differences
        cost_low = self.cost_model.calculate_total_cost(low_rate, order_size, market_context)
        cost_high = self.cost_model.calculate_total_cost(high_rate, order_size, market_context)
        
        # Risk differences
        risk_low = self.risk_model.calculate_risk_score(low_rate, market_context, time_remaining_hours)
        risk_high = self.risk_model.calculate_risk_score(high_rate, market_context, time_remaining_hours)
        
        # Trade-offs
        cost_trade_off = cost_high - cost_low
        risk_trade_off = risk_high - risk_low
        
        return {
            'cost_trade_off': cost_trade_off,
            'risk_trade_off': risk_trade_off,
            'low_rate_cost': cost_low,
            'high_rate_cost': cost_high,
            'low_rate_risk': risk_low,
            'high_rate_risk': risk_high,
            'cost_per_risk_unit': abs(cost_trade_off / risk_trade_off) if risk_trade_off != 0 else 0
        }
        
    def get_optimization_statistics(self) -> Dict:
        """
        Optimizasyon istatistiklerini getir
        
        Returns:
            Dict: Optimization statistics
        """
        
        if not self.optimization_history:
            return {'message': 'Henüz optimizasyon verisi yok'}
            
        recent_optimizations = self.optimization_history[-100:]  # Son 100 optimizasyon
        
        return {
            'total_optimizations': len(self.optimization_history),
            'recent_optimizations': len(recent_optimizations),
            'avg_optimal_rate': np.mean([opt['optimal_rate'] for opt in recent_optimizations]),
            'rate_std': np.std([opt['optimal_rate'] for opt in recent_optimizations]),
            'optimization_methods_used': list(set([
                opt.get('cost_optimal', 0) and 'COST' for opt in recent_optimizations
            ])),
            'avg_risk_tolerance': np.mean([opt.get('risk_tolerance', 0.5) for opt in recent_optimizations])
        }
        
    def train_ml_model(self, training_data: pd.DataFrame) -> None:
        """
        ML model'i eğit
        
        Args:
            training_data: Eğitim verisi
        """
        
        self.ml_optimizer.train_model(training_data)
        
        self.logger.info("Participation optimizer ML model eğitildi")