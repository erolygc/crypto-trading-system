"""
Adaptive Scheduling Algorithm

Bu modül piyasa koşullarına göre dinamik execution planı ayarlayan algoritmayı implement eder.
Piyasa volatilitesi, likidite, spread gibi faktörlere göre execution zamanlamasını optimize eder.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging
from enum import Enum
import json

class MarketRegime(Enum):
    """Piyasa rejim türleri"""
    TRENDING = "trending"
    RANGING = "ranging"
    VOLATILE = "volatile"
    LOW_LIQUIDITY = "low_liquidity"
    HIGH_LIQUIDITY = "high_liquidity"
    NEWS_EVENT = "news_event"

@dataclass
class MarketConditions:
    """Piyasa koşulları bilgileri"""
    timestamp: datetime
    volatility: float  # 0.0-1.0
    spread: float  # Tick sayısı
    volume: float  # Hacim
    bid_ask_spread: float  # Bid-ask spread
    order_book_depth: float  # Order book derinliği
    price_impact: float  # Fiyat etkisi
    market_regime: MarketRegime = MarketRegime.RANGING
    
@dataclass
class AdaptiveSlice:
    """Adaptive execution slice"""
    order_id: str
    original_slice_number: int
    original_quantity: float
    original_target_time: datetime
    adapted_quantity: float
    adapted_target_time: datetime
    adaptation_reason: str
    confidence_score: float
    execution_priority: int  # 1-5, 5 = en yüksek

@dataclass
class SchedulingParameters:
    """Adaptive scheduling parametreleri"""
    volatility_threshold: float = 0.7
    spread_threshold: float = 5  # Tick
    volume_threshold: float = 100000  # Share
    adaptation_frequency_minutes: int = 15
    max_slice_adjustment: float = 0.25  # %25'e kadar ayarlama
    min_slice_size: float = 500.0
    max_slice_size: float = 500000.0
    time_window_minutes: int = 60  # Time grouping window

class MarketConditionAnalyzer:
    """Piyasa koşulları analiz sınıfı"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        
    def analyze_market_conditions(self,
                                current_price: float,
                                price_history: pd.Series,
                                volume_history: pd.Series,
                                spread_data: List[float]) -> MarketConditions:
        """
        Mevcut piyasa koşullarını analiz et
        
        Args:
            current_price: Mevcut fiyat
            price_history: Fiyat geçmişi
            volume_history: Hacim geçmişi
            spread_data: Spread verileri
            
        Returns:
            MarketConditions: Analiz sonuçları
        """
        
        # Volatilite hesapla (son 1 saatlik verilerden)
        if len(price_history) > 0:
            returns = price_history.pct_change().dropna()
            volatility = min(1.0, returns.std() * np.sqrt(252) if len(returns) > 0 else 0.5)
        else:
            volatility = 0.5
            
        # Spread analizi
        avg_spread = np.mean(spread_data) if spread_data else 2.0
        
        # Hacim analizi
        current_volume = volume_history.iloc[-1] if len(volume_history) > 0 else 100000
        avg_volume = volume_history.mean() if len(volume_history) > 0 else 100000
        volume_ratio = current_volume / avg_volume if avg_volume > 0 else 1.0
        
        # Order book derinliği (basitleştirilmiş)
        order_book_depth = min(10.0, current_volume / 10000)  # 1K share = 1 depth unit
        
        # Fiyat etkisi tahmini
        price_impact = self._estimate_price_impact(current_volume, avg_volume, volatility)
        
        # Market regime belirleme
        market_regime = self._determine_market_regime(volatility, volume_ratio, avg_spread)
        
        return MarketConditions(
            timestamp=datetime.now(),
            volatility=volatility,
            spread=avg_spread,
            volume=current_volume,
            bid_ask_spread=avg_spread,
            order_book_depth=order_book_depth,
            price_impact=price_impact,
            market_regime=market_regime
        )
        
    def _estimate_price_impact(self, current_volume: float, avg_volume: float, volatility: float) -> float:
        """
        Fiyat etkisini tahmin et
        
        Args:
            current_volume: Mevcut hacim
            avg_volume: Ortalama hacim
            volatility: Volatilite
            
        Returns:
            float: Fiyat etkisi (0.0-1.0)
        """
        
        volume_factor = current_volume / avg_volume if avg_volume > 0 else 1.0
        
        # Yüksek hacim + yüksek volatilite = yüksek fiyat etkisi
        if volume_factor > 2.0 and volatility > 0.7:
            return min(1.0, 0.8 + volatility * 0.2)
        elif volume_factor < 0.5 or volatility > 0.8:
            return min(1.0, 0.9)
        elif volatility > 0.6:
            return min(1.0, 0.6 + volatility * 0.3)
        else:
            return min(0.5, volatility * 0.8)
            
    def _determine_market_regime(self, volatility: float, volume_ratio: float, spread: float) -> MarketRegime:
        """
        Market regime belirle
        
        Args:
            volatility: Volatilite
            volume_ratio: Hacim oranı
            spread: Spread
            
        Returns:
            MarketRegime: Belirlenen rejim
        """
        
        # Yüksek volatilite
        if volatility > 0.8:
            return MarketRegime.VOLATILE
            
        # Düşük likidite (düşük hacim + yüksek spread)
        if volume_ratio < 0.5 or spread > 10:
            return MarketRegime.LOW_LIQUIDITY
            
        # Yüksek likidite
        if volume_ratio > 2.0 and spread < 2:
            return MarketRegime.HIGH_LIQUIDITY
            
        # Trend vs Range (basit implementasyon)
        if volatility > 0.6:
            return MarketRegime.TRENDING
        else:
            return MarketRegime.RANGING

class AdaptiveScheduler:
    """
    Adaptive Execution Scheduling Algorithm
    
    Piyasa koşullarına göre execution planını dinamik olarak ayarlar.
    Volatilite, likidite, spread gibi faktörlere göre slice'ları yeniden zamanlar ve boyutlandırır.
    """
    
    def __init__(self, 
                 scheduling_parameters: Optional[SchedulingParameters] = None,
                 market_analyzer: Optional[MarketConditionAnalyzer] = None):
        """
        Args:
            scheduling_parameters: Scheduling parametreleri
            market_analyzer: Market condition analyzer
        """
        
        self.params = scheduling_parameters or SchedulingParameters()
        self.market_analyzer = market_analyzer or MarketConditionAnalyzer()
        self.logger = logging.getLogger(__name__)
        
        # Adaptive scheduling state
        self.adaptation_history: Dict[str, List[Dict]] = {}
        self.current_market_conditions: Dict[str, MarketConditions] = {}
        self.execution_plans: Dict[str, List[AdaptiveSlice]] = {}
        
    def create_adaptive_plan(self,
                           order_id: str,
                           base_slices: List[Dict],
                           symbol: str) -> List[AdaptiveSlice]:
        """
        Adaptive execution planı oluştur
        
        Args:
            order_id: Order ID
            base_slices: Temel slice'lar
            symbol: Sembol
            
        Returns:
            List[AdaptiveSlice]: Adaptive slice'lar
        """
        
        adaptive_slices = []
        
        # Her slice için adaptive planning yap
        for i, base_slice in enumerate(base_slices):
            adaptive_slice = AdaptiveSlice(
                order_id=order_id,
                original_slice_number=i + 1,
                original_quantity=base_slice.get('quantity', 10000),
                original_target_time=base_slice.get('target_time', datetime.now()),
                adapted_quantity=base_slice.get('quantity', 10000),
                adapted_target_time=base_slice.get('target_time', datetime.now()),
                adaptation_reason="INITIAL",
                confidence_score=1.0,
                execution_priority=3  # Default priority
            )
            
            adaptive_slices.append(adaptive_slice)
            
        self.execution_plans[order_id] = adaptive_slices
        self.adaptation_history[order_id] = []
        
        self.logger.info(f"Adaptive plan oluşturuldu: Order {order_id}, Slices: {len(adaptive_slices)}")
        return adaptive_slices
        
    def analyze_and_adapt(self,
                         order_id: str,
                         current_time: datetime,
                         market_data: Dict) -> List[AdaptiveSlice]:
        """
        Mevcut piyasa koşullarını analiz et ve planı ayarla
        
        Args:
            order_id: Order ID
            current_time: Mevcut zaman
            market_data: Piyasa verileri
            
        Returns:
            List[AdaptiveSlice]: Güncellenmiş adaptive slice'lar
        """
        
        if order_id not in self.execution_plans:
            raise ValueError(f"Order bulunamadı: {order_id}")
            
        # Piyasa koşullarını analiz et
        current_conditions = self._analyze_current_market_conditions(order_id, market_data)
        self.current_market_conditions[order_id] = current_conditions
        
        # Adaptive planı güncelle
        adapted_slices = self._adapt_execution_plan(order_id, current_conditions, current_time)
        
        # Adaptasyon geçmişini kaydet
        adaptation_record = {
            'timestamp': current_time,
            'market_regime': current_conditions.market_regime.value,
            'volatility': current_conditions.volatility,
            'spread': current_conditions.spread,
            'volume': current_conditions.volume,
            'adaptations_made': len([s for s in adapted_slices if s.adaptation_reason != "INITIAL"])
        }
        
        self.adaptation_history[order_id].append(adaptation_record)
        
        self.logger.info(f"Adaptive analysis tamamlandı: Order {order_id}, "
                        f"Regime: {current_conditions.market_regime.value}, "
                        f"Adaptations: {adaptation_record['adaptations_made']}")
        
        return adapted_slices
        
    def _analyze_current_market_conditions(self, order_id: str, market_data: Dict) -> MarketConditions:
        """
        Mevcut piyasa koşullarını analiz et
        
        Args:
            order_id: Order ID
            market_data: Piyasa verileri
            
        Returns:
            MarketConditions: Analiz sonuçları
        """
        
        current_price = market_data.get('current_price', 100.0)
        price_history = pd.Series(market_data.get('price_history', [100.0] * 100))
        volume_history = pd.Series(market_data.get('volume_history', [100000] * 100))
        spread_data = market_data.get('spread_data', [2.0] * 10)
        
        return self.market_analyzer.analyze_market_conditions(
            current_price, price_history, volume_history, spread_data
        )
        
    def _adapt_execution_plan(self,
                            order_id: str,
                            market_conditions: MarketConditions,
                            current_time: datetime) -> List[AdaptiveSlice]:
        """
        Execution planını piyasa koşullarına göre ayarla
        
        Args:
            order_id: Order ID
            market_conditions: Piyasa koşulları
            current_time: Mevcut zaman
            
        Returns:
            List[AdaptiveSlice]: Adaptasyon uygulanmış slice'lar
        """
        
        if order_id not in self.execution_plans:
            return []
            
        adaptive_slices = self.execution_plans[order_id].copy()
        
        # Market regime'e göre adaptasyon yap
        if market_conditions.market_regime == MarketRegime.VOLATILE:
            self._adapt_for_volatile_market(adaptive_slices, market_conditions, current_time)
        elif market_conditions.market_regime == MarketRegime.LOW_LIQUIDITY:
            self._adapt_for_low_liquidity(adaptive_slices, market_conditions, current_time)
        elif market_conditions.market_regime == MarketRegime.HIGH_LIQUIDITY:
            self._adapt_for_high_liquidity(adaptive_slices, market_conditions, current_time)
        elif market_conditions.market_regime == MarketRegime.TRENDING:
            self._adapt_for_trending_market(adaptive_slices, market_conditions, current_time)
            
        # Güncellenmiş planı kaydet
        self.execution_plans[order_id] = adaptive_slices
        
        return adaptive_slices
        
    def _adapt_for_volatile_market(self,
                                  slices: List[AdaptiveSlice],
                                  conditions: MarketConditions,
                                  current_time: datetime) -> None:
        """
        Volatil piyasa için adaptasyon
        
        Args:
            slices: Adaptive slice'lar
            conditions: Piyasa koşulları
            current_time: Mevcut zaman
        """
        
        # Volatil piyasada:
        # 1. Slice boyutlarını küçült (risk azaltma)
        # 2. Zamanlamayı sıklaştır (hızlı execution)
        # 3. Execution priority'yi artır
        
        volatility_factor = min(2.0, conditions.volatility)
        
        for slice_obj in slices:
            # Hedef zaman yakın mı?
            time_diff = abs((slice_obj.adapted_target_time - current_time).total_seconds()) / 60
            
            if time_diff < 30:  # 30 dakika içinde
                # Slice boyutunu küçült
                size_reduction = min(0.4, (volatility_factor - 1) * 0.2)  # Max %40 küçültme
                slice_obj.adapted_quantity = slice_obj.original_quantity * (1 - size_reduction)
                slice_obj.adaptation_reason = "VOLATILE_SIZE_REDUCTION"
                slice_obj.execution_priority = min(5, slice_obj.execution_priority + 1)
                
                # Zamanlamayı öne çek
                time_advancement = timedelta(minutes=min(15, volatility_factor * 5))
                slice_obj.adapted_target_time = current_time + time_advancement
                
        self.logger.debug("Volatile market adaptasyonu uygulandı")
        
    def _adapt_for_low_liquidity(self,
                                slices: List[AdaptiveSlice],
                                conditions: MarketConditions,
                                current_time: datetime) -> None:
        """
        Düşük likidite için adaptasyon
        
        Args:
            slices: Adaptive slice'lar
            conditions: Piyasa koşulları
            current_time: Mevcut zaman
        """
        
        # Düşük likiditede:
        # 1. Slice boyutlarını küçült (piyasa etkisini azalt)
        # 2. Zamanlamayı uzat (likidite bekle)
        # 3. Execution priority'yi azalt
        
        liquidity_factor = max(0.5, conditions.volume / 100000)  # Normal hacim = 100K
        
        for slice_obj in slices:
            time_diff = abs((slice_obj.adapted_target_time - current_time).total_seconds()) / 60
            
            if time_diff < 60:  # 1 saat içinde
                # Slice boyutunu küçült
                size_reduction = max(0.2, 0.5 - liquidity_factor * 0.3)
                slice_obj.adapted_quantity = slice_obj.original_quantity * (1 - size_reduction)
                slice_obj.adaptation_reason = "LOW_LIQUIDITY_SIZE_REDUCTION"
                slice_obj.execution_priority = max(1, slice_obj.execution_priority - 1)
                
                # Zamanlamayı uzat
                time_extension = timedelta(minutes=(1 - liquidity_factor) * 30)
                slice_obj.adapted_target_time = slice_obj.adapted_target_time + time_extension
                
        self.logger.debug("Low liquidity adaptasyonu uygulandı")
        
    def _adapt_for_high_liquidity(self,
                                 slices: List[AdaptiveSlice],
                                 conditions: MarketConditions,
                                 current_time: datetime) -> None:
        """
        Yüksek likidite için adaptasyon
        
        Args:
            slices: Adaptive slice'lar
            conditions: Piyasa koşulları
            current_time: Mevcut zaman
        """
        
        # Yüksek likiditede:
        # 1. Slice boyutlarını büyüt (hızlı execution)
        # 2. Zamanlamayı sıklaştır
        # 3. Execution priority'yi artır
        
        liquidity_factor = min(3.0, conditions.volume / 50000)
        
        for slice_obj in slices:
            time_diff = abs((slice_obj.adapted_target_time - current_time).total_seconds()) / 60
            
            if time_diff < 45:  # 45 dakika içinde
                # Slice boyutunu büyüt
                size_increase = min(0.3, (liquidity_factor - 1) * 0.15)
                slice_obj.adapted_quantity = slice_obj.original_quantity * (1 + size_increase)
                slice_obj.adaptation_reason = "HIGH_LIQUIDITY_SIZE_INCREASE"
                slice_obj.execution_priority = min(5, slice_obj.execution_priority + 2)
                
                # Zamanlamayı sıklaştır
                time_advancement = timedelta(minutes=liquidity_factor * 10)
                slice_obj.adapted_target_time = current_time + time_advancement
                
        self.logger.debug("High liquidity adaptasyonu uygulandı")
        
    def _adapt_for_trending_market(self,
                                  slices: List[AdaptiveSlice],
                                  conditions: MarketConditions,
                                  current_time: datetime) -> None:
        """
        Trending market için adaptasyon
        
        Args:
            slices: Adaptive slice'lar
            conditions: Piyasa koşulları
            current_time: Mevcut zaman
        """
        
        # Trending market'te:
        # 1. Trend yönüne göre execution'ı hızlandır veya yavaşlat
        # 2. Market impact'i minimize et
        
        volatility_factor = conditions.volatility
        trend_strength = min(1.0, volatility_factor * 1.5)
        
        for slice_obj in slices:
            time_diff = abs((slice_obj.adapted_target_time - current_time).total_seconds()) / 60
            
            if time_diff < 60:  # 1 saat içinde
                # Trend'e uygun execution speed
                if trend_strength > 0.7:  # Güçlü trend
                    # Slice boyutunu orta düzeyde ayarla
                    slice_obj.adapted_quantity = slice_obj.original_quantity * 0.9
                    slice_obj.adaptation_reason = "TRENDING_SPEED_ADJUSTMENT"
                    slice_obj.execution_priority = min(4, slice_obj.execution_priority + 1)
                    
                    # Zamanlamayı biraz öne çek
                    time_advancement = timedelta(minutes=trend_strength * 5)
                    slice_obj.adapted_target_time = slice_obj.adapted_target_time + time_advancement
                    
        self.logger.debug("Trending market adaptasyonu uygulandı")
        
    def get_execution_priorities(self, order_id: str) -> Dict[int, List[int]]:
        """
        Execution priority'leri getir (slice_number -> priority mapping)
        
        Args:
            order_id: Order ID
            
        Returns:
            Dict[int, List[int]]: Priority slice mapping
        """
        
        if order_id not in self.execution_plans:
            return {}
            
        priorities = {}
        for slice_obj in self.execution_plans[order_id]:
            priority = slice_obj.execution_priority
            slice_num = slice_obj.original_slice_number
            
            if priority not in priorities:
                priorities[priority] = []
            priorities[priority].append(slice_num)
            
        # Priority'ye göre sırala
        return dict(sorted(priorities.items(), reverse=True))
        
    def get_adaptation_summary(self, order_id: str) -> Dict:
        """
        Adaptasyon özetini getir
        
        Args:
            order_id: Order ID
            
        Returns:
            Dict: Adaptasyon özeti
        """
        
        if order_id not in self.adaptation_history:
            return {}
            
        history = self.adaptation_history[order_id]
        
        # Regime distribution
        regime_counts = {}
        for record in history:
            regime = record['market_regime']
            regime_counts[regime] = regime_counts.get(regime, 0) + 1
            
        # Average adaptations per regime
        regime_adaptations = {}
        for record in history:
            regime = record['market_regime']
            adaptations = record['adaptations_made']
            if regime not in regime_adaptations:
                regime_adaptations[regime] = []
            regime_adaptations[regime].append(adaptations)
            
        avg_adaptations = {
            regime: np.mean(adaptations) 
            for regime, adaptations in regime_adaptations.items()
        }
        
        return {
            'total_adaptations': len(history),
            'regime_distribution': regime_counts,
            'avg_adaptations_per_regime': avg_adaptations,
            'latest_regime': history[-1]['market_regime'] if history else None,
            'adaptation_frequency': self._calculate_adaptation_frequency(history)
        }
        
    def _calculate_adaptation_frequency(self, history: List[Dict]) -> float:
        """
        Adaptasyon frekansını hesapla
        
        Args:
            history: Adaptasyon geçmişi
            
        Returns:
            float: Dakika başına adaptasyon sayısı
        """
        
        if len(history) < 2:
            return 0.0
            
        # Zaman farklarını hesapla
        time_diffs = []
        for i in range(1, len(history)):
            time_diff = (history[i]['timestamp'] - history[i-1]['timestamp']).total_seconds() / 60
            time_diffs.append(time_diff)
            
        avg_time_between_adaptations = np.mean(time_diffs)
        return 60.0 / avg_time_between_adaptations if avg_time_between_adaptations > 0 else 0.0
        
    def save_adaptation_state(self, filepath: str) -> None:
        """
        Adaptasyon state'ini kaydet
        
        Args:
            filepath: Kaydedilecek dosya yolu
        """
        
        state_data = {
            'adaptation_history': self.adaptation_history,
            'timestamp': datetime.now().isoformat()
        }
        
        with open(filepath, 'w') as f:
            json.dump(state_data, f, indent=2, default=str)
            
        self.logger.info(f"Adaptation state kaydedildi: {filepath}")
        
    def load_adaptation_state(self, filepath: str) -> None:
        """
        Adaptasyon state'ini yükle
        
        Args:
            filepath: State dosyası yolu
        """
        
        try:
            with open(filepath, 'r') as f:
                state_data = json.load(f)
                
            self.adaptation_history = state_data.get('adaptation_history', {})
            
            self.logger.info(f"Adaptation state yüklendi: {filepath}")
            
        except FileNotFoundError:
            self.logger.warning(f"Adaptation state dosyası bulunamadı: {filepath}")
        except Exception as e:
            self.logger.error(f"Adaptation state yüklenemedi: {e}")