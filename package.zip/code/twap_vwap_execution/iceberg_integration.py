"""
Iceberg Detection Integration

Bu modül hidden liquidity (iceberg emirleri) tespiti ve execution entegrasyonu sağlar.
Order book analizi, pattern recognition ve TWAP/VWAP algoritmalarıyla entegrasyon.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import logging
from collections import defaultdict, deque
from scipy import stats
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

@dataclass
class IcebergOrder:
    """Iceberg emir bilgileri"""
    symbol: str
    side: str  # 'BUY' or 'SELL'
    detected_time: datetime
    estimated_hidden_quantity: float
    displayed_quantity: float
    confidence_score: float
    lifetime_estimate: timedelta
    execution_rate: float  # Shares per second
    pattern_type: str  # 'REGULAR', 'ACCELERATING', 'DECELERATING'

@dataclass
class HiddenLiquidityMetrics:
    """Hidden liquidity metrikleri"""
    total_hidden_quantity: float
    hidden_to_displayed_ratio: float
    average_iceberg_lifetime: timedelta
    iceberg_frequency: float  # Icebergs per hour
    liquidity_contribution: float  # % of total liquidity
    detection_confidence: float

@dataclass
class ExecutionImpact:
    """Execution etki analizi"""
    iceberg_impact_on_execution: float
    optimal_slice_adjustment: float
    timing_recommendation: str
    risk_adjustment: float
    execution_window: Tuple[datetime, datetime]

class IcebergPatternAnalyzer:
    """Iceberg pattern analiz sınıfı"""
    
    def __init__(self, 
                 min_display_size: int = 100,
                 max_hidden_ratio: float = 10.0,
                 pattern_window_minutes: int = 15):
        """
        Args:
            min_display_size: Minimum display size for iceberg detection
            max_hidden_ratio: Maximum hidden to displayed ratio
            pattern_window_minutes: Pattern analysis window
        """
        
        self.min_display_size = min_display_size
        self.max_hidden_ratio = max_hidden_ratio
        self.pattern_window_minutes = pattern_window_minutes
        self.logger = logging.getLogger(__name__)
        
    def detect_iceberg_patterns(self,
                              order_book_data: List[Dict],
                              current_time: datetime) -> List[IcebergOrder]:
        """
        Order book data'dan iceberg pattern'lerini tespit et
        
        Args:
            order_book_data: Order book snapshots
            current_time: Mevcut zaman
            
        Returns:
            List[IcebergOrder]: Tespit edilen iceberg emirler
        """
        
        if len(order_book_data) < 3:
            return []
            
        iceberg_candidates = []
        
        # Analyze each side (bid/ask) separately
        for side in ['bid', 'ask']:
            candidates = self._analyze_side_patterns(order_book_data, side, current_time)
            iceberg_candidates.extend(candidates)
            
        # Apply additional filtering
        filtered_candidates = self._filter_iceberg_candidates(iceberg_candidates)
        
        return filtered_candidates
        
    def _analyze_side_patterns(self,
                             order_book_data: List[Dict],
                             side: str,
                             current_time: datetime) -> List[IcebergOrder]:
        """
        Belirli bir taraf için pattern analizi
        
        Args:
            order_book_data: Order book data
            side: 'bid' or 'ask'
            current_time: Mevcut zaman
            
        Returns:
            List[IcebergOrder]: Iceberg candidates for this side
        """
        
        candidates = []
        
        # Extract level data for analysis
        level_data = []
        for snapshot in order_book_data:
            if side in snapshot and 'levels' in snapshot[side]:
                levels = snapshot[side]['levels']
                if levels:
                    level_data.append({
                        'time': snapshot.get('timestamp', current_time),
                        'best_price': levels[0]['price'],
                        'best_size': levels[0]['size'],
                        'total_depth': sum(level['size'] for level in levels[:5])  # Top 5 levels
                    })
                    
        if len(level_data) < 3:
            return []
            
        # Analyze for iceberg patterns
        df = pd.DataFrame(level_data)
        
        # Detect constant size patterns (iceberg indicator)
        iceberg_indicators = self._detect_constant_size_patterns(df)
        
        # Detect repetitive refilling patterns
        refill_patterns = self._detect_refill_patterns(df)
        
        # Combine indicators
        for indicator in iceberg_indicators:
            pattern_info = self._analyze_pattern_characteristics(indicator, df, side)
            if pattern_info:
                candidates.append(pattern_info)
                
        return candidates
        
    def _detect_constant_size_patterns(self, df: pd.DataFrame) -> List[Dict]:
        """
        Constant size pattern'lerini tespit et (iceberg indicator)
        
        Args:
            df: Order book DataFrame
            
        Returns:
            List[Dict]: Pattern indicators
        """
        
        indicators = []
        
        if len(df) < 5:
            return indicators
            
        # Rolling statistics
        df['size_rolling_std'] = df['best_size'].rolling(window=3).std()
        df['size_rolling_mean'] = df['best_size'].rolling(window=3).mean()
        
        # Detect low variability periods
        low_variability_threshold = df['best_size'].std() * 0.3
        
        low_variability_periods = df[df['size_rolling_std'] < low_variability_threshold]
        
        if len(low_variability_periods) >= 3:
            # Check for reasonable size (not too small, not too large)
            avg_size = low_variability_periods['best_size'].mean()
            
            if self.min_display_size <= avg_size <= self.min_display_size * self.max_hidden_ratio:
                indicators.append({
                    'pattern_type': 'CONSTANT_SIZE',
                    'confidence': len(low_variability_periods) / len(df),
                    'avg_size': avg_size,
                    'period_start': low_variability_periods.index[0],
                    'period_end': low_variability_periods.index[-1]
                })
                
        return indicators
        
    def _detect_refill_patterns(self, df: pd.DataFrame) -> List[Dict]:
        """
        Refill pattern'lerini tespit et
        
        Args:
            df: Order book DataFrame
            
        Returns:
            List[Dict]: Refill pattern indicators
        """
        
        patterns = []
        
        if len(df) < 5:
            return patterns
            
        # Detect sharp drops followed by quick recovery
        for i in range(2, len(df) - 2):
            # Sharp drop (50%+ reduction in size)
            current_size = df.iloc[i]['best_size']
            prev_size = df.iloc[i-1]['best_size']
            
            if prev_size > 0 and current_size / prev_size < 0.5:
                # Check for quick recovery (back to 80%+ of original size within 2 periods)
                for j in range(i+1, min(i+3, len(df))):
                    recovery_size = df.iloc[j]['best_size']
                    if recovery_size / prev_size > 0.8:
                        patterns.append({
                            'pattern_type': 'REFILL',
                            'confidence': 0.7,
                            'drop_time': df.iloc[i]['time'],
                            'recovery_time': df.iloc[j]['time'],
                            'original_size': prev_size,
                            'drop_size': current_size,
                            'recovery_size': recovery_size
                        })
                        break
                        
        return patterns
        
    def _analyze_pattern_characteristics(self,
                                       indicator: Dict,
                                       df: pd.DataFrame,
                                       side: str) -> Optional[IcebergOrder]:
        """
        Pattern characteristics'ını analiz et ve IcebergOrder oluştur
        
        Args:
            indicator: Pattern indicator
            df: Order book DataFrame
            side: 'bid' or 'ask'
            
        Returns:
            Optional[IcebergOrder]: Iceberg order if valid
        """
        
        if indicator['pattern_type'] == 'CONSTANT_SIZE':
            return self._create_iceberg_from_constant_size(indicator, df, side)
        elif indicator['pattern_type'] == 'REFILL':
            return self._create_iceberg_from_refill(indicator, side)
            
        return None
        
    def _create_iceberg_from_constant_size(self,
                                         indicator: Dict,
                                         df: pd.DataFrame,
                                         side: str) -> Optional[IcebergOrder]:
        """
        Constant size pattern'den iceberg oluştur
        
        Args:
            indicator: Pattern indicator
            df: Order book DataFrame
            side: 'bid' or 'ask'
            
        Returns:
            Optional[IcebergOrder]: Iceberg order
        """
        
        displayed_quantity = indicator['avg_size']
        
        # Estimate hidden quantity (conservative estimate)
        estimated_hidden = displayed_quantity * 3  # 3x displayed as conservative estimate
        
        # Calculate confidence score
        confidence = min(1.0, indicator['confidence'] * 0.8)
        
        # Estimate lifetime based on pattern duration
        pattern_duration = (df.iloc[indicator['period_end']]['time'] - 
                          df.iloc[indicator['period_start']]['time']).total_seconds()
        
        estimated_lifetime = timedelta(seconds=pattern_duration * 2)  # Pattern duration * 2
        
        # Calculate execution rate
        if pattern_duration > 0:
            execution_rate = displayed_quantity / pattern_duration
        else:
            execution_rate = 0
            
        return IcebergOrder(
            symbol='UNKNOWN',  # Will be set by caller
            side=side,
            detected_time=df.iloc[indicator['period_end']]['time'],
            estimated_hidden_quantity=estimated_hidden,
            displayed_quantity=displayed_quantity,
            confidence_score=confidence,
            lifetime_estimate=estimated_lifetime,
            execution_rate=execution_rate,
            pattern_type='REGULAR'
        )
        
    def _create_iceberg_from_refill(self,
                                  indicator: Dict,
                                  side: str) -> Optional[IcebergOrder]:
        """
        Refill pattern'den iceberg oluştur
        
        Args:
            indicator: Refill pattern indicator
            side: 'bid' or 'ask'
            
        Returns:
            Optional[IcebergOrder]: Iceberg order
        """
        
        displayed_quantity = indicator['drop_size']
        estimated_hidden = displayed_quantity * 5  # Higher multiplier for refill patterns
        
        confidence = indicator['confidence']
        
        # Calculate execution rate
        time_diff = (indicator['recovery_time'] - indicator['drop_time']).total_seconds()
        if time_diff > 0:
            execution_rate = (indicator['recovery_size'] - indicator['drop_size']) / time_diff
        else:
            execution_rate = 0
            
        return IcebergOrder(
            symbol='UNKNOWN',
            side=side,
            detected_time=indicator['drop_time'],
            estimated_hidden_quantity=estimated_hidden,
            displayed_quantity=displayed_quantity,
            confidence_score=confidence,
            lifetime_estimate=timedelta(minutes=30),  # Default estimate
            execution_rate=execution_rate,
            pattern_type='ACCELERATING' if execution_rate > 0 else 'DECELERATING'
        )
        
    def _filter_iceberg_candidates(self, candidates: List[IcebergOrder]) -> List[IcebergOrder]:
        """
        Iceberg candidate'larını filtrele
        
        Args:
            candidates: Raw iceberg candidates
            
        Returns:
            List[IcebergOrder]: Filtered candidates
        """
        
        filtered = []
        
        for candidate in candidates:
            # Filter by confidence
            if candidate.confidence_score < 0.3:
                continue
                
            # Filter by size reasonableness
            if candidate.displayed_quantity < self.min_display_size:
                continue
                
            # Filter by hidden ratio
            hidden_ratio = candidate.estimated_hidden_quantity / candidate.displayed_quantity
            if hidden_ratio > self.max_hidden_ratio:
                continue
                
            # Filter by execution rate reasonableness
            if candidate.execution_rate > 10000:  # 10K shares/second is unreasonable
                continue
                
            filtered.append(candidate)
            
        return filtered

class HiddenLiquidityAnalyzer:
    """Hidden liquidity analiz sınıfı"""
    
    def __init__(self, window_minutes: int = 60):
        """
        Args:
            window_minutes: Analysis window
        """
        
        self.window_minutes = window_minutes
        self.logger = logging.getLogger(__name__)
        
        # Storage
        self.iceberg_history: deque = deque(maxlen=1000)
        self.hidden_liquidity_metrics: Dict[str, HiddenLiquidityMetrics] = {}
        
    def analyze_hidden_liquidity(self,
                               iceberg_orders: List[IcebergOrder],
                               symbol: str,
                               time_window: timedelta) -> HiddenLiquidityMetrics:
        """
        Hidden liquidity analizi yap
        
        Args:
            iceberg_orders: Tespit edilen iceberg emirler
            symbol: Sembol
            time_window: Analiz zaman penceresi
            
        Returns:
            HiddenLiquidityMetrics: Hidden liquidity metrikleri
        """
        
        # Filter by time window
        cutoff_time = datetime.now() - time_window
        recent_orders = [order for order in iceberg_orders 
                        if order.detected_time >= cutoff_time]
        
        if not recent_orders:
            # Return default metrics if no recent data
            return HiddenLiquidityMetrics(
                total_hidden_quantity=0.0,
                hidden_to_displayed_ratio=0.0,
                average_iceberg_lifetime=timedelta(minutes=30),
                iceberg_frequency=0.0,
                liquidity_contribution=0.0,
                detection_confidence=0.0
            )
            
        # Calculate metrics
        total_hidden = sum(order.estimated_hidden_quantity for order in recent_orders)
        total_displayed = sum(order.displayed_quantity for order in recent_orders)
        
        avg_hidden_ratio = total_hidden / total_displayed if total_displayed > 0 else 0
        avg_lifetime = timedelta(seconds=np.mean([order.lifetime_estimate.total_seconds() 
                                                for order in recent_orders]))
        
        # Iceberg frequency (per hour)
        frequency = len(recent_orders) / (time_window.total_seconds() / 3600)
        
        # Average confidence
        avg_confidence = np.mean([order.confidence_score for order in recent_orders])
        
        # Store in history
        self.iceberg_history.extend(recent_orders)
        
        metrics = HiddenLiquidityMetrics(
            total_hidden_quantity=total_hidden,
            hidden_to_displayed_ratio=avg_hidden_ratio,
            average_iceberg_lifetime=avg_lifetime,
            iceberg_frequency=frequency,
            liquidity_contribution=0.0,  # Will be calculated with market data
            detection_confidence=avg_confidence
        )
        
        self.hidden_liquidity_metrics[symbol] = metrics
        
        self.logger.info(f"Hidden liquidity analiz edildi: {symbol}, "
                        f"Total hidden: {total_hidden:.0f}, Avg ratio: {avg_hidden_ratio:.2f}")
        
        return metrics
        
    def predict_hidden_liquidity_impact(self,
                                      symbol: str,
                                      execution_size: float,
                                      execution_horizon: timedelta) -> Dict:
        """
        Hidden liquidity'in execution'a etkisini tahmin et
        
        Args:
            symbol: Sembol
            execution_size: Execution boyutu
            execution_horizon: Execution zaman ufkı
            
        Returns:
            Dict: Impact prediction
        """
        
        if symbol not in self.hidden_liquidity_metrics:
            # Default predictions if no historical data
            return {
                'hidden_liquidity_available': execution_size * 0.5,  # 50% buffer
                'execution_improvement': 0.1,  # 10% improvement
                'optimal_participation_rate': 0.15,
                'risk_adjustment': 1.0,
                'confidence': 0.3
            }
            
        metrics = self.hidden_liquidity_metrics[symbol]
        
        # Predict available hidden liquidity
        hidden_liquidity_rate = min(1.0, metrics.iceberg_frequency * 0.1)  # Frequency-based rate
        available_hidden = execution_size * hidden_liquidity_rate
        
        # Execution improvement estimate
        liquidity_improvement = min(0.3, metrics.hidden_to_displayed_ratio * 0.05)  # Cap at 30%
        
        # Optimal participation rate adjustment
        base_rate = 0.10  # Base participation rate
        adjusted_rate = base_rate * (1 + liquidity_improvement)
        
        # Risk adjustment
        risk_adjustment = 1.0 - (liquidity_improvement * 0.5)  # Lower risk with more hidden liquidity
        
        return {
            'hidden_liquidity_available': min(available_hidden, execution_size),
            'execution_improvement': liquidity_improvement,
            'optimal_participation_rate': min(0.25, adjusted_rate),
            'risk_adjustment': max(0.7, risk_adjustment),
            'confidence': metrics.detection_confidence
        }

class IcebergDetector:
    """
    Iceberg Detection and Integration Engine
    
    Hidden liquidity detection ve TWAP/VWAP execution entegrasyonu.
    """
    
    def __init__(self,
                 pattern_analyzer: Optional[IcebergPatternAnalyzer] = None,
                 liquidity_analyzer: Optional[HiddenLiquidityAnalyzer] = None):
        """
        Args:
            pattern_analyzer: Pattern analyzer
            liquidity_analyzer: Hidden liquidity analyzer
        """
        
        self.pattern_analyzer = pattern_analyzer or IcebergPatternAnalyzer()
        self.liquidity_analyzer = liquidity_analyzer or HiddenLiquidityAnalyzer()
        self.logger = logging.getLogger(__name__)
        
        # Integration state
        self.active_icebergs: Dict[str, List[IcebergOrder]] = {}
        self.execution_adjustments: Dict[str, Dict] = {}
        self.detection_history: List[Dict] = []
        
    def integrate_with_twap(self,
                          order_book_data: List[Dict],
                          symbol: str,
                          current_time: datetime,
                          twap_slice: Dict) -> Dict:
        """
        TWAP execution'a iceberg detection entegre et
        
        Args:
            order_book_data: Order book data
            symbol: Sembol
            current_time: Mevcut zaman
            twap_slice: TWAP slice bilgileri
            
        Returns:
            Dict: Adjusted slice information
        """
        
        # Detect icebergs
        detected_icebergs = self.pattern_analyzer.detect_iceberg_patterns(order_book_data, current_time)
        
        # Set symbol for detected icebergs
        for iceberg in detected_icebergs:
            iceberg.symbol = symbol
            
        # Update active icebergs
        if symbol not in self.active_icebergs:
            self.active_icebergs[symbol] = []
        self.active_icebergs[symbol].extend(detected_icebergs)
        
        # Analyze hidden liquidity
        time_window = timedelta(minutes=60)
        metrics = self.liquidity_analyzer.analyze_hidden_liquidity(
            detected_icebergs, symbol, time_window
        )
        
        # Adjust TWAP slice
        adjusted_slice = self._adjust_twap_slice_for_icebergs(
            twap_slice, detected_icebergs, metrics
        )
        
        return adjusted_slice
        
    def integrate_with_vwap(self,
                          order_book_data: List[Dict],
                          symbol: str,
                          current_time: datetime,
                          vwap_slice: Dict,
                          market_volume: float) -> Dict:
        """
        VWAP execution'a iceberg detection entegre et
        
        Args:
            order_book_data: Order book data
            symbol: Sembol
            current_time: Mevcut zaman
            vwap_slice: VWAP slice bilgileri
            market_volume: Mevcut piyasa hacmi
            
        Returns:
            Dict: Adjusted VWAP slice
        """
        
        # Detect icebergs
        detected_icebergs = self.pattern_analyzer.detect_iceberg_patterns(order_book_data, current_time)
        
        for iceberg in detected_icebergs:
            iceberg.symbol = symbol
            
        # Update active icebergs
        if symbol not in self.active_icebergs:
            self.active_icebergs[symbol] = []
        self.active_icebergs[symbol].extend(detected_icebergs)
        
        # Analyze hidden liquidity impact on execution
        impact_prediction = self.liquidity_analyzer.predict_hidden_liquidity_impact(
            symbol, vwap_slice.get('quantity', 10000), timedelta(hours=1)
        )
        
        # Adjust VWAP slice
        adjusted_slice = self._adjust_vwap_slice_for_icebergs(
            vwap_slice, detected_icebergs, impact_prediction, market_volume
        )
        
        return adjusted_slice
        
    def _adjust_twap_slice_for_icebergs(self,
                                      slice_info: Dict,
                                      icebergs: List[IcebergOrder],
                                      metrics: HiddenLiquidityMetrics) -> Dict:
        """
        TWAP slice'ını iceberg'ler için ayarla
        
        Args:
            slice_info: Original slice info
            icebergs: Detected icebergs
            metrics: Hidden liquidity metrics
            
        Returns:
            Dict: Adjusted slice info
        """
        
        adjusted_info = slice_info.copy()
        
        # If high hidden liquidity detected, increase slice size slightly
        if metrics.hidden_to_displayed_ratio > 2.0:
            adjustment_factor = min(1.2, 1 + (metrics.hidden_to_displayed_ratio - 2) * 0.1)
            adjusted_info['quantity'] = adjusted_info.get('quantity', 10000) * adjustment_factor
            adjusted_info['adjustment_reason'] = 'HIDDEN_LIQUIDITY_AVAILABLE'
        else:
            # Normal execution
            adjusted_info['adjustment_reason'] = 'NORMAL_EXECUTION'
            
        # Add iceberg confidence to slice metadata
        adjusted_info['iceberg_confidence'] = metrics.detection_confidence
        adjusted_info['hidden_liquidity_ratio'] = metrics.hidden_to_displayed_ratio
        
        return adjusted_info
        
    def _adjust_vwap_slice_for_icebergs(self,
                                      slice_info: Dict,
                                      icebergs: List[IcebergOrder],
                                      impact_prediction: Dict,
                                      market_volume: float) -> Dict:
        """
        VWAP slice'ını iceberg'ler için ayarla
        
        Args:
            slice_info: Original slice info
            icebergs: Detected icebergs
            impact_prediction: Impact prediction
            market_volume: Market volume
            
        Returns:
            Dict: Adjusted slice info
        """
        
        adjusted_info = slice_info.copy()
        
        base_quantity = adjusted_info.get('quantity', 10000)
        
        # Adjust based on hidden liquidity availability
        if impact_prediction['hidden_liquidity_available'] > base_quantity * 0.5:
            # Significant hidden liquidity available
            adjustment_factor = 1 + impact_prediction['execution_improvement']
            adjusted_info['quantity'] = base_quantity * adjustment_factor
            adjusted_info['adjustment_reason'] = 'HIDDEN_LIQUIDITY_BOOST'
        else:
            # Limited hidden liquidity
            adjusted_info['adjustment_reason'] = 'LIMITED_HIDDEN_LIQUIDITY'
            
        # Add impact prediction data
        adjusted_info.update({
            'iceberg_confidence': impact_prediction['confidence'],
            'hidden_liquidity_available': impact_prediction['hidden_liquidity_available'],
            'execution_improvement_pct': impact_prediction['execution_improvement'] * 100,
            'optimal_participation_rate': impact_prediction['optimal_participation_rate']
        })
        
        return adjusted_info
        
    def get_iceberg_impact_on_execution(self,
                                      symbol: str,
                                      execution_size: float,
                                      execution_horizon: timedelta) -> ExecutionImpact:
        """
        Execution üzerindeki iceberg etkisini analiz et
        
        Args:
            symbol: Sembol
            execution_size: Execution boyutu
            execution_horizon: Execution zaman ufkı
            
        Returns:
            ExecutionImpact: Execution impact analysis
        """
        
        # Get hidden liquidity prediction
        impact_prediction = self.liquidity_analyzer.predict_hidden_liquidity_impact(
            symbol, execution_size, execution_horizon
        )
        
        # Calculate iceberg impact
        iceberg_impact = impact_prediction['execution_improvement']
        
        # Optimal slice adjustment
        optimal_adjustment = impact_prediction['execution_improvement'] * 0.5  # Conservative adjustment
        
        # Timing recommendation
        if iceberg_impact > 0.2:
            timing_rec = "Favourable conditions: Hidden liquidity detected, can increase execution pace"
        elif iceberg_impact > 0.1:
            timing_rec = "Moderate hidden liquidity: Standard execution with slight adjustments"
        else:
            timing_rec = "Limited hidden liquidity: Conservative execution recommended"
            
        # Risk adjustment
        risk_adjustment = impact_prediction['risk_adjustment']
        
        # Execution window
        current_time = datetime.now()
        execution_window = (current_time, current_time + execution_horizon)
        
        return ExecutionImpact(
            iceberg_impact_on_execution=iceberg_impact,
            optimal_slice_adjustment=optimal_adjustment,
            timing_recommendation=timing_rec,
            risk_adjustment=risk_adjustment,
            execution_window=execution_window
        )
        
    def get_detected_icebergs_summary(self, symbol: str) -> Dict:
        """
        Tespit edilen iceberg'lerin özetini getir
        
        Args:
            symbol: Sembol
            
        Returns:
            Dict: Icebergs summary
        """
        
        if symbol not in self.active_icebergs:
            return {'message': f'{symbol} için iceberg tespit verisi yok'}
            
        icebergs = self.active_icebergs[symbol]
        
        if not icebergs:
            return {'message': f'{symbol} için aktif iceberg yok'}
            
        # Summary statistics
        total_hidden = sum(order.estimated_hidden_quantity for order in icebergs)
        total_displayed = sum(order.displayed_quantity for order in icebergs)
        avg_confidence = np.mean([order.confidence_score for order in icebergs])
        
        # Pattern distribution
        pattern_counts = {}
        for order in icebergs:
            pattern_type = order.pattern_type
            pattern_counts[pattern_type] = pattern_counts.get(pattern_type, 0) + 1
            
        # Side distribution
        side_counts = {'BUY': 0, 'SELL': 0}
        for order in icebergs:
            side_counts[order.side] = side_counts.get(order.side, 0) + 1
            
        return {
            'total_icebergs': len(icebergs),
            'total_hidden_quantity': total_hidden,
            'total_displayed_quantity': total_displayed,
            'average_hidden_ratio': total_hidden / total_displayed if total_displayed > 0 else 0,
            'average_confidence': avg_confidence,
            'pattern_distribution': pattern_counts,
            'side_distribution': side_counts,
            'recent_icebergs': len([order for order in icebergs 
                                  if order.detected_time > datetime.now() - timedelta(hours=1)]),
            'most_confident_iceberg': max(icebergs, key=lambda x: x.confidence_score).__dict__ if icebergs else None
        }
        
    def get_integration_statistics(self) -> Dict:
        """
        Integration istatistiklerini getir
        
        Returns:
            Dict: Integration statistics
        """
        
        return {
            'total_symbols_tracked': len(self.active_icebergs),
            'total_icebergs_detected': sum(len(icebergs) for icebergs in self.active_icebergs.values()),
            'detection_confidence_avg': np.mean([
                np.mean([order.confidence_score for order in icebergs]) if icebergs else 0
                for icebergs in self.active_icebergs.values()
            ]) if self.active_icebergs else 0,
            'most_active_symbol': max(self.active_icebergs.keys(), 
                                    key=lambda k: len(self.active_icebergs[k])) if self.active_icebergs else None,
            'recent_detections': len([
                order for icebergs in self.active_icebergs.values()
                for order in icebergs
                if order.detected_time > datetime.now() - timedelta(hours=1)
            ])
        }
        
    def clear_iceberg_data(self, symbol: Optional[str] = None) -> None:
        """
        Iceberg verilerini temizle
        
        Args:
            symbol: Temizlenecek sembol (None ise hepsi)
        """
        
        if symbol:
            if symbol in self.active_icebergs:
                del self.active_icebergs[symbol]
            self.logger.info(f"Iceberg data temizlendi: {symbol}")
        else:
            self.active_icebergs.clear()
            self.logger.info("Tüm iceberg data temizlendi")