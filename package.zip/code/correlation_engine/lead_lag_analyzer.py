"""
Lead-Lag Analiz Sistemi
======================

Varlıklar arasındaki öncü-ardıl ilişkilerini analiz eden sistem.
Korelasyon ve Granger causality testleri ile lider-ardıl dinamiklerini tespit eder.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
from scipy import stats
from scipy.signal import correlate
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import warnings

try:
    from statsmodels.tsa.stattools import grangercausalitytests
    STATSMODELS_AVAILABLE = True
except ImportError:
    STATSMODELS_AVAILABLE = False
    warnings.warn("statsmodels not available. Granger causality tests will be disabled.")

class LeadLagAnalyzer:
    """
    Lead-Lag analiz sistemi
    
    Varlıklar arasındaki öncü-ardıl ilişkilerini analiz eder.
    Korelasyon analizi, cross-correlation ve Granger causality testleri yapar.
    """
    
    def __init__(self, 
                 lag_window: int = 48,
                 max_lag: int = 24,
                 significance_level: float = 0.05):
        """
        Lead-lag analiz sistemi başlatma
        
        Args:
            lag_window: Lag analizi penceresi
            max_lag: Maksimum lag değeri
            significance_level: İstatistiksel anlamlılık seviyesi
        """
        self.lag_window = lag_window
        self.max_lag = max_lag
        self.significance_level = significance_level
        
        # Analiz sonuçları
        self.lead_lag_cache = {}
        
    def analyze_lead_lag(self, 
                        series1: pd.Series, 
                        series2: pd.Series,
                        method: str = 'correlation') -> Dict[str, Any]:
        """
        İki seri arasında lead-lag analizi
        
        Args:
            series1: İlk zaman serisi
            series2: İkinci zaman serisi
            method: Analiz yöntemi ('correlation', 'granger', 'regression')
            
        Returns:
            Dict: Lead-lag analiz sonuçları
        """
        # Verileri hizala
        aligned_data = pd.DataFrame({
            's1': series1,
            's2': series2
        }).dropna()
        
        if len(aligned_data) < self.lag_window:
            return {
                'lag_periods': 0,
                'relationship': 'insufficient_data',
                'strength': 0.0,
                'confidence': 0.0
            }
        
        if method == 'correlation':
            return self._correlation_based_analysis(aligned_data['s1'], aligned_data['s2'])
        elif method == 'granger' and STATSMODELS_AVAILABLE:
            return self._granger_causality_analysis(aligned_data['s1'], aligned_data['s2'])
        elif method == 'regression':
            return self._regression_based_analysis(aligned_data['s1'], aligned_data['s2'])
        else:
            # Fallback to correlation
            return self._correlation_based_analysis(aligned_data['s1'], aligned_data['s2'])
    
    def _correlation_based_analysis(self, series1: pd.Series, series2: pd.Series) -> Dict[str, Any]:
        """Korelasyon tabanlı lead-lag analizi"""
        # Cross-correlation hesapla
        cross_corr = self._calculate_cross_correlation(series1, series2)
        
        # En yüksek korelasyonlu lag'i bul
        max_corr_idx = np.argmax(np.abs(cross_corr['correlation']))
        optimal_lag = cross_corr['lags'][max_corr_idx]
        max_correlation = cross_corr['correlation'][max_corr_idx]
        
        # Güven seviyesi hesapla
        confidence = self._calculate_correlation_confidence(max_correlation, len(series1))
        
        # İlişki türü belirle
        if optimal_lag > 0:
            relationship = 'series1_leads'
        elif optimal_lag < 0:
            relationship = 'series2_leads'
        else:
            relationship = 'simultaneous'
        
        return {
            'lag_periods': int(optimal_lag),
            'relationship': relationship,
            'strength': abs(max_correlation),
            'max_correlation': max_correlation,
            'confidence': confidence,
            'cross_correlation': cross_corr,
            'method': 'correlation'
        }
    
    def _granger_causality_analysis(self, series1: pd.Series, series2: pd.Series) -> Dict[str, Any]:
        """Granger causality tabanlı lead-lag analizi"""
        try:
            # Series1'in Series2'yi Granger cause etme testi
            data1_to_2 = pd.DataFrame({'y': series2, 'x': series1}).dropna()
            
            # Series2'nin Series1'i Granger cause etme testi
            data2_to_1 = pd.DataFrame({'y': series1, 'x': series2}).dropna()
            
            # Granger causality testleri
            gc_test_1_to_2 = grangercausalitytests(data1_to_2, maxlag=self.max_lag, verbose=False)
            gc_test_2_to_1 = grangercausalitytests(data2_to_1, maxlag=self.max_lag, verbose=False)
            
            # F-statistics ve p-values
            f_stats_1_to_2 = []
            p_values_1_to_2 = []
            f_stats_2_to_1 = []
            p_values_2_to_1 = []
            
            for lag in range(1, self.max_lag + 1):
                if lag in gc_test_1_to_2:
                    f_stat = gc_test_1_to_2[lag][0]['ssr_ftest'][0]
                    p_val = gc_test_1_to_2[lag][0]['ssr_ftest'][1]
                    f_stats_1_to_2.append(f_stat)
                    p_values_1_to_2.append(p_val)
                
                if lag in gc_test_2_to_1:
                    f_stat = gc_test_2_to_1[lag][0]['ssr_ftest'][0]
                    p_val = gc_test_2_to_1[lag][0]['ssr_ftest'][1]
                    f_stats_2_to_1.append(f_stat)
                    p_values_2_to_1.append(p_val)
            
            # En güçlü lag'i bul
            if f_stats_1_to_2 and f_stats_2_to_1:
                max_f_1_to_2_idx = np.argmax(f_stats_1_to_2)
                max_f_2_to_1_idx = np.argmax(f_stats_2_to_1)
                
                optimal_lag_1_to_2 = max_f_1_to_2_idx + 1
                optimal_lag_2_to_1 = max_f_2_to_1_idx + 1
                
                # İlişki belirleme
                if p_values_1_to_2[max_f_1_to_2_idx] < self.significance_level:
                    if p_values_2_to_1[max_f_2_to_1_idx] < self.significance_level:
                        # İki yönlü causality
                        relationship = 'bidirectional'
                        lag_periods = optimal_lag_1_to_2  # Daha güçlü olanı seç
                    else:
                        # Series1 -> Series2
                        relationship = 'series1_granger_causes'
                        lag_periods = optimal_lag_1_to_2
                elif p_values_2_to_1[max_f_2_to_1_idx] < self.significance_level:
                    # Series2 -> Series1
                    relationship = 'series2_granger_causes'
                    lag_periods = optimal_lag_2_to_1
                else:
                    # No significant causality
                    relationship = 'no_causality'
                    lag_periods = 0
                
                return {
                    'lag_periods': lag_periods,
                    'relationship': relationship,
                    'strength': max(max(f_stats_1_to_2), max(f_stats_2_to_1)) if f_stats_1_to_2 and f_stats_2_to_1 else 0,
                    'confidence': 1.0 - min(p_values_1_to_2 + p_values_2_to_1),
                    'f_statistics': {
                        'series1_to_series2': f_stats_1_to_2,
                        'series2_to_series1': f_stats_2_to_1
                    },
                    'p_values': {
                        'series1_to_series2': p_values_1_to_2,
                        'series2_to_series1': p_values_2_to_1
                    },
                    'method': 'granger_causality'
                }
            else:
                return self._correlation_based_analysis(series1, series2)
                
        except Exception as e:
            warnings.warn(f"Granger causality analysis failed: {str(e)}")
            return self._correlation_based_analysis(series1, series2)
    
    def _regression_based_analysis(self, series1: pd.Series, series2: pd.Series) -> Dict[str, Any]:
        """Regresyon tabanlı lead-lag analizi"""
        # Farklı lag değerleri için regression yap
        lag_results = {}
        
        for lag in range(-self.max_lag, self.max_lag + 1):
            if lag == 0:
                continue
            
            try:
                if lag > 0:
                    # Series1 lead, series2 lag
                    X = series1.iloc[:-lag].values.reshape(-1, 1)
                    y = series2.iloc[lag:].values
                else:
                    # Series2 lead, series1 lag
                    X = series2.iloc[:lag].values.reshape(-1, 1)
                    y = series1.iloc[-lag:].values
                
                if len(X) < 10:  # Yeterli veri yok
                    continue
                
                # Linear regression
                reg = LinearRegression()
                reg.fit(X, y)
                y_pred = reg.predict(X)
                
                # R-squared ve MSE
                r_squared = reg.score(X, y)
                mse = mean_squared_error(y, y_pred)
                
                lag_results[lag] = {
                    'r_squared': r_squared,
                    'mse': mse,
                    'coefficient': reg.coef_[0],
                    'intercept': reg.intercept_
                }
                
            except Exception as e:
                continue
        
        if not lag_results:
            return self._correlation_based_analysis(series1, series2)
        
        # En iyi lag'i bul (R-squared'e göre)
        best_lag = max(lag_results.keys(), key=lambda k: lag_results[k]['r_squared'])
        best_result = lag_results[best_lag]
        
        # İlişki belirleme
        if best_lag > 0:
            relationship = 'series1_leads'
        elif best_lag < 0:
            relationship = 'series2_leads'
        else:
            relationship = 'simultaneous'
        
        return {
            'lag_periods': int(best_lag),
            'relationship': relationship,
            'strength': best_result['r_squared'],
            'coefficient': best_result['coefficient'],
            'mse': best_result['mse'],
            'confidence': best_result['r_squared'],
            'all_lag_results': lag_results,
            'method': 'regression'
        }
    
    def _calculate_cross_correlation(self, series1: pd.Series, series2: pd.Series) -> Dict[str, Any]:
        """Cross-correlation hesapla"""
        # Normalize et
        s1_norm = (series1 - series1.mean()) / series1.std()
        s2_norm = (series2 - series2.mean()) / series2.std()
        
        # Cross-correlation hesapla
        correlation = correlate(s1_norm, s2_norm, mode='full')
        
        # Lag değerleri
        lags = np.arange(-len(s2_norm) + 1, len(s1_norm))
        
        # Sadece belirtilen aralığı al
        center = len(correlation) // 2
        start_idx = max(0, center - self.max_lag)
        end_idx = min(len(correlation), center + self.max_lag + 1)
        
        correlation = correlation[start_idx:end_idx]
        lags = lags[start_idx:end_idx]
        
        return {
            'correlation': correlation,
            'lags': lags,
            'max_correlation': np.max(np.abs(correlation)),
            'optimal_lag': lags[np.argmax(np.abs(correlation))]
        }
    
    def _calculate_correlation_confidence(self, correlation: float, sample_size: int) -> float:
        """Korelasyon güven seviyesini hesapla"""
        if sample_size < 3:
            return 0.0
        
        # Fisher z-transformation
        if abs(correlation) >= 1.0:
            return 1.0
        
        z_score = 0.5 * np.log((1 + correlation) / (1 - correlation))
        
        # Standard error
        se = 1 / np.sqrt(sample_size - 3)
        
        # Güven aralığı
        confidence_interval = 1.96 * se  # 95% güven
        
        return min(1.0, confidence_interval)
    
    def analyze_multiple_series(self, 
                              data: pd.DataFrame,
                              method: str = 'correlation') -> Dict[str, Dict[str, Any]]:
        """
        Birden fazla seri için lead-lag analizi
        
        Args:
            data: Varlık verileri DataFrame
            method: Analiz yöntemi
            
        Returns:
            Dict: Varlık çiftleri için lead-lag analizleri
        """
        assets = data.columns.tolist()
        results = {}
        
        for i, asset1 in enumerate(assets):
            for asset2 in assets[i+1:]:
                pair_key = f"{asset1}_{asset2}"
                
                # NaN değerleri temizle
                clean_data = data[[asset1, asset2]].dropna()
                
                if len(clean_data) < self.lag_window:
                    results[pair_key] = {
                        'lag_periods': 0,
                        'relationship': 'insufficient_data',
                        'strength': 0.0,
                        'confidence': 0.0
                    }
                    continue
                
                results[pair_key] = self.analyze_lead_lag(
                    clean_data[asset1], 
                    clean_data[asset2], 
                    method
                )
        
        return results
    
    def detect_causal_relationships(self, 
                                  data: pd.DataFrame,
                                  threshold_strength: float = 0.3) -> Dict[str, Dict[str, Any]]:
        """
        Causal ilişkileri tespit et
        
        Args:
            data: Varlık verileri
            threshold_strength: İlişki güç eşiği
            
        Returns:
            Dict: Causal ilişki analizi
        """
        results = self.analyze_multiple_series(data, method='correlation')
        
        # Causal ilişkileri filtrele
        causal_relationships = {}
        
        for pair_key, analysis in results.items():
            if analysis['strength'] >= threshold_strength:
                causal_relationships[pair_key] = {
                    'leader': analysis['relationship'],
                    'lag_periods': analysis['lag_periods'],
                    'strength': analysis['strength'],
                    'confidence': analysis['confidence'],
                    'is_causal': analysis['strength'] > 0.5 and analysis['confidence'] > 0.8
                }
        
        return causal_relationships
    
    def get_lead_lag_summary(self, 
                           data: pd.DataFrame,
                           method: str = 'correlation') -> Dict[str, Any]:
        """
        Lead-lag analizi özeti
        
        Args:
            data: Varlık verileri
            method: Analiz yöntemi
            
        Returns:
            Dict: Lead-lag analiz özeti
        """
        results = self.analyze_multiple_series(data, method)
        
        # İstatistikler
        lag_values = [r['lag_periods'] for r in results.values() if r['lag_periods'] != 0]
        strength_values = [r['strength'] for r in results.values()]
        confidence_values = [r['confidence'] for r in results.values()]
        
        summary = {
            'total_pairs': len(results),
            'significant_pairs': len([r for r in results.values() if r['strength'] > 0.3]),
            'lag_statistics': {
                'mean_lag': np.mean(lag_values) if lag_values else 0,
                'max_lead': max(lag_values) if lag_values else 0,
                'max_lag': min(lag_values) if lag_values else 0,
                'lag_distribution': pd.Series(lag_values).value_counts().to_dict() if lag_values else {}
            },
            'strength_statistics': {
                'mean_strength': np.mean(strength_values) if strength_values else 0,
                'max_strength': max(strength_values) if strength_values else 0,
                'min_strength': min(strength_values) if strength_values else 0
            },
            'confidence_statistics': {
                'mean_confidence': np.mean(confidence_values) if confidence_values else 0,
                'high_confidence_pairs': len([c for c in confidence_values if c > 0.8])
            },
            'relationship_types': self._categorize_relationships(results),
            'detailed_results': results
        }
        
        return summary
    
    def _categorize_relationships(self, results: Dict[str, Dict[str, Any]]) -> Dict[str, int]:
        """İlişki türlerini kategorize et"""
        categories = {
            'series1_leads': 0,
            'series2_leads': 0,
            'bidirectional': 0,
            'simultaneous': 0,
            'granger_causality': 0,
            'no_causality': 0,
            'insufficient_data': 0
        }
        
        for analysis in results.values():
            relationship = analysis['relationship']
            categories[relationship] = categories.get(relationship, 0) + 1
        
        return categories
    
    def create_lead_lag_matrix(self, data: pd.DataFrame) -> pd.DataFrame:
        """
        Lead-lag matris oluştur
        
        Args:
            data: Varlık verileri
            
        Returns:
            pd.DataFrame: Lead-lag matrisi
        """
        assets = data.columns.tolist()
        n_assets = len(assets)
        
        lag_matrix = np.zeros((n_assets, n_assets))
        
        for i, asset1 in enumerate(assets):
            for j, asset2 in enumerate(assets):
                if i != j:
                    try:
                        analysis = self.analyze_lead_lag(data[asset1], data[asset2])
                        lag_matrix[i, j] = analysis['lag_periods']
                    except:
                        lag_matrix[i, j] = 0
        
        return pd.DataFrame(lag_matrix, index=assets, columns=assets)
    
    def validate_lead_lag_relationship(self, 
                                     series1: pd.Series, 
                                     series2: pd.Series,
                                     lag_periods: int,
                                     method: str = 'correlation') -> Dict[str, Any]:
        """
        Lead-lag ilişkisini doğrula
        
        Args:
            series1: İlk seri
            series2: İkinci seri
            lag_periods: Test edilecek lag değeri
            method: Doğrulama yöntemi
            
        Returns:
            Dict: Doğrulama sonuçları
        """
        if lag_periods == 0:
            return {
                'validation': 'no_lag',
                'correlation': series1.corr(series2),
                'significant': False
            }
        
        # Lag uygula
        if lag_periods > 0:
            # Series1 leads series2
            lagged_series1 = series1.iloc[:-lag_periods]
            aligned_series2 = series2.iloc[lag_periods:]
        else:
            # Series2 leads series1
            lagged_series1 = series1.iloc[-lag_periods:]
            aligned_series2 = series2.iloc[:lag_periods]
        
        # Serileri hizala
        min_length = min(len(lagged_series1), len(aligned_series2))
        if min_length < 10:
            return {
                'validation': 'insufficient_data',
                'correlation': 0,
                'significant': False
            }
        
        lagged_series1 = lagged_series1.iloc[-min_length:]
        aligned_series2 = aligned_series2.iloc[-min_length:]
        
        # Korelasyon hesapla
        correlation = lagged_series1.corr(aligned_series2)
        
        # İstatistiksel anlamlılık
        if len(lagged_series1) > 2:
            t_stat = correlation * np.sqrt((len(lagged_series1) - 2) / (1 - correlation**2))
            p_value = 2 * (1 - stats.t.cdf(abs(t_stat), len(lagged_series1) - 2))
            significant = p_value < self.significance_level
        else:
            significant = False
        
        return {
            'validation': 'validated' if significant else 'weak',
            'correlation': correlation,
            'lag_tested': lag_periods,
            'significant': significant,
            'p_value': p_value if 'p_value' in locals() else None,
            'sample_size': min_length,
            'direction': 'series1_leads' if lag_periods > 0 else 'series2_leads'
        }