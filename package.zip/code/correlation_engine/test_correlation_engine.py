"""
Korelasyon Analizi Motoru - Testler
==================================

Motorun tüm bileşenlerini test eden test sınıfları.
"""

import unittest
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import asyncio

from correlation_engine import (
    CorrelationEngine,
    RollingCorrelation,
    RegimeDetector,
    CorrelationClusterer,
    LeadLagAnalyzer,
    AlertSystem
)

class TestRollingCorrelation(unittest.TestCase):
    """Rolling correlation testleri"""
    
    def setUp(self):
        """Test verilerini hazırla"""
        np.random.seed(42)
        
        # Zaman serisi oluştur
        dates = pd.date_range(start='2023-01-01', periods=100, freq='H')
        
        # İlişkili seriler
        series1 = pd.Series(np.random.normal(0, 0.02, 100), index=dates)
        series2 = series1 * 0.8 + pd.Series(np.random.normal(0, 0.01, 100), index=dates)
        
        self.series1 = series1
        self.series2 = series2
        self.roller = RollingCorrelation(window_size=24)
    
    def test_basic_rolling_correlation(self):
        """Temel rolling correlation testi"""
        result = self.roller.calculate(self.series1, self.series2)
        
        self.assertIsInstance(result, pd.Series)
        self.assertGreater(len(result.dropna()), 0)
        self.assertTrue(all(abs(x) <= 1.0 for x in result.dropna() if not pd.isna(x)))
    
    def test_exponential_weighted(self):
        """Exponential weighted correlation testi"""
        result = self.roller.calculate_exponential_weighted(self.series1, self.series2)
        
        self.assertIsInstance(result, pd.Series)
        self.assertTrue(len(result.dropna()) > 0)
    
    def test_volatility_adjusted(self):
        """Volatilite düzeltmeli correlation testi"""
        result = self.roller.calculate_volatility_adjusted(self.series1, self.series2)
        
        self.assertIsInstance(result, pd.Series)
        # Volatilite düzeltilmiş korelasyon normal korelasyondan farklı olmalı
    
    def test_multiple_windows(self):
        """Çoklu pencere testi"""
        windows = [6, 12, 24, 48]
        result = self.roller.calculate_multiple_windows(self.series1, self.series2, windows)
        
        self.assertEqual(len(result), len(windows))
        for window in windows:
            self.assertIn(window, result)
            self.assertIsInstance(result[window], pd.Series)

class TestRegimeDetector(unittest.TestCase):
    """Rejim tespit sistemi testleri"""
    
    def setUp(self):
        """Test verilerini hazırla"""
        np.random.seed(42)
        
        # Rejim değişimi olan veri oluştur
        n = 200
        dates = pd.date_range(start='2023-01-01', periods=n, freq='H')
        
        # İlk yarısında yüksek korelasyon, ikinci yarısında düşük korelasyon
        base_series = np.random.normal(0, 0.02, n)
        correlation_series = np.concatenate([
            base_series[:n//2] + np.random.normal(0, 0.005, n//2),  # Yüksek korelasyon
            base_series[n//2:] + np.random.normal(0, 0.02, n//2)   # Düşük korelasyon
        ])
        
        self.correlation_series = pd.Series(correlation_series, index=dates)
        self.detector = RegimeDetector(detection_threshold=0.1)
    
    def test_regime_detection(self):
        """Rejim tespiti testi"""
        regime = self.detector.detect_regime(self.correlation_series)
        
        self.assertIsInstance(regime, str)
        self.assertNotEqual(regime, 'insufficient_data')
    
    def test_regime_changes(self):
        """Rejim değişim tespiti testi"""
        changes = self.detector.detect_regime_changes(self.correlation_series)
        
        self.assertIsInstance(changes, list)
        # En az bir rejim değişimi olmalı (veri yapısı gereği)
    
    def test_regime_stability(self):
        """Rejim stabilitesi testi"""
        stability = self.detector.calculate_regime_stability(self.correlation_series)
        
        self.assertIsInstance(stability, float)
        self.assertGreaterEqual(stability, 0.0)
        self.assertLessEqual(stability, 1.0)

class TestCorrelationClusterer(unittest.TestCase):
    """Korelasyon kümeleme testleri"""
    
    def setUp(self):
        """Test verilerini hazırla"""
        np.random.seed(42)
        
        # Korelasyon matrisi oluştur
        n_assets = 5
        correlation_data = np.random.uniform(-1, 1, (n_assets, n_assets))
        correlation_data = (correlation_data + correlation_data.T) / 2
        np.fill_diagonal(correlation_data, 1.0)
        
        assets = [f"ASSET_{i}" for i in range(n_assets)]
        self.correlation_matrix = pd.DataFrame(correlation_data, index=assets, columns=assets)
        
        self.clusterer = CorrelationClusterer(clustering_threshold=0.5)
    
    def test_hierarchical_clustering(self):
        """Hiyerarşik kümeleme testi"""
        clusters = self.clusterer.cluster_assets(
            self.correlation_matrix, 
            method='hierarchical'
        )
        
        self.assertIsInstance(clusters, dict)
        self.assertGreater(len(clusters), 0)
        
        # Tüm varlıklar bir kümede olmalı
        all_assets = set(self.correlation_matrix.index)
        clustered_assets = set()
        for assets in clusters.values():
            clustered_assets.update(assets)
        
        self.assertEqual(all_assets, clustered_assets)
    
    def test_graph_clustering(self):
        """Graf tabanlı kümeleme testi"""
        clusters = self.clusterer.cluster_assets(
            self.correlation_matrix,
            method='graph'
        )
        
        self.assertIsInstance(clusters, dict)
        self.assertGreater(len(clusters), 0)
    
    def test_cluster_characteristics(self):
        """Küme karakteristikleri testi"""
        clusters = self.clusterer.cluster_assets(self.correlation_matrix)
        characteristics = self.clusterer.analyze_cluster_characteristics(
            self.correlation_matrix, 
            clusters
        )
        
        self.assertIsInstance(characteristics, dict)
        
        for cluster_name, chars in characteristics.items():
            self.assertIn('size', chars)
            self.assertIn('avg_internal_correlation', chars)
            self.assertIn('cohesion_score', chars)

class TestLeadLagAnalyzer(unittest.TestCase):
    """Lead-lag analiz testleri"""
    
    def setUp(self):
        """Test verilerini hazırla"""
        np.random.seed(42)
        
        n = 100
        dates = pd.date_range(start='2023-01-01', periods=n, freq='H')
        
        # Asset1 lead, asset2 lag olan veri
        series1 = pd.Series(np.random.normal(0, 0.02, n), index=dates)
        series2 = pd.Series(np.zeros(n), index=dates)
        
        # 3 saat lag ile asset2
        for i in range(3, n):
            series2.iloc[i] = 0.7 * series1.iloc[i-3] + np.random.normal(0, 0.01, 1)[0]
        
        self.series1 = series1
        self.series2 = series2
        self.analyzer = LeadLagAnalyzer(lag_window=48, max_lag=12)
    
    def test_lead_lag_analysis(self):
        """Lead-lag analizi testi"""
        result = self.analyzer.analyze_lead_lag(self.series1, self.series2)
        
        self.assertIsInstance(result, dict)
        self.assertIn('lag_periods', result)
        self.assertIn('relationship', result)
        self.assertIn('strength', result)
        
        # Lag periyotları pozitif olmalı (series1 leads)
        self.assertGreater(result['lag_periods'], 0)
    
    def test_multiple_series_analysis(self):
        """Çoklu seri analizi testi"""
        data = pd.DataFrame({
            'asset1': self.series1,
            'asset2': self.series2,
            'asset3': pd.Series(np.random.normal(0, 0.02, 100), index=self.series1.index)
        })
        
        results = self.analyzer.analyze_multiple_series(data)
        
        self.assertIsInstance(results, dict)
        # 3 varlık = 3 çift olmalı
        expected_pairs = 3
        self.assertGreaterEqual(len(results), expected_pairs // 2)

class TestAlertSystem(unittest.TestCase):
    """Alert sistemi testleri"""
    
    def setUp(self):
        """Test setup"""
        self.alert_thresholds = {
            'high_correlation': 0.8,
            'correlation_breakdown': 0.3,
            'regime_change': 0.15
        }
        
        self.alert_system = AlertSystem(
            alert_thresholds=self.alert_thresholds,
            max_alerts_per_hour=5,
            cooldown_period=60
        )
        
        # Test callback
        self.callback_called = False
        self.last_alert = None
        
        def test_callback(alert):
            self.callback_called = True
            self.last_alert = alert
        
        self.alert_system.set_callback(test_callback)
    
    def test_alert_callback(self):
        """Alert callback testi"""
        # Mock metrics oluştur
        class MockMetrics:
            def __init__(self):
                self.last_update = datetime.now()
        
        metrics = MockMetrics()
        alerts = self.alert_system.check_alerts(metrics)
        
        # Callback çağrılmış olmalı
        self.assertTrue(self.callback_called or len(alerts) >= 0)
    
    def test_rate_limiting(self):
        """Rate limiting testi"""
        # Birden fazla alert gönder
        for i in range(10):
            alert = self.alert_system._create_test_alert(f"test_{i}")
            self.alert_system._process_alerts([alert])
        
        # Rate limiting çalışmalı
        stats = self.alert_system.get_alert_statistics()
        self.assertIsInstance(stats, dict)

class TestCorrelationEngine(unittest.TestCase):
    """Ana korelasyon motoru testleri"""
    
    def setUp(self):
        """Test verilerini hazırla"""
        np.random.seed(42)
        
        # Motor oluştur
        self.engine = CorrelationEngine(
            window_size=24,
            regime_detection_threshold=0.1,
            clustering_threshold=0.6
        )
        
        # Test verisi oluştur
        self.test_data = self._create_test_data(3, 50)
        
        # Verileri ekle
        for asset, df in self.test_data.items():
            self.engine.add_asset_data(asset, df)
    
    def _create_test_data(self, n_assets, n_periods):
        """Test verisi oluştur"""
        data = {}
        start_date = datetime(2023, 1, 1)
        
        for i in range(n_assets):
            asset_name = f"TEST_{i}"
            
            # Returns oluştur
            returns = np.random.normal(0, 0.02, n_periods)
            
            # Fiyat serisi
            prices = [100.0]
            for ret in returns[1:]:
                new_price = prices[-1] * (1 + ret)
                prices.append(new_price)
            
            # DataFrame oluştur
            timestamps = [start_date + timedelta(hours=h) for h in range(n_periods)]
            df = pd.DataFrame({
                'price': prices,
                'volume': np.random.uniform(1000, 10000, n_periods),
                'high': [p * 1.02 for p in prices],
                'low': [p * 0.98 for p in prices],
                'open': prices
            }, index=timestamps)
            
            data[asset_name] = df
        
        return data
    
    def test_add_asset_data(self):
        """Varlık verisi ekleme testi"""
        initial_count = len(self.engine.returns_data)
        
        # Yeni varlık ekle
        new_asset = "NEW_TEST"
        new_data = self._create_test_data(1, 30)[new_asset]
        self.engine.add_asset_data(new_asset, new_data)
        
        self.assertEqual(len(self.engine.returns_data), initial_count + 1)
        self.assertIn(new_asset, self.engine.returns_data)
    
    def test_remove_asset(self):
        """Varlık kaldırma testi"""
        initial_count = len(self.engine.returns_data)
        asset_to_remove = list(self.test_data.keys())[0]
        
        self.engine.remove_asset(asset_to_remove)
        
        self.assertEqual(len(self.engine.returns_data), initial_count - 1)
        self.assertNotIn(asset_to_remove, self.engine.returns_data)
    
    def test_analyze_correlations(self):
        """Korelasyon analizi testi"""
        metrics = self.engine.analyze_correlations()
        
        self.assertIsNotNone(metrics)
        self.assertTrue(hasattr(metrics, 'correlation_matrix'))
        self.assertTrue(hasattr(metrics, 'last_update'))
        
        # Korelasyon matrisi boyutu doğru olmalı
        expected_size = len(self.test_data)
        self.assertEqual(metrics.correlation_matrix.shape, (expected_size, expected_size))
    
    def test_get_correlation_trend(self):
        """Korelasyon trendi testi"""
        asset1, asset2 = list(self.test_data.keys())[:2]
        
        trend = self.engine.get_correlation_trend(asset1, asset2, periods=24)
        
        self.assertIsInstance(trend, dict)
        self.assertIn('current_correlation', trend)
        self.assertIn('mean_correlation', trend)
        self.assertIn('regime', trend)
    
    def test_real_time_correlation_matrix(self):
        """Real-time korelasyon matrisi testi"""
        matrix = self.engine.get_real_time_correlation_matrix()
        
        self.assertIsNotNone(matrix)
        self.assertIsInstance(matrix, pd.DataFrame)
        self.assertEqual(matrix.shape[0], matrix.shape[1])  # Kare matris
        self.assertTrue(all(matrix.iloc[i, i] == 1.0 for i in range(len(matrix))))  # Diagonal = 1
    
    def test_get_correlation_summary(self):
        """Korelasyon özeti testi"""
        # Önce analiz yap
        self.engine.analyze_correlations()
        
        summary = self.engine.get_correlation_summary()
        
        self.assertIsInstance(summary, dict)
        self.assertIn('total_assets', summary)
        self.assertIn('average_correlation', summary)
        self.assertGreater(summary['total_assets'], 0)

class TestIntegration(unittest.TestCase):
    """Entegrasyon testleri"""
    
    def test_full_workflow(self):
        """Tam iş akışı testi"""
        # Veri oluştur
        np.random.seed(42)
        data = self._create_integration_data(4, 100)
        
        # Motor oluştur
        engine = CorrelationEngine(
            window_size=24,
            regime_detection_threshold=0.1,
            clustering_threshold=0.6
        )
        
        # Verileri ekle
        for asset, df in data.items():
            engine.add_asset_data(asset, df)
        
        # Analiz yap
        metrics = engine.analyze_correlations()
        self.assertIsNotNone(metrics)
        
        # Trend analizi
        assets = list(data.keys())
        for i in range(len(assets)):
            for j in range(i+1, len(assets)):
                trend = engine.get_correlation_trend(assets[i], assets[j])
                self.assertIsInstance(trend, dict)
        
        # Özet al
        summary = engine.get_correlation_summary()
        self.assertIsInstance(summary, dict)
    
    def _create_integration_data(self, n_assets, n_periods):
        """Entegrasyon test verisi"""
        data = {}
        start_date = datetime(2023, 1, 1)
        
        for i in range(n_assets):
            asset_name = f"INTEG_{i}"
            
            # Korelasyonlu veri oluştur
            base_returns = np.random.normal(0, 0.02, n_periods)
            
            if i > 0:
                # Önceki varlıklarla korelasyon
                for j in range(i):
                    corr_asset = f"INTEG_{j}"
                    if corr_asset in data:
                        prev_returns = data[corr_asset]['returns']
                        correlation = np.random.uniform(0.2, 0.7)
                        base_returns += correlation * prev_returns * 0.3
            
            # Fiyat serisi
            prices = [100.0]
            for ret in base_returns[1:]:
                new_price = prices[-1] * (1 + ret)
                prices.append(new_price)
            
            # DataFrame
            timestamps = [start_date + timedelta(hours=h) for h in range(n_periods)]
            df = pd.DataFrame({
                'price': prices,
                'returns': base_returns,
                'volume': np.random.uniform(1000, 10000, n_periods)
            }, index=timestamps)
            
            data[asset_name] = df
        
        return data

if __name__ == '__main__':
    # Test suite çalıştır
    unittest.main(verbosity=2)