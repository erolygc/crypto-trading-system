"""
Real-time Alert Sistemi
=======================

Korelasyon değişiklikleri için real-time uyarı sistemi.
Threshold aşımı, rejim değişimleri ve anomalileri tespit eder.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any, Callable
from datetime import datetime, timedelta
import json
import asyncio
from dataclasses import dataclass
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

@dataclass
class Alert:
    """Uyarı veri yapısı"""
    id: str
    timestamp: datetime
    alert_type: str
    severity: str
    title: str
    message: str
    data: Dict[str, Any]
    acknowledged: bool = False
    acknowledged_by: str = None
    acknowledged_at: datetime = None

class AlertSystem:
    """
    Real-time uyarı sistemi
    
    Korelasyon analizi sonuçlarını izler ve belirlenen eşikleri aşan
    durumlar için uyarılar üretir.
    """
    
    def __init__(self, 
                 alert_thresholds: Dict[str, float],
                 max_alerts_per_hour: int = 10,
                 cooldown_period: int = 300,  # 5 dakika
                 alert_history_size: int = 1000):
        """
        Alert sistemi başlatma
        
        Args:
            alert_thresholds: Uyarı eşikleri
            max_alerts_per_hour: Saatlik maksimum uyarı sayısı
            cooldown_period: Uyarı arası bekleme süresi (saniye)
            alert_history_size: Uyarı geçmişi boyutu
        """
        self.alert_thresholds = alert_thresholds
        self.max_alerts_per_hour = max_alerts_per_hour
        self.cooldown_period = cooldown_period
        self.alert_history_size = alert_history_size
        
        # Uyarı yönetimi
        self.active_alerts: Dict[str, Alert] = {}
        self.alert_history: List[Alert] = []
        self.alert_counters: Dict[str, int] = {}
        self.last_alert_times: Dict[str, datetime] = {}
        
        # Callback fonksiyonları
        self.alert_callbacks: List[Callable] = []
        self.email_callback: Optional[Callable] = None
        
        # Alert filter
        self.suppressed_alerts: Set[str] = set()
        self.severity_filters: Dict[str, bool] = {
            'critical': True,
            'high': True,
            'medium': True,
            'low': True
        }
        
        # Logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
    def set_callback(self, callback: Callable[[Alert], None]):
        """Alert callback fonksiyonu ayarla"""
        self.alert_callbacks.append(callback)
    
    def set_email_callback(self, 
                          smtp_server: str,
                          smtp_port: int,
                          username: str,
                          password: str,
                          recipients: List[str]):
        """Email alert callback ayarla"""
        self.email_callback = {
            'smtp_server': smtp_server,
            'smtp_port': smtp_port,
            'username': username,
            'password': password,
            'recipients': recipients
        }
    
    def check_alerts(self, metrics) -> List[Alert]:
        """
        Korelasyon metriklerini kontrol et ve uyarılar üret
        
        Args:
            metrics: CorrelationMetrics objesi
            
        Returns:
            List[Alert]: Üretilen uyarılar
        """
        alerts = []
        
        try:
            # Rate limiting kontrolü
            if self._is_rate_limited():
                return alerts
            
            # Korelasyon matrisi uyarıları
            alerts.extend(self._check_correlation_matrix_alerts(metrics))
            
            # Rolling correlation uyarıları
            alerts.extend(self._check_rolling_correlation_alerts(metrics))
            
            # Rejim değişim uyarıları
            alerts.extend(self._check_regime_change_alerts(metrics))
            
            # Küme değişim uyarıları
            alerts.extend(self._check_cluster_change_alerts(metrics))
            
            # Lead-lag uyarıları
            alerts.extend(self._check_lead_lag_alerts(metrics))
            
            # Korelasyon breakdown uyarıları
            alerts.extend(self._check_correlation_breakdown_alerts(metrics))
            
            # Volatilite uyarıları
            alerts.extend(self._check_volatility_alerts(metrics))
            
            # Uyarıları işle
            processed_alerts = self._process_alerts(alerts)
            
            return processed_alerts
            
        except Exception as e:
            self.logger.error(f"Alert check error: {str(e)}")
            return []
    
    def check_real_time_alerts(self, metrics) -> List[Alert]:
        """
        Real-time alert kontrolü
        
        Args:
            metrics: CorrelationMetrics objesi
            
        Returns:
            List[Alert]: Real-time uyarılar
        """
        # Sadece kritik uyarıları kontrol et
        critical_alerts = []
        
        try:
            # Yüksek korelasyon uyarısı
            if hasattr(metrics, 'correlation_matrix') and metrics.correlation_matrix is not None:
                high_corr_alerts = self._check_high_correlation_realtime(metrics.correlation_matrix)
                critical_alerts.extend(high_corr_alerts)
            
            # Korelasyon breakdown uyarısı
            if hasattr(metrics, 'breakdown_alerts') and metrics.breakdown_alerts:
                breakdown_alerts = self._check_urgent_breakdown_alerts(metrics.breakdown_alerts)
                critical_alerts.extend(breakdown_alerts)
            
            # Rejim değişim uyarısı
            if hasattr(metrics, 'regime_info') and metrics.regime_info:
                regime_alerts = self._check_urgent_regime_alerts(metrics.regime_info)
                critical_alerts.extend(regime_alerts)
            
            # Rate limiting uygula
            filtered_alerts = []
            for alert in critical_alerts:
                if self._should_send_alert(alert):
                    filtered_alerts.append(alert)
            
            return filtered_alerts
            
        except Exception as e:
            self.logger.error(f"Real-time alert check error: {str(e)}")
            return []
    
    def _check_correlation_matrix_alerts(self, metrics) -> List[Alert]:
        """Korelasyon matrisi uyarılarını kontrol et"""
        alerts = []
        
        if not hasattr(metrics, 'correlation_matrix') or metrics.correlation_matrix is None:
            return alerts
        
        corr_matrix = metrics.correlation_matrix
        
        # Yüksek korelasyon uyarısı
        high_corr_threshold = self.alert_thresholds.get('high_correlation', 0.8)
        
        for i, asset1 in enumerate(corr_matrix.index):
            for j, asset2 in enumerate(corr_matrix.columns):
                if i < j:  # Üst üçgen
                    correlation = corr_matrix.iloc[i, j]
                    
                    if abs(correlation) > high_corr_threshold:
                        severity = 'high' if abs(correlation) > 0.9 else 'medium'
                        
                        alert = Alert(
                            id=f"high_corr_{asset1}_{asset2}_{datetime.now().timestamp()}",
                            timestamp=datetime.now(),
                            alert_type='high_correlation',
                            severity=severity,
                            title=f"Yüksek Korelasyon Tespit Edildi: {asset1} - {asset2}",
                            message=f"{asset1} ve {asset2} arasında {correlation:.3f} korelasyon tespit edildi (eşik: {high_corr_threshold})",
                            data={
                                'asset1': asset1,
                                'asset2': asset2,
                                'correlation': correlation,
                                'threshold': high_corr_threshold
                            }
                        )
                        alerts.append(alert)
        
        # Düşük korelasyon uyarısı
        low_corr_threshold = self.alert_thresholds.get('low_correlation', 0.1)
        
        for i, asset1 in enumerate(corr_matrix.index):
            for j, asset2 in enumerate(corr_matrix.columns):
                if i < j:  # Üst üçgen
                    correlation = corr_matrix.iloc[i, j]
                    
                    if abs(correlation) < low_corr_threshold:
                        alert = Alert(
                            id=f"low_corr_{asset1}_{asset2}_{datetime.now().timestamp()}",
                            timestamp=datetime.now(),
                            alert_type='low_correlation',
                            severity='low',
                            title=f"Düşük Korelasyon: {asset1} - {asset2}",
                            message=f"{asset1} ve {asset2} arasında {correlation:.3f} korelasyon tespit edildi (eşik: {low_corr_threshold})",
                            data={
                                'asset1': asset1,
                                'asset2': asset2,
                                'correlation': correlation,
                                'threshold': low_corr_threshold
                            }
                        )
                        alerts.append(alert)
        
        return alerts
    
    def _check_rolling_correlation_alerts(self, metrics) -> List[Alert]:
        """Rolling correlation uyarılarını kontrol et"""
        alerts = []
        
        if not hasattr(metrics, 'rolling_correlations') or not metrics.rolling_correlations:
            return alerts
        
        for asset1, corr_dict in metrics.rolling_correlations.items():
            for asset2, rolling_corr in corr_dict.items():
                if len(rolling_corr) < 24:  # Yeterli veri yok
                    continue
                
                # Son 24 saatlik korelasyon değişimi
                recent_corr = rolling_corr.tail(24)
                historical_corr = rolling_corr.head(-24)
                
                if len(historical_corr) > 0:
                    correlation_change = abs(recent_corr.mean() - historical_corr.mean())
                    
                    change_threshold = self.alert_thresholds.get('correlation_change', 0.2)
                    
                    if correlation_change > change_threshold:
                        severity = 'high' if correlation_change > 0.5 else 'medium'
                        
                        alert = Alert(
                            id=f"corr_change_{asset1}_{asset2}_{datetime.now().timestamp()}",
                            timestamp=datetime.now(),
                            alert_type='correlation_change',
                            severity=severity,
                            title=f"Korelasyon Değişimi: {asset1} - {asset2}",
                            message=f"{asset1} ve {asset2} arasında son 24 saatte {correlation_change:.3f} korelasyon değişimi tespit edildi",
                            data={
                                'asset1': asset1,
                                'asset2': asset2,
                                'correlation_change': correlation_change,
                                'recent_avg': recent_corr.mean(),
                                'historical_avg': historical_corr.mean(),
                                'threshold': change_threshold
                            }
                        )
                        alerts.append(alert)
        
        return alerts
    
    def _check_regime_change_alerts(self, metrics) -> List[Alert]:
        """Rejim değişim uyarılarını kontrol et"""
        alerts = []
        
        if not hasattr(metrics, 'regime_info') or not metrics.regime_info:
            return alerts
        
        regime_threshold = self.alert_thresholds.get('regime_change', 0.15)
        
        for pair_key, regime_data in metrics.regime_info.items():
            if 'stability' in regime_data:
                stability = regime_data['stability']
                
                if stability < regime_threshold:
                    current_regime = regime_data.get('regime', 'unknown')
                    
                    alert = Alert(
                        id=f"regime_change_{pair_key}_{datetime.now().timestamp()}",
                        timestamp=datetime.now(),
                        alert_type='regime_change',
                        severity='medium',
                        title=f"Korelasyon Rejim Değişimi: {pair_key}",
                        message=f"{pair_key} çiftinde rejim değişimi tespit edildi. Mevcut rejim: {current_regime}, stabilite: {stability:.3f}",
                        data={
                            'pair': pair_key,
                            'current_regime': current_regime,
                            'stability': stability,
                            'threshold': regime_threshold
                        }
                    )
                    alerts.append(alert)
        
        return alerts
    
    def _check_cluster_change_alerts(self, metrics) -> List[Alert]:
        """Küme değişim uyarılarını kontrol et"""
        alerts = []
        
        if not hasattr(metrics, 'clusters') or not metrics.clusters:
            return alerts
        
        cluster_threshold = self.alert_thresholds.get('cluster_membership_change', 0.2)
        
        # Son kümeleme sonucunu kaydet (basit implementasyon)
        current_clusters = metrics.clusters
        
        for cluster_name, assets in current_clusters.items():
            if len(assets) > 1:
                # Küme içi ortalama korelasyon
                cluster_corrs = []
                for i, asset1 in enumerate(assets):
                    for asset2 in assets[i+1:]:
                        if hasattr(metrics, 'correlation_matrix'):
                            corr = metrics.correlation_matrix.loc[asset1, asset2]
                            cluster_corrs.append(abs(corr))
                
                if cluster_corrs:
                    avg_corr = np.mean(cluster_corrs)
                    
                    if avg_corr < cluster_threshold:
                        alert = Alert(
                            id=f"cluster_cohesion_{cluster_name}_{datetime.now().timestamp()}",
                            timestamp=datetime.now(),
                            alert_type='cluster_cohesion',
                            severity='low',
                            title=f"Düşük Küme Uyumu: {cluster_name}",
                            message=f"{cluster_name} kümesindeki varlıklar arası ortalama korelasyon {avg_corr:.3f} (eşik: {cluster_threshold})",
                            data={
                                'cluster': cluster_name,
                                'assets': assets,
                                'avg_correlation': avg_corr,
                                'threshold': cluster_threshold
                            }
                        )
                        alerts.append(alert)
        
        return alerts
    
    def _check_lead_lag_alerts(self, metrics) -> List[Alert]:
        """Lead-lag uyarılarını kontrol et"""
        alerts = []
        
        if not hasattr(metrics, 'lead_lag_relations') or not metrics.lead_lag_relations:
            return alerts
        
        for pair_key, lead_lag_data in metrics.lead_lag_relations.items():
            lag_periods = lead_lag_data.get('lag_periods', 0)
            
            # Büyük lag değişiklikleri
            if abs(lag_periods) > 12:  # 12 saatten fazla
                severity = 'high' if abs(lag_periods) > 24 else 'medium'
                
                alert = Alert(
                    id=f"lead_lag_change_{pair_key}_{datetime.now().timestamp()}",
                    timestamp=datetime.now(),
                    alert_type='lead_lag_change',
                    severity=severity,
                    title=f"Lead-Lag Değişimi: {pair_key}",
                    message=f"{pair_key} çiftinde {lag_periods} saatlik lead-lag ilişkisi tespit edildi",
                    data={
                        'pair': pair_key,
                        'lag_periods': lag_periods,
                        'relationship': lead_lag_data.get('relationship', 'unknown')
                    }
                )
                alerts.append(alert)
        
        return alerts
    
    def _check_correlation_breakdown_alerts(self, metrics) -> List[Alert]:
        """Korelasyon breakdown uyarılarını kontrol et"""
        alerts = []
        
        if not hasattr(metrics, 'breakdown_alerts') or not metrics.breakdown_alerts:
            return alerts
        
        breakdown_threshold = self.alert_thresholds.get('correlation_breakdown', 0.3)
        
        for breakdown in metrics.breakdown_alerts:
            change = breakdown.get('change', 0)
            
            if change > breakdown_threshold:
                severity = breakdown.get('severity', 'medium')
                
                alert = Alert(
                    id=f"breakdown_{breakdown['asset1']}_{breakdown['asset2']}_{datetime.now().timestamp()}",
                    timestamp=datetime.now(),
                    alert_type='correlation_breakdown',
                    severity=severity,
                    title=f"Korelasyon Kırılması: {breakdown['asset1']} - {breakdown['asset2']}",
                    message=f"{breakdown['asset1']} ve {breakdown['asset2']} arasında {change:.3f} korelasyon kırılması tespit edildi",
                    data=breakdown
                )
                alerts.append(alert)
        
        return alerts
    
    def _check_volatility_alerts(self, metrics) -> List[Alert]:
        """Volatilite uyarılarını kontrol et"""
        alerts = []
        
        if not hasattr(metrics, 'volatility_adjusted') or metrics.volatility_adjusted is None:
            return alerts
        
        vol_adj_corr = metrics.volatility_adjusted
        
        # Volatilite-adjusted korelasyon anormallikleri
        for i, asset1 in enumerate(vol_adj_corr.index):
            for j, asset2 in enumerate(vol_adj_corr.columns):
                if i < j:
                    vol_corr = vol_adj_corr.iloc[i, j]
                    
                    # Aşırı volatilite-adjusted korelasyon
                    if abs(vol_corr) > 0.9:
                        alert = Alert(
                            id=f"vol_high_corr_{asset1}_{asset2}_{datetime.now().timestamp()}",
                            timestamp=datetime.now(),
                            alert_type='volatile_correlation',
                            severity='medium',
                            title=f"Yüksek Volatilite-Adjusted Korelasyon: {asset1} - {asset2}",
                            message=f"{asset1} ve {asset2} arasında volatilite-düzeltilmiş korelasyon {vol_corr:.3f}",
                            data={
                                'asset1': asset1,
                                'asset2': asset2,
                                'vol_adjusted_correlation': vol_corr
                            }
                        )
                        alerts.append(alert)
        
        return alerts
    
    # Real-time specific alert methods
    def _check_high_correlation_realtime(self, corr_matrix: pd.DataFrame) -> List[Alert]:
        """Real-time yüksek korelasyon uyarısı"""
        alerts = []
        high_corr_threshold = 0.85
        
        for i, asset1 in enumerate(corr_matrix.index):
            for j, asset2 in enumerate(corr_matrix.columns):
                if i < j:
                    correlation = corr_matrix.iloc[i, j]
                    
                    if abs(correlation) > high_corr_threshold:
                        alert = Alert(
                            id=f"realtime_high_corr_{asset1}_{asset2}_{datetime.now().timestamp()}",
                            timestamp=datetime.now(),
                            alert_type='critical_correlation',
                            severity='critical',
                            title=f"URGENT: Yüksek Korelasyon - {asset1} - {asset2}",
                            message=f"URGENT: {asset1} ve {asset2} arasında {correlation:.3f} korelasyon!",
                            data={
                                'asset1': asset1,
                                'asset2': asset2,
                                'correlation': correlation,
                                'alert_level': 'realtime'
                            }
                        )
                        alerts.append(alert)
        
        return alerts
    
    def _check_urgent_breakdown_alerts(self, breakdown_alerts: List[Dict[str, Any]]) -> List[Alert]:
        """Acil breakdown uyarıları"""
        alerts = []
        
        for breakdown in breakdown_alerts:
            if breakdown.get('severity') == 'high':
                alert = Alert(
                    id=f"urgent_breakdown_{breakdown['asset1']}_{breakdown['asset2']}_{datetime.now().timestamp()}",
                    timestamp=datetime.now(),
                    alert_type='urgent_breakdown',
                    severity='critical',
                    title=f"URGENT: Korelasyon Kırılması - {breakdown['asset1']} - {breakdown['asset2']}",
                    message=f"URGENT: {breakdown['asset1']} ve {breakdown['asset2']} arasında büyük korelasyon değişimi!",
                    data=breakdown
                )
                alerts.append(alert)
        
        return alerts
    
    def _check_urgent_regime_alerts(self, regime_info: Dict[str, Any]) -> List[Alert]:
        """Acil rejim değişim uyarıları"""
        alerts = []
        
        for pair_key, regime_data in regime_info.items():
            stability = regime_data.get('stability', 1.0)
            current_regime = regime_data.get('regime', 'unknown')
            
            # Çok düşük stabilite
            if stability < 0.05:
                alert = Alert(
                    id=f"urgent_regime_{pair_key}_{datetime.now().timestamp()}",
                    timestamp=datetime.now(),
                    alert_type='urgent_regime',
                    severity='critical',
                    title=f"URGENT: Rejim Değişimi - {pair_key}",
                    message=f"URGENT: {pair_key} çiftinde ciddi rejim değişimi! Mevcut rejim: {current_regime}",
                    data={
                        'pair': pair_key,
                        'regime': current_regime,
                        'stability': stability
                    }
                )
                alerts.append(alert)
        
        return alerts
    
    def _process_alerts(self, alerts: List[Alert]) -> List[Alert]:
        """Uyarıları işle"""
        processed_alerts = []
        
        for alert in alerts:
            if self._should_send_alert(alert):
                # Active alerts'e ekle
                self.active_alerts[alert.id] = alert
                
                # Callback'leri çağır
                self._execute_callbacks(alert)
                
                # Email gönder
                if self.email_callback:
                    self._send_email_alert(alert)
                
                processed_alerts.append(alert)
                
                # Rate limiting
                self._update_rate_limits(alert)
        
        return processed_alerts
    
    def _should_send_alert(self, alert: Alert) -> bool:
        """Uyarı gönderilmeli mi kontrol et"""
        # Severity filter
        if not self.severity_filters.get(alert.severity, True):
            return False
        
        # Suppressed alerts
        if alert.alert_type in self.suppressed_alerts:
            return False
        
        # Cooldown check
        last_alert_time = self.last_alert_times.get(alert.alert_type)
        if last_alert_time:
            time_diff = (datetime.now() - last_alert_time).total_seconds()
            if time_diff < self.cooldown_period:
                return False
        
        return True
    
    def _execute_callbacks(self, alert: Alert):
        """Alert callback'lerini çalıştır"""
        for callback in self.alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                self.logger.error(f"Callback execution error: {str(e)}")
    
    def _send_email_alert(self, alert: Alert):
        """Email alert gönder"""
        if not self.email_callback:
            return
        
        try:
            email_config = self.email_callback
            
            msg = MIMEMultipart()
            msg['From'] = email_config['username']
            msg['To'] = ', '.join(email_config['recipients'])
            msg['Subject'] = f"[Korelasyon Alert] {alert.title}"
            
            body = f"""
            Korelasyon Analizi Alert Sistemi
            
            Alert ID: {alert.id}
            Zaman: {alert.timestamp}
            Tip: {alert.alert_type}
            Önem: {alert.severity}
            
            Başlık: {alert.title}
            
            Mesaj: {alert.message}
            
            Detaylar: {json.dumps(alert.data, indent=2, default=str)}
            
            Bu otomatik bir sistem mesajıdır.
            """
            
            msg.attach(MIMEText(body, 'plain'))
            
            server = smtplib.SMTP(email_config['smtp_server'], email_config['smtp_port'])
            server.starttls()
            server.login(email_config['username'], email_config['password'])
            server.send_message(msg)
            server.quit()
            
            self.logger.info(f"Email alert sent: {alert.id}")
            
        except Exception as e:
            self.logger.error(f"Email alert error: {str(e)}")
    
    def _is_rate_limited(self) -> bool:
        """Rate limiting kontrolü"""
        current_hour = datetime.now().hour
        alert_count = self.alert_counters.get(current_hour, 0)
        
        return alert_count >= self.max_alerts_per_hour
    
    def _update_rate_limits(self, alert: Alert):
        """Rate limiting sayaçlarını güncelle"""
        current_hour = datetime.now().hour
        self.alert_counters[current_hour] = self.alert_counters.get(current_hour, 0) + 1
        self.last_alert_times[alert.alert_type] = datetime.now()
        
        # Eski sayaçları temizle
        current_time = datetime.now()
        hours_to_keep = 24
        
        for hour in list(self.alert_counters.keys()):
            if current_time.hour - hour > hours_to_keep:
                del self.alert_counters[hour]
    
    def acknowledge_alert(self, alert_id: str, acknowledged_by: str = 'system'):
        """Uyarıyı kabul et"""
        if alert_id in self.active_alerts:
            alert = self.active_alerts[alert_id]
            alert.acknowledged = True
            alert.acknowledged_by = acknowledged_by
            alert.acknowledged_at = datetime.now()
            
            self.logger.info(f"Alert acknowledged: {alert_id} by {acknowledged_by}")
    
    def get_active_alerts(self, severity: str = None) -> List[Alert]:
        """Aktif uyarıları getir"""
        active_alerts = list(self.active_alerts.values())
        
        if severity:
            active_alerts = [alert for alert in active_alerts if alert.severity == severity]
        
        return sorted(active_alerts, key=lambda x: x.timestamp, reverse=True)
    
    def get_alert_history(self, hours: int = 24) -> List[Alert]:
        """Uyarı geçmişini getir"""
        cutoff_time = datetime.now() - timedelta(hours=hours)
        
        return [alert for alert in self.alert_history if alert.timestamp > cutoff_time]
    
    def suppress_alerts(self, alert_type: str, duration_minutes: int = 60):
        """Belirli bir alert tipini geçici olarak sustur"""
        self.suppressed_alerts.add(alert_type)
        
        # Süre sonunda otomatik olarak aç
        def restore_alerts():
            import time
            time.sleep(duration_minutes * 60)
            self.suppressed_alerts.discard(alert_type)
        
        import threading
        thread = threading.Thread(target=restore_alerts)
        thread.daemon = True
        thread.start()
    
    def get_alert_statistics(self) -> Dict[str, Any]:
        """Alert istatistiklerini getir"""
        current_hour = datetime.now().hour
        
        stats = {
            'active_alerts': len(self.active_alerts),
            'total_alerts_today': self.alert_counters.get(current_hour, 0),
            'alert_types': {},
            'severity_distribution': {},
            'recent_alerts': len([a for a in self.alert_history 
                                if a.timestamp > datetime.now() - timedelta(hours=1)])
        }
        
        # Alert tipi dağılımı
        for alert in self.alert_history:
            alert_type = alert.alert_type
            stats['alert_types'][alert_type] = stats['alert_types'].get(alert_type, 0) + 1
            
            severity = alert.severity
            stats['severity_distribution'][severity] = stats['severity_distribution'].get(severity, 0) + 1
        
        return stats