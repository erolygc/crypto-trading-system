# Korelasyon Analizi Motoru 🚀

Kripto varlıklar arasında real-time korelasyon analizi için geliştirilmiş kapsamlı Python sistemi.

## ⭐ Öne Çıkan Özellikler

- **🔄 Rolling Correlation**: Hareketli pencere korelasyon hesaplamaları
- **📊 Dynamic Regime Detection**: Dinamik korelasyon rejim tespiti
- **🎯 Correlation Clustering**: Korelasyon bazlı varlık kümeleme
- **⏱️ Lead-Lag Analysis**: Öncü-ardıl ilişki analizi
- **🚨 Real-Time Alerting**: Anlık uyarı sistemi
- **📈 Volatility-Adjusted**: Volatilite düzeltilmiş korelasyonlar
- **🔍 Correlation Breakdown**: Korelasyon kırılması tespiti
- **🧠 AI-Powered**: Machine learning tabanlı analizler

## 🚀 Hızlı Başlangıç

### Kurulum

```bash
git clone <repository-url>
cd correlation_engine
pip install -r requirements.txt
```

### Temel Kullanım

```python
from correlation_engine import CorrelationEngine
import pandas as pd
import numpy as np

# Motor oluştur
engine = CorrelationEngine(
    window_size=24,
    regime_detection_threshold=0.1,
    clustering_threshold=0.7
)

# Örnek veri
data = {
    'BTC': pd.DataFrame({
        'price': np.random.normal(50000, 2000, 100),
        'volume': np.random.uniform(1000, 10000, 100)
    }),
    'ETH': pd.DataFrame({
        'price': np.random.normal(3000, 200, 100),
        'volume': np.random.uniform(500, 5000, 100)
    })
}

# Varlıkları ekle
for asset, df in data.items():
    engine.add_asset_data(asset, df)

# Korelasyon analizi yap
metrics = engine.analyze_correlations()

print(f"Korelasyon matrisi:\n{metrics.correlation_matrix}")
print(f"Kümeler: {metrics.clusters}")
```

## 📋 Gereksinimler

- Python 3.8+
- NumPy >= 1.21.0
- Pandas >= 1.3.0
- SciPy >= 1.7.0
- Scikit-learn >= 1.0.0
- NetworkX >= 2.6.0

## 🔧 Özellikler

### 1. Rolling Correlation Calculation
- Hareketli pencere analizi
- Exponential weighted correlation
- Volatility-adjusted correlation
- Multiple window support

### 2. Dynamic Correlation Regime Detection
- İstatistiksel rejim tespiti
- K-means clustering
- Change point detection
- Rejim stabilite analizi

### 3. Correlation Clustering
- Hiyerarşik kümeleme
- K-means clustering
- NetworkX graf analizi
- Küme stabilite ölçümü

### 4. Lead-Lag Analysis
- Cross-correlation analysis
- Granger causality tests
- Regression-based analysis
- Causal relationship detection

### 5. Real-Time Alerting
- Threshold-based alerts
- Email notifications
- Alert filtering
- Rate limiting

## 📊 Örnek Senaryolar

### Portföy Korelasyon İzleme

```python
# Real-time portföy izleme
async def monitor_portfolio():
    await engine.start_real_time_monitoring(
        update_interval=60,
        alert_callback=lambda alert: print(f"Alert: {alert.title}")
    )

asyncio.run(monitor_portfolio())
```

### Korelasyon Rejim Değişimi Tespiti

```python
# Rejim değişim analizi
detector = RegimeDetector(detection_threshold=0.15)
regime = detector.detect_regime(correlation_series)
print(f"Mevcut rejim: {regime}")
```

## 🧪 Test Etme

```bash
# Testleri çalıştır
python -m pytest test_correlation_engine.py -v

# Örnekleri çalıştır
python examples.py
```

## 📖 Dokümantasyon

Detaylı dokümantasyon için [docs/korelasyon_analizi_motoru.md](docs/korelasyon_analizi_motoru.md) dosyasına bakınız.

## 🛠️ API Referansı

### CorrelationEngine
```python
engine = CorrelationEngine(
    window_size=24,                    # Rolling window boyutu
    regime_detection_threshold=0.1,     # Rejim tespit eşiği
    clustering_threshold=0.7,           # Kümeleme eşiği
    lead_lag_window=48,                # Lead-lag penceresi
    max_workers=4                      # Paralel işlem sayısı
)
```

### Alert Sistemi
```python
alert_system = AlertSystem({
    'high_correlation': 0.8,
    'correlation_breakdown': 0.3,
    'regime_change': 0.15
})
```

## 📈 Performans

- **100 varlık**: ~2-3 saniye
- **1000 varlık**: ~20-30 saniye
- **Memory usage**: ~50MB (100 varlık için)
- **Real-time update**: 60+ saniye aralık önerilir

## 🛡️ Güvenlik

- Input validation
- Memory leak prevention
- Error handling
- Rate limiting

## 🤝 Katkıda Bulunma

1. Fork edin
2. Feature branch oluşturun (`git checkout -b feature/AmazingFeature`)
3. Commit edin (`git commit -m 'Add some AmazingFeature'`)
4. Push edin (`git push origin feature/AmazingFeature`)
5. Pull Request açın

### Kod Standartları
- PEP 8 compliance
- Type hints
- Comprehensive docstrings
- 80%+ test coverage

## 📄 Lisans

MIT License - detaylar için LICENSE dosyasına bakınız.

## 🆘 Destek

- Issue: GitHub Issues kullanın
- Dokümantasyon: docs/ klasörüne bakın
- Örnekler: examples.py dosyasını inceleyin

## 🚧 Roadmap

- [ ] DCC-GARCH model implementasyonu
- [ ] GPU acceleration desteği
- [ ] Web dashboard arayüzü
- [ ] Real-time streaming API
- [ ] Machine learning modelleri

---

**Korelasyon Analizi Motoru** - Kripto varlıklar arasındaki korelasyon dinamiklerini anlamanız için güçlü bir araç. 🚀📊