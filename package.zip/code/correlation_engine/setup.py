"""
Korelasyon Analizi Motoru - Setup Script
========================================
"""

from setuptools import setup, find_packages
import os

# README dosyasını oku
def read_readme():
    readme_path = os.path.join(os.path.dirname(__file__), 'README.md')
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as f:
            return f.read()
    return ""

# Requirements dosyasını oku
def read_requirements():
    req_path = os.path.join(os.path.dirname(__file__), 'requirements.txt')
    requirements = []
    if os.path.exists(req_path):
        with open(req_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#'):
                    requirements.append(line)
    return requirements

setup(
    name="correlation-engine",
    version="1.0.0",
    author="Korelasyon Analizi Motoru Takımı",
    author_email="contact@example.com",
    description="Kripto varlıklar arasında real-time korelasyon analizi motoru",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    url="https://github.com/your-username/correlation-engine",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Financial and Insurance Industry",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Office/Business :: Financial :: Investment",
        "Topic :: Scientific/Engineering :: Mathematics",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.8",
    install_requires=read_requirements(),
    extras_require={
        "dev": [
            "pytest>=6.0.0",
            "pytest-asyncio>=0.18.0",
            "pytest-cov>=2.12.0",
            "black>=21.0.0",
            "flake8>=3.9.0",
            "mypy>=0.900",
        ],
        "viz": [
            "matplotlib>=3.4.0",
            "seaborn>=0.11.0",
            "plotly>=5.0.0",
        ],
        "stats": [
            "statsmodels>=0.13.0",
            "arch>=4.19.0",
        ]
    },
    entry_points={
        "console_scripts": [
            "correlation-engine=correlation_engine.cli:main",
        ],
    },
    include_package_data=True,
    package_data={
        "correlation_engine": ["data/*.json", "config/*.yaml"],
    },
    zip_safe=False,
    keywords="correlation, crypto, financial, analysis, real-time, clustering, regime-detection",
    project_urls={
        "Bug Reports": "https://github.com/your-username/correlation-engine/issues",
        "Source": "https://github.com/your-username/correlation-engine",
        "Documentation": "https://correlation-engine.readthedocs.io/",
    },
)