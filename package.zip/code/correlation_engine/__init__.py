"""
Korelasyon Analizi Motoru
========================

Kripto varlıklar arasında real-time korelasyon analizi için geliştirilmiş motor.
Bu motor aşağıdaki özellikleri sunar:

- Rolling correlation calculation
- Dynamic correlation regime detection  
- Correlation clustering
- Lead-lag analysis
- Regime-dependent correlation
- Cross-asset correlation
- Correlation breakdown detection
- Volatility-adjusted correlation
- Time-varying correlation models
- Real-time alerting

Ana Bileşenler:
- CorrelationEngine: Ana motor sınıfı
- RollingCorrelation: Hareketli korelasyon hesaplamaları
- RegimeDetector: Korelasyon rejim tespiti
- CorrelationClusterer: Korelasyon kümeleme
- LeadLagAnalyzer: Öncü-ardıl analiz
- AlertSystem: Real-time uyarı sistemi
"""

from .correlation_engine import CorrelationEngine
from .rolling_correlation import RollingCorrelation
from .regime_detector import RegimeDetector
from .correlation_clusterer import CorrelationClusterer
from .lead_lag_analyzer import LeadLagAnalyzer
from .alert_system import AlertSystem

__version__ = "1.0.0"
__author__ = "Korelasyon Analizi Motoru"

__all__ = [
    "CorrelationEngine",
    "RollingCorrelation", 
    "RegimeDetector",
    "CorrelationClusterer",
    "LeadLagAnalyzer",
    "AlertSystem"
]