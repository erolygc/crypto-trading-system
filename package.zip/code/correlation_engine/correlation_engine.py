"""
Korelasyon Analizi Motoru - Ana Engine
=====================================

Tüm korelasyon analizi özelliklerini koordine eden ana sınıf.
Real-time veri akışı ile korelasyon hesaplamalarını yönetir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, timedelta
import logging
from dataclasses import dataclass
import asyncio
from concurrent.futures import ThreadPoolExecutor

try:
    from .rolling_correlation import RollingCorrelation
    from .regime_detector import RegimeDetector
    from .correlation_clusterer import CorrelationClusterer
    from .lead_lag_analyzer import LeadLagAnalyzer
    from .alert_system import AlertSystem
except ImportError:
    # Direct import for standalone usage
    from rolling_correlation import RollingCorrelation
    from regime_detector import RegimeDetector
    from correlation_clusterer import CorrelationClusterer
    from lead_lag_analyzer import LeadLagAnalyzer
    from alert_system import AlertSystem

@dataclass
class CorrelationMetrics:
    """Korelasyon metrikleri için veri yapısı"""
    correlation_matrix: pd.DataFrame
    rolling_correlations: Dict[str, Dict[str, pd.Series]]
    regime_info: Dict[str, Any]
    clusters: Dict[str, List[str]]
    lead_lag_relations: Dict[str, Dict[str, int]]
    volatility_adjusted: pd.DataFrame
    breakdown_alerts: List[Dict[str, Any]]
    last_update: datetime

class CorrelationEngine:
    """
    Ana korelasyon analizi motoru
    
    Bu sınıf tüm korelasyon analizi bileşenlerini koordine eder ve
    real-time veri akışını yönetir.
    """
    
    def __init__(self, 
                 window_size: int = 24,
                 regime_detection_threshold: float = 0.1,
                 clustering_threshold: float = 0.7,
                 lead_lag_window: int = 48,
                 alert_thresholds: Dict[str, float] = None,
                 max_workers: int = 4):
        """
        Korelasyon motoru başlatma
        
        Args:
            window_size: Rolling correlation penceresi boyutu (saat)
            regime_detection_threshold: Rejim değişim tespit eşiği
            clustering_threshold: Kümeleme korelasyon eşiği
            lead_lag_window: Öncü-ardıl analiz penceresi
            alert_thresholds: Uyarı eşikleri
            max_workers: Maksimum worker sayısı
        """
        self.window_size = window_size
        self.regime_threshold = regime_detection_threshold
        self.clustering_threshold = clustering_threshold
        self.lead_lag_window = lead_lag_window
        self.max_workers = max_workers
        
        # Default alert thresholds
        self.alert_thresholds = alert_thresholds or {
            'correlation_breakdown': 0.3,
            'regime_change': 0.15,
            'cluster_membership_change': 0.2,
            'high_correlation': 0.8,
            'low_correlation': 0.1
        }
        
        # Bileşenler
        self.rolling_corr = RollingCorrelation(window_size)
        self.regime_detector = RegimeDetector(regime_detection_threshold)
        self.clusterer = CorrelationClusterer(clustering_threshold)
        self.lead_lag_analyzer = LeadLagAnalyzer(lead_lag_window)
        self.alert_system = AlertSystem(self.alert_thresholds)
        
        # Veri yapıları
        self.price_data: Dict[str, pd.DataFrame] = {}
        self.returns_data: Dict[str, pd.Series] = {}
        self.correlation_history: List[CorrelationMetrics] = []
        self.last_regimes: Dict[str, str] = {}
        self.last_clusters: Dict[str, List[str]] = {}
        
        # Thread pool
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        
        # Logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
    def add_asset_data(self, asset_id: str, price_data: pd.DataFrame):
        """
        Varlık fiyat verisi ekle
        
        Args:
            asset_id: Varlık kimliği
            price_data: Fiyat verisi (timestamp, price columns)
        """
        self.price_data[asset_id] = price_data.copy()
        
        # Returns hesapla
        if 'price' in price_data.columns:
            self.returns_data[asset_id] = price_data['price'].pct_change().dropna()
        else:
            # İlk sayısal sütunu kullan
            price_col = price_data.select_dtypes(include=[np.number]).columns[0]
            self.returns_data[asset_id] = price_data[price_col].pct_change().dropna()
            
        self.logger.info(f"Asset {asset_id} verisi eklendi: {len(price_data)} kayıt")
    
    def remove_asset(self, asset_id: str):
        """Varlık verisini kaldır"""
        self.price_data.pop(asset_id, None)
        self.returns_data.pop(asset_id, None)
        self.logger.info(f"Asset {asset_id} verisi kaldırıldı")
    
    def analyze_correlations(self, 
                           assets: List[str] = None,
                           return_metrics: bool = True) -> Optional[CorrelationMetrics]:
        """
        Tüm korelasyon analizlerini gerçekleştir
        
        Args:
            assets: Analiz edilecek varlıklar (None = tümü)
            return_metrics: Metrikleri döndür
            
        Returns:
            CorrelationMetrics: Korelasyon analizi sonuçları
        """
        if not assets:
            assets = list(self.returns_data.keys())
            
        if len(assets) < 2:
            self.logger.warning("En az 2 varlık gerekli")
            return None
            
        # Returns verilerini al
        returns_series = {asset: self.returns_data[asset] for asset in assets 
                         if asset in self.returns_data}
        
        if len(returns_series) < 2:
            self.logger.warning("Yeterli return verisi yok")
            return None
        
        try:
            # Paralel analizler
            future_corr = self.executor.submit(self._calculate_correlation_matrix, returns_series)
            future_rolling = self.executor.submit(self._calculate_rolling_correlations, returns_series)
            future_regime = self.executor.submit(self._detect_regimes, returns_series)
            future_cluster = self.executor.submit(self._cluster_correlations, returns_series)
            future_leadlag = self.executor.submit(self._analyze_lead_lag, returns_series)
            
            # Sonuçları bekle
            corr_matrix = future_corr.result()
            rolling_corrs = future_rolling.result()
            regime_info = future_regime.result()
            clusters = future_cluster.result()
            lead_lag_relations = future_leadlag.result()
            
            # Volatility-adjusted correlation
            vol_adj_corr = self._calculate_volatility_adjusted_correlation(returns_series)
            
            # Correlation breakdown detection
            breakdown_alerts = self._detect_correlation_breakdowns(rolling_corrs)
            
            # Metrikleri oluştur
            metrics = CorrelationMetrics(
                correlation_matrix=corr_matrix,
                rolling_correlations=rolling_corrs,
                regime_info=regime_info,
                clusters=clusters,
                lead_lag_relations=lead_lag_relations,
                volatility_adjusted=vol_adj_corr,
                breakdown_alerts=breakdown_alerts,
                last_update=datetime.now()
            )
            
            # History'ye ekle
            self.correlation_history.append(metrics)
            
            # Uyarıları kontrol et
            self._check_alerts(metrics)
            
            return metrics if return_metrics else None
            
        except Exception as e:
            self.logger.error(f"Korelasyon analizi hatası: {str(e)}")
            return None
    
    def get_correlation_trend(self, 
                            asset1: str, 
                            asset2: str, 
                            periods: int = 168) -> Dict[str, Any]:
        """
        İki varlık arasındaki korelasyon trendini analiz et
        
        Args:
            asset1: İlk varlık
            asset2: İkinci varlık
            periods: Analiz periyodu (saat)
            
        Returns:
            Dict: Korelasyon trend analizi
        """
        if asset1 not in self.returns_data or asset2 not in self.returns_data:
            return {}
        
        # Rolling correlation hesapla
        rolling_corr = self.rolling_corr.calculate(
            self.returns_data[asset1], 
            self.returns_data[asset2]
        )
        
        # Son dönemi al
        recent_corr = rolling_corr.tail(periods)
        
        trend_analysis = {
            'current_correlation': recent_corr.iloc[-1] if len(recent_corr) > 0 else 0,
            'mean_correlation': recent_corr.mean(),
            'correlation_std': recent_corr.std(),
            'min_correlation': recent_corr.min(),
            'max_correlation': recent_corr.max(),
            'correlation_trend': 'increasing' if recent_corr.iloc[-5:].mean() > recent_corr.iloc[-10:-5].mean() else 'decreasing',
            'regime': self.regime_detector.detect_regime(recent_corr),
            'volatility_adjusted': self._get_volatility_adjusted_pair(asset1, asset2),
            'lead_lag': self.lead_lag_analyzer.analyze_lead_lag(
                self.returns_data[asset1], 
                self.returns_data[asset2]
            )
        }
        
        return trend_analysis
    
    def detect_correlation_regimes(self, 
                                 assets: List[str] = None) -> Dict[str, Dict[str, Any]]:
        """
        Varlık çiftleri arasındaki korelasyon rejimlerini tespit et
        
        Args:
            assets: Analiz edilecek varlıklar
            
        Returns:
            Dict: Korelasyon rejimleri
        """
        if not assets:
            assets = list(self.returns_data.keys())
            
        regimes = {}
        
        for i, asset1 in enumerate(assets):
            for asset2 in assets[i+1:]:
                if asset1 in self.returns_data and asset2 in self.returns_data:
                    # Rolling correlation hesapla
                    rolling_corr = self.rolling_corr.calculate(
                        self.returns_data[asset1],
                        self.returns_data[asset2]
                    )
                    
                    # Rejim tespiti
                    regime = self.regime_detector.detect_regime(rolling_corr)
                    
                    pair_key = f"{asset1}_{asset2}"
                    regimes[pair_key] = {
                        'regime': regime,
                        'current_correlation': rolling_corr.iloc[-1] if len(rolling_corr) > 0 else 0,
                        'regime_stability': self.regime_detector.calculate_regime_stability(rolling_corr),
                        'breakdown_risk': self.regime_detector.calculate_breakdown_risk(rolling_corr)
                    }
        
        return regimes
    
    def get_real_time_correlation_matrix(self) -> Optional[pd.DataFrame]:
        """
        Real-time korelasyon matrisi oluştur
        
        Returns:
            pd.DataFrame: Korelasyon matrisi
        """
        if len(self.returns_data) < 2:
            return None
            
        try:
            # Returns DataFrame oluştur
            returns_df = pd.DataFrame(self.returns_data)
            
            # NaN değerleri temizle
            returns_df = returns_df.dropna(axis=1, thresh=len(returns_df)*0.8)
            
            if returns_df.shape[1] < 2:
                return None
                
            # Korelasyon matrisi hesapla
            corr_matrix = returns_df.corr()
            
            return corr_matrix
            
        except Exception as e:
            self.logger.error(f"Real-time korelasyon matrisi hatası: {str(e)}")
            return None
    
    async def start_real_time_monitoring(self, 
                                       update_interval: int = 60,
                                       alert_callback: callable = None):
        """
        Real-time korelasyon takibini başlat
        
        Args:
            update_interval: Güncelleme aralığı (saniye)
            alert_callback: Uyarı callback fonksiyonu
        """
        self.logger.info("Real-time korelasyon takibi başlatıldı")
        
        if alert_callback:
            self.alert_system.set_callback(alert_callback)
        
        while True:
            try:
                # Korelasyon analizi yap
                metrics = self.analyze_correlations()
                
                if metrics:
                    # Real-time uyarıları kontrol et
                    alerts = self.alert_system.check_real_time_alerts(metrics)
                    
                    for alert in alerts:
                        self.logger.warning(f"ALERT: {alert['message']}")
                        if alert_callback:
                            await alert_callback(alert)
                
                await asyncio.sleep(update_interval)
                
            except Exception as e:
                self.logger.error(f"Real-time monitoring hatası: {str(e)}")
                await asyncio.sleep(update_interval)
    
    def get_correlation_summary(self) -> Dict[str, Any]:
        """
        Korelasyon durumu özeti
        
        Returns:
            Dict: Korelasyon özeti
        """
        if not self.correlation_history:
            return {}
            
        latest = self.correlation_history[-1]
        
        summary = {
            'total_assets': len(self.returns_data),
            'analysis_count': len(self.correlation_history),
            'last_update': latest.last_update,
            'average_correlation': latest.correlation_matrix.values[np.triu_indices_from(latest.correlation_matrix.values, k=1)].mean(),
            'correlation_clusters': len(latest.clusters),
            'regime_changes': self._count_regime_changes(),
            'breakdown_alerts_count': len(latest.breakdown_alerts),
            'high_correlation_pairs': self._get_high_correlation_pairs(latest.correlation_matrix),
            'low_correlation_pairs': self._get_low_correlation_pairs(latest.correlation_matrix)
        }
        
        return summary
    
    # Private helper methods
    def _calculate_correlation_matrix(self, returns_series: Dict[str, pd.Series]) -> pd.DataFrame:
        """Korelasyon matrisi hesapla"""
        returns_df = pd.DataFrame(returns_series)
        returns_df = returns_df.dropna()
        return returns_df.corr()
    
    def _calculate_rolling_correlations(self, returns_series: Dict[str, pd.Series]) -> Dict[str, Dict[str, pd.Series]]:
        """Rolling korelasyonları hesapla"""
        rolling_corrs = {}
        assets = list(returns_series.keys())
        
        for i, asset1 in enumerate(assets):
            rolling_corrs[asset1] = {}
            for asset2 in assets[i+1:]:
                rolling_corr = self.rolling_corr.calculate(
                    returns_series[asset1],
                    returns_series[asset2]
                )
                rolling_corrs[asset1][asset2] = rolling_corr
        
        return rolling_corrs
    
    def _detect_regimes(self, returns_series: Dict[str, pd.Series]) -> Dict[str, Any]:
        """Korelasyon rejimlerini tespit et"""
        regime_info = {}
        assets = list(returns_series.keys())
        
        for i, asset1 in enumerate(assets):
            for asset2 in assets[i+1:]:
                rolling_corr = self.rolling_corr.calculate(
                    returns_series[asset1],
                    returns_series[asset2]
                )
                regime = self.regime_detector.detect_regime(rolling_corr)
                regime_info[f"{asset1}_{asset2}"] = {
                    'regime': regime,
                    'stability': self.regime_detector.calculate_regime_stability(rolling_corr)
                }
        
        return regime_info
    
    def _cluster_correlations(self, returns_series: Dict[str, pd.Series]) -> Dict[str, List[str]]:
        """Korelasyon kümeleme"""
        corr_matrix = self._calculate_correlation_matrix(returns_series)
        return self.clusterer.cluster_assets(corr_matrix)
    
    def _analyze_lead_lag(self, returns_series: Dict[str, pd.Series]) -> Dict[str, Dict[str, int]]:
        """Lead-lag analizi"""
        lead_lag_relations = {}
        assets = list(returns_series.keys())
        
        for i, asset1 in enumerate(assets):
            for asset2 in assets[i+1:]:
                lag = self.lead_lag_analyzer.analyze_lead_lag(
                    returns_series[asset1],
                    returns_series[asset2]
                )
                pair_key = f"{asset1}_{asset2}"
                lead_lag_relations[pair_key] = {
                    'lag_periods': lag,
                    'relationship': 'asset1_leads' if lag > 0 else 'asset2_leads' if lag < 0 else 'simultaneous'
                }
        
        return lead_lag_relations
    
    def _calculate_volatility_adjusted_correlation(self, returns_series: Dict[str, pd.Series]) -> pd.DataFrame:
        """Volatility-adjusted korelasyon hesapla"""
        returns_df = pd.DataFrame(returns_series)
        returns_df = returns_df.dropna()
        
        # Volatiliteyi hesapla (rolling std)
        rolling_vol = returns_df.rolling(window=24).std()
        
        # Standardize et
        normalized_returns = returns_df / rolling_vol
        
        # Korelasyon hesapla
        vol_adj_corr = normalized_returns.corr()
        
        return vol_adj_corr
    
    def _detect_correlation_breakdowns(self, rolling_corrs: Dict[str, Dict[str, pd.Series]]) -> List[Dict[str, Any]]:
        """Korelasyon breakdown tespiti"""
        breakdowns = []
        
        for asset1, corr_dict in rolling_corrs.items():
            for asset2, rolling_corr in corr_dict.items():
                if len(rolling_corr) >= 48:  # En az 2 günlük veri
                    recent_corr = rolling_corr.tail(24)
                    historical_corr = rolling_corr.head(-24)
                    
                    if len(historical_corr) > 0:
                        correlation_change = abs(recent_corr.mean() - historical_corr.mean())
                        
                        if correlation_change > 0.3:  # %30'dan fazla değişim
                            breakdowns.append({
                                'asset1': asset1,
                                'asset2': asset2,
                                'historical_avg': historical_corr.mean(),
                                'recent_avg': recent_corr.mean(),
                                'change': correlation_change,
                                'timestamp': datetime.now(),
                                'severity': 'high' if correlation_change > 0.5 else 'medium'
                            })
        
        return breakdowns
    
    def _check_alerts(self, metrics: CorrelationMetrics):
        """Uyarıları kontrol et"""
        self.alert_system.check_alerts(metrics)
    
    def _get_volatility_adjusted_pair(self, asset1: str, asset2: str) -> float:
        """İki varlık için volatility-adjusted korelasyon"""
        if asset1 not in self.returns_data or asset2 not in self.returns_data:
            return 0.0
            
        returns1 = self.returns_data[asset1]
        returns2 = self.returns_data[asset2]
        
        # Volatiliteyi hesapla
        vol1 = returns1.rolling(window=24).std()
        vol2 = returns2.rolling(window=24).std()
        
        # Normalize et
        norm_ret1 = returns1 / vol1
        norm_ret2 = returns2 / vol2
        
        # Korelasyon hesapla
        correlation = norm_ret1.corr(norm_ret2)
        
        return correlation if not pd.isna(correlation) else 0.0
    
    def _count_regime_changes(self) -> int:
        """Rejim değişim sayısını hesapla"""
        if len(self.correlation_history) < 2:
            return 0
            
        changes = 0
        latest_regimes = self.correlation_history[-1].regime_info
        
        if len(self.correlation_history) >= 2:
            previous_regimes = self.correlation_history[-2].regime_info
            
            for pair in latest_regimes:
                if pair in previous_regimes:
                    if latest_regimes[pair]['regime'] != previous_regimes[pair]['regime']:
                        changes += 1
        
        return changes
    
    def _get_high_correlation_pairs(self, corr_matrix: pd.DataFrame, threshold: float = 0.7) -> List[Tuple[str, str, float]]:
        """Yüksek korelasyonlu çiftleri bul"""
        high_corr_pairs = []
        
        for i in range(len(corr_matrix)):
            for j in range(i+1, len(corr_matrix)):
                corr_val = corr_matrix.iloc[i, j]
                if not pd.isna(corr_val) and abs(corr_val) > threshold:
                    asset1 = corr_matrix.index[i]
                    asset2 = corr_matrix.index[j]
                    high_corr_pairs.append((asset1, asset2, corr_val))
        
        return sorted(high_corr_pairs, key=lambda x: abs(x[2]), reverse=True)
    
    def _get_low_correlation_pairs(self, corr_matrix: pd.DataFrame, threshold: float = 0.3) -> List[Tuple[str, str, float]]:
        """Düşük korelasyonlu çiftleri bul"""
        low_corr_pairs = []
        
        for i in range(len(corr_matrix)):
            for j in range(i+1, len(corr_matrix)):
                corr_val = corr_matrix.iloc[i, j]
                if not pd.isna(corr_val) and abs(corr_val) < threshold:
                    asset1 = corr_matrix.index[i]
                    asset2 = corr_matrix.index[j]
                    low_corr_pairs.append((asset1, asset2, corr_val))
        
        return sorted(low_corr_pairs, key=lambda x: abs(x[2]))
    
    def cleanup(self):
        """Kaynakları temizle"""
        self.executor.shutdown(wait=True)
        self.logger.info("Korelasyon motoru temizlendi")