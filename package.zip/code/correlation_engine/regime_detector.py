"""
Korelasyon Rejim Tespit Sistemi
===============================

Dinamik korelasyon rejimlerini tespit eden sistem.
Korelasyon yapısındaki değişimleri ve rejim geçişlerini analiz eder.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional, Any
import warnings
from scipy import stats
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
import logging

class RegimeDetector:
    """
    Korelasyon rejim tespit sistemi
    
    Zaman serisi korelasyon verilerini analiz ederek rejim değişimlerini
    tespit eder ve korelasyon rejimlerini sınıflandırır.
    """
    
    def __init__(self, 
                 detection_threshold: float = 0.1,
                 regime_window: int = 48,
                 min_regime_duration: int = 12):
        """
        Rejim tespit sistemi başlatma
        
        Args:
            detection_threshold: Rejim değişim tespit eşiği
            regime_window: Rejim analizi penceresi
            min_regime_duration: Minimum rejim süresi
        """
        self.detection_threshold = detection_threshold
        self.regime_window = regime_window
        self.min_regime_duration = min_regime_duration
        
        # Rejim tanımları
        self.regime_definitions = {
            'high_positive': {'threshold': 0.7, 'type': 'positive'},
            'moderate_positive': {'threshold': 0.3, 'type': 'positive'},
            'low_positive': {'threshold': 0.1, 'type': 'positive'},
            'near_zero': {'threshold': 0.1, 'type': 'zero'},
            'low_negative': {'threshold': -0.1, 'type': 'negative'},
            'moderate_negative': {'threshold': -0.3, 'type': 'negative'},
            'high_negative': {'threshold': -0.7, 'type': 'negative'}
        }
        
        # Clustering parametreleri
        self.n_clusters = 5
        self.scaler = StandardScaler()
        
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def detect_regime(self, correlation_series: pd.Series) -> str:
        """
        Korelasyon serisindeki aktif rejimi tespit et
        
        Args:
            correlation_series: Korelasyon zaman serisi
            
        Returns:
            str: Tespit edilen rejim adı
        """
        if len(correlation_series.dropna()) < self.min_regime_duration:
            return 'insufficient_data'
        
        # Son değeri al (veya son N değerin ortalaması)
        recent_values = correlation_series.tail(self.min_regime_duration).dropna()
        if len(recent_values) == 0:
            return 'no_data'
        
        current_correlation = recent_values.mean()
        
        # Rejim sınıflandırması
        return self._classify_correlation_regime(current_correlation)
    
    def detect_regime_changes(self, 
                            correlation_series: pd.Series,
                            method: str = 'statistical') -> List[Dict[str, Any]]:
        """
        Rejim değişim noktalarını tespit et
        
        Args:
            correlation_series: Korelasyon zaman serisi
            method: Tespit yöntemi ('statistical', 'clustering', 'change_point')
            
        Returns:
            List[Dict]: Rejim değişim noktaları
        """
        if method == 'statistical':
            return self._detect_statistical_changes(correlation_series)
        elif method == 'clustering':
            return self._detect_clustering_changes(correlation_series)
        elif method == 'change_point':
            return self._detect_change_points(correlation_series)
        else:
            raise ValueError(f"Bilinmeyen tespit yöntemi: {method}")
    
    def _detect_statistical_changes(self, correlation_series: pd.Series) -> List[Dict[str, Any]]:
        """İstatistiksel yöntemle rejim değişim tespiti"""
        changes = []
        
        # Rolling window ile korelasyon hesapla
        rolling_corr = correlation_series.rolling(window=self.regime_window).mean()
        
        # Korelasyon değişimini hesapla
        correlation_change = rolling_corr.diff().abs()
        
        # Değişim tespiti
        for i in range(self.regime_window, len(rolling_corr)):
            if not pd.isna(correlation_change.iloc[i]):
                if correlation_change.iloc[i] > self.detection_threshold:
                    # Rejim değişimi tespit et
                    old_regime = self._classify_correlation_regime(rolling_corr.iloc[i-1])
                    new_regime = self._classify_correlation_regime(rolling_corr.iloc[i])
                    
                    if old_regime != new_regime:
                        changes.append({
                            'timestamp': correlation_series.index[i],
                            'old_regime': old_regime,
                            'new_regime': new_regime,
                            'change_magnitude': correlation_change.iloc[i],
                            'correlation_value': rolling_corr.iloc[i],
                            'method': 'statistical'
                        })
        
        return changes
    
    def _detect_clustering_changes(self, correlation_series: pd.Series) -> List[Dict[str, Any]]:
        """K-means clustering ile rejim değişim tespiti"""
        # Veriyi hazırla
        clean_series = correlation_series.dropna()
        
        if len(clean_series) < self.regime_window * 2:
            return []
        
        # Veriyi pencerelere böl
        windows = []
        for i in range(0, len(clean_series) - self.regime_window, self.regime_window // 2):
            window_data = clean_series.iloc[i:i + self.regime_window]
            if len(window_data) >= self.min_regime_duration:
                windows.append(window_data.values)
        
        if len(windows) < 2:
            return []
        
        # Özellik vektörleri oluştur
        features = []
        for window in windows:
            features.append([
                np.mean(window),
                np.std(window),
                np.min(window),
                np.max(window),
                stats.skew(window),
                stats.kurtosis(window)
            ])
        
        features = np.array(features)
        
        # Standardize et
        features_scaled = self.scaler.fit_transform(features)
        
        # K-means clustering
        kmeans = KMeans(n_clusters=min(self.n_clusters, len(windows)), random_state=42)
        cluster_labels = kmeans.fit_predict(features_scaled)
        
        # Rejim değişimlerini tespit et
        changes = []
        for i in range(1, len(cluster_labels)):
            if cluster_labels[i] != cluster_labels[i-1]:
                timestamp_idx = (i * self.regime_window // 2) + self.regime_window // 2
                if timestamp_idx < len(clean_series):
                    changes.append({
                        'timestamp': clean_series.index[timestamp_idx],
                        'old_regime': f'cluster_{cluster_labels[i-1]}',
                        'new_regime': f'cluster_{cluster_labels[i]}',
                        'change_magnitude': abs(features[i] - features[i-1]).mean(),
                        'correlation_value': clean_series.iloc[timestamp_idx],
                        'method': 'clustering'
                    })
        
        return changes
    
    def _detect_change_points(self, correlation_series: pd.Series) -> List[Dict[str, Any]]:
        """İstatistiksel change point tespiti"""
        changes = []
        
        clean_series = correlation_series.dropna()
        
        if len(clean_series) < self.regime_window * 2:
            return changes
        
        # Cumulative sum (CUSUM) metodu
        mean_corr = clean_series.mean()
        cusum = (clean_series - mean_corr).cumsum()
        
        # CUSUM threshold kontrolü
        threshold = self.detection_threshold * self.regime_window
        
        # Pozitif ve negatif değişim noktalarını kontrol et
        for i in range(self.regime_window, len(cusum)):
            if abs(cusum.iloc[i]) > threshold:
                # Change point tespit edildi
                old_regime = self._classify_correlation_regime(
                    clean_series.iloc[max(0, i-self.regime_window):i].mean()
                )
                new_regime = self._classify_correlation_regime(
                    clean_series.iloc[i:i+self.regime_window].mean()
                )
                
                if old_regime != new_regime:
                    changes.append({
                        'timestamp': clean_series.index[i],
                        'old_regime': old_regime,
                        'new_regime': new_regime,
                        'change_magnitude': abs(cusum.iloc[i]),
                        'correlation_value': clean_series.iloc[i],
                        'method': 'change_point'
                    })
        
        return changes
    
    def _classify_correlation_regime(self, correlation_value: float) -> str:
        """
        Korelasyon değerine göre rejim sınıflandırması
        
        Args:
            correlation_value: Korelasyon değeri
            
        Returns:
            str: Rejim adı
        """
        if pd.isna(correlation_value):
            return 'no_data'
        
        abs_corr = abs(correlation_value)
        
        if abs_corr >= 0.7:
            return 'high_correlation' if correlation_value > 0 else 'high_negative_correlation'
        elif abs_corr >= 0.5:
            return 'moderate_high_correlation' if correlation_value > 0 else 'moderate_high_negative_correlation'
        elif abs_corr >= 0.3:
            return 'moderate_correlation' if correlation_value > 0 else 'moderate_negative_correlation'
        elif abs_corr >= 0.1:
            return 'low_correlation' if correlation_value > 0 else 'low_negative_correlation'
        else:
            return 'near_zero_correlation'
    
    def calculate_regime_stability(self, correlation_series: pd.Series) -> float:
        """
        Rejim stabilitesini hesapla
        
        Args:
            correlation_series: Korelasyon zaman serisi
            
        Returns:
            float: Stabilite skoru (0-1)
        """
        clean_series = correlation_series.dropna()
        
        if len(clean_series) < self.min_regime_duration:
            return 0.0
        
        # Rolling rejim tespiti
        regime_changes = 0
        total_windows = 0
        
        for i in range(self.min_regime_duration, len(clean_series), self.min_regime_duration):
            current_window = clean_series.iloc[max(0, i-self.min_regime_duration):i]
            previous_window = clean_series.iloc[
                max(0, i-2*self.min_regime_duration):max(0, i-self.min_regime_duration)
            ]
            
            if len(current_window) > 0 and len(previous_window) > 0:
                current_regime = self._classify_correlation_regime(current_window.mean())
                previous_regime = self._classify_correlation_regime(previous_window.mean())
                
                if current_regime != previous_regime:
                    regime_changes += 1
                
                total_windows += 1
        
        if total_windows == 0:
            return 1.0
        
        # Stabilite = 1 - (rejim_değişimi / toplam_pencere)
        stability_score = 1.0 - (regime_changes / total_windows)
        
        return max(0.0, min(1.0, stability_score))
    
    def calculate_regime_probabilities(self, correlation_series: pd.Series) -> Dict[str, float]:
        """
        Her rejimin olasılığını hesapla
        
        Args:
            correlation_series: Korelasyon zaman serisi
            
        Returns:
            Dict[str, float]: Rejim olasılıkları
        """
        clean_series = correlation_series.dropna()
        
        if len(clean_series) == 0:
            return {}
        
        # Tüm veriler için rejim sınıflandırması
        regime_counts = {}
        total_count = len(clean_series)
        
        for value in clean_series:
            regime = self._classify_correlation_regime(value)
            regime_counts[regime] = regime_counts.get(regime, 0) + 1
        
        # Olasılıklara çevir
        regime_probabilities = {
            regime: count / total_count 
            for regime, count in regime_counts.items()
        }
        
        return regime_probabilities
    
    def predict_regime_transition(self, 
                                correlation_series: pd.Series,
                                forecast_periods: int = 24) -> Dict[str, Any]:
        """
        Rejim geçişini tahmin et
        
        Args:
            correlation_series: Korelasyon zaman serisi
            forecast_periods: Tahmin periyodu
            
        Returns:
            Dict: Rejim geçiş tahmini
        """
        clean_series = correlation_series.dropna()
        
        if len(clean_series) < self.regime_window:
            return {
                'prediction': 'uncertain',
                'confidence': 0.0,
                'expected_regime': 'unknown'
            }
        
        # Son rejimi tespit et
        current_regime = self.detect_regime(clean_series)
        
        # Korelasyon trendini analiz et
        recent_data = clean_series.tail(self.regime_window)
        trend = self._calculate_correlation_trend(recent_data)
        
        # Stabilite skoru
        stability = self.calculate_regime_stability(clean_series)
        
        # Geçiş olasılığı
        transition_probability = self._calculate_transition_probability(
            current_regime, trend, stability
        )
        
        # Tahmin
        if transition_probability > 0.7:
            prediction = 'likely_change'
            expected_regime = self._predict_next_regime(current_regime, trend)
            confidence = transition_probability
        elif transition_probability > 0.4:
            prediction = 'possible_change'
            expected_regime = self._predict_next_regime(current_regime, trend)
            confidence = transition_probability
        else:
            prediction = 'stable'
            expected_regime = current_regime
            confidence = 1.0 - transition_probability
        
        return {
            'prediction': prediction,
            'confidence': confidence,
            'current_regime': current_regime,
            'expected_regime': expected_regime,
            'transition_probability': transition_probability,
            'stability_score': stability,
            'trend': trend,
            'forecast_horizon': forecast_periods
        }
    
    def _calculate_correlation_trend(self, series: pd.Series) -> str:
        """Korelasyon trendini hesapla"""
        if len(series) < 2:
            return 'insufficient_data'
        
        # Linear trend
        x = np.arange(len(series))
        slope, intercept, r_value, p_value, std_err = stats.linregress(x, series.values)
        
        # Trend sınıflandırması
        if abs(slope) < 0.01:  # Çok düşük slope
            return 'flat'
        elif slope > 0:
            return 'increasing'
        else:
            return 'decreasing'
    
    def _calculate_transition_probability(self, 
                                        current_regime: str, 
                                        trend: str, 
                                        stability: float) -> float:
        """Rejim geçiş olasılığını hesapla"""
        base_probability = 1.0 - stability
        
        # Trend etkisi
        if trend == 'flat':
            trend_factor = 0.5
        elif trend == 'increasing' or trend == 'decreasing':
            trend_factor = 0.8
        else:
            trend_factor = 0.6
        
        # Rejim tipine göre ayarlama
        regime_adjustment = 1.0
        if current_regime == 'near_zero_correlation':
            regime_adjustment = 1.2  # Near-zero rejimler daha değişken
        elif current_regime in ['high_correlation', 'high_negative_correlation']:
            regime_adjustment = 0.8  # Yüksek korelasyon rejimleri daha stabil
        
        transition_probability = base_probability * trend_factor * regime_adjustment
        
        return min(1.0, max(0.0, transition_probability))
    
    def _predict_next_regime(self, current_regime: str, trend: str) -> str:
        """Bir sonraki rejimi tahmin et"""
        # Trend'e göre basit tahmin
        if trend == 'increasing':
            if 'negative' in current_regime:
                return 'low_negative_correlation'  # Negatiften sıfıra
            elif 'low' in current_regime:
                return 'moderate_correlation'
            elif 'moderate' in current_regime:
                return 'high_correlation'
        elif trend == 'decreasing':
            if 'high' in current_regime:
                return 'moderate_correlation'
            elif 'moderate' in current_regime:
                return 'low_correlation'
            elif 'positive' in current_regime:
                return 'near_zero_correlation'
        
        # Trend flat ise mevcut rejim
        return current_regime
    
    def get_regime_statistics(self, correlation_series: pd.Series) -> Dict[str, Any]:
        """
        Rejim istatistiklerini hesapla
        
        Args:
            correlation_series: Korelasyon zaman serisi
            
        Returns:
            Dict: Rejim istatistikleri
        """
        clean_series = correlation_series.dropna()
        
        if len(clean_series) == 0:
            return {}
        
        # Temel istatistikler
        stats_dict = {
            'total_observations': len(clean_series),
            'mean_correlation': clean_series.mean(),
            'std_correlation': clean_series.std(),
            'min_correlation': clean_series.min(),
            'max_correlation': clean_series.max(),
            'correlation_range': clean_series.max() - clean_series.min()
        }
        
        # Rejim dağılımı
        regime_probs = self.calculate_regime_probabilities(clean_series)
        stats_dict['regime_distribution'] = regime_probs
        
        # En baskın rejim
        if regime_probs:
            dominant_regime = max(regime_probs.items(), key=lambda x: x[1])
            stats_dict['dominant_regime'] = {
                'regime': dominant_regime[0],
                'probability': dominant_regime[1]
            }
        
        # Rejim değişimleri
        regime_changes = self.detect_regime_changes(clean_series)
        stats_dict['total_regime_changes'] = len(regime_changes)
        stats_dict['regime_changes_per_period'] = len(regime_changes) / (len(clean_series) / self.min_regime_duration)
        
        # Stabilite
        stats_dict['regime_stability'] = self.calculate_regime_stability(clean_series)
        
        return stats_dict