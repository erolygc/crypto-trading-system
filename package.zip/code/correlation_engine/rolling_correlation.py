"""
Rolling Correlation Hesaplamaları
================================

Hareketli korelasyon hesaplamaları için sınıf.
Zaman serisi verileri için rolling window korelasyon analizleri.
"""

import numpy as np
import pandas as pd
from typing import Optional, Dict, Any
import warnings

class RollingCorrelation:
    """
    Rolling correlation hesaplamaları
    
    Zaman serisi verileri için hareketli pencereler ile korelasyon hesaplar.
    Farklı pencere boyutları ve exponential weighting seçenekleri sunar.
    """
    
    def __init__(self, window_size: int = 24, min_periods: int = None):
        """
        Rolling correlation hesaplayıcı
        
        Args:
            window_size: Rolling penceresi boyutu
            min_periods: Minimum periyot sayısı
        """
        self.window_size = window_size
        self.min_periods = min_periods or max(2, window_size // 4)
        
    def calculate(self, 
                 series1: pd.Series, 
                 series2: pd.Series, 
                 window: int = None,
                 min_periods: int = None,
                 center: bool = False) -> pd.Series:
        """
        İki seri arasında rolling correlation hesapla
        
        Args:
            series1: İlk zaman serisi
            series2: İkinci zaman serisi
            window: Pencere boyutu (None = default)
            min_periods: Minimum periyot (None = default)
            center: Merkeze dayalı hesaplama
            
        Returns:
            pd.Series: Rolling korelasyon değerleri
        """
        if window is None:
            window = self.window_size
        if min_periods is None:
            min_periods = self.min_periods
            
        # Serileri hizala
        aligned_data = pd.DataFrame({
            's1': series1,
            's2': series2
        }).dropna()
        
        if len(aligned_data) < min_periods:
            warnings.warn(f"Insufficient data: {len(aligned_data)} < {min_periods}")
            return pd.Series(dtype=float)
        
        # Rolling correlation hesapla
        rolling_corr = aligned_data['s1'].rolling(
            window=window, 
            min_periods=min_periods, 
            center=center
        ).corr(aligned_data['s2'])
        
        return rolling_corr
    
    def calculate_matrix(self, 
                        data: pd.DataFrame, 
                        window: int = None,
                        min_periods: int = None) -> pd.DataFrame:
        """
        Tüm varlık çiftleri için rolling correlation matrisi
        
        Args:
            data: Varlık fiyat verisi DataFrame'i
            window: Pencere boyutu
            min_periods: Minimum periyot
            
        Returns:
            pd.DataFrame: Rolling correlation matrisleri
        """
        if window is None:
            window = self.window_size
        if min_periods is None:
            min_periods = self.min_periods
            
        assets = data.columns
        correlations = {}
        
        for i, asset1 in enumerate(assets):
            correlations[asset1] = {}
            for j, asset2 in enumerate(assets):
                if i <= j:  # Üst üçgen + diagonal
                    if i == j:
                        # Diagonal = 1
                        correlations[asset1][asset2] = pd.Series(1.0, index=data.index)
                    else:
                        corr = self.calculate(
                            data[asset1], 
                            data[asset2], 
                            window, 
                            min_periods
                        )
                        correlations[asset1][asset2] = corr
                else:
                    # Alt üçgen = transpoz
                    correlations[asset1][asset2] = correlations[asset2][asset1]
        
        # DataFrame'e çevir
        corr_matrix = pd.DataFrame({
            asset: pd.Series(corr_dict) 
            for asset, corr_dict in correlations.items()
        })
        
        return corr_matrix
    
    def calculate_exponential_weighted(self, 
                                     series1: pd.Series, 
                                     series2: pd.Series,
                                     span: int = 24,
                                     adjust: bool = True) -> pd.Series:
        """
        Exponential weighted rolling correlation
        
        Args:
            series1: İlk zaman serisi
            series2: İkinci zaman serisi
            span: Exponential span değeri
            adjust: Adjust faktörü
            
        Returns:
            pd.Series: Exponential weighted rolling correlation
        """
        # Serileri hizala
        aligned_data = pd.DataFrame({
            's1': series1,
            's2': series2
        }).dropna()
        
        if len(aligned_data) < span:
            warnings.warn(f"Insufficient data for exponential weighted correlation")
            return pd.Series(dtype=float)
        
        # Exponential weighted correlation hesapla
        ewm_corr = aligned_data['s1'].ewm(span=span, adjust=adjust).corr(
            aligned_data['s2'].ewm(span=span, adjust=adjust)
        )
        
        return ewm_corr
    
    def calculate_multiple_windows(self, 
                                 series1: pd.Series, 
                                 series2: pd.Series,
                                 windows: list = None) -> Dict[int, pd.Series]:
        """
        Birden fazla pencere boyutu için rolling correlation
        
        Args:
            series1: İlk zaman serisi
            series2: İkinci zaman serisi
            windows: Pencere boyutları listesi
            
        Returns:
            Dict: Pencere boyutuna göre correlation serileri
        """
        if windows is None:
            windows = [6, 12, 24, 48, 168]  # 6h, 12h, 1d, 2d, 1w
            
        correlations = {}
        
        for window in windows:
            correlations[window] = self.calculate(series1, series2, window)
        
        return correlations
    
    def calculate_volatility_adjusted(self, 
                                    series1: pd.Series, 
                                    series2: pd.Series,
                                    vol_window: int = 24,
                                    corr_window: int = None) -> pd.Series:
        """
        Volatilite düzeltmeli rolling correlation
        
        Args:
            series1: İlk zaman serisi
            series2: İkinci zaman serisi
            vol_window: Volatilite hesaplama penceresi
            corr_window: Korelasyon penceresi
            
        Returns:
            pd.Series: Volatilite düzeltmeli correlation
        """
        if corr_window is None:
            corr_window = self.window_size
            
        # Serileri hizala
        aligned_data = pd.DataFrame({
            's1': series1,
            's2': series2
        }).dropna()
        
        if len(aligned_data) < max(vol_window, corr_window):
            warnings.warn("Insufficient data for volatility adjusted correlation")
            return pd.Series(dtype=float)
        
        # Rolling volatilite hesapla
        vol1 = aligned_data['s1'].rolling(window=vol_window).std()
        vol2 = aligned_data['s2'].rolling(window=vol_window).std()
        
        # Volatiliteyi sıfır olan değerleri filtrele
        valid_mask = (vol1 > 0) & (vol2 > 0)
        
        if not valid_mask.any():
            return pd.Series(dtype=float)
        
        # Normalize et
        norm_s1 = aligned_data.loc[valid_mask, 's1'] / vol1[valid_mask]
        norm_s2 = aligned_data.loc[valid_mask, 's2'] / vol2[valid_mask]
        
        # Normalize edilmiş seriler için correlation hesapla
        vol_adj_corr = norm_s1.rolling(window=corr_window).corr(norm_s2)
        
        # Orijinal index'e geri eşle
        result = pd.Series(index=aligned_data.index, dtype=float)
        result.loc[valid_mask] = vol_adj_corr
        
        return result
    
    def calculate_conditional_correlation(self, 
                                        series1: pd.Series, 
                                        series2: pd.Series,
                                        conditioning_var: pd.Series,
                                        condition_threshold: float = 0.0,
                                        window: int = None) -> Dict[str, pd.Series]:
        """
        Koşullu korelasyon hesapla
        
        Args:
            series1: İlk zaman serisi
            series2: İkinci zaman serisi
            conditioning_var: Koşullandırıcı değişken
            condition_threshold: Koşul eşiği
            window: Pencere boyutu
            
        Returns:
            Dict: Koşul durumuna göre correlation serileri
        """
        if window is None:
            window = self.window_size
            
        # Tüm verileri hizala
        aligned_data = pd.DataFrame({
            's1': series1,
            's2': series2,
            'condition': conditioning_var
        }).dropna()
        
        if len(aligned_data) < window:
            warnings.warn("Insufficient data for conditional correlation")
            return {'high': pd.Series(dtype=float), 'low': pd.Series(dtype=float)}
        
        # Koşullara göre filtrele
        high_condition = aligned_data['condition'] > condition_threshold
        low_condition = aligned_data['condition'] <= condition_threshold
        
        correlations = {}
        
        # Yüksek koşul durumu
        if high_condition.sum() >= self.min_periods:
            correlations['high'] = self.calculate(
                aligned_data.loc[high_condition, 's1'],
                aligned_data.loc[high_condition, 's2'],
                window
            )
        else:
            correlations['high'] = pd.Series(dtype=float)
            
        # Düşük koşul durumu
        if low_condition.sum() >= self.min_periods:
            correlations['low'] = self.calculate(
                aligned_data.loc[low_condition, 's1'],
                aligned_data.loc[low_condition, 's2'],
                window
            )
        else:
            correlations['low'] = pd.Series(dtype=float)
        
        return correlations
    
    def calculate_correlation_stability(self, 
                                      series1: pd.Series, 
                                      series2: pd.Series,
                                      stability_window: int = 168) -> Dict[str, float]:
        """
        Korelasyon stabilitesi metrikleri hesapla
        
        Args:
            series1: İlk zaman serisi
            series2: İkinci zaman serisi
            stability_window: Stabilite analizi penceresi
            
        Returns:
            Dict: Stabilite metrikleri
        """
        # Rolling correlation hesapla
        rolling_corr = self.calculate(series1, series2, stability_window)
        
        if len(rolling_corr.dropna()) < 2:
            return {
                'stability_score': 0.0,
                'mean_correlation': 0.0,
                'std_correlation': 0.0,
                'correlation_range': 0.0
            }
        
        # Metrikleri hesapla
        correlation_values = rolling_corr.dropna()
        
        stability_metrics = {
            'stability_score': 1.0 / (1.0 + correlation_values.std()),
            'mean_correlation': correlation_values.mean(),
            'std_correlation': correlation_values.std(),
            'correlation_range': correlation_values.max() - correlation_values.min(),
            'correlation_skew': correlation_values.skew(),
            'correlation_kurtosis': correlation_values.kurtosis()
        }
        
        return stability_metrics
    
    def detect_correlation_changes(self, 
                                 series1: pd.Series, 
                                 series2: pd.Series,
                                 change_threshold: float = 0.2,
                                 window: int = None) -> pd.DataFrame:
        """
        Korelasyon değişimlerini tespit et
        
        Args:
            series1: İlk zaman serisi
            series2: İkinci zaman serisi
            change_threshold: Değişim tespit eşiği
            window: Pencere boyutu
            
        Returns:
            pd.DataFrame: Korelasyon değişim analizi
        """
        if window is None:
            window = self.window_size
            
        # Rolling correlation hesapla
        rolling_corr = self.calculate(series1, series2, window)
        
        # Korelasyon değişimini hesapla
        correlation_change = rolling_corr.diff().abs()
        
        # Değişim tespit et
        significant_changes = correlation_change > change_threshold
        
        # Değişim noktalarını analiz et
        change_points = []
        
        for i, is_change in enumerate(significant_changes):
            if is_change and not pd.isna(correlation_change.iloc[i]):
                change_points.append({
                    'timestamp': rolling_corr.index[i],
                    'correlation': rolling_corr.iloc[i],
                    'change_magnitude': correlation_change.iloc[i],
                    'change_direction': 'increase' if rolling_corr.iloc[i] > rolling_corr.iloc[i-1] else 'decrease'
                })
        
        # DataFrame oluştur
        if change_points:
            change_df = pd.DataFrame(change_points)
        else:
            change_df = pd.DataFrame(columns=['timestamp', 'correlation', 'change_magnitude', 'change_direction'])
        
        return change_df