"""
Korelasyon Analizi Motoru - Örnek Kullanım
=========================================

Korelasyon analizi motorunun nasıl kullanılacağını gösteren örnek script.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import asyncio
import matplotlib.pyplot as plt
import seaborn as sns

from correlation_engine import (
    CorrelationEngine, 
    RollingCorrelation, 
    RegimeDetector,
    CorrelationClusterer,
    LeadLagAnalyzer,
    AlertSystem
)

def generate_sample_data(n_assets=10, n_periods=1000, start_date=None):
    """
    Örnek kripto varlık verisi oluştur
    
    Args:
        n_assets: Varlık sayısı
        n_periods: Periyot sayısı
        start_date: Başlangıç tarihi
        
    Returns:
        Dict[str, pd.DataFrame]: Varlık verileri
    """
    if start_date is None:
        start_date = datetime.now() - timedelta(hours=n_periods)
    
    # Varlık isimleri
    asset_names = [f"ASSET_{i:02d}" for i in range(n_assets)]
    
    # Korelasyon matrisini oluştur (gerçekçi korelasyonlar)
    correlation_base = np.random.uniform(0.2, 0.8, (n_assets, n_assets))
    correlation_base = (correlation_base + correlation_base.T) / 2  # Simetrik yap
    np.fill_diagonal(correlation_base, 1.0)
    
    data = {}
    
    for i, asset in enumerate(asset_names):
        # Korelasyonlu rastgele yürüyüş
        returns = np.random.normal(0, 0.02, n_periods)
        
        # İlk varlık dışındakiler için önceki varlıklarla korelasyon uygula
        if i > 0:
            for j in range(i):
                correlated_returns = np.random.normal(0, 0.02, n_periods)
                weight = correlation_base[i, j] * 0.3
                returns += weight * correlated_returns
        
        # Fiyat serisini oluştur
        price_series = [100.0]  # Başlangıç fiyatı
        for ret in returns[1:]:
            new_price = price_series[-1] * (1 + ret)
            price_series.append(new_price)
        
        # DataFrame oluştur
        timestamps = [start_date + timedelta(hours=h) for h in range(n_periods)]
        
        df = pd.DataFrame({
            'timestamp': timestamps,
            'price': price_series,
            'volume': np.random.uniform(1000, 10000, n_periods),
            'high': [p * (1 + np.random.uniform(0, 0.05)) for p in price_series],
            'low': [p * (1 - np.random.uniform(0, 0.05)) for p in price_series],
            'open': price_series
        })
        
        df.set_index('timestamp', inplace=True)
        data[asset] = df
    
    return data

def example_basic_usage():
    """Temel kullanım örneği"""
    print("=== Korelasyon Analizi Motoru - Temel Kullanım ===")
    
    # Örnek veri oluştur
    print("Örnek veri oluşturuluyor...")
    data = generate_sample_data(n_assets=8, n_periods=500)
    
    # Motor oluştur
    engine = CorrelationEngine(
        window_size=24,
        regime_detection_threshold=0.1,
        clustering_threshold=0.6,
        lead_lag_window=48
    )
    
    # Varlık verilerini ekle
    for asset, df in data.items():
        engine.add_asset_data(asset, df)
    
    print(f"{len(data)} varlık verisi motor'a eklendi")
    
    # Temel korelasyon analizi
    print("\nKorelasyon analizi yapılıyor...")
    metrics = engine.analyze_correlations()
    
    if metrics:
        print(f"Son analiz zamanı: {metrics.last_update}")
        print(f"Korelasyon matrisi boyutu: {metrics.correlation_matrix.shape}")
        print(f"Tespit edilen küme sayısı: {len(metrics.clusters)}")
        print(f"Rejim değişimi sayısı: {len([r for r in metrics.regime_info.values() if r.get('stability', 1.0) < 0.1])}")
    
    # Özet bilgi al
    summary = engine.get_correlation_summary()
    print(f"\n--- Korelasyon Özeti ---")
    print(f"Toplam varlık: {summary['total_assets']}")
    print(f"Ortalama korelasyon: {summary['average_correlation']:.3f}")
    print(f"Yüksek korelasyonlu çiftler: {len(summary['high_correlation_pairs'])}")
    print(f"Düşük korelasyonlu çiftler: {len(summary['low_correlation_pairs'])}")

def example_rolling_correlation():
    """Rolling correlation örneği"""
    print("\n=== Rolling Correlation Analizi ===")
    
    # Veri hazırla
    data = generate_sample_data(n_assets=3, n_periods=200)
    asset1, asset2 = list(data.keys())[:2]
    
    # Rolling correlation hesapla
    roller = RollingCorrelation(window_size=24)
    
    returns1 = data[asset1]['price'].pct_change().dropna()
    returns2 = data[asset2]['price'].pct_change().dropna()
    
    rolling_corr = roller.calculate(returns1, returns2)
    
    print(f"{asset1} - {asset2} rolling correlation:")
    print(f"Son değer: {rolling_corr.iloc[-1]:.3f}")
    print(f"24 saatlik ortalama: {rolling_corr.tail(24).mean():.3f}")
    print(f"24 saatlik standart sapma: {rolling_corr.tail(24).std():.3f}")
    
    # Volatility-adjusted correlation
    vol_adj_corr = roller.calculate_volatility_adjusted(returns1, returns2)
    print(f"Volatilite-düzeltilmiş korelasyon: {vol_adj_corr.iloc[-1]:.3f}")

def example_regime_detection():
    """Rejim tespiti örneği"""
    print("\n=== Rejim Tespiti Analizi ===")
    
    # Veri hazırla
    data = generate_sample_data(n_assets=3, n_periods=300)
    asset1, asset2 = list(data.keys())[:2]
    
    # Regime detector
    detector = RegimeDetector(detection_threshold=0.15)
    
    returns1 = data[asset1]['price'].pct_change().dropna()
    returns2 = data[asset2]['price'].pct_change().dropna()
    
    # Rolling correlation hesapla
    roller = RollingCorrelation(window_size=24)
    rolling_corr = roller.calculate(returns1, returns2)
    
    # Rejim tespiti
    current_regime = detector.detect_regime(rolling_corr)
    stability = detector.calculate_regime_stability(rolling_corr)
    
    print(f"Mevcut rejim: {current_regime}")
    print(f"Rejim stabilitesi: {stability:.3f}")
    
    # Rejim değişimlerini tespit et
    changes = detector.detect_regime_changes(rolling_corr, method='statistical')
    print(f"Tespit edilen rejim değişim sayısı: {len(changes)}")
    
    if changes:
        latest_change = changes[-1]
        print(f"Son değişim: {latest_change['timestamp']}")
        print(f"Değişim: {latest_change['old_regime']} -> {latest_change['new_regime']}")
    
    # İstatistikler
    stats = detector.get_regime_statistics(rolling_corr)
    print(f"Rejim dağılımı: {stats.get('regime_distribution', {})}")

def example_clustering():
    """Kümeleme örneği"""
    print("\n=== Korelasyon Kümeleme Analizi ===")
    
    # Veri hazırla
    data = generate_sample_data(n_assets=6, n_periods=250)
    
    # Returns verilerini birleştir
    returns_data = {}
    for asset, df in data.items():
        returns_data[asset] = df['price'].pct_change().dropna()
    
    returns_df = pd.DataFrame(returns_data)
    correlation_matrix = returns_df.corr()
    
    # Kümeleme
    clusterer = CorrelationClusterer(clustering_threshold=0.6)
    
    # Hiyerarşik kümeleme
    clusters = clusterer.cluster_assets(correlation_matrix, method='hierarchical')
    
    print("Hiyerarşik kümeler:")
    for cluster_name, assets in clusters.items():
        print(f"{cluster_name}: {assets}")
    
    # Graf tabanlı kümeleme
    graph_clusters = clusterer.cluster_assets(correlation_matrix, method='graph')
    
    print("\nGraf tabanlı kümeler:")
    for cluster_name, assets in graph_clusters.items():
        print(f"{cluster_name}: {assets}")
    
    # Küme karakteristikleri
    characteristics = clusterer.analyze_cluster_characteristics(correlation_matrix, clusters)
    
    print("\nKüme karakteristikleri:")
    for cluster_name, chars in characteristics.items():
        print(f"{cluster_name}:")
        print(f"  Boyut: {chars['size']}")
        print(f"  Ortalama iç korelasyon: {chars['avg_internal_correlation']:.3f}")
        print(f"  Uyum skoru: {chars['cohesion_score']:.3f}")

def example_lead_lag_analysis():
    """Lead-lag analizi örneği"""
    print("\n=== Lead-Lag Analizi ===")
    
    # Veri hazırla
    data = generate_sample_data(n_assets=4, n_periods=200)
    asset1, asset2 = list(data.keys())[:2]
    
    # Lead-lag analyzer
    analyzer = LeadLagAnalyzer(lag_window=48, max_lag=12)
    
    returns1 = data[asset1]['price'].pct_change().dropna()
    returns2 = data[asset2]['price'].pct_change().dropna()
    
    # Lead-lag analizi
    analysis = analyzer.analyze_lead_lag(returns1, returns2, method='correlation')
    
    print(f"{asset1} - {asset2} lead-lag analizi:")
    print(f"Lag periyotları: {analysis['lag_periods']}")
    print(f"İlişki tipi: {analysis['relationship']}")
    print(f"Güç: {analysis['strength']:.3f}")
    print(f"Güven seviyesi: {analysis['confidence']:.3f}")
    
    # Multiple series analizi
    results = analyzer.analyze_multiple_series(
        pd.DataFrame({asset: data[asset]['price'].pct_change() for asset in data.keys()})
    )
    
    print(f"\nToplam analiz edilen çift sayısı: {len(results)}")
    significant_pairs = [k for k, v in results.items() if v['strength'] > 0.3]
    print(f"Anlamlı ilişki sayısı: {len(significant_pairs)}")
    
    # Özet bilgi
    summary = analyzer.get_lead_lag_summary(
        pd.DataFrame({asset: data[asset]['price'].pct_change() for asset in data.keys()})
    )
    
    print(f"\nLead-lag özeti:")
    print(f"Ortalama lag: {summary['lag_statistics']['mean_lag']:.2f}")
    print(f"En güçlü ilişki: {summary['strength_statistics']['max_strength']:.3f}")

def example_alert_system():
    """Alert sistemi örneği"""
    print("\n=== Alert Sistemi ===")
    
    # Alert sistemi
    alert_thresholds = {
        'high_correlation': 0.8,
        'correlation_breakdown': 0.3,
        'regime_change': 0.15
    }
    
    alert_system = AlertSystem(alert_thresholds)
    
    # Callback fonksiyonu
    def alert_callback(alert):
        print(f"ALERT: {alert.title}")
        print(f"Mesaj: {alert.message}")
        print(f"Zaman: {alert.timestamp}")
        print("-" * 50)
    
    alert_system.set_callback(alert_callback)
    
    # Test verisi
    data = generate_sample_data(n_assets=5, n_periods=100)
    
    # Korelasyon motoru
    engine = CorrelationEngine()
    for asset, df in data.items():
        engine.add_asset_data(asset, df)
    
    # Analiz ve alert kontrolü
    metrics = engine.analyze_correlations()
    
    if metrics:
        alerts = alert_system.check_alerts(metrics)
        print(f"Üretilen alert sayısı: {len(alerts)}")
        
        # Alert istatistikleri
        stats = alert_system.get_alert_statistics()
        print(f"Aktif alert sayısı: {stats['active_alerts']}")
        print(f"Son 1 saatteki alert: {stats['recent_alerts']}")

async def example_real_time_monitoring():
    """Real-time monitoring örneği"""
    print("\n=== Real-time Monitoring ===")
    
    # Motor oluştur
    engine = CorrelationEngine()
    
    # Alert callback
    async def real_time_alert_callback(alert):
        print(f"REAL-TIME ALERT: {alert.title}")
        print(f"Seviye: {alert.severity}")
        print(f"Zaman: {alert.timestamp}")
    
    # Örnek veri ekle
    data = generate_sample_data(n_assets=4, n_periods=50)
    for asset, df in data.items():
        engine.add_asset_data(asset, df)
    
    print("Real-time monitoring 30 saniye boyunca çalışacak...")
    print("(Gerçek uygulamada bu sürekli çalışır)")
    
    # 30 saniye simülasyon
    try:
        await asyncio.wait_for(
            engine.start_real_time_monitoring(
                update_interval=5,
                alert_callback=real_time_alert_callback
            ),
            timeout=30.0
        )
    except asyncio.TimeoutError:
        print("Real-time monitoring testi tamamlandı")

def example_correlation_matrix_visualization():
    """Korelasyon matrisi görselleştirme örneği"""
    print("\n=== Korelasyon Matrisi Görselleştirme ===")
    
    # Veri oluştur
    data = generate_sample_data(n_assets=6, n_periods=200)
    
    # Returns verilerini birleştir
    returns_data = {}
    for asset, df in data.items():
        returns_data[asset] = df['price'].pct_change().dropna()
    
    returns_df = pd.DataFrame(returns_data)
    correlation_matrix = returns_df.corr()
    
    print("Korelasyon matrisi:")
    print(correlation_matrix.round(3))
    
    # Yüksek korelasyonlu çiftleri bul
    high_corr_pairs = []
    for i in range(len(correlation_matrix)):
        for j in range(i+1, len(correlation_matrix)):
            corr_val = correlation_matrix.iloc[i, j]
            if abs(corr_val) > 0.7:
                asset1 = correlation_matrix.index[i]
                asset2 = correlation_matrix.index[j]
                high_corr_pairs.append((asset1, asset2, corr_val))
    
    print(f"\nYüksek korelasyonlu çiftler (>0.7):")
    for pair in high_corr_pairs:
        print(f"{pair[0]} - {pair[1]}: {pair[2]:.3f}")
    
    # Grafik oluştur (matplotlib mevcutsa)
    try:
        plt.figure(figsize=(10, 8))
        sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0,
                   square=True, fmt='.3f')
        plt.title('Korelasyon Matrisi')
        plt.tight_layout()
        plt.savefig('correlation_matrix.png')
        print("\nKorelasyon matrisi 'correlation_matrix.png' olarak kaydedildi")
    except ImportError:
        print("Görselleştirme için matplotlib/seaborn gerekli")

def main():
    """Ana fonksiyon - tüm örnekleri çalıştır"""
    print("Korelasyon Analizi Motoru - Örnek Kullanımlar")
    print("=" * 50)
    
    # Temel kullanım
    example_basic_usage()
    
    # Rolling correlation
    example_rolling_correlation()
    
    # Rejim tespiti
    example_regime_detection()
    
    # Kümeleme
    example_clustering()
    
    # Lead-lag analizi
    example_lead_lag_analysis()
    
    # Alert sistemi
    example_alert_system()
    
    # Korelasyon matrisi görselleştirme
    example_correlation_matrix_visualization()
    
    print("\n" + "=" * 50)
    print("Tüm örnekler tamamlandı!")
    print("\nNot: Real-time monitoring örneği ayrı olarak çalıştırılmalı:")
    print("async_example = example_real_time_monitoring()")
    print("asyncio.run(async_example)")

if __name__ == "__main__":
    main()
    
    # Real-time monitoring örneği (isteğe bağlı)
    # asyncio.run(example_real_time_monitoring())