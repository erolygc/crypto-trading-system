"""
Korelasyon Kümeleme Sistemi
==========================

Varlıkları korelasyon özelliklerine göre kümeler halinde gruplandırır.
NetworkX kullanarak korelasyon grafı analizleri yapar.
"""

import numpy as np
import pandas as pd
import networkx as nx
from typing import Dict, List, Tuple, Optional, Any, Set
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler
import warnings

class CorrelationClusterer:
    """
    Korelasyon kümeleme sistemi
    
    Varlıkları korelasyon özelliklerine göre kümeler halinde gruplandırır.
    Farklı kümeleme algoritmaları ve graf tabanlı analizler sunar.
    """
    
    def __init__(self, 
                 clustering_threshold: float = 0.7,
                 linkage_method: str = 'ward',
                 n_clusters: int = None):
        """
        Korelasyon kümeleme sistemi başlatma
        
        Args:
            clustering_threshold: Kümeleme korelasyon eşiği
            linkage_method: Hiyerarşik kümeleme yöntemi
            n_clusters: Kümelerin sayısı (None = otomatik)
        """
        self.clustering_threshold = clustering_threshold
        self.linkage_method = linkage_method
        self.n_clusters = n_clusters
        
        # Kümeleme algoritmaları
        self.clustering_algorithms = {
            'hierarchical': AgglomerativeClustering,
            'kmeans': KMeans,
            'dbscan': DBSCAN
        }
        
        # Network grafi
        self.correlation_graph = None
        
        # Sonuçlar
        self.last_clusters = {}
        self.cluster_stability = {}
        
    def cluster_assets(self, 
                      correlation_matrix: pd.DataFrame,
                      method: str = 'hierarchical',
                      distance_threshold: float = None) -> Dict[str, List[str]]:
        """
        Varlıkları korelasyon matrisine göre kümeleme
        
        Args:
            correlation_matrix: Korelasyon matrisi
            method: Kümeleme yöntemi ('hierarchical', 'kmeans', 'dbscan', 'graph')
            distance_threshold: Mesafe eşiği
            
        Returns:
            Dict[str, List[str]]: Küme adı -> varlık listesi eşlemesi
        """
        if method == 'graph':
            return self._cluster_with_graph(correlation_matrix)
        elif method == 'hierarchical':
            return self._cluster_hierarchical(correlation_matrix, distance_threshold)
        elif method == 'kmeans':
            return self._cluster_kmeans(correlation_matrix)
        elif method == 'dbscan':
            return self._cluster_dbscan(correlation_matrix)
        else:
            raise ValueError(f"Bilinmeyen kümeleme yöntemi: {method}")
    
    def _cluster_with_graph(self, correlation_matrix: pd.DataFrame) -> Dict[str, List[str]]:
        """Network graf ile kümeleme"""
        assets = correlation_matrix.index.tolist()
        
        # Korelasyon grafi oluştur
        self.correlation_graph = nx.Graph()
        
        # Düğümleri ekle
        self.correlation_graph.add_nodes_from(assets)
        
        # Kenar ekle (korelasyon eşiğinden büyük)
        for i, asset1 in enumerate(assets):
            for j, asset2 in enumerate(assets[i+1:], i+1):
                correlation = correlation_matrix.loc[asset1, asset2]
                if abs(correlation) >= self.clustering_threshold:
                    self.correlation_graph.add_edge(
                        asset1, asset2, 
                        weight=abs(correlation),
                        correlation=correlation
                    )
        
        # Connected components = kümeler
        clusters = list(nx.connected_components(self.correlation_graph))
        
        # Kümeleri isimlendir
        cluster_dict = {}
        for i, cluster in enumerate(clusters):
            cluster_name = f"cluster_{i+1}"
            cluster_dict[cluster_name] = list(cluster)
        
        self.last_clusters = cluster_dict
        return cluster_dict
    
    def _cluster_hierarchical(self, 
                            correlation_matrix: pd.DataFrame,
                            distance_threshold: float = None) -> Dict[str, List[str]]:
        """Hiyerarşik kümeleme"""
        assets = correlation_matrix.index.tolist()
        
        if distance_threshold is None:
            distance_threshold = 1.0 - self.clustering_threshold
        
        # Korelasyon matrisini mesafe matrisine çevir
        distance_matrix = 1 - correlation_matrix.abs()
        
        # Mesafe matrisini condensed form'a çevir
        condensed_distance = squareform(distance_matrix, checks=False)
        
        # Hiyerarşik kümeleme
        linkage_matrix = linkage(condensed_distance, method=self.linkage_method)
        
        # Kümeleri belirle
        if self.n_clusters is not None:
            cluster_labels = fcluster(linkage_matrix, self.n_clusters, criterion='maxclust')
        else:
            cluster_labels = fcluster(linkage_matrix, distance_threshold, criterion='distance')
        
        # Kümeleri organize et
        clusters = {}
        for i, label in enumerate(cluster_labels):
            cluster_name = f"cluster_{label}"
            if cluster_name not in clusters:
                clusters[cluster_name] = []
            clusters[cluster_name].append(assets[i])
        
        self.last_clusters = clusters
        return clusters
    
    def _cluster_kmeans(self, correlation_matrix: pd.DataFrame) -> Dict[str, List[str]]:
        """K-means kümeleme"""
        assets = correlation_matrix.index.tolist()
        
        # Korelasyon matrisini özellik vektörlerine çevir
        features = correlation_matrix.values
        
        # Standardize et
        scaler = StandardScaler()
        features_scaled = scaler.fit_transform(features)
        
        # K-means kümeleme
        if self.n_clusters is None:
            # Optimum küme sayısını belirle
            optimal_k = self._find_optimal_clusters(features_scaled)
        else:
            optimal_k = self.n_clusters
        
        kmeans = KMeans(n_clusters=optimal_k, random_state=42, n_init=10)
        cluster_labels = kmeans.fit_predict(features_scaled)
        
        # Kümeleri organize et
        clusters = {}
        for i, label in enumerate(cluster_labels):
            cluster_name = f"cluster_{label+1}"
            if cluster_name not in clusters:
                clusters[cluster_name] = []
            clusters[cluster_name].append(assets[i])
        
        self.last_clusters = clusters
        return clusters
    
    def _cluster_dbscan(self, correlation_matrix: pd.DataFrame) -> Dict[str, List[str]]:
        """DBSCAN kümeleme"""
        assets = correlation_matrix.index.tolist()
        
        # Korelasyon matrisini mesafe matrisine çevir
        distance_matrix = 1 - correlation_matrix.abs()
        
        # Mesafe matrisini özellik vektörlerine çevir
        features = distance_matrix.values
        
        # DBSCAN kümeleme
        eps = 1.0 - self.clustering_threshold
        dbscan = DBSCAN(eps=eps, min_samples=2)
        cluster_labels = dbscan.fit_predict(features)
        
        # Noise points'i filtrele
        clusters = {}
        cluster_id = 1
        
        for i, label in enumerate(cluster_labels):
            if label == -1:  # Noise point
                cluster_name = f"noise_{assets[i]}"
                clusters[cluster_name] = [assets[i]]
            else:
                cluster_name = f"cluster_{label+1}"
                if cluster_name not in clusters:
                    clusters[cluster_name] = []
                clusters[cluster_name].append(assets[i])
        
        self.last_clusters = clusters
        return clusters
    
    def _find_optimal_clusters(self, features: np.ndarray, max_k: int = 10) -> int:
        """Optimum küme sayısını bul"""
        if len(features) < 4:
            return 1
        
        max_k = min(max_k, len(features) // 2)
        
        silhouette_scores = []
        K_range = range(2, max_k + 1)
        
        for k in K_range:
            kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
            cluster_labels = kmeans.fit_predict(features)
            
            if len(set(cluster_labels)) > 1:  # En az 2 küme
                silhouette_avg = silhouette_score(features, cluster_labels)
                silhouette_scores.append(silhouette_avg)
            else:
                silhouette_scores.append(-1)
        
        if not silhouette_scores or max(silhouette_scores) < 0:
            return 2
        
        optimal_k = K_range[np.argmax(silhouette_scores)]
        return optimal_k
    
    def analyze_cluster_characteristics(self, 
                                      correlation_matrix: pd.DataFrame,
                                      clusters: Dict[str, List[str]] = None) -> Dict[str, Dict[str, Any]]:
        """
        Küme karakteristiklerini analiz et
        
        Args:
            correlation_matrix: Korelasyon matrisi
            clusters: Kümeler (None = son kümeleme sonucu)
            
        Returns:
            Dict: Küme karakteristikleri
        """
        if clusters is None:
            clusters = self.last_clusters
        
        if not clusters:
            return {}
        
        characteristics = {}
        
        for cluster_name, assets in clusters.items():
            if len(assets) < 2:
                characteristics[cluster_name] = {
                    'size': len(assets),
                    'avg_correlation': 0.0,
                    'correlation_std': 0.0,
                    'correlation_range': 0.0,
                    'isolation': 1.0
                }
                continue
            
            # Küme içi korelasyonları hesapla
            internal_correlations = []
            for i, asset1 in enumerate(assets):
                for asset2 in assets[i+1:]:
                    corr = correlation_matrix.loc[asset1, asset2]
                    internal_correlations.append(abs(corr))
            
            # Küme dışı korelasyonları hesapla
            external_correlations = []
            for asset1 in assets:
                for asset2 in correlation_matrix.index:
                    if asset2 not in assets:
                        corr = correlation_matrix.loc[asset1, asset2]
                        external_correlations.append(abs(corr))
            
            # Karakteristikleri hesapla
            cluster_chars = {
                'size': len(assets),
                'assets': assets,
                'avg_internal_correlation': np.mean(internal_correlations) if internal_correlations else 0.0,
                'internal_correlation_std': np.std(internal_correlations) if internal_correlations else 0.0,
                'avg_external_correlation': np.mean(external_correlations) if external_correlations else 0.0,
                'external_correlation_std': np.std(external_correlations) if external_correlations else 0.0,
                'internal_correlation_range': (np.max(internal_correlations) - np.min(internal_correlations)) if internal_correlations else 0.0,
                'isolation_score': self._calculate_isolation_score(
                    internal_correlations, external_correlations
                ),
                'cohesion_score': np.mean(internal_correlations) if internal_correlations else 0.0
            }
            
            characteristics[cluster_name] = cluster_chars
        
        return characteristics
    
    def _calculate_isolation_score(self, 
                                 internal_correlations: List[float],
                                 external_correlations: List[float]) -> float:
        """Küme izolasyon skorunu hesapla"""
        if not internal_correlations or not external_correlations:
            return 0.0
        
        internal_avg = np.mean(internal_correlations)
        external_avg = np.mean(external_correlations)
        
        # İzolasyon = iç korelasyon - dış korelasyon
        isolation_score = internal_avg - external_avg
        
        return max(0.0, isolation_score)
    
    def detect_cluster_changes(self, 
                             correlation_matrix: pd.DataFrame,
                             previous_clusters: Dict[str, List[str]] = None,
                             current_clusters: Dict[str, List[str]] = None) -> Dict[str, Any]:
        """
        Küme değişikliklerini tespit et
        
        Args:
            correlation_matrix: Korelasyon matrisi
            previous_clusters: Önceki kümeler
            current_clusters: Mevcut kümeler
            
        Returns:
            Dict: Küme değişiklik analizi
        """
        if current_clusters is None:
            current_clusters = self.last_clusters
        
        if previous_clusters is None:
            previous_clusters = self.cluster_stability.get('previous_clusters', {})
        
        if not previous_clusters:
            return {
                'changes_detected': False,
                'change_type': 'initial_clustering',
                'new_clusters': len(current_clusters)
            }
        
        changes = {
            'changes_detected': False,
            'moved_assets': [],
            'new_clusters': [],
            'removed_clusters': [],
            'merged_clusters': [],
            'split_clusters': []
        }
        
        # Tüm varlıkları topla
        all_assets = set()
        for cluster_assets in previous_clusters.values():
            all_assets.update(cluster_assets)
        for cluster_assets in current_clusters.values():
            all_assets.update(cluster_assets)
        
        # Her varlık için küme değişimini kontrol et
        asset_cluster_map = {}
        for cluster_name, assets in previous_clusters.items():
            for asset in assets:
                asset_cluster_map[asset] = cluster_name
        
        current_asset_cluster_map = {}
        for cluster_name, assets in current_clusters.items():
            for asset in assets:
                current_asset_cluster_map[asset] = cluster_name
        
        for asset in all_assets:
            old_cluster = asset_cluster_map.get(asset, 'none')
            new_cluster = current_asset_cluster_map.get(asset, 'none')
            
            if old_cluster != new_cluster:
                changes['changes_detected'] = True
                changes['moved_assets'].append({
                    'asset': asset,
                    'old_cluster': old_cluster,
                    'new_cluster': new_cluster
                })
        
        # Yeni ve kaldırılan kümeleri tespit et
        previous_cluster_names = set(previous_clusters.keys())
        current_cluster_names = set(current_clusters.keys())
        
        changes['new_clusters'] = list(current_cluster_names - previous_cluster_names)
        changes['removed_clusters'] = list(previous_cluster_names - current_cluster_names)
        
        # Değişim türü
        if changes['moved_assets']:
            if len(changes['moved_assets']) > len(all_assets) * 0.5:
                changes['change_type'] = 'major_reshuffle'
            elif len(changes['moved_assets']) > len(all_assets) * 0.2:
                changes['change_type'] = 'moderate_change'
            else:
                changes['change_type'] = 'minor_change'
        else:
            changes['change_type'] = 'no_change'
        
        # Önceki kümeleri kaydet
        self.cluster_stability['previous_clusters'] = current_clusters
        
        return changes
    
    def calculate_cluster_stability(self, 
                                  correlation_matrix: pd.DataFrame,
                                  window_size: int = 168) -> Dict[str, float]:
        """
        Küme stabilitesini hesapla
        
        Args:
            correlation_matrix: Korelasyon matrisi
            window_size: Analiz penceresi (saat)
            
        Returns:
            Dict: Küme stabilite metrikleri
        """
        stability_metrics = {}
        
        # Mevcut kümeleri kullan
        if not self.last_clusters:
            return stability_metrics
        
        # Her küme için stabilite hesapla
        for cluster_name, assets in self.last_clusters.items():
            if len(assets) < 2:
                stability_metrics[cluster_name] = 1.0
                continue
            
            # Küme içi korelasyonları al
            internal_correlations = []
            for i, asset1 in enumerate(assets):
                for asset2 in assets[i+1:]:
                    if asset1 in correlation_matrix.index and asset2 in correlation_matrix.columns:
                        corr = abs(correlation_matrix.loc[asset1, asset2])
                        internal_correlations.append(corr)
            
            if internal_correlations:
                # Korelasyon varyansı (düşük = stabil)
                correlation_std = np.std(internal_correlations)
                stability_score = 1.0 / (1.0 + correlation_std)
                stability_metrics[cluster_name] = stability_score
            else:
                stability_metrics[cluster_name] = 0.0
        
        self.cluster_stability.update(stability_metrics)
        return stability_metrics
    
    def get_correlation_network(self, 
                              correlation_matrix: pd.DataFrame,
                              min_correlation: float = None) -> nx.Graph:
        """
        Korelasyon ağ grafi oluştur
        
        Args:
            correlation_matrix: Korelasyon matrisi
            min_correlation: Minimum korelasyon eşiği
            
        Returns:
            nx.Graph: Korelasyon ağ grafi
        """
        if min_correlation is None:
            min_correlation = self.clustering_threshold
        
        assets = correlation_matrix.index.tolist()
        graph = nx.Graph()
        
        # Düğümleri ekle
        graph.add_nodes_from(assets)
        
        # Kenar ekle
        for i, asset1 in enumerate(assets):
            for j, asset2 in enumerate(assets[i+1:], i+1):
                correlation = correlation_matrix.loc[asset1, asset2]
                if abs(correlation) >= min_correlation:
                    graph.add_edge(
                        asset1, asset2,
                        weight=abs(correlation),
                        correlation=correlation,
                        type='strong' if abs(correlation) >= 0.8 else 'moderate'
                    )
        
        self.correlation_graph = graph
        return graph
    
    def analyze_network_metrics(self, graph: nx.Graph = None) -> Dict[str, Any]:
        """
        Ağ metriklerini analiz et
        
        Args:
            graph: NetworkX grafi (None = mevcut graf)
            
        Returns:
            Dict: Ağ analiz metrikleri
        """
        if graph is None:
            graph = self.correlation_graph
        
        if graph is None:
            return {}
        
        metrics = {
            'node_count': graph.number_of_nodes(),
            'edge_count': graph.number_of_edges(),
            'density': nx.density(graph),
            'average_clustering': nx.average_clustering(graph),
            'connected_components': list(nx.connected_components(graph))
        }
        
        # Merkezilik metrikleri
        if graph.number_of_edges() > 0:
            metrics['degree_centrality'] = nx.degree_centrality(graph)
            metrics['betweenness_centrality'] = nx.betweenness_centrality(graph)
            metrics['closeness_centrality'] = nx.closeness_centrality(graph)
            
            # En önemli varlıklar
            top_nodes_by_degree = sorted(
                metrics['degree_centrality'].items(),
                key=lambda x: x[1], reverse=True
            )[:5]
            
            top_nodes_by_betweenness = sorted(
                metrics['betweenness_centrality'].items(),
                key=lambda x: x[1], reverse=True
            )[:5]
            
            metrics['top_correlated_assets'] = {
                'by_degree': top_nodes_by_degree,
                'by_betweenness': top_nodes_by_betweenness
            }
        
        return metrics
    
    def detect_correlation_outliers(self, 
                                  correlation_matrix: pd.DataFrame,
                                  threshold_percentile: float = 95) -> Dict[str, Any]:
        """
        Korelasyon outlierlarını tespit et
        
        Args:
            correlation_matrix: Korelasyon matrisi
            threshold_percentile: Eşik yüzdelik
            
        Returns:
            Dict: Outlier analizi
        """
        # Tüm korelasyon değerlerini al (diagonal hariç)
        correlations = []
        asset_pairs = []
        
        for i, asset1 in enumerate(correlation_matrix.index):
            for j, asset2 in enumerate(correlation_matrix.columns):
                if i != j:  # Diagonal hariç
                    correlations.append(abs(correlation_matrix.loc[asset1, asset2]))
                    asset_pairs.append((asset1, asset2))
        
        if not correlations:
            return {}
        
        correlations = np.array(correlations)
        
        # Eşik belirle
        threshold = np.percentile(correlations, threshold_percentile)
        
        # Outlierları bul
        outliers = []
        for i, (asset1, asset2) in enumerate(asset_pairs):
            if correlations[i] >= threshold:
                outliers.append({
                    'asset1': asset1,
                    'asset2': asset2,
                    'correlation': correlation_matrix.loc[asset1, asset2],
                    'abs_correlation': correlations[i]
                })
        
        # Sonuçları sırala
        outliers.sort(key=lambda x: x['abs_correlation'], reverse=True)
        
        return {
            'outliers': outliers,
            'threshold': threshold,
            'outlier_count': len(outliers),
            'total_pairs': len(asset_pairs),
            'outlier_percentage': (len(outliers) / len(asset_pairs)) * 100
        }