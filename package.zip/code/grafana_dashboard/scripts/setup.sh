#!/bin/bash

# Bitwisers 2.0 Grafana Dashboard Setup Script
# Bu betik Grafana ve Prometheus'u başlatır ve gerekli ayarları yapar

set -e

# Renk kodları
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging fonksiyonu
log() {
    echo -e "${BLUE}[$(date +'%Y-%m-%d %H:%M:%S')]${NC} $1"
}

success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Ana dizin kontrolü
if [ ! -f "docker-compose.yml" ]; then
    error "Docker Compose dosyası bulunamadı. Lütfen doğru dizinde olduğunuzdan emin olun."
    exit 1
fi

# Docker ve Docker Compose kontrolü
log "Docker durumu kontrol ediliyor..."
if ! command -v docker &> /dev/null; then
    error "Docker yüklü değil. Lütfen Docker'ı yükleyin."
    exit 1
fi

if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
    error "Docker Compose yüklü değil. Lütfen Docker Compose'u yükleyin."
    exit 1
fi

# Mevcut container'ları durdur
log "Mevcut container'lar durduruluyor..."
if command -v docker-compose &> /dev/null; then
    docker-compose down --remove-orphans
else
    docker compose down --remove-orphans
fi

# Volume'leri temizle (opsiyonel)
read -p "Volume'leri temizlemek istiyor musunuz? (y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    log "Volume'ler temizleniyor..."
    if command -v docker-compose &> /dev/null; then
        docker-compose down -v --remove-orphans
    else
        docker compose down -v --remove-orphans
    fi
fi

# Metrics dosyalarını hazırla
log "Metrics dosyaları hazırlanıyor..."
if [ -f "metrics/bitwisers_metrics.prom" ]; then
    # Metrics dosyasını kopyala (eğer gerekirse)
    cp metrics/bitwisers_metrics.prom /tmp/metrics_temp.prom
    success "Metrics dosyası hazırlandı"
else
    warning "Metrics dosyası bulunamadı, demo metrics kullanılacak"
fi

# Docker network oluştur
log "Monitoring network oluşturuluyor..."
docker network create bitwisers-monitoring --driver bridge || true

# Container'ları başlat
log "Container'lar başlatılıyor..."
if command -v docker-compose &> /dev/null; then
    docker-compose up -d
else
    docker compose up -d
fi

# Servislerin başlamasını bekle
log "Servislerin başlaması bekleniyor..."

# Prometheus durum kontrolü
log "Prometheus durumu kontrol ediliyor..."
for i in {1..30}; do
    if curl -s http://localhost:9090/-/healthy > /dev/null 2>&1; then
        success "Prometheus çalışıyor"
        break
    fi
    if [ $i -eq 30 ]; then
        error "Prometheus başlatılamadı"
        exit 1
    fi
    sleep 2
done

# Grafana durum kontrolü
log "Grafana durumu kontrol ediliyor..."
for i in {1..30}; do
    if curl -s http://localhost:3000/api/health > /dev/null 2>&1; then
        success "Grafana çalışıyor"
        break
    fi
    if [ $i -eq 30 ]; then
        error "Grafana başlatılamadı"
        exit 1
    fi
    sleep 2
done

# Dashboard'u yükle
log "Dashboard yükleniyor..."
if [ -f "dashboards/bitwisers_trading_dashboard.json" ]; then
    # Grafana API ile dashboard yükle
    curl -X POST \
        -H "Content-Type: application/json" \
        -u admin:admin123 \
        -d @dashboards/bitwisers_trading_dashboard.json \
        http://localhost:3000/api/dashboards/db
    success "Dashboard yüklendi"
else
    warning "Dashboard dosyası bulunamadı"
fi

# Erişim bilgileri
echo -e "\n${GREEN}=== Bitwisers 2.0 Dashboard Başarıyla Kuruldu! ===${NC}"
echo -e "\n${BLUE}Erişim Bilgileri:${NC}"
echo -e "Grafana: ${GREEN}http://localhost:3000${NC}"
echo -e "Kullanıcı Adı: ${GREEN}admin${NC}"
echo -e "Şifre: ${GREEN}admin123${NC}"
echo -e "Prometheus: ${GREEN}http://localhost:9090${NC}"
echo -e "Node Exporter: ${GREEN}http://localhost:9100${NC}"
echo -e "cAdvisor: ${GREEN}http://localhost:8080${NC}"

echo -e "\n${BLUE}Yararlı Komutlar:${NC}"
echo -e "Container'ları durdur: ${YELLOW}docker-compose down${NC}"
echo -e "Container'ları başlat: ${YELLOW}docker-compose up -d${NC}"
echo -e "Logs'ları gör: ${YELLOW}docker-compose logs -f${NC}"
echo -e "Container'ları yeniden başlat: ${YELLOW}docker-compose restart${NC}"

echo -e "\n${BLUE}Dashboard İçeriği:${NC}"
echo -e "✓ Real-time P&L Grafikleri"
echo -e "✓ Portfolio Dağılım Görselleri"
echo -e "✓ Strateji Performans Karşılaştırmaları"
echo -e "✓ Risk Metrikleri"
echo -e "✓ Sistem Sağlık Monitörleri"
echo -e "✓ Market Rejim Göstergeleri"
echo -e "✓ Korelasyon Isı Haritaları"
echo -e "✓ Drawdown Analizi"
echo -e "✓ Benchmark Karşılaştırmaları"
echo -e "✓ Alert Durum Panelleri"
echo -e "✓ Execution Performans Metrikleri"
echo -e "✓ Özel Trading Widget'leri"

echo -e "\n${GREEN}Dashboard'u kullanmaya hazırsınız!${NC}"