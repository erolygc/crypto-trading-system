#!/bin/bash

# Bitwisers 2.0 Monitoring & Alerting Script
# Bu betik trading sistemini izler ve uyarılar gönderir

set -e

# Konfigürasyon
GRAFANA_URL="http://localhost:3000"
PROMETHEUS_URL="http://localhost:9090"
ALERT_EMAIL="admin@bitwisers.com"
SLACK_WEBHOOK=""
DINGTALK_WEBHOOK=""
DISCORD_WEBHOOK=""

# Alert thresholds
PNL_THRESHOLD=-5000
DRAWDOWN_THRESHOLD=0.15
VOLATILITY_THRESHOLD=2.5
CPU_THRESHOLD=80
MEMORY_THRESHOLD=85
LATENCY_THRESHOLD=1000
SLIPPAGE_THRESHOLD=0.001

# Logging fonksiyonları
log_info() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] [INFO] $1"
}

log_warn() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] [WARN] $1"
}

log_error() {
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] [ERROR] $1"
}

# Prometheus'dan metrik sorgula
query_prometheus() {
    local query="$1"
    local response=$(curl -s "$PROMETHEUS_URL/api/v1/query?query=$query" | jq -r '.data.result[0].value[1] // 0')
    echo "$response"
}

# Alert gönderme fonksiyonları
send_email_alert() {
    local subject="$1"
    local message="$2"
    
    if command -v mail &> /dev/null; then
        echo "$message" | mail -s "Bitwisers Alert: $subject" "$ALERT_EMAIL"
        log_info "Email alert sent: $subject"
    else
        log_warn "Mail command not available, skipping email alert"
    fi
}

send_slack_alert() {
    local message="$1"
    
    if [ ! -z "$SLACK_WEBHOOK" ]; then
        curl -X POST -H 'Content-type: application/json' \
            --data "{\"text\":\"🚨 Bitwisers Alert: $message\"}" \
            "$SLACK_WEBHOOK"
        log_info "Slack alert sent: $message"
    else
        log_warn "Slack webhook not configured, skipping Slack alert"
    fi
}

send_dingtalk_alert() {
    local message="$1"
    
    if [ ! -z "$DINGTALK_WEBHOOK" ]; then
        curl -X POST -H 'Content-type: application/json' \
            --data "{\"msgtype\": \"text\",\"text\": {\"content\": \"🚨 Bitwisers Alert: $message\"}}" \
            "$DINGTALK_WEBHOOK"
        log_info "DingTalk alert sent: $message"
    else
        log_warn "DingTalk webhook not configured, skipping DingTalk alert"
    fi
}

send_discord_alert() {
    local message="$1"
    
    if [ ! -z "$DISCORD_WEBHOOK" ]; then
        curl -X POST -H 'Content-type: application/json' \
            --data "{\"content\": \"🚨 Bitwisers Alert: $message\"}" \
            "$DISCORD_WEBHOOK"
        log_info "Discord alert sent: $message"
    else
        log_warn "Discord webhook not configured, skipping Discord alert"
    fi
}

send_alert() {
    local subject="$1"
    local message="$2"
    
    log_error "ALERT: $subject - $message"
    
    send_email_alert "$subject" "$message"
    send_slack_alert "$message"
    send_dingtalk_alert "$message"
    send_discord_alert "$message"
}

# P&L Alert Kontrolü
check_pnl_alerts() {
    log_info "Checking P&L alerts..."
    
    local total_pnl=$(query_prometheus "sum(trade_pnl_total)")
    local pnl_change_1h=$(query_prometheus "sum(increase(trade_pnl_total[1h]))")
    local pnl_percentage=$(query_prometheus "avg(trade_pnl_percentage)")
    
    if (( $(echo "$total_pnl < $PNL_THRESHOLD" | bc -l) )); then
        send_alert "P&L Below Threshold" "Total P&L: $total_pnl USD (Threshold: $PNL_THRESHOLD USD)"
    fi
    
    if (( $(echo "$pnl_change_1h < -2000" | bc -l) )); then
        send_alert "High P&L Loss" "1h P&L Change: $pnl_change_1h USD"
    fi
    
    if (( $(echo "$pnl_percentage < -5" | bc -l) )); then
        send_alert "High Percentage Loss" "P&L Percentage: $pnl_percentage%"
    fi
}

# Risk Alert Kontrolü
check_risk_alerts() {
    log_info "Checking risk alerts..."
    
    local max_drawdown=$(query_prometheus "portfolio_drawdown")
    local volatility=$(query_prometheus "market_regime_volatility")
    
    if (( $(echo "$max_drawdown > $DRAWDOWN_THRESHOLD" | bc -l) )); then
        send_alert "High Drawdown" "Maximum Drawdown: $max_drawdown (Threshold: $DRAWDOWN_THRESHOLD)"
    fi
    
    if (( $(echo "$volatility > $VOLATILITY_THRESHOLD" | bc -l) )); then
        send_alert "High Market Volatility" "Volatility: $volatility (Threshold: $VOLATILITY_THRESHOLD)"
    fi
}

# Sistem Sağlık Alert Kontrolü
check_system_health_alerts() {
    log_info "Checking system health alerts..."
    
    local cpu_usage=$(query_prometheus "avg(rate(container_cpu_usage_seconds_total[5m])) * 100")
    local memory_usage=$(query_prometheus "avg(container_memory_usage_bytes / container_spec_memory_limit_bytes * 100)")
    local db_connections=$(query_prometheus "pg_stat_database_numbackends")
    local kafka_lag=$(query_prometheus "kafka_consumer_lag")
    
    if (( $(echo "$cpu_usage > $CPU_THRESHOLD" | bc -l) )); then
        send_alert "High CPU Usage" "CPU Usage: $cpu_usage% (Threshold: $CPU_THRESHOLD%)"
    fi
    
    if (( $(echo "$memory_usage > $MEMORY_THRESHOLD" | bc -l) )); then
        send_alert "High Memory Usage" "Memory Usage: $memory_usage% (Threshold: $MEMORY_THRESHOLD%)"
    fi
    
    if (( $(echo "$db_connections > 50" | bc -l) )); then
        send_alert "High Database Connections" "Active DB Connections: $db_connections"
    fi
    
    if (( $(echo "$kafka_lag > 1000" | bc -l) )); then
        send_alert "High Kafka Lag" "Consumer Lag: $kafka_lag"
    fi
}

# Execution Alert Kontrolü
check_execution_alerts() {
    log_info "Checking execution alerts..."
    
    local avg_slippage=$(query_prometheus "avg(execution_metrics{metric_type=\"avg_slippage\"})")
    local avg_latency=$(query_prometheus "avg(execution_metrics{metric_type=\"latency\"})")
    local avg_fill_rate=$(query_prometheus "avg(execution_metrics{metric_type=\"fill_rate\"})")
    
    if (( $(echo "$avg_slippage > $SLIPPAGE_THRESHOLD" | bc -l) )); then
        send_alert "High Slippage" "Average Slippage: $avg_slippage (Threshold: $SLIPPAGE_THRESHOLD)"
    fi
    
    if (( $(echo "$avg_latency > $LATENCY_THRESHOLD" | bc -l) )); then
        send_alert "High Latency" "Average Latency: ${avg_latency}ms (Threshold: ${LATENCY_THRESHOLD}ms)"
    fi
    
    if (( $(echo "$avg_fill_rate < 0.9" | bc -l) )); then
        send_alert "Low Fill Rate" "Average Fill Rate: $avg_fill_rate"
    fi
}

# Alert geçmişi kontrolü
check_alert_history() {
    log_info "Checking alert history..."
    
    local active_alerts=$(query_prometheus "alert_active_count")
    local critical_alerts=$(query_prometheus "alert_critical_count")
    
    if (( $(echo "$critical_alerts > 0" | bc -l) )); then
        send_alert "Critical Alerts Active" "Number of Critical Alerts: $critical_alerts"
    fi
    
    if (( $(echo "$active_alerts > 10" | bc -l) )); then
        send_alert "High Number of Active Alerts" "Number of Active Alerts: $active_alerts"
    fi
}

# Strateji performans kontrolü
check_strategy_performance() {
    log_info "Checking strategy performance..."
    
    # DVK Strategy
    local dvk_performance=$(query_prometheus "strategy_performance_24h{strategy=\"dvk\"}")
    if (( $(echo "$dvk_performance < -10" | bc -l) )); then
        send_alert "DVK Strategy Underperformance" "24h Performance: $dvk_performance%"
    fi
    
    # Genetic Strategy
    local genetic_performance=$(query_prometheus "strategy_performance_24h{strategy=\"genetic\"}")
    if (( $(echo "$genetic_performance < -10" | bc -l) )); then
        send_alert "Genetic Strategy Underperformance" "24h Performance: $genetic_performance%"
    fi
    
    # Iceberg Strategy
    local iceberg_performance=$(query_prometheus "strategy_performance_24h{strategy=\"iceberg\"}")
    if (( $(echo "$iceberg_performance < -10" | bc -l) )); then
        send_alert "Iceberg Strategy Underperformance" "24h Performance: $iceberg_performance%"
    fi
}

# Market rejim kontrolü
check_market_regime() {
    log_info "Checking market regime..."
    
    local liquidity=$(query_prometheus "market_regime_liquidity")
    local trend=$(query_prometheus "market_regime_trend")
    
    if (( $(echo "$liquidity < 0.3" | bc -l) )); then
        send_alert "Low Market Liquidity" "Liquidity Level: $liquidity"
    fi
    
    if (( $(echo "$trend > 3.0" | bc -l) )); then
        send_alert "Extreme Market Trend" "Trend Strength: $trend"
    fi
}

# Grafana dashboard sağlık kontrolü
check_grafana_health() {
    if curl -s "$GRAFANA_URL/api/health" > /dev/null; then
        log_info "Grafana is healthy"
    else
        log_error "Grafana is not responding"
    fi
}

# Prometheus sağlık kontrolü
check_prometheus_health() {
    if curl -s "$PROMETHEUS_URL/-/healthy" > /dev/null; then
        log_info "Prometheus is healthy"
    else
        log_error "Prometheus is not responding"
    fi
}

# Ana monitoring fonksiyonu
run_monitoring_cycle() {
    log_info "Starting monitoring cycle..."
    
    check_grafana_health
    check_prometheus_health
    check_pnl_alerts
    check_risk_alerts
    check_system_health_alerts
    check_execution_alerts
    check_alert_history
    check_strategy_performance
    check_market_regime
    
    log_info "Monitoring cycle completed"
}

# Sürekli monitoring başlat
start_continuous_monitoring() {
    local interval=${1:-60}  # Default 60 seconds
    
    log_info "Starting continuous monitoring (interval: ${interval}s)"
    
    while true; do
        run_monitoring_cycle
        sleep $interval
    done
}

# Manuel alert testi
test_alerts() {
    log_info "Testing alert system..."
    
    send_alert "Test Alert" "This is a test alert from Bitwisers 2.0 monitoring system"
    
    log_info "Test alert sent. Check your configured notification channels."
}

# Dashboard'u yenile
refresh_dashboard() {
    log_info "Refreshing Grafana dashboard..."
    
    # Dashboard cache'ini temizle
    curl -X POST "$GRAFANA_URL/api/admin/settings" \
        -H "Content-Type: application/json" \
        -u admin:admin123 \
        -d '{"disable_sanitize_html": false}'
    
    log_info "Dashboard refresh initiated"
}

# Yardım mesajı
show_help() {
    cat << EOF
Bitwisers 2.0 Monitoring & Alerting Script

Usage: $0 {command} [options]

Commands:
    monitor          Run one-time monitoring cycle
    continuous [sec] Start continuous monitoring (default: 60s interval)
    test-alerts      Send test alert
    refresh          Refresh Grafana dashboard
    health           Check system health
    help             Show this help message

Environment Variables:
    GRAFANA_URL      Grafana URL (default: http://localhost:3000)
    PROMETHEUS_URL   Prometheus URL (default: http://localhost:9090)
    ALERT_EMAIL      Email for alerts
    SLACK_WEBHOOK    Slack webhook URL
    DINGTALK_WEBHOOK DingTalk webhook URL
    DISCORD_WEBHOOK  Discord webhook URL

Examples:
    $0 monitor
    $0 continuous 30
    $0 test-alerts
    $0 refresh

EOF
}

# Ana komut işleme
case "${1:-help}" in
    monitor)
        run_monitoring_cycle
        ;;
    continuous)
        start_continuous_monitoring ${2:-60}
        ;;
    test-alerts)
        test_alerts
        ;;
    refresh)
        refresh_dashboard
        ;;
    health)
        check_grafana_health
        check_prometheus_health
        ;;
    help|--help|-h)
        show_help
        ;;
    *)
        echo "Unknown command: $1"
        show_help
        exit 1
        ;;
esac