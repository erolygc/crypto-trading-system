#!/bin/bash

# Bitwisers 2.0 Trading Metrics Generator
# Bu betik gerçek zamanlı trading metrikleri üretir

set -e

# Konfigürasyon
METRICS_ENDPOINT="http://localhost:9090/metrics"
PROM_FILE="metrics/bitwisers_metrics.prom"
INTERVAL=5
PORT=8081

# Metrikler
declare -A trading_metrics
trading_metrics=(
    ["trade_pnl_total"]=0
    ["trade_pnl_percentage"]=0
    ["strategy_performance_24h_dvk"]=2.5
    ["strategy_performance_24h_genetic"]=1.8
    ["strategy_performance_24h_iceberg"]=3.2
    ["strategy_performance_24h_twap_vwap"]=1.5
    ["portfolio_allocation_btc"]=40000
    ["portfolio_allocation_eth"]=25000
    ["portfolio_allocation_sol"]=15000
    ["portfolio_allocation_usdt"]=10000
    ["market_regime_volatility"]=0.85
    ["market_regime_trend"]=1.2
    ["market_regime_liquidity"]=0.75
    ["alert_active_count"]=3
    ["alert_critical_count"]=1
    ["alert_warning_count"]=2
    ["container_cpu_usage"]=25.5
    ["container_memory_usage"]=1073741824
    ["pg_stat_database_numbackends"]=15
    ["kafka_consumer_lag"]=120
    ["http_request_duration_seconds"]=0.085
)

# Yardımcı fonksiyonlar
generate_random_change() {
    local current_value=$1
    local change_percent=$((RANDOM % 200 - 100)) # -100% ile +100% arası rastgele
    local new_value=$(echo "$current_value * (1 + $change_percent / 100.0)" | bc -l)
    echo $new_value
}

generate_correlation_data() {
    local assets=("BTC" "ETH" "SOL" "USDT")
    local correlations=()
    
    for ((i=0; i<${#assets[@]}; i++)); do
        for ((j=i+1; j<${#assets[@]}; j++)); do
            local corr=$(awk -v min=-0.5 -v max=0.9 'BEGIN{srand(); print min+rand()*(max-min)}')
            correlations+=("asset_correlation{asset1=\"${assets[i]}\", asset2=\"${assets[j]}\"} $corr")
        done
    done
    
    echo "${correlations[@]}"
}

generate_execution_metrics() {
    local strategies=("dvk" "genetic" "iceberg" "twap_vwap")
    local symbols=("BTC" "ETH" "SOL")
    local metrics=()
    
    for strategy in "${strategies[@]}"; do
        for symbol in "${symbols[@]}"; do
            local slippage=$(awk -v min=0.0001 -v max=0.001 'BEGIN{srand(); print min+rand()*(max-min)}')
            local fill_rate=$(awk -v min=0.85 -v max=0.99 'BEGIN{srand(); print min+rand()*(max-min)}')
            local latency=$(shuf -i 50-300 -n 1)
            
            metrics+=("execution_metrics{strategy=\"$strategy\", symbol=\"$symbol\", metric_type=\"avg_slippage\"} $slippage")
            metrics+=("execution_metrics{strategy=\"$strategy\", symbol=\"$symbol\", metric_type=\"fill_rate\"} $fill_rate")
            metrics+=("execution_metrics{strategy=\"$strategy\", symbol=\"$symbol\", metric_type=\"latency\"} $latency")
        done
    done
    
    echo "${metrics[@]}"
}

generate_signal_strength() {
    local strategies=("dvk" "genetic" "iceberg" "twap_vwap")
    local signals=()
    
    for strategy in "${strategies[@]}"; do
        local strength=$(awk -v min=0.3 -v max=1.0 'BEGIN{srand(); print min+rand()*(max-min)}')
        signals+=("signal_strength{strategy=\"$strategy\"} $strength")
    done
    
    echo "${signals[@]}"
}

# Prometheus formatında metrikler oluştur
generate_prometheus_metrics() {
    local timestamp=$(date +%s)
    local output=""
    
    # Temel trading metrikleri
    local pnl_change=$(awk -v min=-5000 -v max=5000 'BEGIN{srand(); print min+rand()*(max-min)}')
    local pnl_percentage=$(awk -v min=-2.0 -v max=3.0 'BEGIN{srand(); print min+rand()*(max-min)}')
    
    output+="# HELP trade_pnl_total Total P&L of trading strategies\n"
    output+="# TYPE trade_pnl_total counter\n"
    output+="trade_pnl_total{strategy=\"dvk\"} $pnl_change\n"
    output+="trade_pnl_total{strategy=\"genetic\"} $((pnl_change + 1500))\n"
    output+="trade_pnl_total{strategy=\"iceberg\"} $((pnl_change - 800))\n\n"
    
    output+="# HELP trade_pnl_percentage P&L percentage\n"
    output+="# TYPE trade_pnl_percentage gauge\n"
    output+="trade_pnl_percentage $pnl_percentage\n\n"
    
    # Strateji performansı
    output+="# HELP strategy_performance_24h 24h strategy performance\n"
    output+="# TYPE strategy_performance_24h gauge\n"
    output+="strategy_performance_24h{strategy=\"dvk\"} $((RANDOM % 500 - 200))\n"
    output+="strategy_performance_24h{strategy=\"genetic\"} $((RANDOM % 400 - 150))\n"
    output+="strategy_performance_24h{strategy=\"iceberg\"} $((RANDOM % 600 - 250))\n"
    output+="strategy_performance_24h{strategy=\"twap_vwap\"} $((RANDOM % 300 - 100))\n\n"
    
    # Portfolio allocation
    output+="# HELP portfolio_allocation Portfolio allocation by asset\n"
    output+="# TYPE portfolio_allocation gauge\n"
    output+="portfolio_allocation{asset=\"BTC\", strategy=\"dvk\"} $((35000 + RANDOM % 10000))\n"
    output+="portfolio_allocation{asset=\"ETH\", strategy=\"genetic\"} $((20000 + RANDOM % 10000))\n"
    output+="portfolio_allocation{asset=\"SOL\", strategy=\"dvk\"} $((10000 + RANDOM % 10000))\n"
    output+="portfolio_allocation{asset=\"USDT\", strategy=\"risk_mgmt\"} $((8000 + RANDOM % 4000))\n\n"
    
    # Market regime indicators
    output+="# HELP market_regime_indicators Market regime metrics\n"
    output+="# TYPE market_regime_indicators gauge\n"
    output+="market_regime_volatility $((RANDOM % 100)).$((RANDOM % 9))\n"
    output+="market_regime_trend $((RANDOM % 200)).$((RANDOM % 9))\n"
    output+="market_regime_liquidity $((RANDOM % 100)).$((RANDOM % 9))\n\n"
    
    # Korelasyon verileri
    output+="# HELP asset_correlation Asset correlation matrix\n"
    output+="# TYPE asset_correlation gauge\n"
    local correlations
    IFS=' ' read -ra correlations <<< "$(generate_correlation_data)"
    for corr in "${correlations[@]}"; do
        output+="$corr\n"
    done
    output+="\n"
    
    # Alert metrics
    output+="# HELP alert_counters Alert counters\n"
    output+="# TYPE alert_counters gauge\n"
    output+="alert_active_count $((RANDOM % 5 + 1))\n"
    output+="alert_critical_count $((RANDOM % 3))\n"
    output+="alert_warning_count $((RANDOM % 4))\n\n"
    
    # Sistem sağlık metrikleri
    output+="# HELP system_health System health metrics\n"
    output+="# TYPE system_health gauge\n"
    output+="container_cpu_usage_seconds_total $((RANDOM % 30)).$((RANDOM % 9))\n"
    output+="container_memory_usage_bytes $((1073741824 + RANDOM % 50000000))\n"
    output+="container_spec_memory_limit_bytes 2147483648\n"
    output+="pg_stat_database_numbackends $((RANDOM % 20 + 10))\n"
    output+="kafka_consumer_lag $((RANDOM % 150 + 50))\n\n"
    
    # Execution metrics
    output+="# HELP execution_metrics Trading execution metrics\n"
    output+="# TYPE execution_metrics gauge\n"
    local execution_metrics
    IFS=' ' read -ra execution_metrics <<< "$(generate_execution_metrics)"
    for metric in "${execution_metrics[@]}"; do
        output+="$metric\n"
    done
    output+="\n"
    
    # Signal strength
    output+="# HELP signal_strength Strategy signal strength\n"
    output+="# TYPE signal_strength gauge\n"
    local signals
    IFS=' ' read -ra signals <<< "$(generate_signal_strength)"
    for signal in "${signals[@]}"; do
        output+="$signal\n"
    done
    output+="\n"
    
    # Position size distribution
    output+="# HELP position_size_distribution Position size by asset\n"
    output+="# TYPE position_size_distribution gauge\n"
    output+="position_size_distribution{asset=\"BTC\"} $((35000 + RANDOM % 10000))\n"
    output+="position_size_distribution{asset=\"ETH\"} $((20000 + RANDOM % 10000))\n"
    output+="position_size_distribution{asset=\"SOL\"} $((10000 + RANDOM % 10000))\n\n"
    
    # Order latency buckets
    output+="# HELP order_latency_bucket Order execution latency histogram\n"
    output+="# TYPE order_latency_bucket counter\n"
    output+="order_latency_bucket{le=\"0.1\"} $((150 + RANDOM % 100))\n"
    output+="order_latency_bucket{le=\"0.25\"} $((80 + RANDOM % 50))\n"
    output+="order_latency_bucket{le=\"0.5\"} $((45 + RANDOM % 30))\n"
    output+="order_latency_bucket{le=\"1.0\"} $((25 + RANDOM % 15))\n"
    output+="order_latency_bucket{le=\"2.5\"} $((10 + RANDOM % 10))\n\n"
    
    # Strategy success rate
    output+="# HELP strategy_success_rate Strategy success rate\n"
    output+="# TYPE strategy_success_rate gauge\n"
    output+="strategy_success_rate{strategy=\"dvk\"} $((RANDOM % 30 + 60)).$((RANDOM % 9))\n"
    output+="strategy_success_rate{strategy=\"genetic\"} $((RANDOM % 35 + 55)).$((RANDOM % 9))\n"
    output+="strategy_success_rate{strategy=\"iceberg\"} $((RANDOM % 25 + 70)).$((RANDOM % 9))\n"
    output+="strategy_success_rate{strategy=\"twap_vwap\"} $((RANDOM % 40 + 50)).$((RANDOM % 9))\n\n"
    
    echo -e "$output"
}

# HTTP sunucusu başlat
start_metrics_server() {
    local metrics_port=${1:-8081}
    
    if command -v python3 &> /dev/null; then
        cat > /tmp/metrics_server.py << 'EOF'
import time
import random
import subprocess
import os
from http.server import HTTPServer, BaseHTTPRequestHandler

class MetricsHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/metrics':
            try:
                # Generate metrics
                result = subprocess.run(['bash', '-c', '''
                # HELP trade_pnl_total Total P&L
                # TYPE trade_pnl_total counter
                trade_pnl_total{strategy="dvk"} {0}
                trade_pnl_total{strategy="genetic"} {1}
                
                # HELP strategy_performance_24h Performance metrics
                # TYPE strategy_performance_24h gauge
                strategy_performance_24h{strategy="dvk"} {2}
                strategy_performance_24h{strategy="genetic"} {3}
                strategy_performance_24h{strategy="iceberg"} {4}
                strategy_performance_24h{strategy="twap_vwap"} {5}
                
                # HELP market_regime_indicators Market regime
                # TYPE market_regime_indicators gauge
                market_regime_volatility {6}
                market_regime_trend {7}
                market_regime_liquidity {8}
                
                # HELP portfolio_allocation Allocation
                # TYPE portfolio_allocation gauge
                portfolio_allocation{asset="BTC", strategy="dvk"} {9}
                portfolio_allocation{asset="ETH", strategy="genetic"} {10}
                portfolio_allocation{asset="SOL", strategy="dvk"} {11}
                
                # HELP alert_counters Alert counts
                # TYPE alert_counters gauge
                alert_active_count {12}
                alert_critical_count {13}
                alert_warning_count {14}
                
                # HELP signal_strength Signal strength
                # TYPE signal_strength gauge
                signal_strength{strategy="dvk"} {15}
                signal_strength{strategy="genetic"} {16}
                signal_strength{strategy="iceberg"} {17}
                '''.format(
                    random.randint(-5000, 5000),
                    random.randint(-5000, 5000),
                    random.randint(-200, 500),
                    random.randint(-150, 400),
                    random.randint(-250, 600),
                    random.randint(-100, 300),
                    round(random.uniform(0.1, 2.0), 2),
                    round(random.uniform(0.5, 2.5), 2),
                    round(random.uniform(0.1, 1.5), 2),
                    random.randint(30000, 50000),
                    random.randint(15000, 35000),
                    random.randint(10000, 25000),
                    random.randint(1, 8),
                    random.randint(0, 3),
                    random.randint(1, 6),
                    round(random.uniform(0.3, 1.0), 2),
                    round(random.uniform(0.3, 1.0), 2),
                    round(random.uniform(0.3, 1.0), 2)
                )], capture_output=True, text=True)
                
                metrics_data = result.stdout
                
                self.send_response(200)
                self.send_header('Content-type', 'text/plain')
                self.end_headers()
                self.wfile.write(metrics_data.encode())
            except Exception as e:
                self.send_response(500)
                self.send_header('Content-type', 'text/plain')
                self.end_headers()
                self.wfile.write(f"Error: {str(e)}".encode())
        else:
            self.send_response(404)
            self.end_headers()
    
    def log_message(self, format, *args):
        pass  # Suppress default logging

if __name__ == '__main__':
    server = HTTPServer(('', {metrics_port}), MetricsHandler)
    print(f"Metrics server started on port {metrics_port}")
    server.serve_forever()
EOF
        python3 /tmp/metrics_server.py &
        echo $!
    else
        echo "Python3 not found, using static metrics"
        return 1
    fi
}

# Ana fonksiyonlar
start_metrics_generator() {
    echo "Starting Bitwisers 2.0 Metrics Generator..."
    echo "Port: $PORT"
    echo "Interval: ${INTERVAL}s"
    echo "Press Ctrl+C to stop"
    echo ""
    
    # Metrics sunucusunu başlat
    local server_pid=$(start_metrics_server $PORT)
    if [ $? -eq 0 ]; then
        echo "Metrics HTTP server started (PID: $server_pid)"
    fi
    
    # Ana döngü
    local count=0
    while true; do
        echo "[$count] Generating metrics at $(date)"
        
        # Prometheus dosyasını güncelle
        generate_prometheus_metrics > "$PROM_FILE"
        
        # HTTP sunucusuna veri gönder
        if command -v curl &> /dev/null; then
            curl -s -X POST \
                -H "Content-Type: text/plain" \
                --data-binary @<(generate_prometheus_metrics) \
                http://localhost:9090/api/v1/import/prometheus || true
        fi
        
        sleep $INTERVAL
        count=$((count + 1))
    done
    
    # Cleanup
    if [ ! -z "$server_pid" ]; then
        kill $server_pid 2>/dev/null || true
    fi
}

stop_metrics_generator() {
    pkill -f metrics_server.py || true
    echo "Metrics generator stopped"
}

# Command line argument handling
case "${1:-start}" in
    start)
        start_metrics_generator
        ;;
    stop)
        stop_metrics_generator
        ;;
    generate)
        generate_prometheus_metrics
        ;;
    *)
        echo "Usage: $0 {start|stop|generate}"
        exit 1
        ;;
esac