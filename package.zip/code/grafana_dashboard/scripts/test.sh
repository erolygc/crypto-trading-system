#!/bin/bash

# Bitwisers 2.0 Dashboard Test Suite
# Bu betik dashboard'un tüm bileşenlerini test eder

set -e

# Renk kodları
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Test sonuçları
TESTS_PASSED=0
TESTS_FAILED=0

log_info() {
    echo -e "${BLUE}[TEST]${NC} $1"
}

log_pass() {
    echo -e "${GREEN}[PASS]${NC} $1"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

log_fail() {
    echo -e "${RED}[FAIL]${NC} $1"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

# Test fonksiyonları
test_docker_available() {
    log_info "Testing Docker availability..."
    if command -v docker &> /dev/null; then
        log_pass "Docker is available"
    else
        log_fail "Docker is not installed"
        return 1
    fi
}

test_docker_compose_available() {
    log_info "Testing Docker Compose availability..."
    if command -v docker-compose &> /dev/null || docker compose version &> /dev/null; then
        log_pass "Docker Compose is available"
    else
        log_fail "Docker Compose is not installed"
        return 1
    fi
}

test_directory_structure() {
    log_info "Testing directory structure..."
    
    local required_dirs=("dashboards" "metrics" "scripts" "configs")
    local required_files=(
        "dashboards/bitwisers_trading_dashboard.json"
        "metrics/bitwisers_metrics.prom"
        "scripts/setup.sh"
        "scripts/generate_metrics.sh"
        "scripts/monitoring.sh"
        "configs/prometheus.yml"
        "configs/grafana.ini"
        "docker-compose.yml"
    )
    
    for dir in "${required_dirs[@]}"; do
        if [ -d "$dir" ]; then
            log_pass "Directory exists: $dir"
        else
            log_fail "Missing directory: $dir"
        fi
    done
    
    for file in "${required_files[@]}"; do
        if [ -f "$file" ]; then
            log_pass "File exists: $file"
        else
            log_fail "Missing file: $file"
        fi
    done
}

test_json_syntax() {
    log_info "Testing JSON syntax..."
    
    if command -v jq &> /dev/null; then
        if jq empty dashboards/bitwisers_trading_dashboard.json 2>/dev/null; then
            log_pass "Dashboard JSON is valid"
        else
            log_fail "Dashboard JSON has syntax errors"
        fi
    else
        log_warn "jq not installed, skipping JSON validation"
        # Basit JSON validation
        if python3 -c "import json; json.load(open('dashboards/bitwisers_trading_dashboard.json'))" 2>/dev/null; then
            log_pass "Dashboard JSON is valid (Python check)"
        else
            log_fail "Dashboard JSON has syntax errors"
        fi
    fi
}

test_prometheus_config() {
    log_info "Testing Prometheus configuration..."
    
    if [ -f "configs/prometheus.yml" ]; then
        if command -v yamllint &> /dev/null; then
            yamllint configs/prometheus.yml
            log_pass "Prometheus YAML is valid"
        else
            log_warn "yamllint not installed, basic check only"
            if grep -q "global:" configs/prometheus.yml && grep -q "scrape_configs:" configs/prometheus.yml; then
                log_pass "Prometheus config has required sections"
            else
                log_fail "Prometheus config is missing required sections"
            fi
        fi
    else
        log_fail "Prometheus config file missing"
    fi
}

test_docker_compose_syntax() {
    log_info "Testing Docker Compose syntax..."
    
    if command -v docker-compose &> /dev/null; then
        if docker-compose config &> /dev/null; then
            log_pass "Docker Compose syntax is valid"
        else
            log_fail "Docker Compose syntax errors"
        fi
    else
        if docker compose config &> /dev/null; then
            log_pass "Docker Compose syntax is valid"
        else
            log_fail "Docker Compose syntax errors"
        fi
    fi
}

test_port_availability() {
    log_info "Testing port availability..."
    
    local ports=(3000 9090 9100 8080)
    for port in "${ports[@]}"; do
        if ! netstat -tuln 2>/dev/null | grep -q ":$port "; then
            log_pass "Port $port is available"
        else
            log_fail "Port $port is already in use"
        fi
    done
}

test_metrics_syntax() {
    log_info "Testing metrics file syntax..."
    
    if [ -f "metrics/bitwisers_metrics.prom" ]; then
        # Prometheus metrics basic validation
        if grep -q "^[^#]" metrics/bitwisers_metrics.prom; then
            log_pass "Metrics file has content"
            
            # Check for common metric patterns
            if grep -qE "^[a-zA-Z_][a-zA-Z0-9_]*\{" metrics/bitwisers_metrics.prom; then
                log_pass "Metrics file contains valid Prometheus metrics"
            else
                log_fail "Metrics file does not contain valid Prometheus metrics"
            fi
        else
            log_fail "Metrics file is empty or contains only comments"
        fi
    else
        log_fail "Metrics file does not exist"
    fi
}

test_script_executable() {
    log_info "Testing script permissions..."
    
    local scripts=("scripts/setup.sh" "scripts/generate_metrics.sh" "scripts/monitoring.sh")
    for script in "${scripts[@]}"; do
        if [ -f "$script" ]; then
            if [ -x "$script" ] || chmod +x "$script" 2>/dev/null; then
                log_pass "Script is executable: $script"
            else
                log_warn "Script may not be executable: $script"
            fi
        else
            log_fail "Script does not exist: $script"
        fi
    done
}

test_docker_containers() {
    log_info "Testing Docker container startup..."
    
    # Container'ları başlat
    if command -v docker-compose &> /dev/null; then
        docker-compose up -d --quiet
    else
        docker compose up -d --quiet
    fi
    
    sleep 5
    
    # Container durumlarını kontrol et
    local containers=("bitwisers_prometheus" "bitwisers_grafana" "bitwisers_node_exporter" "bitwisers_cadvisor")
    for container in "${containers[@]}"; do
        if docker ps --filter "name=$container" --format "{{.Status}}" | grep -q "Up"; then
            log_pass "Container is running: $container"
        else
            log_fail "Container is not running: $container"
        fi
    done
}

test_grafana_api() {
    log_info "Testing Grafana API..."
    
    # Grafana'nın hazır olmasını bekle
    local max_attempts=30
    local attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        if curl -s http://localhost:3000/api/health > /dev/null 2>&1; then
            log_pass "Grafana API is responding"
            break
        fi
        attempt=$((attempt + 1))
        sleep 2
    done
    
    if [ $attempt -eq $max_attempts ]; then
        log_fail "Grafana API is not responding after 60 seconds"
    fi
}

test_prometheus_api() {
    log_info "Testing Prometheus API..."
    
    # Prometheus'un hazır olmasını bekle
    local max_attempts=30
    local attempt=0
    
    while [ $attempt -lt $max_attempts ]; do
        if curl -s http://localhost:9090/-/healthy > /dev/null 2>&1; then
            log_pass "Prometheus API is responding"
            break
        fi
        attempt=$((attempt + 1))
        sleep 2
    done
    
    if [ $attempt -eq $max_attempts ]; then
        log_fail "Prometheus API is not responding after 60 seconds"
    fi
}

test_dashboard_load() {
    log_info "Testing dashboard loading..."
    
    # Dashboard'u yüklemeye çalış
    local dashboard_response=$(curl -s -X POST \
        -H "Content-Type: application/json" \
        -u admin:admin123 \
        -w "%{http_code}" \
        -o /tmp/dashboard_response.json \
        -d @dashboards/bitwisers_trading_dashboard.json \
        http://localhost:3000/api/dashboards/db)
    
    if [ "$dashboard_response" = "200" ]; then
        log_pass "Dashboard loaded successfully"
    else
        log_fail "Dashboard loading failed (HTTP: $dashboard_response)"
    fi
}

test_metrics_endpoint() {
    log_info "Testing metrics endpoint..."
    
    # Prometheus metrics endpoint
    if curl -s http://localhost:9090/metrics | grep -q "trade_pnl_total"; then
        log_pass "Prometheus metrics are available"
    else
        log_fail "Prometheus metrics are not available"
    fi
}

test_monitoring_script() {
    log_info "Testing monitoring script..."
    
    # Monitoring script'in çalışıp çalışmadığını test et
    if timeout 10 bash scripts/monitoring.sh health > /dev/null 2>&1; then
        log_pass "Monitoring script executed successfully"
    else
        log_fail "Monitoring script failed to execute"
    fi
}

test_metrics_generator() {
    log_info "Testing metrics generator..."
    
    # Metrics generator'i test et
    if bash scripts/generate_metrics.sh generate > /dev/null 2>&1; then
        log_pass "Metrics generator executed successfully"
        
        # Output kontrolü
        if bash scripts/generate_metrics.sh generate | grep -q "trade_pnl_total"; then
            log_pass "Metrics generator produces valid output"
        else
            log_fail "Metrics generator output is invalid"
        fi
    else
        log_fail "Metrics generator failed to execute"
    fi
}

cleanup_containers() {
    log_info "Cleaning up test containers..."
    
    if command -v docker-compose &> /dev/null; then
        docker-compose down --remove-orphans --quiet
    else
        docker compose down --remove-orphans --quiet
    fi
    
    log_pass "Containers cleaned up"
}

# Ana test fonksiyonu
run_all_tests() {
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE} Bitwisers 2.0 Dashboard Test Suite${NC}"
    echo -e "${BLUE}========================================${NC}"
    echo ""
    
    # Temel sistem testleri
    test_docker_available
    test_docker_compose_available
    test_port_availability
    
    echo ""
    echo -e "${BLUE}--- File Structure Tests ---${NC}"
    test_directory_structure
    
    echo ""
    echo -e "${BLUE}--- Configuration Tests ---${NC}"
    test_json_syntax
    test_prometheus_config
    test_docker_compose_syntax
    test_metrics_syntax
    
    echo ""
    echo -e "${BLUE}--- Script Tests ---${NC}"
    test_script_executable
    
    echo ""
    echo -e "${BLUE}--- Container Tests ---${NC}"
    test_docker_containers
    
    echo ""
    echo -e "${BLUE}--- API Tests ---${NC}"
    test_grafana_api
    test_prometheus_api
    test_dashboard_load
    test_metrics_endpoint
    
    echo ""
    echo -e "${BLUE}--- Integration Tests ---${NC}"
    test_monitoring_script
    test_metrics_generator
    
    echo ""
    echo -e "${BLUE}--- Cleanup ---${NC}"
    cleanup_containers
    
    # Test sonuçları
    echo ""
    echo -e "${BLUE}========================================${NC}"
    echo -e "${BLUE} Test Results Summary${NC}"
    echo -e "${BLUE}========================================${NC}"
    echo -e "${GREEN}Passed: $TESTS_PASSED${NC}"
    echo -e "${RED}Failed: $TESTS_FAILED${NC}"
    echo -e "${BLUE}Total: $((TESTS_PASSED + TESTS_FAILED))${NC}"
    echo ""
    
    if [ $TESTS_FAILED -eq 0 ]; then
        echo -e "${GREEN}🎉 All tests passed! Dashboard is ready to use.${NC}"
        return 0
    else
        echo -e "${RED}❌ Some tests failed. Please check the errors above.${NC}"
        return 1
    fi
}

# Komut satırı argümanları
case "${1:-all}" in
    all)
        run_all_tests
        ;;
    docker)
        test_docker_available
        test_docker_compose_available
        test_docker_containers
        ;;
    config)
        test_json_syntax
        test_prometheus_config
        test_docker_compose_syntax
        test_metrics_syntax
        ;;
    api)
        test_grafana_api
        test_prometheus_api
        test_dashboard_load
        test_metrics_endpoint
        ;;
    scripts)
        test_script_executable
        test_monitoring_script
        test_metrics_generator
        ;;
    cleanup)
        cleanup_containers
        ;;
    help|--help|-h)
        cat << EOF
Bitwisers 2.0 Dashboard Test Suite

Usage: $0 [command]

Commands:
    all     Run all tests (default)
    docker  Test Docker setup
    config  Test configuration files
    api     Test API endpoints
    scripts Test scripts
    cleanup Clean up containers
    help    Show this help message

Examples:
    $0              # Run all tests
    $0 docker       # Test Docker only
    $0 config       # Test configuration files only
    $0 api          # Test API endpoints only
    $0 cleanup      # Clean up containers

EOF
        ;;
    *)
        echo "Unknown command: $1"
        echo "Run '$0 help' for usage information"
        exit 1
        ;;
esac