# 🚀 Bitwisers 2.0 Grafana Dashboard

## 📊 Proje Açıklaması

Bitwisers 2.0 için geliştirilmiş kapsamlı Grafana trading dashboard'u. Real-time P&L takibi, portfolio analizi, risk yönetimi ve sistem sağlığını tek arayüzde sunan profesyonel trading monitörü.

### ✨ Özellikler

- **Real-time P&L Charts** 📈
- **Portfolio Allocation Visualizations** 🎯
- **Strategy Performance Comparisons** 🏆
- **Risk Metrics Dashboards** ⚠️
- **System Health Monitors** 🖥️
- **Market Regime Indicators** 🔴
- **Correlation Heatmaps** 🌡️
- **Drawdown Analysis** 📉
- **Benchmark Comparisons** 📊
- **Alert Status Boards** 🚨
- **Execution Performance Metrics** ⚡
- **Custom Trading Widgets** 🎮

### 🏗️ Proje Yapısı

```
code/grafana_dashboard/
├── dashboards/
│   └── bitwisers_trading_dashboard.json  # Ana dashboard konfigürasyonu
├── metrics/
│   └── bitwisers_metrics.prom           # Prometheus metrics dosyası
├── scripts/
│   ├── setup.sh                         # Kurulum betiği
│   ├── generate_metrics.sh              # Metrik jeneratörü
│   └── monitoring.sh                    # Monitoring & alerting
├── configs/
│   ├── prometheus.yml                   # Prometheus konfigürasyonu
│   └── grafana.ini                      # Grafana konfigürasyonu
└── docker-compose.yml                   # Container orchestrator
```

## 🚀 Hızlı Başlangıç

### 1. Kurulum

```bash
# Proje dizinine git
cd code/grafana_dashboard/

# Kurulum betiğini çalıştır
bash scripts/setup.sh
```

### 2. Erişim

- **Grafana**: http://localhost:3000 (admin/admin123)
- **Prometheus**: http://localhost:9090

### 3. Metrikleri Başlat

```bash
# Demo metrikleri oluştur (opsiyonel)
bash scripts/generate_metrics.sh start
```

### 4. Monitoring'i Aktifleştir

```bash
# Sürekli monitoring
bash scripts/monitoring.sh continuous 60

# Test alerti
bash scripts/monitoring.sh test-alerts
```

## 📱 Dashboard Bileşenleri

### Ana Sayfa Panelleri

1. **📊 Real-time P&L Dashboard**
   - Toplam P&L görünümü
   - Saatlik değişim
   - Yüzdelik performans

2. **📈 P&L Chart (Real-time)**
   - Zaman serisi grafik
   - Strateji bazında ayrım
   - Interactive zoom

3. **🎯 Portfolio Allocation**
   - Pasta chart görünümü
   - Varlık bazında dağılım
   - Dynamic updates

4. **🏆 Strategy Performance Comparison**
   - Bar chart karşılaştırma
   - 24 saat performansı
   - Success rate

5. **📊 Risk Metrics Overview**
   - VaR, Drawdown
   - Sharpe, Calmar ratio
   - Tablo formatında

6. **🔴 Market Regime Indicators**
   - Volatilite rejimi
   - Trend analizi
   - Likidite durumu

7. **💎 Correlation Heatmap**
   - Varlık korelasyonları
   - Heat map görselleştirme
   - Color-coded values

8. **📉 Drawdown Analysis**
   - Strateji bazında drawdown
   - Zaman serisi analiz
   - Maximum drawdown tracking

9. **🎯 Benchmark Comparison**
   - Portfolio vs Bitcoin
   - Portfolio vs Ethereum
   - Relative performance

10. **⚠️ Alert Status Board**
    - Aktif uyarı sayısı
    - Kritik uyarılar
    - Warning seviyesi

11. **⚡ Execution Performance Metrics**
    - Average slippage
    - Fill rate
    - Order latency

12. **🎮 Custom Trading Widgets**
    - Signal strength gauge
    - Position size distribution
    - Order latency histogram
    - Success rate pie chart

### Sistem Sağlık Panelleri

- **CPU Usage**: Container CPU utilization
- **Memory Usage**: RAM consumption
- **Database Connections**: PostgreSQL connections
- **Message Queue**: Kafka consumer lag
- **API Response Time**: HTTP endpoint performance

## 🔧 Kullanım Komutları

### Container Yönetimi

```bash
# Container'ları başlat
docker-compose up -d

# Container'ları durdur
docker-compose down

# Container'ları yeniden başlat
docker-compose restart

# Logs'ları takip et
docker-compose logs -f

# Belirli container logu
docker-compose logs -f grafana
docker-compose logs -f prometheus
```

### Dashboard Yönetimi

```bash
# Dashboard'u yükle
curl -X POST \
  -H "Content-Type: application/json" \
  -u admin:admin123 \
  -d @dashboards/bitwisers_trading_dashboard.json \
  http://localhost:3000/api/dashboards/db

# Dashboard listesini al
curl -u admin:admin123 http://localhost:3000/api/search?type=dash-db

# Dashboard'u sil
curl -X DELETE \
  -u admin:admin123 \
  http://localhost:3000/api/dashboards/db/bitwisers-trading-dashboard
```

### Metrik Yönetimi

```bash
# Metrikleri oluştur (demo)
bash scripts/generate_metrics.sh generate

# Sürekli metrik üretimi
bash scripts/generate_metrics.sh start

# Metrik üretimini durdur
bash scripts/generate_metrics.sh stop

# Prometheus metrics endpoint'ini test et
curl http://localhost:9090/metrics
```

### Monitoring & Alerting

```bash
# Tek seferlik monitoring
bash scripts/monitoring.sh monitor

# Sürekli monitoring (30 saniye aralıkla)
bash scripts/monitoring.sh continuous 30

# Test alerti gönder
bash scripts/monitoring.sh test-alerts

# Dashboard'u yenile
bash scripts/monitoring.sh refresh

# Sistem sağlığını kontrol et
bash scripts/monitoring.sh health
```

## 📊 Metrik Kategorileri

### Trading Metrikleri

```prometheus
# P&L Metrikleri
trade_pnl_total{strategy="dvk", symbol="BTC"} 4200
trade_pnl_percentage 2.35

# Portfolio Allocation
portfolio_allocation{asset="BTC", strategy="dvk"} 40000
portfolio_allocation{asset="ETH", strategy="genetic"} 25000

# Strateji Performansı
strategy_performance_24h{strategy="dvk"} 2.5
strategy_performance_24h{strategy="genetic"} 1.8
```

### Risk Metrikleri

```prometheus
# Risk Metrikleri
risk_metrics{risk_type="var_99"} 5000
risk_metrics{risk_type="max_drawdown"} 0.12
risk_metrics{risk_type="sharpe_ratio"} 1.8

# Drawdown Analizi
portfolio_drawdown{strategy="dvk", symbol="BTC"} 0.08
```

### Sistem Metrikleri

```prometheus
# Container Metrikleri
container_cpu_usage_seconds_total 0.25
container_memory_usage_bytes 1073741824

# Database Metrikleri
pg_stat_database_numbackends 15

# HTTP Metrikleri
http_request_duration_seconds{endpoint="/api/trades"} 0.085
```

## 🚨 Alert Sistemi

### Alert Seviyeleri

- **🔴 Critical**: Sistem çökmesi, yüksek kayıp
- **🟡 Warning**: Performans sorunları, dikkat gerektiren durumlar
- **🟢 Info**: Bilgilendirici bildirimler

### Alert Türleri

1. **P&L Alerts**: Yüksek kayıp, negative performance
2. **Risk Alerts**: Yüksek drawdown, VaR aşımı
3. **System Alerts**: CPU/Memory kullanımı, DB bağlantıları
4. **Execution Alerts**: Yüksek slippage, düşük fill rate
5. **Market Alerts**: Aşırı volatilite, düşük likidite

### Notification Kanalları

- **📧 Email**: SMTP üzerinden e-posta
- **💬 Slack**: Webhook entegrasyonu
- **🐦 Discord**: Webhook entegrasyonu
- **🔔 DingTalk**: Webhook entegrasyonu

## 🔧 Konfigürasyon

### Environment Variables

```bash
# Alert konfigürasyonu
export ALERT_EMAIL="admin@bitwisers.com"
export SLACK_WEBHOOK="https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK"
export DISCORD_WEBHOOK="https://discord.com/api/webhooks/YOUR/DISCORD/WEBHOOK"
export DINGTALK_WEBHOOK="YOUR_DINGTALK_WEBHOOK"

# Prometheus URL
export PROMETHEUS_URL="http://localhost:9090"

# Grafana URL
export GRAFANA_URL="http://localhost:3000"
```

### Alert Thresholds

```bash
# P&L Threshold
PNL_THRESHOLD=-5000

# Drawdown Threshold
DRAWDOWN_THRESHOLD=0.15

# System Thresholds
CPU_THRESHOLD=80
MEMORY_THRESHOLD=85
LATENCY_THRESHOLD=1000
SLIPPAGE_THRESHOLD=0.001
```

## 🐛 Sorun Giderme

### Container Sorunları

```bash
# Port çakışması kontrolü
netstat -tulpn | grep :3000
netstat -tulpn | grep :9090

# Container durumu
docker-compose ps

# Container logları
docker-compose logs prometheus
docker-compose logs grafana
```

### Metrik Sorunları

```bash
# Prometheus durumu
curl http://localhost:9090/-/healthy

# Metrik endpoint testi
curl http://localhost:9090/metrics

# Metrik jeneratör durumu
ps aux | grep generate_metrics
```

### Alert Sorunları

```bash
# Network bağlantısı testi
curl -v $SLACK_WEBHOOK
telnet smtp.gmail.com 587

# Monitoring betik logları
bash scripts/monitoring.sh monitor
```

## 📈 Performance Optimization

### Metrik Saklama

```bash
# Prometheus retention
prometheus \
  --storage.tsdb.retention.time=30d \
  --storage.tsdb.retention.size=10GB
```

### Query Optimization

```prometheus
# Efficient queries
rate(trade_pnl_total[5m])
sum by (strategy) (trader_pnl_total)
```

### Dashboard Refresh

```json
{
  "refresh": "5s",  // Real-time
  "time": {
    "from": "now-1h",
    "to": "now"
  }
}
```

## 📚 Dokümantasyon

Detaylı dokümantasyon için: [`docs/grafana_dashboard.md`](../docs/grafana_dashboard.md)

## 🤝 Katkıda Bulunma

1. Fork yapın
2. Feature branch oluşturun (`git checkout -b feature/amazing-feature`)
3. Değişikliklerinizi commit edin (`git commit -m 'Add amazing feature'`)
4. Branch'inizi push edin (`git push origin feature/amazing-feature`)
5. Pull Request oluşturun

## 📄 Lisans

Bu proje MIT lisansı altında lisanslanmıştır. Detaylar için `LICENSE` dosyasına bakınız.

## 🙏 Teşekkürler

- Grafana Labs (Dashboard platform)
- Prometheus (Metrics platform)
- Docker (Containerization)
- Bitcoin community (Inspiration)

## 📞 İletişim

- **Proje**: Bitwisers 2.0
- **Takım**: Trading Systems Team
- **Email**: admin@bitwisers.com
- **GitHub**: github.com/bitwisers/grafana-dashboard

---

**⚡ Bitwisers 2.0 Trading Dashboard - Profesyonel Trading İçin Tasarlanmış**