"""
Risk Bütçesi Yönetimi Utility Fonksiyonları

Bu modül risk bütçesi yönetimi sisteminde kullanılan 
yardımcı fonksiyonları ve araçları içerir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
import json
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

class RiskUtils:
    """
    Risk Yönetimi Utility Fonksiyonları
    
    Risk hesaplamaları ve dönüşümler için yardımcı fonksiyonlar.
    """
    
    @staticmethod
    def calculate_portfolio_volatility(weights: np.ndarray, cov_matrix: np.ndarray) -> float:
        """Portföy volatilitesi hesapla"""
        return np.sqrt(np.dot(weights, np.dot(cov_matrix, weights)))
    
    @staticmethod
    def calculate_information_ratio(portfolio_returns: pd.Series, benchmark_returns: pd.Series) -> float:
        """Information ratio hesapla"""
        excess_returns = portfolio_returns - benchmark_returns
        tracking_error = excess_returns.std() * np.sqrt(252)
        return excess_returns.mean() * 252 / tracking_error if tracking_error > 0 else 0
    
    @staticmethod
    def calculate_max_drawdown(returns: pd.Series) -> float:
        """Maksimum çekilme hesapla"""
        cumulative = (1 + returns).cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        return drawdown.min()
    
    @staticmethod
    def calculate_var_historical(returns: pd.Series, confidence_level: float = 0.95) -> float:
        """Tarihsel VaR hesapla"""
        return abs(np.percentile(returns, (1 - confidence_level) * 100))
    
    @staticmethod
    def calculate_cvar_historical(returns: pd.Series, confidence_level: float = 0.95) -> float:
        """Tarihsel CVaR hesapla"""
        var_threshold = np.percentile(returns, (1 - confidence_level) * 100)
        tail_returns = returns[returns <= var_threshold]
        return abs(tail_returns.mean()) if len(tail_returns) > 0 else abs(var_threshold)
    
    @staticmethod
    def normalize_weights(weights: np.ndarray, max_weight: float = 0.4) -> np.ndarray:
        """Ağırlıkları normalize et"""
        # Negatif ağırlıkları sıfırla
        weights = np.maximum(weights, 0)
        
        # Maksimum ağırlık sınırı
        weights = np.minimum(weights, max_weight)
        
        # Normalize et
        if weights.sum() > 0:
            weights = weights / weights.sum()
        
        return weights
    
    @staticmethod
    def calculate_risk_budget(weights: np.ndarray, target_risk: float, cov_matrix: np.ndarray) -> np.ndarray:
        """Risk bütçesini hesapla"""
        portfolio_vol = RiskUtils.calculate_portfolio_volatility(weights, cov_matrix)
        
        if portfolio_vol == 0:
            return np.zeros_like(weights)
        
        # Risk marjinal katkıları
        marginal_risks = np.dot(cov_matrix, weights) / portfolio_vol
        
        # Risk bütçesi
        risk_budget = marginal_risks / marginal_risks.sum() * target_risk
        
        return risk_budget
    
    @staticmethod
    def format_percentage(value: float, decimals: int = 2) -> str:
        """Yüzde formatında göster"""
        return f"{value * 100:.{decimals}f}%"
    
    @staticmethod
    def format_currency(value: float, currency: str = "USD", decimals: int = 2) -> str:
        """Para birimi formatında göster"""
        symbols = {"USD": "$", "EUR": "€", "GBP": "£"}
        symbol = symbols.get(currency, currency)
        return f"{symbol}{value:,.{decimals}f}"
    
    @staticmethod
    def create_risk_matrix(assets: List[str], method: str = 'historical') -> pd.DataFrame:
        """Risk matrisi oluştur (dummy)"""
        np.random.seed(42)
        n_assets = len(assets)
        
        # Dummy volatilities
        volatilities = np.random.uniform(0.1, 0.4, n_assets)
        
        # Dummy correlation matrix
        correlation = np.random.uniform(-0.3, 0.8, (n_assets, n_assets))
        correlation = (correlation + correlation.T) / 2  # Symmetrize
        np.fill_diagonal(correlation, 1.0)
        
        # Covariance matrix
        cov_matrix = np.outer(volatilities, volatilities) * correlation
        
        return pd.DataFrame(cov_matrix, index=assets, columns=assets)
    
    @staticmethod
    def validate_portfolio(weights: np.ndarray, constraints: Dict = None) -> Dict:
        """Portföy validasyonu"""
        constraints = constraints or {}
        
        results = {
            'valid': True,
            'errors': [],
            'warnings': []
        }
        
        # Toplam ağırlık kontrolü
        if abs(weights.sum() - 1.0) > 1e-6:
            results['errors'].append("Ağırlıklar toplamı 1'e eşit değil")
            results['valid'] = False
        
        # Negatif ağırlık kontrolü
        negative_weights = weights[weights < 0]
        if len(negative_weights) > 0:
            results['errors'].append(f"{len(negative_weights)} negatif ağırlık var")
            results['valid'] = False
        
        # Maksimum ağırlık kontrolü
        max_weight = constraints.get('max_weight', 0.4)
        if (weights > max_weight).any():
            results['warnings'].append(f"Bazı ağırlıklar {max_weight}'den büyük")
        
        # Konsantrasyon kontrolü
        hhi = (weights ** 2).sum()
        if hhi > 0.25:
            results['warnings'].append(f"Yüksek konsentrasyon (HHI: {hhi:.3f})")
        
        return results

class DataValidator:
    """Veri validasyon araçları"""
    
    @staticmethod
    def validate_returns_data(returns: pd.Series, check_missing: bool = True, check_outliers: bool = True) -> Dict:
        """Getiri verilerini doğrula"""
        
        results = {
            'valid': True,
            'issues': [],
            'statistics': {}
        }
        
        # Temel istatistikler
        results['statistics'] = {
            'count': len(returns),
            'missing_count': returns.isnull().sum(),
            'mean': returns.mean(),
            'std': returns.std(),
            'min': returns.min(),
            'max': returns.max(),
            'skewness': stats.skew(returns.dropna()),
            'kurtosis': stats.kurtosis(returns.dropna())
        }
        
        # Eksik veri kontrolü
        if check_missing and results['statistics']['missing_count'] > 0:
            missing_pct = results['statistics']['missing_count'] / len(returns) * 100
            if missing_pct > 5:
                results['issues'].append(f"Yüksek eksik veri oranı: {missing_pct:.1f}%")
                results['valid'] = False
            else:
                results['issues'].append(f"Düşük eksik veri oranı: {missing_pct:.1f}%")
        
        # Outlier kontrolü
        if check_outliers:
            q1 = returns.quantile(0.25)
            q3 = returns.quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            
            outliers = returns[(returns < lower_bound) | (returns > upper_bound)]
            outlier_pct = len(outliers) / len(returns) * 100
            
            if outlier_pct > 5:
                results['issues'].append(f"Yüksek outlier oranı: {outlier_pct:.1f}%")
                results['valid'] = False
        
        # Normallik testi
        try:
            jb_stat, jb_pvalue = stats.jarque_bera(returns.dropna())
            if jb_pvalue < 0.05:
                results['issues'].append("Veriler normal dağılıma uymuyor (Jarque-Bera test)")
        except Exception:
            pass
        
        return results
    
    @staticmethod
    def validate_portfolio_data(portfolio_data: Dict) -> Dict:
        """Portföy verilerini doğrula"""
        
        results = {
            'valid': True,
            'issues': []
        }
        
        # Kompozisyon kontrolü
        composition = portfolio_data.get('composition', {})
        if not composition:
            results['issues'].append("Portföy kompozisyonu boş")
            results['valid'] = False
            return results
        
        # Toplam değer kontrolü
        total_value = sum(composition.values())
        if total_value <= 0:
            results['issues'].append("Toplam portföy değeri sıfır veya negatif")
            results['valid'] = False
        
        # Negatif pozisyonlar
        negative_positions = [k for k, v in composition.items() if v < 0]
        if negative_positions:
            results['issues'].append(f"Negatif pozisyonlar: {negative_positions}")
        
        # Aşırı konsantrasyon
        max_position = max(composition.values()) / total_value if total_value > 0 else 0
        if max_position > 0.4:
            results['issues'].append(f"Yüksek konsantrasyon: {max_position:.1%}")
        
        return results

class ConfigManager:
    """Konfigürasyon yönetimi"""
    
    def __init__(self, config_file: Optional[str] = None):
        self.config_file = config_file
        self.config = {}
        if config_file:
            self.load_config()
    
    def load_config(self) -> Dict:
        """Konfigürasyon dosyasını yükle"""
        try:
            if self.config_file and os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    self.config = json.load(f)
            else:
                # Varsayılan konfigürasyon
                self.config = self._get_default_config()
            return self.config
        except Exception as e:
            logging.error(f"Konfigürasyon yükleme hatası: {str(e)}")
            return self._get_default_config()
    
    def save_config(self) -> bool:
        """Konfigürasyon dosyasını kaydet"""
        try:
            if self.config_file:
                with open(self.config_file, 'w') as f:
                    json.dump(self.config, f, indent=2, default=str)
                return True
            return False
        except Exception as e:
            logging.error(f"Konfigürasyon kaydetme hatası: {str(e)}")
            return False
    
    def _get_default_config(self) -> Dict:
        """Varsayılan konfigürasyon"""
        return {
            'risk_limits': {
                'var_limit': 0.15,
                'cvar_limit': 0.20,
                'max_position_size': 0.05,
                'correlation_threshold': 0.8
            },
            'monitoring': {
                'check_interval': 60,
                'alert_cooldown': 300,
                'notification_channels': ['console', 'file']
            },
            'performance': {
                'benchmark': 'MSCI_World',
                'risk_free_rate': 0.02
            }
        }

# Utility fonksiyonlarını export et
__all__ = [
    'RiskUtils',
    'DataValidator', 
    'ConfigManager'
]