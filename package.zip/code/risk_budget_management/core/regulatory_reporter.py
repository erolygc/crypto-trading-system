"""
Düzenleyici Risk Raporlama Sistemi

Çeşitli düzenleyici gereksinimler için risk raporları oluşturur
ve uyumluluk kontrolleri yapar.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from dataclasses import dataclass
from enum import Enum
import json
import xml.etree.ElementTree as ET
from xml.dom import minidom
import warnings
warnings.filterwarnings('ignore')

@dataclass
class RegulatoryRequirement:
    """Düzenleyici gereksinim"""
    requirement_id: str
    name: str
    jurisdiction: str  # 'US', 'EU', 'UK', 'Global'
    regulation_type: str  # 'Basel_III', 'MiFID_II', 'Dodd_Frank', etc.
    report_frequency: str  # 'daily', 'weekly', 'monthly', 'quarterly', 'annual'
    required_fields: List[str]
    format_type: str  # 'XML', 'JSON', 'CSV', 'PDF'
    compliance_deadline: Optional[str]

class ReportFormat(Enum):
    """Rapor format türleri"""
    XML = "xml"
    JSON = "json"
    CSV = "csv"
    PDF = "pdf"
    EXCEL = "xlsx"

class Jurisdiction(Enum):
    """Yargı yetkisi"""
    US = "US"
    EU = "EU"
    UK = "UK"
    GLOBAL = "Global"
    APAC = "APAC"

class RegulatoryReporter:
    """
    Düzenleyici Risk Raporlama Sistemi
    
    Çeşitli düzenleyici gereksinimler için uyumlu risk raporları 
    oluşturur ve yönetimi sağlar.
    """
    
    def __init__(self, config):
        """
        Düzenleyici Raporlama sistemini başlat
        
        Args:
            config: RiskBudgetConfig objesi
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Düzenleyici gereksinimler
        self.regulatory_requirements = {}
        self.report_history = []
        self.compliance_status = {}
        
        # Rapor parametreleri
        self.report_generation_time = {}
        self.compliance_deadlines = {}
        
        # Standard formatlar
        self.supported_formats = [ReportFormat.XML, ReportFormat.JSON, ReportFormat.CSV]
        
        # Düzenleyici metrikler
        self.regulatory_metrics = {
            'tier_1_capital': 0,
            'risk_weighted_assets': 0,
            'leverage_ratio': 0,
            'liquidity_coverage_ratio': 0,
            'net_stable_funding_ratio': 0
        }
        
        self._load_regulatory_requirements()
        
        self.logger.info("Düzenleyici Raporlama sistemi başlatıldı")
    
    def _load_regulatory_requirements(self):
        """Düzenleyici gereksinimleri yükle"""
        
        # Basel III gereksinimleri
        basel_requirements = [
            RegulatoryRequirement(
                requirement_id="BASEL_III_CAPITAL_RATIOS",
                name="Basel III Capital Ratios",
                jurisdiction="GLOBAL",
                regulation_type="Basel_III",
                report_frequency="quarterly",
                required_fields=[
                    'tier_1_capital_ratio', 'total_capital_ratio', 'leverage_ratio',
                    'risk_weighted_assets', 'capital_buffers', 'counterparty_credit_risk'
                ],
                format_type="XML",
                compliance_deadline="2025-12-31"
            ),
            RegulatoryRequirement(
                requirement_id="BASEL_III_LIQUIDITY_RATIOS",
                name="Basel III Liquidity Ratios",
                jurisdiction="GLOBAL", 
                regulation_type="Basel_III",
                report_frequency="monthly",
                required_fields=[
                    'liquidity_coverage_ratio', 'net_stable_funding_ratio',
                    'high_quality_liquid_assets', 'cash_outflows'
                ],
                format_type="XML",
                compliance_deadline="2025-12-31"
            )
        ]
        
        # MiFID II gereksinimleri
        mifid_requirements = [
            RegulatoryRequirement(
                requirement_id="MIFID_II_TRADE_REPORTING",
                name="MiFID II Trade Reporting",
                jurisdiction="EU",
                regulation_type="MiFID_II",
                report_frequency="daily",
                required_fields=[
                    'trade_execution_details', 'best_execution', 'transaction_costs',
                    'investment_recommendations', 'research_reports'
                ],
                format_type="XML",
                compliance_deadline="2025-06-30"
            ),
            RegulatoryRequirement(
                requirement_id="MIFID_II_RISK_DISCLOSURE",
                name="MiFID II Risk Disclosure",
                jurisdiction="EU",
                regulation_type="MiFID_II", 
                report_frequency="quarterly",
                required_fields=[
                    'investment_risks', 'product_risks', 'market_risks',
                    'operational_risks', 'compliance_risks'
                ],
                format_type="PDF",
                compliance_deadline="2025-06-30"
            )
        ]
        
        # Dodd-Frank gereksinimleri
        dodd_frank_requirements = [
            RegulatoryRequirement(
                requirement_id="DODD_FRANK_SWAP_REPORTING",
                name="Dodd-Frank Swap Reporting",
                jurisdiction="US",
                regulation_type="Dodd_Frank",
                report_frequency="daily",
                required_fields=[
                    'swap_transactions', 'clearing_data', 'margin_data',
                    'counterparty_data', 'risk_management_procedures'
                ],
                format_type="XML",
                compliance_deadline="2025-03-31"
            ),
            RegulatoryRequirement(
                requirement_id="DODD_FRANK_VA_REPORTING",
                name="Dodd-Frank VaR Reporting",
                jurisdiction="US",
                regulation_type="Dodd_Frank",
                report_frequency="monthly",
                required_fields=[
                    'var_calculations', 'backtesting_results', 'stress_test_results',
                    'model_validation', 'risk_parameter_updates'
                ],
                format_type="CSV",
                compliance_deadline="2025-03-31"
            )
        ]
        
        # FRTB (Fundamental Review of Trading Book) gereksinimleri
        frtb_requirements = [
            RegulatoryRequirement(
                requirement_id="FRTB_STANDARDIZED_APPROACH",
                name="FRTB Standardized Approach",
                jurisdiction="GLOBAL",
                regulation_type="FRTB",
                report_frequency="quarterly",
                required_fields=[
                    'sensitivity_based_approach', 'default_risk_charge',
                    'residual_risk_add_on', 'comprehensive_risk_measure'
                ],
                format_type="XML",
                compliance_deadline="2025-12-31"
            )
        ]
        
        # Tüm gereksinimleri birleştir
        all_requirements = (basel_requirements + mifid_requirements + 
                          dodd_frank_requirements + frtb_requirements)
        
        for requirement in all_requirements:
            self.regulatory_requirements[requirement.requirement_id] = requirement
        
        self.logger.info(f"{len(all_requirements)} düzenleyici gereksinim yüklendi")
    
    def generate_report(self, 
                       report_type: str = "comprehensive",
                       portfolio_data: Dict = None,
                       risk_metrics: Dict = None) -> Dict:
        """
        Düzenleyici risk raporu oluştur
        
        Args:
            report_type: Rapor türü ('comprehensive', 'basel_iii', 'mifid_ii', etc.)
            portfolio_data: Portföy verileri (opsiyonel)
            risk_metrics: Risk metrikleri (opsiyonel)
            
        Returns:
            Dict: Rapor sonuçları
        """
        
        try:
            self.logger.info(f"Düzenleyici rapor oluşturuluyor: {report_type}")
            
            start_time = datetime.now()
            
            # Rapor tipine göre gereksinimleri seç
            requirements = self._get_requirements_for_report_type(report_type)
            
            if not requirements:
                return {'error': f'Geçersiz rapor tipi: {report_type}'}
            
            # Rapor içeriğini oluştur
            report_content = self._build_report_content(requirements, portfolio_data, risk_metrics)
            
            # Format dönüşümü
            formatted_reports = {}
            for requirement in requirements:
                formatted_report = self._format_report(requirement, report_content)
                formatted_reports[requirement.requirement_id] = formatted_report
            
            # Uyumluluk kontrolü
            compliance_check = self._check_compliance(requirements, report_content)
            
            generation_time = (datetime.now() - start_time).total_seconds()
            
            report_result = {
                'report_id': f"{report_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                'report_type': report_type,
                'generation_time': generation_time,
                'timestamp': datetime.now().isoformat(),
                'requirements_covered': len(requirements),
                'report_content': report_content,
                'formatted_reports': formatted_reports,
                'compliance_status': compliance_check,
                'recommendations': self._generate_compliance_recommendations(compliance_check)
            }
            
            # Rapor geçmişine ekle
            self.report_history.append(report_result)
            
            self.logger.info(f"Düzenleyici rapor oluşturuldu: {len(requirements)} gereksinim kapsandı")
            return report_result
            
        except Exception as e:
            self.logger.error(f"Rapor oluşturma hatası: {str(e)}")
            return {'error': str(e)}
    
    def _get_requirements_for_report_type(self, report_type: str) -> List[RegulatoryRequirement]:
        """Rapor tipi için gereksinimleri al"""
        
        type_mapping = {
            'comprehensive': list(self.regulatory_requirements.values()),
            'basel_iii': [req for req in self.regulatory_requirements.values() if 'Basel' in req.regulation_type],
            'mifid_ii': [req for req in self.regulatory_requirements.values() if 'MiFID' in req.regulation_type],
            'dodd_frank': [req for req in self.regulatory_requirements.values() if 'Dodd' in req.regulation_type],
            'frtb': [req for req in self.regulatory_requirements.values() if 'FRTB' in req.regulation_type],
            'liquidity': [req for req in self.regulatory_requirements.values() if 'Liquidity' in req.name],
            'capital': [req for req in self.regulatory_requirements.values() if 'Capital' in req.name]
        }
        
        return type_mapping.get(report_type.lower(), [])
    
    def _build_report_content(self, 
                            requirements: List[RegulatoryRequirement],
                            portfolio_data: Dict = None,
                            risk_metrics: Dict = None) -> Dict:
        """Rapor içeriğini oluştur"""
        
        content = {
            'report_metadata': {
                'generation_date': datetime.now().isoformat(),
                'reporting_period': self._get_current_reporting_period(),
                'jurisdiction': 'GLOBAL',
                'currency': 'USD',
                'decimal_places': 4
            },
            'executive_summary': self._create_executive_summary(portfolio_data, risk_metrics),
            'risk_metrics': self._compile_risk_metrics(portfolio_data, risk_metrics),
            'regulatory_data': {},
            'compliance_indicators': self._calculate_compliance_indicators(portfolio_data, risk_metrics)
        }
        
        # Her gereksinim için özel veri ekle
        for requirement in requirements:
            content['regulatory_data'][requirement.requirement_id] = self._extract_regulatory_data(
                requirement, portfolio_data, risk_metrics
            )
        
        return content
    
    def _create_executive_summary(self, portfolio_data: Dict, risk_metrics: Dict) -> Dict:
        """Yönetici özeti oluştur"""
        
        summary = {
            'overall_risk_level': 'Medium',
            'key_risk_indicators': [],
            'compliance_status': 'Compliant',
            'recommendations': [],
            'critical_issues': []
        }
        
        try:
            # Risk seviyesi değerlendirmesi
            if risk_metrics:
                portfolio_var = risk_metrics.get('portfolio_var', 0)
                portfolio_cvar = risk_metrics.get('portfolio_cvar', 0)
                
                if portfolio_var > 0.15:
                    summary['overall_risk_level'] = 'High'
                    summary['critical_issues'].append('Yüksek VaR seviyesi')
                elif portfolio_var < 0.05:
                    summary['overall_risk_level'] = 'Low'
                
                # Anahtar risk göstergeleri
                if portfolio_cvar > 0.20:
                    summary['key_risk_indicators'].append('Tail risk yüksek')
                
                if risk_metrics.get('max_drawdown', 0) < -0.15:
                    summary['key_risk_indicators'].append('Yüksek çekilme riski')
            
            # Uyumluluk durumu
            compliance_score = self._calculate_overall_compliance_score()
            summary['compliance_status'] = 'Compliant' if compliance_score > 0.9 else 'Partial Compliance'
            
            # Öneriler
            if len(summary['critical_issues']) > 0:
                summary['recommendations'].append('Kritik risk konularını acilen ele alın')
            if compliance_score < 0.95:
                summary['recommendations'].append('Uyumluluk eksikliklerini giderin')
            
        except Exception as e:
            self.logger.error(f"Yönetici özeti oluşturma hatası: {str(e)}")
        
        return summary
    
    def _compile_risk_metrics(self, portfolio_data: Dict, risk_metrics: Dict) -> Dict:
        """Risk metriklerini derle"""
        
        compiled_metrics = {
            'market_risk': {},
            'credit_risk': {},
            'operational_risk': {},
            'liquidity_risk': {},
            'concentration_risk': {}
        }
        
        try:
            if risk_metrics:
                compiled_metrics['market_risk'] = {
                    'portfolio_var_95': risk_metrics.get('portfolio_var', 0),
                    'portfolio_var_99': risk_metrics.get('portfolio_var_99', 0),
                    'portfolio_cvar_95': risk_metrics.get('portfolio_cvar', 0),
                    'portfolio_cvar_99': risk_metrics.get('portfolio_cvar_99', 0),
                    'portfolio_volatility': risk_metrics.get('portfolio_volatility', 0),
                    'beta': risk_metrics.get('beta', 1.0),
                    'tracking_error': risk_metrics.get('tracking_error', 0)
                }
                
                compiled_metrics['operational_risk'] = {
                    'max_drawdown': risk_metrics.get('max_drawdown', 0),
                    'calmar_ratio': risk_metrics.get('calmar_ratio', 0),
                    'sharpe_ratio': risk_metrics.get('sharpe_ratio', 0),
                    'sortino_ratio': risk_metrics.get('sortino_ratio', 0)
                }
            
            # Varsayılan değerler (gerçek uygulamada hesaplanacak)
            compiled_metrics['credit_risk'] = {
                'counterparty_exposure': portfolio_data.get('total_exposure', 0) * 0.1,
                'credit_spread_risk': 0.05,
                'default_probability': 0.02
            }
            
            compiled_metrics['liquidity_risk'] = {
                'liquidity_coverage_ratio': 1.2,
                'net_stable_funding_ratio': 1.1,
                'market_impact_cost': 0.001
            }
            
            compiled_metrics['concentration_risk'] = {
                'single_name_limit': 0.05,
                'sector_concentration': 0.15,
                'geographic_concentration': 0.25
            }
            
        except Exception as e:
            self.logger.error(f"Risk metrikleri derleme hatası: {str(e)}")
        
        return compiled_metrics
    
    def _extract_regulatory_data(self, 
                               requirement: RegulatoryRequirement,
                               portfolio_data: Dict,
                               risk_metrics: Dict) -> Dict:
        """Düzenleyici veri çıkarma"""
        
        regulatory_data = {}
        
        try:
            # Gereksinim alanlarına göre veri çıkar
            for field in requirement.required_fields:
                if risk_metrics and field in risk_metrics:
                    regulatory_data[field] = risk_metrics[field]
                elif portfolio_data and field in portfolio_data:
                    regulatory_data[field] = portfolio_data[field]
                else:
                    # Varsayılan değerler
                    regulatory_data[field] = self._get_default_field_value(field)
            
            # Gereksinim özel alanları
            if 'Basel' in requirement.regulation_type:
                regulatory_data.update(self._calculate_basel_metrics(portfolio_data, risk_metrics))
            elif 'MiFID' in requirement.regulation_type:
                regulatory_data.update(self._calculate_mifid_metrics(portfolio_data, risk_metrics))
            elif 'Dodd' in requirement.regulation_type:
                regulatory_data.update(self._calculate_dodd_frank_metrics(portfolio_data, risk_metrics))
            
        except Exception as e:
            self.logger.error(f"Düzenleyici veri çıkarma hatası: {str(e)}")
        
        return regulatory_data
    
    def _calculate_basel_metrics(self, portfolio_data: Dict, risk_metrics: Dict) -> Dict:
        """Basel metrikleri hesapla"""
        
        total_capital = portfolio_data.get('total_capital', 1000000)
        risk_weighted_assets = portfolio_data.get('risk_weighted_assets', 800000)
        
        return {
            'tier_1_capital_ratio': 0.12,  # %12
            'total_capital_ratio': 0.15,   # %15
            'leverage_ratio': 0.05,        # %5
            'liquidity_coverage_ratio': 1.2,  # 120%
            'net_stable_funding_ratio': 1.1   # 110%
        }
    
    def _calculate_mifid_metrics(self, portfolio_data: Dict, risk_metrics: Dict) -> Dict:
        """MiFID II metrikleri hesapla"""
        
        return {
            'transaction_costs': 0.001,    # %0.1
            'best_execution_score': 0.95,  # %95
            'research_cost_ratio': 0.002,  # %0.2
            'product_governance_score': 0.90  # %90
        }
    
    def _calculate_dodd_frank_metrics(self, portfolio_data: Dict, risk_metrics: Dict) -> Dict:
        """Dodd-Frank metrikleri hesapla"""
        
        return {
            'swap_notional_amount': portfolio_data.get('swap_exposure', 0),
            'clearing_requirement_met': True,
            'margin_requirement_compliance': 0.98,
            'capital_requirement': portfolio_data.get('required_capital', 500000)
        }
    
    def _get_default_field_value(self, field_name: str) -> Union[float, str, bool]:
        """Varsayılan alan değeri"""
        
        defaults = {
            'tier_1_capital_ratio': 0.12,
            'total_capital_ratio': 0.15,
            'leverage_ratio': 0.05,
            'liquidity_coverage_ratio': 1.2,
            'var_95': 0.10,
            'var_99': 0.15,
            'trading_volume': 1000000,
            'counterparty_count': 50,
            'risk_weighted_assets': 800000,
            'compliance_status': 'Compliant'
        }
        
        return defaults.get(field_name, 0.0)
    
    def _format_report(self, requirement: RegulatoryRequirement, content: Dict) -> Dict:
        """Raporu formatla"""
        
        try:
            report_data = content.get('regulatory_data', {}).get(requirement.requirement_id, {})
            
            if requirement.format_type == "XML":
                formatted_report = self._format_as_xml(requirement, report_data)
            elif requirement.format_type == "JSON":
                formatted_report = self._format_as_json(requirement, report_data)
            elif requirement.format_type == "CSV":
                formatted_report = self._format_as_csv(requirement, report_data)
            elif requirement.format_type == "PDF":
                formatted_report = self._format_as_pdf(requirement, report_data)
            else:
                formatted_report = self._format_as_json(requirement, report_data)
            
            return {
                'format': requirement.format_type,
                'content': formatted_report,
                'size_kb': len(str(formatted_report)) / 1024,
                'compliance_ready': True
            }
            
        except Exception as e:
            self.logger.error(f"Rapor formatlama hatası: {str(e)}")
            return {'error': str(e)}
    
    def _format_as_xml(self, requirement: RegulatoryRequirement, data: Dict) -> str:
        """XML formatında rapor oluştur"""
        
        root = ET.Element("RegulatoryReport")
        root.set("requirement_id", requirement.requirement_id)
        root.set("generation_date", datetime.now().isoformat())
        
        # Meta bilgiler
        metadata = ET.SubElement(root, "Metadata")
        ET.SubElement(metadata, "RequirementName").text = requirement.name
        ET.SubElement(metadata, "Jurisdiction").text = requirement.jurisdiction
        ET.SubElement(metadata, "RegulationType").text = requirement.regulation_type
        
        # Veri alanları
        data_element = ET.SubElement(root, "Data")
        for field, value in data.items():
            field_element = ET.SubElement(data_element, field.replace(" ", "_"))
            field_element.text = str(value)
        
        # XML'i düzenle
        xml_string = ET.tostring(root, encoding='unicode')
        return minidom.parseString(xml_string).toprettyxml()
    
    def _format_as_json(self, requirement: RegulatoryRequirement, data: Dict) -> str:
        """JSON formatında rapor oluştur"""
        
        json_data = {
            "requirement_id": requirement.requirement_id,
            "requirement_name": requirement.name,
            "generation_date": datetime.now().isoformat(),
            "jurisdiction": requirement.jurisdiction,
            "regulation_type": requirement.regulation_type,
            "data": data
        }
        
        return json.dumps(json_data, indent=2, default=str)
    
    def _format_as_csv(self, requirement: RegulatoryRequirement, data: Dict) -> str:
        """CSV formatında rapor oluştur"""
        
        import io
        
        output = io.StringIO()
        
        # Header
        output.write("Field,Value,Requirement,GenerationDate\\n")
        
        # Data rows
        for field, value in data.items():
            output.write(f'"{field}","{value}","{requirement.requirement_id}","{datetime.now().isoformat()}"\\n')
        
        return output.getvalue()
    
    def _format_as_pdf(self, requirement: RegulatoryRequirement, data: Dict) -> str:
        """PDF formatında rapor oluştur (basit metin)"""
        
        # Gerçek uygulamada PDF kütüphanesi kullanılır
        pdf_content = f"""
DÜZENLEYICI RAPOR
================

Gereksinim ID: {requirement.requirement_id}
Gereksinim Adı: {requirement.name}
Yargı Yetkisi: {requirement.jurisdiction}
Düzenleme Türü: {requirement.regulation_type}
Oluşturma Tarihi: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

RAPOR İÇERİĞİ:
-------------
"""
        
        for field, value in data.items():
            pdf_content += f"{field}: {value}\\n"
        
        return pdf_content
    
    def _check_compliance(self, requirements: List[RegulatoryRequirement], content: Dict) -> Dict:
        """Uyumluluk kontrolü"""
        
        compliance_status = {
            'overall_compliance_score': 0.0,
            'requirements_met': 0,
            'total_requirements': len(requirements),
            'critical_issues': [],
            'recommendations': []
        }
        
        try:
            met_requirements = 0
            
            for requirement in requirements:
                # Her gereksinim için uyumluluk kontrolü
                requirement_data = content.get('regulatory_data', {}).get(requirement.requirement_id, {})
                
                missing_fields = []
                for field in requirement.required_fields:
                    if field not in requirement_data or requirement_data[field] is None:
                        missing_fields.append(field)
                
                if not missing_fields:
                    met_requirements += 1
                    compliance_status[f'requirement_{requirement.requirement_id}'] = 'Compliant'
                else:
                    compliance_status[f'requirement_{requirement.requirement_id}'] = f'Missing: {missing_fields}'
                    compliance_status['critical_issues'].append(
                        f"{requirement.requirement_id}: Missing fields {missing_fields}"
                    )
            
            # Uyumluluk skoru
            compliance_status['overall_compliance_score'] = met_requirements / len(requirements)
            compliance_status['requirements_met'] = met_requirements
            
            # Öneriler
            if compliance_status['overall_compliance_score'] < 0.8:
                compliance_status['recommendations'].append('Uyumluluk eksikliklerini acilen giderin')
            elif compliance_status['overall_compliance_score'] < 0.95:
                compliance_status['recommendations'].append('Uyumluluk iyileştirmeleri yapın')
            
        except Exception as e:
            self.logger.error(f"Uyumluluk kontrol hatası: {str(e)}")
            compliance_status['error'] = str(e)
        
        return compliance_status
    
    def _calculate_compliance_indicators(self, portfolio_data: Dict, risk_metrics: Dict) -> Dict:
        """Uyumluluk göstergelerini hesapla"""
        
        indicators = {
            'basel_compliance': {
                'tier_1_ratio_ok': True,
                'leverage_ratio_ok': True,
                'liquidity_ratio_ok': True
            },
            'mifid_compliance': {
                'best_execution_ok': True,
                'risk_disclosure_ok': True,
                'transaction_reporting_ok': True
            },
            'dodd_frank_compliance': {
                'swap_reporting_ok': True,
                'margin_requirements_ok': True,
                'capital_requirements_ok': True
            }
        }
        
        # Basel uyumluluğu
        if risk_metrics:
            if risk_metrics.get('portfolio_var', 0) > 0.20:
                indicators['basel_compliance']['tier_1_ratio_ok'] = False
        
        return indicators
    
    def _generate_compliance_recommendations(self, compliance_check: Dict) -> List[str]:
        """Uyumluluk önerileri oluştur"""
        
        recommendations = []
        
        compliance_score = compliance_check.get('overall_compliance_score', 0)
        
        if compliance_score < 0.7:
            recommendations.append("KRİTİK: Uyumluluk eksiklikleri acilen giderilmeli")
        elif compliance_score < 0.9:
            recommendations.append("UYARI: Uyumluluk iyileştirmeleri gerekli")
        
        # Kritik sorunlar
        critical_issues = compliance_check.get('critical_issues', [])
        if critical_issues:
            recommendations.append(f"Öncelikli konular: {len(critical_issues)} kritik sorun tespit edildi")
        
        return recommendations
    
    def _get_current_reporting_period(self) -> Dict:
        """Geçerli raporlama dönemi"""
        
        today = datetime.now()
        
        return {
            'quarter': f"Q{((today.month - 1) // 3) + 1} {today.year}",
            'month': today.strftime('%Y-%m'),
            'year': str(today.year),
            'period_end': today.strftime('%Y-%m-%d')
        }
    
    def _calculate_overall_compliance_score(self) -> float:
        """Genel uyumluluk skoru"""
        
        # Basit uyumluluk skoru hesaplaması
        # Gerçek uygulamada daha karmaşık hesaplamalar
        
        if not self.report_history:
            return 0.85  # Varsayılan skor
        
        # Son 10 raporun ortalaması
        recent_reports = self.report_history[-10:]
        compliance_scores = []
        
        for report in recent_reports:
            compliance = report.get('compliance_status', {})
            score = compliance.get('overall_compliance_score', 0.8)
            compliance_scores.append(score)
        
        return np.mean(compliance_scores) if compliance_scores else 0.85
    
    def get_compliance_dashboard(self) -> Dict:
        """Uyumluluk dashboard verilerini al"""
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_requirements': len(self.regulatory_requirements),
            'active_requirements': len([r for r in self.regulatory_requirements.values() if r.compliance_deadline]),
            'reports_generated': len(self.report_history),
            'overall_compliance_score': self._calculate_overall_compliance_score(),
            'upcoming_deadlines': self._get_upcoming_deadlines(),
            'recent_reports': self.report_history[-5:] if self.report_history else [],
            'compliance_trends': self._calculate_compliance_trends()
        }
    
    def _get_upcoming_deadlines(self) -> List[Dict]:
        """Yaklaşan son tarihleri al"""
        
        upcoming = []
        today = datetime.now()
        
        for req_id, requirement in self.regulatory_requirements.items():
            if requirement.compliance_deadline:
                deadline = datetime.strptime(requirement.compliance_deadline, '%Y-%m-%d')
                days_until = (deadline - today).days
                
                if days_until <= 90:  # 90 gün içinde
                    upcoming.append({
                        'requirement_id': req_id,
                        'requirement_name': requirement.name,
                        'deadline': requirement.compliance_deadline,
                        'days_remaining': days_until,
                        'priority': 'High' if days_until <= 30 else 'Medium'
                    })
        
        return sorted(upcoming, key=lambda x: x['days_remaining'])
    
    def _calculate_compliance_trends(self) -> Dict:
        """Uyumluluk trendlerini hesapla"""
        
        if len(self.report_history) < 3:
            return {'trend': 'Insufficient data'}
        
        # Son 3 raporun uyumluluk skorları
        recent_scores = []
        for report in self.report_history[-3:]:
            compliance = report.get('compliance_status', {})
            score = compliance.get('overall_compliance_score', 0.8)
            recent_scores.append(score)
        
        if len(recent_scores) >= 2:
            if recent_scores[-1] > recent_scores[-2]:
                trend = 'Improving'
            elif recent_scores[-1] < recent_scores[-2]:
                trend = 'Declining'
            else:
                trend = 'Stable'
        else:
            trend = 'Unknown'
        
        return {
            'trend': trend,
            'recent_scores': recent_scores,
            'average_score': np.mean(recent_scores) if recent_scores else 0
        }