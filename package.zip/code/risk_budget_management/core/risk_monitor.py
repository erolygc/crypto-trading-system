"""
Gerçek Zamanlı Risk İzleme ve Uyarı Sistemi

Portföy risk metriklerini sürekli izler ve limit aşımlarında 
anında uyarılar gönderir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union, Callable
from datetime import datetime, timedelta
import logging
import threading
import time
from dataclasses import dataclass
from enum import Enum
import json
import queue
import smtplib
from email.mime.text import MimeText
from email.mime.multipart import MimeMultipart

@dataclass
class MonitoringRule:
    """Risk izleme kuralı"""
    rule_id: str
    metric_name: str
    threshold_value: float
    threshold_type: str  # 'greater_than', 'less_than', 'equal_to'
    severity: str  # 'low', 'medium', 'high', 'critical'
    description: str
    enabled: bool = True

@dataclass
class AlertEvent:
    """Uyarı olayı"""
    event_id: str
    rule_id: str
    timestamp: datetime
    metric_value: float
    threshold_value: float
    severity: str
    message: str
    action_required: str
    acknowledged: bool = False
    resolved: bool = False

class AlertSeverity(Enum):
    """Uyarı seviyeleri"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class RiskMonitor:
    """
    Gerçek Zamanlı Risk İzleme Sistemi
    
    Portföy risk metriklerini sürekli izler ve anında uyarılar üretir.
    """
    
    def __init__(self, config):
        """
        Risk İzleme sistemini başlat
        
        Args:
            config: RiskBudgetConfig objesi
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # İzleme durumu
        self.is_monitoring = False
        self.monitoring_thread = None
        self.monitoring_interval = 60  # 60 saniye
        
        # İzleme kuralları
        self.monitoring_rules = {}
        self.alert_queue = queue.Queue()
        self.active_alerts = {}
        self.alert_history = []
        
        # Bildirim sistemi
        self.notification_channels = []
        self.alert_callbacks = []
        
        # Metrik cache'i
        self.metric_cache = {}
        self.last_update_time = {}
        
        # İstatistikler
        self.monitoring_stats = {
            'total_alerts': 0,
            'alerts_by_severity': {},
            'response_time_avg': 0,
            'uptime_percentage': 0
        }
        
        self._initialize_monitoring_rules()
        self._initialize_notification_system()
        
        self.logger.info("Risk İzleme sistemi başlatıldı")
    
    def _initialize_monitoring_rules(self):
        """İzleme kurallarını başlat"""
        
        rules = [
            MonitoringRule(
                rule_id="VAR_LIMIT_95",
                metric_name="portfolio_var",
                threshold_value=self.config.var_limit,
                threshold_type="greater_than",
                severity="high",
                description="Portfolio VaR limit aşımı"
            ),
            MonitoringRule(
                rule_id="CVAR_LIMIT_95",
                metric_name="portfolio_cvar",
                threshold_value=self.config.cvar_limit,
                threshold_type="greater_than",
                severity="critical",
                description="Portfolio CVaR limit aşımı"
            ),
            MonitoringRule(
                rule_id="VOLATILITY_HIGH",
                metric_name="portfolio_volatility",
                threshold_value=0.25,
                threshold_type="greater_than",
                severity="medium",
                description="Yüksek portföy volatilitesi"
            ),
            MonitoringRule(
                rule_id="DRAWDOWN_WARNING",
                metric_name="max_drawdown",
                threshold_value=-0.15,
                threshold_type="less_than",
                severity="high",
                description="Yüksek çekilme seviyesi"
            ),
            MonitoringRule(
                rule_id="SHARPE_LOW",
                metric_name="sharpe_ratio",
                threshold_value=1.0,
                threshold_type="less_than",
                severity="medium",
                description="Düşük risk-ayarlı getiri"
            ),
            MonitoringRule(
                rule_id="CORRELATION_HIGH",
                metric_name="correlation_risk",
                threshold_value=0.7,
                threshold_type="greater_than",
                severity="medium",
                description="Yüksek korelasyon riski"
            ),
            MonitoringRule(
                rule_id="LIQUIDITY_LOW",
                metric_name="portfolio_liquidity",
                threshold_value=0.3,
                threshold_type="less_than",
                severity="high",
                description="Düşük portföy likiditesi"
            ),
            MonitoringRule(
                rule_id="CONCENTRATION_HIGH",
                metric_name="concentration_risk",
                threshold_value=0.6,
                threshold_type="greater_than",
                severity="medium",
                description="Yüksek konsantrasyon riski"
            )
        ]
        
        for rule in rules:
            self.monitoring_rules[rule.rule_id] = rule
        
        self.logger.info(f"{len(rules)} izleme kuralı yüklendi")
    
    def _initialize_notification_system(self):
        """Bildirim sistemini başlat"""
        
        # Varsayılan bildirim kanallarını ayarla
        self.notification_channels = [
            {
                'type': 'email',
                'enabled': False,  # Email gönderimi için config gerekir
                'recipients': ['risk-team@company.com']
            },
            {
                'type': 'console',
                'enabled': True,
                'level': 'INFO'
            },
            {
                'type': 'file',
                'enabled': True,
                'path': 'logs/risk_alerts.log'
            }
        ]
        
        self.logger.info("Bildirim sistemi başlatıldı")
    
    def start_monitoring(self):
        """İzleme sistemini başlat"""
        
        if self.is_monitoring:
            self.logger.warning("İzleme zaten aktif")
            return
        
        self.is_monitoring = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        
        self.logger.info("Risk izleme sistemi başlatıldı")
    
    def stop_monitoring(self):
        """İzleme sistemini durdur"""
        
        self.is_monitoring = False
        
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=5)
        
        self.logger.info("Risk izleme sistemi durduruldu")
    
    def _monitoring_loop(self):
        """Ana izleme döngüsü"""
        
        self.logger.info("İzleme döngüsü başlatıldı")
        
        while self.is_monitoring:
            try:
                start_time = time.time()
                
                # Risk metriklerini güncelle
                current_metrics = self._update_risk_metrics()
                
                # Kuralları kontrol et
                triggered_alerts = self._check_monitoring_rules(current_metrics)
                
                # Uyarıları işle
                for alert in triggered_alerts:
                    self._process_alert(alert)
                
                # İstatistikleri güncelle
                self._update_monitoring_stats(len(triggered_alerts), time.time() - start_time)
                
                # Kuyruktaki uyarıları işle
                self._process_alert_queue()
                
                # Interval kadar bekle
                time.sleep(self.monitoring_interval)
                
            except Exception as e:
                self.logger.error(f"İzleme döngüsü hatası: {str(e)}")
                time.sleep(5)  # Hata durumunda kısa bekle
    
    def _update_risk_metrics(self) -> Dict:
        """Risk metriklerini güncelle"""
        
        # Bu metot gerçek uygulamada portföy verilerini alacak
        # Şimdi dummy verilerle çalışıyor
        
        current_time = datetime.now()
        
        # Dummy metrikler (gerçek uygulamada hesaplanacak)
        metrics = {
            'timestamp': current_time,
            'portfolio_var': np.random.uniform(0.05, 0.15),
            'portfolio_cvar': np.random.uniform(0.08, 0.20),
            'portfolio_volatility': np.random.uniform(0.10, 0.25),
            'max_drawdown': np.random.uniform(-0.20, -0.05),
            'sharpe_ratio': np.random.uniform(0.5, 2.0),
            'sortino_ratio': np.random.uniform(0.8, 2.5),
            'calmar_ratio': np.random.uniform(0.3, 1.5),
            'correlation_risk': np.random.uniform(0.1, 0.8),
            'portfolio_liquidity': np.random.uniform(0.3, 0.9),
            'concentration_risk': np.random.uniform(0.2, 0.7)
        }
        
        # Cache'e kaydet
        self.metric_cache = metrics
        self.last_update_time = current_time
        
        return metrics
    
    def _check_monitoring_rules(self, metrics: Dict) -> List[AlertEvent]:
        """İzleme kurallarını kontrol et"""
        
        triggered_alerts = []
        
        for rule_id, rule in self.monitoring_rules.items():
            if not rule.enabled:
                continue
            
            metric_value = metrics.get(rule.metric_name)
            
            if metric_value is None:
                continue
            
            # Eşik kontrolü
            threshold_breach = self._check_threshold(
                metric_value, rule.threshold_value, rule.threshold_type
            )
            
            if threshold_breach:
                alert = AlertEvent(
                    event_id=f"{rule_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                    rule_id=rule_id,
                    timestamp=datetime.now(),
                    metric_value=metric_value,
                    threshold_value=rule.threshold_value,
                    severity=rule.severity,
                    message=f"{rule.description}: {metric_value:.3f} (Limit: {rule.threshold_value:.3f})",
                    action_required=self._get_recommended_action(rule, metric_value)
                )
                
                triggered_alerts.append(alert)
        
        return triggered_alerts
    
    def _check_threshold(self, value: float, threshold: float, threshold_type: str) -> bool:
        """Eşik kontrolü yap"""
        
        if threshold_type == "greater_than":
            return value > threshold
        elif threshold_type == "less_than":
            return value < threshold
        elif threshold_type == "equal_to":
            return abs(value - threshold) < 0.001
        else:
            return False
    
    def _get_recommended_action(self, rule: MonitoringRule, metric_value: float) -> str:
        """Önerilen aksiyonu al"""
        
        action_map = {
            "VAR_LIMIT_95": "Pozisyon boyutlarını azalt veya hedge stratejisi uygula",
            "CVAR_LIMIT_95": "Tail risk azaltımı için acil önlem al",
            "VOLATILITY_HIGH": "Volatilite hedge'i değerlendir veya pozisyon çeşitliliği artır",
            "DRAWDOWN_WARNING": "Stop-loss seviyelerini gözden geçir ve risk azaltımı yap",
            "SHARPE_LOW": "Risk-ayarlı getiri iyileştirmesi için portföy optimizasyonu yap",
            "CORRELATION_HIGH": "Yüksek korelasyonlu pozisyonları diversifiye et",
            "LIQUIDITY_LOW": "Likidite sağlayıcılarıyla görüş veya pozisyonları azalt",
            "CONCENTRATION_HIGH": "Portföy konsantrasyonunu azalt"
        }
        
        return action_map.get(rule.rule_id, "Risk metriklerini detaylı incele")
    
    def _process_alert(self, alert: AlertEvent):
        """Uyarıyı işle"""
        
        try:
            # Aktif uyarılara ekle
            self.active_alerts[alert.event_id] = alert
            
            # Kuyruğa ekle
            self.alert_queue.put(alert)
            
            # Bildirim gönder
            self._send_notification(alert)
            
            # Callback'leri çağır
            self._trigger_callbacks(alert)
            
            self.logger.warning(f"Uyarı oluşturuldu: {alert.message}")
            
        except Exception as e:
            self.logger.error(f"Uyarı işleme hatası: {str(e)}")
    
    def _send_notification(self, alert: AlertEvent):
        """Bildirim gönder"""
        
        for channel in self.notification_channels:
            if not channel.get('enabled', True):
                continue
            
            try:
                if channel['type'] == 'console':
                    self._send_console_notification(alert, channel)
                elif channel['type'] == 'file':
                    self._send_file_notification(alert, channel)
                elif channel['type'] == 'email':
                    self._send_email_notification(alert, channel)
                    
            except Exception as e:
                self.logger.error(f"Bildirim gönderme hatası ({channel['type']}): {str(e)}")
    
    def _send_console_notification(self, alert: AlertEvent, channel: Dict):
        """Konsol bildirimi gönder"""
        
        timestamp = alert.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        
        if alert.severity in ['high', 'critical']:
            # Kritik uyarılar için farklı format
            print(f"\n🚨 KRİTİK UYARI 🚨")
            print(f"Zaman: {timestamp}")
            print(f"Seviye: {alert.severity.upper()}")
            print(f"Mesaj: {alert.message}")
            print(f"Aksiyon: {alert.action_required}\n")
        else:
            print(f"[{timestamp}] {alert.severity.upper()}: {alert.message}")
    
    def _send_file_notification(self, alert: AlertEvent, channel: Dict):
        """Dosya bildirimi gönder"""
        
        import os
        
        log_path = channel.get('path', 'logs/risk_alerts.log')
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        
        timestamp = alert.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        
        with open(log_path, 'a', encoding='utf-8') as f:
            f.write(f"[{timestamp}] {alert.severity.upper()}: {alert.message}\\n")
            f.write(f"Event ID: {alert.event_id}\\n")
            f.write(f"Aksiyon: {alert.action_required}\\n")
            f.write("-" * 50 + "\\n")
    
    def _send_email_notification(self, alert: AlertEvent, channel: Dict):
        """Email bildirimi gönder"""
        
        # Bu metot gerçek email yapılandırması gerektirir
        # Şimdi basit simülasyon
        
        recipients = channel.get('recipients', [])
        
        if recipients:
            self.logger.info(f"Email uyarısı gönderildi: {recipients} - {alert.message}")
    
    def _trigger_callbacks(self, alert: AlertEvent):
        """Callback fonksiyonlarını tetikle"""
        
        for callback in self.alert_callbacks:
            try:
                callback(alert)
            except Exception as e:
                self.logger.error(f"Callback hatası: {str(e)}")
    
    def _process_alert_queue(self):
        """Uyarı kuyruğunu işle"""
        
        while not self.alert_queue.empty():
            try:
                alert = self.alert_queue.get_nowait()
                
                # Uyarı geçmişine ekle
                self.alert_history.append(alert)
                
                # Eski uyarıları temizle (son 1000)
                if len(self.alert_history) > 1000:
                    self.alert_history = self.alert_history[-1000:]
                
            except queue.Empty:
                break
            except Exception as e:
                self.logger.error(f"Kuyruk işleme hatası: {str(e)}")
    
    def _update_monitoring_stats(self, alert_count: int, response_time: float):
        """İzleme istatistiklerini güncelle"""
        
        self.monitoring_stats['total_alerts'] += alert_count
        
        # Seviyeye göre dağılım
        if alert_count > 0:
            severity_key = f"alerts_{datetime.now().strftime('%Y%m%d')}"
            if severity_key not in self.monitoring_stats['alerts_by_severity']:
                self.monitoring_stats['alerts_by_severity'][severity_key] = {
                    'low': 0, 'medium': 0, 'high': 0, 'critical': 0
                }
            
            for severity in ['low', 'medium', 'high', 'critical']:
                self.monitoring_stats['alerts_by_severity'][severity_key][severity] += 1
        
        # Ortalama yanıt süresi güncelleme
        if self.monitoring_stats['response_time_avg'] == 0:
            self.monitoring_stats['response_time_avg'] = response_time
        else:
            # Exponential moving average
            alpha = 0.1
            self.monitoring_stats['response_time_avg'] = (
                alpha * response_time + (1 - alpha) * self.monitoring_stats['response_time_avg']
            )
    
    def acknowledge_alert(self, event_id: str, user: str = "system") -> bool:
        """Uyarıyı kabul et"""
        
        if event_id in self.active_alerts:
            self.active_alerts[event_id].acknowledged = True
            self.logger.info(f"Uyarı kabul edildi: {event_id} - Kullanıcı: {user}")
            return True
        else:
            self.logger.warning(f"Uyarı bulunamadı: {event_id}")
            return False
    
    def resolve_alert(self, event_id: str, user: str = "system", notes: str = "") -> bool:
        """Uyarıyı çöz"""
        
        if event_id in self.active_alerts:
            self.active_alerts[event_id].resolved = True
            self.logger.info(f"Uyarı çözüldü: {event_id} - Kullanıcı: {user} - Notlar: {notes}")
            
            # Aktif uyarılardan kaldır
            del self.active_alerts[event_id]
            return True
        else:
            self.logger.warning(f"Uyarı bulunamadı: {event_id}")
            return False
    
    def get_active_alerts(self) -> List[Dict]:
        """Aktif uyarıları al"""
        
        alerts = []
        for alert in self.active_alerts.values():
            alerts.append({
                'event_id': alert.event_id,
                'rule_id': alert.rule_id,
                'timestamp': alert.timestamp.isoformat(),
                'metric_value': alert.metric_value,
                'threshold_value': alert.threshold_value,
                'severity': alert.severity,
                'message': alert.message,
                'action_required': alert.action_required,
                'acknowledged': alert.acknowledged,
                'resolved': alert.resolved
            })
        
        return alerts
    
    def get_alert_statistics(self) -> Dict:
        """Uyarı istatistiklerini al"""
        
        return {
            'total_alerts': len(self.alert_history),
            'active_alerts': len(self.active_alerts),
            'monitoring_active': self.is_monitoring,
            'last_update': self.last_update_time.isoformat() if self.last_update_time else None,
            'monitoring_stats': self.monitoring_stats,
            'rules_count': len(self.monitoring_rules),
            'enabled_rules': sum(1 for r in self.monitoring_rules.values() if r.enabled)
        }
    
    def add_custom_monitoring_rule(self, rule: MonitoringRule):
        """Özel izleme kuralı ekle"""
        
        self.monitoring_rules[rule.rule_id] = rule
        self.logger.info(f"Özel izleme kuralı eklendi: {rule.rule_id}")
    
    def remove_monitoring_rule(self, rule_id: str) -> bool:
        """İzleme kuralını kaldır"""
        
        if rule_id in self.monitoring_rules:
            del self.monitoring_rules[rule_id]
            self.logger.info(f"İzleme kuralı kaldırıldı: {rule_id}")
            return True
        else:
            self.logger.warning(f"İzleme kuralı bulunamadı: {rule_id}")
            return False
    
    def add_alert_callback(self, callback: Callable[[AlertEvent], None]):
        """Uyarı callback'i ekle"""
        
        self.alert_callbacks.append(callback)
        self.logger.info("Uyarı callback'i eklendi")
    
    def get_dashboard_data(self) -> Dict:
        """Dashboard verilerini al"""
        
        return {
            'monitoring_status': 'active' if self.is_monitoring else 'inactive',
            'active_alerts_count': len(self.active_alerts),
            'critical_alerts': len([a for a in self.active_alerts.values() if a.severity == 'critical']),
            'total_rules': len(self.monitoring_rules),
            'enabled_rules': sum(1 for r in self.monitoring_rules.values() if r.enabled),
            'last_update': self.last_update_time.isoformat() if self.last_update_time else None,
            'recent_alerts': self.get_active_alerts()[:5],  # Son 5 uyarı
            'monitoring_stats': self.monitoring_stats
        }
    
    def initialize_alerts(self):
        """Uyarı sistemini başlat"""
        
        self.logger.info("Uyarı sistemi hazırlandı")
        
        # Test uyarısı (opsiyonel)
        if hasattr(self.config, 'send_test_alert') and self.config.send_test_alert:
            test_alert = AlertEvent(
                event_id=f"TEST_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                rule_id="SYSTEM_TEST",
                timestamp=datetime.now(),
                metric_value=1.0,
                threshold_value=0.5,
                severity="low",
                message="Risk izleme sistemi test uyarısı",
                action_required="Test başarılı - sistem çalışıyor"
            )
            self._process_alert(test_alert)