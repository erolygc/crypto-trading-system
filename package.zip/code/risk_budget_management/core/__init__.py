"""
Risk Bütçesi Yönetimi Ana Koordinatör

Bu modül tüm risk bütçesi yönetimi bileşenlerini koordine eder ve 
Bitwisers 2.0 sisteminin risk yönetimi omurgasını oluşturur.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from dataclasses import dataclass
import json
from enum import Enum

from .risk_budget_allocator import RiskBudgetAllocator
from .risk_monitor import RiskMonitor
from .risk_limit_engine import RiskLimitEngine
from .stress_tester import StressTester
from .risk_attributor import RiskAttributor
from .performance_calculator import PerformanceCalculator
from .regulatory_reporter import RegulatoryReporter

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RiskLevel(Enum):
    """Risk seviyeleri tanımları"""
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4

class PortfolioLevel(Enum):
    """Portföy seviyeleri"""
    ENTERPRISE = "enterprise"
    PORTFOLIO = "portfolio"
    STRATEGY = "strategy"
    POSITION = "position"

@dataclass
class RiskBudgetConfig:
    """Risk bütçesi konfigürasyonu"""
    total_risk_budget: float
    var_limit: float
    cvar_limit: float
    max_position_size: float
    correlation_threshold: float
    stress_test_scenarios: List[str]
    rebalance_frequency: str  # daily, weekly, monthly
    alert_thresholds: Dict[str, float]

@dataclass
class RiskMetrics:
    """Risk metrikleri"""
    portfolio_var: float
    portfolio_cvar: float
    portfolio_volatility: float
    max_drawdown: float
    sharpe_ratio: float
    sortino_ratio: float
    calmar_ratio: float
    correlation_risk: float

@dataclass
class AlertInfo:
    """Risk alert bilgileri"""
    alert_id: str
    severity: RiskLevel
    message: str
    timestamp: datetime
    components_affected: List[str]
    recommended_action: str

class RiskBudgetManager:
    """
    Risk Bütçesi Yönetimi Ana Koordinatör
    
    Bitwisers 2.0 sisteminin risk yönetimi omurgasını oluşturan merkezi 
    bileşen. Tüm risk yönetimi işlevlerini koordine eder ve entegre eder.
    """
    
    def __init__(self, config: RiskBudgetConfig):
        """
        Risk Bütçesi Yöneticisini başlat
        
        Args:
            config: Risk bütçesi konfigürasyonu
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Alt bileşenleri başlat
        self.allocator = RiskBudgetAllocator(config)
        self.monitor = RiskMonitor(config)
        self.limit_engine = RiskLimitEngine(config)
        self.stress_tester = StressTester(config)
        self.attributor = RiskAttributor(config)
        self.performance_calc = PerformanceCalculator(config)
        self.regulatory_reporter = RegulatoryReporter(config)
        
        # Durum bilgileri
        self.current_risk_budgets = {}
        self.active_alerts = []
        self.risk_history = []
        self.last_rebalance = datetime.now()
        
        self.logger.info("Risk Bütçesi Yöneticisi başlatıldı")
    
    def initialize_system(self) -> bool:
        """
        Risk yönetimi sistemini başlat ve test et
        
        Returns:
            bool: Başlatma başarılı ise True
        """
        try:
            self.logger.info("Risk yönetimi sistemi başlatılıyor...")
            
            # 1. Risk bütçesi dağıtımını başlat
            self.allocator.initialize_allocations()
            
            # 2. Risk limitlerini kur
            self.limit_engine.initialize_limits()
            
            # 3. Monitor sistemini başlat
            self.monitor.start_monitoring()
            
            # 4. Alert sistemini hazırla
            self.monitor.initialize_alerts()
            
            # 5. Stress test senaryolarını yükle
            self.stress_tester.load_scenarios()
            
            self.logger.info("Risk yönetimi sistemi başarıyla başlatıldı")
            return True
            
        except Exception as e:
            self.logger.error(f"Sistem başlatma hatası: {str(e)}")
            return False
    
    def process_portfolio_risk(self, 
                             portfolio_data: Dict,
                             market_data: Dict,
                             positions: Dict) -> Dict:
        """
        Portföy risk analizi ve yönetimi gerçekleştir
        
        Args:
            portfolio_data: Portföy verileri
            market_data: Piyasa verileri
            positions: Pozisyon verileri
            
        Returns:
            Dict: Risk analiz sonuçları ve öneriler
        """
        try:
            results = {}
            
            # 1. Mevcut risk metriklerini hesapla
            risk_metrics = self._calculate_risk_metrics(
                portfolio_data, market_data, positions
            )
            results['risk_metrics'] = risk_metrics
            
            # 2. Risk limitlerini kontrol et
            limit_status = self.limit_engine.check_limits(risk_metrics)
            results['limit_status'] = limit_status
            
            # 3. Risk bütçesi dağılımını güncelle
            budget_allocation = self.allocator.update_allocations(
                risk_metrics, limit_status
            )
            results['budget_allocation'] = budget_allocation
            
            # 4. Korelasyon riskini analiz et
            correlation_risk = self._analyze_correlation_risk(
                market_data, positions
            )
            results['correlation_risk'] = correlation_risk
            
            # 5. Stress testleri çalıştır
            stress_results = self.stress_tester.run_stress_tests(
                portfolio_data, market_data
            )
            results['stress_tests'] = stress_results
            
            # 6. Alert durumunu kontrol et
            alerts = self._check_alerts(risk_metrics, limit_status)
            results['alerts'] = alerts
            
            # 7. Risk önerilerini oluştur
            recommendations = self._generate_recommendations(
                risk_metrics, limit_status, stress_results
            )
            results['recommendations'] = recommendations
            
            return results
            
        except Exception as e:
            self.logger.error(f"Portföy risk analizi hatası: {str(e)}")
            return {"error": str(e)}
    
    def _calculate_risk_metrics(self, 
                              portfolio_data: Dict,
                              market_data: Dict, 
                              positions: Dict) -> RiskMetrics:
        """Risk metriklerini hesapla"""
        
        # VaR/CVaR hesaplamaları
        portfolio_returns = self._calculate_portfolio_returns(
            portfolio_data, market_data
        )
        
        # VaR hesaplama (95% güven seviyesi)
        var_95 = self._calculate_var(portfolio_returns, 0.95)
        
        # CVaR hesaplama
        cvar_95 = self._calculate_cvar(portfolio_returns, var_95)
        
        # Volatilite
        volatility = np.std(portfolio_returns) * np.sqrt(252)
        
        # Max Drawdown
        max_drawdown = self._calculate_max_drawdown(portfolio_returns)
        
        # Risk-ayarlı performans metrikleri
        risk_free_rate = 0.02  # Risk-free rate
        
        excess_returns = portfolio_returns - risk_free_rate / 252
        
        sharpe_ratio = np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252)
        
        # Downside deviation for Sortino ratio
        downside_returns = np.minimum(portfolio_returns, 0)
        downside_std = np.std(downside_returns) * np.sqrt(252)
        sortino_ratio = np.mean(excess_returns) / downside_std if downside_std > 0 else 0
        
        # Calmar ratio (annualized return / max drawdown)
        annual_return = np.mean(portfolio_returns) * 252
        calmar_ratio = annual_return / abs(max_drawdown) if max_drawdown != 0 else 0
        
        return RiskMetrics(
            portfolio_var=var_95,
            portfolio_cvar=cvar_95,
            portfolio_volatility=volatility,
            max_drawdown=max_drawdown,
            sharpe_ratio=sharpe_ratio,
            sortino_ratio=sortino_ratio,
            calmar_ratio=calmar_ratio,
            correlation_risk=0.0  # Will be calculated separately
        )
    
    def _calculate_portfolio_returns(self, 
                                   portfolio_data: Dict,
                                   market_data: Dict) -> np.ndarray:
        """Portföy getiri serisini hesapla"""
        
        # Basitleştirilmiş portföy getiri hesaplaması
        # Gerçek uygulamada pozisyon ağırlıkları ve fiyat serileri kullanılır
        
        price_history = market_data.get('price_history', pd.DataFrame())
        positions = portfolio_data.get('positions', {})
        
        if price_history.empty or not positions:
            return np.array([0.0])  # Tek değer döndür
        
        # Portföy değer serisi
        portfolio_values = []
        
        for date in price_history.index:
            portfolio_value = 0
            for symbol, position in positions.items():
                if symbol in price_history.columns:
                    price = price_history.loc[date, symbol]
                    portfolio_value += position['quantity'] * price
            
            portfolio_values.append(portfolio_value)
        
        # Getiri serisi hesapla
        portfolio_values = np.array(portfolio_values)
        returns = np.diff(portfolio_values) / portfolio_values[:-1]
        
        return returns
    
    def _calculate_var(self, returns: np.ndarray, confidence_level: float) -> float:
        """VaR hesapla"""
        if len(returns) == 0:
            return 0.0
        
        var = np.percentile(returns, (1 - confidence_level) * 100)
        return abs(var)  # Pozitif değer olarak döndür
    
    def _calculate_cvar(self, returns: np.ndarray, var: float) -> float:
        """CVaR hesapla"""
        if len(returns) == 0:
            return 0.0
        
        threshold = -var
        tail_returns = returns[returns <= threshold]
        
        if len(tail_returns) == 0:
            return abs(var)
        
        cvar = np.mean(tail_returns)
        return abs(cvar)
    
    def _calculate_max_drawdown(self, returns: np.ndarray) -> float:
        """Maksimum çekilme hesapla"""
        if len(returns) == 0:
            return 0.0
        
        cumulative_returns = (1 + returns).cumprod()
        running_max = np.maximum.accumulate(cumulative_returns)
        drawdown = (cumulative_returns - running_max) / running_max
        
        return np.min(drawdown)
    
    def _analyze_correlation_risk(self, 
                                market_data: Dict,
                                positions: Dict) -> float:
        """Korelasyon riskini analiz et"""
        
        price_history = market_data.get('price_history', pd.DataFrame())
        
        if price_history.empty or len(price_history.columns) < 2:
            return 0.0
        
        # Korelasyon matrisi hesapla
        returns = price_history.pct_change().dropna()
        correlation_matrix = returns.corr()
        
        # Yüksek korelasyonlu çiftleri tespit et
        high_correlations = []
        for i in range(len(correlation_matrix.columns)):
            for j in range(i+1, len(correlation_matrix.columns)):
                corr = correlation_matrix.iloc[i, j]
                if abs(corr) > self.config.correlation_threshold:
                    high_correlations.append(abs(corr))
        
        # Ortalama yüksek korelasyon
        if high_correlations:
            avg_high_corr = np.mean(high_correlations)
            risk_score = avg_high_corr * len(high_correlations)
            return min(risk_score, 1.0)  # 0-1 arası normalize et
        
        return 0.0
    
    def _check_alerts(self, 
                     risk_metrics: RiskMetrics,
                     limit_status: Dict) -> List[AlertInfo]:
        """Alert durumunu kontrol et"""
        
        alerts = []
        
        # VaR limit alertı
        if risk_metrics.portfolio_var > self.config.var_limit:
            alert = AlertInfo(
                alert_id=f"VAR_LIMIT_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                severity=RiskLevel.HIGH,
                message=f"VaR limit aşıldı: {risk_metrics.portfolio_var:.2%} > {self.config.var_limit:.2%}",
                timestamp=datetime.now(),
                components_affected=["Portfolio", "Risk Limits"],
                recommended_action="Pozisyon boyutlarını azalt veya hedge yap"
            )
            alerts.append(alert)
        
        # CVaR limit alertı
        if risk_metrics.portfolio_cvar > self.config.cvar_limit:
            alert = AlertInfo(
                alert_id=f"CVAR_LIMIT_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                severity=RiskLevel.CRITICAL,
                message=f"CVaR limit aşıldı: {risk_metrics.portfolio_cvar:.2%} > {self.config.cvar_limit:.2%}",
                timestamp=datetime.now(),
                components_affected=["Portfolio", "Tail Risk"],
                recommended_action="Acil pozisyon azaltımı gerekli"
            )
            alerts.append(alert)
        
        # Volatilite alertı
        volatility_threshold = self.config.alert_thresholds.get('volatility', 0.30)
        if risk_metrics.portfolio_volatility > volatility_threshold:
            alert = AlertInfo(
                alert_id=f"VOLATILITY_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                severity=RiskLevel.MEDIUM,
                message=f"Yüksek volatilite: {risk_metrics.portfolio_volatility:.2%}",
                timestamp=datetime.now(),
                components_affected=["Market Conditions"],
                recommended_action="Volatilite hedge'i değerlendir"
            )
            alerts.append(alert)
        
        return alerts
    
    def _generate_recommendations(self, 
                                risk_metrics: RiskMetrics,
                                limit_status: Dict,
                                stress_results: Dict) -> Dict:
        """Risk yönetimi önerileri oluştur"""
        
        recommendations = {
            'immediate_actions': [],
            'portfolio_adjustments': [],
            'risk_mitigation': [],
            'monitoring_changes': []
        }
        
        # VaR önerileri
        if risk_metrics.portfolio_var > self.config.var_limit * 0.8:
            recommendations['immediate_actions'].append(
                "VaR limitine yaklaşıyoruz - pozisyon boyutlarını gözden geçirin"
            )
        
        # CVaR önerileri  
        if risk_metrics.portfolio_cvar > self.config.cvar_limit * 0.8:
            recommendations['immediate_actions'].append(
                "CVaR riskini azaltmak için tail hedge stratejileri uygulayın"
            )
        
        # Korelasyon önerileri
        if risk_metrics.correlation_risk > 0.7:
            recommendations['portfolio_adjustments'].append(
                "Yüksek korelasyonlu pozisyonları diversifiye edin"
            )
        
        # Sharpe ratio önerileri
        if risk_metrics.sharpe_ratio < 1.0:
            recommendations['risk_mitigation'].append(
                "Sharpe ratio düşük - risk ayarlı getiri iyileştirmesi gerekli"
            )
        
        # Stress test önerileri
        if stress_results.get('severe_scenarios_failed', 0) > 0:
            recommendations['immediate_actions'].append(
                f"Stress testlerinde {stress_results['severe_scenarios_failed']} senaryo başarısız - acil önlem alın"
            )
        
        return recommendations
    
    def get_dashboard_data(self) -> Dict:
        """Risk yönetimi dashboard verilerini al"""
        
        return {
            'timestamp': datetime.now().isoformat(),
            'risk_budgets': self.current_risk_budgets,
            'active_alerts': [
                {
                    'id': alert.alert_id,
                    'severity': alert.severity.value,
                    'message': alert.message,
                    'timestamp': alert.timestamp.isoformat()
                }
                for alert in self.active_alerts
            ],
            'performance_summary': self.performance_calc.get_latest_metrics(),
            'risk_limits_status': self.limit_engine.get_limit_status(),
            'last_rebalance': self.last_rebalance.isoformat()
        }
    
    def rebalance_risk_budgets(self) -> bool:
        """Risk bütçelerini yeniden dengele"""
        
        try:
            self.logger.info("Risk bütçesi yeniden dengeleme başlatılıyor...")
            
            # Yeniden dengeleme zamanını güncelle
            self.last_rebalance = datetime.now()
            
            # Risk bütçesi dağıtımını güncelle
            self.current_risk_budgets = self.allocator.rebalance_allocations()
            
            # Limitleri yeniden ayarla
            self.limit_engine.update_limits_from_budgets(self.current_risk_budgets)
            
            self.logger.info("Risk bütçesi yeniden dengeleme tamamlandı")
            return True
            
        except Exception as e:
            self.logger.error(f"Yeniden dengeleme hatası: {str(e)}")
            return False
    
    def generate_regulatory_report(self, 
                                 report_type: str = "comprehensive") -> Dict:
        """Düzenleyici risk raporu oluştur"""
        
        return self.regulatory_reporter.generate_report(
            report_type=report_type,
            portfolio_data=self.current_risk_budgets,
            risk_metrics=self._get_current_risk_metrics()
        )
    
    def _get_current_risk_metrics(self) -> RiskMetrics:
        """Mevcut risk metriklerini al"""
        # Bu metot gerçek uygulamada cache'den veya hesaplamadan gelir
        return RiskMetrics(
            portfolio_var=0.0,
            portfolio_cvar=0.0,
            portfolio_volatility=0.0,
            max_drawdown=0.0,
            sharpe_ratio=0.0,
            sortino_ratio=0.0,
            calmar_ratio=0.0,
            correlation_risk=0.0
        )