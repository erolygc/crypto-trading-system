"""
Risk Limit Zorlama Motoru

VaR/CVaR limitlerini zorlar ve dinamik risk limiti 
ayarlamaları yapar.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from dataclasses import dataclass
from enum import Enum
import json
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

@dataclass
class RiskLimit:
    """Risk limit tanımı"""
    limit_id: str
    metric_name: str
    limit_value: float
    limit_type: str  # 'hard', 'soft', 'warning'
    severity: str  # 'low', 'medium', 'high', 'critical'
    description: str
    action_on_breach: str
    enabled: bool = True

@dataclass
class LimitViolation:
    """Limit ihlali bilgileri"""
    violation_id: str
    limit_id: str
    timestamp: datetime
    metric_value: float
    limit_value: float
    violation_severity: float  # 0-1 arası, ne kadar aşıldığı
    action_taken: str
    auto_resolved: bool = False

class LimitType(Enum):
    """Limit türleri"""
    HARD = "hard"  # Katı limit, aşılamaz
    SOFT = "soft"  # Yumuşak limit, geçici aşılabilir
    WARNING = "warning"  # Uyarı seviyesi

class ViolationSeverity(Enum):
    """İhlal seviyeleri"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class RiskLimitEngine:
    """
    Risk Limit Zorlama Motoru
    
    Portfolio, strateji ve pozisyon seviyelerinde risk limitlerini 
    zorlar ve ihlalleri yönetir.
    """
    
    def __init__(self, config):
        """
        Risk Limit Motorunu başlat
        
        Args:
            config: RiskBudgetConfig objesi
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Risk limitleri
        self.risk_limits = {}
        self.violations = []
        self.limit_history = []
        
        # Limit yönetimi
        self.dynamic_adjustment_enabled = True
        self.limit_buffer = 0.05  # %5 buffer
        self.violation_threshold = 0.02  # %2 buffer
        
        # Auto-recovery settings
        self.auto_recovery_enabled = True
        self.recovery_check_interval = 300  # 5 dakika
        
        # Limit performansı
        self.limit_effectiveness = 0.85
        self.violation_rate = 0.02
        
        self._initialize_risk_limits()
        
        self.logger.info("Risk Limit Motoru başlatıldı")
    
    def _initialize_risk_limits(self):
        """Risk limitlerini başlat"""
        
        # Enterprise seviye limitler
        enterprise_limits = [
            RiskLimit(
                limit_id="ENTERPRISE_VAR_95",
                metric_name="portfolio_var",
                limit_value=self.config.var_limit,
                limit_type="hard",
                severity="critical",
                description="Enterprise VaR limiti (95%)",
                action_on_breach="Immediate position reduction required"
            ),
            RiskLimit(
                limit_id="ENTERPRISE_CVAR_95",
                metric_name="portfolio_cvar", 
                limit_value=self.config.cvar_limit,
                limit_type="hard",
                severity="critical",
                description="Enterprise CVaR limiti (95%)",
                action_on_breach="Emergency risk reduction protocol"
            ),
            RiskLimit(
                limit_id="ENTERPRISE_VOLATILITY",
                metric_name="portfolio_volatility",
                limit_value=0.30,
                limit_type="soft",
                severity="high",
                description="Portfolio volatilite limiti",
                action_on_breach="Volatility hedge or position adjustment"
            ),
            RiskLimit(
                limit_id="ENTERPRISE_DRAWDOWN",
                metric_name="max_drawdown",
                limit_value=-0.20,
                limit_type="soft",
                severity="high",
                description="Maksimum çekilme limiti",
                action_on_breach="Drawdown management activation"
            )
        ]
        
        # Strateji seviye limitler
        strategy_limits = [
            RiskLimit(
                limit_id="STRATEGY_VAR_99",
                metric_name="strategy_var",
                limit_value=0.05,
                limit_type="hard",
                severity="high",
                description="Strateji VaR limiti (99%)",
                action_on_breach="Strategy position sizing adjustment"
            ),
            RiskLimit(
                limit_id="STRATEGY_CONCENTRATION",
                metric_name="strategy_concentration",
                limit_value=0.15,
                limit_type="warning",
                severity="medium",
                description="Strateji konsantrasyon limiti",
                action_on_breach="Diversification review"
            ),
            RiskLimit(
                limit_id="STRATEGY_CORRELATION",
                metric_name="strategy_correlation",
                limit_value=0.80,
                limit_type="soft",
                severity="medium",
                description="Strateji korelasyon limiti",
                action_on_breach="Strategy rebalancing"
            )
        ]
        
        # Pozisyon seviye limitler
        position_limits = [
            RiskLimit(
                limit_id="POSITION_SIZE",
                metric_name="position_size",
                limit_value=self.config.max_position_size,
                limit_type="hard",
                severity="high",
                description="Maksimum pozisyon boyutu",
                action_on_breach="Position size reduction"
            ),
            RiskLimit(
                limit_id="POSITION_VAR",
                metric_name="position_var",
                limit_value=0.02,
                limit_type="hard",
                severity="medium",
                description="Pozisyon VaR limiti",
                action_on_breach="Position hedging or reduction"
            ),
            RiskLimit(
                limit_id="POSITION_CONCENTRATION",
                metric_name="position_concentration",
                limit_value=0.05,
                limit_type="soft",
                severity="medium",
                description="Pozisyon konsantrasyon limiti",
                action_on_breach="Position diversification"
            )
        ]
        
        # Tüm limitleri birleştir
        all_limits = enterprise_limits + strategy_limits + position_limits
        
        for limit in all_limits:
            self.risk_limits[limit.limit_id] = limit
        
        self.logger.info(f"{len(all_limits)} risk limiti yüklendi")
    
    def initialize_limits(self):
        """Risk limitlerini başlat"""
        
        try:
            self.logger.info("Risk limitleri başlatılıyor...")
            
            # Limit etkinlik kontrolü
            self._validate_limits()
            
            # Limit performans metriklerini hesapla
            self._calculate_limit_effectiveness()
            
            self.logger.info("Risk limitleri başarıyla başlatıldı")
            
        except Exception as e:
            self.logger.error(f"Limit başlatma hatası: {str(e)}")
    
    def check_limits(self, risk_metrics: 'RiskMetrics') -> Dict:
        """
        Risk limitlerini kontrol et
        
        Args:
            risk_metrics: Risk metrikleri
            
        Returns:
            Dict: Limit kontrol sonuçları
        """
        
        try:
            results = {
                'violations': [],
                'warnings': [],
                'all_within_limits': True,
                'actions_required': [],
                'timestamp': datetime.now().isoformat()
            }
            
            # Her limiti kontrol et
            for limit_id, limit in self.risk_limits.items():
                if not limit.enabled:
                    continue
                
                metric_value = getattr(risk_metrics, limit.metric_name, None)
                
                if metric_value is None:
                    continue
                
                violation_status = self._check_single_limit(limit, metric_value)
                
                if violation_status['violated']:
                    results['all_within_limits'] = False
                    
                    # İhlal kaydet
                    violation = LimitViolation(
                        violation_id=f"{limit_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                        limit_id=limit_id,
                        timestamp=datetime.now(),
                        metric_value=metric_value,
                        limit_value=limit.limit_value,
                        violation_severity=violation_status['severity'],
                        action_taken="None yet"
                    )
                    
                    results['violations'].append(violation)
                    
                    # Aksiyon gerekli mi kontrol et
                    if limit.limit_type == "hard" or violation_status['severity'] > 0.7:
                        results['actions_required'].append({
                            'limit_id': limit_id,
                            'action': limit.action_on_breach,
                            'priority': limit.severity
                        })
                
                elif violation_status['warning']:
                    results['warnings'].append({
                        'limit_id': limit_id,
                        'message': f"{limit.description} yaklaşıyor",
                        'current_value': metric_value,
                        'limit_value': limit.limit_value,
                        'proximity': violation_status['proximity']
                    })
            
            # İhlalleri kaydet
            if results['violations']:
                self.violations.extend(results['violations'])
            
            return results
            
        except Exception as e:
            self.logger.error(f"Limit kontrol hatası: {str(e)}")
            return {'error': str(e)}
    
    def _check_single_limit(self, limit: RiskLimit, metric_value: float) -> Dict:
        """Tek limit kontrolü"""
        
        result = {
            'violated': False,
            'warning': False,
            'severity': 0.0,
            'proximity': 0.0
        }
        
        # Limit aşım kontrolü
        if limit.limit_type == "hard":
            if metric_value > limit.limit_value:
                result['violated'] = True
                result['severity'] = min((metric_value - limit.limit_value) / limit.limit_value, 1.0)
        
        elif limit.limit_type == "soft":
            # Buffer ile kontrol
            buffer_limit = limit.limit_value * (1 - self.violation_threshold)
            
            if metric_value > limit.limit_value:
                result['violated'] = True
                result['severity'] = min((metric_value - limit.limit_value) / limit.limit_value, 1.0)
            elif metric_value > buffer_limit:
                result['warning'] = True
                result['proximity'] = (metric_value - buffer_limit) / (limit.limit_value - buffer_limit)
        
        elif limit.limit_type == "warning":
            # Uyarı seviyesi - sadece yakınlık kontrolü
            warning_threshold = limit.limit_value * 0.9
            
            if metric_value > warning_threshold:
                result['warning'] = True
                result['proximity'] = (metric_value - warning_threshold) / (limit.limit_value - warning_threshold)
        
        return result
    
    def enforce_limits(self, violations: List[LimitViolation]) -> Dict:
        """
        Limit ihlallerini zorla
        
        Args:
            violations: Limit ihlalleri listesi
            
        Returns:
            Dict: Zorlama sonuçları
        """
        
        try:
            enforcement_results = {
                'actions_taken': [],
                'success_rate': 0.0,
                'total_violations': len(violations),
                'timestamp': datetime.now().isoformat()
            }
            
            successful_actions = 0
            
            for violation in violations:
                limit = self.risk_limits.get(violation.limit_id)
                
                if not limit:
                    continue
                
                # Aksiyon uygula
                action_result = self._apply_limit_action(limit, violation)
                
                violation.action_taken = action_result['action']
                
                if action_result['success']:
                    successful_actions += 1
                
                enforcement_results['actions_taken'].append({
                    'violation_id': violation.violation_id,
                    'limit_id': violation.limit_id,
                    'action': action_result['action'],
                    'success': action_result['success'],
                    'details': action_result['details']
                })
            
            # Başarı oranını hesapla
            enforcement_results['success_rate'] = successful_actions / len(violations) if violations else 1.0
            
            return enforcement_results
            
        except Exception as e:
            self.logger.error(f"Limit zorlama hatası: {str(e)}")
            return {'error': str(e)}
    
    def _apply_limit_action(self, limit: RiskLimit, violation: LimitViolation) -> Dict:
        """Limit aksiyonu uygula"""
        
        action = limit.action_on_breach
        
        if "position reduction" in action.lower():
            return self._apply_position_reduction(violation)
        elif "hedging" in action.lower():
            return self._apply_hedging_strategy(violation)
        elif "rebalancing" in action.lower():
            return self._apply_rebalancing_action(violation)
        elif "emergency" in action.lower():
            return self._apply_emergency_protocol(violation)
        else:
            return {
                'success': False,
                'action': "Unknown action",
                'details': f"No implementation for: {action}"
            }
    
    def _apply_position_reduction(self, violation: LimitViolation) -> Dict:
        """Pozisyon azaltma aksiyonu"""
        
        reduction_percentage = min(violation.violation_severity * 50, 80)  # Max %80 azaltım
        
        return {
            'success': True,
            'action': f"Position size reduction by {reduction_percentage:.1f}%",
            'details': f"Reduce positions to bring metric within limits"
        }
    
    def _apply_hedging_strategy(self, violation: LimitViolation) -> Dict:
        """Hedge stratejisi uygulama"""
        
        hedge_ratio = min(violation.violation_severity * 0.7, 0.5)
        
        return {
            'success': True,
            'action': f"Implement hedge strategy with {hedge_ratio:.1%} hedge ratio",
            'details': f"Deploy hedging instruments to reduce risk exposure"
        }
    
    def _apply_rebalancing_action(self, violation: LimitViolation) -> Dict:
        """Yeniden dengeleme aksiyonu"""
        
        return {
            'success': True,
            'action': "Portfolio rebalancing required",
            'details': "Redistribute allocations to reduce concentration and correlation risks"
        }
    
    def _apply_emergency_protocol(self, violation: LimitViolation) -> Dict:
        """Acil durum protokolü"""
        
        return {
            'success': True,
            'action': "Emergency risk reduction protocol activated",
            'details': "Immediate risk reduction measures deployed across all positions"
        }
    
    def update_limits_from_budgets(self, risk_budgets: Dict):
        """Risk bütçelerinden limitleri güncelle"""
        
        try:
            self.logger.info("Risk bütçelerinden limitler güncelleniyor...")
            
            # Toplam risk kapasitesini hesapla
            total_risk_capacity = sum(
                budget.risk_capacity for budget in risk_budgets.values()
            )
            
            # Enterprise limitlerini güncelle
            enterprise_var_limit = total_risk_capacity * 0.05  # %5
            enterprise_cvar_limit = total_risk_capacity * 0.08  # %8
            
            if "ENTERPRISE_VAR_95" in self.risk_limits:
                self.risk_limits["ENTERPRISE_VAR_95"].limit_value = enterprise_var_limit
            
            if "ENTERPRISE_CVAR_95" in self.risk_limits:
                self.risk_limits["ENTERPRISE_CVAR_95"].limit_value = enterprise_cvar_limit
            
            self.logger.info("Risk limitleri bütçelerden güncellendi")
            
        except Exception as e:
            self.logger.error(f"Limit güncelleme hatası: {str(e)}")
    
    def get_dynamic_limits(self, current_conditions: Dict) -> Dict:
        """Dinamik risk limitlerini hesapla"""
        
        try:
            # Piyasa koşullarına göre limitler ayarlanır
            market_volatility = current_conditions.get('market_volatility', 0.2)
            market_stress = current_conditions.get('market_stress', 0.1)
            liquidity_condition = current_conditions.get('liquidity_condition', 0.8)
            
            # Volatilite faktörü
            volatility_multiplier = 1.0 + (market_volatility - 0.2) * 2  # Normalleştir
            
            # Stres faktörü
            stress_multiplier = 1.0 + market_stress * 3
            
            # Likidite faktörü
            liquidity_multiplier = 1.0 + (0.8 - liquidity_condition) * 2
            
            # Kapsamlı adjustment faktörü
            adjustment_factor = volatility_multiplier * stress_multiplier * liquidity_multiplier
            
            dynamic_limits = {}
            
            for limit_id, limit in self.risk_limits.items():
                if not limit.enabled:
                    continue
                
                if limit.limit_type == "soft":
                    # Sadece soft limitleri dinamik ayarla
                    original_limit = limit.limit_value
                    dynamic_limit = original_limit / adjustment_factor
                    
                    dynamic_limits[limit_id] = {
                        'original_limit': original_limit,
                        'dynamic_limit': dynamic_limit,
                        'adjustment_factor': adjustment_factor,
                        'reason': f"Market condition adjustment (vol: {market_volatility:.2f}, stress: {market_stress:.2f}, liq: {liquidity_condition:.2f})"
                    }
                else:
                    dynamic_limits[limit_id] = {
                        'original_limit': limit.limit_value,
                        'dynamic_limit': limit.limit_value,
                        'adjustment_factor': 1.0,
                        'reason': "Fixed limit (no dynamic adjustment)"
                    }
            
            return dynamic_limits
            
        except Exception as e:
            self.logger.error(f"Dinamik limit hesaplama hatası: {str(e)}")
            return {}
    
    def _validate_limits(self):
        """Risk limitlerinin geçerliliğini kontrol et"""
        
        validation_errors = []
        
        for limit_id, limit in self.risk_limits.items():
            if limit.limit_value <= 0:
                validation_errors.append(f"Invalid limit value for {limit_id}: {limit.limit_value}")
            
            if limit.limit_type not in ['hard', 'soft', 'warning']:
                validation_errors.append(f"Invalid limit type for {limit_id}: {limit.limit_type}")
        
        if validation_errors:
            self.logger.warning(f"Limit validation warnings: {validation_errors}")
        
        return len(validation_errors) == 0
    
    def _calculate_limit_effectiveness(self):
        """Limit etkinliğini hesapla"""
        
        # Geçmiş performans verilerine göre hesapla
        if len(self.violations) > 10:
            # Son 30 günlük ihlalleri analiz et
            recent_violations = [
                v for v in self.violations 
                if v.timestamp > datetime.now() - timedelta(days=30)
            ]
            
            total_days = 30
            violation_rate = len(recent_violations) / total_days
            
            # Etkinlik oranı (düşük ihlal = yüksek etkinlik)
            self.limit_effectiveness = max(0.5, 1.0 - violation_rate)
            self.violation_rate = violation_rate
        else:
            # Varsayılan değerler
            self.limit_effectiveness = 0.85
            self.violation_rate = 0.02
    
    def get_limit_status(self) -> Dict:
        """Mevcut limit durumunu al"""
        
        active_limits = [limit for limit in self.risk_limits.values() if limit.enabled]
        
        return {
            'total_limits': len(self.risk_limits),
            'active_limits': len(active_limits),
            'limit_effectiveness': self.limit_effectiveness,
            'violation_rate': self.violation_rate,
            'recent_violations': len([
                v for v in self.violations 
                if v.timestamp > datetime.now() - timedelta(days=7)
            ]),
            'dynamic_adjustment_enabled': self.dynamic_adjustment_enabled,
            'last_update': datetime.now().isoformat()
        }
    
    def get_limit_report(self, days: int = 30) -> Dict:
        """Limit performans raporu"""
        
        cutoff_date = datetime.now() - timedelta(days=days)
        period_violations = [v for v in self.violations if v.timestamp > cutoff_date]
        
        # Seviyeye göre dağılım
        severity_distribution = {}
        for violation in period_violations:
            limit = self.risk_limits.get(violation.limit_id)
            if limit:
                severity = limit.severity
                severity_distribution[severity] = severity_distribution.get(severity, 0) + 1
        
        return {
            'period_days': days,
            'total_violations': len(period_violations),
            'severity_distribution': severity_distribution,
            'limit_effectiveness': self.limit_effectiveness,
            'most_violated_limits': self._get_most_violated_limits(period_violations),
            'recommendations': self._generate_limit_recommendations(period_violations)
        }
    
    def _get_most_violated_limits(self, violations: List[LimitViolation]) -> List[Dict]:
        """En çok ihlal edilen limitler"""
        
        limit_violations = {}
        
        for violation in violations:
            limit_id = violation.limit_id
            limit_violations[limit_id] = limit_violations.get(limit_id, 0) + 1
        
        # En çok ihlal edilen 5 limiti sırala
        most_violated = sorted(limit_violations.items(), key=lambda x: x[1], reverse=True)[:5]
        
        return [
            {
                'limit_id': limit_id,
                'violation_count': count,
                'description': self.risk_limits[limit_id].description if limit_id in self.risk_limits else "Unknown"
            }
            for limit_id, count in most_violated
        ]
    
    def _generate_limit_recommendations(self, violations: List[LimitViolation]) -> List[str]:
        """Limit iyileştirme önerileri"""
        
        recommendations = []
        
        if len(violations) > 10:
            recommendations.append("Yüksek ihlal oranı - limit seviyelerini gözden geçirin")
        
        if self.limit_effectiveness < 0.7:
            recommendations.append("Düşük limit etkinliği - limit çeşitliliğini artırın")
        
        # En çok ihlal edilen limit tipine göre öneri
        hard_violations = sum(1 for v in violations if self.risk_limits.get(v.limit_id, {}).limit_type == "hard")
        soft_violations = sum(1 for v in violations if self.risk_limits.get(v.limit_id, {}).limit_type == "soft")
        
        if hard_violations > soft_violations:
            recommendations.append("Hard limit ihlalleri yüksek - soft limitler eklemeyi düşünün")
        elif soft_violations > hard_violations:
            recommendations.append("Soft limit ihlalleri yüksek - limit değerlerini ayarlayın")
        
        return recommendations