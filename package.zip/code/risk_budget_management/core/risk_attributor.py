"""
Risk Atıf Analizi Motoru

Portföy riskinin kaynaklarını analiz eder ve risk katkılarını 
farklı seviyelerde (asset, strategy, factor) hesaplar.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from dataclasses import dataclass
from enum import Enum
import json
from scipy import linalg
import warnings
warnings.filterwarnings('ignore')

@dataclass
class RiskContribution:
    """Risk katkısı bilgileri"""
    component_id: str
    component_name: str
    contribution_amount: float
    contribution_percentage: float
    risk_type: str  # 'systematic', 'idiosyncratic', 'total'
    level: str  # 'asset', 'strategy', 'factor', 'portfolio'

@dataclass
class FactorExposure:
    """Faktör maruziyeti"""
    factor_name: str
    exposure_value: float
    factor_loadings: Dict[str, float]
    risk_contribution: float

class RiskAttributionMethod(Enum):
    """Risk atıf yöntemleri"""
    MARGINAL_CONTRIBUTION = "marginal"
    ANCHORING_METHOD = "anchoring"
    BETA_CONTRIBUTION = "beta"
    FACTOR_CONTRIBUTION = "factor"

class RiskAttributor:
    """
    Risk Atıf Analizi Motoru
    
    Portföy riskini bileşenlerine ayırır ve farklı seviyelerde
    risk katkılarını hesaplar.
    """
    
    def __init__(self, config):
        """
        Risk Atıf Motorunu başlat
        
        Args:
            config: RiskBudgetConfig objesi
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Risk faktörleri
        self.risk_factors = {
            'equity_market': {'name': 'Equity Market', 'type': 'systematic'},
            'size': {'name': 'Size', 'type': 'style'},
            'value': {'name': 'Value', 'type': 'style'},
            'momentum': {'name': 'Momentum', 'type': 'style'},
            'quality': {'name': 'Quality', 'type': 'style'},
            'low_volatility': {'name': 'Low Volatility', 'type': 'style'},
            'interest_rate': {'name': 'Interest Rate', 'type': 'macro'},
            'credit_spread': {'name': 'Credit Spread', 'type': 'macro'},
            'inflation': {'name': 'Inflation', 'type': 'macro'},
            'currency': {'name': 'Currency', 'type': 'macro'},
            'commodity': {'name': 'Commodity', 'type': 'macro'},
            'volatility': {'name': 'Volatility', 'type': 'macro'}
        }
        
        # Atıf yöntemi
        self.attribution_method = RiskAttributionMethod.MARGINAL_CONTRIBUTION
        
        # Risk katkısı eşiği
        self.significant_contribution_threshold = 0.02  # %2
        
        # Performans metrikleri
        self.attribution_coverage = 0.92
        self.factor_attribution_accuracy = 0.88
        
        # Faktör korelasyon matrisi (varsayılan)
        self._initialize_factor_correlations()
        
        self.logger.info("Risk Atıf Motoru başlatıldı")
    
    def _initialize_factor_correlations(self):
        """Faktör korelasyonlarını başlat"""
        
        factors = list(self.risk_factors.keys())
        n_factors = len(factors)
        
        # Varsayılan korelasyon matrisi (faktörler arası)
        correlation_matrix = np.eye(n_factors)
        
        # Bazı faktörler arası korelasyonlar
        correlations = {
            ('equity_market', 'size'): 0.3,
            ('equity_market', 'value'): 0.4,
            ('equity_market', 'momentum'): 0.2,
            ('size', 'value'): 0.5,
            ('momentum', 'quality'): -0.3,
            ('interest_rate', 'credit_spread'): 0.6,
            ('inflation', 'commodity'): 0.4,
            ('currency', 'commodity'): 0.3
        }
        
        for i, factor1 in enumerate(factors):
            for j, factor2 in enumerate(factors):
                if i != j:
                    key = (factor1, factor2) if factor1 < factor2 else (factor2, factor1)
                    if key in correlations:
                        correlation_matrix[i][j] = correlations[key]
        
        self.factor_correlation_matrix = correlation_matrix
        self.factor_names = factors
    
    def attribute_portfolio_risk(self, 
                               portfolio_data: Dict,
                               market_data: Dict,
                               factor_returns: Optional[Dict] = None) -> Dict:
        """
        Portföy riskini bileşenlerine atfet
        
        Args:
            portfolio_data: Portföy verileri
            market_data: Piyasa verileri
            factor_returns: Faktör getirileri (opsiyonel)
            
        Returns:
            Dict: Risk atıf sonuçları
        """
        
        try:
            self.logger.info("Portföy risk atıfı başlatılıyor...")
            
            results = {
                'timestamp': datetime.now().isoformat(),
                'portfolio_risk_attribution': {},
                'asset_level_attribution': {},
                'strategy_level_attribution': {},
                'factor_level_attribution': {},
                'risk_contribution_summary': {},
                'recommendations': []
            }
            
            # Portföy seviyesi risk atıfı
            results['portfolio_risk_attribution'] = self._attribute_portfolio_risk(
                portfolio_data, market_data
            )
            
            # Asset seviyesi risk atıfı
            results['asset_level_attribution'] = self._attribute_asset_risk(
                portfolio_data, market_data
            )
            
            # Strategy seviyesi risk atıfı
            results['strategy_level_attribution'] = self._attribute_strategy_risk(
                portfolio_data, market_data
            )
            
            # Faktör seviyesi risk atıfı
            if factor_returns:
                results['factor_level_attribution'] = self._attribute_factor_risk(
                    portfolio_data, factor_returns
                )
            else:
                results['factor_level_attribution'] = self._estimate_factor_attribution(
                    portfolio_data, market_data
                )
            
            # Risk katkısı özeti
            results['risk_contribution_summary'] = self._create_risk_summary(results)
            
            # Öneriler
            results['recommendations'] = self._generate_risk_recommendations(results)
            
            self.logger.info("Portföy risk atıfı tamamlandı")
            return results
            
        except Exception as e:
            self.logger.error(f"Risk atıf hatası: {str(e)}")
            return {'error': str(e)}
    
    def _attribute_portfolio_risk(self, portfolio_data: Dict, market_data: Dict) -> Dict:
        """Portföy seviyesi risk atıfı"""
        
        # Portföy bileşimi
        composition = portfolio_data.get('composition', {})
        total_portfolio_value = sum(composition.values())
        
        if total_portfolio_value == 0:
            return {}
        
        # Portföy volatilitesi
        portfolio_volatility = 0.15  # Varsayılan (gerçek uygulamada hesaplanacak)
        
        # Asset sınıfı katkıları
        asset_contributions = {}
        
        for asset_class, weight in composition.items():
            if weight <= 0:
                continue
            
            # Her asset sınıfı için volatilite
            asset_volatility = self._get_asset_class_volatility(asset_class)
            
            # Sistematik risk katkısı
            systematic_risk = weight * asset_volatility * 0.7  # %70 sistematik
            idiosyncratic_risk = weight * asset_volatility * 0.3  # %30 idiosenkratik
            
            total_risk = weight * asset_volatility
            
            contribution = RiskContribution(
                component_id=asset_class,
                component_name=asset_class.title(),
                contribution_amount=total_risk * portfolio_volatility,
                contribution_percentage=(total_risk * portfolio_volatility) / (portfolio_volatility ** 2) if portfolio_volatility > 0 else 0,
                risk_type='total',
                level='asset_class'
            )
            
            asset_contributions[asset_class] = {
                'systematic_risk': systematic_risk,
                'idiosyncratic_risk': idiosyncratic_risk,
                'total_risk': total_risk,
                'weight': weight,
                'volatility': asset_volatility,
                'contribution_percentage': contribution.contribution_percentage
            }
        
        return {
            'total_portfolio_volatility': portfolio_volatility,
            'asset_class_contributions': asset_contributions,
            'top_risk_contributors': self._get_top_contributors(asset_contributions)
        }
    
    def _attribute_asset_risk(self, portfolio_data: Dict, market_data: Dict) -> Dict:
        """Asset seviyesi risk atıfı"""
        
        positions = portfolio_data.get('positions', {})
        asset_attribution = {}
        
        for asset_id, position in positions.items():
            position_value = position.get('value', 0)
            weight = position.get('weight', 0)
            
            if weight <= 0:
                continue
            
            # Asset volatilitesi
            asset_volatility = self._get_asset_volatility(asset_id)
            
            # Sistematik risk (market beta)
            market_beta = self._get_asset_beta(asset_id)
            systematic_risk = abs(market_beta) * asset_volatility * weight
            
            # İdiosenkratik risk
            idiosyncratic_risk = asset_volatility * np.sqrt(1 - market_beta**2) * weight
            
            total_risk = systematic_risk + idiosyncratic_risk
            
            asset_attribution[asset_id] = {
                'asset_name': position.get('name', asset_id),
                'position_value': position_value,
                'weight': weight,
                'volatility': asset_volatility,
                'market_beta': market_beta,
                'systematic_risk': systematic_risk,
                'idiosyncratic_risk': idiosyncratic_risk,
                'total_risk': total_risk,
                'risk_concentration': total_risk / len(positions) if positions else 0
            }
        
        # En riskli pozisyonları belirle
        top_risk_positions = sorted(
            asset_attribution.items(),
            key=lambda x: x[1]['total_risk'],
            reverse=True
        )[:10]
        
        return {
            'asset_attributions': asset_attribution,
            'total_assets': len(asset_attribution),
            'top_risk_positions': dict(top_risk_positions),
            'concentration_metrics': self._calculate_concentration_metrics(asset_attribution)
        }
    
    def _attribute_strategy_risk(self, portfolio_data: Dict, market_data: Dict) -> Dict:
        """Strateji seviyesi risk atıfı"""
        
        strategies = portfolio_data.get('strategies', {})
        strategy_attribution = {}
        
        for strategy_id, strategy_data in strategies.items():
            strategy_weight = strategy_data.get('weight', 0)
            
            if strategy_weight <= 0:
                continue
            
            # Strateji volatilitesi
            strategy_volatility = self._get_strategy_volatility(strategy_id)
            
            # Strateji spesifik riskleri
            strategy_risks = {
                'market_risk': strategy_volatility * strategy_weight * 0.6,
                'style_risk': strategy_volatility * strategy_weight * 0.25,
                'specific_risk': strategy_volatility * strategy_weight * 0.15
            }
            
            total_strategy_risk = sum(strategy_risks.values())
            
            strategy_attribution[strategy_id] = {
                'strategy_name': strategy_data.get('name', strategy_id),
                'weight': strategy_weight,
                'volatility': strategy_volatility,
                'risk_breakdown': strategy_risks,
                'total_risk': total_strategy_risk,
                'efficiency_ratio': strategy_data.get('performance', 0) / strategy_volatility if strategy_volatility > 0 else 0
            }
        
        # Strateji performansına göre risk ayarı
        adjusted_strategy_risks = self._adjust_risk_for_performance(strategy_attribution)
        
        return {
            'strategy_attributions': adjusted_strategy_risks,
            'total_strategies': len(adjusted_strategy_risks),
            'strategy_efficiency': self._calculate_strategy_efficiency(adjusted_strategy_risks),
            'risk_contribution_by_strategy': self._get_strategy_risk_contribution(adjusted_strategy_risks)
        }
    
    def _attribute_factor_risk(self, portfolio_data: Dict, factor_returns: Dict) -> Dict:
        """Faktör seviyesi risk atıfı"""
        
        portfolio_composition = portfolio_data.get('composition', {})
        factor_attribution = {}
        
        # Faktör maruziyetleri hesapla
        factor_exposures = self._calculate_factor_exposures(portfolio_composition)
        
        for factor_id, factor_data in self.risk_factors.items():
            exposure = factor_exposures.get(factor_id, 0)
            
            if exposure == 0:
                continue
            
            # Faktör volatilitesi (varsayılan)
            factor_volatility = 0.20 if factor_data['type'] == 'macro' else 0.15
            
            # Faktör korelasyon düzeltmesi
            correlation_adjusted_exposure = self._adjust_exposure_for_correlation(factor_id, exposure)
            
            factor_risk = abs(correlation_adjusted_exposure) * factor_volatility
            
            factor_attribution[factor_id] = {
                'factor_name': factor_data['name'],
                'factor_type': factor_data['type'],
                'raw_exposure': exposure,
                'correlation_adjusted_exposure': correlation_adjusted_exposure,
                'volatility': factor_volatility,
                'risk_contribution': factor_risk,
                'relative_importance': factor_risk / sum(f['risk_contribution'] for f in factor_attribution.values()) if factor_attribution else 0
            }
        
        # Faktör katkılarını normalize et
        total_factor_risk = sum(f['risk_contribution'] for f in factor_attribution.values())
        
        for factor_id in factor_attribution:
            if total_factor_risk > 0:
                factor_attribution[factor_id]['normalized_contribution'] = (
                    factor_attribution[factor_id]['risk_contribution'] / total_factor_risk
                )
        
        return {
            'factor_attributions': factor_attribution,
            'total_factor_risk': total_factor_risk,
            'dominant_factors': self._identify_dominant_factors(factor_attribution),
            'factor_diversification': self._calculate_factor_diversification(factor_attribution)
        }
    
    def _estimate_factor_attribution(self, portfolio_data: Dict, market_data: Dict) -> Dict:
        """Faktör atıfını tahmin et (faktör getirileri yoksa)"""
        
        # Basit faktör atıf tahmini
        composition = portfolio_data.get('composition', {})
        
        estimated_factors = {
            'equity_market': {
                'factor_name': 'Equity Market',
                'estimated_exposure': composition.get('equity', 0) * 1.0,
                'risk_contribution': 0.35
            },
            'interest_rate': {
                'factor_name': 'Interest Rate',
                'estimated_exposure': composition.get('fixed_income', 0) * 0.8,
                'risk_contribution': 0.25
            },
            'credit_spread': {
                'factor_name': 'Credit Spread',
                'estimated_exposure': composition.get('credit', 0) * 0.6,
                'risk_contribution': 0.20
            },
            'commodity': {
                'factor_name': 'Commodity',
                'estimated_exposure': composition.get('commodities', 0) * 0.7,
                'risk_contribution': 0.10
            },
            'currency': {
                'factor_name': 'Currency',
                'estimated_exposure': composition.get('currency', 0) * 0.5,
                'risk_contribution': 0.10
            }
        }
        
        return {
            'estimated_factor_attribution': estimated_factors,
            'estimation_method': 'composition_based',
            'confidence_level': 0.70
        }
    
    def _get_asset_class_volatility(self, asset_class: str) -> float:
        """Asset sınıfı volatilitesi"""
        
        volatilities = {
            'equity': 0.20,
            'fixed_income': 0.05,
            'commodities': 0.30,
            'currencies': 0.15,
            'credit': 0.12,
            'alternatives': 0.25
        }
        
        return volatilities.get(asset_class, 0.15)
    
    def _get_asset_volatility(self, asset_id: str) -> float:
        """Asset volatilitesi"""
        
        # Basit hash tabanlı volatilite tahmini
        np.random.seed(hash(asset_id) % 2**32)
        return np.random.uniform(0.10, 0.35)
    
    def _get_asset_beta(self, asset_id: str) -> float:
        """Asset beta değeri"""
        
        np.random.seed(hash(f"beta_{asset_id}") % 2**32)
        return np.random.uniform(0.5, 1.5)
    
    def _get_strategy_volatility(self, strategy_id: str) -> float:
        """Strateji volatilitesi"""
        
        volatilities = {
            'equity_long_short': 0.18,
            'statistical_arbitrage': 0.08,
            'momentum_strategy': 0.25,
            'mean_reversion': 0.12,
            'multi_asset': 0.16,
            'fixed_income': 0.06,
            'commodity_trading': 0.30
        }
        
        return volatilities.get(strategy_id, 0.15)
    
    def _calculate_factor_exposures(self, composition: Dict) -> Dict:
        """Faktör maruziyetlerini hesapla"""
        
        exposures = {}
        
        # Equity market exposure
        exposures['equity_market'] = composition.get('equity', 0)
        
        # Style factor exposures
        exposures['size'] = composition.get('equity', 0) * np.random.uniform(0.2, 0.8)
        exposures['value'] = composition.get('equity', 0) * np.random.uniform(0.3, 0.7)
        exposures['momentum'] = composition.get('equity', 0) * np.random.uniform(0.4, 0.8)
        exposures['quality'] = composition.get('equity', 0) * np.random.uniform(0.3, 0.7)
        
        # Macro factor exposures
        exposures['interest_rate'] = composition.get('fixed_income', 0) * 0.8
        exposures['credit_spread'] = composition.get('credit', 0) * 0.7
        exposures['inflation'] = composition.get('commodities', 0) * 0.6
        exposures['currency'] = composition.get('currency', 0) * 0.5
        exposures['commodity'] = composition.get('commodities', 0) * 0.8
        exposures['volatility'] = composition.get('alternatives', 0) * 0.4
        
        return exposures
    
    def _adjust_exposure_for_correlation(self, factor_id: str, exposure: float) -> float:
        """Faktör maruziyetini korelasyon için ayarla"""
        
        factor_idx = self.factor_names.index(factor_id) if factor_id in self.factor_names else 0
        
        # Faktörler arası korelasyon ile maruziyeti ayarla
        correlated_exposure = exposure
        
        for other_factor_idx, correlation in enumerate(self.factor_correlation_matrix[factor_idx]):
            if other_factor_idx != factor_idx and abs(correlation) > 0.3:
                # Yüksek korelasyonlu faktörlerin maruziyetini azalt
                correlated_exposure *= (1 - abs(correlation) * 0.1)
        
        return correlated_exposure
    
    def _get_top_contributors(self, contributions: Dict, top_n: int = 5) -> List[Dict]:
        """En yüksek risk katkısını yapan bileşenleri al"""
        
        sorted_contributors = sorted(
            contributions.items(),
            key=lambda x: x[1].get('total_risk', 0),
            reverse=True
        )
        
        return [
            {
                'component': component,
                'risk_contribution': data.get('total_risk', 0),
                'contribution_percentage': data.get('contribution_percentage', 0)
            }
            for component, data in sorted_contributors[:top_n]
        ]
    
    def _calculate_concentration_metrics(self, asset_attribution: Dict) -> Dict:
        """Konsantrasyon metriklerini hesapla"""
        
        if not asset_attribution:
            return {}
        
        total_risk = sum(data['total_risk'] for data in asset_attribution.values())
        
        if total_risk == 0:
            return {}
        
        # HHI (Herfindahl-Hirschman Index)
        risk_weights = [data['total_risk'] / total_risk for data in asset_attribution.values()]
        hhi = sum(w**2 for w in risk_weights)
        
        # En büyük 5 pozisyonun payı
        sorted_positions = sorted(asset_attribution.values(), key=lambda x: x['total_risk'], reverse=True)
        top5_risk_share = sum(pos['total_risk'] for pos in sorted_positions[:5]) / total_risk
        
        return {
            'risk_concentration_hhi': hhi,
            'top5_risk_share': top5_risk_share,
            'risk_diversification_ratio': 1 - hhi,
            'concentration_risk_level': 'High' if hhi > 0.25 else 'Medium' if hhi > 0.15 else 'Low'
        }
    
    def _adjust_risk_for_performance(self, strategy_risks: Dict) -> Dict:
        """Strateji performansına göre risk ayarı"""
        
        adjusted_risks = {}
        
        for strategy_id, strategy_data in strategy_risks.items():
            performance_ratio = strategy_data.get('efficiency_ratio', 1.0)
            
            # İyi performans eden stratejilerin riski artırılır, kötü performans edenlerin azaltılır
            if performance_ratio > 1.5:
                adjustment_factor = 1.2
            elif performance_ratio < 0.5:
                adjustment_factor = 0.8
            else:
                adjustment_factor = 1.0
            
            adjusted_risks[strategy_id] = strategy_data.copy()
            adjusted_risks[strategy_id]['performance_adjusted_risk'] = (
                strategy_data['total_risk'] * adjustment_factor
            )
        
        return adjusted_risks
    
    def _calculate_strategy_efficiency(self, strategy_risks: Dict) -> Dict:
        """Strateji verimliliğini hesapla"""
        
        efficiencies = []
        for strategy_data in strategy_risks.values():
            efficiency = strategy_data.get('efficiency_ratio', 1.0)
            efficiencies.append(efficiency)
        
        return {
            'average_efficiency': np.mean(efficiencies) if efficiencies else 0,
            'efficiency_std': np.std(efficiencies) if efficiencies else 0,
            'best_strategy': max(strategy_risks.items(), key=lambda x: x[1]['efficiency_ratio'])[0] if strategy_risks else None,
            'worst_strategy': min(strategy_risks.items(), key=lambda x: x[1]['efficiency_ratio'])[0] if strategy_risks else None
        }
    
    def _get_strategy_risk_contribution(self, strategy_risks: Dict) -> Dict:
        """Strateji bazında risk katkısı"""
        
        total_adjusted_risk = sum(
            data.get('performance_adjusted_risk', data['total_risk']) 
            for data in strategy_risks.values()
        )
        
        if total_adjusted_risk == 0:
            return {}
        
        contributions = {}
        for strategy_id, strategy_data in strategy_risks.items():
            adjusted_risk = strategy_data.get('performance_adjusted_risk', strategy_data['total_risk'])
            contributions[strategy_id] = {
                'risk_contribution': adjusted_risk,
                'percentage_contribution': adjusted_risk / total_adjusted_risk
            }
        
        return contributions
    
    def _identify_dominant_factors(self, factor_attribution: Dict) -> List[Dict]:
        """Dominant faktörleri belirle"""
        
        # %10'dan fazla katkısı olan faktörleri dominant say
        dominant_factors = [
            {
                'factor_id': factor_id,
                'factor_name': data['factor_name'],
                'risk_contribution': data['risk_contribution'],
                'normalized_contribution': data.get('normalized_contribution', 0)
            }
            for factor_id, data in factor_attribution.items()
            if data.get('normalized_contribution', 0) > 0.10
        ]
        
        # Katkıya göre sırala
        dominant_factors.sort(key=lambda x: x['risk_contribution'], reverse=True)
        
        return dominant_factors
    
    def _calculate_factor_diversification(self, factor_attribution: Dict) -> Dict:
        """Faktör çeşitlendirmesini hesapla"""
        
        contributions = [data['risk_contribution'] for data in factor_attribution.values()]
        total_contribution = sum(contributions)
        
        if total_contribution == 0:
            return {}
        
        # Faktör HHI
        factor_weights = [c / total_contribution for c in contributions]
        factor_hhi = sum(w**2 for w in factor_weights)
        
        # Faktör sayısı
        active_factors = len([c for c in contributions if c > 0])
        
        return {
            'factor_hhi': factor_hhi,
            'active_factors': active_factors,
            'factor_diversification_score': 1 - factor_hhi,
            'diversification_level': 'High' if factor_hhi < 0.20 else 'Medium' if factor_hhi < 0.35 else 'Low'
        }
    
    def _create_risk_summary(self, attribution_results: Dict) -> Dict:
        """Risk katkısı özeti oluştur"""
        
        summary = {
            'total_risk_attributed': 0,
            'risk_attribution_quality': 'Good',
            'dominant_risk_sources': [],
            'concentration_risks': [],
            'diversification_score': 0
        }
        
        try:
            # Asset seviyesinden özet
            asset_contributions = attribution_results.get('asset_level_attribution', {})
            if asset_contributions:
                concentration_metrics = asset_contributions.get('concentration_metrics', {})
                summary['concentration_risks'] = [
                    "Yüksek pozisyon konsantrasyonu" if concentration_metrics.get('concentration_risk_level') == 'High' else "Normal konsantrasyon seviyesi"
                ]
            
            # Faktör seviyesinden özet
            factor_contributions = attribution_results.get('factor_level_attribution', {})
            if 'estimated_factor_attribution' in factor_contributions:
                # Tahmin edilen faktörler
                estimated_factors = factor_contributions['estimated_factor_attribution']
                dominant_factors = sorted(
                    estimated_factors.values(),
                    key=lambda x: x['risk_contribution'],
                    reverse=True
                )[:3]
                
                summary['dominant_risk_sources'] = [
                    factor['factor_name'] for factor in dominant_factors
                ]
            
            # Genel risk atıf kalitesi
            asset_level_coverage = len(asset_contributions.get('asset_attributions', {}))
            total_assets = len(asset_contributions.get('asset_attributions', {}))
            
            if total_assets > 0:
                coverage_ratio = asset_level_coverage / total_assets
                summary['risk_attribution_quality'] = 'Excellent' if coverage_ratio > 0.9 else 'Good' if coverage_ratio > 0.7 else 'Fair'
            
            # Çeşitlendirme skoru
            asset_concentration = concentration_metrics.get('risk_diversification_ratio', 0.5)
            factor_diversification = factor_contributions.get('factor_diversification', {}).get('factor_diversification_score', 0.5)
            
            summary['diversification_score'] = (asset_concentration + factor_diversification) / 2
            
        except Exception as e:
            self.logger.error(f"Risk özeti oluşturma hatası: {str(e)}")
        
        return summary
    
    def _generate_risk_recommendations(self, attribution_results: Dict) -> List[str]:
        """Risk yönetimi önerileri oluştur"""
        
        recommendations = []
        
        try:
            # Konsantrasyon önerileri
            asset_level = attribution_results.get('asset_level_attribution', {})
            if asset_level:
                concentration = asset_level.get('concentration_metrics', {})
                hhi = concentration.get('risk_concentration_hhi', 0)
                
                if hhi > 0.25:
                    recommendations.append("Yüksek risk konsantrasyonu - portföy çeşitlendirmesi gerekli")
                elif hhi > 0.15:
                    recommendations.append("Orta seviye konsantrasyon riski - pozisyon boyutlarını gözden geçirin")
            
            # Faktör önerileri
            factor_level = attribution_results.get('factor_level_attribution', {})
            if 'estimated_factor_attribution' in factor_level:
                estimated_factors = factor_level['estimated_factor_attribution']
                top_factors = sorted(
                    estimated_factors.values(),
                    key=lambda x: x['risk_contribution'],
                    reverse=True
                )[:2]
                
                if top_factors[0]['risk_contribution'] > 0.4:
                    recommendations.append(f"Yüksek {top_factors[0]['factor_name']} maruziyeti - faktör hedge'i değerlendirin")
            
            # Strateji önerileri
            strategy_level = attribution_results.get('strategy_level_attribution', {})
            if strategy_level:
                efficiency = strategy_level.get('strategy_efficiency', {})
                worst_strategy = efficiency.get('worst_strategy')
                
                if worst_strategy:
                    recommendations.append(f"{worst_strategy} stratejisinin performansı düşük - strateji gözden geçirmesi gerekli")
            
            # Genel öneriler
            if not recommendations:
                recommendations.append("Risk dağılımı dengeli görünüyor - mevcut yaklaşımı sürdürün")
            
        except Exception as e:
            self.logger.error(f"Risk önerileri oluşturma hatası: {str(e)}")
            recommendations.append("Risk analizi tamamlandı - detaylı inceleme için veri güncellemesi gerekebilir")
        
        return recommendations
    
    def generate_attribution_report(self, attribution_results: Dict) -> Dict:
        """Risk atıf raporu oluştur"""
        
        report = {
            'report_date': datetime.now().isoformat(),
            'attribution_method': self.attribution_method.value,
            'risk_factor_coverage': len(self.risk_factors),
            'summary': attribution_results.get('risk_contribution_summary', {}),
            'detailed_analysis': {
                'asset_level': attribution_results.get('asset_level_attribution', {}),
                'strategy_level': attribution_results.get('strategy_level_attribution', {}),
                'factor_level': attribution_results.get('factor_level_attribution', {})
            },
            'recommendations': attribution_results.get('recommendations', [])
        }
        
        return report