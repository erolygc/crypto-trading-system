"""
Risk Bütçesi Dağıtım Motoru

Enterprise seviyesinde risk bütçesi dağıtımı ve tahsisi yapar.
Portföy, strateji ve pozisyon seviyelerinde risk bütçelerini optimize eder.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from dataclasses import dataclass
from scipy.optimize import minimize
import warnings
warnings.filterwarnings('ignore')

@dataclass
class RiskBudgetAllocation:
    """Risk bütçesi dağıtım bilgileri"""
    portfolio_name: str
    strategy_name: str
    allocation_amount: float
    weight: float
    risk_capacity: float
    current_exposure: float
    efficiency_score: float
    last_updated: datetime

class RiskBudgetAllocator:
    """
    Risk Bütçesi Dağıtım Motoru
    
    Enterprise seviyesinde risk bütçesi dağıtımını yönetir ve 
    farklı seviyelerdeki risk bütçelerini optimize eder.
    """
    
    def __init__(self, config):
        """
        Risk Bütçesi Dağıtıcısını başlat
        
        Args:
            config: RiskBudgetConfig objesi
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Risk bütçesi parametreleri
        self.risk_free_rate = 0.02
        self.minimum_allocation = 0.01  # Minimum %1 allocation
        self.maximum_allocation = 0.30  # Maksimum %30 allocation
        
        # Performans metrikleri
        self.allocations_history = []
        self.rebalancing_triggers = []
        
        # Risk faktörleri
        self.risk_factors = {
            'volatility': 0.3,
            'liquidity': 0.2,
            'correlation': 0.2,
            'concentration': 0.15,
            'momentum': 0.15
        }
        
        self.logger.info("Risk Bütçesi Dağıtıcısı başlatıldı")
    
    def initialize_allocations(self) -> Dict[str, RiskBudgetAllocation]:
        """
        Başlangıç risk bütçesi dağıtımlarını oluştur
        
        Returns:
            Dict: Portfolio bazlı risk bütçesi dağıtımları
        """
        try:
            self.logger.info("Risk bütçesi dağıtımları başlatılıyor...")
            
            # Temel portföy stratejileri
            base_strategies = {
                'Equity_Long_Short': {'base_weight': 0.25, 'risk_premium': 1.2},
                'Statistical_Arbitrage': {'base_weight': 0.20, 'risk_premium': 0.8},
                'Momentum_Strategy': {'base_weight': 0.15, 'risk_premium': 1.0},
                'Mean_Reversion': {'base_weight': 0.15, 'risk_premium': 0.9},
                'Multi_Asset': {'base_weight': 0.10, 'risk_premium': 1.1},
                'Fixed_Income': {'base_weight': 0.08, 'risk_premium': 0.6},
                'Commodity_Trading': {'base_weight': 0.07, 'risk_premium': 1.3}
            }
            
            # Enterprise risk bütçesi dağıtımı
            total_budget = self.config.total_risk_budget
            allocations = {}
            
            for strategy_name, params in base_strategies.items():
                # Temel dağıtım hesapla
                base_allocation = total_budget * params['base_weight']
                
                # Risk premium ile ayarla
                risk_adjusted_allocation = base_allocation * params['risk_premium']
                
                # Risk kapasitesini hesapla
                risk_capacity = self._calculate_risk_capacity(strategy_name)
                
                allocation = RiskBudgetAllocation(
                    portfolio_name="Enterprise",
                    strategy_name=strategy_name,
                    allocation_amount=risk_adjusted_allocation,
                    weight=params['base_weight'],
                    risk_capacity=risk_capacity,
                    current_exposure=0.0,
                    efficiency_score=0.0,
                    last_updated=datetime.now()
                )
                
                allocations[strategy_name] = allocation
            
            # Normalleştir (toplam dağıtım %100 olmalı)
            total_allocated = sum(a.allocation_amount for a in allocations.values())
            normalization_factor = total_budget / total_allocated
            
            for allocation in allocations.values():
                allocation.allocation_amount *= normalization_factor
                allocation.weight *= normalization_factor
            
            self.logger.info(f"{len(allocations)} strateji için risk bütçesi dağıtımı tamamlandı")
            return allocations
            
        except Exception as e:
            self.logger.error(f"Risk bütçesi başlatma hatası: {str(e)}")
            return {}
    
    def optimize_risk_allocation(self, 
                               current_allocations: Dict[str, RiskBudgetAllocation],
                               target_portfolio_metrics: Dict,
                               constraints: Optional[Dict] = None) -> Dict[str, RiskBudgetAllocation]:
        """
        Risk bütçesi dağıtımını optimize et
        
        Args:
            current_allocations: Mevcut dağıtımlar
            target_portfolio_metrics: Hedef portföy metrikleri
            constraints: Kısıtlama parametreleri
            
        Returns:
            Dict: Optimize edilmiş risk bütçesi dağıtımları
        """
        try:
            self.logger.info("Risk bütçesi optimizasyonu başlatılıyor...")
            
            # Optimizasyon problemi kurulumu
            strategies = list(current_allocations.keys())
            n_strategies = len(strategies)
            
            # Hedef fonksiyon: Risk-ayarlı getiri maksimizasyonu
            def objective_function(weights):
                """Optimizasyon hedef fonksiyonu"""
                
                portfolio_return = 0
                portfolio_risk = 0
                
                for i, strategy in enumerate(strategies):
                    strategy_data = current_allocations[strategy]
                    
                    # Strateji beklenen getirisi
                    expected_return = self._get_strategy_expected_return(strategy)
                    portfolio_return += weights[i] * expected_return
                    
                    # Strateji riski (volatilite)
                    strategy_vol = self._get_strategy_volatility(strategy)
                    portfolio_risk += (weights[i] * strategy_vol) ** 2
                
                # Korelasyon düzeltmesi
                correlation_matrix = self._get_correlation_matrix(strategies)
                for i in range(n_strategies):
                    for j in range(i+1, n_strategies):
                        portfolio_risk += 2 * weights[i] * weights[j] * \
                                        correlation_matrix[i][j] * \
                                        self._get_strategy_volatility(strategies[i]) * \
                                        self._get_strategy_volatility(strategies[j])
                
                portfolio_risk = np.sqrt(portfolio_risk)
                
                # Sharpe ratio maksimize et
                if portfolio_risk > 0:
                    sharpe_ratio = (portfolio_return - self.risk_free_rate) / portfolio_risk
                    return -sharpe_ratio  # Minimize için negatif al
                else:
                    return 0
            
            # Kısıtlama fonksiyonları
            def constraint_weights_sum_to_one(weights):
                return np.sum(weights) - 1.0
            
            def constraint_var_limit(weights):
                """VaR kısıtlaması"""
                portfolio_var = self._calculate_portfolio_var(weights, strategies)
                return self.config.var_limit - portfolio_var
            
            def constraint_cvar_limit(weights):
                """CVaR kısıtlaması"""
                portfolio_cvar = self._calculate_portfolio_cvar(weights, strategies)
                return self.config.cvar_limit - portfolio_cvar
            
            # Başlangıç ağırlıkları
            initial_weights = np.array([
                current_allocations[s].weight for s in strategies
            ])
            
            # Kısıtlama tanımları
            constraints_list = [
                {'type': 'eq', 'fun': constraint_weights_sum_to_one},
                {'type': 'ineq', 'fun': constraint_var_limit},
                {'type': 'ineq', 'fun': constraint_cvar_limit}
            ]
            
            # Değişken sınırları
            bounds = []
            for _ in strategies:
                bounds.append((self.minimum_allocation, self.maximum_allocation))
            
            # Optimizasyon
            result = minimize(
                objective_function,
                initial_weights,
                method='SLSQP',
                bounds=bounds,
                constraints=constraints_list,
                options={'maxiter': 1000, 'ftol': 1e-9}
            )
            
            if result.success:
                optimal_weights = result.x
                
                # Optimize edilmiş dağıtımları oluştur
                optimized_allocations = {}
                total_budget = self.config.total_risk_budget
                
                for i, strategy in enumerate(strategies):
                    current_allocation = current_allocations[strategy]
                    
                    optimized_allocation = RiskBudgetAllocation(
                        portfolio_name=current_allocation.portfolio_name,
                        strategy_name=strategy,
                        allocation_amount=optimal_weights[i] * total_budget,
                        weight=optimal_weights[i],
                        risk_capacity=current_allocation.risk_capacity,
                        current_exposure=current_allocation.current_exposure,
                        efficiency_score=self._calculate_efficiency_score(strategy, optimal_weights[i]),
                        last_updated=datetime.now()
                    )
                    
                    optimized_allocations[strategy] = optimized_allocation
                
                self.logger.info(f"Risk bütçesi optimizasyonu başarılı - {len(optimized_allocations)} strateji")
                return optimized_allocations
                
            else:
                self.logger.warning(f"Optimizasyon başarısız: {result.message}")
                return current_allocations
                
        except Exception as e:
            self.logger.error(f"Risk bütçesi optimizasyon hatası: {str(e)}")
            return current_allocations
    
    def update_allocations(self, 
                          risk_metrics: 'RiskMetrics',
                          limit_status: Dict) -> Dict[str, RiskBudgetAllocation]:
        """
        Risk metriklerine göre dağıtımları güncelle
        
        Args:
            risk_metrics: Mevcut risk metrikleri
            limit_status: Limit durumu
            
        Returns:
            Dict: Güncellenmiş risk bütçesi dağıtımları
        """
        try:
            # Limit aşım kontrolü
            var_breach = risk_metrics.portfolio_var > self.config.var_limit
            cvar_breach = risk_metrics.portfolio_cvar > self.config.cvar_limit
            
            if var_breach or cvar_breach:
                self.logger.warning("Limit aşımı tespit edildi - dağıtım güncelleniyor...")
                return self._adjust_allocations_for_limit_breach(risk_metrics, limit_status)
            
            # Performance tabanlı güncelleme
            return self._adjust_allocations_for_performance(risk_metrics)
            
        except Exception as e:
            self.logger.error(f"Dağıtım güncelleme hatası: {str(e)}")
            return {}
    
    def _adjust_allocations_for_limit_breach(self, 
                                           risk_metrics: 'RiskMetrics',
                                           limit_status: Dict) -> Dict[str, RiskBudgetAllocation]:
        """Limit aşımı durumunda dağıtımları ayarla"""
        
        # Yüksek riskli stratejilerin ağırlıklarını azalt
        high_risk_strategies = [
            'Equity_Long_Short', 'Commodity_Trading', 'Momentum_Strategy'
        ]
        
        # Düşük riskli stratejilerin ağırlıklarını artır
        low_risk_strategies = ['Fixed_Income', 'Mean_Reversion']
        
        adjustment_factor = 0.8  # %20 azaltım
        
        # Bu metot gerçek uygulamada mevcut dağıtımları güncelleyecek
        # Basitleştirilmiş uygulama
        updated_allocations = {}
        
        for strategy in high_risk_strategies + low_risk_strategies:
            # Dummy allocation - gerçek uygulamada mevcut verilerden güncelle
            allocation = RiskBudgetAllocation(
                portfolio_name="Enterprise",
                strategy_name=strategy,
                allocation_amount=1000000.0 * adjustment_factor if strategy in high_risk_strategies else 1000000.0 * 1.2,
                weight=0.1,
                risk_capacity=1000000.0,
                current_exposure=0.0,
                efficiency_score=0.8,
                last_updated=datetime.now()
            )
            updated_allocations[strategy] = allocation
        
        return updated_allocations
    
    def _adjust_allocations_for_performance(self, risk_metrics: 'RiskMetrics') -> Dict[str, RiskBudgetAllocation]:
        """Performansa göre dağıtımları ayarla"""
        
        # Sharpe ratio'ya göre ağırlık ayarlaması
        sharpe_multiplier = min(risk_metrics.sharpe_ratio / 2.0, 1.5)  # Max 1.5x
        
        updated_allocations = {}
        
        # Basit performans tabanlı güncelleme
        base_strategies = ['Equity_Long_Short', 'Statistical_Arbitrage', 'Momentum_Strategy']
        
        for strategy in base_strategies:
            allocation = RiskBudgetAllocation(
                portfolio_name="Enterprise",
                strategy_name=strategy,
                allocation_amount=1000000.0 * sharpe_multiplier,
                weight=0.1,
                risk_capacity=1000000.0,
                current_exposure=0.0,
                efficiency_score=0.9,
                last_updated=datetime.now()
            )
            updated_allocations[strategy] = allocation
        
        return updated_allocations
    
    def rebalance_allocations(self) -> Dict[str, RiskBudgetAllocation]:
        """
        Risk bütçesi dağıtımlarını yeniden dengele
        
        Returns:
            Dict: Yeniden dengelenmiş dağıtımlar
        """
        try:
            self.logger.info("Risk bütçesi yeniden dengeleme başlatılıyor...")
            
            # Yeniden dengeleme kriterlerini kontrol et
            should_rebalance = self._should_rebalance()
            
            if should_rebalance:
                # Yeniden dengeleme tetiklenir
                self.rebalancing_triggers.append({
                    'timestamp': datetime.now(),
                    'trigger_type': 'scheduled',
                    'reason': 'Periodic rebalancing'
                })
                
                # Dengeli dağıtım hesapla
                balanced_allocations = self._calculate_balanced_allocation()
                
                self.logger.info("Risk bütçesi yeniden dengeleme tamamlandı")
                return balanced_allocations
            else:
                self.logger.info("Yeniden dengeleme gerekli değil")
                return {}  # Mevcut dağıtımları koru
                
        except Exception as e:
            self.logger.error(f"Yeniden dengeleme hatası: {str(e)}")
            return {}
    
    def _should_rebalance(self) -> bool:
        """Yeniden dengeleme gerekip gerekmediğini kontrol et"""
        
        # Son yeniden dengeleme zamanını kontrol et
        if not self.rebalancing_triggers:
            return True
        
        last_rebalance = self.rebalancing_triggers[-1]['timestamp']
        days_since_rebalance = (datetime.now() - last_rebalance).days
        
        # Frekansa göre kontrol
        if self.config.rebalance_frequency == 'daily' and days_since_rebalance >= 1:
            return True
        elif self.config.rebalance_frequency == 'weekly' and days_since_rebalance >= 7:
            return True
        elif self.config.rebalance_frequency == 'monthly' and days_since_rebalance >= 30:
            return True
        
        return False
    
    def _calculate_balanced_allocation(self) -> Dict[str, RiskBudgetAllocation]:
        """Dengeli risk bütçesi dağıtımı hesapla"""
        
        # Temel dengeli dağıtım
        balanced_strategies = {
            'Conservative_Equity': {'weight': 0.15, 'risk_level': 0.6},
            'Alpha_Strategies': {'weight': 0.25, 'risk_level': 0.8},
            'Market_Neutral': {'weight': 0.20, 'risk_level': 0.4},
            'Global_Macro': {'weight': 0.15, 'risk_level': 0.7},
            'Credit_Strategies': {'weight': 0.10, 'risk_level': 0.5},
            'Alternative_Risk': {'weight': 0.15, 'risk_level': 0.9}
        }
        
        total_budget = self.config.total_risk_budget
        balanced_allocations = {}
        
        for strategy_name, params in balanced_strategies.items():
            allocation = RiskBudgetAllocation(
                portfolio_name="Enterprise",
                strategy_name=strategy_name,
                allocation_amount=total_budget * params['weight'],
                weight=params['weight'],
                risk_capacity=total_budget * params['weight'] * params['risk_level'],
                current_exposure=0.0,
                efficiency_score=0.8,
                last_updated=datetime.now()
            )
            balanced_allocations[strategy_name] = allocation
        
        return balanced_allocations
    
    def _calculate_risk_capacity(self, strategy_name: str) -> float:
        """Strateji için risk kapasitesi hesapla"""
        
        # Strateji bazlı risk kapasitesi faktörleri
        risk_capacity_factors = {
            'Equity_Long_Short': 0.8,
            'Statistical_Arbitrage': 0.6,
            'Momentum_Strategy': 0.9,
            'Mean_Reversion': 0.7,
            'Multi_Asset': 0.75,
            'Fixed_Income': 0.4,
            'Commodity_Trading': 0.95
        }
        
        factor = risk_capacity_factors.get(strategy_name, 0.5)
        return self.config.total_risk_budget * factor
    
    def _get_strategy_expected_return(self, strategy_name: str) -> float:
        """Strateji beklenen getirisini al"""
        
        return_estimates = {
            'Equity_Long_Short': 0.12,
            'Statistical_Arbitrage': 0.08,
            'Momentum_Strategy': 0.15,
            'Mean_Reversion': 0.10,
            'Multi_Asset': 0.11,
            'Fixed_Income': 0.04,
            'Commodity_Trading': 0.18
        }
        
        return return_estimates.get(strategy_name, 0.10)
    
    def _get_strategy_volatility(self, strategy_name: str) -> float:
        """Strateji volatilitesini al"""
        
        volatility_estimates = {
            'Equity_Long_Short': 0.20,
            'Statistical_Arbitrage': 0.08,
            'Momentum_Strategy': 0.25,
            'Mean_Reversion': 0.12,
            'Multi_Asset': 0.18,
            'Fixed_Income': 0.05,
            'Commodity_Trading': 0.30
        }
        
        return volatility_estimates.get(strategy_name, 0.15)
    
    def _get_correlation_matrix(self, strategies: List[str]) -> np.ndarray:
        """Stratejiler arası korelasyon matrisini al"""
        
        n = len(strategies)
        correlation_matrix = np.eye(n)  # Başlangıçta diagonal matris
        
        # Basit korelasyon tahmini
        for i in range(n):
            for j in range(i+1, n):
                # Strateji çiftine göre korelasyon tahmini
                corr = self._estimate_strategy_correlation(strategies[i], strategies[j])
                correlation_matrix[i][j] = corr
                correlation_matrix[j][i] = corr
        
        return correlation_matrix
    
    def _estimate_strategy_correlation(self, strategy1: str, strategy2: str) -> float:
        """İki strateji arası korelasyon tahmini"""
        
        # Strateji tipine göre korelasyon tahminleri
        correlation_estimates = {
            ('Equity_Long_Short', 'Momentum_Strategy'): 0.7,
            ('Statistical_Arbitrage', 'Mean_Reversion'): 0.6,
            ('Multi_Asset', 'Global_Macro'): 0.5,
            ('Fixed_Income', 'Credit_Strategies'): 0.4,
            ('Commodity_Trading', 'Momentum_Strategy'): 0.3
        }
        
        # Çift varsa o değeri al, yoksa 0.5 varsay
        key = (strategy1, strategy2) if strategy1 < strategy2 else (strategy2, strategy1)
        return correlation_estimates.get(key, 0.3)
    
    def _calculate_portfolio_var(self, weights: np.ndarray, strategies: List[str]) -> float:
        """Portföy VaR hesapla"""
        
        # Basit VaR hesaplaması (gerçek uygulamada historical simulation veya Monte Carlo)
        portfolio_volatility = 0
        for i, strategy in enumerate(strategies):
            vol = self._get_strategy_volatility(strategy)
            portfolio_volatility += (weights[i] * vol) ** 2
        
        portfolio_volatility = np.sqrt(portfolio_volatility)
        
        # %95 VaR (1.65 sigma)
        var_95 = 1.65 * portfolio_volatility
        return var_95
    
    def _calculate_portfolio_cvar(self, weights: np.ndarray, strategies: List[str]) -> float:
        """Portföy CVaR hesapla"""
        
        portfolio_var = self._calculate_portfolio_var(weights, strategies)
        
        # CVaR genellikle VaR'in 1.2-1.5 katı
        cvar_multiplier = 1.3
        cvar_95 = cvar_multiplier * portfolio_var
        
        return cvar_95
    
    def _calculate_efficiency_score(self, strategy_name: str, weight: float) -> float:
        """Strateji verimlilik skoru hesapla"""
        
        # Risk-adjusted return ve diğer faktörlere göre efficiency score
        expected_return = self._get_strategy_expected_return(strategy_name)
        volatility = self._get_strategy_volatility(strategy_name)
        
        if volatility > 0:
            sharpe_like = expected_return / volatility
            efficiency = min(sharpe_like / 2.0, 1.0)  # Normalize to [0,1]
        else:
            efficiency = 0.5
        
        # Ağırlık faktörü (çok düşük veya çok yüksek ağırlıklar efficiency'yi düşürür)
        weight_factor = 1.0 - abs(weight - 0.15) * 2 if weight > 0 else 0
        
        return efficiency * weight_factor
    
    def get_allocation_summary(self) -> Dict:
        """Risk bütçesi dağıtım özetini al"""
        
        return {
            'total_budget': self.config.total_risk_budget,
            'number_of_strategies': 7,
            'rebalancing_frequency': self.config.rebalance_frequency,
            'last_rebalancing': datetime.now().isoformat(),
            'risk_factors': self.risk_factors,
            'allocation_efficiency': 0.85  # Ortalama efficiency
        }