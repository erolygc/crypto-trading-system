"""
Stres Test ve Senaryo Analizi Motoru

Çeşitli piyasa koşulları altında portföy performansını test eder 
ve senaryo analizleri gerçekleştirir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from dataclasses import dataclass
from enum import Enum
import json
from scipy import stats
from scipy.stats import norm, t
import warnings
warnings.filterwarnings('ignore')

@dataclass
class StressScenario:
    """Stres testi senaryosu"""
    scenario_id: str
    name: str
    scenario_type: str  # 'historical', 'hypothetical', 'monte_carlo'
    description: str
    market_shocks: Dict[str, float]  # Asset class -> shock %
    correlation_changes: Dict[str, Dict[str, float]]  # Correlation adjustments
    probability: float
    time_horizon: int  # days
    severity_level: str  # 'low', 'medium', 'high', 'extreme'
    enabled: bool = True

@dataclass
class StressTestResult:
    """Stres testi sonucu"""
    result_id: str
    scenario_id: str
    timestamp: datetime
    portfolio_impact: float
    var_impact: float
    cvar_impact: float
    pnl_distribution: Dict
    key_risks: List[str]
    passed: bool
    details: Dict

class ScenarioType(Enum):
    """Senaryo türleri"""
    HISTORICAL = "historical"
    HYPOTHETICAL = "hypothetical"
    MONTE_CARLO = "monte_carlo"
    PARAMETRIC = "parametric"

class SeverityLevel(Enum):
    """Şiddet seviyeleri"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    EXTREME = "extreme"

class StressTester:
    """
    Stres Test ve Senaryo Analizi Motoru
    
    Çeşitli piyasa şokları ve stres senaryoları altında 
    portföy performansını analiz eder.
    """
    
    def __init__(self, config):
        """
        Stres Test Motorunu başlat
        
        Args:
            config: RiskBudgetConfig objesi
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Stres testi senaryoları
        self.scenarios = {}
        self.test_results = []
        
        # Monte Carlo parametreleri
        self.monte_carlo_simulations = 10000
        self.confidence_levels = [0.95, 0.99]
        
        # Test konfigürasyonu
        self.default_horizon = 10  # 10 günlük stres testi
        self.asset_classes = [
            'equity', 'fixed_income', 'commodities', 'currencies', 
            'alternatives', 'credit'
        ]
        
        # Performans metrikleri
        self.stress_test_coverage = 0.85
        self.avg_scenario_count = 25
        
        self._load_stress_scenarios()
        
        self.logger.info("Stres Test Motoru başlatıldı")
    
    def _load_stress_scenarios(self):
        """Stres testi senaryolarını yükle"""
        
        # Tarihi senaryolar (2008 krizi, 2020 COVID, vs.)
        historical_scenarios = [
            StressScenario(
                scenario_id="GFC_2008",
                name="2008 Global Finansal Krizi",
                scenario_type="historical",
                description="2008 küresel finansal krizini taklit eden senaryo",
                market_shocks={
                    'equity': -0.40,
                    'fixed_income': 0.10,  # Government bonds rise
                    'commodities': -0.25,
                    'currencies': 0.15,
                    'credit': -0.35,
                    'alternatives': -0.20
                },
                correlation_changes={
                    ('equity', 'fixed_income'): 0.2,  # Negative correlation
                    ('equity', 'credit'): 0.8       # High positive correlation
                },
                probability=0.02,
                time_horizon=30,
                severity_level="extreme"
            ),
            StressScenario(
                scenario_id="COVID_2020",
                name="COVID-19 Piyasa Çöküşü 2020",
                scenario_type="historical",
                description="Mart 2020 COVID-19 piyasa çöküşü",
                market_shocks={
                    'equity': -0.30,
                    'fixed_income': 0.05,
                    'commodities': -0.20,
                    'currencies': 0.08,
                    'credit': -0.25,
                    'alternatives': -0.15
                },
                correlation_changes={
                    ('equity', 'alternatives'): 0.6,
                    ('fixed_income', 'equity'): -0.1
                },
                probability=0.05,
                time_horizon=15,
                severity_level="high"
            ),
            StressScenario(
                scenario_id="RATE_SHOCK_2022",
                name="2022 Faiz Şoku",
                scenario_type="historical",
                description="2022 küresel faiz artışları",
                market_shocks={
                    'equity': -0.15,
                    'fixed_income': -0.12,  # Bond prices fall
                    'commodities': 0.10,
                    'currencies': 0.12,
                    'credit': -0.18,
                    'alternatives': -0.08
                },
                correlation_changes={
                    ('fixed_income', 'credit'): 0.7,
                    ('equity', 'commodities'): 0.3
                },
                probability=0.08,
                time_horizon=20,
                severity_level="medium"
            )
        ]
        
        # Hipotetik senaryolar
        hypothetical_scenarios = [
            StressScenario(
                scenario_id="RECESSION_DEEP",
                name="Derin Resesyon",
                scenario_type="hypothetical",
                description="Derin ekonomik resesyon senaryosu",
                market_shocks={
                    'equity': -0.35,
                    'fixed_income': 0.15,
                    'commodities': -0.30,
                    'currencies': 0.20,
                    'credit': -0.40,
                    'alternatives': -0.25
                },
                correlation_changes={
                    ('equity', 'credit'): 0.9,
                    ('equity', 'alternatives'): 0.7,
                    ('fixed_income', 'equity'): -0.3
                },
                probability=0.03,
                time_horizon=45,
                severity_level="extreme"
            ),
            StressScenario(
                scenario_id="INFLATION_SHOCK",
                name="Enflasyon Şoku",
                scenario_type="hypothetical",
                description="Yüksek enflasyon ortamı",
                market_shocks={
                    'equity': -0.20,
                    'fixed_income': -0.15,  # Real yields fall
                    'commodities': 0.25,
                    'currencies': -0.10,
                    'credit': -0.22,
                    'alternatives': 0.15
                },
                correlation_changes={
                    ('commodities', 'alternatives'): 0.5,
                    ('fixed_income', 'commodities'): -0.4
                },
                probability=0.06,
                time_horizon=25,
                severity_level="high"
            ),
            StressScenario(
                scenario_id="GEOPOLITICAL_CRISIS",
                name="Jeopolitik Kriz",
                scenario_type="hypothetical",
                description="Büyük jeopolitik kriz",
                market_shocks={
                    'equity': -0.25,
                    'fixed_income': 0.08,
                    'commodities': 0.40,  # Commodities surge
                    'currencies': 0.25,
                    'credit': -0.28,
                    'alternatives': -0.12
                },
                correlation_changes={
                    ('commodities', 'currencies'): 0.6,
                    ('equity', 'credit'): 0.75
                },
                probability=0.04,
                time_horizon=30,
                severity_level="high"
            ),
            StressScenario(
                scenario_id="LIQUIDITY_FREEZE",
                name="Likidite Dondurma",
                scenario_type="hypothetical",
                description="Piyasa likiditesi tamamen donma",
                market_shocks={
                    'equity': -0.45,
                    'fixed_income': -0.08,
                    'commodities': -0.20,
                    'currencies': 0.05,
                    'credit': -0.50,
                    'alternatives': -0.35
                },
                correlation_changes={
                    ('equity', 'credit'): 0.95,
                    ('alternatives', 'equity'): 0.8
                },
                probability=0.01,
                time_horizon=60,
                severity_level="extreme"
            )
        ]
        
        # Monte Carlo senaryoları parametreleri
        monte_carlo_scenarios = [
            StressScenario(
                scenario_id="MC_VOLATILITY_SPIKE",
                name="Volatilite Patlaması",
                scenario_type="monte_carlo",
                description="Monte Carlo ile volatilite artışı",
                market_shocks={
                    'equity': 0.0,  # Will be simulated
                    'fixed_income': 0.0,
                    'commodities': 0.0,
                    'currencies': 0.0,
                    'credit': 0.0,
                    'alternatives': 0.0
                },
                correlation_changes={},
                probability=0.10,
                time_horizon=10,
                severity_level="medium"
            ),
            StressScenario(
                scenario_id="MC_TAIL_RISK",
                name="Tail Risk Senaryosu",
                scenario_type="monte_carlo",
                description="Monte Carlo ile tail risk analizi",
                market_shocks={
                    'equity': 0.0,
                    'fixed_income': 0.0,
                    'commodities': 0.0,
                    'currencies': 0.0,
                    'credit': 0.0,
                    'alternatives': 0.0
                },
                correlation_changes={},
                probability=0.05,
                time_horizon=20,
                severity_level="high"
            )
        ]
        
        # Tüm senaryoları birleştir
        all_scenarios = historical_scenarios + hypothetical_scenarios + monte_carlo_scenarios
        
        for scenario in all_scenarios:
            self.scenarios[scenario.scenario_id] = scenario
        
        self.logger.info(f"{len(all_scenarios)} stres senaryosu yüklendi")
    
    def load_scenarios(self):
        """Senaryoları yükle (RiskBudgetManager ile uyumlu)"""
        
        self.logger.info("Stres senaryoları hazırlandı")
    
    def run_stress_tests(self, portfolio_data: Dict, market_data: Dict) -> Dict:
        """
        Kapsamlı stres testleri çalıştır
        
        Args:
            portfolio_data: Portföy verileri
            market_data: Piyasa verileri
            
        Returns:
            Dict: Stres test sonuçları
        """
        
        try:
            self.logger.info("Kapsamlı stres testleri başlatılıyor...")
            
            results = {
                'timestamp': datetime.now().isoformat(),
                'scenarios_tested': 0,
                'passed_scenarios': 0,
                'failed_scenarios': 0,
                'severe_scenarios_failed': 0,
                'scenario_results': [],
                'summary_metrics': {},
                'key_findings': []
            }
            
            portfolio_metrics = portfolio_data.get('metrics', {})
            current_var = portfolio_metrics.get('portfolio_var', 0.10)
            current_cvar = portfolio_metrics.get('portfolio_cvar', 0.15)
            
            # Her senaryoyu test et
            for scenario_id, scenario in self.scenarios.items():
                if not scenario.enabled:
                    continue
                
                scenario_result = self._run_single_scenario(scenario, portfolio_data, market_data)
                results['scenario_results'].append(scenario_result)
                results['scenarios_tested'] += 1
                
                # Senaryo geçip geçmediğini kontrol et
                if scenario_result['passed']:
                    results['passed_scenarios'] += 1
                else:
                    results['failed_scenarios'] += 1
                    
                    # Şiddetli senaryoların başarısızlığı
                    if scenario.severity_level in ['high', 'extreme']:
                        results['severe_scenarios_failed'] += 1
            
            # Özet metrikleri hesapla
            results['summary_metrics'] = self._calculate_summary_metrics(results['scenario_results'])
            
            # Ana bulgular
            results['key_findings'] = self._generate_key_findings(results)
            
            self.logger.info(
                f"Stres testleri tamamlandı: {results['passed_scenarios']}/{results['scenarios_tested']} senaryo geçti"
            )
            
            return results
            
        except Exception as e:
            self.logger.error(f"Stres test hatası: {str(e)}")
            return {'error': str(e)}
    
    def _run_single_scenario(self, scenario: StressScenario, 
                           portfolio_data: Dict, 
                           market_data: Dict) -> Dict:
        """Tek senaryo test et"""
        
        try:
            # Senaryo tipine göre farklı yaklaşımlar
            if scenario.scenario_type == "monte_carlo":
                return self._run_monte_carlo_scenario(scenario, portfolio_data)
            elif scenario.scenario_type == "historical":
                return self._run_historical_scenario(scenario, portfolio_data)
            else:
                return self._run_hypothetical_scenario(scenario, portfolio_data)
                
        except Exception as e:
            self.logger.error(f"Senaryo test hatası ({scenario.scenario_id}): {str(e)}")
            
            return {
                'scenario_id': scenario.scenario_id,
                'scenario_name': scenario.name,
                'passed': False,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    def _run_hypothetical_scenario(self, scenario: StressScenario, 
                                 portfolio_data: Dict) -> Dict:
        """Hipotetik senaryo çalıştır"""
        
        # Portföy kompozisyonu
        portfolio_composition = portfolio_data.get('composition', {})
        
        # Şok uygulaması
        portfolio_impact = 0.0
        
        for asset_class, shock in scenario.market_shocks.items():
            weight = portfolio_composition.get(asset_class, 0.0)
            portfolio_impact += weight * shock
        
        # Korelasyon düzeltmeleri
        correlation_adjustment = 0.0
        if scenario.correlation_changes:
            # Basit korelasyon etkisi (gerçek uygulamada daha karmaşık)
            for (asset1, asset2), corr_change in scenario.correlation_changes.items():
                weight1 = portfolio_composition.get(asset1, 0.0)
                weight2 = portfolio_composition.get(asset2, 0.0)
                correlation_adjustment += weight1 * weight2 * corr_change * 0.1
        
        total_impact = portfolio_impact + correlation_adjustment
        
        # VaR/CVaR etkisi tahmini
        var_impact = abs(total_impact) * 1.2  # VaR etkisi
        cvar_impact = abs(total_impact) * 1.5  # CVaR etkisi
        
        # Geçme kriteri
        var_limit = self.config.var_limit
        cvar_limit = self.config.cvar_limit
        
        # Basit geçme kriteri (limit aşımı yok ise geçer)
        passed = (var_impact <= var_limit * 0.5) and (cvar_impact <= cvar_limit * 0.5)
        
        # Risk tespiti
        key_risks = []
        if total_impact < -0.2:
            key_risks.append("Yüksek portföy kaybı riski")
        if var_impact > var_limit * 0.3:
            key_risks.append("VaR limitine yakın risk")
        if scenario.severity_level in ['high', 'extreme']:
            key_risks.append("Şiddetli piyasa şoku riski")
        
        result = StressTestResult(
            result_id=f"{scenario.scenario_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            scenario_id=scenario.scenario_id,
            timestamp=datetime.now(),
            portfolio_impact=total_impact,
            var_impact=var_impact,
            cvar_impact=cvar_impact,
            pnl_distribution={
                'impact': total_impact,
                'worst_case': total_impact * 1.5,
                'best_case': total_impact * 0.5
            },
            key_risks=key_risks,
            passed=passed,
            details={
                'scenario_type': scenario.scenario_type,
                'severity': scenario.severity_level,
                'time_horizon': scenario.time_horizon,
                'probability': scenario.probability
            }
        )
        
        return {
            'scenario_id': scenario.scenario_id,
            'scenario_name': scenario.name,
            'scenario_type': scenario.scenario_type,
            'severity_level': scenario.severity_level,
            'portfolio_impact': result.portfolio_impact,
            'var_impact': result.var_impact,
            'cvar_impact': result.cvar_impact,
            'passed': result.passed,
            'key_risks': result.key_risks,
            'time_horizon': scenario.time_horizon,
            'timestamp': result.timestamp.isoformat(),
            'details': result.details
        }
    
    def _run_historical_scenario(self, scenario: StressScenario, 
                               portfolio_data: Dict) -> Dict:
        """Tarihsel senaryo çalıştır"""
        
        # Tarihsel senaryolar için piyasa şoklarını uygula
        # (Hipotetik senaryoya benzer ama tarihsel verilere dayalı)
        
        result = self._run_hypothetical_scenario(scenario, portfolio_data)
        result['scenario_type'] = "historical"
        
        # Tarihsel senaryolara özel düzeltmeler
        result['details']['historical_period'] = self._get_historical_period(scenario.scenario_id)
        
        return result
    
    def _run_monte_carlo_scenario(self, scenario: StressScenario, 
                                portfolio_data: Dict) -> Dict:
        """Monte Carlo senaryo çalıştır"""
        
        try:
            # Monte Carlo simülasyonu
            simulations = self.monte_carlo_simulations
            
            # Varsayım: volatilite artışı
            if scenario.scenario_id == "MC_VOLATILITY_SPIKE":
                # Volatilite 2x artar
                volatility_multiplier = 2.0
                base_return = -0.05  # Küçük negatif getiri
                
                # Simülasyon
                simulated_returns = np.random.normal(
                    base_return, 
                    0.20 * volatility_multiplier,  # Artan volatilite
                    simulations
                )
                
            elif scenario.scenario_id == "MC_TAIL_RISK":
                # Fat-tail dağılım (t-distribution)
                base_return = -0.08
                base_volatility = 0.25
                degrees_freedom = 3  # Fat tail
                
                simulated_returns = t.rvs(
                    df=degrees_freedom,
                    loc=base_return,
                    scale=base_volatility,
                    size=simulations
                )
            
            else:
                # Genel Monte Carlo
                simulated_returns = np.random.normal(-0.05, 0.20, simulations)
            
            # Sonuçları analiz et
            mean_return = np.mean(simulated_returns)
            std_return = np.std(simulated_returns)
            
            # VaR/CVaR hesapla
            var_95 = np.percentile(simulated_returns, 5)
            var_99 = np.percentile(simulated_returns, 1)
            cvar_95 = np.mean(simulated_returns[simulated_returns <= var_95])
            cvar_99 = np.mean(simulated_returns[simulated_returns <= var_99])
            
            # Geçme kriteri
            passed = var_95 > -0.25 and cvar_95 > -0.35
            
            # Risk tespiti
            key_risks = []
            if var_95 < -0.20:
                key_risks.append("Yüksek VaR riski")
            if cvar_95 < -0.30:
                key_risks.append("Yüksek tail riski")
            if np.abs(mean_return) > 0.10:
                key_risks.append("Yüksek beklenen kayıp")
            
            return {
                'scenario_id': scenario.scenario_id,
                'scenario_name': scenario.name,
                'scenario_type': "monte_carlo",
                'severity_level': scenario.severity_level,
                'portfolio_impact': mean_return,
                'var_impact': abs(var_95),
                'cvar_impact': abs(cvar_95),
                'var_99': abs(var_99),
                'cvar_99': abs(cvar_99),
                'passed': passed,
                'key_risks': key_risks,
                'simulation_count': simulations,
                'time_horizon': scenario.time_horizon,
                'timestamp': datetime.now().isoformat(),
                'details': {
                    'mean_return': mean_return,
                    'volatility': std_return,
                    'skewness': stats.skew(simulated_returns),
                    'kurtosis': stats.kurtosis(simulated_returns)
                }
            }
            
        except Exception as e:
            self.logger.error(f"Monte Carlo simülasyon hatası: {str(e)}")
            return {
                'scenario_id': scenario.scenario_id,
                'scenario_name': scenario.name,
                'scenario_type': "monte_carlo",
                'passed': False,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    def _get_historical_period(self, scenario_id: str) -> str:
        """Tarihsel dönem bilgisini al"""
        
        periods = {
            'GFC_2008': '2008-09-01 to 2009-03-01',
            'COVID_2020': '2020-02-15 to 2020-04-30',
            'RATE_SHOCK_2022': '2022-01-01 to 2022-12-31'
        }
        
        return periods.get(scenario_id, "Unknown period")
    
    def _calculate_summary_metrics(self, scenario_results: List[Dict]) -> Dict:
        """Özet metrikleri hesapla"""
        
        if not scenario_results:
            return {}
        
        # Geçme oranı
        passed_count = sum(1 for result in scenario_results if result.get('passed', False))
        pass_rate = passed_count / len(scenario_results)
        
        # Ortalama etki
        impacts = [result.get('portfolio_impact', 0) for result in scenario_results]
        avg_impact = np.mean(impacts) if impacts else 0
        
        # Maksimum etki
        max_impact = min(impacts) if impacts else 0  # En negatif değer
        
        # VaR etkisi
        var_impacts = [result.get('var_impact', 0) for result in scenario_results]
        avg_var_impact = np.mean(var_impacts) if var_impacts else 0
        
        # CVaR etkisi
        cvar_impacts = [result.get('cvar_impact', 0) for result in scenario_results]
        avg_cvar_impact = np.mean(cvar_impacts) if cvar_impacts else 0
        
        return {
            'pass_rate': pass_rate,
            'average_portfolio_impact': avg_impact,
            'worst_case_impact': max_impact,
            'average_var_impact': avg_var_impact,
            'average_cvar_impact': avg_cvar_impact,
            'scenarios_failed': len(scenario_results) - passed_count,
            'scenarios_passed': passed_count
        }
    
    def _generate_key_findings(self, results: Dict) -> List[str]:
        """Ana bulguları oluştur"""
        
        findings = []
        
        summary = results['summary_metrics']
        scenarios_failed = results['failed_scenarios']
        severe_failed = results['severe_scenarios_failed']
        
        # Geçme oranı analizi
        pass_rate = summary.get('pass_rate', 0)
        if pass_rate < 0.7:
            findings.append("Düşük senaryo geçme oranı - portföy dayanıklılığı artırılmalı")
        elif pass_rate > 0.9:
            findings.append("Yüksek senaryo geçme oranı - güçlü risk yönetimi")
        
        # Şiddetli senaryolar
        if severe_failed > 0:
            findings.append(f"{severe_failed} şiddetli senaryo başarısız - acil risk azaltımı gerekli")
        
        # En kötü durum etkisi
        worst_impact = summary.get('worst_case_impact', 0)
        if worst_impact < -0.3:
            findings.append("Çok yüksek kayıp potansiyeli - pozisyon boyutları azaltılmalı")
        
        # VaR etkisi
        avg_var = summary.get('average_var_impact', 0)
        if avg_var > self.config.var_limit * 0.8:
            findings.append("VaR etkisi yüksek - hedge stratejileri değerlendirilmeli")
        
        # Genel değerlendirme
        if scenarios_failed == 0:
            findings.append("Tüm senaryolar başarılı - portföy sağlıklı")
        elif scenarios_failed > len(results['scenario_results']) * 0.5:
            findings.append("Çok sayıda senaryo başarısız - kapsamlı risk gözden geçirmesi gerekli")
        
        return findings
    
    def add_custom_scenario(self, scenario: StressScenario):
        """Özel senaryo ekle"""
        
        self.scenarios[scenario.scenario_id] = scenario
        self.logger.info(f"Özel senaryo eklendi: {scenario.scenario_id}")
    
    def remove_scenario(self, scenario_id: str) -> bool:
        """Senaryo kaldır"""
        
        if scenario_id in self.scenarios:
            del self.scenarios[scenario_id]
            self.logger.info(f"Senaryo kaldırıldı: {scenario_id}")
            return True
        else:
            self.logger.warning(f"Senaryo bulunamadı: {scenario_id}")
            return False
    
    def get_scenario_performance(self, days: int = 30) -> Dict:
        """Senaryo performans raporu"""
        
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_results = [r for r in self.test_results if r.timestamp > cutoff_date]
        
        if not recent_results:
            return {'message': 'No recent test results'}
        
        # Performans metrikleri
        passed_rate = sum(1 for r in recent_results if r.passed) / len(recent_results)
        
        # Senaryo bazlı analiz
        scenario_performance = {}
        for scenario_id in self.scenarios.keys():
            scenario_results = [r for r in recent_results if r.scenario_id == scenario_id]
            if scenario_results:
                scenario_performance[scenario_id] = {
                    'tests_run': len(scenario_results),
                    'pass_rate': sum(1 for r in scenario_results if r.passed) / len(scenario_results),
                    'avg_impact': np.mean([r.portfolio_impact for r in scenario_results])
                }
        
        return {
            'period_days': days,
            'total_tests': len(recent_results),
            'overall_pass_rate': passed_rate,
            'scenario_performance': scenario_performance,
            'total_scenarios': len(self.scenarios)
        }
    
    def run_comprehensive_stress_test(self, portfolio_data: Dict) -> Dict:
        """Kapsamlı stres testi raporu"""
        
        # Temel senaryolar
        basic_scenarios = ['GFC_2008', 'COVID_2020', 'RECESSION_DEEP', 'LIQUIDITY_FREEZE']
        available_scenarios = [s for s in basic_scenarios if s in self.scenarios]
        
        if not available_scenarios:
            return {'error': 'No basic stress test scenarios available'}
        
        # Seçili senaryoları test et
        market_data = {}  # Dummy market data
        
        test_results = []
        for scenario_id in available_scenarios:
            scenario = self.scenarios[scenario_id]
            result = self._run_single_scenario(scenario, portfolio_data, market_data)
            test_results.append(result)
        
        # Kapsamlı analiz
        summary = self._calculate_summary_metrics(test_results)
        
        # Risk değerlendirmesi
        risk_assessment = {
            'overall_resilience': 'High' if summary.get('pass_rate', 0) > 0.8 else 'Medium',
            'tail_risk_level': 'High' if summary.get('worst_case_impact', 0) < -0.25 else 'Medium',
            'var_resilience': 'Strong' if summary.get('average_var_impact', 0) < 0.15 else 'Weak'
        }
        
        return {
            'test_date': datetime.now().isoformat(),
            'scenarios_tested': len(available_scenarios),
            'summary_metrics': summary,
            'risk_assessment': risk_assessment,
            'detailed_results': test_results,
            'recommendations': self._generate_stress_recommendations(summary)
        }
    
    def _generate_stress_recommendations(self, summary: Dict) -> List[str]:
        """Stres testi önerileri"""
        
        recommendations = []
        
        pass_rate = summary.get('pass_rate', 1.0)
        worst_impact = summary.get('worst_case_impact', 0)
        
        if pass_rate < 0.8:
            recommendations.append("Portföy çeşitliliğini artırın ve risk konsantrasyonunu azaltın")
        
        if worst_impact < -0.3:
            recommendations.append("Pozisyon boyutlarını küçültün ve tail hedge stratejileri uygulayın")
        
        if summary.get('average_var_impact', 0) > 0.2:
            recommendations.append("VaR azaltımı için hedge fonksiyonlarını güçlendirin")
        
        recommendations.append("Düzenli stres testi protokollerini güncelleyin")
        
        return recommendations