"""
Risk-Ayarlı Performans Hesaplama Motoru

Çeşitli risk-ayarlı performans metriklerini hesaplar ve 
portföy performansını analiz eder.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from dataclasses import dataclass
from enum import Enum
import json
from scipy import stats
import warnings
warnings.filterwarnings('ignore')

@dataclass
class PerformanceMetrics:
    """Performans metrikleri"""
    total_return: float
    annualized_return: float
    volatility: float
    sharpe_ratio: float
    sortino_ratio: float
    calmar_ratio: float
    information_ratio: float
    treynor_ratio: float
    jensen_alpha: float
    beta: float
    max_drawdown: float
    var_95: float
    cvar_95: float
    tracking_error: float
    win_rate: float
    profit_factor: float

class BenchmarkType(Enum):
    """Benchmark türleri"""
    MARKET_INDEX = "market_index"
    CUSTOM_BENCHMARK = "custom_benchmark"
    RISK_FREE_RATE = "risk_free_rate"
    STRATEGY_BENCHMARK = "strategy_benchmark"

class RiskAdjustedMetric(Enum):
    """Risk-ayarlı metrikler"""
    SHARPE = "sharpe_ratio"
    SORTINO = "sortino_ratio"
    CALMAR = "calmar_ratio"
    INFORMATION = "information_ratio"
    TREYNOR = "treynor_ratio"
    STERLING = "sterling_ratio"

class PerformanceCalculator:
    """
    Risk-Ayarlı Performans Hesaplama Motoru
    
    Çeşitlı risk-ayarlı performans metriklerini hesaplar ve
    portföy performansını değerlendirir.
    """
    
    def __init__(self, config):
        """
        Performans Hesaplama Motorunu başlat
        
        Args:
            config: RiskBudgetConfig objesi
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Risk-free rate
        self.risk_free_rate = 0.02  # %2 yıllık
        
        # Performans hesaplama parametreleri
        self.annualization_factor = 252  # Trading days per year
        self.downside_threshold = 0.0  # Downside deviation için eşik
        
        # Benchmark ayarları
        self.primary_benchmark = "MSCI_World"
        self.benchmark_returns = {}
        
        # Rolling windows (günlük)
        self.rolling_windows = {
            'short_term': 30,
            'medium_term': 90,
            'long_term': 252
        }
        
        # Performans eşiği
        self.good_performance_threshold = {
            'sharpe_ratio': 1.0,
            'sortino_ratio': 1.5,
            'calmar_ratio': 0.5,
            'win_rate': 0.55
        }
        
        # Performans geçmişi
        self.performance_history = []
        
        # Hesaplama önbelleği
        self.metrics_cache = {}
        
        self.logger.info("Performans Hesaplama Motoru başlatıldı")
    
    def calculate_portfolio_performance(self, 
                                      portfolio_returns: pd.Series,
                                      benchmark_returns: Optional[pd.Series] = None,
                                      risk_free_returns: Optional[pd.Series] = None) -> Dict:
        """
        Kapsamlı portföy performans analizi
        
        Args:
            portfolio_returns: Portföy getiri serisi
            benchmark_returns: Benchmark getiri serisi (opsiyonel)
            risk_free_returns: Risk-free getiri serisi (opsiyonel)
            
        Returns:
            Dict: Kapsamlı performans analizi
        """
        
        try:
            self.logger.info("Portföy performans analizi başlatılıyor...")
            
            if portfolio_returns.empty:
                return {'error': 'Empty returns series'}
            
            # Temel metrikleri hesapla
            basic_metrics = self._calculate_basic_metrics(portfolio_returns)
            
            # Risk-ayarlı metrikleri hesapla
            risk_adjusted_metrics = self._calculate_risk_adjusted_metrics(
                portfolio_returns, benchmark_returns, risk_free_returns
            )
            
            # Downside metrikleri hesapla
            downside_metrics = self._calculate_downside_metrics(portfolio_returns)
            
            # Rolling metrikleri hesapla
            rolling_metrics = self._calculate_rolling_metrics(portfolio_returns)
            
            # Benchmark karşılaştırması
            benchmark_comparison = {}
            if benchmark_returns is not None:
                benchmark_comparison = self._calculate_benchmark_comparison(
                    portfolio_returns, benchmark_returns
                )
            
            # Risk metrikleri
            risk_metrics = self._calculate_risk_metrics(portfolio_returns)
            
            # Sonuçları birleştir
            performance_analysis = {
                'timestamp': datetime.now().isoformat(),
                'period_analysis': {
                    'start_date': portfolio_returns.index[0].strftime('%Y-%m-%d'),
                    'end_date': portfolio_returns.index[-1].strftime('%Y-%m-%d'),
                    'total_periods': len(portfolio_returns),
                    'trading_days': len(portfolio_returns[portfolio_returns != 0])
                },
                'basic_metrics': basic_metrics,
                'risk_adjusted_metrics': risk_adjusted_metrics,
                'downside_metrics': downside_metrics,
                'rolling_metrics': rolling_metrics,
                'benchmark_comparison': benchmark_comparison,
                'risk_metrics': risk_metrics,
                'performance_rating': self._calculate_performance_rating(
                    {**basic_metrics, **risk_adjusted_metrics, **downside_metrics}
                ),
                'recommendations': self._generate_performance_recommendations(
                    {**basic_metrics, **risk_adjusted_metrics, **risk_metrics}
                )
            }
            
            # Cache'e kaydet
            self.metrics_cache = performance_analysis
            
            self.logger.info("Portföy performans analizi tamamlandı")
            return performance_analysis
            
        except Exception as e:
            self.logger.error(f"Performans analizi hatası: {str(e)}")
            return {'error': str(e)}
    
    def _calculate_basic_metrics(self, returns: pd.Series) -> Dict:
        """Temel performans metrikleri"""
        
        # Toplam getiri
        total_return = (1 + returns).prod() - 1
        
        # Yıllıklandırılmış getiri
        n_years = len(returns) / self.annualization_factor
        annualized_return = (1 + total_return) ** (1 / n_years) - 1 if n_years > 0 else 0
        
        # Volatilite (yıllıklandırılmış)
        volatility = returns.std() * np.sqrt(self.annualization_factor)
        
        # Win rate
        win_rate = (returns > 0).sum() / len(returns)
        
        # Ortalama kazanç/kayıp oranı
        gains = returns[returns > 0].mean() if (returns > 0).any() else 0
        losses = abs(returns[returns < 0].mean()) if (returns < 0).any() else 0
        profit_factor = gains / losses if losses > 0 else np.inf
        
        return {
            'total_return': total_return,
            'annualized_return': annualized_return,
            'volatility': volatility,
            'win_rate': win_rate,
            'profit_factor': profit_factor,
            'best_day': returns.max(),
            'worst_day': returns.min(),
            'avg_daily_return': returns.mean()
        }
    
    def _calculate_risk_adjusted_metrics(self, 
                                       returns: pd.Series,
                                       benchmark_returns: Optional[pd.Series] = None,
                                       risk_free_returns: Optional[pd.Series] = None) -> Dict:
        """Risk-ayarlı performans metrikleri"""
        
        # Excess returns
        excess_returns = returns - (risk_free_returns if risk_free_returns is not None 
                                  else pd.Series(self.risk_free_rate / self.annualization_factor, 
                                               index=returns.index))
        
        # Sharpe ratio
        if excess_returns.std() > 0:
            sharpe_ratio = excess_returns.mean() / excess_returns.std() * np.sqrt(self.annualization_factor)
        else:
            sharpe_ratio = 0
        
        # Sortino ratio
        downside_returns = np.minimum(returns, 0)
        downside_deviation = np.sqrt((downside_returns ** 2).mean()) * np.sqrt(self.annualization_factor)
        sortino_ratio = excess_returns.mean() * self.annualization_factor / downside_deviation if downside_deviation > 0 else 0
        
        # Calmar ratio (max drawdown ile)
        cumulative_returns = (1 + returns).cumprod()
        running_max = cumulative_returns.expanding().max()
        drawdown = (cumulative_returns - running_max) / running_max
        max_drawdown = abs(drawdown.min())
        
        calmar_ratio = annualized_return / max_drawdown if max_drawdown > 0 else 0
        
        # Information ratio (benchmark varsa)
        information_ratio = 0
        jensen_alpha = 0
        beta = 0
        treynor_ratio = 0
        tracking_error = 0
        
        if benchmark_returns is not None and len(benchmark_returns) == len(returns):
            # Alpha ve beta hesaplaması
            excess_benchmark = benchmark_returns - (risk_free_returns if risk_free_returns is not None 
                                                  else pd.Series(self.risk_free_rate / self.annualization_factor, 
                                                               index=benchmark_returns.index))
            
            # Beta: covariance(portfolyo, benchmark) / variance(benchmark)
            if excess_benchmark.var() > 0:
                beta = excess_returns.cov(excess_benchmark) / excess_benchmark.var()
            
            # Jensen's Alpha
            market_expected_return = excess_benchmark.mean() * self.annualization_factor
            jensen_alpha = excess_returns.mean() * self.annualization_factor - beta * market_expected_return
            
            # Information ratio
            active_returns = returns - benchmark_returns
            tracking_error = active_returns.std() * np.sqrt(self.annualization_factor)
            
            if tracking_error > 0:
                information_ratio = active_returns.mean() * self.annualization_factor / tracking_error
            
            # Treynor ratio
            if beta != 0:
                treynor_ratio = excess_returns.mean() * self.annualization_factor / beta
        
        return {
            'sharpe_ratio': sharpe_ratio,
            'sortino_ratio': sortino_ratio,
            'calmar_ratio': calmar_ratio,
            'information_ratio': information_ratio,
            'jensen_alpha': jensen_alpha,
            'beta': beta,
            'treynor_ratio': treynor_ratio,
            'tracking_error': tracking_error,
            'max_drawdown': max_drawdown
        }
    
    def _calculate_downside_metrics(self, returns: pd.Series) -> Dict:
        """Downside risk metrikleri"""
        
        # Downside deviation
        downside_returns = np.minimum(returns, 0)
        downside_deviation = np.sqrt((downside_returns ** 2).mean()) * np.sqrt(self.annualization_factor)
        
        # Downside deviation ratio
        downside_deviation_ratio = returns.std() * np.sqrt(self.annualization_factor) / downside_deviation if downside_deviation > 0 else 0
        
        # Upside potential ratio
        upside_returns = returns[returns > 0]
        upside_potential = np.sqrt((upside_returns ** 2).mean()) * np.sqrt(self.annualization_factor) if len(upside_returns) > 0 else 0
        
        upside_potential_ratio = upside_potential / downside_deviation if downside_deviation > 0 else 0
        
        # Value at Risk (historical)
        var_95 = np.percentile(returns, 5)
        var_99 = np.percentile(returns, 1)
        
        # Conditional VaR (Expected Shortfall)
        cvar_95 = returns[returns <= var_95].mean()
        cvar_99 = returns[returns <= var_99].mean()
        
        # Historical drawdown metrics
        cumulative_returns = (1 + returns).cumprod()
        running_max = cumulative_returns.expanding().max()
        drawdowns = (cumulative_returns - running_max) / running_max
        
        # Average drawdown
        avg_drawdown = abs(drawdowns[drawdowns < 0].mean()) if (drawdowns < 0).any() else 0
        
        # Drawdown duration
        drawdown_periods = []
        in_drawdown = False
        drawdown_start = 0
        
        for i, dd in enumerate(drawdowns):
            if dd < 0 and not in_drawdown:
                in_drawdown = True
                drawdown_start = i
            elif dd >= 0 and in_drawdown:
                in_drawdown = False
                drawdown_periods.append(i - drawdown_start)
        
        avg_drawdown_duration = np.mean(drawdown_periods) if drawdown_periods else 0
        
        return {
            'downside_deviation': downside_deviation,
            'downside_deviation_ratio': downside_deviation_ratio,
            'upside_potential_ratio': upside_potential_ratio,
            'var_95': var_95,
            'var_99': var_99,
            'cvar_95': abs(cvar_95),
            'cvar_99': abs(cvar_99),
            'average_drawdown': avg_drawdown,
            'average_drawdown_duration': avg_drawdown_duration,
            'recovery_factor': (cumulative_returns.iloc[-1] - 1) / avg_drawdown if avg_drawdown > 0 else 0
        }
    
    def _calculate_rolling_metrics(self, returns: pd.Series) -> Dict:
        """Rolling window performans metrikleri"""
        
        rolling_metrics = {}
        
        for window_name, window_size in self.rolling_windows.items():
            if len(returns) >= window_size:
                rolling_returns = returns.rolling(window=window_size)
                
                # Rolling Sharpe ratio
                rolling_mean = rolling_returns.mean() * self.annualization_factor
                rolling_std = rolling_returns.std() * np.sqrt(self.annualization_factor)
                rolling_sharpe = rolling_mean / rolling_std
                
                # Rolling max drawdown
                rolling_cumulative = (1 + rolling_returns.cumsum()).cumprod()
                rolling_max = rolling_cumulative.expanding().max()
                rolling_dd = (rolling_cumulative - rolling_max) / rolling_max
                rolling_max_dd = rolling_dd.min()
                
                rolling_metrics[window_name] = {
                    'window_size': window_size,
                    'current_sharpe': rolling_sharpe.iloc[-1] if not rolling_sharpe.empty else 0,
                    'max_sharpe': rolling_sharpe.max() if not rolling_sharpe.empty else 0,
                    'min_sharpe': rolling_sharpe.min() if not rolling_sharpe.empty else 0,
                    'current_max_drawdown': rolling_max_dd,
                    'sharpe_stability': rolling_sharpe.std() if not rolling_sharpe.empty else 0
                }
        
        return rolling_metrics
    
    def _calculate_benchmark_comparison(self, 
                                      portfolio_returns: pd.Series,
                                      benchmark_returns: pd.Series) -> Dict:
        """Benchmark karşılaştırması"""
        
        try:
            # Getirileri hizala
            aligned_returns = pd.concat([portfolio_returns, benchmark_returns], axis=1).dropna()
            aligned_returns.columns = ['portfolio', 'benchmark']
            
            if aligned_returns.empty:
                return {}
            
            # Relative performance
            portfolio_total = (1 + aligned_returns['portfolio']).prod() - 1
            benchmark_total = (1 + aligned_returns['benchmark']).prod() - 1
            relative_performance = portfolio_total - benchmark_total
            
            # Alpha ve beta (regression)
            from scipy.stats import linregress
            slope, intercept, r_value, p_value, std_err = linregress(
                aligned_returns['benchmark'], aligned_returns['portfolio']
            )
            
            # Correlation
            correlation = aligned_returns['portfolio'].corr(aligned_returns['benchmark'])
            
            # Active risk
            active_returns = aligned_returns['portfolio'] - aligned_returns['benchmark']
            tracking_error = active_returns.std() * np.sqrt(self.annualization_factor)
            
            # Information ratio
            information_ratio = active_returns.mean() * self.annualization_factor / tracking_error if tracking_error > 0 else 0
            
            # Hit ratio
            hit_ratio = (active_returns > 0).sum() / len(active_returns)
            
            return {
                'relative_performance': relative_performance,
                'alpha': intercept * self.annualization_factor,
                'beta': slope,
                'r_squared': r_value ** 2,
                'correlation': correlation,
                'tracking_error': tracking_error,
                'information_ratio': information_ratio,
                'hit_ratio': hit_ratio,
                'outperformance_periods': (active_returns > 0).sum(),
                'total_periods': len(active_returns)
            }
            
        except Exception as e:
            self.logger.error(f"Benchmark karşılaştırma hatası: {str(e)}")
            return {}
    
    def _calculate_risk_metrics(self, returns: pd.Series) -> Dict:
        """Risk metrikleri hesapla"""
        
        # Historical volatility
        volatility = returns.std() * np.sqrt(self.annualization_factor)
        
        # Conditional volatility (GARCH-like)
        squared_returns = returns ** 2
        conditional_vol = squared_returns.rolling(window=20).mean().iloc[-1]
        
        # Skewness ve Kurtosis
        skewness = stats.skew(returns)
        kurtosis = stats.kurtosis(returns)
        
        # Jarque-Bera test for normality
        jb_stat, jb_pvalue = stats.jarque_bera(returns)
        is_normal = jb_pvalue > 0.05
        
        # Autocorrelation in returns
        autocorr_1 = returns.autocorr(lag=1) if len(returns) > 1 else 0
        
        # Tail ratio
        var_95 = np.percentile(returns, 5)
        var_5 = np.percentile(returns, 95)
        
        upside_returns = returns[returns > var_5]
        downside_returns = returns[returns < var_95]
        
        tail_ratio = (np.abs(np.percentile(upside_returns, 95)) / 
                     np.abs(np.percentile(downside_returns, 5))) if len(upside_returns) > 0 and len(downside_returns) > 0 else 0
        
        return {
            'historical_volatility': volatility,
            'conditional_volatility': np.sqrt(conditional_vol) * np.sqrt(self.annualization_factor) if not np.isnan(conditional_vol) else 0,
            'skewness': skewness,
            'kurtosis': kurtosis,
            'jarque_bera_statistic': jb_stat,
            'jarque_bera_pvalue': jb_pvalue,
            'is_normal_distribution': is_normal,
            'autocorrelation_lag1': autocorr_1,
            'tail_ratio': tail_ratio,
            'risk_score': self._calculate_risk_score(volatility, skewness, kurtosis)
        }
    
    def _calculate_risk_score(self, volatility: float, skewness: float, kurtosis: float) -> float:
        """Kapsamlı risk skoru hesapla (0-100)"""
        
        # Volatilite skoru (0-40 puan)
        vol_score = min(volatility * 100, 40)
        
        # Skewness skoru (0-30 puan, negative skew cezalandırılır)
        skew_score = 30 - max(0, -skewness * 15)
        
        # Kurtosis skoru (0-30 puan, high kurtosis cezalandırılır)
        kurt_score = 30 - max(0, (kurtosis - 3) * 10)
        
        total_score = vol_score + skew_score + kurt_score
        
        return min(total_score, 100)
    
    def _calculate_performance_rating(self, metrics: Dict) -> Dict:
        """Performans derecelendirmesi"""
        
        # Sharpe ratio rating
        sharpe = metrics.get('sharpe_ratio', 0)
        if sharpe >= 2.0:
            sharpe_rating = 'Excellent'
        elif sharpe >= 1.5:
            sharpe_rating = 'Very Good'
        elif sharpe >= 1.0:
            sharpe_rating = 'Good'
        elif sharpe >= 0.5:
            sharpe_rating = 'Fair'
        else:
            sharpe_rating = 'Poor'
        
        # Risk-adjusted return rating
        annualized_return = metrics.get('annualized_return', 0)
        volatility = metrics.get('volatility', 1)
        risk_adj_return = annualized_return / volatility if volatility > 0 else 0
        
        if risk_adj_return >= 1.0:
            risk_adj_rating = 'Excellent'
        elif risk_adj_return >= 0.7:
            risk_adj_rating = 'Good'
        elif risk_adj_return >= 0.4:
            risk_adj_rating = 'Fair'
        else:
            risk_adj_rating = 'Poor'
        
        # Overall rating
        overall_scores = []
        
        # Sharpe score (0-25)
        overall_scores.append(min(sharpe * 12.5, 25))
        
        # Return score (0-25)
        overall_scores.append(min(max(annualized_return * 125, 0), 25))
        
        # Risk score (inverted, 0-25)
        overall_scores.append(max(25 - metrics.get('risk_score', 50), 0))
        
        # Consistency score (0-25)
        consistency = metrics.get('win_rate', 0.5)
        overall_scores.append((consistency - 0.3) * 125)  # Normalize 0.3-1.0 to 0-25
        
        total_score = sum(overall_scores)
        
        if total_score >= 85:
            overall_rating = 'A+'
        elif total_score >= 75:
            overall_rating = 'A'
        elif total_score >= 65:
            overall_rating = 'B'
        elif total_score >= 55:
            overall_rating = 'C'
        else:
            overall_rating = 'D'
        
        return {
            'overall_rating': overall_rating,
            'overall_score': total_score,
            'sharpe_rating': sharpe_rating,
            'risk_adjusted_rating': risk_adj_rating,
            'component_scores': {
                'return_score': overall_scores[1],
                'risk_score': 25 - overall_scores[2],
                'consistency_score': overall_scores[3],
                'sharpe_score': overall_scores[0]
            }
        }
    
    def _generate_performance_recommendations(self, metrics: Dict) -> List[str]:
        """Performans iyileştirme önerileri"""
        
        recommendations = []
        
        sharpe_ratio = metrics.get('sharpe_ratio', 0)
        annualized_return = metrics.get('annualized_return', 0)
        win_rate = metrics.get('win_rate', 0.5)
        max_drawdown = abs(metrics.get('max_drawdown', 0))
        volatility = metrics.get('volatility', 0)
        
        # Sharpe ratio önerileri
        if sharpe_ratio < 0.5:
            recommendations.append("Sharpe ratio çok düşük - risk yönetimini iyileştirin")
        elif sharpe_ratio < 1.0:
            recommendations.append("Sharpe ratio geliştirilebilir - risk/ödül oranını optimize edin")
        
        # Getiri önerileri
        if annualized_return < 0.05:
            recommendations.append("Yıllık getiri düşük - strateji gözden geçirmesi gerekli")
        
        # Win rate önerileri
        if win_rate < 0.4:
            recommendations.append("Düşük kazanma oranı - giriş/çıkış sinyallerini iyileştirin")
        elif win_rate > 0.7:
            recommendations.append("Yüksek kazanma oranı - pozisyon boyutlarını artırmayı değerlendirin")
        
        # Drawdown önerileri
        if max_drawdown > 0.20:
            recommendations.append("Yüksek maksimum çekilme - stop-loss mekanizmalarını güçlendirin")
        elif max_drawdown > 0.10:
            recommendations.append("Orta seviye çekilme - risk konsantrasyonunu azaltın")
        
        # Volatilite önerileri
        if volatility > 0.30:
            recommendations.append("Yüksek volatilite - pozisyon boyutlarını küçültün")
        
        # Genel öneriler (pozitif)
        if sharpe_ratio > 1.5 and win_rate > 0.55:
            recommendations.append("Güçlü performans - mevcut stratejileri koruyun")
        
        if not recommendations:
            recommendations.append("Performans metrikleri makul seviyelerde")
        
        return recommendations
    
    def get_latest_metrics(self) -> Dict:
        """Son hesaplanan metrikleri al"""
        
        if self.metrics_cache:
            return {
                'sharpe_ratio': self.metrics_cache.get('risk_adjusted_metrics', {}).get('sharpe_ratio', 0),
                'annualized_return': self.metrics_cache.get('basic_metrics', {}).get('annualized_return', 0),
                'volatility': self.metrics_cache.get('basic_metrics', {}).get('volatility', 0),
                'max_drawdown': abs(self.metrics_cache.get('risk_adjusted_metrics', {}).get('max_drawdown', 0)),
                'overall_rating': self.metrics_cache.get('performance_rating', {}).get('overall_rating', 'N/A'),
                'timestamp': self.metrics_cache.get('timestamp', datetime.now().isoformat())
            }
        else:
            return {
                'message': 'No cached metrics available',
                'timestamp': datetime.now().isoformat()
            }
    
    def calculate_attribution_analysis(self, 
                                     portfolio_returns: pd.Series,
                                     factor_returns: Dict[str, pd.Series]) -> Dict:
        """Performans atıf analizi"""
        
        attribution_analysis = {
            'timestamp': datetime.now().isoformat(),
            'factor_contributions': {},
            'residual_performance': 0,
            'total_attributed_performance': 0,
            'attribution_quality': 'Unknown'
        }
        
        try:
            total_performance = portfolio_returns.sum()
            attributed_performance = 0
            
            # Faktör katkılarını hesapla
            for factor_name, factor_return_series in factor_returns.items():
                if len(factor_return_series) == len(portfolio_returns):
                    # Basit korelasyon bazlı atıf
                    correlation = portfolio_returns.corr(factor_return_series)
                    factor_contribution = correlation * factor_return_series.std() * portfolio_returns.std()
                    attributed_performance += factor_contribution
                    
                    attribution_analysis['factor_contributions'][factor_name] = {
                        'correlation': correlation,
                        'contribution': factor_contribution,
                        'relative_contribution': factor_contribution / total_performance if total_performance != 0 else 0
                    }
            
            # Residual performance
            residual = total_performance - attributed_performance
            attribution_analysis['residual_performance'] = residual
            attribution_analysis['total_attributed_performance'] = attributed_performance
            
            # Atıf kalitesi
            attribution_quality = abs(attributed_performance) / abs(total_performance) if total_performance != 0 else 0
            if attribution_quality > 0.8:
                attribution_analysis['attribution_quality'] = 'Excellent'
            elif attribution_quality > 0.6:
                attribution_analysis['attribution_quality'] = 'Good'
            elif attribution_quality > 0.4:
                attribution_analysis['attribution_quality'] = 'Fair'
            else:
                attribution_analysis['attribution_quality'] = 'Poor'
            
            return attribution_analysis
            
        except Exception as e:
            self.logger.error(f"Atıf analizi hatası: {str(e)}")
            attribution_analysis['error'] = str(e)
            return attribution_analysis