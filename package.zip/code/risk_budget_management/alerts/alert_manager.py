"""
Risk Alert Manager

Risk uyarılarını yöneten ve koordine eden ana bileşen.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union, Callable
from datetime import datetime, timedelta
import logging
from enum import Enum
from dataclasses import dataclass
import json
import queue
import threading
import time

class AlertSeverity(Enum):
    """Uyarı seviyeleri"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class AlertType(Enum):
    """Uyarı türleri"""
    VAR_BREACH = "var_breach"
    CVAR_BREACH = "cvar_breach"
    VOLATILITY_HIGH = "volatility_high"
    DRAWDOWN_WARNING = "drawdown_warning"
    CONCENTRATION_RISK = "concentration_risk"
    CORRELATION_RISK = "correlation_risk"
    LIQUIDITY_RISK = "liquidity_risk"
    PERFORMANCE_DEGRADATION = "performance_degradation"
    SYSTEM_ERROR = "system_error"
    COMPLIANCE_ISSUE = "compliance_issue"

@dataclass
class AlertRule:
    """Uyarı kuralı tanımı"""
    rule_id: str
    alert_type: AlertType
    severity: AlertSeverity
    threshold_value: float
    comparison_operator: str  # '>', '<', '>=', '<=', '=='
    description: str
    enabled: bool = True
    cooldown_period: int = 300  # seconds

@dataclass
class AlertEvent:
    """Uyarı olayı"""
    event_id: str
    rule_id: str
    alert_type: AlertType
    severity: AlertSeverity
    message: str
    timestamp: datetime
    metric_value: float
    threshold_value: float
    acknowledged: bool = False
    resolved: bool = False
    action_taken: str = ""
    escalation_level: int = 0

class AlertManager:
    """
    Risk Alert Yöneticisi
    
    Risk uyarılarını yönetir, kuralları kontrol eder ve bildirimler gönderir.
    """
    
    def __init__(self, config=None):
        """
        Alert Manager'ı başlat
        
        Args:
            config: Alert konfigürasyonu
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Alert durumu
        self.alert_rules = {}
        self.active_alerts = {}
        self.alert_history = []
        self.alert_queue = queue.Queue()
        
        # Monitoring
        self.monitoring_active = False
        self.monitoring_thread = None
        self.monitoring_interval = 60  # 60 saniye
        
        # Bildirim callback'leri
        self.notification_callbacks = []
        self.escalation_callbacks = []
        
        # İstatistikler
        self.alert_stats = {
            'total_alerts': 0,
            'alerts_by_severity': {level.value: 0 for level in AlertSeverity},
            'average_response_time': 0,
            'escalation_rate': 0
        }
        
        # Cooldown takibi
        self.last_alert_time = {}
        
        self._initialize_default_rules()
        
        self.logger.info("Risk Alert Manager başlatıldı")
    
    def _initialize_default_rules(self):
        """Varsayılan uyarı kurallarını başlat"""
        
        default_rules = [
            AlertRule(
                rule_id="VAR_LIMIT_95",
                alert_type=AlertType.VAR_BREACH,
                severity=AlertSeverity.HIGH,
                threshold_value=0.15,
                comparison_operator=">",
                description="Portfolio VaR (95%) limit aşımı"
            ),
            AlertRule(
                rule_id="CVAR_LIMIT_95",
                alert_type=AlertType.CVAR_BREACH,
                severity=AlertSeverity.CRITICAL,
                threshold_value=0.20,
                comparison_operator=">",
                description="Portfolio CVaR (95%) limit aşımı"
            ),
            AlertRule(
                rule_id="VOLATILITY_HIGH",
                alert_type=AlertType.VOLATILITY_HIGH,
                severity=AlertSeverity.MEDIUM,
                threshold_value=0.25,
                comparison_operator=">",
                description="Yüksek portföy volatilitesi"
            ),
            AlertRule(
                rule_id="DRAWDOWN_WARNING",
                alert_type=AlertType.DRAWDOWN_WARNING,
                severity=AlertSeverity.HIGH,
                threshold_value=0.15,
                comparison_operator=">",
                description="Yüksek çekilme seviyesi"
            ),
            AlertRule(
                rule_id="CONCENTRATION_RISK",
                alert_type=AlertType.CONCENTRATION_RISK,
                severity=AlertSeverity.MEDIUM,
                threshold_value=0.05,
                comparison_operator=">",
                description="Yüksek konsantrasyon riski"
            )
        ]
        
        for rule in default_rules:
            self.alert_rules[rule.rule_id] = rule
    
    def start_monitoring(self):
        """Alert monitoring'i başlat"""
        
        if self.monitoring_active:
            self.logger.warning("Alert monitoring zaten aktif")
            return
        
        self.monitoring_active = True
        self.monitoring_thread = threading.Thread(target=self._monitoring_loop, daemon=True)
        self.monitoring_thread.start()
        
        self.logger.info("Alert monitoring başlatıldı")
    
    def stop_monitoring(self):
        """Alert monitoring'i durdur"""
        
        self.monitoring_active = False
        
        if self.monitoring_thread and self.monitoring_thread.is_alive():
            self.monitoring_thread.join(timeout=5)
        
        self.logger.info("Alert monitoring durduruldu")
    
    def _monitoring_loop(self):
        """Ana monitoring döngüsü"""
        
        self.logger.info("Alert monitoring döngüsü başlatıldı")
        
        while self.monitoring_active:
            try:
                # Kuyruktaki uyarıları işle
                self._process_alert_queue()
                
                # Cooldown kontrolü yap
                self._check_cooldowns()
                
                time.sleep(self.monitoring_interval)
                
            except Exception as e:
                self.logger.error(f"Alert monitoring hatası: {str(e)}")
                time.sleep(5)
    
    def check_risk_metrics(self, risk_metrics: Dict) -> List[AlertEvent]:
        """
        Risk metriklerini kontrol et ve uyarıları üret
        
        Args:
            risk_metrics: Risk metrikleri
            
        Returns:
            List[AlertEvent]: Oluşturulan uyarılar
        """
        
        alerts = []
        
        for rule_id, rule in self.alert_rules.items():
            if not rule.enabled:
                continue
            
            # Metrik değerini al
            metric_value = self._extract_metric_value(risk_metrics, rule.alert_type)
            
            if metric_value is None:
                continue
            
            # Koşul kontrolü
            if self._check_condition(metric_value, rule.threshold_value, rule.comparison_operator):
                # Cooldown kontrolü
                if self._is_in_cooldown(rule_id):
                    continue
                
                # Uyarı oluştur
                alert = AlertEvent(
                    event_id=f"{rule_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                    rule_id=rule_id,
                    alert_type=rule.alert_type,
                    severity=rule.severity,
                    message=f"{rule.description}: {metric_value:.3f} (Limit: {rule.threshold_value:.3f})",
                    timestamp=datetime.now(),
                    metric_value=metric_value,
                    threshold_value=rule.threshold_value
                )
                
                # Uyarıyı işle
                self._process_alert(alert)
                alerts.append(alert)
                
                # Cooldown güncelle
                self.last_alert_time[rule_id] = datetime.now()
        
        return alerts
    
    def _extract_metric_value(self, risk_metrics: Dict, alert_type: AlertType) -> Optional[float]:
        """Uyarı tipine göre metrik değerini çıkar"""
        
        metric_mapping = {
            AlertType.VAR_BREACH: 'portfolio_var',
            AlertType.CVAR_BREACH: 'portfolio_cvar',
            AlertType.VOLATILITY_HIGH: 'portfolio_volatility',
            AlertType.DRAWDOWN_WARNING: 'max_drawdown',
            AlertType.CONCENTRATION_RISK: 'concentration_risk',
            AlertType.CORRELATION_RISK: 'correlation_risk'
        }
        
        metric_name = metric_mapping.get(alert_type)
        return risk_metrics.get(metric_name) if metric_name else None
    
    def _check_condition(self, metric_value: float, threshold: float, operator: str) -> bool:
        """Koşul kontrolü yap"""
        
        if operator == ">":
            return metric_value > threshold
        elif operator == "<":
            return metric_value < threshold
        elif operator == ">=":
            return metric_value >= threshold
        elif operator == "<=":
            return metric_value <= threshold
        elif operator == "==":
            return abs(metric_value - threshold) < 0.001
        else:
            return False
    
    def _is_in_cooldown(self, rule_id: str) -> bool:
        """Cooldown periyodunda mı kontrol et"""
        
        if rule_id not in self.last_alert_time:
            return False
        
        rule = self.alert_rules.get(rule_id)
        if not rule:
            return False
        
        last_alert = self.last_alert_time[rule_id]
        time_since_last = (datetime.now() - last_alert).total_seconds()
        
        return time_since_last < rule.cooldown_period
    
    def _process_alert(self, alert: AlertEvent):
        """Uyarıyı işle"""
        
        try:
            # Aktif uyarılara ekle
            self.active_alerts[alert.event_id] = alert
            
            # İstatistikleri güncelle
            self._update_alert_stats(alert)
            
            # Kuyruğa ekle
            self.alert_queue.put(alert)
            
            # Callback'leri çağır
            self._trigger_notification_callbacks(alert)
            
            # Eskalasyon kontrolü
            if alert.severity == AlertSeverity.CRITICAL:
                self._trigger_escalation(alert)
            
            self.logger.warning(f"Alert oluşturuldu: {alert.message}")
            
        except Exception as e:
            self.logger.error(f"Alert işleme hatası: {str(e)}")
    
    def _process_alert_queue(self):
        """Alert kuyruğunu işle"""
        
        processed_count = 0
        max_process = 10  # Maksimum işleme sayısı
        
        while not self.alert_queue.empty() and processed_count < max_process:
            try:
                alert = self.alert_queue.get_nowait()
                
                # Alert geçmişine ekle
                self.alert_history.append(alert)
                
                # Eski uyarıları temizle (son 1000)
                if len(self.alert_history) > 1000:
                    self.alert_history = self.alert_history[-1000:]
                
                processed_count += 1
                
            except queue.Empty:
                break
            except Exception as e:
                self.logger.error(f"Queue işleme hatası: {str(e)}")
    
    def _update_alert_stats(self, alert: AlertEvent):
        """Alert istatistiklerini güncelle"""
        
        self.alert_stats['total_alerts'] += 1
        
        severity_key = alert.severity.value
        if severity_key in self.alert_stats['alerts_by_severity']:
            self.alert_stats['alerts_by_severity'][severity_key] += 1
    
    def _trigger_notification_callbacks(self, alert: AlertEvent):
        """Bildirim callback'lerini tetikle"""
        
        for callback in self.notification_callbacks:
            try:
                callback(alert)
            except Exception as e:
                self.logger.error(f"Notification callback hatası: {str(e)}")
    
    def _trigger_escalation(self, alert: AlertEvent):
        """Eskalasyon tetikle"""
        
        for callback in self.escalation_callbacks:
            try:
                callback(alert)
            except Exception as e:
                self.logger.error(f"Escalation callback hatası: {str(e)}")
    
    def _check_cooldowns(self):
        """Cooldown periyotlarını kontrol et"""
        
        current_time = datetime.now()
        
        # Timeout olan alert'leri temizle
        timeout_threshold = current_time - timedelta(hours=24)  # 24 saat
        
        timed_out_alerts = [
            alert_id for alert_id, alert in self.active_alerts.items()
            if alert.timestamp < timeout_threshold
        ]
        
        for alert_id in timed_out_alerts:
            del self.active_alerts[alert_id]
            self.logger.info(f"Timeout olan alert temizlendi: {alert_id}")
    
    def acknowledge_alert(self, event_id: str, user: str = "system", notes: str = "") -> bool:
        """Alert'i onayla"""
        
        if event_id in self.active_alerts:
            alert = self.active_alerts[event_id]
            alert.acknowledged = True
            alert.action_taken = f"Acknowledged by {user}: {notes}"
            
            self.logger.info(f"Alert onaylandı: {event_id} - Kullanıcı: {user}")
            return True
        else:
            self.logger.warning(f"Alert bulunamadı: {event_id}")
            return False
    
    def resolve_alert(self, event_id: str, user: str = "system", notes: str = "") -> bool:
        """Alert'i çöz"""
        
        if event_id in self.active_alerts:
            alert = self.active_alerts[event_id]
            alert.resolved = True
            alert.action_taken = f"Resolved by {user}: {notes}"
            
            # Aktif alertlerden kaldır
            del self.active_alerts[event_id]
            
            self.logger.info(f"Alert çözüldü: {event_id} - Kullanıcı: {user}")
            return True
        else:
            self.logger.warning(f"Alert bulunamadı: {event_id}")
            return False
    
    def add_notification_callback(self, callback: Callable[[AlertEvent], None]):
        """Notification callback ekle"""
        
        self.notification_callbacks.append(callback)
        self.logger.info("Notification callback eklendi")
    
    def add_escalation_callback(self, callback: Callable[[AlertEvent], None]):
        """Escalation callback ekle"""
        
        self.escalation_callbacks.append(callback)
        self.logger.info("Escalation callback eklendi")
    
    def add_custom_rule(self, rule: AlertRule):
        """Özel uyarı kuralı ekle"""
        
        self.alert_rules[rule.rule_id] = rule
        self.logger.info(f"Özel uyarı kuralı eklendi: {rule.rule_id}")
    
    def remove_rule(self, rule_id: str) -> bool:
        """Uyarı kuralını kaldır"""
        
        if rule_id in self.alert_rules:
            del self.alert_rules[rule_id]
            self.logger.info(f"Uyarı kuralı kaldırıldı: {rule_id}")
            return True
        else:
            self.logger.warning(f"Uyarı kuralı bulunamadı: {rule_id}")
            return False
    
    def get_active_alerts(self) -> List[Dict]:
        """Aktif uyarıları al"""
        
        alerts = []
        for alert in self.active_alerts.values():
            alerts.append({
                'event_id': alert.event_id,
                'alert_type': alert.alert_type.value,
                'severity': alert.severity.value,
                'message': alert.message,
                'timestamp': alert.timestamp.isoformat(),
                'metric_value': alert.metric_value,
                'threshold_value': alert.threshold_value,
                'acknowledged': alert.acknowledged,
                'resolved': alert.resolved
            })
        
        return alerts
    
    def get_alert_summary(self) -> Dict:
        """Alert özetini al"""
        
        return {
            'total_active_alerts': len(self.active_alerts),
            'total_rules': len(self.alert_rules),
            'enabled_rules': sum(1 for rule in self.alert_rules.values() if rule.enabled),
            'alert_statistics': self.alert_stats,
            'monitoring_active': self.monitoring_active,
            'severity_breakdown': {
                'critical': len([a for a in self.active_alerts.values() if a.severity == AlertSeverity.CRITICAL]),
                'high': len([a for a in self.active_alerts.values() if a.severity == AlertSeverity.HIGH]),
                'medium': len([a for a in self.active_alerts.values() if a.severity == AlertSeverity.MEDIUM]),
                'low': len([a for a in self.active_alerts.values() if a.severity == AlertSeverity.LOW])
            }
        }
    
    def get_recent_alerts(self, hours: int = 24) -> List[Dict]:
        """Son n saatteki uyarıları al"""
        
        cutoff_time = datetime.now() - timedelta(hours=hours)
        recent_alerts = [
            alert for alert in self.alert_history
            if alert.timestamp > cutoff_time
        ]
        
        return [
            {
                'event_id': alert.event_id,
                'alert_type': alert.alert_type.value,
                'severity': alert.severity.value,
                'message': alert.message,
                'timestamp': alert.timestamp.isoformat(),
                'acknowledged': alert.acknowledged,
                'resolved': alert.resolved
            }
            for alert in recent_alerts
        ]
    
    def test_alert_system(self) -> Dict:
        """Alert sistemini test et"""
        
        test_metrics = {
            'portfolio_var': 0.20,  # VaR limit aşımı
            'portfolio_cvar': 0.25,  # CVaR limit aşımı
            'portfolio_volatility': 0.30,  # Yüksek volatilite
            'max_drawdown': 0.18,  # Yüksek çekilme
            'concentration_risk': 0.08  # Yüksek konsantrasyon
        }
        
        test_alerts = self.check_risk_metrics(test_metrics)
        
        return {
            'test_timestamp': datetime.now().isoformat(),
            'test_metrics': test_metrics,
            'alerts_generated': len(test_alerts),
            'alert_types': [alert.alert_type.value for alert in test_alerts],
            'severity_distribution': {
                'critical': len([a for a in test_alerts if a.severity == AlertSeverity.CRITICAL]),
                'high': len([a for a in test_alerts if a.severity == AlertSeverity.HIGH]),
                'medium': len([a for a in test_alerts if a.severity == AlertSeverity.MEDIUM])
            }
        }