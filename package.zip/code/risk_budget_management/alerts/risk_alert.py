"""
Risk Alert Sınıfı

Risk uyarılarını temsil eden veri sınıfı.
"""

from typing import Dict, List, Optional
from datetime import datetime
from enum import Enum
from dataclasses import dataclass

class AlertAction(Enum):
    """Uyarı aksiyonları"""
    ACKNOWLEDGE = "acknowledge"
    RESOLVE = "resolve"
    ESCALATE = "escalate"
    DISMISS = "dismiss"
    COMMENT = "comment"

@dataclass
class RiskAlert:
    """
    Risk Uyarı Sınıfı
    
    Risk sistemindeki uyarıları temsil eder.
    """
    
    alert_id: str
    alert_type: str
    severity: str
    title: str
    message: str
    timestamp: datetime
    source_system: str
    metric_value: float
    threshold_value: float
    current_value: float
    action_required: str
    auto_resolve: bool = False
    ttl_hours: int = 24
    tags: List[str] = None
    metadata: Dict = None
    acknowledged: bool = False
    resolved: bool = False
    escalated: bool = False
    
    def __post_init__(self):
        if self.tags is None:
            self.tags = []
        if self.metadata is None:
            self.metadata = {}
    
    def is_expired(self) -> bool:
        """Uyarının süresi dolmuş mu kontrol et"""
        return (datetime.now() - self.timestamp).total_seconds() > (self.ttl_hours * 3600)
    
    def needs_action(self) -> bool:
        """Aksiyon gerekli mi"""
        return not self.acknowledged and not self.resolved and not self.is_expired()
    
    def get_severity_score(self) -> int:
        """Seviye skorunu al (1-4)"""
        severity_scores = {
            'low': 1,
            'medium': 2,
            'high': 3,
            'critical': 4
        }
        return severity_scores.get(self.severity.lower(), 1)
    
    def to_dict(self) -> Dict:
        """Sözlük formatına dönüştür"""
        return {
            'alert_id': self.alert_id,
            'alert_type': self.alert_type,
            'severity': self.severity,
            'title': self.title,
            'message': self.message,
            'timestamp': self.timestamp.isoformat(),
            'source_system': self.source_system,
            'metric_value': self.metric_value,
            'threshold_value': self.threshold_value,
            'current_value': self.current_value,
            'action_required': self.action_required,
            'auto_resolve': self.auto_resolve,
            'ttl_hours': self.ttl_hours,
            'tags': self.tags,
            'metadata': self.metadata,
            'acknowledged': self.acknowledged,
            'resolved': self.resolved,
            'escalated': self.escalated,
            'expired': self.is_expired(),
            'needs_action': self.needs_action(),
            'severity_score': self.get_severity_score()
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'RiskAlert':
        """Sözlükten oluştur"""
        data['timestamp'] = datetime.fromisoformat(data['timestamp'])
        return cls(**data)