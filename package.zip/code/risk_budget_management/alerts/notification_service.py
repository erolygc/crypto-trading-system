"""
Notification Service

Uyarı bildirimlerini farklı kanallar üzerinden gönderen servis.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union, Callable
from datetime import datetime, timedelta
import logging
from enum import Enum
from dataclasses import dataclass
import json
import smtplib
from email.mime.text import MimeText
from email.mime.multipart import MimeMultipart
import requests
import os

class NotificationChannel(Enum):
    """Bildirim kanalları"""
    EMAIL = "email"
    SMS = "sms"
    SLACK = "slack"
    TEAMS = "teams"
    WEBHOOK = "webhook"
    CONSOLE = "console"
    FILE = "file"

class NotificationPriority(Enum):
    """Bildirim önceliği"""
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    URGENT = "urgent"

@dataclass
class NotificationMessage:
    """Bildirim mesajı"""
    title: str
    body: str
    severity: str
    timestamp: datetime
    source: str
    action_url: Optional[str] = None
    metadata: Dict = None

class NotificationService:
    """
    Bildirim Servisi
    
    Uyarıları farklı kanallar üzerinden bildirim olarak gönderir.
    """
    
    def __init__(self, config=None):
        """
        Notification Service'i başlat
        
        Args:
            config: Bildirim konfigürasyonu
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Aktif kanallar
        self.active_channels = {}
        self.channel_configs = {}
        
        # Bildirim geçmişi
        self.notification_history = []
        
        # Rate limiting
        self.rate_limits = {}
        self.last_notifications = {}
        
        # Callback'ler
        self.notification_callbacks = []
        
        self._initialize_default_channels()
        
        self.logger.info("Notification Service başlatıldı")
    
    def _initialize_default_channels(self):
        """Varsayılan bildirim kanallarını başlat"""
        
        # Console kanalı (her zaman aktif)
        self.add_channel(NotificationChannel.CONSOLE, {
            'enabled': True,
            'level': 'INFO'
        })
        
        # Dosya kanalı
        self.add_channel(NotificationChannel.FILE, {
            'enabled': True,
            'path': 'logs/risk_notifications.log',
            'max_size_mb': 100
        })
        
        # Email kanalı (opsiyonel)
        if hasattr(self.config, 'email_config') and self.config.email_config:
            self.add_channel(NotificationChannel.EMAIL, self.config.email_config)
    
    def add_channel(self, channel: NotificationChannel, config: Dict):
        """Bildirim kanalı ekle"""
        
        self.channel_configs[channel] = config
        self.active_channels[channel] = True
        
        # Rate limiting başlat
        self.rate_limits[channel] = {
            'max_per_hour': config.get('max_per_hour', 10),
            'max_per_day': config.get('max_per_day', 100),
            'hour_window': 3600,  # 1 hour in seconds
            'day_window': 86400   # 1 day in seconds
        }
        
        self.logger.info(f"Bildirim kanalı eklendi: {channel.value}")
    
    def remove_channel(self, channel: NotificationChannel) -> bool:
        """Bildirim kanalını kaldır"""
        
        if channel in self.active_channels:
            del self.active_channels[channel]
            if channel in self.channel_configs:
                del self.channel_configs[channel]
            if channel in self.rate_limits:
                del self.rate_limits[channel]
            
            self.logger.info(f"Bildirim kanalı kaldırıldı: {channel.value}")
            return True
        else:
            self.logger.warning(f"Bildirim kanalı bulunamadı: {channel.value}")
            return False
    
    def send_notification(self, 
                         message: NotificationMessage,
                         channels: Optional[List[NotificationChannel]] = None,
                         priority: NotificationPriority = NotificationPriority.NORMAL) -> Dict:
        """
        Bildirim gönder
        
        Args:
            message: Bildirim mesajı
            channels: Hedef kanallar (None = tüm aktif kanallar)
            priority: Öncelik seviyesi
            
        Returns:
            Dict: Gönderim sonuçları
        """
        
        try:
            if channels is None:
                channels = list(self.active_channels.keys())
            
            results = {
                'timestamp': datetime.now().isoformat(),
                'message_title': message.title,
                'channels_attempted': len(channels),
                'channels_successful': 0,
                'channels_failed': 0,
                'results_by_channel': {}
            }
            
            for channel in channels:
                if channel not in self.active_channels or not self.active_channels[channel]:
                    results['results_by_channel'][channel.value] = {
                        'status': 'skipped',
                        'reason': 'channel_inactive'
                    }
                    continue
                
                # Rate limiting kontrolü
                if not self._check_rate_limit(channel):
                    results['results_by_channel'][channel.value] = {
                        'status': 'rate_limited',
                        'reason': 'rate_limit_exceeded'
                    }
                    continue
                
                # Kanal tipine göre bildirim gönder
                try:
                    success = self._send_to_channel(channel, message)
                    
                    if success:
                        results['channels_successful'] += 1
                        results['results_by_channel'][channel.value] = {
                            'status': 'success',
                            'timestamp': datetime.now().isoformat()
                        }
                    else:
                        results['channels_failed'] += 1
                        results['results_by_channel'][channel.value] = {
                            'status': 'failed',
                            'reason': 'delivery_failed'
                        }
                        
                except Exception as e:
                    results['channels_failed'] += 1
                    results['results_by_channel'][channel.value] = {
                        'status': 'error',
                        'error': str(e)
                    }
                    self.logger.error(f"Kanal bildirim hatası ({channel.value}): {str(e)}")
            
            # Bildirim geçmişine ekle
            self.notification_history.append({
                'message': message,
                'channels': channels,
                'results': results,
                'timestamp': datetime.now()
            })
            
            # Callback'leri çağır
            self._trigger_callbacks(message, results)
            
            self.logger.info(f"Bildirim gönderildi: {message.title} - Başarılı: {results['channels_successful']}/{results['channels_attempted']}")
            
            return results
            
        except Exception as e:
            self.logger.error(f"Bildirim gönderme hatası: {str(e)}")
            return {'error': str(e)}
    
    def _check_rate_limit(self, channel: NotificationChannel) -> bool:
        """Rate limiting kontrolü"""
        
        if channel not in self.rate_limits:
            return True
        
        limits = self.rate_limits[channel]
        now = datetime.now()
        
        # Son bildirim zamanlarını kontrol et
        if channel not in self.last_notifications:
            self.last_notifications[channel] = []
        
        # Eski kayıtları temizle
        hour_ago = now - timedelta(seconds=limits['hour_window'])
        day_ago = now - timedelta(seconds=limits['day_window'])
        
        self.last_notifications[channel] = [
            timestamp for timestamp in self.last_notifications[channel]
            if timestamp > day_ago
        ]
        
        # Rate limit kontrolü
        recent_hour = [t for t in self.last_notifications[channel] if t > hour_ago]
        recent_day = self.last_notifications[channel]
        
        if len(recent_hour) >= limits['max_per_hour']:
            return False
        
        if len(recent_day) >= limits['max_per_day']:
            return False
        
        # Başarılı, timestamp ekle
        self.last_notifications[channel].append(now)
        return True
    
    def _send_to_channel(self, channel: NotificationChannel, message: NotificationMessage) -> bool:
        """Belirli kanala bildirim gönder"""
        
        config = self.channel_configs.get(channel, {})
        
        if channel == NotificationChannel.CONSOLE:
            return self._send_console(message, config)
        elif channel == NotificationChannel.FILE:
            return self._send_file(message, config)
        elif channel == NotificationChannel.EMAIL:
            return self._send_email(message, config)
        elif channel == NotificationChannel.SLACK:
            return self._send_slack(message, config)
        elif channel == NotificationChannel.WEBHOOK:
            return self._send_webhook(message, config)
        else:
            self.logger.warning(f"Desteklenmeyen kanal: {channel.value}")
            return False
    
    def _send_console(self, message: NotificationMessage, config: Dict) -> bool:
        """Console'a bildirim gönder"""
        
        try:
            level = config.get('level', 'INFO')
            
            # Seviyeye göre farklı formatlar
            if message.severity in ['high', 'critical']:
                prefix = f"🚨 {message.severity.upper()} ALERT"
            elif message.severity == 'medium':
                prefix = f"⚠️  WARNING"
            else:
                prefix = f"ℹ️  INFO"
            
            print(f"\n{prefix}")
            print(f"Zaman: {message.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"Başlık: {message.title}")
            print(f"Mesaj: {message.body}")
            if message.action_url:
                print(f"Aksiyon: {message.action_url}")
            print("-" * 50)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Console bildirim hatası: {str(e)}")
            return False
    
    def _send_file(self, message: NotificationMessage, config: Dict) -> bool:
        """Dosyaya bildirim gönder"""
        
        try:
            file_path = config.get('path', 'logs/risk_notifications.log')
            
            # Klasörü oluştur
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            # Dosyaya yaz
            with open(file_path, 'a', encoding='utf-8') as f:
                f.write(f"[{message.timestamp.strftime('%Y-%m-%d %H:%M:%S')}] {message.severity.upper()}: {message.title}\\n")
                f.write(f"Mesaj: {message.body}\\n")
                f.write(f"Kaynak: {message.source}\\n")
                if message.action_url:
                    f.write(f"Aksiyon: {message.action_url}\\n")
                f.write("-" * 50 + "\\n")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Dosya bildirim hatası: {str(e)}")
            return False
    
    def _send_email(self, message: NotificationMessage, config: Dict) -> bool:
        """Email ile bildirim gönder"""
        
        try:
            smtp_server = config.get('smtp_server')
            smtp_port = config.get('smtp_port', 587)
            username = config.get('username')
            password = config.get('password')
            recipients = config.get('recipients', [])
            
            if not all([smtp_server, username, password, recipients]):
                self.logger.warning("Email konfigürasyonu eksik")
                return False
            
            # Email oluştur
            msg = MimeMultipart()
            msg['From'] = username
            msg['To'] = ', '.join(recipients)
            msg['Subject'] = f"[{message.severity.upper()}] {message.title}"
            
            # Email body
            body = f"""
Risk Uyarısı Bildirimi
            
Tarih: {message.timestamp.strftime('%Y-%m-%d %H:%M:%S')}
Seviye: {message.severity}
Kaynak: {message.source}

Mesaj:
{message.body}

---
Bu otomatik bir bildirimdir.
            """
            
            msg.attach(MimeText(body, 'plain', 'utf-8'))
            
            # Email gönder
            with smtplib.SMTP(smtp_server, smtp_port) as server:
                server.starttls()
                server.login(username, password)
                server.send_message(msg)
            
            return True
            
        except Exception as e:
            self.logger.error(f"Email bildirim hatası: {str(e)}")
            return False
    
    def _send_slack(self, message: NotificationMessage, config: Dict) -> bool:
        """Slack'e bildirim gönder"""
        
        try:
            webhook_url = config.get('webhook_url')
            channel = config.get('channel', '#alerts')
            
            if not webhook_url:
                self.logger.warning("Slack webhook URL yok")
                return False
            
            # Slack payload
            color = {
                'low': 'good',
                'medium': 'warning', 
                'high': 'danger',
                'critical': 'danger'
            }.get(message.severity, 'good')
            
            payload = {
                'channel': channel,
                'username': 'Risk Bot',
                'icon_emoji': ':warning:',
                'attachments': [{
                    'color': color,
                    'title': message.title,
                    'text': message.body,
                    'fields': [
                        {'title': 'Seviye', 'value': message.severity, 'short': True},
                        {'title': 'Kaynak', 'value': message.source, 'short': True}
                    ],
                    'footer': 'Risk Management System',
                    'ts': int(message.timestamp.timestamp())
                }]
            }
            
            if message.action_url:
                payload['attachments'][0]['actions'] = [{
                    'type': 'button',
                    'text': 'View Details',
                    'url': message.action_url
                }]
            
            # Gönder
            response = requests.post(webhook_url, json=payload)
            response.raise_for_status()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Slack bildirim hatası: {str(e)}")
            return False
    
    def _send_webhook(self, message: NotificationMessage, config: Dict) -> bool:
        """Webhook ile bildirim gönder"""
        
        try:
            webhook_url = config.get('url')
            headers = config.get('headers', {})
            
            if not webhook_url:
                self.logger.warning("Webhook URL yok")
                return False
            
            # Webhook payload
            payload = {
                'title': message.title,
                'message': message.body,
                'severity': message.severity,
                'timestamp': message.timestamp.isoformat(),
                'source': message.source,
                'action_url': message.action_url,
                'metadata': message.metadata
            }
            
            # Gönder
            response = requests.post(webhook_url, json=payload, headers=headers)
            response.raise_for_status()
            
            return True
            
        except Exception as e:
            self.logger.error(f"Webhook bildirim hatası: {str(e)}")
            return False
    
    def _trigger_callbacks(self, message: NotificationMessage, results: Dict):
        """Callback fonksiyonlarını tetikle"""
        
        for callback in self.notification_callbacks:
            try:
                callback(message, results)
            except Exception as e:
                self.logger.error(f"Callback hatası: {str(e)}")
    
    def add_callback(self, callback: Callable[[NotificationMessage, Dict], None]):
        """Callback ekle"""
        
        self.notification_callbacks.append(callback)
        self.logger.info("Notification callback eklendi")
    
    def get_channel_status(self) -> Dict:
        """Kanal durumlarını al"""
        
        status = {}
        for channel in NotificationChannel:
            status[channel.value] = {
                'active': self.active_channels.get(channel, False),
                'configured': channel in self.channel_configs,
                'rate_limited': not self._check_rate_limit(channel) if channel in self.rate_limits else False,
                'last_notification': self.last_notifications.get(channel, [None])[-1].isoformat() 
                                  if self.last_notifications.get(channel) else None
            }
        
        return status
    
    def get_notification_history(self, hours: int = 24) -> List[Dict]:
        """Bildirim geçmişini al"""
        
        cutoff_time = datetime.now() - timedelta(hours=hours)
        recent_notifications = [
            {
                'timestamp': notification['timestamp'].isoformat(),
                'message_title': notification['message'].title,
                'severity': notification['message'].severity,
                'channels_attempted': notification['results']['channels_attempted'],
                'channels_successful': notification['results']['channels_successful'],
                'channels_failed': notification['results']['channels_failed']
            }
            for notification in self.notification_history
            if notification['timestamp'] > cutoff_time
        ]
        
        return recent_notifications
    
    def test_channel(self, channel: NotificationChannel) -> Dict:
        """Kanalı test et"""
        
        test_message = NotificationMessage(
            title="Test Bildirimi",
            body="Bu bir test bildirimidir.",
            severity="low",
            timestamp=datetime.now(),
            source="NotificationService"
        )
        
        results = self.send_notification(test_message, [channel])
        
        return {
            'channel': channel.value,
            'test_timestamp': datetime.now().isoformat(),
            'test_results': results
        }