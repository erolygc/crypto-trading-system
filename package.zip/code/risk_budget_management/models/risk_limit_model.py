"""
Risk Limit Model Sınıfı

Risk limitlerini yöneten ve zorlayan model.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from enum import Enum
from dataclasses import dataclass

class LimitType(Enum):
    """Risk limit türleri"""
    HARD = "hard"
    SOFT = "soft"
    WARNING = "warning"
    DYNAMIC = "dynamic"

class LimitMetric(Enum):
    """Limit metrik türleri"""
    VAR = "var"
    CVAR = "cvar"
    VOLATILITY = "volatility"
    DRAWDOWN = "drawdown"
    CONCENTRATION = "concentration"
    CORRELATION = "correlation"
    LIQUIDITY = "liquidity"

@dataclass
class RiskLimit:
    """Risk limit tanımı"""
    limit_id: str
    metric: LimitMetric
    limit_value: float
    limit_type: LimitType
    severity: str
    description: str
    current_usage: float = 0.0
    utilization_rate: float = 0.0

class RiskLimitModel:
    """
    Risk Limit Yönetimi Modeli
    
    Risk limitlerini yönetir, izler ve zorlar.
    """
    
    def __init__(self, config=None):
        """Risk Limit Modelini başlat"""
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        self.risk_limits = {}
        self.violation_history = []
        
        self._initialize_default_limits()
        self.logger.info("Risk Limit Modeli başlatıldı")
    
    def _initialize_default_limits(self):
        """Varsayılan limitleri başlat"""
        
        default_limits = [
            RiskLimit("VAR_95_LIMIT", LimitMetric.VAR, 0.15, LimitType.HARD, "critical", "Portfolio VaR (95%) limit"),
            RiskLimit("CVAR_95_LIMIT", LimitMetric.CVAR, 0.20, LimitType.HARD, "critical", "Portfolio CVaR (95%) limit"),
            RiskLimit("VOLATILITY_LIMIT", LimitMetric.VOLATILITY, 0.25, LimitType.SOFT, "high", "Portfolio volatilite limiti"),
            RiskLimit("DRAWDOWN_LIMIT", LimitMetric.DRAWDOWN, 0.15, LimitType.SOFT, "high", "Maksimum çekilme limiti"),
            RiskLimit("CONCENTRATION_LIMIT", LimitMetric.CONCENTRATION, 0.05, LimitType.WARNING, "medium", "Pozisyon konsantrasyon limiti"),
            RiskLimit("CORRELATION_LIMIT", LimitMetric.CORRELATION, 0.80, LimitType.WARNING, "medium", "Korelasyon limiti")
        ]
        
        for limit in default_limits:
            self.risk_limits[limit.limit_id] = limit
    
    def check_limits(self, risk_metrics: Dict) -> Dict:
        """Risk limitlerini kontrol et"""
        
        violations = []
        warnings = []
        
        for limit_id, limit in self.risk_limits.items():
            metric_value = risk_metrics.get(limit.metric.value, 0)
            
            # Limit kullanımını güncelle
            limit.current_usage = metric_value
            limit.utilization_rate = metric_value / limit.limit_value if limit.limit_value > 0 else 0
            
            # Kontrol
            if limit.limit_type == LimitType.HARD and metric_value > limit.limit_value:
                violations.append({
                    'limit_id': limit_id,
                    'metric': limit.metric.value,
                    'current_value': metric_value,
                    'limit_value': limit.limit_value,
                    'severity': limit.severity
                })
            elif limit.limit_type == LimitType.SOFT and metric_value > limit.limit_value * 0.9:
                warnings.append({
                    'limit_id': limit_id,
                    'metric': limit.metric.value,
                    'current_value': metric_value,
                    'limit_value': limit.limit_value,
                    'proximity': limit.utilization_rate
                })
            elif limit.limit_type == LimitType.WARNING and limit.utilization_rate > 0.7:
                warnings.append({
                    'limit_id': limit_id,
                    'metric': limit.metric.value,
                    'current_value': metric_value,
                    'limit_value': limit.limit_value,
                    'proximity': limit.utilization_rate
                })
        
        return {
            'violations': violations,
            'warnings': warnings,
            'overall_status': 'breach' if violations else 'warning' if warnings else 'compliant',
            'total_limits': len(self.risk_limits),
            'active_violations': len(violations),
            'active_warnings': len(warnings)
        }
    
    def update_dynamic_limits(self, market_conditions: Dict):
        """Dinamik limit güncelleme"""
        
        market_stress = market_conditions.get('market_stress', 0.5)
        volatility_regime = market_conditions.get('volatility_regime', 'normal')
        
        # Stres seviyesine göre limitleri ayarla
        for limit_id, limit in self.risk_limits.items():
            if limit.limit_type == LimitType.DYNAMIC or limit.metric in [LimitMetric.VAR, LimitMetric.CVAR]:
                if market_stress > 0.7:  # Yüksek stres
                    limit.limit_value *= 0.8  # %20 azalt
                elif market_stress < 0.3:  # Düşük stres
                    limit.limit_value *= 1.1  # %10 artır
        
        self.logger.info("Dinamik limitler güncellendi")
    
    def add_custom_limit(self, limit: RiskLimit):
        """Özel limit ekle"""
        self.risk_limits[limit.limit_id] = limit
        self.logger.info(f"Özel limit eklendi: {limit.limit_id}")
    
    def get_limit_status(self) -> Dict:
        """Limit durumu raporu"""
        
        return {
            'total_limits': len(self.risk_limits),
            'limit_summary': {
                limit_id: {
                    'metric': limit.metric.value,
                    'limit_value': limit.limit_value,
                    'current_usage': limit.current_usage,
                    'utilization_rate': limit.utilization_rate,
                    'limit_type': limit.limit_type.value,
                    'severity': limit.severity
                }
                for limit_id, limit in self.risk_limits.items()
            }
        }