"""
Performance Metric Model Sınıfı

Risk-ayarlı performans metriklerini hesaplayan model.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from enum import Enum
from dataclasses import dataclass
from scipy import stats

class MetricType(Enum):
    """Performans metrik türleri"""
    RETURN = "return"
    RISK_ADJUSTED = "risk_adjusted"
    DOWNSIDE = "downside"
    ATTRIBUTION = "attribution"

@dataclass
class PerformanceMetric:
    """Performans metrik sonucu"""
    metric_name: str
    value: float
    description: str
    category: MetricType
    benchmark_comparison: Optional[float] = None
    percentile_rank: Optional[float] = None

class PerformanceMetricModel:
    """
    Performans Metrik Hesaplama Modeli
    
    Risk-ayarlı performans metriklerini hesaplar ve değerlendirir.
    """
    
    def __init__(self, config=None):
        """Performance Metric Modelini başlat"""
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Varsayılan parametreler
        self.risk_free_rate = 0.02  # %2 yıllık
        self.annualization_factor = 252  # Trading days per year
        
        self.logger.info("Performance Metric Modeli başlatıldı")
    
    def calculate_performance_metrics(self, 
                                    returns: pd.Series,
                                    benchmark_returns: Optional[pd.Series] = None) -> Dict:
        """Kapsamlı performans metrikleri hesapla"""
        
        try:
            self.logger.info("Performans metrikleri hesaplanıyor...")
            
            if returns.empty:
                return {'error': 'Boş getiri serisi'}
            
            # Temel metrikler
            basic_metrics = self._calculate_basic_metrics(returns)
            
            # Risk-ayarlı metrikler
            risk_adjusted_metrics = self._calculate_risk_adjusted_metrics(returns, benchmark_returns)
            
            # Downside metrikler
            downside_metrics = self._calculate_downside_metrics(returns)
            
            # Benchmark karşılaştırması
            benchmark_comparison = {}
            if benchmark_returns is not None:
                benchmark_comparison = self._calculate_benchmark_comparison(returns, benchmark_returns)
            
            return {
                'timestamp': datetime.now().isoformat(),
                'basic_metrics': basic_metrics,
                'risk_adjusted_metrics': risk_adjusted_metrics,
                'downside_metrics': downside_metrics,
                'benchmark_comparison': benchmark_comparison,
                'overall_score': self._calculate_overall_score(basic_metrics, risk_adjusted_metrics)
            }
            
        except Exception as e:
            self.logger.error(f"Performans metrikleri hatası: {str(e)}")
            return {'error': str(e)}
    
    def _calculate_basic_metrics(self, returns: pd.Series) -> Dict:
        """Temel performans metrikleri"""
        
        # Toplam getiri
        total_return = (1 + returns).prod() - 1
        
        # Yıllıklandırılmış getiri
        n_years = len(returns) / self.annualization_factor
        annualized_return = (1 + total_return) ** (1 / n_years) - 1 if n_years > 0 else 0
        
        # Volatilite
        volatility = returns.std() * np.sqrt(self.annualization_factor)
        
        # Win rate
        win_rate = (returns > 0).sum() / len(returns)
        
        # En iyi/en kötü gün
        best_day = returns.max()
        worst_day = returns.min()
        
        return {
            'total_return': total_return,
            'annualized_return': annualized_return,
            'volatility': volatility,
            'win_rate': win_rate,
            'best_day': best_day,
            'worst_day': worst_day,
            'avg_daily_return': returns.mean()
        }
    
    def _calculate_risk_adjusted_metrics(self, 
                                       returns: pd.Series,
                                       benchmark_returns: Optional[pd.Series] = None) -> Dict:
        """Risk-ayarlı performans metrikleri"""
        
        # Sharpe ratio
        excess_returns = returns - self.risk_free_rate / self.annualization_factor
        sharpe_ratio = excess_returns.mean() / excess_returns.std() * np.sqrt(self.annualization_factor) if excess_returns.std() > 0 else 0
        
        # Sortino ratio
        downside_returns = np.minimum(returns, 0)
        downside_deviation = np.sqrt((downside_returns ** 2).mean()) * np.sqrt(self.annualization_factor)
        sortino_ratio = excess_returns.mean() * self.annualization_factor / downside_deviation if downside_deviation > 0 else 0
        
        # Calmar ratio (max drawdown ile)
        cumulative_returns = (1 + returns).cumprod()
        running_max = cumulative_returns.expanding().max()
        drawdown = (cumulative_returns - running_max) / running_max
        max_drawdown = abs(drawdown.min())
        
        calmar_ratio = annualized_return / max_drawdown if max_drawdown > 0 else 0
        
        # Information ratio (benchmark varsa)
        information_ratio = 0
        beta = 0
        alpha = 0
        tracking_error = 0
        
        if benchmark_returns is not None and len(benchmark_returns) == len(returns):
            # Alpha ve beta
            beta = np.corrcoef(returns, benchmark_returns)[0, 1] * (returns.std() / benchmark_returns.std()) if benchmark_returns.std() > 0 else 0
            
            # Jensen's Alpha
            market_expected_return = benchmark_returns.mean() * self.annualization_factor
            alpha = excess_returns.mean() * self.annualization_factor - beta * market_expected_return
            
            # Information ratio
            active_returns = returns - benchmark_returns
            tracking_error = active_returns.std() * np.sqrt(self.annualization_factor)
            
            if tracking_error > 0:
                information_ratio = active_returns.mean() * self.annualization_factor / tracking_error
        
        # Treynor ratio
        treynor_ratio = excess_returns.mean() * self.annualization_factor / beta if beta != 0 else 0
        
        return {
            'sharpe_ratio': sharpe_ratio,
            'sortino_ratio': sortino_ratio,
            'calmar_ratio': calmar_ratio,
            'information_ratio': information_ratio,
            'jensen_alpha': alpha,
            'beta': beta,
            'treynor_ratio': treynor_ratio,
            'tracking_error': tracking_error
        }
    
    def _calculate_downside_metrics(self, returns: pd.Series) -> Dict:
        """Downside risk metrikleri"""
        
        # VaR ve CVaR
        var_95 = np.percentile(returns, 5)
        var_99 = np.percentile(returns, 1)
        
        cvar_95 = returns[returns <= var_95].mean() if len(returns[returns <= var_95]) > 0 else var_95
        cvar_99 = returns[returns <= var_99].mean() if len(returns[returns <= var_99]) > 0 else var_99
        
        # Downside deviation
        downside_returns = np.minimum(returns, 0)
        downside_deviation = np.sqrt((downside_returns ** 2).mean()) * np.sqrt(self.annualization_factor)
        
        # Drawdown metrikleri
        cumulative_returns = (1 + returns).cumprod()
        running_max = cumulative_returns.expanding().max()
        drawdowns = (cumulative_returns - running_max) / running_max
        
        avg_drawdown = abs(drawdowns[drawdowns < 0].mean()) if (drawdowns < 0).any() else 0
        
        # Recovery time (basitleştirilmiş)
        recovery_periods = []
        in_drawdown = False
        drawdown_start = 0
        
        for i, dd in enumerate(drawdowns):
            if dd < 0 and not in_drawdown:
                in_drawdown = True
                drawdown_start = i
            elif dd >= 0 and in_drawdown:
                in_drawdown = False
                recovery_periods.append(i - drawdown_start)
        
        avg_recovery_time = np.mean(recovery_periods) if recovery_periods else 0
        
        return {
            'var_95': abs(var_95),
            'var_99': abs(var_99),
            'cvar_95': abs(cvar_95),
            'cvar_99': abs(cvar_99),
            'downside_deviation': downside_deviation,
            'max_drawdown': abs(drawdowns.min()),
            'average_drawdown': avg_drawdown,
            'average_recovery_time': avg_recovery_time
        }
    
    def _calculate_benchmark_comparison(self, 
                                     returns: pd.Series,
                                     benchmark_returns: pd.Series) -> Dict:
        """Benchmark karşılaştırması"""
        
        try:
            # Getirileri hizala
            aligned_data = pd.concat([returns, benchmark_returns], axis=1).dropna()
            aligned_data.columns = ['portfolio', 'benchmark']
            
            if aligned_data.empty:
                return {}
            
            portfolio_returns = aligned_data['portfolio']
            benchmark_returns = aligned_data['benchmark']
            
            # Relative performance
            portfolio_total = (1 + portfolio_returns).prod() - 1
            benchmark_total = (1 + benchmark_returns).prod() - 1
            relative_performance = portfolio_total - benchmark_total
            
            # Correlation
            correlation = portfolio_returns.corr(benchmark_returns)
            
            # Active returns ve tracking error
            active_returns = portfolio_returns - benchmark_returns
            tracking_error = active_returns.std() * np.sqrt(self.annualization_factor)
            
            # Hit ratio
            hit_ratio = (active_returns > 0).sum() / len(active_returns)
            
            # R-squared
            r_squared = correlation ** 2
            
            return {
                'relative_performance': relative_performance,
                'correlation': correlation,
                'r_squared': r_squared,
                'tracking_error': tracking_error,
                'hit_ratio': hit_ratio,
                'outperformance_periods': (active_returns > 0).sum(),
                'total_periods': len(active_returns)
            }
            
        except Exception as e:
            self.logger.error(f"Benchmark karşılaştırma hatası: {str(e)}")
            return {}
    
    def _calculate_overall_score(self, basic_metrics: Dict, risk_adjusted_metrics: Dict) -> Dict:
        """Genel performans skoru"""
        
        # Komponent skorları (0-100)
        return_score = min(basic_metrics['annualized_return'] * 200, 100)  # 50% getiri = 100 puan
        
        risk_score = max(100 - risk_adjusted_metrics['sharpe_ratio'] * 30, 0)  # 3+ Sharpe = 0 puan
        
        consistency_score = basic_metrics['win_rate'] * 100  # Win rate directly
        
        # Sharpe score
        sharpe_score = min(risk_adjusted_metrics['sharpe_ratio'] * 25, 100)  # 4+ Sharpe = 100 puan
        
        # Ağırlıklı genel skor
        weights = {
            'return': 0.25,
            'risk': 0.25,
            'consistency': 0.25,
            'sharpe': 0.25
        }
        
        overall_score = (
            return_score * weights['return'] +
            risk_score * weights['risk'] +
            consistency_score * weights['consistency'] +
            sharpe_score * weights['sharpe']
        )
        
        # Rating
        if overall_score >= 85:
            rating = 'A+'
        elif overall_score >= 75:
            rating = 'A'
        elif overall_score >= 65:
            rating = 'B'
        elif overall_score >= 55:
            rating = 'C'
        else:
            rating = 'D'
        
        return {
            'overall_score': overall_score,
            'rating': rating,
            'component_scores': {
                'return_score': return_score,
                'risk_score': risk_score,
                'consistency_score': consistency_score,
                'sharpe_score': sharpe_score
            }
        }
    
    def get_rolling_performance(self, 
                              returns: pd.Series,
                              window: int = 60) -> Dict:
        """Rolling performans metrikleri"""
        
        if len(returns) < window:
            return {'error': 'Yetersiz veri'}
        
        rolling_returns = returns.rolling(window=window)
        
        # Rolling Sharpe ratio
        rolling_mean = rolling_returns.mean() * self.annualization_factor
        rolling_std = rolling_returns.std() * np.sqrt(self.annualization_factor)
        rolling_sharpe = rolling_mean / rolling_std
        
        # Rolling max drawdown
        rolling_cumulative = (1 + rolling_returns.cumsum()).cumprod()
        rolling_max = rolling_cumulative.expanding().max()
        rolling_dd = (rolling_cumulative - rolling_max) / rolling_max
        rolling_max_dd = rolling_dd.min()
        
        return {
            'window_size': window,
            'current_sharpe': rolling_sharpe.iloc[-1] if not rolling_sharpe.empty else 0,
            'max_sharpe': rolling_sharpe.max() if not rolling_sharpe.empty else 0,
            'min_sharpe': rolling_sharpe.min() if not rolling_sharpe.empty else 0,
            'current_max_drawdown': rolling_max_dd,
            'sharpe_volatility': rolling_sharpe.std() if not rolling_sharpe.empty else 0
        }
    
    def compare_strategies(self, strategy_returns: Dict[str, pd.Series]) -> Dict:
        """Stratejileri karşılaştır"""
        
        if not strategy_returns:
            return {'error': 'Strateji verisi yok'}
        
        comparison_results = {}
        
        for strategy_name, returns in strategy_returns.items():
            metrics = self.calculate_performance_metrics(returns)
            comparison_results[strategy_name] = {
                'sharpe_ratio': metrics['risk_adjusted_metrics']['sharpe_ratio'],
                'annualized_return': metrics['basic_metrics']['annualized_return'],
                'max_drawdown': abs(metrics['downside_metrics']['max_drawdown']),
                'overall_score': metrics['overall_score']['overall_score'],
                'rating': metrics['overall_score']['rating']
            }
        
        # Ranking
        sorted_strategies = sorted(
            comparison_results.items(),
            key=lambda x: x[1]['overall_score'],
            reverse=True
        )
        
        for i, (strategy_name, metrics) in enumerate(sorted_strategies):
            metrics['rank'] = i + 1
        
        return {
            'strategy_comparison': comparison_results,
            'ranked_strategies': dict(sorted_strategies),
            'best_strategy': sorted_strategies[0][0] if sorted_strategies else None,
            'worst_strategy': sorted_strategies[-1][0] if sorted_strategies else None
        }