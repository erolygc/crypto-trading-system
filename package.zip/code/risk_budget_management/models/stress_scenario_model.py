"""
Stress Scenario Model Sınıfı

Stres testi senaryolarını yöneten model.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from enum import Enum
from dataclasses import dataclass

class ScenarioType(Enum):
    """Stres senaryo türleri"""
    HISTORICAL = "historical"
    HYPOTHETICAL = "hypothetical"
    MONTE_CARLO = "monte_carlo"
    PARAMETRIC = "parametric"

@dataclass
class StressScenario:
    """Stres senaryosu"""
    scenario_id: str
    name: str
    scenario_type: ScenarioType
    severity_level: str
    market_shocks: Dict[str, float]
    correlation_changes: Dict[str, Dict[str, float]]
    probability: float
    time_horizon: int
    description: str

class StressScenarioModel:
    """
    Stres Senaryo Yönetimi Modeli
    
    Stres testi senaryolarını yönetir ve çalıştırır.
    """
    
    def __init__(self, config=None):
        """Stress Scenario Modelini başlat"""
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        self.scenarios = {}
        self.test_results = []
        
        self._load_default_scenarios()
        self.logger.info("Stress Scenario Modeli başlatıldı")
    
    def _load_default_scenarios(self):
        """Varsayılan stres senaryolarını yükle"""
        
        scenarios = [
            StressScenario(
                scenario_id="GFC_2008",
                name="2008 Global Finansal Krizi",
                scenario_type=ScenarioType.HISTORICAL,
                severity_level="extreme",
                market_shocks={
                    'equity': -0.40,
                    'fixed_income': 0.10,
                    'commodities': -0.25,
                    'credit': -0.35
                },
                correlation_changes={},
                probability=0.02,
                time_horizon=30,
                description="2008 küresel finansal krizini taklit eden senaryo"
            ),
            StressScenario(
                scenario_id="RECESSION_DEEP",
                name="Derin Ekonomik Resesyon",
                scenario_type=ScenarioType.HYPOTHETICAL,
                severity_level="high",
                market_shocks={
                    'equity': -0.30,
                    'fixed_income': 0.15,
                    'commodities': -0.35,
                    'credit': -0.40
                },
                correlation_changes={
                    ('equity', 'credit'): 0.9,
                    ('equity', 'alternatives'): 0.7
                },
                probability=0.03,
                time_horizon=45,
                description="Derin ekonomik resesyon senaryosu"
            ),
            StressScenario(
                scenario_id="VOLATILITY_SPIKE",
                name="Volatilite Patlaması",
                scenario_type=ScenarioType.MONTE_CARLO,
                severity_level="medium",
                market_shocks={
                    'equity': -0.20,
                    'fixed_income': 0.05,
                    'commodities': -0.15,
                    'credit': -0.25
                },
                correlation_changes={},
                probability=0.10,
                time_horizon=10,
                description="Piyasa volatilitesinde ani artış"
            )
        ]
        
        for scenario in scenarios:
            self.scenarios[scenario.scenario_id] = scenario
    
    def run_scenario(self, scenario_id: str, portfolio_data: Dict) -> Dict:
        """Belirli bir senaryoyu çalıştır"""
        
        if scenario_id not in self.scenarios:
            raise ValueError(f"Bilinmeyen senaryo: {scenario_id}")
        
        scenario = self.scenarios[scenario_id]
        
        # Portföy kompozisyonu
        portfolio_composition = portfolio_data.get('composition', {})
        
        # Portföy etkisini hesapla
        portfolio_impact = 0.0
        
        for asset_class, shock in scenario.market_shocks.items():
            weight = portfolio_composition.get(asset_class, 0.0)
            portfolio_impact += weight * shock
        
        # Sonuç oluştur
        result = {
            'scenario_id': scenario_id,
            'scenario_name': scenario.name,
            'scenario_type': scenario.scenario_type.value,
            'severity_level': scenario.severity_level,
            'portfolio_impact': portfolio_impact,
            'probability': scenario.probability,
            'time_horizon': scenario.time_horizon,
            'passed': portfolio_impact > -0.20,  # %20'den az kayıp = geçti
            'timestamp': datetime.now().isoformat()
        }
        
        # Sonuçları kaydet
        self.test_results.append(result)
        
        return result
    
    def run_all_scenarios(self, portfolio_data: Dict) -> Dict:
        """Tüm senaryoları çalıştır"""
        
        results = []
        passed_count = 0
        
        for scenario_id in self.scenarios.keys():
            try:
                result = self.run_scenario(scenario_id, portfolio_data)
                results.append(result)
                
                if result['passed']:
                    passed_count += 1
                    
            except Exception as e:
                self.logger.error(f"Senaryo çalıştırma hatası {scenario_id}: {str(e)}")
        
        return {
            'total_scenarios': len(results),
            'passed_scenarios': passed_count,
            'success_rate': passed_count / len(results) if results else 0,
            'scenario_results': results,
            'timestamp': datetime.now().isoformat()
        }
    
    def add_scenario(self, scenario: StressScenario):
        """Yeni senaryo ekle"""
        self.scenarios[scenario.scenario_id] = scenario
        self.logger.info(f"Stres senaryosu eklendi: {scenario.scenario_id}")
    
    def get_scenario_summary(self) -> Dict:
        """Senaryo özeti"""
        
        summary = {
            'total_scenarios': len(self.scenarios),
            'scenario_types': {},
            'severity_levels': {},
            'average_probability': 0,
            'total_historical_scenarios': 0
        }
        
        probabilities = []
        
        for scenario in self.scenarios.values():
            # Tip dağılımı
            scenario_type = scenario.scenario_type.value
            summary['scenario_types'][scenario_type] = summary['scenario_types'].get(scenario_type, 0) + 1
            
            # Şiddet dağılımı
            severity = scenario.severity_level
            summary['severity_levels'][severity] = summary['severity_levels'].get(severity, 0) + 1
            
            # Ortalama olasılık
            probabilities.append(scenario.probability)
            
            # Tarihsel senaryo sayısı
            if scenario.scenario_type == ScenarioType.HISTORICAL:
                summary['total_historical_scenarios'] += 1
        
        # Ortalama olasılık hesapla
        if probabilities:
            summary['average_probability'] = sum(probabilities) / len(probabilities)
        
        return summary
    
    def get_test_history(self, days: int = 30) -> List[Dict]:
        """Test geçmişini al"""
        
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_results = [
            result for result in self.test_results 
            if datetime.fromisoformat(result['timestamp']) > cutoff_date
        ]
        
        return recent_results