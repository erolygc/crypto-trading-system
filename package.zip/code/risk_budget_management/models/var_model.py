"""
Value at Risk (VaR) Modeli

Farklı yöntemlerle VaR hesaplayan model sınıfı.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from enum import Enum
from dataclasses import dataclass
from scipy import stats
from scipy.optimize import minimize
import warnings
warnings.filterwarnings('ignore')

class VaRMethod(Enum):
    """VaR hesaplama yöntemleri"""
    HISTORICAL = "historical"
    PARAMETRIC = "parametric"
    MONTE_CARLO = "monte_carlo"
    EXTREME_VALUE = "extreme_value"
    CORNISH_FISHER = "cornish_fisher"

@dataclass
class VaRResult:
    """VaR hesaplama sonucu"""
    method: VaRMethod
    confidence_level: float
    var_value: float
    confidence_interval: Tuple[float, float]
    backtest_passed: bool
    model_validation: Dict
    timestamp: datetime
    calculation_details: Dict

class VaRModel:
    """
    Value at Risk (VaR) Hesaplama Modeli
    
    Çeşitli yöntemlerle VaR hesaplar ve model doğrulaması yapar.
    """
    
    def __init__(self, config=None):
        """
        VaR Modelini başlat
        
        Args:
            config: Konfigürasyon parametreleri
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Model parametreleri
        self.default_confidence_levels = [0.95, 0.99]
        self.lookback_period = 252  # 1 yıl
        self.bootstrap_samples = 1000
        
        # Kalibrasyon parametreleri
        self.ewma_lambda = 0.94
        self.garch_p = 1
        self.garch_q = 1
        
        # Model doğrulama
        self.backtest_window = 252
        self.confidence_intervals = {}
        
        self.logger.info("VaR Modeli başlatıldı")
    
    def calculate_var(self, 
                     returns: pd.Series,
                     confidence_level: float = 0.95,
                     method: VaRMethod = VaRMethod.HISTORICAL,
                     **kwargs) -> VaRResult:
        """
        VaR hesapla
        
        Args:
            returns: Getiri serisi
            confidence_level: Güven seviyesi
            method: Hesaplama yöntemi
            **kwargs: Ek parametreler
            
        Returns:
            VaRResult: VaR hesaplama sonucu
        """
        
        try:
            self.logger.info(f"VaR hesaplanıyor - Yöntem: {method.value}, Güven: {confidence_level}")
            
            if returns.empty:
                raise ValueError("Boş getiri serisi")
            
            # Yönteme göre VaR hesapla
            if method == VaRMethod.HISTORICAL:
                var_result = self._calculate_historical_var(returns, confidence_level)
            elif method == VaRMethod.PARAMETRIC:
                var_result = self._calculate_parametric_var(returns, confidence_level)
            elif method == VaRMethod.MONTE_CARLO:
                var_result = self._calculate_monte_carlo_var(returns, confidence_level, **kwargs)
            elif method == VaRMethod.EXTREME_VALUE:
                var_result = self._calculate_extreme_value_var(returns, confidence_level)
            elif method == VaRMethod.CORNISH_FISHER:
                var_result = self._calculate_cornish_fisher_var(returns, confidence_level)
            else:
                raise ValueError(f"Bilinmeyen yöntem: {method}")
            
            # Güven aralığı hesapla
            confidence_interval = self._calculate_confidence_interval(returns, confidence_level, method)
            
            # Backtest yap
            backtest_passed = self._perform_backtest(returns, var_result.var_value, confidence_level)
            
            # Model doğrulaması
            model_validation = self._validate_model(returns, method)
            
            return VaRResult(
                method=method,
                confidence_level=confidence_level,
                var_value=var_result,
                confidence_interval=confidence_interval,
                backtest_passed=backtest_passed,
                model_validation=model_validation,
                timestamp=datetime.now(),
                calculation_details=self._get_calculation_details(method, confidence_level)
            )
            
        except Exception as e:
            self.logger.error(f"VaR hesaplama hatası: {str(e)}")
            raise
    
    def _calculate_historical_var(self, returns: pd.Series, confidence_level: float) -> float:
        """Tarihsel VaR hesaplama"""
        
        # Son n günlük veriler
        lookback_window = min(self.lookback_period, len(returns))
        recent_returns = returns.tail(lookback_window)
        
        # Percentile hesaplama
        var_value = np.percentile(recent_returns, (1 - confidence_level) * 100)
        
        return abs(var_value)  # Pozitif değer olarak döndür
    
    def _calculate_parametric_var(self, returns: pd.Series, confidence_level: float) -> float:
        """Parametrik VaR hesaplama (Normal dağılım)"""
        
        # Normal dağılım parametreleri
        mean_return = returns.mean()
        std_return = returns.std()
        
        # Z-score
        alpha = 1 - confidence_level
        z_score = stats.norm.ppf(alpha)
        
        # VaR hesaplama ( parametrik formül)
        var_value = mean_return + z_score * std_return
        
        return abs(var_value)
    
    def _calculate_monte_carlo_var(self, 
                                 returns: pd.Series, 
                                 confidence_level: float,
                                 simulations: int = 10000) -> float:
        """Monte Carlo VaR hesaplama"""
        
        # Parametreleri tahmin et
        mean_return = returns.mean()
        std_return = returns.std()
        
        # Simülasyon
        simulated_returns = np.random.normal(
            mean_return, 
            std_return, 
            simulations
        )
        
        # VaR hesaplama
        var_value = np.percentile(simulated_returns, (1 - confidence_level) * 100)
        
        return abs(var_value)
    
    def _calculate_extreme_value_var(self, returns: pd.Series, confidence_level: float) -> float:
        """Extreme Value Theory (EVT) bazlı VaR"""
        
        # Peak-over-Threshold (POT) yöntemi
        threshold = np.percentile(returns, 10)  # Alt %10 threshold
        
        # Threshold üstü değerler
        tail_returns = returns[returns < threshold]
        
        if len(tail_returns) < 10:
            # Yeterli veri yoksa normal yönteme dön
            return self._calculate_historical_var(returns, confidence_level)
        
        # Generalized Pareto Distribution parametreleri
        # Basitleştirilmiş tahmin
        shape_param = 0.2  # Tail indeksi (varsayılan)
        scale_param = tail_returns.std()  # Scale parametresi
        
        # EVT VaR hesaplama
        n_exceedances = len(tail_returns)
        n_total = len(returns)
        
        # GPD quantile
        u = threshold
        p = (1 - confidence_level) * n_total / n_exceedances
        
        if p <= 0 or p >= 1:
            return self._calculate_historical_var(returns, confidence_level)
        
        # GPD quantile function (basitleştirilmiş)
        if shape_param != 0:
            var_value = u + (scale_param / shape_param) * ((1 - p) ** (-shape_param) - 1)
        else:
            var_value = u + scale_param * np.log(1 - p)
        
        return abs(var_value)
    
    def _calculate_cornish_fisher_var(self, returns: pd.Series, confidence_level: float) -> float:
        """Cornish-Fisher expansions ile VaR"""
        
        # Moment hesaplamaları
        mean_return = returns.mean()
        std_return = returns.std()
        
        # Higher moments
        skewness = stats.skew(returns)
        kurtosis = stats.kurtosis(returns)
        
        # Normal VaR
        alpha = 1 - confidence_level
        z_score = stats.norm.ppf(alpha)
        
        # Cornish-Fisher düzeltmesi
        cf_correction = (z_score + 
                        (z_score**2 - 1) * skewness / 6 +
                        (z_score**3 - 3*z_score) * kurtosis / 24 -
                        (2*z_score**3 - 5*z_score) * (skewness**2) / 36)
        
        # Düzeltilmiş VaR
        var_value = mean_return + cf_correction * std_return
        
        return abs(var_value)
    
    def _calculate_confidence_interval(self, 
                                     returns: pd.Series, 
                                     confidence_level: float, 
                                     method: VaRMethod) -> Tuple[float, float]:
        """VaR güven aralığı hesapla"""
        
        # Bootstrap ile güven aralığı
        n_bootstrap = 100
        bootstrap_vars = []
        
        for _ in range(n_bootstrap):
            # Bootstrap sample
            bootstrap_sample = np.random.choice(returns, size=len(returns), replace=True)
            
            # VaR hesapla
            bootstrap_var = self.calculate_var(
                pd.Series(bootstrap_sample), 
                confidence_level, 
                method
            )
            bootstrap_vars.append(bootstrap_var.var_value)
        
        # Güven aralığı
        lower_bound = np.percentile(bootstrap_vars, 2.5)
        upper_bound = np.percentile(bootstrap_vars, 97.5)
        
        return (lower_bound, upper_bound)
    
    def _perform_backtest(self, 
                         returns: pd.Series, 
                         var_value: float, 
                         confidence_level: float) -> bool:
        """VaR backtest (Kupiec testi)"""
        
        try:
            if len(returns) < self.backtest_window:
                return True  # Yeterli veri yoksa geç
            
            # Rolling VaR backtest
            violations = 0
            total_observations = 0
            
            for i in range(self.backtest_window, len(returns)):
                # Geçmiş verilerle VaR hesapla
                history = returns.iloc[:i]
                current_var = self.calculate_var(history, confidence_level, VaRMethod.HISTORICAL)
                
                # Mevcut getiri VaR'ı aştı mı?
                if returns.iloc[i] < -current_var.var_value:
                    violations += 1
                
                total_observations += 1
            
            # Kupiec testi
            expected_violations = total_observations * (1 - confidence_level)
            
            # Chi-square test
            if expected_violations > 0:
                test_statistic = ((violations - expected_violations) ** 2) / expected_violations
                critical_value = stats.chi2.ppf(0.95, 1)  # 95% güven
                
                backtest_passed = test_statistic <= critical_value
            else:
                backtest_passed = True
            
            return backtest_passed
            
        except Exception as e:
            self.logger.error(f"Backtest hatası: {str(e)}")
            return True  # Hata durumunda geç
    
    def _validate_model(self, returns: pd.Series, method: VaRMethod) -> Dict:
        """Model doğrulaması"""
        
        validation_results = {
            'data_sufficiency': True,
            'stationarity_test': True,
            'normality_test': True,
            'autocorrelation_test': True,
            'overall_validity': True
        }
        
        try:
            # Veri yeterliliği
            if len(returns) < 100:
                validation_results['data_sufficiency'] = False
            
            # Stationarity test (ADF)
            from statsmodels.tsa.stattools import adfuller
            adf_stat, adf_pvalue = adfuller(returns.dropna())
            validation_results['stationarity_test'] = adf_pvalue < 0.05
            
            # Normality test
            jb_stat, jb_pvalue = stats.jarque_bera(returns.dropna())
            validation_results['normality_test'] = jb_pvalue > 0.05
            
            # Autocorrelation test
            from statsmodels.stats.diagnostic import acorr_ljungbox
            ljung_result = acorr_ljungbox(returns.dropna(), lags=10, return_df=True)
            validation_results['autocorrelation_test'] = ljung_result['lb_pvalue'].min() > 0.05
            
            # Genel geçerlilik
            validation_results['overall_validity'] = all([
                validation_results['data_sufficiency'],
                validation_results['stationarity_test'],
                validation_results['autocorrelation_test']
            ])
            
        except Exception as e:
            self.logger.error(f"Model doğrulama hatası: {str(e)}")
        
        return validation_results
    
    def _get_calculation_details(self, method: VaRMethod, confidence_level: float) -> Dict:
        """Hesaplama detayları"""
        
        return {
            'method': method.value,
            'confidence_level': confidence_level,
            'lookback_period': self.lookback_period,
            'ewma_lambda': self.ewma_lambda,
            'calculation_timestamp': datetime.now().isoformat()
        }
    
    def calculate_portfolio_var(self, 
                              portfolio_weights: np.ndarray,
                              asset_returns: pd.DataFrame,
                              confidence_level: float = 0.95,
                              method: VaRMethod = VaRMethod.PARAMETRIC) -> VaRResult:
        """
        Portföy VaR hesapla
        
        Args:
            portfolio_weights: Portföy ağırlıkları
            asset_returns: Asset getiri matrisi
            confidence_level: Güven seviyesi
            method: Hesaplama yöntemi
            
        Returns:
            VaRResult: Portföy VaR sonucu
        """
        
        try:
            if len(portfolio_weights) != len(asset_returns.columns):
                raise ValueError("Ağırlık sayısı asset sayısı ile uyuşmuyor")
            
            # Portföy getirilerini hesapla
            portfolio_returns = (asset_returns * portfolio_weights).sum(axis=1)
            
            # VaR hesapla
            var_result = self.calculate_var(portfolio_returns, confidence_level, method)
            
            return var_result
            
        except Exception as e:
            self.logger.error(f"Portföy VaR hesaplama hatası: {str(e)}")
            raise
    
    def calculate_component_var(self, 
                              portfolio_weights: np.ndarray,
                              asset_returns: pd.DataFrame,
                              confidence_level: float = 0.95) -> Dict:
        """
        Bileşen VaR katkıları hesapla
        
        Args:
            portfolio_weights: Portföy ağırlıkları
            asset_returns: Asset getiri matrisi
            confidence_level: Güven seviyesi
            
        Returns:
            Dict: Bileşen VaR katkıları
        """
        
        try:
            # Portfolio VaR
            portfolio_var = self.calculate_portfolio_var(
                portfolio_weights, asset_returns, confidence_level
            )
            
            # Covariance matrix
            cov_matrix = asset_returns.cov().values
            
            # Marginal VaR contributions
            portfolio_std = np.sqrt(np.dot(portfolio_weights, np.dot(cov_matrix, portfolio_weights)))
            marginal_contribs = np.dot(cov_matrix, portfolio_weights) / portfolio_std
            
            # Component VaR contributions
            component_vars = portfolio_weights * marginal_contribs * portfolio_var.var_value
            
            # Normalize
            component_var_percentages = component_vars / portfolio_var.var_value if portfolio_var.var_value > 0 else np.zeros_like(component_vars)
            
            return {
                'portfolio_var': portfolio_var.var_value,
                'component_vars': component_vars,
                'component_percentages': component_var_percentages,
                'total_components': np.sum(component_vars),
                'asset_names': list(asset_returns.columns)
            }
            
        except Exception as e:
            self.logger.error(f"Bileşen VaR hesaplama hatası: {str(e)}")
            return {}
    
    def stress_test_var(self, 
                      returns: pd.Series,
                      stress_scenarios: Dict[str, Dict],
                      confidence_level: float = 0.95) -> Dict:
        """
        VaR stress testi
        
        Args:
            returns: Getiri serisi
            stress_scenarios: Stres senaryoları
            confidence_level: Güven seviyesi
            
        Returns:
            Dict: Stress test sonuçları
        """
        
        stress_results = {}
        
        try:
            # Normal VaR
            normal_var = self.calculate_var(returns, confidence_level, VaRMethod.HISTORICAL)
            stress_results['normal_var'] = normal_var.var_value
            
            # Her senaryo için VaR hesapla
            for scenario_name, scenario_params in stress_scenarios.items():
                # Senaryo uygula
                stressed_returns = self._apply_stress_scenario(returns, scenario_params)
                
                # Stresli VaR
                stressed_var = self.calculate_var(stressed_returns, confidence_level, VaRMethod.HISTORICAL)
                
                stress_results[scenario_name] = {
                    'var': stressed_var.var_value,
                    'increase_ratio': stressed_var.var_value / normal_var.var_value,
                    'scenario_params': scenario_params
                }
            
            return stress_results
            
        except Exception as e:
            self.logger.error(f"VaR stress test hatası: {str(e)}")
            return {'error': str(e)}
    
    def _apply_stress_scenario(self, returns: pd.Series, scenario_params: Dict) -> pd.Series:
        """Stres senaryosunu uygula"""
        
        stressed_returns = returns.copy()
        
        # Mean shift
        if 'mean_shift' in scenario_params:
            stressed_returns += scenario_params['mean_shift']
        
        # Volatility increase
        if 'volatility_multiplier' in scenario_params:
            stressed_returns *= scenario_params['volatility_multiplier']
        
        # Skewness/kurtosis adjustment
        if 'skewness_adjustment' in scenario_params:
            # Basit skewness adjustment
            stressed_returns = stressed_returns * (1 + scenario_params['skewness_adjustment'])
        
        return stressed_returns
    
    def get_model_comparison(self, returns: pd.Series) -> Dict:
        """Farklı VaR yöntemlerini karşılaştır"""
        
        comparison_results = {}
        
        try:
            confidence_levels = [0.95, 0.99]
            
            for confidence_level in confidence_levels:
                level_results = {}
                
                for method in VaRMethod:
                    try:
                        var_result = self.calculate_var(returns, confidence_level, method)
                        level_results[method.value] = {
                            'var': var_result.var_value,
                            'backtest_passed': var_result.backtest_passed,
                            'confidence_interval': var_result.confidence_interval
                        }
                    except Exception as e:
                        level_results[method.value] = {'error': str(e)}
                
                comparison_results[f'confidence_{confidence_level}'] = level_results
            
            return comparison_results
            
        except Exception as e:
            self.logger.error(f"Model karşılaştırma hatası: {str(e)}")
            return {'error': str(e)}