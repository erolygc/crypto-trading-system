"""
Conditional Value at Risk (CVaR) Modeli

Expected Shortfall olarak da bilinen CVaR hesaplayan model sınıfı.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from enum import Enum
from dataclasses import dataclass
from scipy import stats
from scipy.optimize import minimize
import warnings
warnings.filterwarnings('ignore')

class CVaRMethod(Enum):
    """CVaR hesaplama yöntemleri"""
    HISTORICAL = "historical"
    PARAMETRIC_NORMAL = "parametric_normal"
    PARAMETRIC_T = "parametric_t"
    MONTE_CARLO = "monte_carlo"
    EXTREME_VALUE = "extreme_value"
    DISTRIBUTION_FITTING = "distribution_fitting"

@dataclass
class CVaRResult:
    """CVaR hesaplama sonucu"""
    method: CVaRMethod
    confidence_level: float
    cvar_value: float
    var_value: float
    tail_expectation: float
    conditional_expectation: float
    calculation_details: Dict
    timestamp: datetime

class CVaRModel:
    """
    Conditional Value at Risk (CVaR) Hesaplama Modeli
    
    Expected Shortfall olarak da bilinen CVaR'ı çeşitli yöntemlerle hesaplar.
    """
    
    def __init__(self, config=None):
        """
        CVaR Modelini başlat
        
        Args:
            config: Konfigürasyon parametreleri
        """
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Model parametreleri
        self.default_confidence_levels = [0.95, 0.99]
        self.lookback_period = 252
        self.bootstrap_samples = 1000
        
        # Dağılım parametreleri
        self.t_distribution_df = 5  # Student-t degrees of freedom
        
        self.logger.info("CVaR Modeli başlatıldı")
    
    def calculate_cvar(self, 
                      returns: pd.Series,
                      confidence_level: float = 0.95,
                      method: CVaRMethod = CVaRMethod.HISTORICAL,
                      **kwargs) -> CVaRResult:
        """
        CVaR hesapla
        
        Args:
            returns: Getiri serisi
            confidence_level: Güven seviyesi
            method: Hesaplama yöntemi
            **kwargs: Ek parametreler
            
        Returns:
            CVaRResult: CVaR hesaplama sonucu
        """
        
        try:
            self.logger.info(f"CVaR hesaplanıyor - Yöntem: {method.value}, Güven: {confidence_level}")
            
            if returns.empty:
                raise ValueError("Boş getiri serisi")
            
            # Yönteme göre CVaR hesapla
            if method == CVaRMethod.HISTORICAL:
                cvar_result = self._calculate_historical_cvar(returns, confidence_level)
            elif method == CVaRMethod.PARAMETRIC_NORMAL:
                cvar_result = self._calculate_parametric_normal_cvar(returns, confidence_level)
            elif method == CVaRMethod.PARAMETRIC_T:
                cvar_result = self._calculate_parametric_t_cvar(returns, confidence_level)
            elif method == CVaRMethod.MONTE_CARLO:
                cvar_result = self._calculate_monte_carlo_cvar(returns, confidence_level, **kwargs)
            elif method == CVaRMethod.EXTREME_VALUE:
                cvar_result = self._calculate_extreme_value_cvar(returns, confidence_level)
            elif method == CVaRMethod.DISTRIBUTION_FITTING:
                cvar_result = self._calculate_distribution_fitting_cvar(returns, confidence_level)
            else:
                raise ValueError(f"Bilinmeyen yöntem: {method}")
            
            # VaR hesapla (CVaR ile birlikte)
            var_value = self._calculate_var_for_cvar(returns, confidence_level, method)
            
            return CVaRResult(
                method=method,
                confidence_level=confidence_level,
                cvar_value=cvar_result,
                var_value=var_value,
                tail_expectation=cvar_result,
                conditional_expectation=cvar_result,
                calculation_details=self._get_calculation_details(method, confidence_level),
                timestamp=datetime.now()
            )
            
        except Exception as e:
            self.logger.error(f"CVaR hesaplama hatası: {str(e)}")
            raise
    
    def _calculate_var_for_cvar(self, 
                               returns: pd.Series, 
                               confidence_level: float, 
                               method: CVaRMethod) -> float:
        """CVaR hesabı için VaR hesapla"""
        
        # Basit historical VaR
        lookback_window = min(self.lookback_period, len(returns))
        recent_returns = returns.tail(lookback_window)
        var_value = abs(np.percentile(recent_returns, (1 - confidence_level) * 100))
        
        return var_value
    
    def _calculate_historical_cvar(self, returns: pd.Series, confidence_level: float) -> float:
        """Tarihsel CVaR hesaplama"""
        
        # VaR hesapla
        var_threshold = np.percentile(returns, (1 - confidence_level) * 100)
        
        # VaR altındaki değerler (tail)
        tail_returns = returns[returns <= var_threshold]
        
        if len(tail_returns) == 0:
            return abs(var_threshold)
        
        # CVaR = Tail'in ortalaması
        cvar_value = abs(tail_returns.mean())
        
        return cvar_value
    
    def _calculate_parametric_normal_cvar(self, returns: pd.Series, confidence_level: float) -> float:
        """Normal dağılım parametrik CVaR"""
        
        # Normal dağılım parametreleri
        mean_return = returns.mean()
        std_return = returns.std()
        
        # VaR hesaplama
        alpha = 1 - confidence_level
        z_score = stats.norm.ppf(alpha)
        var_value = mean_return + z_score * std_return
        
        # Normal dağılım için CVaR formülü
        # CVaR = μ - σ * φ(z) / α
        # φ(z): standard normal density at z
        phi_z = stats.norm.pdf(z_score)
        cvar_value = -(mean_return + std_return * phi_z / alpha)
        
        return abs(cvar_value)
    
    def _calculate_parametric_t_cvar(self, returns: pd.Series, confidence_level: float) -> float:
        """Student-t dağılım parametrik CVaR"""
        
        # Student-t parametreleri tahmin et
        # Basit yaklaşım: degrees of freedom sabit alınır
        df = self.t_distribution_df
        
        # Mean ve std
        mean_return = returns.mean()
        std_return = returns.std()
        
        # t-dağılım quantile
        alpha = 1 - confidence_level
        t_quantile = stats.t.ppf(alpha, df)
        
        # t-dağılım density at quantile
        t_density = stats.t.pdf(t_quantile, df)
        
        # t-dağılım CVaR formülü
        cvar_value = -(mean_return + 
                      std_return * 
                      (1 / alpha) * 
                      (df + t_quantile**2) / (df - 1) * 
                      t_density)
        
        return abs(cvar_value)
    
    def _calculate_monte_carlo_cvar(self, 
                                  returns: pd.Series, 
                                  confidence_level: float,
                                  simulations: int = 10000) -> float:
        """Monte Carlo CVaR hesaplama"""
        
        # Parametreleri tahmin et
        mean_return = returns.mean()
        std_return = returns.std()
        
        # Normal dağılımdan örnekleme
        simulated_returns = np.random.normal(
            mean_return, 
            std_return, 
            simulations
        )
        
        # VaR hesaplama
        var_threshold = np.percentile(simulated_returns, (1 - confidence_level) * 100)
        
        # Tail değerler
        tail_returns = simulated_returns[simulated_returns <= var_threshold]
        
        # CVaR hesaplama
        if len(tail_returns) > 0:
            cvar_value = abs(tail_returns.mean())
        else:
            cvar_value = abs(var_threshold)
        
        return cvar_value
    
    def _calculate_extreme_value_cvar(self, returns: pd.Series, confidence_level: float) -> float:
        """Extreme Value Theory bazlı CVaR"""
        
        # POT (Peak-Over-Threshold) yaklaşımı
        threshold = np.percentile(returns, 10)  # Alt %10
        
        # Threshold altı değerler
        tail_data = returns[returns < threshold]
        
        if len(tail_data) < 10:
            return self._calculate_historical_cvar(returns, confidence_level)
        
        # Generalized Pareto Distribution fit
        from scipy.stats import genextreme
        
        # Basit yaklaşım: exceedances
        exceedances = threshold - tail_data
        
        # GPD parametreleri (basitleştirilmiş)
        shape_param = 0.2  # Tail index
        scale_param = exceedances.std()
        
        # CVaR hesaplama için exceedance rate
        n_exceedances = len(exceedances)
        n_total = len(returns)
        exceedance_rate = n_exceedances / n_total
        
        # GPD CVaR hesaplama
        alpha = 1 - confidence_level
        
        if exceedance_rate > alpha:
            # GPD tail quantile
            p = (alpha * n_total) / n_exceedances
            
            if shape_param != 0:
                var_u = threshold - (scale_param / shape_param) * ((1 - p) ** shape_param - 1)
            else:
                var_u = threshold - scale_param * np.log(1 - p)
            
            # Expected Shortfall hesaplama
            if shape_param != 0 and shape_param < 1:
                cvar_u = var_u + (scale_param / (1 - shape_param)) * (1 - (1 - p) ** (1 - shape_param))
            else:
                cvar_u = var_u + scale_param
            
            return abs(cvar_u)
        else:
            return self._calculate_historical_cvar(returns, confidence_level)
    
    def _calculate_distribution_fitting_cvar(self, returns: pd.Series, confidence_level: float) -> float:
        """Dağılım uydurma bazlı CVaR"""
        
        try:
            # Farklı dağılımları dene
            distributions = [
                stats.norm,
                stats.t,
                stats.skewnorm,
                stats.genextreme,
                stats.laplace
            ]
            
            best_aic = np.inf
            best_cvar = 0
            best_dist = stats.norm
            
            for dist in distributions:
                try:
                    # Dağılımı fit et
                    params = dist.fit(returns)
                    
                    # AIC hesapla (basitleştirilmiş)
                    log_likelihood = np.sum(dist.logpdf(returns, *params))
                    aic = -2 * log_likelihood + 2 * len(params)
                    
                    if aic < best_aic:
                        best_aic = aic
                        best_dist = dist
                        
                        # CVaR hesapla
                        if dist == stats.t:
                            # t-dağılım CVaR
                            cvar_value = self._calculate_parametric_t_cvar(returns, confidence_level)
                        elif dist == stats.norm:
                            # Normal dağılım CVaR
                            cvar_value = self._calculate_parametric_normal_cvar(returns, confidence_level)
                        else:
                            # Diğer dağılımlar için sayısal yöntem
                            cvar_value = self._calculate_numeric_cvar(returns, confidence_level, dist, params)
                        
                        best_cvar = cvar_value
                        
                except Exception:
                    continue
            
            return best_cvar
            
        except Exception as e:
            self.logger.warning(f"Dağılım uydurma başarısız, historical CVaR kullanılıyor: {str(e)}")
            return self._calculate_historical_cvar(returns, confidence_level)
    
    def _calculate_numeric_cvar(self, 
                              returns: pd.Series, 
                              confidence_level: float, 
                              dist, 
                              params) -> float:
        """Sayısal CVaR hesaplama"""
        
        try:
            # Percentile fonksiyonunu kullanarak VaR bul
            alpha = 1 - confidence_level
            var_value = dist.ppf(alpha, *params)
            
            # CVaR sayısal entegrasyon
            # CVaR = (1/α) * ∫_{-∞}^{VaR} x * f(x) dx
            # Basit yaklaşım: VaR altındaki değerlerin ortalaması
            
            # Distansın PDF'i
            x_range = np.linspace(var_value - 0.1, var_value, 1000)
            pdf_values = dist.pdf(x_range, *params)
            
            # Sayısal entegrasyon
            if np.trapz(pdf_values, x_range) > 0:
                cvar_numerator = np.trapz(x_range * pdf_values, x_range)
                cvar_denominator = alpha
                cvar_value = -(cvar_numerator / cvar_denominator) if cvar_denominator > 0 else abs(var_value)
            else:
                cvar_value = abs(var_value)
            
            return abs(cvar_value)
            
        except Exception:
            # Hata durumunda varsayılan değer
            return self._calculate_historical_cvar(returns, confidence_level)
    
    def calculate_portfolio_cvar(self, 
                               portfolio_weights: np.ndarray,
                               asset_returns: pd.DataFrame,
                               confidence_level: float = 0.95,
                               method: CVaRMethod = CVaRMethod.HISTORICAL) -> CVaRResult:
        """
        Portföy CVaR hesapla
        
        Args:
            portfolio_weights: Portföy ağırlıkları
            asset_returns: Asset getiri matrisi
            confidence_level: Güven seviyesi
            method: Hesaplama yöntemi
            
        Returns:
            CVaRResult: Portföy CVaR sonucu
        """
        
        try:
            if len(portfolio_weights) != len(asset_returns.columns):
                raise ValueError("Ağırlık sayısı asset sayısı ile uyuşmuyor")
            
            # Portföy getirilerini hesapla
            portfolio_returns = (asset_returns * portfolio_weights).sum(axis=1)
            
            # CVaR hesapla
            cvar_result = self.calculate_cvar(portfolio_returns, confidence_level, method)
            
            return cvar_result
            
        except Exception as e:
            self.logger.error(f"Portföy CVaR hesaplama hatası: {str(e)}")
            raise
    
    def calculate_incremental_cvar(self, 
                                 portfolio_weights: np.ndarray,
                                 asset_returns: pd.DataFrame,
                                 asset_index: int,
                                 confidence_level: float = 0.95) -> float:
        """
        Artımsal CVaR hesapla (incremental CVaR)
        
        Args:
            portfolio_weights: Mevcut portföy ağırlıkları
            asset_returns: Asset getiri matrisi
            asset_index: Eklenecek asset'in indeksi
            confidence_level: Güven seviyesi
            
        Returns:
            float: Artımsal CVaR değeri
        """
        
        try:
            # Mevcut portföy CVaR
            current_portfolio_cvar = self.calculate_portfolio_cvar(
                portfolio_weights, asset_returns, confidence_level
            )
            
            # Asset eklenmiş portföy
            new_weights = portfolio_weights.copy()
            if asset_index < len(new_weights):
                new_weights[asset_index] += 0.01  # %1 artış
            
            # Normalize et
            new_weights = new_weights / np.sum(new_weights)
            
            # Yeni portföy CVaR
            new_portfolio_cvar = self.calculate_portfolio_cvar(
                new_weights, asset_returns, confidence_level
            )
            
            # Incremental CVaR
            incremental_cvar = new_portfolio_cvar.cvar_value - current_portfolio_cvar.cvar_value
            
            return incremental_cvar
            
        except Exception as e:
            self.logger.error(f"Artımsal CVaR hesaplama hatası: {str(e)}")
            return 0.0
    
    def calculate_marginal_cvar(self, 
                              portfolio_weights: np.ndarray,
                              asset_returns: pd.DataFrame,
                              confidence_level: float = 0.95) -> np.ndarray:
        """
        Marjinal CVaR hesapla
        
        Args:
            portfolio_weights: Portföy ağırlıkları
            asset_returns: Asset getiri matrisi
            confidence_level: Güven seviyesi
            
        Returns:
            np.ndarray: Marjinal CVaR katkıları
        """
        
        try:
            n_assets = len(portfolio_weights)
            marginal_cvars = np.zeros(n_assets)
            epsilon = 0.001  # Küçük değişim
            
            # Temel portföy CVaR
            base_cvar = self.calculate_portfolio_cvar(
                portfolio_weights, asset_returns, confidence_level
            )
            
            # Her asset için marjinal CVaR
            for i in range(n_assets):
                # Ağırlığı epsilon kadar artır
                perturbed_weights = portfolio_weights.copy()
                perturbed_weights[i] += epsilon
                perturbed_weights = perturbed_weights / np.sum(perturbed_weights)
                
                # Yeni portföy CVaR
                perturbed_cvar = self.calculate_portfolio_cvar(
                    perturbed_weights, asset_returns, confidence_level
                )
                
                # Marjinal CVaR (sonlu farklar)
                marginal_cvars[i] = (perturbed_cvar.cvar_value - base_cvar.cvar_value) / epsilon
            
            return marginal_cvars
            
        except Exception as e:
            self.logger.error(f"Marjinal CVaR hesaplama hatası: {str(e)}")
            return np.zeros(len(portfolio_weights))
    
    def optimize_portfolio_for_cvar(self, 
                                  asset_returns: pd.DataFrame,
                                  target_return: float = 0.10,
                                  confidence_level: float = 0.95) -> np.ndarray:
        """
        CVaR optimize edilmiş portföy ağırlıkları
        
        Args:
            asset_returns: Asset getiri matrisi
            target_return: Hedef getiri
            confidence_level: Güven seviyesi
            
        Returns:
            np.ndarray: Optimize edilmiş ağırlıklar
        """
        
        try:
            n_assets = len(asset_returns.columns)
            
            # Objective function: minimize CVaR
            def objective(weights):
                try:
                    portfolio_cvar = self.calculate_portfolio_cvar(
                        weights, asset_returns, confidence_level
                    )
                    return portfolio_cvar.cvar_value
                except:
                    return 1e6  # Penalty for infeasible weights
            
            # Constraints
            def return_constraint(weights):
                portfolio_returns = (asset_returns * weights).sum(axis=1)
                return portfolio_returns.mean() - target_return
            
            def weight_sum_constraint(weights):
                return np.sum(weights) - 1.0
            
            # Bounds (long-only)
            bounds = [(0.0, 0.4) for _ in range(n_assets)]  # Max %40 per asset
            
            # Constraints list
            constraints = [
                {'type': 'eq', 'fun': weight_sum_constraint},
                {'type': 'ineq', 'fun': return_constraint}
            ]
            
            # Initial guess (equal weights)
            x0 = np.ones(n_assets) / n_assets
            
            # Optimize
            result = minimize(
                objective,
                x0,
                method='SLSQP',
                bounds=bounds,
                constraints=constraints,
                options={'maxiter': 1000}
            )
            
            if result.success:
                return result.x
            else:
                # Fallback to equal weights
                return np.ones(n_assets) / n_assets
            
        except Exception as e:
            self.logger.error(f"CVaR optimizasyon hatası: {str(e)}")
            return np.ones(len(asset_returns.columns)) / len(asset_returns.columns)
    
    def stress_test_cvar(self, 
                       returns: pd.Series,
                       stress_scenarios: Dict[str, Dict],
                       confidence_level: float = 0.95) -> Dict:
        """
        CVaR stress testi
        
        Args:
            returns: Getiri serisi
            stress_scenarios: Stres senaryoları
            confidence_level: Güven seviyesi
            
        Returns:
            Dict: Stress test sonuçları
        """
        
        stress_results = {}
        
        try:
            # Normal CVaR
            normal_cvar = self.calculate_cvar(returns, confidence_level, CVaRMethod.HISTORICAL)
            stress_results['normal_cvar'] = normal_cvar.cvar_value
            
            # Her senaryo için CVaR hesapla
            for scenario_name, scenario_params in stress_scenarios.items():
                # Senaryo uygula
                stressed_returns = self._apply_stress_scenario(returns, scenario_params)
                
                # Stresli CVaR
                stressed_cvar = self.calculate_cvar(stressed_returns, confidence_level, CVaRMethod.HISTORICAL)
                
                stress_results[scenario_name] = {
                    'cvar': stressed_cvar.cvar_value,
                    'increase_ratio': stressed_cvar.cvar_value / normal_cvar.cvar_value,
                    'scenario_params': scenario_params
                }
            
            return stress_results
            
        except Exception as e:
            self.logger.error(f"CVaR stress test hatası: {str(e)}")
            return {'error': str(e)}
    
    def _apply_stress_scenario(self, returns: pd.Series, scenario_params: Dict) -> pd.Series:
        """Stres senaryosunu uygula"""
        
        stressed_returns = returns.copy()
        
        # Mean shift
        if 'mean_shift' in scenario_params:
            stressed_returns += scenario_params['mean_shift']
        
        # Volatility increase
        if 'volatility_multiplier' in scenario_params:
            stressed_returns *= scenario_params['volatility_multiplier']
        
        # Fat tails (kurtosis increase)
        if 'kurtosis_multiplier' in scenario_params:
            # Kurtosis artırma (basitleştirilmiş)
            stressed_returns = stressed_returns * (1 + np.random.normal(0, scenario_params['kurtosis_multiplier'], len(stressed_returns)))
        
        return stressed_returns
    
    def _get_calculation_details(self, method: CVaRMethod, confidence_level: float) -> Dict:
        """Hesaplama detayları"""
        
        return {
            'method': method.value,
            'confidence_level': confidence_level,
            'lookback_period': self.lookback_period,
            'calculation_timestamp': datetime.now().isoformat()
        }
    
    def get_cvar_comparison(self, returns: pd.Series) -> Dict:
        """Farklı CVaR yöntemlerini karşılaştır"""
        
        comparison_results = {}
        
        try:
            confidence_levels = [0.95, 0.99]
            
            for confidence_level in confidence_levels:
                level_results = {}
                
                for method in CVaRMethod:
                    try:
                        cvar_result = self.calculate_cvar(returns, confidence_level, method)
                        level_results[method.value] = {
                            'cvar': cvar_result.cvar_value,
                            'var': cvar_result.var_value,
                            'cvar_var_ratio': cvar_result.cvar_value / cvar_result.var_value if cvar_result.var_value > 0 else 0
                        }
                    except Exception as e:
                        level_results[method.value] = {'error': str(e)}
                
                comparison_results[f'confidence_{confidence_level}'] = level_results
            
            return comparison_results
            
        except Exception as e:
            self.logger.error(f"CVaR karşılaştırma hatası: {str(e)}")
            return {'error': str(e)}