"""
Risk Attribution Model Sınıfı

Risk atıf analizi yapan model.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Union
from datetime import datetime, timedelta
import logging
from enum import Enum
from dataclasses import dataclass

class AttributionMethod(Enum):
    """Risk atıf yöntemleri"""
    MARGINAL_CONTRIBUTION = "marginal"
    ANCHORING_METHOD = "anchoring"
    BETA_CONTRIBUTION = "beta"
    FACTOR_CONTRIBUTION = "factor"
    COMPONENT_DECOMPOSITION = "component"

@dataclass
class RiskAttribution:
    """Risk atıf sonucu"""
    component_id: str
    component_name: str
    contribution_amount: float
    contribution_percentage: float
    risk_type: str
    level: str

class RiskAttributionModel:
    """
    Risk Atıf Analizi Modeli
    
    Portföy riskinin kaynaklarını analiz eder.
    """
    
    def __init__(self, config=None):
        """Risk Attribution Modelini başlat"""
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Risk faktörleri
        self.risk_factors = [
            'equity_market', 'size', 'value', 'momentum', 'quality',
            'interest_rate', 'credit_spread', 'inflation', 'currency'
        ]
        
        self.logger.info("Risk Attribution Modeli başlatıldı")
    
    def attribute_risk(self, 
                      portfolio_data: Dict,
                      market_data: Dict,
                      method: AttributionMethod = AttributionMethod.MARGINAL_CONTRIBUTION) -> Dict:
        """Risk atıf analizi"""
        
        try:
            self.logger.info(f"Risk atıf analizi başlatılıyor - Yöntem: {method.value}")
            
            if method == AttributionMethod.MARGINAL_CONTRIBUTION:
                return self._marginal_contribution_attribution(portfolio_data, market_data)
            elif method == AttributionMethod.BETA_CONTRIBUTION:
                return self._beta_contribution_attribution(portfolio_data, market_data)
            elif method == AttributionMethod.FACTOR_CONTRIBUTION:
                return self._factor_contribution_attribution(portfolio_data, market_data)
            else:
                return self._marginal_contribution_attribution(portfolio_data, market_data)
                
        except Exception as e:
            self.logger.error(f"Risk atıf hatası: {str(e)}")
            return {'error': str(e)}
    
    def _marginal_contribution_attribution(self, portfolio_data: Dict, market_data: Dict) -> Dict:
        """Marjinal katkı yöntemi"""
        
        # Portföy kompozisyonu
        composition = portfolio_data.get('composition', {})
        total_value = sum(composition.values())
        
        if total_value == 0:
            return {}
        
        # Asset volatilite tahminleri (basit)
        volatilities = {
            'equity': 0.20,
            'fixed_income': 0.05,
            'commodities': 0.30,
            'credit': 0.12,
            'alternatives': 0.25
        }
        
        # Marjinal risk katkıları
        marginal_contributions = {}
        total_risk = 0
        
        for asset_class, weight_value in composition.items():
            if weight_value <= 0:
                continue
                
            weight = weight_value / total_value
            volatility = volatilities.get(asset_class, 0.15)
            
            # Marjinal risk katkısı
            marginal_risk = weight * volatility
            marginal_contributions[asset_class] = {
                'weight': weight,
                'volatility': volatility,
                'marginal_risk': marginal_risk,
                'risk_contribution': marginal_risk
            }
            total_risk += marginal_risk
        
        # Yüzdeleri hesapla
        for asset_class in marginal_contributions:
            if total_risk > 0:
                marginal_contributions[asset_class]['risk_percentage'] = (
                    marginal_contributions[asset_class]['risk_contribution'] / total_risk
                )
        
        return {
            'method': 'marginal_contribution',
            'total_risk': total_risk,
            'asset_contributions': marginal_contributions,
            'top_contributors': self._get_top_contributors(marginal_contributions, 3)
        }
    
    def _beta_contribution_attribution(self, portfolio_data: Dict, market_data: Dict) -> Dict:
        """Beta katkı yöntemi"""
        
        composition = portfolio_data.get('composition', {})
        total_value = sum(composition.values())
        
        # Varsayılan beta değerleri
        betas = {
            'equity': 1.0,
            'fixed_income': -0.2,  # Negative correlation with market
            'commodities': 0.7,
            'credit': 0.8,
            'alternatives': 0.6
        }
        
        beta_contributions = {}
        market_risk = 0.15  # Piyasa volatilitesi
        
        for asset_class, weight_value in composition.items():
            if weight_value <= 0:
                continue
                
            weight = weight_value / total_value
            beta = betas.get(asset_class, 1.0)
            
            # Beta-based risk contribution
            beta_risk = weight * beta * market_risk
            beta_contributions[asset_class] = {
                'weight': weight,
                'beta': beta,
                'beta_risk': beta_risk,
                'risk_contribution': beta_risk
            }
        
        return {
            'method': 'beta_contribution',
            'market_risk': market_risk,
            'asset_contributions': beta_contributions,
            'total_beta_risk': sum(c['risk_contribution'] for c in beta_contributions.values())
        }
    
    def _factor_contribution_attribution(self, portfolio_data: Dict, market_data: Dict) -> Dict:
        """Faktör katkı yöntemi"""
        
        composition = portfolio_data.get('composition', {})
        
        # Faktör maruziyet tahminleri
        factor_exposures = {
            'equity_market': composition.get('equity', 0),
            'interest_rate': composition.get('fixed_income', 0) * 0.8,
            'credit_spread': composition.get('credit', 0) * 0.7,
            'inflation': composition.get('commodities', 0) * 0.6,
            'currency': composition.get('alternatives', 0) * 0.4
        }
        
        # Faktör volatilite tahminleri
        factor_volatilities = {
            'equity_market': 0.20,
            'interest_rate': 0.08,
            'credit_spread': 0.15,
            'inflation': 0.12,
            'currency': 0.10
        }
        
        factor_contributions = {}
        total_factor_risk = 0
        
        for factor, exposure in factor_exposures.items():
            if exposure <= 0:
                continue
                
            volatility = factor_volatilities.get(factor, 0.15)
            factor_risk = abs(exposure) * volatility
            factor_contributions[factor] = {
                'exposure': exposure,
                'volatility': volatility,
                'factor_risk': factor_risk,
                'risk_contribution': factor_risk
            }
            total_factor_risk += factor_risk
        
        # Yüzdeleri hesapla
        for factor in factor_contributions:
            if total_factor_risk > 0:
                factor_contributions[factor]['risk_percentage'] = (
                    factor_contributions[factor]['risk_contribution'] / total_factor_risk
                )
        
        return {
            'method': 'factor_contribution',
            'total_factor_risk': total_factor_risk,
            'factor_contributions': factor_contributions,
            'dominant_factors': self._get_top_contributors(factor_contributions, 3)
        }
    
    def _get_top_contributors(self, contributions: Dict, top_n: int) -> List[Dict]:
        """En büyük katkı sağlayanları al"""
        
        sorted_contributors = sorted(
            contributions.items(),
            key=lambda x: x[1]['risk_contribution'],
            reverse=True
        )
        
        return [
            {
                'component': component,
                'risk_contribution': data['risk_contribution'],
                'percentage': data.get('risk_percentage', 0)
            }
            for component, data in sorted_contributors[:top_n]
        ]
    
    def calculate_risk_concentration(self, portfolio_data: Dict) -> Dict:
        """Risk konsantrasyonu hesapla"""
        
        composition = portfolio_data.get('composition', {})
        
        if not composition:
            return {}
        
        # Her asset sınıfı için risk hesapla
        risk_weights = []
        total_risk = 0
        
        volatilities = {
            'equity': 0.20,
            'fixed_income': 0.05,
            'commodities': 0.30,
            'credit': 0.12,
            'alternatives': 0.25
        }
        
        for asset_class, weight_value in composition.items():
            volatility = volatilities.get(asset_class, 0.15)
            risk_weight = weight_value * volatility
            risk_weights.append(risk_weight)
            total_risk += risk_weight
        
        # HHI (Herfindahl-Hirschman Index)
        if total_risk > 0:
            normalized_weights = [rw / total_risk for rw in risk_weights]
            hhi = sum(w**2 for w in normalized_weights)
        else:
            hhi = 0
        
        # En büyük 5 pozisyonun payı
        sorted_weights = sorted(risk_weights, reverse=True)
        top5_share = sum(sorted_weights[:5]) / total_risk if total_risk > 0 else 0
        
        return {
            'hhi': hhi,
            'top5_share': top5_share,
            'concentration_level': 'High' if hhi > 0.25 else 'Medium' if hhi > 0.15 else 'Low',
            'risk_diversification_ratio': 1 - hhi
        }
    
    def analyze_factor_exposure(self, portfolio_data: Dict) -> Dict:
        """Faktör maruziyet analizi"""
        
        composition = portfolio_data.get('composition', {})
        
        # Ana faktör maruziyetleri
        factor_exposures = {
            'Market Risk (Equity)': composition.get('equity', 0),
            'Interest Rate Risk': composition.get('fixed_income', 0) * 0.8,
            'Credit Risk': composition.get('credit', 0) * 0.9,
            'Commodity Risk': composition.get('commodities', 0) * 0.7,
            'Alternative Risk': composition.get('alternatives', 0) * 0.6
        }
        
        # Toplam maruziyet
        total_exposure = sum(factor_exposures.values())
        
        if total_exposure > 0:
            # Normalize yüzdeler
            for factor in factor_exposures:
                factor_exposures[factor] = factor_exposures[factor] / total_exposure
        
        return {
            'factor_exposures': factor_exposures,
            'total_exposure': total_exposure,
            'dominant_factors': self._get_top_contributors(
                {k: {'risk_contribution': v} for k, v in factor_exposures.items()}, 3
            )
        }