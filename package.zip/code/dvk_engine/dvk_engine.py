"""
Dinamik Varlık Karakterizasyonu (DVK) Ana Engine
===============================================

Bu modül, kripto paraların dinamik olarak hangi indikatörler ve parametrelerle
en iyi performans gösterdiğini analiz eden ana DVK motorudur.

Author: DVK Development Team
Date: 2025-10-30
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Any, Optional
import logging
from datetime import datetime, timedelta
import asyncio
from concurrent.futures import ThreadPoolExecutor
import json

from .indicators.technical_indicators import TechnicalIndicators
from .regime_detection.market_regime_detector import MarketRegimeDetector
from .strategy_ranking.performance_ranker import PerformanceRanker
from .backtest.backtest_engine import BacktestEngine
from .config.dvk_config import DVKConfig

class DVKEngine:
    """
    Dinamik Varlık Karakterizasyonu ana motor sınıfı
    """
    
    def __init__(self, config: Optional[DVKConfig] = None):
        """
        DVK Motor başlatıcı
        
        Args:
            config: DVK konfigürasyon objesi
        """
        self.config = config or DVKConfig()
        self.logger = self._setup_logging()
        
        # Alt motorları başlat
        self.technical_indicators = TechnicalIndicators()
        self.regime_detector = MarketRegimeDetector()
        self.performance_ranker = PerformanceRanker()
        self.backtest_engine = BacktestEngine()
        
        # Sonuçları sakla
        self.coin_characterizations = {}
        self.current_regimes = {}
        self.active_strategies = {}
        
        self.logger.info("DVK Motor başarıyla başlatıldı")
    
    def _setup_logging(self) -> logging.Logger:
        """Log sistemini ayarla"""
        logger = logging.getLogger('DVKEngine')
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        return logger
    
    async def analyze_coin_portfolio(self, coins: List[str], days: int = 30) -> Dict[str, Any]:
        """
        Coin portföyünün dinamik karakterizasyonunu analiz et
        
        Args:
            coins: Analiz edilecek coin sembolleri
            days: Analiz periyodu (gün)
            
        Returns:
            Her coin için karakterizasyon sonuçları
        """
        self.logger.info(f"Portföy analizi başlatılıyor: {len(coins)} coin, {days} gün")
        
        results = {}
        
        # Her coin için paralel analiz
        with ThreadPoolExecutor(max_workers=self.config.max_parallel_analysis) as executor:
            futures = {
                executor.submit(self._analyze_single_coin, coin, days): coin 
                for coin in coins
            }
            
            for future in futures:
                coin = futures[future]
                try:
                    result = future.result(timeout=300)  # 5 dakika timeout
                    results[coin] = result
                    self.logger.info(f"{coin} analizi tamamlandı")
                except Exception as e:
                    self.logger.error(f"{coin} analizi hatası: {str(e)}")
                    results[coin] = {"error": str(e)}
        
        self.coin_characterizations = results
        return results
    
    def _analyze_single_coin(self, coin: str, days: int) -> Dict[str, Any]:
        """
        Tek coin için detaylı DVK analizi
        
        Args:
            coin: Coin sembolü
            days: Analiz periyodu
            
        Returns:
            Coin karakterizasyon sonuçları
        """
        self.logger.info(f"{coin} için DVK analizi başlatılıyor")
        
        try:
            # 1. Fiyat verilerini al (simülasyon - gerçek uygulamada API'den alınacak)
            price_data = self._fetch_price_data(coin, days)
            
            # 2. Market regime tespiti
            current_regime = self.regime_detector.detect_regime(price_data)
            
            # 3. Parameter sweep analizi
            parameter_results = self._perform_parameter_sweep(coin, price_data, current_regime)
            
            # 4. Strategy ranking
            best_strategies = self.performance_ranker.rank_strategies(parameter_results)
            
            # 5. Coin karakterizasyonu oluştur
            characterization = {
                "coin": coin,
                "analysis_date": datetime.now().isoformat(),
                "current_regime": current_regime,
                "best_strategies": best_strategies,
                "parameter_ranges": parameter_results,
                "performance_metrics": self._calculate_overall_metrics(parameter_results),
                "recommended_allocation": self._calculate_allocation(best_strategies)
            }
            
            self.logger.info(f"{coin} DVK analizi tamamlandı")
            return characterization
            
        except Exception as e:
            self.logger.error(f"{coin} DVK analizi hatası: {str(e)}")
            return {"error": str(e), "coin": coin}
    
    def _fetch_price_data(self, coin: str, days: int) -> pd.DataFrame:
        """
        Fiyat verilerini simüle et (gerçek uygulamada API'den gelecek)
        
        Args:
            coin: Coin sembolü
            days: Gün sayısı
            
        Returns:
            OHLCV veri çerçevesi
        """
        # Simülasyon için rastgele fiyat verisi oluştur
        np.random.seed(hash(coin) % 2**31)  # Her coin için deterministik veri
        
        dates = pd.date_range(start=datetime.now() - timedelta(days=days), 
                             end=datetime.now(), freq='1H')
        
        # Random walk ile fiyat simülasyonu
        returns = np.random.normal(0, 0.02, len(dates))  # Daily average 2% volatility
        prices = 100 * np.exp(np.cumsum(returns))  # Başlangıç fiyatı $100
        
        # OHLCV oluştur
        data = []
        for i, (date, price) in enumerate(zip(dates, prices)):
            # Open, High, Low oluştur
            volatility = np.random.uniform(0.005, 0.02)  # Daily volatility
            open_price = price * (1 + np.random.normal(0, 0.01))
            high_price = max(open_price, price) * (1 + volatility)
            low_price = min(open_price, price) * (1 - volatility)
            close_price = price
            
            # Volume oluştur
            volume = np.random.uniform(1000, 10000)  * 1000
            
            data.append({
                'timestamp': date,
                'open': open_price,
                'high': high_price,
                'low': low_price,
                'close': close_price,
                'volume': volume
            })
        
        return pd.DataFrame(data).set_index('timestamp')
    
    def _perform_parameter_sweep(self, coin: str, price_data: pd.DataFrame, 
                               regime: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parameter sweep analizi gerçekleştir
        
        Args:
            coin: Coin sembolü
            price_data: OHLCV verileri
            regime: Market regime bilgisi
            
        Returns:
            Parameter sweep sonuçları
        """
        self.logger.info(f"{coin} için parameter sweep başlatılıyor")
        
        results = {}
        
        # RSI parameter sweep
        rsi_results = self._rsi_parameter_sweep(price_data, regime)
        results["rsi"] = rsi_results
        
        # MACD parameter sweep
        macd_results = self._macd_parameter_sweep(price_data, regime)
        results["macd"] = macd_results
        
        # Bollinger Bands parameter sweep
        bb_results = self._bollinger_parameter_sweep(price_data, regime)
        results["bollinger_bands"] = bb_results
        
        # Stochastic parameter sweep
        stoch_results = self._stochastic_parameter_sweep(price_data, regime)
        results["stochastic"] = stoch_results
        
        self.logger.info(f"{coin} parameter sweep tamamlandı")
        return results
    
    def _rsi_parameter_sweep(self, price_data: pd.DataFrame, 
                           regime: Dict[str, Any]) -> Dict[str, Any]:
        """
        RSI için parameter sweep analizi
        
        Args:
            price_data: OHLCV verileri
            regime: Market regime
            
        Returns:
            RSI parameter sweep sonuçları
        """
        rsi_periods = range(self.config.rsi_min_period, 
                           self.config.rsi_max_period + 1, 5)
        results = []
        
        for period in rsi_periods:
            # RSI hesapla
            rsi = self.technical_indicators.calculate_rsi(price_data['close'], period)
            
            # Strategy simülasyonu
            trades = self._simulate_rsi_strategy(price_data, rsi, period)
            
            # Performance hesapla
            performance = self._calculate_trade_performance(trades)
            
            results.append({
                "indicator": "RSI",
                "parameters": {"period": period},
                "performance": performance,
                "trades": trades,
                "suitable_for_regime": self._regime_suitability("RSI", regime)
            })
        
        return {"sweep_results": results}
    
    def _macd_parameter_sweep(self, price_data: pd.DataFrame, 
                            regime: Dict[str, Any]) -> Dict[str, Any]:
        """
        MACD için parameter sweep analizi
        """
        fast_periods = [8, 12, 16, 20, 24]
        slow_periods = [18, 24, 30, 36, 42]
        signal_periods = [6, 9, 12, 15]
        
        results = []
        
        for fast in fast_periods:
            for slow in slow_periods:
                if slow <= fast:
                    continue
                for signal in signal_periods:
                    # MACD hesapla
                    macd_data = self.technical_indicators.calculate_macd(
                        price_data['close'], fast, slow, signal
                    )
                    
                    # Strategy simülasyonu
                    trades = self._simulate_macd_strategy(price_data, macd_data)
                    
                    # Performance hesapla
                    performance = self._calculate_trade_performance(trades)
                    
                    results.append({
                        "indicator": "MACD",
                        "parameters": {"fast": fast, "slow": slow, "signal": signal},
                        "performance": performance,
                        "trades": trades,
                        "suitable_for_regime": self._regime_suitability("MACD", regime)
                    })
        
        return {"sweep_results": results}
    
    def _bollinger_parameter_sweep(self, price_data: pd.DataFrame, 
                                 regime: Dict[str, Any]) -> Dict[str, Any]:
        """
        Bollinger Bands için parameter sweep
        """
        periods = [10, 15, 20, 25, 30]
        std_multipliers = [1.5, 2.0, 2.5, 3.0]
        
        results = []
        
        for period in periods:
            for multiplier in std_multipliers:
                # Bollinger Bands hesapla
                bb_data = self.technical_indicators.calculate_bollinger_bands(
                    price_data['close'], period, multiplier
                )
                
                # Strategy simülasyonu
                trades = self._simulate_bollinger_strategy(price_data, bb_data)
                
                # Performance hesapla
                performance = self._calculate_trade_performance(trades)
                
                results.append({
                    "indicator": "Bollinger_Bands",
                    "parameters": {"period": period, "multiplier": multiplier},
                    "performance": performance,
                    "trades": trades,
                    "suitable_for_regime": self._regime_suitability("Bollinger_Bands", regime)
                })
        
        return {"sweep_results": results}
    
    def _stochastic_parameter_sweep(self, price_data: pd.DataFrame, 
                                  regime: Dict[str, Any]) -> Dict[str, Any]:
        """
        Stochastic için parameter sweep
        """
        k_periods = [10, 14, 18, 22]
        d_periods = [3, 5, 7]
        
        results = []
        
        for k in k_periods:
            for d in d_periods:
                # Stochastic hesapla
                stoch_data = self.technical_indicators.calculate_stochastic(
                    price_data, k, d
                )
                
                # Strategy simülasyonu
                trades = self._simulate_stochastic_strategy(price_data, stoch_data)
                
                # Performance hesapla
                performance = self._calculate_trade_performance(trades)
                
                results.append({
                    "indicator": "Stochastic",
                    "parameters": {"k_period": k, "d_period": d},
                    "performance": performance,
                    "trades": trades,
                    "suitable_for_regime": self._regime_suitability("Stochastic", regime)
                })
        
        return {"sweep_results": results}
    
    def _simulate_rsi_strategy(self, price_data: pd.DataFrame, rsi: pd.Series, 
                             period: int) -> List[Dict]:
        """
        RSI strategy simülasyonu
        """
        trades = []
        position = None
        
        for i, (timestamp, rsi_val) in enumerate(rsi.items()):
            if pd.isna(rsi_val):
                continue
                
            price = price_data.loc[timestamp, 'close']
            
            # Buy signal: RSI < oversold level
            if rsi_val < 30 and position is None:
                position = {
                    "type": "buy",
                    "entry_price": price,
                    "entry_time": timestamp,
                    "rsi_value": rsi_val,
                    "rsi_period": period
                }
            
            # Sell signal: RSI > overbought level and position exists
            elif rsi_val > 70 and position is not None:
                if position["type"] == "buy":
                    exit_price = price
                    profit = exit_price - position["entry_price"]
                    profit_pct = (profit / position["entry_price"]) * 100
                    
                    trades.append({
                        **position,
                        "exit_price": exit_price,
                        "exit_time": timestamp,
                        "profit": profit,
                        "profit_pct": profit_pct
                    })
                    position = None
        
        # Açık pozisyonu kapat
        if position is not None:
            final_price = price_data['close'].iloc[-1]
            profit = final_price - position["entry_price"]
            profit_pct = (profit / position["entry_price"]) * 100
            
            trades.append({
                **position,
                "exit_price": final_price,
                "exit_time": price_data.index[-1],
                "profit": profit,
                "profit_pct": profit_pct
            })
        
        return trades
    
    def _simulate_macd_strategy(self, price_data: pd.DataFrame, 
                              macd_data: Dict) -> List[Dict]:
        """
        MACD strategy simülasyonu
        """
        trades = []
        position = None
        
        macd_line = macd_data['macd']
        signal_line = macd_data['signal']
        
        for i, timestamp in enumerate(macd_line.index):
            if pd.isna(macd_line.iloc[i]) or pd.isna(signal_line.iloc[i]):
                continue
                
            price = price_data.loc[timestamp, 'close']
            
            # Golden cross - buy signal
            if (i > 0 and 
                macd_line.iloc[i] > signal_line.iloc[i] and 
                macd_line.iloc[i-1] <= signal_line.iloc[i-1] and 
                position is None):
                
                position = {
                    "type": "buy",
                    "entry_price": price,
                    "entry_time": timestamp,
                    "macd_value": macd_line.iloc[i],
                    "signal_value": signal_line.iloc[i]
                }
            
            # Death cross - sell signal
            elif (i > 0 and 
                  macd_line.iloc[i] < signal_line.iloc[i] and 
                  macd_line.iloc[i-1] >= signal_line.iloc[i-1] and 
                  position is not None):
                
                if position["type"] == "buy":
                    exit_price = price
                    profit = exit_price - position["entry_price"]
                    profit_pct = (profit / position["entry_price"]) * 100
                    
                    trades.append({
                        **position,
                        "exit_price": exit_price,
                        "exit_time": timestamp,
                        "profit": profit,
                        "profit_pct": profit_pct
                    })
                    position = None
        
        # Açık pozisyonu kapat
        if position is not None:
            final_price = price_data['close'].iloc[-1]
            profit = final_price - position["entry_price"]
            profit_pct = (profit / position["entry_price"]) * 100
            
            trades.append({
                **position,
                "exit_price": final_price,
                "exit_time": price_data.index[-1],
                "profit": profit,
                "profit_pct": profit_pct
            })
        
        return trades
    
    def _simulate_bollinger_strategy(self, price_data: pd.DataFrame, 
                                   bb_data: Dict) -> List[Dict]:
        """
        Bollinger Bands strategy simülasyonu
        """
        trades = []
        position = None
        
        price_series = price_data['close']
        upper_band = bb_data['upper']
        lower_band = bb_data['lower']
        middle_band = bb_data['middle']
        
        for i, timestamp in enumerate(price_series.index):
            if pd.isna(upper_band.iloc[i]) or pd.isna(lower_band.iloc[i]):
                continue
                
            price = price_series.loc[timestamp]
            
            # Buy signal: Price touches lower band
            if price <= lower_band.iloc[i] and position is None:
                position = {
                    "type": "buy",
                    "entry_price": price,
                    "entry_time": timestamp,
                    "lower_band": lower_band.iloc[i],
                    "price_vs_lower": (price - lower_band.iloc[i]) / lower_band.iloc[i]
                }
            
            # Sell signal: Price reaches middle band or higher
            elif (position is not None and 
                  price >= middle_band.iloc[i]):
                
                exit_price = price
                profit = exit_price - position["entry_price"]
                profit_pct = (profit / position["entry_price"]) * 100
                
                trades.append({
                    **position,
                    "exit_price": exit_price,
                    "exit_time": timestamp,
                    "profit": profit,
                    "profit_pct": profit_pct
                })
                position = None
        
        # Açık pozisyonu kapat
        if position is not None:
            final_price = price_series.iloc[-1]
            profit = final_price - position["entry_price"]
            profit_pct = (profit / position["entry_price"]) * 100
            
            trades.append({
                **position,
                "exit_price": final_price,
                "exit_time": price_series.index[-1],
                "profit": profit,
                "profit_pct": profit_pct
            })
        
        return trades
    
    def _simulate_stochastic_strategy(self, price_data: pd.DataFrame, 
                                    stoch_data: Dict) -> List[Dict]:
        """
        Stochastic strategy simülasyonu
        """
        trades = []
        position = None
        
        k_percent = stoch_data['k']
        d_percent = stoch_data['d']
        
        for i, timestamp in enumerate(k_percent.index):
            if pd.isna(k_percent.iloc[i]) or pd.isna(d_percent.iloc[i]):
                continue
                
            price = price_data.loc[timestamp, 'close']
            
            # Buy signal: %K and %D < 20 (oversold)
            if (k_percent.iloc[i] < 20 and d_percent.iloc[i] < 20 and 
                position is None):
                
                position = {
                    "type": "buy",
                    "entry_price": price,
                    "entry_time": timestamp,
                    "k_value": k_percent.iloc[i],
                    "d_value": d_percent.iloc[i]
                }
            
            # Sell signal: %K and %D > 80 (overbought)
            elif (position is not None and 
                  k_percent.iloc[i] > 80 and d_percent.iloc[i] > 80):
                
                exit_price = price
                profit = exit_price - position["entry_price"]
                profit_pct = (profit / position["entry_price"]) * 100
                
                trades.append({
                    **position,
                    "exit_price": exit_price,
                    "exit_time": timestamp,
                    "profit": profit,
                    "profit_pct": profit_pct
                })
                position = None
        
        # Açık pozisyonu kapat
        if position is not None:
            final_price = price_data['close'].iloc[-1]
            profit = final_price - position["entry_price"]
            profit_pct = (profit / position["entry_price"]) * 100
            
            trades.append({
                **position,
                "exit_price": final_price,
                "exit_time": price_data.index[-1],
                "profit": profit,
                "profit_pct": profit_pct
            })
        
        return trades
    
    def _calculate_trade_performance(self, trades: List[Dict]) -> Dict[str, float]:
        """
        Trading performansını hesapla
        
        Args:
            trades: Trade listesi
            
        Returns:
            Performance metrikleri
        """
        if not trades:
            return {
                "total_return": 0.0,
                "win_rate": 0.0,
                "avg_profit_per_trade": 0.0,
                "max_drawdown": 0.0,
                "sharpe_ratio": 0.0,
                "profit_factor": 0.0,
                "total_trades": 0
            }
        
        # Temel metrikleri hesapla
        total_profit = sum(trade["profit"] for trade in trades)
        total_return = sum(trade["profit_pct"] for trade in trades)
        
        winning_trades = [t for t in trades if t["profit"] > 0]
        losing_trades = [t for t in trades if t["profit"] < 0]
        
        win_rate = len(winning_trades) / len(trades) if trades else 0
        
        avg_profit_per_trade = total_profit / len(trades)
        
        # Drawdown hesapla
        cumulative_profits = np.cumsum([t["profit"] for t in trades])
        running_max = np.maximum.accumulate(cumulative_profits)
        drawdown = running_max - cumulative_profits
        max_drawdown = np.max(drawdown) if len(drawdown) > 0 else 0
        
        # Sharpe ratio hesapla
        profits = [t["profit_pct"] for t in trades]
        if len(profits) > 1 and np.std(profits) > 0:
            sharpe_ratio = np.mean(profits) / np.std(profits) * np.sqrt(252)
        else:
            sharpe_ratio = 0.0
        
        # Profit factor
        gross_profit = sum(t["profit"] for t in winning_trades) if winning_trades else 0
        gross_loss = abs(sum(t["profit"] for t in losing_trades)) if losing_trades else 0
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else 0
        
        return {
            "total_return": total_return,
            "win_rate": win_rate,
            "avg_profit_per_trade": avg_profit_per_trade,
            "max_drawdown": max_drawdown,
            "sharpe_ratio": sharpe_ratio,
            "profit_factor": profit_factor,
            "total_trades": len(trades)
        }
    
    def _regime_suitability(self, indicator: str, regime: Dict[str, Any]) -> float:
        """
        Belirli bir indikatörün mevcut market regime için uygunluğunu hesapla
        
        Args:
            indicator: İndikatör adı
            regime: Market regime bilgisi
            
        Returns:
            Uygunluk skoru (0-1)
        """
        regime_type = regime.get("regime_type", "unknown")
        
        # Regime-indikatör uygunluk matrisleri
        suitability_matrix = {
            "trending": {
                "MACD": 0.9,
                "RSI": 0.7,
                "Bollinger_Bands": 0.6,
                "Stochastic": 0.5
            },
            "ranging": {
                "RSI": 0.9,
                "Bollinger_Bands": 0.8,
                "Stochastic": 0.7,
                "MACD": 0.4
            },
            "volatile": {
                "Bollinger_Bands": 0.9,
                "RSI": 0.6,
                "Stochastic": 0.5,
                "MACD": 0.3
            },
            "unknown": {
                "RSI": 0.6,
                "Bollinger_Bands": 0.6,
                "MACD": 0.6,
                "Stochastic": 0.6
            }
        }
        
        return suitability_matrix.get(regime_type, {}).get(indicator, 0.5)
    
    def _calculate_overall_metrics(self, parameter_results: Dict) -> Dict[str, Any]:
        """
        Genel performans metriklerini hesapla
        """
        all_performances = []
        
        for indicator_type, sweep_results in parameter_results.items():
            if "sweep_results" in sweep_results:
                for result in sweep_results["sweep_results"]:
                    all_performances.append(result["performance"])
        
        if not all_performances:
            return {}
        
        # Ortalama metrikleri hesapla
        avg_return = np.mean([p["total_return"] for p in all_performances])
        avg_win_rate = np.mean([p["win_rate"] for p in all_performances])
        avg_sharpe = np.mean([p["sharpe_ratio"] for p in all_performances])
        
        # En iyi strategies
        best_sharpe = max(all_performances, key=lambda x: x["sharpe_ratio"])
        best_win_rate = max(all_performances, key=lambda x: x["win_rate"])
        
        return {
            "avg_total_return": avg_return,
            "avg_win_rate": avg_win_rate,
            "avg_sharpe_ratio": avg_sharpe,
            "best_sharpe_strategy": best_sharpe,
            "best_win_rate_strategy": best_win_rate,
            "total_strategies_tested": len(all_performances)
        }
    
    def _calculate_allocation(self, best_strategies: List[Dict]) -> Dict[str, float]:
        """
        En iyi stratejilere göre allocation hesapla
        """
        if not best_strategies:
            return {}
        
        # Sharpe ratio ağırlıklı allocation
        total_weight = sum(s["sharpe_ratio"] for s in best_strategies if s["sharpe_ratio"] > 0)
        
        if total_weight == 0:
            equal_allocation = 1.0 / len(best_strategies)
            return {f"{s['indicator']}_{s['parameters']}": equal_allocation for s in best_strategies}
        
        allocation = {}
        for strategy in best_strategies:
            if strategy["sharpe_ratio"] > 0:
                weight = strategy["sharpe_ratio"] / total_weight
                key = f"{strategy['indicator']}_{strategy['parameters']}"
                allocation[key] = weight
        
        return allocation
    
    async def get_real_time_strategy_activation(self, coins: List[str]) -> Dict[str, Any]:
        """
        Real-time strategy aktivasyon/deaktivasyonunu yönet
        
        Args:
            coins: İzlenecek coin listesi
            
        Returns:
            Strategy aktivasyon durumları
        """
        self.logger.info("Real-time strategy activation kontrolü")
        
        activations = {}
        
        for coin in coins:
            if coin not in self.coin_characterizations:
                activations[coin] = {"status": "waiting_analysis", "active_strategies": []}
                continue
            
            char_data = self.coin_characterizations[coin]
            
            # Güncel market regime'i kontrol et
            price_data = self._fetch_price_data(coin, 7)  # Son 7 gün
            current_regime = self.regime_detector.detect_regime(price_data)
            
            # En iyi stratejileri al
            best_strategies = char_data.get("best_strategies", [])
            active_strategies = []
            
            for strategy in best_strategies:
                # Regime uyumluluğunu kontrol et
                regime_suitability = strategy.get("regime_suitability", 0)
                
                # Minimum performans eşiği
                performance = strategy.get("performance", {})
                win_rate = performance.get("win_rate", 0)
                sharpe_ratio = performance.get("sharpe_ratio", 0)
                
                # Strategy'yi aktifleştir kriterleri
                should_activate = (
                    regime_suitability > 0.6 and
                    win_rate > 0.4 and
                    sharpe_ratio > 0.5
                )
                
                if should_activate:
                    active_strategies.append({
                        **strategy,
                        "activation_score": (regime_suitability * 0.4 + win_rate * 0.3 + 
                                           min(sharpe_ratio/2, 1) * 0.3)
                    })
            
            # En iyi 3 stratejiyi seç
            active_strategies.sort(key=lambda x: x["activation_score"], reverse=True)
            top_strategies = active_strategies[:3]
            
            # Bitwisers Account Manager'a gönderilecek format
            activations[coin] = {
                "status": "active" if top_strategies else "inactive",
                "current_regime": current_regime,
                "active_strategies": top_strategies,
                "analysis_timestamp": datetime.now().isoformat()
            }
        
        self.active_strategies = activations
        return activations
    
    def get_bitwisers_integration_data(self) -> Dict[str, Any]:
        """
        Bitwisers Account Managers için entegrasyon verilerini hazırla
        
        Returns:
            Bitwisers entegrasyon formatında veriler
        """
        integration_data = {
            "dvk_analysis_timestamp": datetime.now().isoformat(),
            "source": "DVK_Engine",
            "version": "1.0",
            "coin_characterizations": {},
            "active_strategies": self.active_strategies,
            "market_regimes": self.current_regimes
        }
        
        for coin, char_data in self.coin_characterizations.items():
            if "error" not in char_data:
                integration_data["coin_characterizations"][coin] = {
                    "recommended_strategies": char_data.get("best_strategies", [])[:3],
                    "allocation_weights": char_data.get("recommended_allocation", {}),
                    "performance_summary": char_data.get("performance_metrics", {}),
                    "current_regime_suitability": char_data.get("current_regime", {})
                }
        
        return integration_data
    
    def save_results(self, filepath: str = "dvk_results.json"):
        """
        DVK sonuçlarını dosyaya kaydet
        
        Args:
            filepath: Kaydetme dosya yolu
        """
        results = {
            "dvk_analysis_results": self.coin_characterizations,
            "active_strategies": self.active_strategies,
            "current_regimes": self.current_regimes,
            "integration_data": self.get_bitwisers_integration_data(),
            "analysis_timestamp": datetime.now().isoformat()
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        self.logger.info(f"DVK sonuçları kaydedildi: {filepath}")


# Örnek kullanım
if __name__ == "__main__":
    async def main():
        # DVK motorunu başlat
        dvk = DVKEngine()
        
        # Analiz edilecek coinler
        coins = ["BTCUSDT", "ETHUSDT", "ADAUSDT", "DOTUSDT", "LINKUSDT"]
        
        # Coin portföyünü analiz et
        results = await dvk.analyze_coin_portfolio(coins, days=30)
        
        # Real-time strategy kontrolü
        activations = await dvk.get_real_time_strategy_activation(coins)
        
        # Sonuçları kaydet
        dvk.save_results("dvk_analysis_results.json")
        
        print("DVK Analizi Tamamlandı!")
        print(f"Analiz edilen coin sayısı: {len(results)}")
        print(f"Aktif strategy sayısı: {sum(1 for a in activations.values() if a['status'] == 'active')}")
    
    # Ana fonksiyonu çalıştır
    import asyncio
    asyncio.run(main())