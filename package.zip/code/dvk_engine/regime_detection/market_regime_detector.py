"""
Market Regime Detection Modülü
==============================

Bu modül, kripto para piyasasının farklı rejimlerini (trending, ranging, volatile)
otomatik olarak tespit eder. DVK algoritması için kritik bir bileşendir.

Author: DVK Development Team
Date: 2025-10-30
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Any, Optional
from datetime import datetime, timedelta
import logging
from dataclasses import dataclass
import warnings
warnings.filterwarnings('ignore')


@dataclass
class RegimeMetrics:
    """Market regime metrikleri"""
    regime_type: str  # 'trending', 'ranging', 'volatile', 'unknown'
    confidence: float  # 0-1 arası güven seviyesi
    trend_strength: float  # Trend gücü (0-1)
    volatility_level: float  # Volatilite seviyesi (0-1)
    duration_estimate: int  # Tahmini süre (gün)
    indicators_used: List[str]  # Kullanılan indikatörler


class MarketRegimeDetector:
    """
    Market regime tespit sınıfı
    Trending, ranging ve volatile rejimleri tespit eder
    """
    
    def __init__(self):
        """Regime detector'ı başlat"""
        self.logger = logging.getLogger('MarketRegimeDetector')
        
        # Regime tanımları
        self.regime_thresholds = {
            'trending': {
                'min_trend_strength': 0.6,
                'max_volatility': 0.7,
                'min_duration': 5
            },
            'ranging': {
                'max_trend_strength': 0.4,
                'max_volatility': 0.6,
                'min_duration': 7
            },
            'volatile': {
                'min_volatility': 0.8,
                'max_duration': 3  # Kısa süreli
            }
        }
    
    def detect_regime(self, price_data: pd.DataFrame, 
                     lookback_days: int = 30) -> Dict[str, Any]:
        """
        Market regime'ini tespit et
        
        Args:
            price_data: OHLCV veri çerçevesi
            lookback_days: Kaç gün geriye bakılacağı
            
        Returns:
            Regime tespit sonuçları
        """
        try:
            # Son periyodu al
            recent_data = price_data.tail(min(len(price_data), lookback_days))
            
            if len(recent_data) < 10:
                return self._unknown_regime("Yetersiz veri")
            
            # Regime metriklerini hesapla
            metrics = self._calculate_regime_metrics(recent_data)
            
            # Regime sınıflandırması
            regime_classification = self._classify_regime(metrics)
            
            # Trend analizi
            trend_analysis = self._analyze_trend(recent_data)
            
            # Volatilite analizi
            volatility_analysis = self._analyze_volatility(recent_data)
            
            # Döngü analizi
            cycle_analysis = self._analyze_cycles(recent_data)
            
            # Sonuçları birleştir
            regime_result = {
                "regime_type": regime_classification['type'],
                "confidence": regime_classification['confidence'],
                "metrics": {
                    "trend_strength": metrics.trend_strength,
                    "volatility_level": metrics.volatility_level,
                    "duration_estimate": metrics.duration_estimate
                },
                "trend_analysis": trend_analysis,
                "volatility_analysis": volatility_analysis,
                "cycle_analysis": cycle_analysis,
                "indicators_used": metrics.indicators_used,
                "analysis_timestamp": datetime.now().isoformat(),
                "data_period": {
                    "start": recent_data.index[0].isoformat(),
                    "end": recent_data.index[-1].isoformat(),
                    "days": len(recent_data)
                }
            }
            
            return regime_result
            
        except Exception as e:
            self.logger.error(f"Regime detection hatası: {str(e)}")
            return self._unknown_regime(f"Hata: {str(e)}")
    
    def _calculate_regime_metrics(self, data: pd.DataFrame) -> RegimeMetrics:
        """
        Regime metriklerini hesapla
        """
        close_prices = data['close']
        
        # Trend gücü hesaplama
        trend_strength = self._calculate_trend_strength(close_prices)
        
        # Volatilite hesaplama
        volatility_level = self._calculate_volatility_level(data)
        
        # Regime süresi tahmini
        duration_estimate = self._estimate_regime_duration(data)
        
        # En güçlü indikatörleri belirle
        indicators_used = self._identify_dominant_indicators(data)
        
        return RegimeMetrics(
            regime_type="unknown",
            confidence=0.0,
            trend_strength=trend_strength,
            volatility_level=volatility_level,
            duration_estimate=duration_estimate,
            indicators_used=indicators_used
        )
    
    def _calculate_trend_strength(self, prices: pd.Series) -> float:
        """
        Trend gücünü hesapla (0-1 arası)
        """
        try:
            # Dönüşümleri hesapla
            returns = prices.pct_change().dropna()
            
            # Linear regression slope
            x = np.arange(len(returns))
            slope = np.polyfit(x, returns, 1)[0]
            
            # Trend sürdürülebilirliği
            consecutive_directions = self._count_consecutive_directions(returns)
            
            # Trend gücü = slope * sürdürülebilirlik
            slope_strength = min(abs(slope) * 1000, 1.0)  # Slope'i normalize et
            consistency = consecutive_directions / len(returns)
            
            trend_strength = (slope_strength + consistency) / 2
            
            return min(max(trend_strength, 0), 1)
            
        except Exception:
            return 0.5
    
    def _calculate_volatility_level(self, data: pd.DataFrame) -> float:
        """
        Volatilite seviyesini hesapla (0-1 arası)
        """
        try:
            # Günlük getiriler
            returns = data['close'].pct_change().dropna()
            
            # Farklı volatilite ölçütleri
            daily_vol = returns.std()
            
            # ATR bazlı volatilite
            atr = self._calculate_atr(data)
            atr_normalized = atr / data['close']
            
            # Range-based volatilite
            daily_range = (data['high'] - data['low']) / data['close']
            range_vol = daily_range.mean()
            
            # Volatilite composite score
            volatility_score = (
                daily_vol * 0.4 + 
                atr_normalized.mean() * 0.4 + 
                range_vol * 0.2
            )
            
            # Normalize et (0-1 arası)
            volatility_normalized = min(volatility_score * 10, 1.0)
            
            return volatility_normalized
            
        except Exception:
            return 0.5
    
    def _calculate_atr(self, data: pd.DataFrame, period: int = 14) -> pd.Series:
        """
        Average True Range hesapla
        """
        high = data['high']
        low = data['low']
        close = data['close']
        
        tr1 = high - low
        tr2 = abs(high - close.shift())
        tr3 = abs(low - close.shift())
        
        true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = true_range.rolling(window=period).mean()
        
        return atr
    
    def _count_consecutive_directions(self, returns: pd.Series) -> int:
        """
        Ardışık aynı yönlü hareketleri say
        """
        if len(returns) < 2:
            return 0
        
        directions = (returns > 0).astype(int)
        consecutive_count = 1
        
        for i in range(1, len(directions)):
            if directions.iloc[i] == directions.iloc[i-1]:
                consecutive_count += 1
            else:
                consecutive_count = 1
        
        return consecutive_count
    
    def _estimate_regime_duration(self, data: pd.DataFrame) -> int:
        """
        Regime süresini tahmin et
        """
        try:
            # Son değişim noktalarını bul
            price_changes = data['close'].pct_change().abs()
            
            # Trend değişimleri
            significant_moves = price_changes > price_changes.quantile(0.8)
            change_points = significant_moves.sum()
            
            # Ortalama regime süresi
            if change_points == 0:
                return len(data)
            
            avg_duration = len(data) / change_points
            return int(avg_duration)
            
        except Exception:
            return len(data)
    
    def _identify_dominant_indicators(self, data: pd.DataFrame) -> List[str]:
        """
        Hangi indikatörlerin baskın olduğunu belirle
        """
        indicators = []
        
        try:
            # RSI kontrolü
            rsi = self._calculate_rsi(data['close'])
            rsi_range = rsi.max() - rsi.min()
            if rsi_range > 30:  # Geniş RSI aralığı
                indicators.append("RSI")
            
            # MACD kontrolü
            macd_data = self._calculate_macd(data['close'])
            macd_strength = abs(macd_data['macd']).mean()
            if macd_strength > data['close'].mean() * 0.01:
                indicators.append("MACD")
            
            # Bollinger Bands kontrolü
            bb_data = self._calculate_bollinger_bands(data['close'])
            bb_width = (bb_data['upper'] - bb_data['lower']).mean() / data['close'].mean()
            if bb_width > 0.02:  # %2'den fazla bant genişliği
                indicators.append("Bollinger_Bands")
            
            # ADX kontrolü
            adx_data = self._calculate_adx(data)
            if adx_data['adx'].mean() > 25:
                indicators.append("ADX")
            
        except Exception as e:
            self.logger.warning(f"İndikatör tespiti hatası: {str(e)}")
        
        return indicators
    
    def _calculate_rsi(self, prices: pd.Series, period: int = 14) -> pd.Series:
        """RSI hesapla"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    def _calculate_macd(self, prices: pd.Series, fast: int = 12, 
                       slow: int = 26, signal: int = 9) -> Dict[str, pd.Series]:
        """MACD hesapla"""
        ema_fast = prices.ewm(span=fast).mean()
        ema_slow = prices.ewm(span=slow).mean()
        
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=signal).mean()
        
        return {'macd': macd_line, 'signal': signal_line}
    
    def _calculate_bollinger_bands(self, prices: pd.Series, 
                                  period: int = 20, std_dev: float = 2.0) -> Dict[str, pd.Series]:
        """Bollinger Bands hesapla"""
        sma = prices.rolling(window=period).mean()
        std = prices.rolling(window=period).std()
        
        upper = sma + (std * std_dev)
        lower = sma - (std * std_dev)
        
        return {'upper': upper, 'lower': lower, 'middle': sma}
    
    def _calculate_adx(self, data: pd.DataFrame, period: int = 14) -> Dict[str, pd.Series]:
        """ADX hesapla (basitleştirilmiş)"""
        high = data['high']
        low = data['low']
        
        # Directional movement
        up_move = high.diff()
        down_move = -low.diff()
        
        plus_dm = up_move.where((up_move > down_move) & (up_move > 0), 0)
        minus_dm = down_move.where((down_move > up_move) & (down_move > 0), 0)
        
        # True range
        atr = self._calculate_atr(data)
        
        # Directional indicators
        plus_di = 100 * (plus_dm.rolling(window=period).mean() / atr)
        minus_di = 100 * (minus_dm.rolling(window=period).mean() / atr)
        
        # ADX
        dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
        adx = dx.rolling(window=period).mean()
        
        return {'adx': adx, 'plus_di': plus_di, 'minus_di': minus_di}
    
    def _classify_regime(self, metrics: RegimeMetrics) -> Dict[str, Any]:
        """
        Regime'i sınıflandır
        """
        trend_strength = metrics.trend_strength
        volatility_level = metrics.volatility_level
        
        # Regime skorları
        trending_score = 0
        ranging_score = 0
        volatile_score = 0
        
        # Trending regime: yüksek trend gücü, orta volatilite
        if trend_strength > 0.6 and volatility_level < 0.7:
            trending_score = trend_strength * (1 - volatility_level)
        
        # Ranging regime: düşük trend gücü, orta volatilite
        if trend_strength < 0.4 and volatility_level < 0.6:
            ranging_score = (1 - trend_strength) * (1 - volatility_level)
        
        # Volatile regime: yüksek volatilite
        if volatility_level > 0.8:
            volatile_score = volatility_level
        
        # En yüksek skoru seç
        scores = {
            'trending': trending_score,
            'ranging': ranging_score,
            'volatile': volatile_score
        }
        
        best_regime = max(scores, key=scores.get)
        max_score = scores[best_regime]
        
        # Minimum eşiği kontrol et
        if max_score < 0.2:
            return {'type': 'unknown', 'confidence': max_score}
        
        # Güven seviyesini normalize et
        confidence = min(max_score, 1.0)
        
        # Regime tipini güncelle
        metrics.regime_type = best_regime
        metrics.confidence = confidence
        
        return {'type': best_regime, 'confidence': confidence}
    
    def _analyze_trend(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Detaylı trend analizi
        """
        close_prices = data['close']
        
        # Trend yönü
        current_price = close_prices.iloc[-1]
        price_7d_ago = close_prices.iloc[-min(8, len(close_prices))]
        price_30d_ago = close_prices.iloc[-min(31, len(close_prices))]
        
        trend_7d = "up" if current_price > price_7d_ago else "down"
        trend_30d = "up" if current_price > price_30d_ago else "down"
        
        # Trend momentum
        returns_7d = close_prices.pct_change(7).iloc[-1]
        returns_30d = close_prices.pct_change(30).iloc[-1]
        
        # Support/resistance seviyeleri
        support_level = close_prices.rolling(window=30).min().iloc[-1]
        resistance_level = close_prices.rolling(window=30).max().iloc[-1]
        
        # Trend consistency
        direction_changes = self._count_trend_changes(close_prices)
        
        return {
            "direction_7d": trend_7d,
            "direction_30d": trend_30d,
            "momentum_7d": returns_7d,
            "momentum_30d": returns_30d,
            "support_level": support_level,
            "resistance_level": resistance_level,
            "price_position": (current_price - support_level) / (resistance_level - support_level),
            "trend_changes_30d": direction_changes,
            "trend_consistency": 1 - (direction_changes / 30)
        }
    
    def _count_trend_changes(self, prices: pd.Series, window: int = 5) -> int:
        """
        Trend değişimlerini say
        """
        if len(prices) < window * 2:
            return 0
        
        trends = []
        for i in range(window, len(prices) - window, window):
            segment_prices = prices.iloc[i-window:i+window]
            slope = np.polyfit(range(len(segment_prices)), segment_prices, 1)[0]
            trends.append(1 if slope > 0 else -1)
        
        changes = 0
        for i in range(1, len(trends)):
            if trends[i] != trends[i-1]:
                changes += 1
        
        return changes
    
    def _analyze_volatility(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Detaylı volatilite analizi
        """
        close_prices = data['close']
        
        # Günlük volatilite
        daily_returns = close_prices.pct_change().dropna()
        current_volatility = daily_returns.std()
        
        # Volatilite trendi
        vol_ma = daily_returns.rolling(window=7).std()
        vol_trend = "increasing" if vol_ma.iloc[-1] > vol_ma.mean() else "decreasing"
        
        # Volatilite percentiles
        vol_percentile = (current_volatility / daily_returns.std().max()) * 100
        
        # ATR analizi
        atr = self._calculate_atr(data)
        atr_current = atr.iloc[-1]
        atr_avg = atr.mean()
        atr_ratio = atr_current / atr_avg if atr_avg > 0 else 1
        
        # Volatilite kategorisi
        if current_volatility > daily_returns.std() * 1.5:
            vol_category = "high"
        elif current_volatility < daily_returns.std() * 0.5:
            vol_category = "low"
        else:
            vol_category = "normal"
        
        return {
            "current_level": current_volatility,
            "trend": vol_trend,
            "percentile": vol_percentile,
            "category": vol_category,
            "atr_current": atr_current,
            "atr_ratio": atr_ratio,
            "expected_range": {
                "lower": close_prices.iloc[-1] * (1 - current_volatility * 2),
                "upper": close_prices.iloc[-1] * (1 + current_volatility * 2)
            }
        }
    
    def _analyze_cycles(self, data: pd.DataFrame) -> Dict[str, Any]:
        """
        Market döngüsü analizi
        """
        try:
            close_prices = data['close']
            
            # Basit döngü tespiti - local extrema kullanarak
            local_maxima = []
            local_minima = []
            
            for i in range(2, len(close_prices) - 2):
                # Local maxima
                if (close_prices.iloc[i] > close_prices.iloc[i-1] and
                    close_prices.iloc[i] > close_prices.iloc[i+1] and
                    close_prices.iloc[i] > close_prices.iloc[i-2] and
                    close_prices.iloc[i] > close_prices.iloc[i+2]):
                    local_maxima.append((i, close_prices.iloc[i]))
                
                # Local minima
                if (close_prices.iloc[i] < close_prices.iloc[i-1] and
                    close_prices.iloc[i] < close_prices.iloc[i+1] and
                    close_prices.iloc[i] < close_prices.iloc[i-2] and
                    close_prices.iloc[i] < close_prices.iloc[i+2]):
                    local_minima.append((i, close_prices.iloc[i]))
            
            # Döngü uzunluğu tahmini
            if len(local_maxima) > 1:
                max_intervals = [local_maxima[i+1][0] - local_maxima[i][0] 
                               for i in range(len(local_maxima)-1)]
                avg_cycle_length = np.mean(max_intervals) if max_intervals else 0
            else:
                avg_cycle_length = 0
            
            # Mevcut döngü pozisyonu
            current_position = "unknown"
            if local_minima:
                last_min_idx = local_minima[-1][0]
                days_since_min = len(close_prices) - last_min_idx - 1
                if avg_cycle_length > 0:
                    cycle_position = (days_since_min % avg_cycle_length) / avg_cycle_length
                    if cycle_position < 0.25:
                        current_position = "early_recovery"
                    elif cycle_position < 0.5:
                        current_position = "mid_recovery"
                    elif cycle_position < 0.75:
                        current_position = "early_decline"
                    else:
                        current_position = "mid_decline"
            
            return {
                "cycle_length_days": avg_cycle_length,
                "current_position": current_position,
                "local_maxima_count": len(local_maxima),
                "local_minima_count": len(local_minima),
                "cycle_strength": min(len(local_maxima) + len(local_minima), 10) / 10
            }
            
        except Exception as e:
            self.logger.warning(f"Döngü analizi hatası: {str(e)}")
            return {
                "cycle_length_days": 0,
                "current_position": "unknown",
                "local_maxima_count": 0,
                "local_minima_count": 0,
                "cycle_strength": 0
            }
    
    def _unknown_regime(self, reason: str) -> Dict[str, Any]:
        """
        Bilinmeyen regime durumu
        """
        return {
            "regime_type": "unknown",
            "confidence": 0.0,
            "metrics": {
                "trend_strength": 0.5,
                "volatility_level": 0.5,
                "duration_estimate": 0
            },
            "reason": reason,
            "analysis_timestamp": datetime.now().isoformat(),
            "indicators_used": []
        }
    
    def compare_regimes(self, regime1: Dict, regime2: Dict) -> Dict[str, Any]:
        """
        İki regime'i karşılaştır
        """
        comparison = {
            "types_match": regime1["regime_type"] == regime2["regime_type"],
            "confidence_difference": abs(
                regime1["confidence"] - regime2["confidence"]
            ),
            "trend_strength_difference": abs(
                regime1["metrics"]["trend_strength"] - 
                regime2["metrics"]["trend_strength"]
            ),
            "volatility_difference": abs(
                regime1["metrics"]["volatility_level"] - 
                regime2["metrics"]["volatility_level"]
            ),
            "similarity_score": 0.0
        }
        
        # Benzerlik skoru hesapla
        type_match_score = 1 if comparison["types_match"] else 0
        confidence_score = 1 - min(comparison["confidence_difference"], 1)
        trend_score = 1 - min(comparison["trend_strength_difference"], 1)
        volatility_score = 1 - min(comparison["volatility_difference"], 1)
        
        comparison["similarity_score"] = (
            type_match_score * 0.4 +
            confidence_score * 0.2 +
            trend_score * 0.2 +
            volatility_score * 0.2
        )
        
        return comparison


# Test ve örnek kullanım
if __name__ == "__main__":
    import matplotlib.pyplot as plt
    import numpy as np
    
    # Test verisi oluştur
    np.random.seed(42)
    dates = pd.date_range(start='2024-01-01', end='2024-12-31', freq='D')
    
    # Trending veri simülasyonu
    trending_prices = 100 * np.exp(np.cumsum(np.random.normal(0.001, 0.02, len(dates))))
    trending_data = pd.DataFrame({
        'open': trending_prices * (1 + np.random.normal(0, 0.005, len(dates))),
        'high': trending_prices * (1 + np.abs(np.random.normal(0, 0.01, len(dates)))),
        'low': trending_prices * (1 - np.abs(np.random.normal(0, 0.01, len(dates)))),
        'close': trending_prices,
        'volume': np.random.uniform(1000, 10000, len(dates)) * 1000
    }, index=dates)
    
    # Ranging veri simülasyonu
    base_price = 100
    ranging_prices = base_price + np.random.normal(0, 2, len(dates)).cumsum()
    ranging_data = pd.DataFrame({
        'open': ranging_prices * (1 + np.random.normal(0, 0.005, len(dates))),
        'high': ranging_prices * (1 + np.abs(np.random.normal(0, 0.01, len(dates)))),
        'low': ranging_prices * (1 - np.abs(np.random.normal(0, 0.01, len(dates)))),
        'close': ranging_prices,
        'volume': np.random.uniform(1000, 10000, len(dates)) * 1000
    }, index=dates)
    
    # Volatile veri simülasyonu
    volatile_prices = 100 * (1 + np.random.normal(0, 0.05, len(dates))).cumprod()
    volatile_data = pd.DataFrame({
        'open': volatile_prices * (1 + np.random.normal(0, 0.01, len(dates))),
        'high': volatile_prices * (1 + np.abs(np.random.normal(0, 0.02, len(dates)))),
        'low': volatile_prices * (1 - np.abs(np.random.normal(0, 0.02, len(dates)))),
        'close': volatile_prices,
        'volume': np.random.uniform(1000, 10000, len(dates)) * 1000
    }, index=dates)
    
    # Regime detection test
    detector = MarketRegimeDetector()
    
    print("Market Regime Detection Test Sonuçları:")
    print("=" * 45)
    
    # Trending test
    trending_regime = detector.detect_regime(trending_data)
    print(f"Trending Market:")
    print(f"  Regime: {trending_regime['regime_type']}")
    print(f"  Confidence: {trending_regime['confidence']:.2f}")
    print(f"  Trend Strength: {trending_regime['metrics']['trend_strength']:.2f}")
    print(f"  Volatility: {trending_regime['metrics']['volatility_level']:.2f}")
    print()
    
    # Ranging test
    ranging_regime = detector.detect_regime(ranging_data)
    print(f"Ranging Market:")
    print(f"  Regime: {ranging_regime['regime_type']}")
    print(f"  Confidence: {ranging_regime['confidence']:.2f}")
    print(f"  Trend Strength: {ranging_regime['metrics']['trend_strength']:.2f}")
    print(f"  Volatility: {ranging_regime['metrics']['volatility_level']:.2f}")
    print()
    
    # Volatile test
    volatile_regime = detector.detect_regime(volatile_data)
    print(f"Volatile Market:")
    print(f"  Regime: {volatile_regime['regime_type']}")
    print(f"  Confidence: {volatile_regime['confidence']:.2f}")
    print(f"  Trend Strength: {volatile_regime['metrics']['trend_strength']:.2f}")
    print(f"  Volatility: {volatile_regime['metrics']['volatility_level']:.2f}")
    print()
    
    # Regime karşılaştırma
    comparison = detector.compare_regimes(trending_regime, ranging_regime)
    print(f"Trending vs Ranging Comparison:")
    print(f"  Types Match: {comparison['types_match']}")
    print(f"  Similarity Score: {comparison['similarity_score']:.2f}")
    print()
    
    print("Market Regime Detection testleri tamamlandı!")