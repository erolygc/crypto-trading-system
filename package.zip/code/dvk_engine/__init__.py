"""
Dinamik Varlık Karakterizasyonu (DVK) Engine
===========================================

Bu paket, kripto paraların hangi teknik indikatörler ve parametrelerle
en iyi performans gösterdiğini otomatik olarak tespit eden DVK algoritmasını
içerir.

Author: DVK Development Team
Date: 2025-10-30
Version: 1.0
"""

from .dvk_engine import DVKEngine
from .config.dvk_config import DVKConfig, DVKConfigProfiles
from .indicators.technical_indicators import TechnicalIndicators
from .regime_detection.market_regime_detector import MarketRegimeDetector
from .strategy_ranking.performance_ranker import PerformanceRanker
from .backtest.backtest_engine import BacktestEngine

__version__ = "1.0.0"
__author__ = "DVK Development Team"

__all__ = [
    'DVKEngine',
    'DVKConfig', 
    'DVKConfigProfiles',
    'TechnicalIndicators',
    'MarketRegimeDetector',
    'PerformanceRanker',
    'BacktestEngine'
]