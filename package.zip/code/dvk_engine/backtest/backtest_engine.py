"""
Backtest Engine Modülü
======================

DVK algoritması için basit backtest engine. Strategy'lerin
geçmiş veri üzerinde test edilmesini sağlar.

Author: DVK Development Team
Date: 2025-10-30
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Any, Optional
from datetime import datetime
import logging
from dataclasses import dataclass
import warnings
warnings.filterwarnings('ignore')


@dataclass
class Trade:
    """Trade bilgisi"""
    entry_time: datetime
    exit_time: datetime
    entry_price: float
    exit_price: float
    position_type: str  # 'long' or 'short'
    quantity: float
    pnl: float
    pnl_pct: float
    commission: float
    slippage: float


@dataclass
class BacktestResult:
    """Backtest sonuçları"""
    total_return: float
    win_rate: float
    total_trades: int
    winning_trades: int
    losing_trades: int
    avg_win: float
    avg_loss: float
    max_drawdown: float
    sharpe_ratio: float
    profit_factor: float
    trades: List[Trade]
    equity_curve: pd.Series
    performance_summary: Dict[str, float]


class BacktestEngine:
    """
    Basit backtest engine
    """
    
    def __init__(self, initial_capital: float = 100000, 
                 commission: float = 0.001, slippage: float = 0.0005):
        """
        Backtest engine başlatıcı
        
        Args:
            initial_capital: Başlangıç sermayesi
            commission: Komisyon oranı
            slippage: Slippage oranı
        """
        self.initial_capital = initial_capital
        self.commission = commission
        self.slippage = slippage
        self.logger = logging.getLogger('BacktestEngine')
    
    def run_backtest(self, data: pd.DataFrame, strategy_func, 
                    strategy_params: Dict[str, Any]) -> BacktestResult:
        """
        Strategy için backtest çalıştır
        
        Args:
            data: OHLCV veri çerçevesi
            strategy_func: Strategy fonksiyonu
            strategy_params: Strategy parametreleri
            
        Returns:
            Backtest sonuçları
        """
        try:
            # Signals üret
            signals = strategy_func(data, **strategy_params)
            
            # Trades simüle et
            trades = self._simulate_trades(data, signals)
            
            # Equity curve oluştur
            equity_curve = self._create_equity_curve(trades)
            
            # Performance metrikleri hesapla
            performance = self._calculate_performance(trades, equity_curve)
            
            return BacktestResult(
                total_return=performance['total_return'],
                win_rate=performance['win_rate'],
                total_trades=performance['total_trades'],
                winning_trades=performance['winning_trades'],
                losing_trades=performance['losing_trades'],
                avg_win=performance['avg_win'],
                avg_loss=performance['avg_loss'],
                max_drawdown=performance['max_drawdown'],
                sharpe_ratio=performance['sharpe_ratio'],
                profit_factor=performance['profit_factor'],
                trades=trades,
                equity_curve=equity_curve,
                performance_summary=performance
            )
            
        except Exception as e:
            self.logger.error(f"Backtest hatası: {str(e)}")
            # Empty result döndür
            return self._empty_result()
    
    def _simulate_trades(self, data: pd.DataFrame, signals: pd.Series) -> List[Trade]:
        """
        Trade simülasyonu
        """
        trades = []
        position = None
        entry_price = 0
        entry_time = None
        
        for i, (timestamp, signal) in enumerate(signals.items()):
            if pd.isna(signal):
                continue
                
            current_price = data.loc[timestamp, 'close']
            
            # Long position aç
            if signal == 1 and position is None:
                entry_price = current_price * (1 + self.slippage)  # Slippage ekle
                entry_time = timestamp
                position = 'long'
            
            # Long position kapat
            elif signal == -1 and position == 'long':
                exit_price = current_price * (1 - self.slippage)  # Slippage düş
                
                # Trade hesapla
                quantity = self.initial_capital / entry_price
                pnl = (exit_price - entry_price) * quantity
                commission_cost = (entry_price + exit_price) * quantity * self.commission
                net_pnl = pnl - commission_cost
                pnl_pct = net_pnl / self.initial_capital
                
                trade = Trade(
                    entry_time=entry_time,
                    exit_time=timestamp,
                    entry_price=entry_price,
                    exit_price=exit_price,
                    position_type='long',
                    quantity=quantity,
                    pnl=net_pnl,
                    pnl_pct=pnl_pct,
                    commission=commission_cost,
                    slippage=self.slippage
                )
                
                trades.append(trade)
                position = None
        
        return trades
    
    def _create_equity_curve(self, trades: List[Trade]) -> pd.Series:
        """
        Equity curve oluştur
        """
        equity = [self.initial_capital]
        
        for trade in trades:
            equity.append(equity[-1] + trade.pnl)
        
        return pd.Series(equity)
    
    def _calculate_performance(self, trades: List[Trade], 
                             equity_curve: pd.Series) -> Dict[str, float]:
        """
        Performance metrikleri hesapla
        """
        if not trades:
            return {
                'total_return': 0,
                'win_rate': 0,
                'total_trades': 0,
                'winning_trades': 0,
                'losing_trades': 0,
                'avg_win': 0,
                'avg_loss': 0,
                'max_drawdown': 0,
                'sharpe_ratio': 0,
                'profit_factor': 0
            }
        
        # Temel metrikler
        total_trades = len(trades)
        winning_trades = [t for t in trades if t.pnl > 0]
        losing_trades = [t for t in trades if t.pnl < 0]
        
        win_rate = len(winning_trades) / total_trades
        
        avg_win = np.mean([t.pnl_pct for t in winning_trades]) if winning_trades else 0
        avg_loss = np.mean([t.pnl_pct for t in losing_trades]) if losing_trades else 0
        
        # Toplam getiri
        total_return = (equity_curve.iloc[-1] - self.initial_capital) / self.initial_capital
        
        # Max drawdown
        cumulative_returns = equity_curve / self.initial_capital
        running_max = cumulative_returns.expanding().max()
        drawdown = (cumulative_returns - running_max) / running_max
        max_drawdown = abs(drawdown.min())
        
        # Sharpe ratio (basitleştirilmiş)
        returns = [t.pnl_pct for t in trades]
        if len(returns) > 1 and np.std(returns) > 0:
            sharpe_ratio = np.mean(returns) / np.std(returns) * np.sqrt(252)
        else:
            sharpe_ratio = 0
        
        # Profit factor
        gross_profit = sum(t.pnl for t in winning_trades)
        gross_loss = abs(sum(t.pnl for t in losing_trades))
        profit_factor = gross_profit / gross_loss if gross_loss > 0 else 0
        
        return {
            'total_return': total_return * 100,  # Percentage
            'win_rate': win_rate,
            'total_trades': total_trades,
            'winning_trades': len(winning_trades),
            'losing_trades': len(losing_trades),
            'avg_win': avg_win * 100,
            'avg_loss': avg_loss * 100,
            'max_drawdown': max_drawdown * 100,
            'sharpe_ratio': sharpe_ratio,
            'profit_factor': profit_factor
        }
    
    def _empty_result(self) -> BacktestResult:
        """
        Boş backtest sonucu döndür
        """
        return BacktestResult(
            total_return=0,
            win_rate=0,
            total_trades=0,
            winning_trades=0,
            losing_trades=0,
            avg_win=0,
            avg_loss=0,
            max_drawdown=0,
            sharpe_ratio=0,
            profit_factor=0,
            trades=[],
            equity_curve=pd.Series([self.initial_capital]),
            performance_summary={}
        )
    
    # Strategy örnekleri
    
    @staticmethod
    def rsi_strategy(data: pd.DataFrame, period: int = 14, 
                    oversold: float = 30, overbought: float = 70) -> pd.Series:
        """
        RSI bazlı strategy
        """
        from ..indicators.technical_indicators import TechnicalIndicators
        
        ti = TechnicalIndicators()
        rsi = ti.calculate_rsi(data['close'], period)
        
        signals = pd.Series(0, index=data.index)
        
        # Long signal
        signals[rsi < oversold] = 1
        # Short signal  
        signals[rsi > overbought] = -1
        
        return signals
    
    @staticmethod
    def macd_strategy(data: pd.DataFrame, fast: int = 12, 
                     slow: int = 26, signal: int = 9) -> pd.Series:
        """
        MACD bazlı strategy
        """
        from ..indicators.technical_indicators import TechnicalIndicators
        
        ti = TechnicalIndicators()
        macd_data = ti.calculate_macd(data['close'], fast, slow, signal)
        
        signals = pd.Series(0, index=data.index)
        
        # Golden cross
        macd_line = macd_data['macd']
        signal_line = macd_data['signal']
        
        # Long when MACD crosses above signal
        long_signals = (macd_line > signal_line) & (macd_line.shift(1) <= signal_line.shift(1))
        signals[long_signals] = 1
        
        # Short when MACD crosses below signal
        short_signals = (macd_line < signal_line) & (macd_line.shift(1) >= signal_line.shift(1))
        signals[short_signals] = -1
        
        return signals
    
    @staticmethod
    def bollinger_strategy(data: pd.DataFrame, period: int = 20, 
                          std_dev: float = 2.0) -> pd.Series:
        """
        Bollinger Bands bazlı strategy
        """
        from ..indicators.technical_indicators import TechnicalIndicators
        
        ti = TechnicalIndicators()
        bb_data = ti.calculate_bollinger_bands(data['close'], period, std_dev)
        
        signals = pd.Series(0, index=data.index)
        
        # Long when price touches lower band
        signals[data['close'] < bb_data['lower']] = 1
        
        # Short when price touches upper band
        signals[data['close'] > bb_data['upper']] = -1
        
        return signals
    
    def compare_strategies(self, results: List[BacktestResult]) -> Dict[str, Any]:
        """
        Strategy sonuçlarını karşılaştır
        """
        if not results:
            return {}
        
        comparison = {}
        
        for i, result in enumerate(results):
            strategy_name = f"Strategy_{i+1}"
            
            comparison[strategy_name] = {
                'total_return': result.total_return,
                'win_rate': result.win_rate,
                'sharpe_ratio': result.sharpe_ratio,
                'max_drawdown': result.max_drawdown,
                'profit_factor': result.profit_factor,
                'total_trades': result.total_trades,
                'score': self._calculate_composite_score(result)
            }
        
        # En iyi strategy'yi belirle
        best_strategy = max(comparison.keys(), 
                           key=lambda x: comparison[x]['score'])
        
        comparison['best_strategy'] = best_strategy
        comparison['rankings'] = sorted(
            [(name, data['score']) for name, data in comparison.items() 
             if name != 'best_strategy' and name != 'rankings'],
            key=lambda x: x[1],
            reverse=True
        )
        
        return comparison
    
    def _calculate_composite_score(self, result: BacktestResult) -> float:
        """
        Composite score hesapla
        """
        # Normalize edilmiş skorlar
        return_score = max(0, min(1, result.total_return / 100))
        win_rate_score = result.win_rate
        sharpe_score = max(0, min(1, result.sharpe_ratio / 3))
        drawdown_score = max(0, 1 - result.max_drawdown / 100)
        profit_factor_score = max(0, min(1, result.profit_factor / 2))
        
        # Ağırlıklı composite score
        composite = (
            return_score * 0.3 +
            win_rate_score * 0.2 +
            sharpe_score * 0.2 +
            drawdown_score * 0.2 +
            profit_factor_score * 0.1
        )
        
        return composite


# Test ve örnek kullanım
if __name__ == "__main__":
    import matplotlib.pyplot as plt
    import numpy as np
    
    # Test verisi oluştur
    np.random.seed(42)
    dates = pd.date_range(start='2024-01-01', end='2024-12-31', freq='D')
    prices = 100 * (1 + np.random.normal(0, 0.02, len(dates))).cumprod()
    
    ohlcv_data = pd.DataFrame({
        'open': prices * (1 + np.random.normal(0, 0.005, len(dates))),
        'high': prices * (1 + np.abs(np.random.normal(0, 0.01, len(dates)))),
        'low': prices * (1 - np.abs(np.random.normal(0, 0.01, len(dates)))),
        'close': prices,
        'volume': np.random.uniform(1000, 10000, len(dates)) * 1000
    }, index=dates)
    
    # Backtest engine test
    engine = BacktestEngine(initial_capital=100000)
    
    print("Backtest Engine Test Sonuçları:")
    print("=" * 35)
    
    # RSI strategy test
    rsi_result = engine.run_backtest(
        ohlcv_data, 
        BacktestEngine.rsi_strategy, 
        {'period': 14, 'oversold': 30, 'overbought': 70}
    )
    
    print("RSI Strategy:")
    print(f"  Total Return: {rsi_result.total_return:.2f}%")
    print(f"  Win Rate: {rsi_result.win_rate:.1%}")
    print(f"  Total Trades: {rsi_result.total_trades}")
    print(f"  Sharpe Ratio: {rsi_result.sharpe_ratio:.2f}")
    print(f"  Max Drawdown: {rsi_result.max_drawdown:.2f}%")
    print()
    
    # MACD strategy test
    macd_result = engine.run_backtest(
        ohlcv_data,
        BacktestEngine.macd_strategy,
        {'fast': 12, 'slow': 26, 'signal': 9}
    )
    
    print("MACD Strategy:")
    print(f"  Total Return: {macd_result.total_return:.2f}%")
    print(f"  Win Rate: {macd_result.win_rate:.1%}")
    print(f"  Total Trades: {macd_result.total_trades}")
    print(f"  Sharpe Ratio: {macd_result.sharpe_ratio:.2f}")
    print(f"  Max Drawdown: {macd_result.max_drawdown:.2f}%")
    print()
    
    # Strategy karşılaştırma
    comparison = engine.compare_strategies([rsi_result, macd_result])
    print("Strategy Comparison:")
    print(f"  Best Strategy: {comparison['best_strategy']}")
    print(f"  Rankings: {comparison['rankings']}")
    
    print("\nBacktest engine testleri tamamlandı!")