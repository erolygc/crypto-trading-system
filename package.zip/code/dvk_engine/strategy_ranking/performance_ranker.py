"""
Strategy Performance Ranking Modülü
===================================

Bu modül, DVK algoritmasında farklı indikatör kombinasyonlarının
performansını değerlendirir ve sıralar. Sharpe ratio, win rate ve
stability metriklerini kullanarak en optimal stratejileri belirler.

Author: DVK Development Team
Date: 2025-10-30
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Any, Optional
from datetime import datetime
import logging
from dataclasses import dataclass
import warnings
warnings.filterwarnings('ignore')


@dataclass
class PerformanceMetrics:
    """Performance metrikleri"""
    sharpe_ratio: float
    win_rate: float
    total_return: float
    max_drawdown: float
    profit_factor: float
    avg_profit_per_trade: float
    stability_score: float
    risk_adjusted_return: float
    calmar_ratio: float
    total_trades: int


@dataclass
class StrategyScore:
    """Strategy skorlaması"""
    strategy_id: str
    indicator: str
    parameters: Dict[str, Any]
    performance: PerformanceMetrics
    composite_score: float
    rank: int
    regime_suitability: float
    risk_level: str
    recommendation: str


class PerformanceRanker:
    """
    Strategy performans ranking sınıfı
    """
    
    def __init__(self):
        """Performance ranker'ı başlat"""
        self.logger = logging.getLogger('PerformanceRanker')
        
        # Ağırlıklandırma katsayıları
        self.weights = {
            'sharpe_ratio': 0.25,      # Risk-adjusted return
            'win_rate': 0.20,          # Kazanma oranı
            'stability': 0.20,         # Stabilite
            'total_return': 0.15,      # Toplam getiri
            'max_drawdown': 0.10,      # Risk kontrolü (ters ağırlık)
            'profit_factor': 0.10      # Kar/zarar oranı
        }
        
        # Minimum gereksinimler
        self.min_requirements = {
            'min_trades': 5,
            'min_return': -0.5,  # %-50'den fazla zarar kabul etmiyoruz
            'max_drawdown': 0.8,  # %80'den fazla drawdown kabul etmiyoruz
            'min_win_rate': 0.3   # %30'dan düşük win rate kabul etmiyoruz
        }
    
    def rank_strategies(self, parameter_results: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Tüm strategy'leri performanslarına göre sırala
        
        Args:
            parameter_results: Parameter sweep sonuçları
            
        Returns:
            Sıralanmış strategy listesi
        """
        self.logger.info("Strategy performans ranking başlatılıyor")
        
        all_strategies = []
        
        # Tüm indikatörlerden stratejileri topla
        for indicator_type, sweep_data in parameter_results.items():
            if "sweep_results" in sweep_data:
                for result in sweep_data["sweep_results"]:
                    strategy = self._prepare_strategy_data(result, indicator_type)
                    if strategy:
                        all_strategies.append(strategy)
        
        if not all_strategies:
            self.logger.warning("Ranking için hiç strategy bulunamadı")
            return []
        
        # Her strategy için composite score hesapla
        scored_strategies = []
        for strategy in all_strategies:
            try:
                score = self._calculate_composite_score(strategy)
                strategy['composite_score'] = score
                scored_strategies.append(strategy)
            except Exception as e:
                self.logger.error(f"Strategy scoring hatası: {str(e)}")
                continue
        
        # Sıralama yap
        scored_strategies.sort(key=lambda x: x['composite_score'], reverse=True)
        
        # Rank ata
        for i, strategy in enumerate(scored_strategies):
            strategy['rank'] = i + 1
        
        # En iyi stratejileri filtrele ve döndür
        top_strategies = self._filter_top_strategies(scored_strategies)
        
        self.logger.info(f"Toplam {len(scored_strategies)} strategy değerlendirildi, "
                        f"en iyi {len(top_strategies)} seçildi")
        
        return top_strategies
    
    def _prepare_strategy_data(self, result: Dict, indicator_type: str) -> Optional[Dict]:
        """
        Strategy verilerini hazırla
        """
        try:
            performance = result.get('performance', {})
            parameters = result.get('parameters', {})
            
            # Minimum gereksinimler kontrolü
            if not self._meets_minimum_requirements(performance):
                return None
            
            # Performance metriklerini hesapla
            metrics = self._calculate_performance_metrics(performance)
            
            # Risk seviyesi belirle
            risk_level = self._determine_risk_level(metrics)
            
            # Regime uygunluğu
            regime_suitability = result.get('suitable_for_regime', 0.5)
            
            # Strategy ID oluştur
            strategy_id = f"{indicator_type}_{parameters}"
            
            strategy_data = {
                'strategy_id': strategy_id,
                'indicator': indicator_type,
                'parameters': parameters,
                'performance': performance,
                'metrics': metrics,
                'regime_suitability': regime_suitability,
                'risk_level': risk_level
            }
            
            return strategy_data
            
        except Exception as e:
            self.logger.error(f"Strategy data hazırlama hatası: {str(e)}")
            return None
    
    def _meets_minimum_requirements(self, performance: Dict) -> bool:
        """
        Minimum gereksinimleri kontrol et
        """
        try:
            total_trades = performance.get('total_trades', 0)
            total_return = performance.get('total_return', 0) / 100  # Yüzde'den decimal'e çevir
            max_drawdown = performance.get('max_drawdown', 0) / 100
            win_rate = performance.get('win_rate', 0)
            
            return (total_trades >= self.min_requirements['min_trades'] and
                   total_return >= self.min_requirements['min_return'] and
                   max_drawdown <= self.min_requirements['max_drawdown'] and
                   win_rate >= self.min_requirements['min_win_rate'])
        
        except Exception:
            return False
    
    def _calculate_performance_metrics(self, performance: Dict) -> PerformanceMetrics:
        """
        Detaylı performans metriklerini hesapla
        """
        try:
            # Temel metrikler
            sharpe_ratio = performance.get('sharpe_ratio', 0)
            win_rate = performance.get('win_rate', 0)
            total_return = performance.get('total_return', 0) / 100  # %'den decimal'e
            max_drawdown = performance.get('max_drawdown', 0) / 100
            profit_factor = performance.get('profit_factor', 0)
            avg_profit = performance.get('avg_profit_per_trade', 0) / 100
            
            # Stability score hesapla
            stability_score = self._calculate_stability_score(performance)
            
            # Risk-adjusted return
            risk_adjusted_return = total_return / max(max_drawdown, 0.01)  # Drawdown zero olmasın diye
            
            # Calmar ratio (annual return / max drawdown)
            # Yıllık getiri tahmini (basitleştirilmiş)
            estimated_annual_return = total_return * (365 / 30)  # 30 günlük veriyi yıllığa çevir
            calmar_ratio = estimated_annual_return / max(max_drawdown, 0.01)
            
            return PerformanceMetrics(
                sharpe_ratio=sharpe_ratio,
                win_rate=win_rate,
                total_return=total_return,
                max_drawdown=max_drawdown,
                profit_factor=profit_factor,
                avg_profit_per_trade=avg_profit,
                stability_score=stability_score,
                risk_adjusted_return=risk_adjusted_return,
                calmar_ratio=calmar_ratio,
                total_trades=performance.get('total_trades', 0)
            )
            
        except Exception as e:
            self.logger.error(f"Performance metrics hesaplama hatası: {str(e)}")
            # Default değerler döndür
            return PerformanceMetrics(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    
    def _calculate_stability_score(self, performance: Dict) -> float:
        """
        Strategy stabilite skorunu hesapla
        """
        try:
            total_trades = performance.get('total_trades', 0)
            
            if total_trades < 2:
                return 0.5  # Yetersiz trade için orta skor
            
            # Win rate istikrarı (win_rate 0.5'e ne kadar yakınsa o kadar stabil)
            win_rate = performance.get('win_rate', 0)
            consistency = 1 - abs(win_rate - 0.5) * 2
            
            # Profit factor istikrarı (1.0'a ne kadar yakınsa o kadar stabil)
            profit_factor = performance.get('profit_factor', 0)
            if profit_factor > 0:
                pf_consistency = 1 - abs(profit_factor - 1.0) / max(profit_factor, 1.0)
            else:
                pf_consistency = 0
            
            # Trade count consistency (minimum trade sayısı için bonus)
            trade_consistency = min(total_trades / 20, 1.0)  # 20+ trade tam bonus
            
            # Composite stability score
            stability = (consistency * 0.4 + pf_consistency * 0.4 + trade_consistency * 0.2)
            
            return max(0, min(1, stability))
            
        except Exception:
            return 0.5
    
    def _determine_risk_level(self, metrics: PerformanceMetrics) -> str:
        """
        Strategy risk seviyesini belirle
        """
        try:
            # Risk faktörleri
            max_dd = metrics.max_drawdown
            volatility_proxy = abs(metrics.total_return) * 0.1  # Basit volatilite proxy
            
            # Risk skoru
            risk_score = (max_dd * 0.6 + volatility_proxy * 0.4)
            
            if risk_score < 0.2:
                return "Low"
            elif risk_score < 0.5:
                return "Medium"
            elif risk_score < 0.8:
                return "High"
            else:
                return "Very High"
                
        except Exception:
            return "Medium"
    
    def _calculate_composite_score(self, strategy: Dict) -> float:
        """
        Composite score hesapla
        """
        try:
            metrics = strategy['metrics']
            regime_suitability = strategy['regime_suitability']
            
            # Normalize edilmiş skorlar
            normalized_scores = {
                'sharpe_ratio': self._normalize_sharpe(metrics.sharpe_ratio),
                'win_rate': metrics.win_rate,
                'stability': metrics.stability_score,
                'total_return': self._normalize_return(metrics.total_return),
                'max_drawdown': self._normalize_drawdown(metrics.max_drawdown),
                'profit_factor': self._normalize_profit_factor(metrics.profit_factor)
            }
            
            # Ağırlıklı composite score
            composite_score = sum(
                normalized_scores[key] * weight 
                for key, weight in self.weights.items()
            )
            
            # Regime suitability bonus/malus
            regime_bonus = (regime_suitability - 0.5) * 0.1  # ±%5 bonus
            composite_score += regime_bonus
            
            # Risk penalty (çok yüksek risk için)
            risk_level = strategy['risk_level']
            risk_penalty = {
                'Low': 0,
                'Medium': -0.02,
                'High': -0.05,
                'Very High': -0.1
            }.get(risk_level, 0)
            
            final_score = max(0, min(1, composite_score + risk_penalty))
            
            return final_score
            
        except Exception as e:
            self.logger.error(f"Composite score hesaplama hatası: {str(e)}")
            return 0.0
    
    def _normalize_sharpe(self, sharpe: float) -> float:
        """
        Sharpe ratio'yu normalize et (0-1 arası)
        """
        if sharpe <= 0:
            return 0.0
        elif sharpe >= 3.0:
            return 1.0
        else:
            return sharpe / 3.0
    
    def _normalize_return(self, return_pct: float) -> float:
        """
        Return'ü normalize et (0-1 arası)
        """
        if return_pct <= -0.5:
            return 0.0
        elif return_pct >= 1.0:  # %100+ getiri
            return 1.0
        else:
            return (return_pct + 0.5) / 1.5  # -%50'den %100'e 0-1'e map et
    
    def _normalize_drawdown(self, drawdown: float) -> float:
        """
        Drawdown'u normalize et (ters - yüksek drawdown düşük skor)
        """
        if drawdown >= 0.8:
            return 0.0
        elif drawdown <= 0.1:
            return 1.0
        else:
            return 1.0 - (drawdown - 0.1) / 0.7
    
    def _normalize_profit_factor(self, pf: float) -> float:
        """
        Profit factor'ü normalize et
        """
        if pf <= 0:
            return 0.0
        elif pf >= 3.0:
            return 1.0
        else:
            return min(pf / 3.0, 1.0)
    
    def _filter_top_strategies(self, strategies: List[Dict]) -> List[Dict]:
        """
        En iyi stratejileri filtrele
        """
        # En az 10 strategy varsa top 10'u al, yoksa top 5'i al
        top_count = min(10, max(5, len(strategies) // 4))
        
        # Diversity için aynı indikatörden en fazla 3 tane al
        indicator_count = {}
        filtered_strategies = []
        
        for strategy in strategies:
            indicator = strategy['indicator']
            
            # Bu indikatörden kaç tane aldık
            current_count = indicator_count.get(indicator, 0)
            
            if current_count < 3:
                # Öneri ekle
                strategy['recommendation'] = self._generate_recommendation(strategy)
                filtered_strategies.append(strategy)
                indicator_count[indicator] = current_count + 1
            
            if len(filtered_strategies) >= top_count:
                break
        
        return filtered_strategies
    
    def _generate_recommendation(self, strategy: Dict) -> str:
        """
        Strategy için öneri oluştur
        """
        metrics = strategy['metrics']
        composite_score = strategy['composite_score']
        regime_suitability = strategy['regime_suitability']
        
        if composite_score >= 0.8:
            if metrics.win_rate >= 0.6:
                return "Strong Buy - High confidence strategy"
            else:
                return "Buy - Good risk-adjusted returns"
        elif composite_score >= 0.6:
            if metrics.stability_score >= 0.7:
                return "Hold - Stable performance"
            else:
                return "Moderate - Consider for diversification"
        elif composite_score >= 0.4:
            return "Weak - Monitor closely"
        else:
            return "Avoid - Poor performance metrics"
    
    def analyze_regime_performance(self, strategies: List[Dict]) -> Dict[str, Any]:
        """
        Regime'e göre strategy performanslarını analiz et
        """
        regime_analysis = {
            'trending': [],
            'ranging': [],
            'volatile': [],
            'overall_best': []
        }
        
        for strategy in strategies:
            suitability = strategy.get('regime_suitability', 0)
            indicator = strategy['indicator']
            score = strategy['composite_score']
            
            # Regime uygunluğuna göre grupla
            if suitability > 0.7:
                if indicator in ['MACD', 'ADX']:
                    regime_analysis['trending'].append(strategy)
                elif indicator in ['RSI', 'Bollinger_Bands']:
                    regime_analysis['ranging'].append(strategy)
                elif indicator in ['Bollinger_Bands', 'ATR']:
                    regime_analysis['volatile'].append(strategy)
            
            # Overall best
            if score > 0.7:
                regime_analysis['overall_best'].append(strategy)
        
        # Her kategori için top performers
        for regime in regime_analysis:
            regime_analysis[regime] = sorted(
                regime_analysis[regime], 
                key=lambda x: x['composite_score'], 
                reverse=True
            )[:5]
        
        return regime_analysis
    
    def get_allocation_recommendations(self, strategies: List[Dict], 
                                     total_capital: float = 100000) -> Dict[str, float]:
        """
        Strategy allocation önerilerini hesapla
        """
        if not strategies:
            return {}
        
        # Score ağırlıklı allocation
        total_score = sum(s['composite_score'] for s in strategies)
        
        if total_score == 0:
            # Equal allocation
            equal_share = total_capital / len(strategies)
            return {s['strategy_id']: equal_share for s in strategies}
        
        allocations = {}
        for strategy in strategies:
            score = strategy['composite_score']
            weight = score / total_score
            
            # Risk seviyesine göre adjustment
            risk_level = strategy['risk_level']
            risk_multiplier = {
                'Low': 1.2,
                'Medium': 1.0,
                'High': 0.7,
                'Very High': 0.3
            }.get(risk_level, 1.0)
            
            adjusted_weight = weight * risk_multiplier
            allocation = total_capital * adjusted_weight
            
            allocations[strategy['strategy_id']] = allocation
        
        # Normalize weights to sum to total_capital
        total_allocated = sum(allocations.values())
        if total_allocated > 0:
            scaling_factor = total_capital / total_allocated
            for key in allocations:
                allocations[key] *= scaling_factor
        
        return allocations
    
    def backtest_validation(self, strategies: List[Dict], 
                          validation_data: pd.DataFrame) -> Dict[str, Any]:
        """
        Strategy'lerin validation performansını test et
        """
        validation_results = {}
        
        for strategy in strategies:
            try:
                # Bu strategy'yi validation data üzerinde test et
                # (Basitleştirilmiş implementasyon)
                
                strategy_id = strategy['strategy_id']
                
                # Dummy validation (gerçek implementasyonda backtest yapılır)
                validation_performance = {
                    'total_return': strategy['performance']['total_return'] * np.random.uniform(0.8, 1.2),
                    'win_rate': max(0, min(1, strategy['performance']['win_rate'] * np.random.uniform(0.9, 1.1))),
                    'max_drawdown': strategy['performance']['max_drawdown'] * np.random.uniform(0.9, 1.1),
                    'sharpe_ratio': strategy['metrics'].sharpe_ratio * np.random.uniform(0.85, 1.15)
                }
                
                # Out-of-sample score
                oos_score = self._calculate_composite_score({
                    'metrics': PerformanceMetrics(**{**validation_performance, 
                                                   'total_trades': strategy['metrics'].total_trades // 2}),
                    'regime_suitability': strategy['regime_suitability'],
                    'risk_level': strategy['risk_level']
                })
                
                validation_results[strategy_id] = {
                    'original_score': strategy['composite_score'],
                    'validation_score': oos_score,
                    'performance_drift': abs(strategy['composite_score'] - oos_score),
                    'validation_performance': validation_performance
                }
                
            except Exception as e:
                self.logger.error(f"Validation test hatası {strategy['strategy_id']}: {str(e)}")
                continue
        
        return validation_results


# Test ve örnek kullanım
if __name__ == "__main__":
    # Test verisi oluştur
    test_strategies = [
        {
            'indicator': 'RSI',
            'parameters': {'period': 14},
            'performance': {
                'total_return': 15.5,
                'win_rate': 0.65,
                'max_drawdown': 8.2,
                'sharpe_ratio': 1.8,
                'profit_factor': 1.4,
                'avg_profit_per_trade': 2.1,
                'total_trades': 24
            },
            'suitable_for_regime': 0.8
        },
        {
            'indicator': 'MACD',
            'parameters': {'fast': 12, 'slow': 26, 'signal': 9},
            'performance': {
                'total_return': 22.3,
                'win_rate': 0.58,
                'max_drawdown': 12.5,
                'sharpe_ratio': 1.5,
                'profit_factor': 1.3,
                'avg_profit_per_trade': 3.2,
                'total_trades': 18
            },
            'suitable_for_regime': 0.9
        },
        {
            'indicator': 'Bollinger_Bands',
            'parameters': {'period': 20, 'multiplier': 2.0},
            'performance': {
                'total_return': 8.7,
                'win_rate': 0.72,
                'max_drawdown': 5.1,
                'sharpe_ratio': 1.2,
                'profit_factor': 1.8,
                'avg_profit_per_trade': 1.5,
                'total_trades': 31
            },
            'suitable_for_regime': 0.6
        }
    ]
    
    # Performance ranking test
    ranker = PerformanceRanker()
    
    print("Strategy Performance Ranking Test:")
    print("=" * 40)
    
    # Parameter results formatını oluştur
    parameter_results = {
        'rsi': {'sweep_results': [test_strategies[0]]},
        'macd': {'sweep_results': [test_strategies[1]]},
        'bollinger_bands': {'sweep_results': [test_strategies[2]]}
    }
    
    # Ranking yap
    ranked_strategies = ranker.rank_strategies(parameter_results)
    
    print(f"Toplam strategy sayısı: {len(ranked_strategies)}")
    print()
    
    for i, strategy in enumerate(ranked_strategies[:3], 1):
        print(f"#{i} {strategy['indicator']} Strategy")
        print(f"  Composite Score: {strategy['composite_score']:.3f}")
        print(f"  Win Rate: {strategy['performance']['win_rate']:.1%}")
        print(f"  Total Return: {strategy['performance']['total_return']:.1f}%")
        print(f"  Sharpe Ratio: {strategy['metrics'].sharpe_ratio:.2f}")
        print(f"  Recommendation: {strategy['recommendation']}")
        print()
    
    # Allocation önerileri
    allocations = ranker.get_allocation_recommendations(ranked_strategies, 100000)
    print("Allocation Recommendations (Total Capital: $100,000):")
    print("-" * 55)
    for strategy_id, allocation in allocations.items():
        print(f"{strategy_id}: ${allocation:,.0f} ({allocation/100000:.1%})")
    
    print("\nPerformance ranking testleri tamamlandı!")