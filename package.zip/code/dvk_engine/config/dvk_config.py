"""
DVK Konfigürasyon Modülü
========================

Dinamik Varlık Karakterizasyonu algoritması için tüm konfigürasyon
parametrelerini ve ayarları içerir.

Author: DVK Development Team
Date: 2025-10-30
"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
import os


@dataclass
class DVKConfig:
    """
    DVK ana konfigürasyon sınıfı
    """
    
    # Genel Ayarlar
    analysis_period_days: int = 30  # Analiz periyodu (gün)
    lookback_days: int = 90  # Geçmiş veri bakış süresi
    update_frequency_hours: int = 6  # Güncelleme sıklığı (saat)
    max_parallel_analysis: int = 5  # Paralel analiz sayısı
    
    # RSI Parametreleri
    rsi_min_period: int = 5
    rsi_max_period: int = 50
    rsi_step: int = 5
    rsi_oversold: float = 30.0
    rsi_overbought: float = 70.0
    
    # MACD Parametreleri
    macd_fast_periods: List[int] = field(default_factory=lambda: [8, 12, 16, 20, 24])
    macd_slow_periods: List[int] = field(default_factory=lambda: [18, 24, 30, 36, 42])
    macd_signal_periods: List[int] = field(default_factory=lambda: [6, 9, 12, 15])
    
    # Bollinger Bands Parametreleri
    bb_periods: List[int] = field(default_factory=lambda: [10, 15, 20, 25, 30])
    bb_std_multipliers: List[float] = field(default_factory=lambda: [1.5, 2.0, 2.5, 3.0])
    
    # Stochastic Parametreleri
    stochastic_k_periods: List[int] = field(default_factory=lambda: [10, 14, 18, 22])
    stochastic_d_periods: List[int] = field(default_factory=lambda: [3, 5, 7])
    
    # Performance Ranking Ağırlıkları
    performance_weights: Dict[str, float] = field(default_factory=lambda: {
        'sharpe_ratio': 0.25,
        'win_rate': 0.20,
        'stability': 0.20,
        'total_return': 0.15,
        'max_drawdown': 0.10,
        'profit_factor': 0.10
    })
    
    # Minimum Gereksinimler
    min_requirements: Dict[str, float] = field(default_factory=lambda: {
        'min_trades': 5,
        'min_return': -0.5,  # -50%
        'max_drawdown': 0.8,  # 80%
        'min_win_rate': 0.3   # 30%
    })
    
    # Risk Parametreleri
    risk_levels: Dict[str, Dict[str, float]] = field(default_factory=lambda: {
        'low': {'max_drawdown': 0.15, 'volatility_limit': 0.3},
        'medium': {'max_drawdown': 0.30, 'volatility_limit': 0.5},
        'high': {'max_drawdown': 0.50, 'volatility_limit': 0.8},
        'very_high': {'max_drawdown': 1.0, 'volatility_limit': 1.5}
    })
    
    # Market Regime Eşikleri
    regime_thresholds: Dict[str, Dict[str, float]] = field(default_factory=lambda: {
        'trending': {
            'min_trend_strength': 0.6,
            'max_volatility': 0.7,
            'min_duration': 5
        },
        'ranging': {
            'max_trend_strength': 0.4,
            'max_volatility': 0.6,
            'min_duration': 7
        },
        'volatile': {
            'min_volatility': 0.8,
            'max_duration': 3
        }
    })
    
    # Regime-İndikatör Uygunluk Matrisi
    regime_indicator_suitability: Dict[str, Dict[str, float]] = field(default_factory=lambda: {
        'trending': {
            'MACD': 0.9,
            'ADX': 0.8,
            'EMA_Crossover': 0.8,
            'RSI': 0.7,
            'Bollinger_Bands': 0.6,
            'Stochastic': 0.5
        },
        'ranging': {
            'RSI': 0.9,
            'Bollinger_Bands': 0.8,
            'Stochastic': 0.7,
            'MACD': 0.4,
            'ADX': 0.3
        },
        'volatile': {
            'Bollinger_Bands': 0.9,
            'ATR': 0.8,
            'RSI': 0.6,
            'Stochastic': 0.5,
            'MACD': 0.3
        }
    })
    
    # Strategy Filtering
    max_strategies_per_indicator: int = 3
    top_strategies_count: int = 10
    min_composite_score: float = 0.4
    
    # Backtest Ayarları
    backtest_initial_capital: float = 100000.0
    backtest_commission: float = 0.001  # 0.1%
    backtest_slippage: float = 0.0005  # 0.05%
    
    # Real-time Strategy Activation
    strategy_activation_threshold: float = 0.6
    regime_suitability_threshold: float = 0.6
    min_win_rate_activation: float = 0.4
    min_sharpe_activation: float = 0.5
    max_active_strategies_per_coin: int = 3
    
    # Data Source Ayarları
    data_sources: Dict[str, Dict[str, Any]] = field(default_factory=lambda: {
        'primary': {
            'name': 'Binance',
            'api_base_url': 'https://api.binance.com',
            'rate_limit': 1200,  # requests per minute
            'weight': 1.0
        },
        'secondary': {
            'name': 'CoinGecko',
            'api_base_url': 'https://api.coingecko.com/api/v3',
            'rate_limit': 50,  # requests per minute
            'weight': 0.8
        }
    })
    
    # Caching Ayarları
    cache_ttl_minutes: int = 30
    cache_max_size: int = 1000
    enable_cache: bool = True
    
    # Logging Ayarları
    log_level: str = 'INFO'
    log_format: str = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    log_file: str = 'dvk_engine.log'
    enable_file_logging: bool = True
    
    # Alert Ayarları
    enable_alerts: bool = True
    alert_threshold_performance_drop: float = 0.2  # %20 performans düşüşü
    alert_threshold_new_regime: bool = True
    
    # Bitwisers Integration
    bitwisers_endpoint: str = 'http://localhost:8080/api/dvk'
    bitwisers_timeout: int = 30  # seconds
    bitwisers_retry_attempts: int = 3
    bitwisers_auth_token: Optional[str] = None
    
    # Monitoring ve Metrics
    enable_monitoring: bool = True
    metrics_retention_days: int = 30
    performance_tracking_enabled: bool = True
    
    # Feature Flags
    use_ml_enhancement: bool = False  # Machine learning geliştirmeleri
    enable_regime_detection: bool = True
    enable_multi_timeframe: bool = False
    enable_portfolio_optimization: bool = True
    
    # Gelişmiş Ayarlar
    use_ensemble_methods: bool = False
    confidence_threshold: float = 0.7
    volatility_adjustment: bool = True
    correlation_filtering: bool = True
    
    def validate_config(self) -> List[str]:
        """
        Konfigürasyon doğrulaması
        
        Returns:
            Hata listesi (varsa)
        """
        errors = []
        
        # Parametre kontrolü
        if self.analysis_period_days <= 0:
            errors.append("analysis_period_days must be positive")
        
        if self.max_parallel_analysis <= 0:
            errors.append("max_parallel_analysis must be positive")
        
        # RSI kontrolü
        if self.rsi_min_period >= self.rsi_max_period:
            errors.append("rsi_min_period must be less than rsi_max_period")
        
        if not (0 < self.rsi_oversold < self.rsi_overbought < 100):
            errors.append("RSI oversold/overbought values must be between 0 and 100")
        
        # MACD kontrolü
        if not self.macd_fast_periods or not self.macd_slow_periods:
            errors.append("MACD periods cannot be empty")
        
        for fast in self.macd_fast_periods:
            for slow in self.macd_slow_periods:
                if fast >= slow:
                    errors.append(f"MACD fast period ({fast}) must be less than slow period ({slow})")
        
        # Ağırlık kontrolü
        total_weight = sum(self.performance_weights.values())
        if abs(total_weight - 1.0) > 0.01:
            errors.append(f"Performance weights must sum to 1.0, got {total_weight}")
        
        # Risk seviyesi kontrolü
        for level, limits in self.risk_levels.items():
            if limits['max_drawdown'] > 1.0:
                errors.append(f"Risk level {level} max_drawdown cannot exceed 1.0")
        
        return errors
    
    def get_indicator_config(self, indicator: str) -> Dict[str, Any]:
        """
        Belirli bir indikatör için konfigürasyon al
        
        Args:
            indicator: İndikatör adı
            
        Returns:
            İndikatör konfigürasyonu
        """
        configs = {
            'RSI': {
                'periods': list(range(self.rsi_min_period, self.rsi_max_period + 1, self.rsi_step)),
                'oversold': self.rsi_oversold,
                'overbought': self.rsi_overbought
            },
            'MACD': {
                'fast_periods': self.macd_fast_periods,
                'slow_periods': self.macd_slow_periods,
                'signal_periods': self.macd_signal_periods
            },
            'Bollinger_Bands': {
                'periods': self.bb_periods,
                'std_multipliers': self.bb_std_multipliers
            },
            'Stochastic': {
                'k_periods': self.stochastic_k_periods,
                'd_periods': self.stochastic_d_periods
            }
        }
        
        return configs.get(indicator, {})
    
    def get_regime_suitability(self, indicator: str, regime: str) -> float:
        """
        İndikatör-regime uygunluğunu al
        
        Args:
            indicator: İndikatör adı
            regime: Market regime
            
        Returns:
            Uygunluk skoru (0-1)
        """
        return self.regime_indicator_suitability.get(regime, {}).get(indicator, 0.5)
    
    def save_config(self, filepath: str = 'dvk_config.yaml'):
        """
        Konfigürasyonu dosyaya kaydet
        
        Args:
            filepath: Kaydetme dosya yolu
        """
        import yaml
        
        config_dict = {
            'analysis_period_days': self.analysis_period_days,
            'lookback_days': self.lookback_days,
            'update_frequency_hours': self.update_frequency_hours,
            'max_parallel_analysis': self.max_parallel_analysis,
            'rsi_parameters': {
                'min_period': self.rsi_min_period,
                'max_period': self.rsi_max_period,
                'oversold': self.rsi_oversold,
                'overbought': self.rsi_overbought
            },
            'macd_parameters': {
                'fast_periods': self.macd_fast_periods,
                'slow_periods': self.macd_slow_periods,
                'signal_periods': self.macd_signal_periods
            },
            'performance_weights': self.performance_weights,
            'min_requirements': self.min_requirements,
            'strategy_activation': {
                'threshold': self.strategy_activation_threshold,
                'regime_suitability': self.regime_suitability_threshold,
                'min_win_rate': self.min_win_rate_activation,
                'min_sharpe': self.min_sharpe_activation
            }
        }
        
        with open(filepath, 'w', encoding='utf-8') as f:
            yaml.dump(config_dict, f, default_flow_style=False, allow_unicode=True)
    
    @classmethod
    def load_config(cls, filepath: str = 'dvk_config.yaml') -> 'DVKConfig':
        """
        Konfigürasyonu dosyadan yükle
        
        Args:
            filepath: Yükleme dosya yolu
            
        Returns:
            Konfigürasyon nesnesi
        """
        try:
            import yaml
            
            with open(filepath, 'r', encoding='utf-8') as f:
                config_data = yaml.safe_load(f)
            
            # Default değerlerle başla
            config = cls()
            
            # Dosyadan gelen değerleri uygula
            if config_data:
                for key, value in config_data.items():
                    if hasattr(config, key):
                        setattr(config, key, value)
            
            return config
            
        except Exception as e:
            print(f"Config yükleme hatası: {e}")
            return cls()  # Default config döndür


# Çevre değişkenleri ile config override
class EnvironmentConfig(DVKConfig):
    """
    Çevre değişkenleri ile override edilebilir konfigürasyon
    """
    
    def __init__(self):
        super().__init__()
        
        # Çevre değişkenlerinden override et
        if os.getenv('DVK_LOG_LEVEL'):
            self.log_level = os.getenv('DVK_LOG_LEVEL')
        
        if os.getenv('DVK_MAX_PARALLEL'):
            self.max_parallel_analysis = int(os.getenv('DVK_MAX_PARALLEL'))
        
        if os.getenv('DVK_ANALYSIS_DAYS'):
            self.analysis_period_days = int(os.getenv('DVK_ANALYSIS_DAYS'))
        
        if os.getenv('DVK_BITWISERS_TOKEN'):
            self.bitwisers_auth_token = os.getenv('DVK_BITWISERS_TOKEN')
        
        if os.getenv('DVK_ENABLE_ML') == 'true':
            self.use_ml_enhancement = True
        
        if os.getenv('DVK_DEBUG') == 'true':
            self.log_level = 'DEBUG'


# Önceden tanımlı konfigürasyon profilleri
class DVKConfigProfiles:
    """
    DVK konfigürasyon profilleri
    """
    
    @staticmethod
    def conservative_config() -> DVKConfig:
        """Konservatif yaklaşım - düşük risk"""
        config = DVKConfig()
        config.performance_weights = {
            'sharpe_ratio': 0.30,
            'win_rate': 0.25,
            'stability': 0.25,
            'total_return': 0.10,
            'max_drawdown': 0.05,
            'profit_factor': 0.05
        }
        config.min_requirements = {
            'min_trades': 10,
            'min_return': -0.2,
            'max_drawdown': 0.15,
            'min_win_rate': 0.5
        }
        config.strategy_activation_threshold = 0.7
        return config
    
    @staticmethod
    def aggressive_config() -> DVKConfig:
        """Agresif yaklaşım - yüksek getiri odaklı"""
        config = DVKConfig()
        config.performance_weights = {
            'sharpe_ratio': 0.20,
            'win_rate': 0.15,
            'stability': 0.15,
            'total_return': 0.30,
            'max_drawdown': 0.10,
            'profit_factor': 0.10
        }
        config.min_requirements = {
            'min_trades': 3,
            'min_return': -0.8,
            'max_drawdown': 0.6,
            'min_win_rate': 0.25
        }
        config.strategy_activation_threshold = 0.5
        return config
    
    @staticmethod
    def balanced_config() -> DVKConfig:
        """Dengeli yaklaşım"""
        return DVKConfig()  # Default config zaten dengeli


# Test ve örnek kullanım
if __name__ == "__main__":
    print("DVK Konfigürasyon Testi:")
    print("=" * 30)
    
    # Default config
    default_config = DVKConfig()
    print("Default Config:")
    print(f"  Analysis Period: {default_config.analysis_period_days} days")
    print(f"  Max Parallel: {default_config.max_parallel_analysis}")
    print(f"  RSI Range: {default_config.rsi_min_period}-{default_config.rsi_max_period}")
    
    # Config validation
    errors = default_config.validate_config()
    if errors:
        print(f"Config Errors: {errors}")
    else:
        print("Config validation: OK")
    
    # Profil configs
    conservative = DVKConfigProfiles.conservative_config()
    aggressive = DVKConfigProfiles.aggressive_config()
    
    print("\nConservative Profile:")
    print(f"  Strategy Activation Threshold: {conservative.strategy_activation_threshold}")
    print(f"  Min Win Rate: {conservative.min_requirements['min_win_rate']}")
    
    print("\nAggressive Profile:")
    print(f"  Strategy Activation Threshold: {aggressive.strategy_activation_threshold}")
    print(f"  Min Win Rate: {aggressive.min_requirements['min_win_rate']}")
    
    # Config kaydet
    try:
        default_config.save_config('test_dvk_config.yaml')
        print("\nConfig saved to test_dvk_config.yaml")
    except Exception as e:
        print(f"Config save error: {e}")
    
    print("\nKonfigürasyon testi tamamlandı!")