"""
Teknik İndikatörler Modülü
==========================

Bu modül, DVK algoritması için gerekli tüm teknik indikatörleri içerir.
RSI, MACD, Bollinger Bands, Stochastic ve diğer popüler indikatörleri hesaplar.

Author: DVK Development Team
Date: 2025-10-30
"""

import pandas as pd
import numpy as np
from typing import Dict, Tuple, Union, Optional
import warnings
warnings.filterwarnings('ignore')


class TechnicalIndicators:
    """
    Teknik indikatörler hesaplama sınıfı
    """
    
    def __init__(self):
        """İndikatör sınıfını başlat"""
        pass
    
    def calculate_rsi(self, prices: pd.Series, period: int = 14) -> pd.Series:
        """
        Relative Strength Index (RSI) hesapla
        
        Args:
            prices: Fiyat serisi
            period: RSI periyodu (varsayılan: 14)
            
        Returns:
            RSI değerleri
        """
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        return rsi
    
    def calculate_macd(self, prices: pd.Series, fast: int = 12, 
                      slow: int = 26, signal: int = 9) -> Dict[str, pd.Series]:
        """
        MACD (Moving Average Convergence Divergence) hesapla
        
        Args:
            prices: Fiyat serisi
            fast: Hızlı EMA periyodu (varsayılan: 12)
            slow: Yavaş EMA periyodu (varsayılan: 26)
            signal: Signal line periyodu (varsayılan: 9)
            
        Returns:
            MACD line, Signal line ve Histogram içeren dict
        """
        ema_fast = prices.ewm(span=fast).mean()
        ema_slow = prices.ewm(span=slow).mean()
        
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=signal).mean()
        histogram = macd_line - signal_line
        
        return {
            'macd': macd_line,
            'signal': signal_line,
            'histogram': histogram
        }
    
    def calculate_bollinger_bands(self, prices: pd.Series, 
                                 period: int = 20, 
                                 std_dev: float = 2.0) -> Dict[str, pd.Series]:
        """
        Bollinger Bands hesapla
        
        Args:
            prices: Fiyat serisi
            period: Periyot (varsayılan: 20)
            std_dev: Standart sapma çarpanı (varsayılan: 2.0)
            
        Returns:
            Üst, alt ve orta bantları içeren dict
        """
        sma = prices.rolling(window=period).mean()
        std = prices.rolling(window=period).std()
        
        upper_band = sma + (std * std_dev)
        lower_band = sma - (std * std_dev)
        
        return {
            'upper': upper_band,
            'middle': sma,
            'lower': lower_band,
            'width': upper_band - lower_band,
            'position': (prices - lower_band) / (upper_band - lower_band)
        }
    
    def calculate_stochastic(self, ohlcv_data: pd.DataFrame, 
                           k_period: int = 14, 
                           d_period: int = 3) -> Dict[str, pd.Series]:
        """
        Stochastic Oscillator hesapla
        
        Args:
            ohlcv_data: OHLCV veri çerçevesi
            k_period: %K periyodu (varsayılan: 14)
            d_period: %D periyodu (varsayılan: 3)
            
        Returns:
            %K ve %D değerleri içeren dict
        """
        low_min = ohlcv_data['low'].rolling(window=k_period).min()
        high_max = ohlcv_data['high'].rolling(window=k_period).max()
        
        k_percent = 100 * ((ohlcv_data['close'] - low_min) / (high_max - low_min))
        d_percent = k_percent.rolling(window=d_period).mean()
        
        return {
            'k': k_percent,
            'd': d_percent
        }
    
    def calculate_sma(self, prices: pd.Series, period: int) -> pd.Series:
        """
        Simple Moving Average hesapla
        
        Args:
            prices: Fiyat serisi
            period: Periyot
            
        Returns:
            SMA değerleri
        """
        return prices.rolling(window=period).mean()
    
    def calculate_ema(self, prices: pd.Series, period: int) -> pd.Series:
        """
        Exponential Moving Average hesapla
        
        Args:
            prices: Fiyat serisi
            period: Periyot
            
        Returns:
            EMA değerleri
        """
        return prices.ewm(span=period).mean()
    
    def calculate_atr(self, ohlcv_data: pd.DataFrame, period: int = 14) -> pd.Series:
        """
        Average True Range (ATR) hesapla
        
        Args:
            ohlcv_data: OHLCV veri çerçevesi
            period: Periyot (varsayılan: 14)
            
        Returns:
            ATR değerleri
        """
        high = ohlcv_data['high']
        low = ohlcv_data['low']
        close = ohlcv_data['close']
        
        tr1 = high - low
        tr2 = abs(high - close.shift())
        tr3 = abs(low - close.shift())
        
        true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        atr = true_range.rolling(window=period).mean()
        
        return atr
    
    def calculate_adx(self, ohlcv_data: pd.DataFrame, period: int = 14) -> Dict[str, pd.Series]:
        """
        Average Directional Index (ADX) hesapla
        
        Args:
            ohlcv_data: OHLCV veri çerçevesi
            period: Periyot (varsayılan: 14)
            
        Returns:
            ADX, +DI ve -DI değerleri içeren dict
        """
        high = ohlcv_data['high']
        low = ohlcv_data['low']
        close = ohlcv_data['close']
        
        # Directional Movement
        up_move = high - high.shift()
        down_move = low.shift() - low
        
        plus_dm = pd.Series(0.0, index=close.index)
        minus_dm = pd.Series(0.0, index=close.index)
        
        plus_dm[(up_move > down_move) & (up_move > 0)] = up_move
        minus_dm[(down_move > up_move) & (down_move > 0)] = down_move
        
        # True Range
        atr_values = self.calculate_atr(ohlcv_data, period)
        
        # Directional Indicators
        plus_di = 100 * (plus_dm.rolling(window=period).mean() / atr_values)
        minus_di = 100 * (minus_dm.rolling(window=period).mean() / atr_values)
        
        # ADX
        dx = 100 * abs(plus_di - minus_di) / (plus_di + minus_di)
        adx = dx.rolling(window=period).mean()
        
        return {
            'adx': adx,
            'plus_di': plus_di,
            'minus_di': minus_di
        }
    
    def calculate_williams_r(self, ohlcv_data: pd.DataFrame, period: int = 14) -> pd.Series:
        """
        Williams %R hesapla
        
        Args:
            ohlcv_data: OHLCV veri çerçevesi
            period: Periyot (varsayılan: 14)
            
        Returns:
            Williams %R değerleri
        """
        high_max = ohlcv_data['high'].rolling(window=period).max()
        low_min = ohlcv_data['low'].rolling(window=period).min()
        
        wr = -100 * ((high_max - ohlcv_data['close']) / (high_max - low_min))
        
        return wr
    
    def calculate_cci(self, ohlcv_data: pd.DataFrame, period: int = 20) -> pd.Series:
        """
        Commodity Channel Index (CCI) hesapla
        
        Args:
            ohlcv_data: OHLCV veri çerçevesi
            period: Periyot (varsayılan: 20)
            
        Returns:
            CCI değerleri
        """
        typical_price = (ohlcv_data['high'] + ohlcv_data['low'] + ohlcv_data['close']) / 3
        sma_tp = typical_price.rolling(window=period).mean()
        mean_deviation = typical_price.rolling(window=period).apply(
            lambda x: np.mean(np.abs(x - x.mean()))
        )
        
        cci = (typical_price - sma_tp) / (0.015 * mean_deviation)
        
        return cci
    
    def calculate_roc(self, prices: pd.Series, period: int = 10) -> pd.Series:
        """
        Rate of Change (ROC) hesapla
        
        Args:
            prices: Fiyat serisi
            period: Periyot (varsayılan: 10)
            
        Returns:
            ROC değerleri
        """
        roc = ((prices - prices.shift(period)) / prices.shift(period)) * 100
        return roc
    
    def calculate_mfi(self, ohlcv_data: pd.DataFrame, period: int = 14) -> pd.Series:
        """
        Money Flow Index (MFI) hesapla
        
        Args:
            ohlcv_data: OHLCV veri çerçevesi
            period: Periyot (varsayılan: 14)
            
        Returns:
            MFI değerleri
        """
        typical_price = (ohlcv_data['high'] + ohlcv_data['low'] + ohlcv_data['close']) / 3
        money_flow = typical_price * ohlcv_data['volume']
        
        positive_flow = money_flow.where(typical_price > typical_price.shift(), 0)
        negative_flow = money_flow.where(typical_price < typical_price.shift(), 0)
        
        positive_mf = positive_flow.rolling(window=period).sum()
        negative_mf = negative_flow.rolling(window=period).sum()
        
        money_ratio = positive_mf / negative_mf
        mfi = 100 - (100 / (1 + money_ratio))
        
        return mfi
    
    def calculate_psar(self, ohlcv_data: pd.DataFrame, 
                      af_start: float = 0.02, 
                      af_max: float = 0.2, 
                      af_increment: float = 0.02) -> Dict[str, pd.Series]:
        """
        Parabolic SAR hesapla
        
        Args:
            ohlcv_data: OHLCV veri çerçevesi
            af_start: Başlangıç acceleration factor
            af_max: Maksimum acceleration factor
            af_increment: Acceleration factor artışı
            
        Returns:
            SAR değerleri ve trend bilgisi
        """
        high = ohlcv_data['high']
        low = ohlcv_data['low']
        close = ohlcv_data['close']
        
        sar = pd.Series(0.0, index=close.index)
        af = af_start
        ep = 0.0
        trend = 1  # 1: yukarı, -1: aşağı
        
        for i in range(1, len(close)):
            if i == 1:
                if close.iloc[i] > close.iloc[i-1]:
                    trend = 1
                    sar.iloc[i] = low.iloc[i-1]
                    ep = high.iloc[i-1]
                else:
                    trend = -1
                    sar.iloc[i] = high.iloc[i-1]
                    ep = low.iloc[i-1]
            else:
                # Önceki SAR'ı hesapla
                if trend == 1:
                    sar.iloc[i] = sar.iloc[i-1] + af * (ep - sar.iloc[i-1])
                    # Trend değişim kontrolü
                    if low.iloc[i] <= sar.iloc[i]:
                        trend = -1
                        sar.iloc[i] = ep
                        af = af_start
                        ep = low.iloc[i]
                else:
                    sar.iloc[i] = sar.iloc[i-1] + af * (ep - sar.iloc[i-1])
                    # Trend değişim kontrolü
                    if high.iloc[i] >= sar.iloc[i]:
                        trend = 1
                        sar.iloc[i] = ep
                        af = af_start
                        ep = high.iloc[i]
                
                # Acceleration factor güncelle
                if trend == 1 and high.iloc[i] > ep:
                    ep = high.iloc[i]
                    af = min(af + af_increment, af_max)
                elif trend == -1 and low.iloc[i] < ep:
                    ep = low.iloc[i]
                    af = min(af + af_increment, af_max)
        
        return {
            'sar': sar,
            'trend': pd.Series([1 if close.iloc[i] > sar.iloc[i] else -1 
                              for i in range(len(close))], index=close.index)
        }
    
    def calculate_keltner_channels(self, ohlcv_data: pd.DataFrame, 
                                  period: int = 20, 
                                  atr_multiplier: float = 2.0) -> Dict[str, pd.Series]:
        """
        Keltner Channels hesapla
        
        Args:
            ohlcv_data: OHLCV veri çerçevesi
            period: Periyot (varsayılan: 20)
            atr_multiplier: ATR çarpanı (varsayılan: 2.0)
            
        Returns:
            Üst, alt ve orta kanalları içeren dict
        """
        ema = self.calculate_ema(ohlcv_data['close'], period)
        atr = self.calculate_atr(ohlcv_data, period)
        
        upper_channel = ema + (atr_multiplier * atr)
        lower_channel = ema - (atr_multiplier * atr)
        
        return {
            'upper': upper_channel,
            'middle': ema,
            'lower': lower_channel,
            'width': upper_channel - lower_channel,
            'position': (ohlcv_data['close'] - lower_channel) / (upper_channel - lower_channel)
        }
    
    def calculate_ichimoku(self, ohlcv_data: pd.DataFrame, 
                          tenkan: int = 9, 
                          kijun: int = 26, 
                          senkou_b: int = 52) -> Dict[str, pd.Series]:
        """
        Ichimoku Cloud hesapla
        
        Args:
            ohlcv_data: OHLCV veri çerçevesi
            tenkan: Tenkan-sen periyodu (varsayılan: 9)
            kijun: Kijun-sen periyodu (varsayılan: 26)
            senkou_b: Senkou Span B periyodu (varsayılan: 52)
            
        Returns:
            Ichimoku bileşenlerini içeren dict
        """
        high = ohlcv_data['high']
        low = ohlcv_data['low']
        
        # Tenkan-sen (Conversion Line)
        tenkan_sen = (high.rolling(window=tenkan).max() + low.rolling(window=tenkan).min()) / 2
        
        # Kijun-sen (Base Line)
        kijun_sen = (high.rolling(window=kijun).max() + low.rolling(window=kijun).min()) / 2
        
        # Senkou Span A (Leading Span A)
        senkou_span_a = ((tenkan_sen + kijun_sen) / 2).shift(kijun)
        
        # Senkou Span B (Leading Span B)
        senkou_span_b = ((high.rolling(window=senkou_b).max() + 
                         low.rolling(window=senkou_b).min()) / 2).shift(kijun)
        
        # Chikou Span (Lagging Span)
        chikou_span = ohlcv_data['close'].shift(-kijun)
        
        return {
            'tenkan_sen': tenkan_sen,
            'kijun_sen': kijun_sen,
            'senkou_span_a': senkou_span_a,
            'senkou_span_b': senkou_span_b,
            'chikou_span': chikou_span,
            'cloud_top': pd.concat([senkou_span_a, senkou_span_b], axis=1).max(axis=1),
            'cloud_bottom': pd.concat([senkou_span_a, senkou_span_b], axis=1).min(axis=1)
        }
    
    def calculate_vwap(self, ohlcv_data: pd.DataFrame) -> pd.Series:
        """
        Volume Weighted Average Price (VWAP) hesapla
        
        Args:
            ohlcv_data: OHLCV veri çerçevesi
            
        Returns:
            VWAP değerleri
        """
        typical_price = (ohlcv_data['high'] + ohlcv_data['low'] + ohlcv_data['close']) / 3
        vwap = (typical_price * ohlcv_data['volume']).cumsum() / ohlcv_data['volume'].cumsum()
        
        return vwap
    
    def calculate_obv(self, ohlcv_data: pd.DataFrame) -> pd.Series:
        """
        On-Balance Volume (OBV) hesapla
        
        Args:
            ohlcv_data: OHLCV veri çerçevesi
            
        Returns:
            OBV değerleri
        """
        obv = pd.Series(0.0, index=ohlcv_data.index)
        
        for i in range(1, len(ohlcv_data)):
            if ohlcv_data['close'].iloc[i] > ohlcv_data['close'].iloc[i-1]:
                obv.iloc[i] = obv.iloc[i-1] + ohlcv_data['volume'].iloc[i]
            elif ohlcv_data['close'].iloc[i] < ohlcv_data['close'].iloc[i-1]:
                obv.iloc[i] = obv.iloc[i-1] - ohlcv_data['volume'].iloc[i]
            else:
                obv.iloc[i] = obv.iloc[i-1]
        
        return obv


# Test ve örnek kullanım
if __name__ == "__main__":
    import matplotlib.pyplot as plt
    import numpy as np
    from datetime import datetime, timedelta
    
    # Test verisi oluştur
    np.random.seed(42)
    dates = pd.date_range(start='2024-01-01', end='2024-12-31', freq='D')
    prices = 100 * (1 + np.random.normal(0, 0.02, len(dates))).cumprod()
    
    ohlcv_data = pd.DataFrame({
        'open': prices * (1 + np.random.normal(0, 0.005, len(dates))),
        'high': prices * (1 + np.abs(np.random.normal(0, 0.01, len(dates)))),
        'low': prices * (1 - np.abs(np.random.normal(0, 0.01, len(dates)))),
        'close': prices,
        'volume': np.random.uniform(1000, 10000, len(dates)) * 1000
    }, index=dates)
    
    # İndikatörleri test et
    indicator_calc = TechnicalIndicators()
    
    print("Teknik İndikatörler Test Sonuçları:")
    print("=" * 40)
    
    # RSI test
    rsi = indicator_calc.calculate_rsi(ohlcv_data['close'], 14)
    print(f"RSI (14) - Son değer: {rsi.iloc[-1]:.2f}")
    print(f"RSI (14) - Ortalama: {rsi.mean():.2f}")
    
    # MACD test
    macd_data = indicator_calc.calculate_macd(ohlcv_data['close'])
    print(f"MACD - Son değer: {macd_data['macd'].iloc[-1]:.4f}")
    print(f"Signal - Son değer: {macd_data['signal'].iloc[-1]:.4f}")
    
    # Bollinger Bands test
    bb_data = indicator_calc.calculate_bollinger_bands(ohlcv_data['close'])
    print(f"Bollinger Upper: {bb_data['upper'].iloc[-1]:.2f}")
    print(f"Bollinger Lower: {bb_data['lower'].iloc[-1]:.2f}")
    print(f"Fiyat Pozisyonu: {bb_data['position'].iloc[-1]:.2%}")
    
    # Stochastic test
    stoch_data = indicator_calc.calculate_stochastic(ohlcv_data)
    print(f"Stochastic %K: {stoch_data['k'].iloc[-1]:.2f}")
    print(f"Stochastic %D: {stoch_data['d'].iloc[-1]:.2f}")
    
    # ATR test
    atr = indicator_calc.calculate_atr(ohlcv_data)
    print(f"ATR (14): {atr.iloc[-1]:.4f}")
    
    print("\nTüm indikatörler başarıyla hesaplandı!")