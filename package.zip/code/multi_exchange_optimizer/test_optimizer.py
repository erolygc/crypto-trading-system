"""
Multi-Exchange Optimizer Test Suite
Sistem testleri ve örnek kullanım senaryoları
"""

import asyncio
import sys
import os
import logging
from datetime import datetime, timedelta
import numpy as np

# Add the code directory to path
sys.path.append('/workspace/code/multi_exchange_optimizer')

# Import all components
from config import ExchangeConfig, VenueConfig, OptimizationConfig, VenueType
from multi_exchange_optimizer import MultiExchangeOptimizer, OptimizationRequest
from price_aggregator import PriceAggregator, PriceData
from liquidity_router import LiquidityRouter
from cost_optimizer import CostOptimizer
from venue_constraints import VenueConstraintManager
from rate_limiter import AdvancedRateLimiter
from latency_manager import LatencyManager
from vwap_calculator import VWAPCalculator, TradeData
from twap_optimizer import TWAPOptimizer
from cross_venue_analyzer import CrossVenueAnalyzer
from slippage_predictor import SlippagePredictor
from utils import MathUtils, TimeUtils, DataUtils

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class OptimizerTester:
    """Test suite for Multi-Exchange Optimizer"""
    
    def __init__(self):
        self.config = self._create_test_config()
        self.results = {}
        
    def _create_test_config(self) -> ExchangeConfig:
        """Test için konfigürasyon oluştur"""
        config = ExchangeConfig()
        
        # Test venues
        config.VENUES = {
            'binance_test': VenueConfig(
                name='Binance Test',
                type=VenueType.CEX,
                base_url='https://api.binance.com',
                rate_limit=1200,
                latency_threshold=30.0,
                min_trade_size=10.0,
                fee_maker=0.001,
                fee_taker=0.001,
                priority=1
            ),
            'coinbase_test': VenueConfig(
                name='Coinbase Test',
                type=VenueType.CEX,
                base_url='https://api.exchange.coinbase.com',
                rate_limit=300,
                latency_threshold=40.0,
                min_trade_size=1.0,
                fee_maker=0.005,
                fee_taker=0.005,
                priority=2
            ),
            'uniswap_test': VenueConfig(
                name='Uniswap Test',
                type=VenueType.DEX,
                base_url='https://api.thegraph.com',
                rate_limit=100,
                latency_threshold=200.0,
                min_trade_size=0.01,
                fee_maker=0.0005,
                fee_taker=0.0005,
                priority=3
            )
        }
        
        return config
    
    async def test_basic_optimization(self):
        """Temel optimizasyon testi"""
        logger.info("Testing basic optimization...")
        
        try:
            # Test request oluştur
            request = OptimizationRequest(
                symbol='BTC-USD',
                quantity=1.0,
                side='buy',
                urgency='normal',
                execution_style='immediate'
            )
            
            # Test data ekle
            await self._add_test_market_data()
            
            # Optimizer oluştur (mock version)
            optimizer = self._create_mock_optimizer()
            
            # Simulated optimization
            result = await self._simulate_optimization(request)
            
            self.results['basic_optimization'] = {
                'success': True,
                'execution_time': result.get('execution_time', 0),
                'best_venue': result.get('best_venue'),
                'estimated_cost': result.get('estimated_cost'),
                'slippage': result.get('slippage')
            }
            
            logger.info("Basic optimization test completed successfully")
            
        except Exception as e:
            logger.error(f"Basic optimization test failed: {e}")
            self.results['basic_optimization'] = {'success': False, 'error': str(e)}
    
    async def test_price_aggregation(self):
        """Price aggregation testi"""
        logger.info("Testing price aggregation...")
        
        try:
            # Price aggregator oluştur
            price_aggregator = PriceAggregator(self.config)
            
            # Test price data ekle
            await self._add_test_price_data(price_aggregator)
            
            # Aggregate prices test et
            aggregated = price_aggregator.aggregate_prices('BTC-USD')
            
            if aggregated:
                self.results['price_aggregation'] = {
                    'success': True,
                    'venue_count': aggregated.venue_count,
                    'mid_price': aggregated.mid_price,
                    'price_spread': aggregated.price_spread,
                    'liquidity_score': aggregated.liquidity_score
                }
            else:
                self.results['price_aggregation'] = {'success': False, 'error': 'No aggregated data'}
            
            logger.info("Price aggregation test completed")
            
        except Exception as e:
            logger.error(f"Price aggregation test failed: {e}")
            self.results['price_aggregation'] = {'success': False, 'error': str(e)}
    
    async def test_liquidity_routing(self):
        """Liquidity routing testi"""
        logger.info("Testing liquidity routing...")
        
        try:
            # Mock price aggregator
            price_aggregator = self._create_mock_price_aggregator()
            
            # Liquidity router oluştur
            router = LiquidityRouter(self.config, price_aggregator)
            
            # Test routing
            routing_result = router.optimize_route('BTC-USD', 1.0, 'buy')
            
            self.results['liquidity_routing'] = {
                'success': True,
                'routes_count': len(routing_result.routes),
                'total_cost': routing_result.total_cost,
                'liquidity_score': routing_result.liquidity_score,
                'estimated_slippage': routing_result.estimated_slippage
            }
            
            logger.info("Liquidity routing test completed")
            
        except Exception as e:
            logger.error(f"Liquidity routing test failed: {e}")
            self.results['liquidity_routing'] = {'success': False, 'error': str(e)}
    
    async def test_cost_optimization(self):
        """Cost optimization testi"""
        logger.info("Testing cost optimization...")
        
        try:
            # Mock price aggregator
            price_aggregator = self._create_mock_price_aggregator()
            
            # Cost optimizer oluştur
            optimizer = CostOptimizer(self.config, price_aggregator)
            
            # Test optimization
            result = optimizer.optimize_execution_cost('BTC-USD', 1.0, 'buy')
            
            self.results['cost_optimization'] = {
                'success': True,
                'total_cost': result.total_cost.total_cost,
                'explicit_fees': result.total_cost.explicit_fees,
                'implicit_costs': result.total_cost.implicit_costs,
                'convergence': result.convergence,
                'iterations': result.iterations
            }
            
            logger.info("Cost optimization test completed")
            
        except Exception as e:
            logger.error(f"Cost optimization test failed: {e}")
            self.results['cost_optimization'] = {'success': False, 'error': str(e)}
    
    async def test_venue_constraints(self):
        """Venue constraints testi"""
        logger.info("Testing venue constraints...")
        
        try:
            # Constraint manager oluştur
            manager = VenueConstraintManager(self.config)
            
            # Test constraint checking
            is_valid, violations = manager.check_constraints('binance_test', 1000.0)
            
            # Get constraint status
            status = manager.get_constraint_status('binance_test')
            
            self.results['venue_constraints'] = {
                'success': True,
                'valid': is_valid,
                'violations_count': len(violations),
                'constraints_count': len(status.get('constraints', {})),
                'circuit_breaker': status.get('circuit_breaker', False)
            }
            
            logger.info("Venue constraints test completed")
            
        except Exception as e:
            logger.error(f"Venue constraints test failed: {e}")
            self.results['venue_constraints'] = {'success': False, 'error': str(e)}
    
    async def test_rate_limiting(self):
        """Rate limiting testi"""
        logger.info("Testing rate limiting...")
        
        try:
            # Rate limiter oluştur
            limiter = AdvancedRateLimiter(self.config)
            
            # Test rate limiting
            success = await limiter.acquire('binance_test', '/api/v3/ticker/price', 1)
            
            # Get status
            status = limiter.get_rate_limit_status('binance_test', '/api/v3/ticker/price')
            
            self.results['rate_limiting'] = {
                'success': True,
                'acquire_success': success,
                'can_proceed': status.can_proceed if status else False,
                'usage_percentage': status.usage_percentage if status else 0,
                'estimated_wait': status.estimated_wait_time if status else 0
            }
            
            logger.info("Rate limiting test completed")
            
        except Exception as e:
            logger.error(f"Rate limiting test failed: {e}")
            self.results['rate_limiting'] = {'success': False, 'error': str(e)}
    
    async def test_vwap_calculation(self):
        """VWAP calculation testi"""
        logger.info("Testing VWAP calculation...")
        
        try:
            # VWAP calculator oluştur
            calculator = VWAPCalculator(self.config)
            
            # Test trade data ekle
            await self._add_test_trade_data(calculator)
            
            # VWAP hesapla
            vwap_result = calculator.calculate_vwap('BTC-USD', 60)
            
            if vwap_result:
                self.results['vwap_calculation'] = {
                    'success': True,
                    'vwap_price': vwap_result.vwap,
                    'total_volume': vwap_result.total_volume,
                    'venue_count': len(vwap_result.venue_breakdown),
                    'price_range': vwap_result.price_range
                }
            else:
                self.results['vwap_calculation'] = {'success': False, 'error': 'No VWAP data'}
            
            logger.info("VWAP calculation test completed")
            
        except Exception as e:
            logger.error(f"VWAP calculation test failed: {e}")
            self.results['vwap_calculation'] = {'success': False, 'error': str(e)}
    
    async def test_twap_optimization(self):
        """TWAP optimization testi"""
        logger.info("Testing TWAP optimization...")
        
        try:
            # Mock price aggregator
            price_aggregator = self._create_mock_price_aggregator()
            
            # TWAP optimizer oluştur
            optimizer = TWAPOptimizer(self.config, price_aggregator)
            
            # Test plan oluştur
            twap_plan = optimizer.create_twap_plan('BTC-USD', 10.0, 1.0, 'adaptive')
            
            self.results['twap_optimization'] = {
                'success': True,
                'slice_count': twap_plan.slice_count,
                'total_quantity': twap_plan.total_quantity,
                'time_horizon_minutes': twap_plan.time_horizon.total_seconds() / 60,
                'execution_strategy': twap_plan.execution_strategy
            }
            
            logger.info("TWAP optimization test completed")
            
        except Exception as e:
            logger.error(f"TWAP optimization test failed: {e}")
            self.results['twap_optimization'] = {'success': False, 'error': str(e)}
    
    async def test_slippage_prediction(self):
        """Slippage prediction testi"""
        logger.info("Testing slippage prediction...")
        
        try:
            # Mock price aggregator
            price_aggregator = self._create_mock_price_aggregator()
            
            # Slippage predictor oluştur
            predictor = SlippagePredictor(self.config, price_aggregator)
            
            # Test trade data ekle
            await self._add_test_slippage_data(predictor)
            
            # Slippage tahmin et
            prediction = predictor.predict_slippage('BTC-USD', 1.0, 'binance_test')
            
            if prediction:
                self.results['slippage_prediction'] = {
                    'success': True,
                    'predicted_slippage': prediction.predicted_slippage,
                    'confidence_interval': prediction.confidence_interval,
                    'model_count': len(prediction.prediction_sources)
                }
            else:
                self.results['slippage_prediction'] = {'success': False, 'error': 'No prediction'}
            
            logger.info("Slippage prediction test completed")
            
        except Exception as e:
            logger.error(f"Slippage prediction test failed: {e}")
            self.results['slippage_prediction'] = {'success': False, 'error': str(e)}
    
    async def test_cross_venue_analysis(self):
        """Cross-venue analysis testi"""
        logger.info("Testing cross-venue analysis...")
        
        try:
            # Mock price aggregator
            price_aggregator = self._create_mock_price_aggregator()
            
            # Cross-venue analyzer oluştur
            analyzer = CrossVenueAnalyzer(self.config, price_aggregator)
            
            # Test cost analysis
            comparison = analyzer.analyze_transaction_costs('BTC-USD', 1000.0, 'buy')
            
            self.results['cross_venue_analysis'] = {
                'success': True,
                'venue_count': len(comparison.comparisons),
                'best_venue': comparison.best_venue,
                'cost_spread': comparison.cost_spread,
                'execution_time_spread': comparison.execution_time_spread
            }
            
            logger.info("Cross-venue analysis test completed")
            
        except Exception as e:
            logger.error(f"Cross-venue analysis test failed: {e}")
            self.results['cross_venue_analysis'] = {'success': False, 'error': str(e)}
    
    async def test_performance_benchmark(self):
        """Performance benchmark testi"""
        logger.info("Running performance benchmark...")
        
        try:
            # Mock optimizer
            optimizer = self._create_mock_optimizer()
            
            # Benchmark parameters
            test_cases = [
                {'symbol': 'BTC-USD', 'quantity': 0.1},
                {'symbol': 'BTC-USD', 'quantity': 1.0},
                {'symbol': 'BTC-USD', 'quantity': 10.0},
                {'symbol': 'ETH-USD', 'quantity': 1.0},
                {'symbol': 'ETH-USD', 'quantity': 10.0}
            ]
            
            results = []
            
            for test_case in test_cases:
                start_time = datetime.now()
                
                # Simulate optimization
                result = await self._simulate_optimization(OptimizationRequest(
                    symbol=test_case['symbol'],
                    quantity=test_case['quantity'],
                    side='buy'
                ))
                
                end_time = datetime.now()
                execution_time = (end_time - start_time).total_seconds()
                
                results.append({
                    'symbol': test_case['symbol'],
                    'quantity': test_case['quantity'],
                    'execution_time': execution_time,
                    'success': result.get('success', True)
                })
            
            # Calculate statistics
            execution_times = [r['execution_time'] for r in results]
            success_rate = sum(1 for r in results if r['success']) / len(results)
            
            self.results['performance_benchmark'] = {
                'success': True,
                'test_cases': len(test_cases),
                'success_rate': success_rate,
                'avg_execution_time': np.mean(execution_times),
                'min_execution_time': min(execution_times),
                'max_execution_time': max(execution_times),
                'std_execution_time': np.std(execution_times)
            }
            
            logger.info("Performance benchmark completed")
            
        except Exception as e:
            logger.error(f"Performance benchmark failed: {e}")
            self.results['performance_benchmark'] = {'success': False, 'error': str(e)}
    
    async def _add_test_market_data(self):
        """Test market data ekle (simulated)"""
        # Bu gerçek implementasyonda exchange API'lerini çağırır
        pass
    
    async def _add_test_price_data(self, price_aggregator):
        """Test price data ekle"""
        # Simulated price data
        test_prices = [
            PriceData('binance_test', 'BTC-USD', 50000, 49990, 50010, 1000000, datetime.now(), 25.0),
            PriceData('coinbase_test', 'BTC-USD', 50050, 50040, 50060, 500000, datetime.now(), 35.0),
            PriceData('uniswap_test', 'BTC-USD', 50100, 50090, 50110, 100000, datetime.now(), 180.0)
        ]
        
        for price_data in test_prices:
            if price_data.venue not in price_aggregator.price_cache:
                price_aggregator.price_cache[price_data.venue] = {}
            price_aggregator.price_cache[price_data.venue][price_data.symbol] = price_data
    
    async def _add_test_trade_data(self, calculator):
        """Test trade data ekle"""
        test_trades = [
            TradeData('binance_test', datetime.now() - timedelta(minutes=30), 49990, 0.1, 'buy', 'trade1'),
            TradeData('coinbase_test', datetime.now() - timedelta(minutes=25), 50010, 0.2, 'buy', 'trade2'),
            TradeData('binance_test', datetime.now() - timedelta(minutes=20), 50000, 0.15, 'sell', 'trade3'),
            TradeData('uniswap_test', datetime.now() - timedelta(minutes=15), 50020, 0.05, 'buy', 'trade4'),
            TradeData('coinbase_test', datetime.now() - timedelta(minutes=10), 50030, 0.25, 'sell', 'trade5')
        ]
        
        for trade in test_trades:
            calculator.add_trade_data(trade)
    
    async def _add_test_slippage_data(self, predictor):
        """Test slippage data ekle"""
        import random
        
        for i in range(50):
            trade_record = {
                'symbol': 'BTC-USD',
                'venue': 'binance_test',
                'trade_size_usd': random.uniform(1000, 50000),
                'trade_price': random.uniform(49000, 51000),
                'market_price': random.uniform(49000, 51000),
                'slippage': random.uniform(-0.001, 0.005),
                'timestamp': datetime.now() - timedelta(hours=random.randint(1, 24)),
                'market_volume': random.uniform(100000, 1000000)
            }
            
            predictor.add_trade_data(
                symbol='BTC-USD',
                venue='binance_test',
                trade_size=trade_record['trade_size_usd'] / trade_record['market_price'],
                trade_price=trade_record['trade_price'],
                market_price=trade_record['market_price'],
                timestamp=trade_record['timestamp'],
                market_volume=trade_record['market_volume']
            )
    
    def _create_mock_price_aggregator(self):
        """Mock price aggregator oluştur"""
        class MockPriceAggregator:
            def __init__(self):
                self.price_cache = {
                    'binance_test': {
                        'BTC-USD': PriceData('binance_test', 'BTC-USD', 50000, 49990, 50010, 1000000, datetime.now(), 25.0),
                        'ETH-USD': PriceData('binance_test', 'ETH-USD', 3000, 2990, 3010, 500000, datetime.now(), 30.0)
                    },
                    'coinbase_test': {
                        'BTC-USD': PriceData('coinbase_test', 'BTC-USD', 50050, 50040, 50060, 500000, datetime.now(), 35.0),
                        'ETH-USD': PriceData('coinbase_test', 'ETH-USD', 3010, 3000, 3020, 300000, datetime.now(), 40.0)
                    },
                    'uniswap_test': {
                        'BTC-USD': PriceData('uniswap_test', 'BTC-USD', 50100, 50090, 50110, 100000, datetime.now(), 180.0),
                        'ETH-USD': PriceData('uniswap_test', 'ETH-USD', 3020, 3010, 3030, 50000, datetime.now(), 200.0)
                    }
                }
                self.latency_tracker = MockLatencyTracker()
            
            def aggregate_prices(self, symbol):
                if symbol not in ['BTC-USD', 'ETH-USD']:
                    return None
                
                prices = []
                for venue_data in self.price_cache.values():
                    if symbol in venue_data:
                        prices.append(venue_data[symbol])
                
                if not prices:
                    return None
                
                from price_aggregator import AggregatedPrice
                return AggregatedPrice(
                    symbol=symbol,
                    best_bid=max(p.bid for p in prices),
                    best_ask=min(p.ask for p in prices),
                    mid_price=np.mean([p.price for p in prices]),
                    volume_weighted_price=np.mean([p.price for p in prices]),
                    timestamp=datetime.now(),
                    venue_count=len(prices),
                    price_spread=max(p.ask for p in prices) - min(p.bid for p in prices),
                    liquidity_score=0.8
                )
        
        class MockLatencyTracker:
            def get_avg_latency(self, venue):
                latency_map = {'binance_test': 25, 'coinbase_test': 35, 'uniswap_test': 180}
                return latency_map.get(venue, 50)
        
        return MockPriceAggregator()
    
    def _create_mock_optimizer(self):
        """Mock optimizer oluştur"""
        class MockOptimizer:
            def __init__(self):
                self.performance_metrics = {}
            
            async def optimize_trade(self, request):
                # Simulated optimization result
                return {
                    'success': True,
                    'execution_time': 0.15,
                    'best_venue': 'binance_test',
                    'estimated_cost': 0.0012,
                    'slippage': 0.0008
                }
        
        return MockOptimizer()
    
    async def _simulate_optimization(self, request):
        """Optimizasyon simülasyonu"""
        # Simulated processing time
        await asyncio.sleep(0.1)
        
        # Simulated result based on request parameters
        result = {
            'success': True,
            'execution_time': 0.1 + np.random.uniform(0, 0.1),
            'best_venue': np.random.choice(['binance_test', 'coinbase_test']),
            'estimated_cost': 0.001 + np.random.uniform(0, 0.002),
            'slippage': 0.0005 + np.random.uniform(0, 0.001)
        }
        
        return result
    
    def print_results(self):
        """Test sonuçlarını yazdır"""
        print("\n" + "="*60)
        print("MULTI-EXCHANGE OPTIMIZER TEST RESULTS")
        print("="*60)
        
        total_tests = len(self.results)
        passed_tests = sum(1 for r in self.results.values() if r.get('success', False))
        
        print(f"\nTotal Tests: {total_tests}")
        print(f"Passed: {passed_tests}")
        print(f"Failed: {total_tests - passed_tests}")
        print(f"Success Rate: {passed_tests/total_tests*100:.1f}%")
        
        print("\n" + "-"*60)
        print("TEST DETAILS:")
        print("-"*60)
        
        for test_name, result in self.results.items():
            status = "✓ PASS" if result.get('success', False) else "✗ FAIL"
            print(f"{test_name:25} {status}")
            
            if not result.get('success', False):
                print(f"  Error: {result.get('error', 'Unknown error')}")
            else:
                # Print key metrics
                for key, value in result.items():
                    if key != 'success' and key != 'error':
                        if isinstance(value, float):
                            print(f"  {key}: {value:.4f}")
                        else:
                            print(f"  {key}: {value}")
        
        print("\n" + "="*60)
        
        return passed_tests == total_tests

async def main():
    """Ana test fonksiyonu"""
    print("Starting Multi-Exchange Optimizer Tests...")
    
    tester = OptimizerTester()
    
    # Run all tests
    await tester.test_basic_optimization()
    await tester.test_price_aggregation()
    await tester.test_liquidity_routing()
    await tester.test_cost_optimization()
    await tester.test_venue_constraints()
    await tester.test_rate_limiting()
    await tester.test_vwap_calculation()
    await tester.test_twap_optimization()
    await tester.test_slippage_prediction()
    await tester.test_cross_venue_analysis()
    await tester.test_performance_benchmark()
    
    # Print results
    success = tester.print_results()
    
    if success:
        print("\n🎉 All tests passed successfully!")
    else:
        print("\n⚠️  Some tests failed. Check the logs for details.")
    
    return success

if __name__ == "__main__":
    # Run the tests
    success = asyncio.run(main())
    sys.exit(0 if success else 1)