"""
Slippage Predictor
Market slippage tahmin modelleri ve analizi
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging
from collections import deque, defaultdict
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error
from scipy import stats
from config import ExchangeConfig

@dataclass
class SlippagePrediction:
    """Slippage tahmin sonucu"""
    predicted_slippage: float
    confidence_interval: Tuple[float, float]
    prediction_sources: Dict[str, float]
    market_factors: Dict[str, float]
    model_scores: Dict[str, float]
    timestamp: datetime

@dataclass
class MarketCondition:
    """Market koşulu"""
    volatility: float
    volume_ratio: float
    bid_ask_spread: float
    market_depth: float
    price_momentum: float
    liquidity_score: float
    timestamp: datetime

class SlippagePredictor:
    """Market slippage tahmin sistemi"""
    
    def __init__(self, config: ExchangeConfig, price_aggregator):
        self.config = config
        self.price_aggregator = price_aggregator
        self.logger = logging.getLogger(__name__)
        
        # Slippage data storage
        self.slippage_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=5000))
        self.market_conditions: Dict[str, deque] = defaultdict(lambda: deque(maxlen=1000))
        self.venue_profiles: Dict[str, Dict] = {}
        
        # Machine learning models
        self.models = {
            'random_forest': RandomForestRegressor(n_estimators=100, random_state=42),
            'gradient_boosting': GradientBoostingRegressor(n_estimators=100, random_state=42)
        }
        self.model_scalers = {}
        self.model_performance = {}
        
        # Feature engineering
        self.feature_columns = [
            'trade_size_usd', 'volume_ratio', 'volatility_5m', 'volatility_1h',
            'bid_ask_spread_bps', 'market_depth_score', 'price_momentum',
            'liquidity_score', 'hour_of_day', 'day_of_week', 'venue_latency',
            'venue_reliability', 'market_stress'
        ]
        
        # Prediction parameters
        self.confidence_levels = [0.68, 0.95, 0.99]  # 1σ, 2σ, 3σ
        self.prediction_horizon = 300  # 5 minutes
        
        # Initialize models
        self._initialize_models()
        
    def _initialize_models(self):
        """ML modellerini başlat"""
        for model_name in self.models.keys():
            self.model_scalers[model_name] = StandardScaler()
            self.model_performance[model_name] = {
                'mae': 0.0,
                'rmse': 0.0,
                'r2': 0.0,
                'last_trained': None
            }
    
    def add_trade_data(self, symbol: str, venue: str, trade_size: float,
                     trade_price: float, market_price: float, timestamp: datetime,
                     market_volume: float = 0, volatility: float = 0):
        """Trade verisi ekle"""
        
        # Calculate slippage
        if market_price > 0:
            slippage = abs(trade_price - market_price) / market_price
        else:
            slippage = 0
        
        # Create trade record
        trade_record = {
            'symbol': symbol,
            'venue': venue,
            'trade_size_usd': trade_size * trade_price,
            'trade_size_base': trade_size,
            'trade_price': trade_price,
            'market_price': market_price,
            'slippage': slippage,
            'timestamp': timestamp,
            'market_volume': market_volume,
            'volatility': volatility
        }
        
        # Store in history
        self.slippage_history[symbol].append(trade_record)
        
        # Update market conditions
        self._update_market_conditions(symbol, trade_record)
        
        # Retrain models periodically
        if len(self.slippage_history[symbol]) % 100 == 0:
            self._retrain_models(symbol)
    
    def _update_market_conditions(self, symbol: str, trade_record: Dict):
        """Market koşullarını güncelle"""
        
        # Calculate market metrics
        conditions = self._calculate_market_conditions(symbol, trade_record)
        
        # Store conditions
        self.market_conditions[symbol].append(conditions)
    
    def _calculate_market_conditions(self, symbol: str, trade_record: Dict) -> MarketCondition:
        """Market koşullarını hesapla"""
        
        # Get recent data for calculations
        recent_trades = list(self.slippage_history[symbol])[-20:]  # Last 20 trades
        recent_conditions = list(self.market_conditions[symbol])[-10:]  # Last 10 conditions
        
        # Calculate volatility
        if len(recent_trades) >= 5:
            prices = [t['trade_price'] for t in recent_trades[-5:]]
            returns = np.diff(np.log(prices))
            volatility = np.std(returns) * np.sqrt(252 * 24 * 60 / 5)  # Annualized
        else:
            volatility = trade_record.get('volatility', 0.02)
        
        # Volume ratio
        trade_volume = trade_record['trade_size_usd']
        market_volume = trade_record.get('market_volume', 1)
        volume_ratio = trade_volume / max(market_volume, 1)
        
        # Bid-ask spread (simulated)
        spread_bps = np.random.uniform(1, 10)  # 1-10 bps
        
        # Market depth score (based on recent volume)
        if recent_trades:
            avg_volume = np.mean([t['market_volume'] for t in recent_trades if t.get('market_volume', 0) > 0])
            market_depth_score = min(1.0, market_volume / max(avg_volume, 1))
        else:
            market_depth_score = 0.5
        
        # Price momentum
        if len(prices) >= 3:
            momentum = (prices[-1] - prices[0]) / prices[0]
        else:
            momentum = 0
        
        # Liquidity score
        liquidity_score = self._calculate_liquidity_score(symbol, trade_volume)
        
        return MarketCondition(
            volatility=volatility,
            volume_ratio=volume_ratio,
            bid_ask_spread=spread_bps,
            market_depth=market_depth_score,
            price_momentum=momentum,
            liquidity_score=liquidity_score,
            timestamp=trade_record['timestamp']
        )
    
    def _calculate_liquidity_score(self, symbol: str, trade_size: float) -> float:
        """Likidite skoru hesapla"""
        
        # Get venue data
        venue_data = self._get_venue_liquidity_data(symbol)
        
        if not venue_data:
            return 0.5
        
        # Calculate liquidity score based on trade size vs market depth
        total_liquidity = sum(data.get('liquidity', 0) for data in venue_data.values())
        
        if total_liquidity > 0:
            liquidity_ratio = min(1.0, trade_size / total_liquidity)
            liquidity_score = max(0.1, 1 - liquidity_ratio)
        else:
            liquidity_score = 0.1
        
        return liquidity_score
    
    def _get_venue_liquidity_data(self, symbol: str) -> Dict:
        """Venue likidite verisi"""
        
        venue_data = {}
        
        # Get data from price aggregator
        if hasattr(self.price_aggregator, 'price_cache'):
            for venue_name, venue_trades in self.price_aggregator.price_cache.items():
                if symbol in venue_trades:
                    price_data = venue_trades[symbol]
                    venue_data[venue_name] = {
                        'volume': price_data.volume_24h,
                        'liquidity': price_data.volume_24h * 0.1,  # 10% as available liquidity
                        'spread': (price_data.ask - price_data.bid) / price_data.price
                    }
        
        return venue_data
    
    def predict_slippage(self, symbol: str, trade_size: float, venue: str,
                        market_data: Optional[Dict] = None) -> SlippagePrediction:
        """Slippage tahmini"""
        
        # Prepare features
        features = self._prepare_prediction_features(symbol, trade_size, venue, market_data)
        
        if not features:
            # Fallback to simple model
            return self._simple_slippage_prediction(symbol, trade_size, venue)
        
        # Get predictions from all models
        predictions = {}
        prediction_sources = {}
        
        for model_name, model in self.models.items():
            try:
                if model_name in self.model_scalers:
                    # Scale features
                    scaled_features = self.model_scalers[model_name].transform([features])
                    
                    # Make prediction
                    prediction = model.predict(scaled_features)[0]
                    predictions[model_name] = max(0, prediction)  # Ensure non-negative
                    
                    # Get model score
                    model_score = self.model_performance.get(model_name, {}).get('r2', 0)
                    prediction_sources[model_name] = model_score
                    
            except Exception as e:
                self.logger.warning(f"Model {model_name} prediction failed: {e}")
                continue
        
        if not predictions:
            return self._simple_slippage_prediction(symbol, trade_size, venue)
        
        # Combine predictions (weighted average based on model performance)
        weights = np.array(list(prediction_sources.values()))
        if np.sum(weights) > 0:
            weights = weights / np.sum(weights)
            combined_prediction = np.average(list(predictions.values()), weights=weights)
        else:
            combined_prediction = np.mean(list(predictions.values()))
        
        # Calculate confidence interval
        std_dev = np.std(list(predictions.values()))
        confidence_interval = self._calculate_confidence_interval(combined_prediction, std_dev)
        
        # Add market factors
        market_factors = self._analyze_market_factors(symbol, features)
        
        return SlippagePrediction(
            predicted_slippage=combined_prediction,
            confidence_interval=confidence_interval,
            prediction_sources=prediction_sources,
            market_factors=market_factors,
            model_scores=self.model_performance,
            timestamp=datetime.now()
        )
    
    def _prepare_prediction_features(self, symbol: str, trade_size: float, 
                                   venue: str, market_data: Optional[Dict]) -> List[float]:
        """Tahmin için features hazırla"""
        
        features = []
        
        try:
            # Basic trade features
            features.append(trade_size)  # trade_size_usd
            
            # Market data features
            if market_data:
                features.append(market_data.get('volume_ratio', 0))
                features.append(market_data.get('volatility_5m', 0.02))
                features.append(market_data.get('volatility_1h', 0.02))
                features.append(market_data.get('bid_ask_spread_bps', 5))
                features.append(market_data.get('market_depth_score', 0.5))
                features.append(market_data.get('price_momentum', 0))
                features.append(market_data.get('liquidity_score', 0.5))
            else:
                # Default values if no market data
                features.extend([0.01, 0.02, 0.02, 5, 0.5, 0, 0.5])
            
            # Time features
            now = datetime.now()
            features.append(now.hour)  # hour_of_day
            features.append(now.weekday())  # day_of_week
            
            # Venue features
            venue_latency = self._get_venue_latency(venue)
            venue_reliability = self._get_venue_reliability(venue)
            features.append(venue_latency)
            features.append(venue_reliability)
            
            # Market stress indicator
            market_stress = self._calculate_market_stress(symbol)
            features.append(market_stress)
            
        except Exception as e:
            self.logger.error(f"Feature preparation failed: {e}")
            return []
        
        return features
    
    def _get_venue_latency(self, venue: str) -> float:
        """Venue latency al"""
        if hasattr(self.price_aggregator, 'latency_tracker'):
            return self.price_aggregator.latency_tracker.get_avg_latency(venue) / 1000  # Convert to seconds
        return 0.05  # Default 50ms
    
    def _get_venue_reliability(self, venue: str) -> float:
        """Venue reliability al"""
        # Get from venue configuration
        venue_config = self.config.VENUES.get(venue)
        if venue_config:
            return (6 - venue_config.priority) / 5  # Higher priority = higher reliability
        return 0.8  # Default reliability
    
    def _calculate_market_stress(self, symbol: str) -> float:
        """Market stress hesapla"""
        
        recent_trades = list(self.slippage_history[symbol])[-50:]  # Last 50 trades
        
        if len(recent_trades) < 5:
            return 0.0
        
        # Calculate stress based on recent volatility and volume changes
        recent_slippage = [t['slippage'] for t in recent_trades[-10:]]
        recent_volumes = [t.get('market_volume', 0) for t in recent_trades[-10:] if t.get('market_volume', 0) > 0]
        
        # Stress components
        slippage_stress = np.std(recent_slippage) if recent_slippage else 0
        
        volume_stress = 0
        if len(recent_volumes) >= 2:
            volume_changes = np.diff(recent_volumes)
            volume_stress = np.std(volume_changes) / np.mean(recent_volumes) if np.mean(recent_volumes) > 0 else 0
        
        # Combined stress
        total_stress = min(1.0, slippage_stress * 10 + volume_stress)
        
        return total_stress
    
    def _simple_slippage_prediction(self, symbol: str, trade_size: float, venue: str) -> SlippagePrediction:
        """Basit slippage tahmini (fallback)"""
        
        # Simple model based on trade size and venue
        venue_config = self.config.VENUES.get(venue)
        if venue_config:
            base_slippage = venue_config.fee_taker
        else:
            base_slippage = 0.001
        
        # Adjust based on trade size (larger trades = more slippage)
        size_factor = min(3.0, 1 + (trade_size / 10000))  # Scale with size
        
        # Get recent market volatility
        recent_trades = list(self.slippage_history[symbol])[-20:]
        if recent_trades:
            recent_slippage = np.mean([t['slippage'] for t in recent_trades])
            predicted_slippage = (base_slippage + recent_slippage) / 2 * size_factor
        else:
            predicted_slippage = base_slippage * size_factor
        
        # Simple confidence interval (±50%)
        margin = predicted_slippage * 0.5
        confidence_interval = (max(0, predicted_slippage - margin), predicted_slippage + margin)
        
        return SlippagePrediction(
            predicted_slippage=predicted_slippage,
            confidence_interval=confidence_interval,
            prediction_sources={'simple_model': 1.0},
            market_factors={'size_factor': size_factor, 'base_slippage': base_slippage},
            model_scores={'simple_model': {'mae': 0.001, 'rmse': 0.001, 'r2': 0.5}},
            timestamp=datetime.now()
        )
    
    def _calculate_confidence_interval(self, prediction: float, std_dev: float) -> Tuple[float, float]:
        """Güven aralığı hesapla"""
        
        # Use 95% confidence interval
        margin = 1.96 * std_dev  # 95% confidence
        
        lower_bound = max(0, prediction - margin)
        upper_bound = prediction + margin
        
        return (lower_bound, upper_bound)
    
    def _analyze_market_factors(self, symbol: str, features: List[float]) -> Dict[str, float]:
        """Market faktörleri analizi"""
        
        factors = {}
        
        try:
            if len(features) >= len(self.feature_columns):
                factor_dict = dict(zip(self.feature_columns, features))
                
                # Key factors analysis
                factors['volatility_impact'] = min(1.0, factor_dict.get('volatility_1h', 0) * 10)
                factors['size_impact'] = min(1.0, factor_dict.get('trade_size_usd', 0) / 100000)
                factors['liquidity_impact'] = 1 - factor_dict.get('liquidity_score', 0.5)
                factors['spread_impact'] = min(1.0, factor_dict.get('bid_ask_spread_bps', 5) / 20)
                factors['stress_impact'] = factor_dict.get('market_stress', 0)
                
        except Exception as e:
            self.logger.warning(f"Market factor analysis failed: {e}")
            factors = {'volatility_impact': 0.5, 'size_impact': 0.5, 'liquidity_impact': 0.5}
        
        return factors
    
    def _retrain_models(self, symbol: str):
        """Modelleri yeniden eğit"""
        
        # Get training data
        training_data = self._prepare_training_data(symbol)
        
        if len(training_data) < 50:  # Minimum samples needed
            return
        
        try:
            X = training_data.drop('slippage', axis=1)
            y = training_data['slippage']
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            # Train each model
            for model_name, model in self.models.items():
                try:
                    # Scale features
                    scaler = self.model_scalers[model_name]
                    X_train_scaled = scaler.fit_transform(X_train)
                    X_test_scaled = scaler.transform(X_test)
                    
                    # Train model
                    model.fit(X_train_scaled, y_train)
                    
                    # Evaluate
                    y_pred = model.predict(X_test_scaled)
                    mae = mean_absolute_error(y_test, y_pred)
                    rmse = np.sqrt(mean_squared_error(y_test, y_pred))
                    r2 = model.score(X_test_scaled, y_test)
                    
                    # Store performance
                    self.model_performance[model_name] = {
                        'mae': mae,
                        'rmse': rmse,
                        'r2': r2,
                        'last_trained': datetime.now()
                    }
                    
                    self.logger.info(f"Model {model_name} retrained for {symbol}: MAE={mae:.6f}, R2={r2:.3f}")
                    
                except Exception as e:
                    self.logger.warning(f"Model {model_name} training failed: {e}")
                    
        except Exception as e:
            self.logger.error(f"Model retraining failed for {symbol}: {e}")
    
    def _prepare_training_data(self, symbol: str) -> pd.DataFrame:
        """Training data hazırla"""
        
        trades = list(self.slippage_history[symbol])
        if not trades:
            return pd.DataFrame()
        
        # Convert to DataFrame
        df = pd.DataFrame(trades)
        
        # Feature engineering
        features_df = pd.DataFrame()
        
        # Basic features
        features_df['trade_size_usd'] = df['trade_size_usd']
        features_df['volume_ratio'] = df.apply(
            lambda row: row['trade_size_usd'] / max(row.get('market_volume', 1), 1), axis=1
        )
        
        # Rolling volatility (5-minute and 1-hour windows)
        prices = df['trade_price'].values
        if len(prices) >= 5:
            returns_5m = np.diff(np.log(prices[-5:]))
            features_df['volatility_5m'] = np.std(returns_5m) if len(returns_5m) > 0 else 0
        else:
            features_df['volatility_5m'] = 0
        
        if len(prices) >= 60:
            returns_1h = np.diff(np.log(prices[-60:]))
            features_df['volatility_1h'] = np.std(returns_1h) if len(returns_1h) > 0 else 0
        else:
            features_df['volatility_1h'] = 0
        
        # Time features
        timestamps = pd.to_datetime(df['timestamp'])
        features_df['hour_of_day'] = timestamps.dt.hour
        features_df['day_of_week'] = timestamps.dt.dayofweek
        
        # Add synthetic features for training
        np.random.seed(42)  # For reproducible synthetic data
        features_df['bid_ask_spread_bps'] = np.random.uniform(1, 10, len(df))
        features_df['market_depth_score'] = np.random.uniform(0.3, 1.0, len(df))
        features_df['price_momentum'] = np.random.uniform(-0.01, 0.01, len(df))
        features_df['liquidity_score'] = np.random.uniform(0.2, 0.9, len(df))
        features_df['venue_latency'] = np.random.uniform(20, 100, len(df))
        features_df['venue_reliability'] = np.random.uniform(0.7, 0.99, len(df))
        features_df['market_stress'] = np.random.uniform(0, 0.5, len(df))
        
        # Add target
        features_df['slippage'] = df['slippage']
        
        return features_df
    
    def get_slippage_statistics(self, symbol: str, days: int = 30) -> Dict:
        """Slippage istatistikleri"""
        
        cutoff_date = datetime.now() - timedelta(days=days)
        
        # Filter recent data
        recent_trades = [
            trade for trade in self.slippage_history[symbol]
            if trade['timestamp'] > cutoff_date
        ]
        
        if not recent_trades:
            return {'message': 'No recent data available'}
        
        # Calculate statistics
        slippage_values = [trade['slippage'] for trade in recent_trades]
        trade_sizes = [trade['trade_size_usd'] for trade in recent_trades]
        
        stats_dict = {
            'period_days': days,
            'total_trades': len(recent_trades),
            'slippage_stats': {
                'mean': np.mean(slippage_values),
                'median': np.median(slippage_values),
                'std': np.std(slippage_values),
                'min': np.min(slippage_values),
                'max': np.max(slippage_values),
                'p95': np.percentile(slippage_values, 95),
                'p99': np.percentile(slippage_values, 99)
            },
            'trade_size_stats': {
                'mean': np.mean(trade_sizes),
                'median': np.median(trade_sizes),
                'std': np.std(trade_sizes),
                'min': np.min(trade_sizes),
                'max': np.max(trade_sizes)
            },
            'correlation_analysis': {
                'size_slippage_corr': np.corrcoef(trade_sizes, slippage_values)[0, 1]
                if len(trade_sizes) > 1 else 0
            }
        }
        
        # Venue analysis
        venue_analysis = defaultdict(list)
        for trade in recent_trades:
            venue_analysis[trade['venue']].append(trade['slippage'])
        
        venue_stats = {}
        for venue, venue_slippage in venue_analysis.items():
            venue_stats[venue] = {
                'mean_slippage': np.mean(venue_slippage),
                'median_slippage': np.median(venue_slippage),
                'trade_count': len(venue_slippage)
            }
        
        stats_dict['venue_analysis'] = venue_stats
        
        return stats_dict
    
    def compare_prediction_accuracy(self, symbol: str, days: int = 7) -> Dict:
        """Tahmin doğruluğu karşılaştırması"""
        
        cutoff_date = datetime.now() - timedelta(days=days)
        
        # Get prediction history and actual results
        predictions = []
        actual_results = []
        
        # This would require storing prediction-result pairs
        # For now, return model performance metrics
        performance_summary = {}
        
        for model_name, performance in self.model_performance.items():
            performance_summary[model_name] = {
                'mae': performance.get('mae', 0),
                'rmse': performance.get('rmse', 0),
                'r2': performance.get('r2', 0),
                'last_trained': performance.get('last_trained')
            }
        
        return {
            'period_days': days,
            'model_performance': performance_summary,
            'best_model': max(performance_summary.items(), 
                            key=lambda x: x[1]['r2'] if x[1]['r2'] is not None else 0)[0],
            'accuracy_trends': 'Insufficient prediction history for trend analysis'
        }