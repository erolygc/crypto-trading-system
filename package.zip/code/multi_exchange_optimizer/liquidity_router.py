"""
Liquidity-Weighted Router
Likiditeye dayalı optimal routing algoritması
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from scipy.optimize import minimize
import logging
from config import ExchangeConfig

@dataclass
class Route:
    """Trading route yapısı"""
    venue: str
    symbol: str
    quantity: float
    price: float
    estimated_slippage: float
    execution_time: float
    cost: float
    liquidity_depth: float

@dataclass
class RoutingResult:
    """Routing sonucu"""
    routes: List[Route]
    total_quantity: float
    total_cost: float
    estimated_slippage: float
    execution_time: float
    liquidity_score: float
    cost_efficiency: float

class LiquidityRouter:
    """Likidite-ağırlıklı router"""
    
    def __init__(self, config: ExchangeConfig, price_aggregator):
        self.config = config
        self.price_aggregator = price_aggregator
        self.logger = logging.getLogger(__name__)
        
        # Historical slippage data
        self.slippage_history = {}
        
        # Market impact parameters
        self.impact_params = {}
        self._init_impact_parameters()
    
    def _init_impact_parameters(self):
        """Market impact parametrelerini başlat"""
        for venue_name, venue_config in self.config.VENUES.items():
            if venue_config.enabled:
                # Venue-specific market impact modeli
                self.impact_params[venue_name] = {
                    'k': 0.1,  # Market impact coefficient
                    'alpha': 0.5,  # Impact exponent
                    'base_spread': venue_config.fee_taker,
                    'latency_factor': 0.001,  # Latency penalty
                    'volume_factor': 1.0 / venue_config.rate_limit  # Volume capacity factor
                }
    
    def optimize_route(self, symbol: str, quantity: float, side: str = 'buy') -> RoutingResult:
        """Optimal route hesaplama"""
        
        # Market data topla
        market_data = self._get_market_data(symbol)
        if not market_data:
            raise ValueError(f"No market data available for {symbol}")
        
        # Route optimizasyonu
        optimal_routes = self._calculate_optimal_allocation(market_data, quantity, side)
        
        # Execution simulation
        execution_result = self._simulate_execution(optimal_routes, symbol, quantity, side)
        
        return execution_result
    
    def _get_market_data(self, symbol: str) -> Dict:
        """Market verilerini topla"""
        market_data = {
            'venues': {},
            'aggregated': self.price_aggregator.aggregate_prices(symbol)
        }
        
        for venue_name, venue_data in self.price_aggregator.price_cache.items():
            if symbol in venue_data:
                price_data = venue_data[symbol]
                
                # Venue score hesapla
                venue_score = self._calculate_venue_score(venue_name, price_data)
                
                # Depth analizi
                depth = self._estimate_liquidity_depth(venue_name, price_data)
                
                # Market impact tahmini
                impact = self._estimate_market_impact(venue_name, quantity)
                
                market_data['venues'][venue_name] = {
                    'price_data': price_data,
                    'score': venue_score,
                    'liquidity_depth': depth,
                    'estimated_impact': impact,
                    'execution_cost': self._calculate_execution_cost(venue_name, price_data)
                }
        
        return market_data
    
    def _calculate_venue_score(self, venue_name: str, price_data) -> float:
        """Venue scoring algoritması"""
        venue_config = self.config.VENUES[venue_name]
        opt_config = self.config.OPTIMIZATION
        
        # Latency score
        avg_latency = self.price_aggregator.latency_tracker.get_avg_latency(venue_name)
        latency_score = max(0, 1 - avg_latency / venue_config.latency_threshold)
        
        # Volume score
        total_volume = sum([v.volume_24h for venue_data in self.price_aggregator.price_cache.values() 
                           for v in venue_data.values()])
        volume_score = price_data.volume_24h / total_volume if total_volume > 0 else 0
        
        # Cost score (fee + spread)
        total_cost = venue_config.fee_taker + (price_data.ask - price_data.bid) / price_data.price
        cost_score = max(0, 1 - total_cost / 0.01)  # Normalize against 1%
        
        # Priority score
        priority_score = (5 - venue_config.priority) / 4
        
        # Ağırlıklı toplam
        total_score = (
            opt_config.liquidity_weight_alpha * volume_score +
            opt_config.latency_weight_beta * latency_score +
            opt_config.cost_weight_gamma * cost_score +
            0.1 * priority_score
        )
        
        return max(0, min(1, total_score))  # 0-1 arası normalize et
    
    def _estimate_liquidity_depth(self, venue_name: str, price_data) -> float:
        """Likidite derinliği tahmini"""
        venue_config = self.config.VENUES[venue_name]
        
        # Volume'e dayalı basit depth tahmini
        # Gerçek implementasyonda order book verileri kullanılır
        daily_volume = price_data.volume_24h
        
        # Venue-specific depth multipliers
        if venue_config.type == 'cex':
            depth_factor = 0.1  # CEX'lerde genelde yüksek likidite
        else:
            depth_factor = 0.05  # DEX'lerde daha düşük
        
        estimated_depth = daily_volume * depth_factor
        return min(estimated_depth, venue_config.max_trade_size)
    
    def _estimate_market_impact(self, venue_name: str, quantity: float) -> float:
        """Market impact tahmini"""
        params = self.impact_params[venue_name]
        venue_config = self.config.VENUES[venue_name]
        
        # Square root market impact model
        # Impact = k * (quantity/volume)^alpha
        base_impact = params['k'] * (quantity / venue_config.rate_limit) ** params['alpha']
        
        # Latency penalty
        avg_latency = self.price_aggregator.latency_tracker.get_avg_latency(venue_name)
        latency_penalty = params['latency_factor'] * avg_latency / 1000
        
        return base_impact + latency_penalty
    
    def _calculate_execution_cost(self, venue_name: str, price_data) -> float:
        """Execution cost hesaplama"""
        venue_config = self.config.VENUES[venue_name]
        
        # Fee + spread + slippage
        spread_cost = (price_data.ask - price_data.bid) / price_data.price
        fee_cost = venue_config.fee_taker
        
        return spread_cost + fee_cost
    
    def _calculate_optimal_allocation(self, market_data: Dict, quantity: float, side: str) -> List[Route]:
        """Optimal quantity allocation hesaplama"""
        venues = list(market_data['venues'].keys())
        n_venues = len(venues)
        
        if n_venues == 0:
            return []
        
        if n_venues == 1:
            # Tek venue durumu
            venue_name = venues[0]
            venue_info = market_data['venues'][venue_name]
            
            allocated_quantity = min(quantity, venue_info['liquidity_depth'])
            
            return [Route(
                venue=venue_name,
                symbol='',
                quantity=allocated_quantity,
                price=venue_info['price_data'].ask if side == 'buy' else venue_info['price_data'].bid,
                estimated_slippage=venue_info['estimated_impact'],
                execution_time=self.price_aggregator.latency_tracker.get_avg_latency(venue_name) / 1000,
                cost=allocated_quantity * venue_info['execution_cost'],
                liquidity_depth=venue_info['liquidity_depth']
            )]
        
        # Multi-venue optimization
        def objective(weights):
            """Optimization objective function"""
            total_slippage = 0
            total_cost = 0
            total_latency = 0
            
            for i, venue_name in enumerate(venues):
                venue_info = market_data['venues'][venue_name]
                allocated_qty = weights[i] * quantity
                
                if allocated_qty > 0:
                    # Weighted slippage
                    slippage = venue_info['estimated_impact'] * (allocated_qty / quantity)
                    total_slippage += weights[i] * slippage
                    
                    # Weighted cost
                    total_cost += weights[i] * venue_info['execution_cost']
                    
                    # Weighted latency
                    avg_latency = self.price_aggregator.latency_tracker.get_avg_latency(venue_name)
                    total_latency += weights[i] * avg_latency
            
            # Objective: minimize cost + slippage + latency penalty
            opt_config = self.config.OPTIMIZATION
            
            objective_value = (
                opt_config.cost_weight_gamma * total_cost +
                opt_config.liquidity_weight_alpha * total_slippage +
                opt_config.latency_weight_beta * total_latency / 1000
            )
            
            return objective_value
        
        # Constraints
        constraints = [
            {'type': 'eq', 'fun': lambda w: np.sum(w) - 1},  # Sum of weights = 1
        ]
        
        # Bounds - her venue için
        bounds = []
        for venue_name in venues:
            venue_info = market_data['venues'][venue_name]
            max_weight = min(1.0, venue_info['liquidity_depth'] / quantity)
            bounds.append((0, max_weight))
        
        # Initial guess - equal weights
        x0 = np.ones(n_venues) / n_venues
        
        # Optimization
        result = minimize(
            objective,
            x0,
            method='SLSQP',
            bounds=bounds,
            constraints=constraints,
            options={'maxiter': 100, 'ftol': 1e-6}
        )
        
        if not result.success:
            self.logger.warning(f"Optimization failed: {result.message}")
            # Fallback to proportional allocation
            weights = np.ones(n_venues) / n_venues
        else:
            weights = result.x
        
        # Create routes
        routes = []
        for i, venue_name in enumerate(venues):
            venue_info = market_data['venues'][venue_name]
            allocated_quantity = weights[i] * quantity
            
            if allocated_quantity > 0:
                price = (venue_info['price_data'].ask if side == 'buy' 
                        else venue_info['price_data'].bid)
                
                routes.append(Route(
                    venue=venue_name,
                    symbol='',
                    quantity=allocated_quantity,
                    price=price,
                    estimated_slippage=venue_info['estimated_impact'] * (allocated_quantity / quantity),
                    execution_time=self.price_aggregator.latency_tracker.get_avg_latency(venue_name) / 1000,
                    cost=allocated_quantity * venue_info['execution_cost'],
                    liquidity_depth=venue_info['liquidity_depth']
                ))
        
        return routes
    
    def _simulate_execution(self, routes: List[Route], symbol: str, 
                          total_quantity: float, side: str) -> RoutingResult:
        """Execution simülasyonu"""
        
        total_cost = sum([route.cost for route in routes])
        total_slippage = sum([route.estimated_slippage * route.quantity for route in routes])
        total_execution_time = max([route.execution_time for route in routes]) if routes else 0
        
        # Liquidity score hesaplama
        total_liquidity = sum([route.liquidity_depth for route in routes])
        liquidity_score = min(1.0, total_liquidity / total_quantity) if total_quantity > 0 else 0
        
        # Cost efficiency
        avg_price = np.mean([route.price for route in routes])
        cost_efficiency = total_cost / avg_price if avg_price > 0 else 0
        
        return RoutingResult(
            routes=routes,
            total_quantity=total_quantity,
            total_cost=total_cost,
            estimated_slippage=total_slippage,
            execution_time=total_execution_time,
            liquidity_score=liquidity_score,
            cost_efficiency=cost_efficiency
        )
    
    def get_venue_ranking(self, symbol: str) -> List[Dict]:
        """Venue ranking ve analizi"""
        market_data = self._get_market_data(symbol)
        
        if not market_data['venues']:
            return []
        
        rankings = []
        for venue_name, venue_info in market_data['venues'].items():
            ranking_data = {
                'venue': venue_name,
                'score': venue_info['score'],
                'liquidity_depth': venue_info['liquidity_depth'],
                'execution_cost': venue_info['execution_cost'],
                'estimated_impact': venue_info['estimated_impact'],
                'avg_latency': self.price_aggregator.latency_tracker.get_avg_latency(venue_name),
                'rank': 0  # Will be set after sorting
            }
            rankings.append(ranking_data)
        
        # Score'a göre sırala
        rankings.sort(key=lambda x: x['score'], reverse=True)
        
        # Rank ataması
        for i, ranking in enumerate(rankings):
            ranking['rank'] = i + 1
        
        return rankings
    
    def calculate_execution_plan(self, symbol: str, quantity: float, 
                               execution_window: float = 300) -> List[Dict]:
        """Time-based execution plan (TWAP)"""
        
        # Market data
        market_data = self._get_market_data(symbol)
        if not market_data['venues']:
            return []
        
        # Optimal allocation
        routes = self._calculate_optimal_allocation(market_data, quantity, 'buy')
        
        # Time slices
        n_slices = min(10, int(execution_window / 30))  # Max 10 slices, 30s minimum
        slice_size = quantity / n_slices
        slice_interval = execution_window / n_slices
        
        execution_plan = []
        
        for i in range(n_slices):
            slice_routes = []
            remaining_quantity = slice_size
            
            for route in routes:
                if remaining_quantity > 0:
                    allocated = min(route.quantity * slice_size / quantity, remaining_quantity)
                    
                    if allocated > 0:
                        slice_routes.append({
                            'venue': route.venue,
                            'quantity': allocated,
                            'price': route.price,
                            'execution_time': i * slice_interval + slice_interval / 2
                        })
                        remaining_quantity -= allocated
            
            execution_plan.append({
                'slice': i + 1,
                'quantity': slice_size - remaining_quantity,
                'routes': slice_routes,
                'execution_time': i * slice_interval
            })
        
        return execution_plan
    
    def backtest_routing_strategy(self, symbol: str, historical_data: pd.DataFrame) -> Dict:
        """Routing stratejisi backtest"""
        
        results = []
        
        for index, row in historical_data.iterrows():
            try:
                quantity = row.get('quantity', 1000)  # Default quantity
                
                # Simulate routing
                routing_result = self.optimize_route(symbol, quantity, row.get('side', 'buy'))
                
                result_metrics = {
                    'timestamp': index,
                    'quantity': quantity,
                    'total_cost': routing_result.total_cost,
                    'estimated_slippage': routing_result.estimated_slippage,
                    'liquidity_score': routing_result.liquidity_score,
                    'cost_efficiency': routing_result.cost_efficiency,
                    'execution_time': routing_result.execution_time,
                    'n_venues': len(routing_result.routes)
                }
                results.append(result_metrics)
                
            except Exception as e:
                self.logger.warning(f"Backtest error at {index}: {e}")
                continue
        
        # Performance metrics
        if not results:
            return {}
        
        results_df = pd.DataFrame(results)
        
        return {
            'total_trades': len(results),
            'avg_cost': results_df['total_cost'].mean(),
            'avg_slippage': results_df['estimated_slippage'].mean(),
            'avg_liquidity_score': results_df['liquidity_score'].mean(),
            'avg_execution_time': results_df['execution_time'].mean(),
            'cost_std': results_df['total_cost'].std(),
            'slippage_std': results_df['estimated_slippage'].std(),
            'venue_diversity': results_df['n_venues'].mean(),
            'detailed_results': results_df.to_dict('records')
        }