"""
Multi-Exchange Optimizer
Ana koordinatör ve ana sistem
"""

import asyncio
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import json
import pandas as pd
import numpy as np

# Import all components
from config import ExchangeConfig
from price_aggregator import PriceAggregator, AggregatedPrice
from liquidity_router import LiquidityRouter, RoutingResult
from cost_optimizer import CostOptimizer, OptimizationResult
from venue_constraints import VenueConstraintManager, ConstraintViolation
from rate_limiter import AdvancedRateLimiter, APIRequest
from latency_manager import LatencyManager, LatencyRoutingDecision
from vwap_calculator import VWAPCalculator, VWAPResult
from twap_optimizer import TWAPOptimizer, TWAPExecutionPlan
from cross_venue_analyzer import CrossVenueAnalyzer, CrossVenueComparison
from slippage_predictor import SlippagePredictor, SlippagePrediction

@dataclass
class OptimizationRequest:
    """Optimizasyon isteği"""
    symbol: str
    quantity: float
    side: str = 'buy'  # 'buy' or 'sell'
    urgency: str = 'normal'  # 'low', 'normal', 'high', 'critical'
    execution_style: str = 'immediate'  # 'immediate', 'twap', 'vwap'
    time_horizon: Optional[int] = None  # seconds for TWAP
    max_slippage: Optional[float] = None
    preferred_venues: Optional[List[str]] = None
    constraints: Optional[Dict] = None

@dataclass
class OptimizationResponse:
    """Optimizasyon yanıtı"""
    request_id: str
    success: bool
    recommended_routing: Optional[Dict] = None
    cost_breakdown: Optional[Dict] = None
    risk_analysis: Optional[Dict] = None
    execution_plan: Optional[Dict] = None
    estimated_slippage: Optional[float] = None
    alternatives: List[Dict] = None
    warnings: List[str] = None
    timestamp: datetime = None

class MultiExchangeOptimizer:
    """Multi-Exchange Optimizer Ana Sistemi"""
    
    def __init__(self, config: ExchangeConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Initialize components
        self.price_aggregator = PriceAggregator(config)
        self.constraint_manager = VenueConstraintManager(config)
        self.rate_limiter = AdvancedRateLimiter(config)
        self.latency_manager = LatencyManager(config)
        
        # Initialize with dependencies
        self.cost_optimizer = CostOptimizer(config, self.price_aggregator)
        self.liquidity_router = LiquidityRouter(config, self.price_aggregator)
        self.vwap_calculator = VWAPCalculator(config)
        self.twap_optimizer = TWAPOptimizer(config, self.price_aggregator)
        self.cross_venue_analyzer = CrossVenueAnalyzer(config, self.price_aggregator)
        self.slippage_predictor = SlippagePredictor(config, self.price_aggregator)
        
        # System state
        self.request_counter = 0
        self.active_optimizations = {}
        self.performance_metrics = {}
        self.system_status = 'initialized'
        
        # Performance tracking
        self.optimization_history = []
        
        self.logger.info("Multi-Exchange Optimizer initialized")
    
    async def start_system(self):
        """Sistemi başlat"""
        try:
            self.logger.info("Starting Multi-Exchange Optimizer system...")
            
            # Start price aggregation
            price_task = asyncio.create_task(self.price_aggregator.start_price_feeds())
            
            # Start background processes
            monitoring_task = asyncio.create_task(self._system_monitoring_loop())
            cleanup_task = asyncio.create_task(self._cleanup_loop())
            
            self.system_status = 'running'
            self.logger.info("System started successfully")
            
            # Run all tasks concurrently
            await asyncio.gather(price_task, monitoring_task, cleanup_task)
            
        except Exception as e:
            self.logger.error(f"System startup failed: {e}")
            self.system_status = 'error'
            raise
    
    async def optimize_trade(self, request: OptimizationRequest) -> OptimizationResponse:
        """Ana trade optimizasyon fonksiyonu"""
        
        request_id = f"opt_{self.request_counter}_{int(datetime.now().timestamp())}"
        self.request_counter += 1
        
        try:
            self.logger.info(f"Processing optimization request {request_id} for {request.symbol}")
            
            # Phase 1: Market Data Collection
            market_data = await self._collect_market_data(request.symbol)
            
            # Phase 2: Constraint Analysis
            constraint_analysis = await self._analyze_constraints(request)
            
            # Phase 3: Latency Analysis
            latency_analysis = await self._analyze_latency_routing(request.symbol, request.urgency)
            
            # Phase 4: Cost Optimization
            cost_optimization = await self._optimize_costs(request, market_data, constraint_analysis)
            
            # Phase 5: Liquidity Routing
            liquidity_routing = await self._optimize_liquidity_routing(
                request, market_data, cost_optimization, latency_analysis
            )
            
            # Phase 6: Slippage Prediction
            slippage_prediction = await self._predict_slippage(request, market_data)
            
            # Phase 7: Execution Plan
            execution_plan = await self._create_execution_plan(request, liquidity_routing, slippage_prediction)
            
            # Phase 8: Risk Analysis
            risk_analysis = await self._analyze_risks(request, liquidity_routing, slippage_prediction)
            
            # Compile response
            response = OptimizationResponse(
                request_id=request_id,
                success=True,
                recommended_routing=liquidity_routing,
                cost_breakdown=cost_optimization,
                risk_analysis=risk_analysis,
                execution_plan=execution_plan,
                estimated_slippage=slippage_prediction.predicted_slippage if slippage_prediction else None,
                alternatives=await self._generate_alternatives(request, market_data),
                warnings=await self._generate_warnings(request, market_data, constraint_analysis),
                timestamp=datetime.now()
            )
            
            # Store for tracking
            self.active_optimizations[request_id] = response
            
            # Update performance metrics
            self._update_performance_metrics(request, response)
            
            self.logger.info(f"Optimization request {request_id} completed successfully")
            
            return response
            
        except Exception as e:
            self.logger.error(f"Optimization request {request_id} failed: {e}")
            
            return OptimizationResponse(
                request_id=request_id,
                success=False,
                warnings=[f"Optimization failed: {str(e)}"],
                timestamp=datetime.now()
            )
    
    async def _collect_market_data(self, symbol: str) -> Dict:
        """Market verilerini topla"""
        
        # Wait for price aggregation
        await asyncio.sleep(0.1)  # Allow time for data collection
        
        # Get aggregated price
        aggregated_price = self.price_aggregator.aggregate_prices(symbol)
        
        # Get market opportunities
        opportunities = self.price_aggregator.get_best_routing_opportunities(symbol)
        
        # Get market summary
        market_summary = self.price_aggregator.get_market_summary()
        
        return {
            'aggregated_price': aggregated_price,
            'routing_opportunities': opportunities,
            'market_summary': market_summary,
            'timestamp': datetime.now()
        }
    
    async def _analyze_constraints(self, request: OptimizationRequest) -> Dict:
        """Kısıtlama analizi"""
        
        constraint_results = {}
        
        for venue_name, venue_config in self.config.VENUES.items():
            if not venue_config.enabled:
                continue
            
            # Check constraints
            is_valid, violations = self.constraint_manager.check_constraints(
                venue_name, request.quantity, symbol=request.symbol
            )
            
            constraint_results[venue_name] = {
                'valid': is_valid,
                'violations': violations,
                'status': self.constraint_manager.get_constraint_status(venue_name)
            }
        
        return {
            'venue_analysis': constraint_results,
            'global_constraints': self.constraint_manager.get_all_constraint_status(),
            'recommendations': self._generate_constraint_recommendations(constraint_results)
        }
    
    async def _analyze_latency_routing(self, symbol: str, urgency: str) -> Dict:
        """Latency routing analizi"""
        
        venues = [name for name, config in self.config.VENUES.items() if config.enabled]
        
        if not venues:
            return {}
        
        # Get routing decisions
        routing_decisions = self.latency_manager.make_routing_decision(
            venues, '/api/v3/ticker/price', urgency
        )
        
        # Get recommendations
        recommendations = self.latency_manager.get_latency_recommendations()
        
        return {
            'routing_decisions': [
                {
                    'venue': decision.venue,
                    'priority': decision.priority,
                    'total_score': decision.total_score,
                    'estimated_time': decision.estimated_time,
                    'recommended': decision.recommended,
                    'reasons': decision.reasons
                }
                for decision in routing_decisions
            ],
            'recommendations': recommendations,
            'latency_heatmap': self.latency_manager.get_latency_heatmap_data()
        }
    
    async def _optimize_costs(self, request: OptimizationRequest, market_data: Dict, 
                            constraint_analysis: Dict) -> Dict:
        """Cost optimizasyonu"""
        
        try:
            # Filter venues based on constraints
            available_venues = [
                venue for venue, analysis in constraint_analysis['venue_analysis'].items()
                if analysis['valid']
            ]
            
            if not available_venues:
                return {'error': 'No valid venues available after constraint filtering'}
            
            # Optimize execution cost
            optimization_result = self.cost_optimizer.optimize_execution_cost(
                symbol=request.symbol,
                quantity=request.quantity,
                side=request.side
            )
            
            return {
                'optimal_allocation': optimization_result.optimal_allocation,
                'total_cost_breakdown': optimization_result.total_cost,
                'expected_slippage': optimization_result.expected_slippage,
                'execution_time': optimization_result.execution_time,
                'venue_costs': optimization_result.venue_costs,
                'convergence': optimization_result.convergence
            }
            
        except Exception as e:
            self.logger.warning(f"Cost optimization failed: {e}")
            return {'error': str(e)}
    
    async def _optimize_liquidity_routing(self, request: OptimizationRequest, market_data: Dict,
                                        cost_optimization: Dict, latency_analysis: Dict) -> Dict:
        """Liquidity routing optimizasyonu"""
        
        try:
            # Get routing result
            routing_result = self.liquidity_router.optimize_route(
                symbol=request.symbol,
                quantity=request.quantity,
                side=request.side
            )
            
            # Get venue ranking
            venue_ranking = self.liquidity_router.get_venue_ranking(request.symbol)
            
            return {
                'routing_result': {
                    'routes': [
                        {
                            'venue': route.venue,
                            'quantity': route.quantity,
                            'price': route.price,
                            'estimated_slippage': route.estimated_slippage,
                            'execution_time': route.execution_time,
                            'cost': route.cost
                        }
                        for route in routing_result.routes
                    ],
                    'total_quantity': routing_result.total_quantity,
                    'total_cost': routing_result.total_cost,
                    'estimated_slippage': routing_result.estimated_slippage,
                    'liquidity_score': routing_result.liquidity_score,
                    'cost_efficiency': routing_result.cost_efficiency
                },
                'venue_ranking': venue_ranking,
                'optimization_metrics': {
                    'execution_plan': self.liquidity_router.calculate_execution_plan(
                        request.symbol, request.quantity, request.time_horizon or 300
                    )
                }
            }
            
        except Exception as e:
            self.logger.warning(f"Liquidity routing failed: {e}")
            return {'error': str(e)}
    
    async def _predict_slippage(self, request: OptimizationRequest, market_data: Dict) -> Optional[SlippagePrediction]:
        """Slippage tahmini"""
        
        try:
            # Prepare market data for slippage prediction
            market_features = {
                'volume_ratio': request.quantity / 100000,  # Simplified
                'volatility_5m': 0.02,
                'volatility_1h': 0.02,
                'bid_ask_spread_bps': 5.0,
                'market_depth_score': 0.7,
                'price_momentum': 0.0,
                'liquidity_score': 0.8
            }
            
            # Get prediction for each potential venue
            venue_predictions = {}
            for venue_name in self.config.VENUES.keys():
                if self.config.VENUES[venue_name].enabled:
                    prediction = self.slippage_predictor.predict_slippage(
                        symbol=request.symbol,
                        trade_size=request.quantity,
                        venue=venue_name,
                        market_data=market_features
                    )
                    if prediction:
                        venue_predictions[venue_name] = prediction
            
            # Return best prediction
            if venue_predictions:
                # Choose venue with lowest predicted slippage
                best_venue = min(venue_predictions.keys(), 
                               key=lambda v: venue_predictions[v].predicted_slippage)
                return venue_predictions[best_venue]
            
            return None
            
        except Exception as e:
            self.logger.warning(f"Slippage prediction failed: {e}")
            return None
    
    async def _create_execution_plan(self, request: OptimizationRequest, liquidity_routing: Dict,
                                   slippage_prediction: Optional[SlippagePrediction]) -> Dict:
        """Execution plan oluştur"""
        
        try:
            if request.execution_style == 'twap':
                # Create TWAP plan
                time_hours = (request.time_horizon or 300) / 3600
                twap_plan = self.twap_optimizer.create_twap_plan(
                    symbol=request.symbol,
                    quantity=request.quantity,
                    time_hours=time_hours,
                    execution_style='adaptive'
                )
                
                return {
                    'type': 'twap',
                    'plan': {
                        'total_quantity': twap_plan.total_quantity,
                        'slice_count': twap_plan.slice_count,
                        'time_horizon_minutes': time_hours * 60,
                        'slices': [
                            {
                                'slice_id': slice_obj.slice_id,
                                'start_time': slice_obj.start_time.isoformat(),
                                'end_time': slice_obj.end_time.isoformat(),
                                'planned_quantity': slice_obj.planned_quantity,
                                'target_price': slice_obj.target_price
                            }
                            for slice_obj in twap_plan.slices
                        ]
                    }
                }
            
            elif request.execution_style == 'vwap':
                # Create VWAP calculation
                vwap_result = self.vwap_calculator.calculate_vwap(
                    symbol=request.symbol,
                    window_minutes=60
                )
                
                return {
                    'type': 'vwap',
                    'target_price': vwap_result.vwap if vwap_result else None,
                    'volume_profile': vwap_result.volume_profile if vwap_result else None
                }
            
            else:
                # Immediate execution
                return {
                    'type': 'immediate',
                    'execution_time': 'now',
                    'routing_instructions': liquidity_routing.get('routing_result', {})
                }
                
        except Exception as e:
            self.logger.warning(f"Execution plan creation failed: {e}")
            return {'type': 'immediate', 'error': str(e)}
    
    async def _analyze_risks(self, request: OptimizationRequest, liquidity_routing: Dict,
                           slippage_prediction: Optional[SlippagePrediction]) -> Dict:
        """Risk analizi"""
        
        try:
            risks = {
                'slippage_risk': {
                    'level': 'high' if slippage_prediction and slippage_prediction.predicted_slippage > 0.01 
                            else 'medium' if slippage_prediction and slippage_prediction.predicted_slippage > 0.005
                            else 'low',
                    'predicted_slippage': slippage_prediction.predicted_slippage if slippage_prediction else 0,
                    'confidence_interval': slippage_prediction.confidence_interval if slippage_prediction else None
                },
                'latency_risk': {
                    'level': 'high' if request.urgency in ['high', 'critical'] else 'medium',
                    'execution_time': liquidity_routing.get('routing_result', {}).get('execution_time', 0)
                },
                'liquidity_risk': {
                    'level': 'high' if request.quantity > 100000 else 'medium' if request.quantity > 10000 else 'low',
                    'score': liquidity_routing.get('routing_result', {}).get('liquidity_score', 0)
                },
                'venue_risk': {
                    'level': 'high' if len(liquidity_routing.get('routing_result', {}).get('routes', [])) < 2 else 'low',
                    'venue_count': len(liquidity_routing.get('routing_result', {}).get('routes', []))
                }
            }
            
            # Overall risk score
            risk_scores = {'high': 3, 'medium': 2, 'low': 1}
            total_score = sum(risk_scores[risk['level']] for risk in risks.values()) / len(risks)
            overall_risk = 'high' if total_score >= 2.5 else 'medium' if total_score >= 1.5 else 'low'
            
            risks['overall_risk'] = {
                'level': overall_risk,
                'score': total_score,
                'recommendations': self._generate_risk_recommendations(risks)
            }
            
            return risks
            
        except Exception as e:
            self.logger.warning(f"Risk analysis failed: {e}")
            return {'overall_risk': {'level': 'unknown', 'error': str(e)}}
    
    async def _generate_alternatives(self, request: OptimizationRequest, market_data: Dict) -> List[Dict]:
        """Alternatif stratejiler"""
        
        alternatives = []
        
        # Alternative 1: Different venues
        opportunities = market_data.get('routing_opportunities', [])
        if len(opportunities) >= 2:
            alternatives.append({
                'type': 'venue_alternative',
                'description': 'Use different venue combination',
                'venues': [opp['venue'] for opp in opportunities[:3]],
                'estimated_savings': 0.005  # 0.5% savings estimate
            })
        
        # Alternative 2: TWAP execution
        alternatives.append({
            'type': 'execution_alternative',
            'description': 'Use TWAP execution to reduce market impact',
            'method': 'twap',
            'time_horizon': 900,  # 15 minutes
            'estimated_slippage_reduction': 0.3  # 30% reduction
        })
        
        # Alternative 3: Split execution
        alternatives.append({
            'type': 'execution_alternative',
            'description': 'Split execution across time',
            'method': 'split_execution',
            'splits': 3,
            'estimated_slippage_reduction': 0.2  # 20% reduction
        })
        
        return alternatives
    
    async def _generate_warnings(self, request: OptimizationRequest, market_data: Dict, 
                               constraint_analysis: Dict) -> List[str]:
        """Uyarılar oluştur"""
        
        warnings = []
        
        # High slippage warning
        aggregated_price = market_data.get('aggregated_price')
        if aggregated_price and aggregated_price.price_spread > aggregated_price.mid_price * 0.005:
            warnings.append("Wide bid-ask spread detected - expect higher transaction costs")
        
        # Constraint warnings
        for venue, analysis in constraint_analysis['venue_analysis'].items():
            if not analysis['valid']:
                warnings.append(f"Constraints violated at {venue}: {analysis['violations']}")
        
        # Liquidity warning
        liquidity_score = market_data.get('market_summary', {}).get('liquidity_score', 0)
        if liquidity_score < 0.5:
            warnings.append("Low market liquidity - consider reducing order size or using TWAP")
        
        # Time-based warnings
        if request.urgency == 'critical' and request.execution_style == 'twap':
            warnings.append("Critical urgency with TWAP execution may result in missed opportunities")
        
        return warnings
    
    def _generate_constraint_recommendations(self, constraint_analysis: Dict) -> List[str]:
        """Kısıtlama önerileri"""
        
        recommendations = []
        
        # Find venues with violations
        problematic_venues = [
            venue for venue, analysis in constraint_analysis['venue_analysis'].items()
            if not analysis['valid']
        ]
        
        if problematic_venues:
            recommendations.append(f"Avoid venues with constraint violations: {', '.join(problematic_venues)}")
        
        # Check circuit breakers
        active_breakers = [
            venue for venue, status in constraint_analysis.get('global_constraints', {}).items()
            if status.get('circuit_breaker', False)
        ]
        
        if active_breakers:
            recommendations.append(f"Circuit breakers active at: {', '.join(active_breakers)}")
        
        return recommendations
    
    def _generate_risk_recommendations(self, risks: Dict) -> List[str]:
        """Risk önerileri"""
        
        recommendations = []
        
        if risks['slippage_risk']['level'] == 'high':
            recommendations.append("Consider using TWAP execution or reducing order size to minimize slippage")
        
        if risks['latency_risk']['level'] == 'high':
            recommendations.append("Use venues with lowest latency for time-sensitive orders")
        
        if risks['liquidity_risk']['level'] == 'high':
            recommendations.append("Large order detected - consider splitting across multiple venues")
        
        if risks['venue_risk']['level'] == 'high':
            recommendations.append("Limited venue options - monitor for venue availability issues")
        
        return recommendations
    
    def _update_performance_metrics(self, request: OptimizationRequest, response: OptimizationResponse):
        """Performance metriklerini güncelle"""
        
        if not self.performance_metrics:
            self.performance_metrics = {
                'total_requests': 0,
                'successful_requests': 0,
                'avg_processing_time': 0,
                'avg_slippage': 0,
                'cost_savings': 0
            }
        
        self.performance_metrics['total_requests'] += 1
        if response.success:
            self.performance_metrics['successful_requests'] += 1
        
        # Store in history
        self.optimization_history.append({
            'timestamp': datetime.now(),
            'symbol': request.symbol,
            'quantity': request.quantity,
            'success': response.success,
            'estimated_slippage': response.estimated_slippage,
            'cost_breakdown': response.cost_breakdown
        })
        
        # Keep only last 1000 records
        if len(self.optimization_history) > 1000:
            self.optimization_history = self.optimization_history[-1000:]
    
    async def _system_monitoring_loop(self):
        """Sistem monitoring döngüsü"""
        while True:
            try:
                # Check system health
                await self._check_system_health()
                
                # Clean up old active optimizations
                cutoff_time = datetime.now() - timedelta(hours=1)
                old_keys = [
                    key for key, opt in self.active_optimizations.items()
                    if opt.timestamp and opt.timestamp < cutoff_time
                ]
                for key in old_keys:
                    del self.active_optimizations[key]
                
                await asyncio.sleep(60)  # Check every minute
                
            except Exception as e:
                self.logger.error(f"System monitoring error: {e}")
                await asyncio.sleep(60)
    
    async def _check_system_health(self):
        """Sistem sağlığını kontrol et"""
        
        health_status = {
            'timestamp': datetime.now(),
            'system_status': self.system_status,
            'components': {},
            'overall_health': 'healthy'
        }
        
        # Check component health
        component_checks = [
            ('price_aggregator', self._check_price_aggregator_health),
            ('constraint_manager', self._check_constraint_manager_health),
            ('rate_limiter', self._check_rate_limiter_health)
        ]
        
        for component_name, check_func in component_checks:
            try:
                health_status['components'][component_name] = check_func()
            except Exception as e:
                health_status['components'][component_name] = {'status': 'error', 'error': str(e)}
                health_status['overall_health'] = 'unhealthy'
        
        # Log health status if unhealthy
        if health_status['overall_health'] != 'healthy':
            self.logger.warning(f"System health issue detected: {health_status}")
    
    def _check_price_aggregator_health(self) -> Dict:
        """Price aggregator sağlık kontrolü"""
        
        # Check if we're getting recent price data
        recent_data = False
        for venue_data in self.price_aggregator.price_cache.values():
            if venue_data:
                # Check if data is recent (within 5 minutes)
                latest_timestamp = max(
                    (getattr(data, 'timestamp', datetime.now()) 
                     for data in venue_data.values()),
                    default=datetime.now()
                )
                if datetime.now() - latest_timestamp < timedelta(minutes=5):
                    recent_data = True
                    break
        
        return {
            'status': 'healthy' if recent_data else 'warning',
            'data_freshness': recent_data,
            'venue_count': len(self.price_aggregator.price_cache)
        }
    
    def _check_constraint_manager_health(self) -> Dict:
        """Constraint manager sağlık kontrolü"""
        
        # Check for critical violations
        constraint_report = self.constraint_manager.get_constraint_report()
        critical_violations = constraint_report['summary'].get('critical_violations', 0)
        active_circuit_breakers = len(constraint_report['circuit_breakers'])
        
        status = 'healthy'
        if critical_violations > 0 or active_circuit_breakers > 0:
            status = 'warning'
        
        return {
            'status': status,
            'critical_violations': critical_violations,
            'circuit_breakers': active_circuit_breakers,
            'active_venues': constraint_report['summary'].get('active_venues', 0)
        }
    
    def _check_rate_limiter_health(self) -> Dict:
        """Rate limiter sağlık kontrolü"""
        
        metrics = self.rate_limiter.get_performance_metrics()
        throttled_venues = metrics.get('total_throttled', 0)
        
        status = 'healthy'
        if throttled_venues > 0:
            status = 'warning'
        
        return {
            'status': status,
            'throttled_venues': throttled_venues,
            'pending_requests': metrics.get('pending_requests', 0),
            'active_venues': metrics.get('active_venues', 0)
        }
    
    async def _cleanup_loop(self):
        """Cleanup döngüsü"""
        while True:
            try:
                # Cleanup old performance data
                cutoff_time = datetime.now() - timedelta(days=7)
                self.optimization_history = [
                    record for record in self.optimization_history
                    if record['timestamp'] > cutoff_time
                ]
                
                # Reset rate limits for venues that haven't been used recently
                inactive_venues = [
                    venue for venue in self.config.VENUES.keys()
                    if venue not in self.rate_limiter.concurrent_requests or
                    self.rate_limiter.concurrent_requests[venue] == 0
                ]
                
                for venue in inactive_venues:
                    if len(self.optimization_history) > 0:
                        last_use = max(
                            record['timestamp'] for record in self.optimization_history
                        )
                        if datetime.now() - last_use > timedelta(hours=1):
                            self.rate_limiter.reset_rate_limits(venue)
                
                await asyncio.sleep(3600)  # Cleanup every hour
                
            except Exception as e:
                self.logger.error(f"Cleanup error: {e}")
                await asyncio.sleep(3600)
    
    def get_system_status(self) -> Dict:
        """Sistem durumu"""
        
        return {
            'status': self.system_status,
            'uptime': datetime.now() - getattr(self, 'start_time', datetime.now()),
            'active_optimizations': len(self.active_optimizations),
            'performance_metrics': self.performance_metrics,
            'component_status': {
                'price_aggregator': 'active',
                'constraint_manager': 'active',
                'rate_limiter': 'active',
                'latency_manager': 'active',
                'cost_optimizer': 'active',
                'liquidity_router': 'active'
            }
        }
    
    def export_performance_report(self, days: int = 30) -> Dict:
        """Performance raporu dışa aktar"""
        
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_history = [
            record for record in self.optimization_history
            if record['timestamp'] > cutoff_date
        ]
        
        if not recent_history:
            return {'message': 'No performance data available for the specified period'}
        
        # Calculate summary statistics
        successful_requests = [r for r in recent_history if r['success']]
        
        report = {
            'period_days': days,
            'total_requests': len(recent_history),
            'successful_requests': len(successful_requests),
            'success_rate': len(successful_requests) / len(recent_history),
            'average_metrics': {
                'slippage': np.mean([r['estimated_slippage'] for r in recent_history if r['estimated_slippage']]) if recent_history else 0,
                'quantity': np.mean([r['quantity'] for r in recent_history])
            },
            'symbol_breakdown': {},
            'trend_analysis': {}
        }
        
        # Symbol breakdown
        symbol_stats = {}
        for record in recent_history:
            symbol = record['symbol']
            if symbol not in symbol_stats:
                symbol_stats[symbol] = {'count': 0, 'success_rate': 0, 'avg_slippage': 0}
            
            symbol_stats[symbol]['count'] += 1
            if record['success']:
                symbol_stats[symbol]['success_rate'] += 1
        
        # Calculate success rates
        for symbol, stats in symbol_stats.items():
            stats['success_rate'] = stats['success_rate'] / stats['count']
        
        report['symbol_breakdown'] = symbol_stats
        
        return report