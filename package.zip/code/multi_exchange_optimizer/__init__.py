"""
Multi-Exchange Optimizer
Farklı borsalardan en iyi fiyat ve likiditeyi bulan kapsamlı optimizasyon sistemi

Bu modül aşağıdaki bileşenleri içerir:
- Real-time price aggregation
- Liquidity-weighted routing
- Execution cost minimization
- Venue-specific constraints
- API rate limiting management
- Latency-based routing decisions
- Volume-weighted average price (VWAP) calculation
- Time-weighted average price (TWAP) optimization
- Cross-venue transaction cost analysis
- Slippage prediction models
"""

__version__ = "1.0.0"
__author__ = "Multi-Exchange Optimizer Team"
__description__ = "Multi-exchange trading optimization system"

# Import main classes
from .config import ExchangeConfig, VenueConfig, OptimizationConfig, VenueType
from .multi_exchange_optimizer import MultiExchangeOptimizer, OptimizationRequest, OptimizationResponse
from .price_aggregator import PriceAggregator, PriceData, AggregatedPrice
from .liquidity_router import LiquidityRouter, Route, RoutingResult
from .cost_optimizer import CostOptimizer, CostBreakdown, OptimizationResult
from .venue_constraints import VenueConstraintManager, VenueConstraint, ConstraintViolation
from .rate_limiter import AdvancedRateLimiter, RateLimitRule, APIRequest, RateLimitStatus
from .latency_manager import LatencyManager, LatencyMetrics, LatencyProfile, LatencyRoutingDecision
from .vwap_calculator import VWAPCalculator, TradeData, VWAPResult, VolumeAnalysis
from .twap_optimizer import TWAPOptimizer, TWAPSlice, TWAPExecutionPlan, TWAPPerformance
from .cross_venue_analyzer import CrossVenueAnalyzer, TransactionCost, CrossVenueComparison, CostOptimizationResult
from .slippage_predictor import SlippagePredictor, SlippagePrediction, MarketCondition

# Import utility classes
from . import utils

# Define what gets imported with "from module import *"
__all__ = [
    # Main classes
    'MultiExchangeOptimizer',
    'OptimizationRequest', 
    'OptimizationResponse',
    'ExchangeConfig',
    
    # Core components
    'PriceAggregator',
    'LiquidityRouter',
    'CostOptimizer',
    'VenueConstraintManager',
    'AdvancedRateLimiter',
    'LatencyManager',
    'VWAPCalculator',
    'TWAPOptimizer',
    'CrossVenueAnalyzer',
    'SlippagePredictor',
    
    # Configuration
    'VenueConfig',
    'OptimizationConfig',
    'VenueType',
    
    # Data structures
    'PriceData',
    'AggregatedPrice',
    'Route',
    'RoutingResult',
    'CostBreakdown',
    'OptimizationResult',
    'VenueConstraint',
    'ConstraintViolation',
    'RateLimitRule',
    'APIRequest',
    'RateLimitStatus',
    'LatencyMetrics',
    'LatencyProfile',
    'LatencyRoutingDecision',
    'TradeData',
    'VWAPResult',
    'VolumeAnalysis',
    'TWAPSlice',
    'TWAPExecutionPlan',
    'TWAPPerformance',
    'TransactionCost',
    'CrossVenueComparison',
    'CostOptimizationResult',
    'SlippagePrediction',
    'MarketCondition',
    
    # Utilities
    'utils'
]

def create_optimizer(config_path: str = None, config_dict: dict = None):
    """
    Create and configure a MultiExchangeOptimizer instance
    
    Args:
        config_path: Path to configuration file
        config_dict: Configuration dictionary
    
    Returns:
        MultiExchangeOptimizer: Configured optimizer instance
    """
    # Create configuration
    if config_dict:
        config = ExchangeConfig()
        # Apply config_dict to config object
        for key, value in config_dict.items():
            if hasattr(config, key):
                setattr(config, key, value)
    else:
        config = ExchangeConfig()
    
    # Create optimizer
    optimizer = MultiExchangeOptimizer(config)
    
    return optimizer

def quick_optimize(symbol: str, quantity: float, side: str = 'buy', 
                  urgency: str = 'normal', **kwargs):
    """
    Quick optimization function for simple trading scenarios
    
    Args:
        symbol: Trading symbol (e.g., 'BTC-USD')
        quantity: Trade quantity
        side: 'buy' or 'sell'
        urgency: 'low', 'normal', 'high', 'critical'
        **kwargs: Additional optimization parameters
    
    Returns:
        OptimizationResponse: Optimization results
    """
    # Create optimizer
    optimizer = create_optimizer()
    
    # Create request
    request = OptimizationRequest(
        symbol=symbol,
        quantity=quantity,
        side=side,
        urgency=urgency,
        **kwargs
    )
    
    # Run optimization (synchronous version)
    import asyncio
    
    async def run_optimization():
        return await optimizer.optimize_trade(request)
    
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # If event loop is running, create new task
            return loop.create_task(run_optimization())
        else:
            return loop.run_until_complete(run_optimization())
    except RuntimeError:
        # No event loop, create one
        return asyncio.run(run_optimization())

def get_supported_exchanges():
    """
    Get list of supported exchanges
    
    Returns:
        list: Supported exchange names
    """
    return ['binance', 'coinbase', 'kraken', 'uniswap_v3', '1inch']

def get_supported_symbols():
    """
    Get list of supported trading symbols
    
    Returns:
        list: Supported symbol names
    """
    return ['BTC-USD', 'ETH-USD']

def validate_symbol(symbol: str):
    """
    Validate if a trading symbol is supported
    
    Args:
        symbol: Symbol to validate
    
    Returns:
        bool: True if symbol is supported
    """
    return symbol in get_supported_symbols()

def estimate_execution_cost(symbol: str, quantity: float, venue: str = None):
    """
    Estimate execution cost for a trade
    
    Args:
        symbol: Trading symbol
        quantity: Trade quantity
        venue: Specific venue (None for best venue)
    
    Returns:
        dict: Cost estimation
    """
    optimizer = create_optimizer()
    
    # This would be implemented with actual cost estimation logic
    # For now, return a simple estimate
    base_cost = 0.001  # 0.1% base cost
    
    if venue:
        # Venue-specific adjustments would go here
        pass
    
    return {
        'estimated_cost': base_cost,
        'estimated_slippage': base_cost * 0.5,
        'total_estimated_cost': quantity * base_cost * (1 + 0.5)
    }

def benchmark_optimization():
    """
    Run optimization benchmark
    
    Returns:
        dict: Benchmark results
    """
    import time
    import statistics
    
    results = []
    symbols = get_supported_symbols()
    
    for symbol in symbols:
        for i in range(10):  # 10 iterations
            start_time = time.time()
            result = quick_optimize(symbol, 1000, 'buy', 'normal')
            end_time = time.time()
            
            results.append({
                'symbol': symbol,
                'execution_time': end_time - start_time,
                'success': result.success if hasattr(result, 'success') else True
            })
    
    # Calculate statistics
    execution_times = [r['execution_time'] for r in results]
    success_rate = statistics.mean([r['success'] for r in results])
    
    return {
        'total_tests': len(results),
        'success_rate': success_rate,
        'avg_execution_time': statistics.mean(execution_times),
        'median_execution_time': statistics.median(execution_times),
        'min_execution_time': min(execution_times),
        'max_execution_time': max(execution_times),
        'std_execution_time': statistics.stdev(execution_times)
    }