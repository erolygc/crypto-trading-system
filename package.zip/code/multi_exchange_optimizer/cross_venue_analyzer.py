"""
Cross-Venue Transaction Cost Analyzer
Borsalar arası transaction maliyet analizi
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging
from collections import defaultdict, deque
from config import ExchangeConfig

@dataclass
class TransactionCost:
    """Transaction maliyet yapısı"""
    venue: str
    explicit_cost: float
    implicit_cost: float
    total_cost: float
    cost_breakdown: Dict[str, float]
    execution_time: float
    reliability_score: float

@dataclass
class CrossVenueComparison:
    """Borsalar arası karşılaştırma"""
    symbol: str
    comparisons: Dict[str, TransactionCost]
    best_venue: str
    cost_spread: float
    execution_time_spread: float
    recommendations: List[str]

@dataclass
class CostOptimizationResult:
    """Cost optimizasyon sonucu"""
    original_venue: str
    optimized_venue: str
    potential_savings: float
    savings_percentage: float
    trade_size_threshold: float
    optimization_parameters: Dict[str, float]

class CrossVenueAnalyzer:
    """Cross-venue transaction cost analyzer"""
    
    def __init__(self, config: ExchangeConfig, price_aggregator):
        self.config = config
        self.price_aggregator = price_aggregator
        self.logger = logging.getLogger(__name__)
        
        # Cost data storage
        self.cost_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=1000))
        self.venue_cost_profiles: Dict[str, Dict] = {}
        self.execution_metrics: Dict[str, Dict] = {}
        
        # Analysis parameters
        self.cost_components = {
            'trading_fee': 1.0,
            'spread_cost': 1.0,
            'slippage_cost': 1.5,
            'latency_cost': 0.5,
            'market_impact': 2.0,
            'regulatory_cost': 1.0,
            'operational_cost': 0.3
        }
        
        # Initialize venue profiles
        self._initialize_venue_profiles()
    
    def _initialize_venue_profiles(self):
        """Venue cost profillerini başlat"""
        for venue_name, venue_config in self.config.VENUES.items():
            if not venue_config.enabled:
                continue
            
            self.venue_cost_profiles[venue_name] = {
                'base_trading_fee': venue_config.fee_taker,
                'avg_spread_bps': self._estimate_average_spread(venue_name),
                'latency_profile': self._get_latency_profile(venue_name),
                'liquidity_profile': self._estimate_liquidity_profile(venue_name),
                'reliability_score': self._calculate_reliability_score(venue_name),
                'operational_overhead': self._estimate_operational_overhead(venue_name),
                'regulatory_constraints': self._get_regulatory_constraints(venue_name),
                'last_updated': datetime.now()
            }
    
    def _estimate_average_spread(self, venue_name: str) -> float:
        """Ortalama spread tahmini"""
        # Venue-specific spread estimates
        spread_estimates = {
            'binance': 1.5,    # 1.5 bps
            'coinbase': 3.0,   # 3.0 bps
            'kraken': 2.5,     # 2.5 bps
            'uniswap_v3': 10.0, # 10.0 bps (DEX)
            '1inch': 2.0       # 2.0 bps (aggregator)
        }
        
        return spread_estimates.get(venue_name, 3.0)
    
    def _get_latency_profile(self, venue_name: str) -> Dict:
        """Latency profili al"""
        venue_config = self.config.VENUES[venue_name]
        
        return {
            'average_latency': venue_config.latency_threshold * 0.8,
            'p95_latency': venue_config.latency_threshold,
            'p99_latency': venue_config.latency_threshold * 1.2,
            'latency_volatility': venue_config.latency_threshold * 0.3
        }
    
    def _estimate_liquidity_profile(self, venue_name: str) -> Dict:
        """Likidite profili tahmini"""
        venue_config = self.config.VENUES[venue_name]
        
        # Venue-specific liquidity estimates
        liquidity_estimates = {
            'binance': {'daily_volume': 1000000000, 'avg_trade_size': 10000},
            'coinbase': {'daily_volume': 500000000, 'avg_trade_size': 5000},
            'kraken': {'daily_volume': 200000000, 'avg_trade_size': 3000},
            'uniswap_v3': {'daily_volume': 50000000, 'avg_trade_size': 1000},
            '1inch': {'daily_volume': 800000000, 'avg_trade_size': 8000}
        }
        
        return liquidity_estimates.get(venue_name, {'daily_volume': 100000000, 'avg_trade_size': 1000})
    
    def _calculate_reliability_score(self, venue_name: str) -> float:
        """Güvenilirlik skoru hesapla"""
        venue_config = self.config.VENUES[venue_name]
        
        # Base reliability from venue type and priority
        base_reliability = 0.95 if venue_config.type.value == "cex" else 0.85
        
        # Adjust based on priority
        priority_factor = (6 - venue_config.priority) / 5
        reliability = base_reliability * priority_factor
        
        return min(0.99, max(0.70, reliability))
    
    def _estimate_operational_overhead(self, venue_name: str) -> float:
        """Operasyonel overhead tahmini"""
        overhead_estimates = {
            'binance': 0.0001,   # 1 bps
            'coinbase': 0.0002,  # 2 bps
            'kraken': 0.00015,   # 1.5 bps
            'uniswap_v3': 0.0005, # 5 bps (DEX complexity)
            '1inch': 0.0001      # 1 bps
        }
        
        return overhead_estimates.get(venue_name, 0.0002)
    
    def _get_regulatory_constraints(self, venue_name: str) -> Dict:
        """Regulatory kısıtlamalar"""
        constraints = {
            'binance': {'jurisdictions': 'global', 'restrictions': []},
            'coinbase': {'jurisdictions': 'US_focused', 'restrictions': ['US_only']},
            'kraken': {'jurisdictions': 'global', 'restrictions': ['US_limited']},
            'uniswap_v3': {'jurisdictions': 'defi', 'restrictions': ['jurisdictionless']},
            '1inch': {'jurisdictions': 'aggregator', 'restrictions': []}
        }
        
        return constraints.get(venue_name, {'jurisdictions': 'unknown', 'restrictions': []})
    
    def analyze_transaction_costs(self, symbol: str, trade_size: float, 
                                side: str = 'buy') -> CrossVenueComparison:
        """Transaction maliyet analizi"""
        
        comparisons = {}
        venue_results = []
        
        # Get market data
        market_data = self._get_market_data_for_analysis(symbol)
        
        # Analyze each venue
        for venue_name, venue_config in self.config.VENUES.items():
            if not venue_config.enabled:
                continue
            
            # Skip if no market data
            if venue_name not in market_data:
                continue
            
            cost_analysis = self._analyze_venue_cost(
                venue_name, market_data[venue_name], trade_size, side
            )
            
            if cost_analysis:
                comparisons[venue_name] = cost_analysis
                venue_results.append((venue_name, cost_analysis.total_cost))
        
        # Find best venue
        best_venue = min(venue_results, key=lambda x: x[1])[0] if venue_results else None
        
        # Calculate spreads
        costs = [cost.total_cost for cost in comparisons.values()]
        cost_spread = max(costs) - min(costs) if costs else 0
        
        execution_times = [cost.execution_time for cost in comparisons.values()]
        execution_time_spread = max(execution_times) - min(execution_times) if execution_times else 0
        
        # Generate recommendations
        recommendations = self._generate_cost_recommendations(comparisons, trade_size)
        
        return CrossVenueComparison(
            symbol=symbol,
            comparisons=comparisons,
            best_venue=best_venue,
            cost_spread=cost_spread,
            execution_time_spread=execution_time_spread,
            recommendations=recommendations
        )
    
    def _get_market_data_for_analysis(self, symbol: str) -> Dict:
        """Analiz için market data al"""
        market_data = {}
        
        # Get data from price aggregator
        for venue_name, venue_data in self.price_aggregator.price_cache.items():
            if symbol in venue_data:
                market_data[venue_name] = venue_data[symbol]
        
        return market_data
    
    def _analyze_venue_cost(self, venue_name: str, price_data, 
                          trade_size: float, side: str) -> Optional[TransactionCost]:
        """Venue-specific cost analizi"""
        
        venue_config = self.config.VENUES[venue_name]
        cost_profile = self.venue_cost_profiles[venue_name]
        
        # Explicit costs
        trading_fee = venue_config.fee_taker  # 0.15%
        
        # Spread cost
        spread = price_data.ask - price_data.bid if side == 'buy' else price_data.bid - price_data.ask
        spread_cost = spread / price_data.price
        
        # Slippage cost (estimated based on trade size and liquidity)
        slippage_cost = self._estimate_slippage_cost(venue_name, trade_size, price_data)
        
        # Latency cost
        latency_cost = self._calculate_latency_cost(venue_name, trade_size)
        
        # Market impact cost
        market_impact = self._estimate_market_impact(venue_name, trade_size)
        
        # Regulatory cost
        regulatory_cost = self._estimate_regulatory_cost(venue_name, trade_size)
        
        # Operational overhead
        operational_cost = cost_profile['operational_overhead']
        
        # Calculate total costs
        explicit_cost = trading_fee + spread_cost
        implicit_cost = slippage_cost + latency_cost + market_impact + regulatory_cost + operational_cost
        total_cost = explicit_cost + implicit_cost
        
        # Cost breakdown
        cost_breakdown = {
            'trading_fee': trading_fee,
            'spread_cost': spread_cost,
            'slippage_cost': slippage_cost,
            'latency_cost': latency_cost,
            'market_impact': market_impact,
            'regulatory_cost': regulatory_cost,
            'operational_cost': operational_cost
        }
        
        # Execution time
        execution_time = cost_profile['latency_profile']['average_latency'] / 1000  # Convert to seconds
        
        # Reliability score
        reliability_score = cost_profile['reliability_score']
        
        return TransactionCost(
            venue=venue_name,
            explicit_cost=explicit_cost,
            implicit_cost=implicit_cost,
            total_cost=total_cost,
            cost_breakdown=cost_breakdown,
            execution_time=execution_time,
            reliability_score=reliability_score
        )
    
    def _estimate_slippage_cost(self, venue_name: str, trade_size: float, price_data) -> float:
        """Slippage maliyeti tahmini"""
        
        # Get venue liquidity profile
        liquidity_profile = self.venue_cost_profiles[venue_name]['liquidity_profile']
        daily_volume = liquidity_profile['daily_volume']
        avg_trade_size = liquidity_profile['avg_trade_size']
        
        # Calculate trade size relative to daily volume and typical trades
        volume_ratio = trade_size / daily_volume if daily_volume > 0 else 1
        size_ratio = trade_size / avg_trade_size if avg_trade_size > 0 else 1
        
        # Slippage model: increases with trade size relative to market
        base_slippage = 0.0001  # 1 bps base
        slippage_multiplier = 1 + (volume_ratio * 10) + (size_ratio * 2)
        
        # Venue-specific adjustments
        venue_adjustments = {
            'binance': 1.0,      # Best liquidity
            'coinbase': 1.2,     # Good liquidity
            'kraken': 1.3,       # Moderate liquidity
            'uniswap_v3': 2.0,   # DEX - higher slippage
            '1inch': 0.9         # Aggregator - optimized routing
        }
        
        adjustment = venue_adjustments.get(venue_name, 1.0)
        
        return base_slippage * slippage_multiplier * adjustment
    
    def _calculate_latency_cost(self, venue_name: str, trade_size: float) -> float:
        """Latency maliyeti hesapla"""
        
        latency_profile = self.venue_cost_profiles[venue_name]['latency_profile']
        avg_latency = latency_profile['average_latency']
        
        # Latency cost model: time-sensitive orders have higher latency cost
        # Convert latency to cost (simple model)
        latency_cost_per_ms = 0.000001  # 0.1 bps per millisecond
        
        return avg_latency * latency_cost_per_ms
    
    def _estimate_market_impact(self, venue_name: str, trade_size: float) -> float:
        """Market impact tahmini"""
        
        liquidity_profile = self.venue_cost_profiles[venue_name]['liquidity_profile']
        daily_volume = liquidity_profile['daily_volume']
        
        # Square root impact model
        volume_ratio = trade_size / daily_volume if daily_volume > 0 else 1
        impact_coefficient = 0.001  # 1 bps base impact
        
        return impact_coefficient * np.sqrt(volume_ratio)
    
    def _estimate_regulatory_cost(self, venue_name: str, trade_size: float) -> float:
        """Regulatory maliyet tahmini"""
        
        constraints = self.venue_cost_profiles[venue_name]['regulatory_constraints']
        
        # Base regulatory cost
        base_cost = 0.0001  # 1 bps
        
        # Add costs based on restrictions
        if 'US_only' in constraints['restrictions']:
            base_cost *= 1.5  # US restrictions increase cost
        elif 'US_limited' in constraints['restrictions']:
            base_cost *= 1.2
        
        return base_cost
    
    def _generate_cost_recommendations(self, comparisons: Dict[str, TransactionCost], 
                                     trade_size: float) -> List[str]:
        """Cost önerileri oluştur"""
        
        recommendations = []
        
        if not comparisons:
            return ["No venues available for analysis"]
        
        # Find best and worst venues
        sorted_venues = sorted(comparisons.items(), key=lambda x: x[1].total_cost)
        best_venue, best_cost = sorted_venues[0]
        worst_venue, worst_cost = sorted_venues[-1]
        
        # Cost savings recommendation
        savings = worst_cost.total_cost - best_cost.total_cost
        savings_percentage = (savings / worst_cost.total_cost) * 100 if worst_cost.total_cost > 0 else 0
        
        recommendations.append(
            f"Switching from {worst_venue} to {best_venue} could save {savings_percentage:.2f}%"
        )
        
        # Trade size recommendations
        if trade_size > 100000:  # Large trade
            recommendations.append("Consider splitting large trade across multiple venues")
        
        # Venue-specific recommendations
        for venue_name, cost in comparisons.items():
            if cost.total_cost > best_cost.total_cost * 1.5:
                recommendations.append(f"High costs detected at {venue_name} - avoid for normal trades")
            
            if cost.reliability_score < 0.8:
                recommendations.append(f"Low reliability at {venue_name} - use only for small trades")
        
        # Time-based recommendations
        if hasattr(self, 'price_aggregator'):
            # Check for optimal trading times
            recommendations.append("Consider trading during high-liquidity hours for better prices")
        
        return recommendations
    
    def find_cost_optimization_opportunities(self, historical_trades: pd.DataFrame) -> List[CostOptimizationResult]:
        """Cost optimizasyon fırsatları bul"""
        
        opportunities = []
        
        if historical_trades.empty:
            return opportunities
        
        # Group by venue and calculate average costs
        venue_stats = historical_trades.groupby('venue').agg({
            'total_cost': ['mean', 'std', 'count'],
            'trade_size': 'mean',
            'slippage': 'mean'
        }).round(6)
        
        # Compare venues to find optimization opportunities
        venues = list(venue_stats.index)
        
        for i, venue1 in enumerate(venues):
            for venue2 in venues[i+1:]:
                
                cost1 = venue_stats.loc[venue1, ('total_cost', 'mean')]
                cost2 = venue_stats.loc[venue2, ('total_cost', 'mean')]
                
                if cost1 > cost2:
                    # Venue1 has higher costs than venue2
                    potential_savings = cost1 - cost2
                    savings_percentage = (potential_savings / cost1) * 100 if cost1 > 0 else 0
                    
                    if savings_percentage > 5:  # Only consider if savings > 5%
                        
                        # Find optimal trade size threshold
                        threshold = self._calculate_trade_size_threshold(
                            venue1, venue2, venue_stats
                        )
                        
                        opportunities.append(CostOptimizationResult(
                            original_venue=venue1,
                            optimized_venue=venue2,
                            potential_savings=potential_savings,
                            savings_percentage=savings_percentage,
                            trade_size_threshold=threshold,
                            optimization_parameters={
                                'venue1_avg_cost': cost1,
                                'venue2_avg_cost': cost2,
                                'savings_per_trade': potential_savings
                            }
                        ))
        
        # Sort by savings percentage
        opportunities.sort(key=lambda x: x.savings_percentage, reverse=True)
        
        return opportunities
    
    def _calculate_trade_size_threshold(self, venue1: str, venue2: str, 
                                      venue_stats: pd.DataFrame) -> float:
        """Trade size threshold hesapla"""
        
        # Get average trade sizes
        avg_size1 = venue_stats.loc[venue1, ('trade_size', 'mean')]
        avg_size2 = venue_stats.loc[venue2, ('trade_size', 'mean')]
        
        # Simple threshold: trade sizes between the two averages
        threshold = (avg_size1 + avg_size2) / 2
        
        return threshold
    
    def calculate_cross_venue_arbitrage_opportunities(self, symbol: str) -> Dict:
        """Cross-venue arbitraj fırsatları"""
        
        opportunities = []
        market_data = self._get_market_data_for_analysis(symbol)
        
        if len(market_data) < 2:
            return {'message': 'Insufficient venues for arbitrage analysis'}
        
        # Get prices from different venues
        prices = {}
        for venue_name, price_data in market_data.items():
            prices[venue_name] = {
                'bid': price_data.bid,
                'ask': price_data.ask,
                'mid': (price_data.bid + price_data.ask) / 2
            }
        
        # Find arbitrage opportunities
        venues = list(prices.keys())
        for i, venue1 in enumerate(venues):
            for venue2 in venues[i+1:]:
                
                price1 = prices[venue1]
                price2 = prices[venue2]
                
                # Buy low, sell high opportunities
                if price1['ask'] < price2['bid']:
                    spread = price2['bid'] - price1['ask']
                    spread_percentage = (spread / price1['ask']) * 100
                    
                    if spread_percentage > 0.1:  # Only consider if spread > 0.1%
                        opportunities.append({
                            'type': 'buy_low_sell_high',
                            'buy_venue': venue1,
                            'sell_venue': venue2,
                            'buy_price': price1['ask'],
                            'sell_price': price2['bid'],
                            'spread': spread,
                            'spread_percentage': spread_percentage,
                            'potential_profit_per_unit': spread
                        })
                
                # Reverse opportunity
                if price2['ask'] < price1['bid']:
                    spread = price1['bid'] - price2['ask']
                    spread_percentage = (spread / price2['ask']) * 100
                    
                    if spread_percentage > 0.1:
                        opportunities.append({
                            'type': 'buy_low_sell_high',
                            'buy_venue': venue2,
                            'sell_venue': venue1,
                            'buy_price': price2['ask'],
                            'sell_price': price1['bid'],
                            'spread': spread,
                            'spread_percentage': spread_percentage,
                            'potential_profit_per_unit': spread
                        })
        
        # Calculate net opportunity value (considering costs)
        net_opportunities = []
        for opp in opportunities:
            # Subtract estimated transaction costs
            buy_cost = self._estimate_total_cost(opp['buy_venue'], 1.0)
            sell_cost = self._estimate_total_cost(opp['sell_venue'], 1.0)
            
            total_cost = buy_cost + sell_cost
            net_profit = opp['potential_profit_per_unit'] - total_cost
            
            if net_profit > 0:
                opp['net_profit_per_unit'] = net_profit
                opp['net_spread_percentage'] = (net_profit / opp['buy_price']) * 100
                net_opportunities.append(opp)
        
        # Sort by net profit
        net_opportunities.sort(key=lambda x: x['net_profit_per_unit'], reverse=True)
        
        return {
            'symbol': symbol,
            'total_opportunities': len(net_opportunities),
            'best_opportunity': net_opportunities[0] if net_opportunities else None,
            'opportunities': net_opportunities[:5],  # Top 5 opportunities
            'analysis_timestamp': datetime.now()
        }
    
    def _estimate_total_cost(self, venue_name: str, trade_size: float) -> float:
        """Toplam maliyet tahmini"""
        
        if venue_name not in self.venue_cost_profiles:
            return 0.01  # Default 1%
        
        profile = self.venue_cost_profiles[venue_name]
        
        # Simple cost estimation
        fee = profile['base_trading_fee']
        overhead = profile['operational_overhead']
        
        return fee + overhead
    
    def generate_cost_analysis_report(self, symbol: str, trade_size: float) -> Dict:
        """Cost analysis raporu oluştur"""
        
        # Main cost comparison
        comparison = self.analyze_transaction_costs(symbol, trade_size)
        
        # Historical cost data
        historical_data = self._get_historical_cost_data(symbol, days=30)
        
        # Optimization opportunities
        optimization_opps = []
        if not historical_data.empty:
            optimization_opps = self.find_cost_optimization_opportunities(historical_data)
        
        # Arbitrage opportunities
        arbitrage_opps = self.calculate_cross_venue_arbitrage_opportunities(symbol)
        
        # Venue ranking
        venue_ranking = self._rank_venues_by_cost(symbol, trade_size)
        
        report = {
            'timestamp': datetime.now(),
            'symbol': symbol,
            'trade_size': trade_size,
            'cost_comparison': {
                'best_venue': comparison.best_venue,
                'cost_spread': comparison.cost_spread,
                'venue_details': {
                    venue: {
                        'total_cost': cost.total_cost,
                        'explicit_cost': cost.explicit_cost,
                        'implicit_cost': cost.implicit_cost,
                        'execution_time': cost.execution_time,
                        'reliability_score': cost.reliability_score,
                        'cost_breakdown': cost.cost_breakdown
                    }
                    for venue, cost in comparison.comparisons.items()
                }
            },
            'recommendations': comparison.recommendations,
            'optimization_opportunities': [
                {
                    'original_venue': opp.original_venue,
                    'optimized_venue': opp.optimized_venue,
                    'savings_percentage': opp.savings_percentage,
                    'trade_size_threshold': opp.trade_size_threshold
                }
                for opp in optimization_opps[:5]
            ],
            'arbitrage_opportunities': arbitrage_opps,
            'venue_ranking': venue_ranking,
            'market_conditions': self._assess_market_conditions(symbol)
        }
        
        return report
    
    def _get_historical_cost_data(self, symbol: str, days: int = 30) -> pd.DataFrame:
        """Historical cost data al"""
        
        # In a real implementation, this would fetch from a database
        # For now, return empty DataFrame
        return pd.DataFrame()
    
    def _rank_venues_by_cost(self, symbol: str, trade_size: float) -> List[Dict]:
        """Venue'ları cost'a göre sırala"""
        
        comparison = self.analyze_transaction_costs(symbol, trade_size)
        
        rankings = []
        for venue, cost in comparison.comparisons.items():
            rankings.append({
                'venue': venue,
                'rank': 0,  # Will be set after sorting
                'total_cost': cost.total_cost,
                'cost_per_bps': cost.total_cost * 10000,  # Convert to bps
                'execution_time': cost.execution_time,
                'reliability': cost.reliability_score
            })
        
        # Sort by total cost
        rankings.sort(key=lambda x: x['total_cost'])
        
        # Assign ranks
        for i, ranking in enumerate(rankings):
            ranking['rank'] = i + 1
        
        return rankings
    
    def _assess_market_conditions(self, symbol: str) -> Dict:
        """Market koşullarını değerlendir"""
        
        market_data = self._get_market_data_for_analysis(symbol)
        
        if not market_data:
            return {'status': 'insufficient_data'}
        
        # Calculate market metrics
        spreads = []
        volumes = []
        latencies = []
        
        for venue_name, price_data in market_data.items():
            spread = (price_data.ask - price_data.bid) / price_data.price
            spreads.append(spread)
            volumes.append(price_data.volume_24h)
            latencies.append(getattr(price_data, 'latency', 100))
        
        # Assess conditions
        avg_spread = np.mean(spreads) if spreads else 0
        total_volume = sum(volumes) if volumes else 0
        avg_latency = np.mean(latencies) if latencies else 100
        
        conditions = {
            'spread_tightness': 'tight' if avg_spread < 0.001 else 'normal' if avg_spread < 0.002 else 'wide',
            'liquidity_level': 'high' if total_volume > 1000000 else 'medium' if total_volume > 100000 else 'low',
            'execution_speed': 'fast' if avg_latency < 50 else 'normal' if avg_latency < 100 else 'slow',
            'avg_spread_bps': avg_spread * 10000,
            'total_volume_24h': total_volume,
            'avg_latency_ms': avg_latency
        }
        
        return conditions