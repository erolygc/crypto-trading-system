"""
Multi-Exchange Optimizer Configuration
Farklı borsalar için ayarlar ve parametreler
"""

import numpy as np
from dataclasses import dataclass
from typing import Dict, List, Optional
from enum import Enum

class VenueType(Enum):
    CEX = "cex"  # Centralized Exchange
    DEX = "dex"  # Decentralized Exchange
    AGGREGATOR = "aggregator"

@dataclass
class VenueConfig:
    """Borsa yapılandırması"""
    name: str
    type: VenueType
    base_url: str
    api_key: Optional[str] = None
    api_secret: Optional[str] = None
    rate_limit: int = 100  # requests per minute
    latency_threshold: float = 50.0  # milliseconds
    min_trade_size: float = 10.0
    max_trade_size: float = 1000000.0
    fee_maker: float = 0.001  # 0.1%
    fee_taker: float = 0.0015  # 0.15%
    priority: int = 1  # 1 = highest priority
    enabled: bool = True

@dataclass
class OptimizationConfig:
    """Optimizasyon parametreleri"""
    max_slippage: float = 0.005  # 0.5%
    target_latency: float = 100.0  # milliseconds
    max_execution_time: float = 30.0  # seconds
    rebalance_threshold: float = 0.01  # 1%
    risk_tolerance: float = 0.02  # 2%
    liquidity_weight_alpha: float = 0.3
    latency_weight_beta: float = 0.2
    cost_weight_gamma: float = 0.5
    twap_interval: int = 300  # 5 minutes
    vwap_window: int = 3600  # 1 hour
    slippage_lookback: int = 100  # trades to analyze

class ExchangeConfig:
    """Multi-exchange configuration"""
    
    # Ana borsalar ve yapılandırmaları
    VENUES: Dict[str, VenueConfig] = {
        'binance': VenueConfig(
            name='Binance',
            type=VenueType.CEX,
            base_url='https://api.binance.com',
            rate_limit=1200,
            latency_threshold=30.0,
            min_trade_size=10.0,
            fee_maker=0.001,
            fee_taker=0.001,
            priority=1
        ),
        'coinbase': VenueConfig(
            name='Coinbase Pro',
            type=VenueType.CEX,
            base_url='https://api.exchange.coinbase.com',
            rate_limit=300,
            latency_threshold=40.0,
            min_trade_size=1.0,
            fee_maker=0.005,
            fee_taker=0.005,
            priority=2
        ),
        'kraken': VenueConfig(
            name='Kraken',
            type=VenueType.CEX,
            base_url='https://api.kraken.com',
            rate_limit=200,
            latency_threshold=35.0,
            min_trade_size=1.0,
            fee_maker=0.0016,
            fee_taker=0.0026,
            priority=3
        ),
        'uniswap_v3': VenueConfig(
            name='Uniswap V3',
            type=VenueType.DEX,
            base_url='https://api.thegraph.com/subgraphs/name/uniswap/uniswap-v3',
            rate_limit=100,
            latency_threshold=200.0,
            min_trade_size=0.01,
            fee_maker=0.0005,
            fee_taker=0.0005,
            priority=4
        ),
        '1inch': VenueConfig(
            name='1inch Aggregator',
            type=VenueType.AGGREGATOR,
            base_url='https://api.1inch.io/v5.0',
            rate_limit=500,
            latency_threshold=80.0,
            min_trade_size=10.0,
            fee_maker=0.001,
            fee_taker=0.001,
            priority=2
        )
    }
    
    # Desteklenen trading çiftleri
    TRADING_PAIRS = {
        'BTC-USD': {
            'symbols': ['BTC/USDT', 'BTC/USD', 'BTC/USDC'],
            'tick_size': 0.01,
            'min_order_size': 0.0001,
            'price_precision': 8,
            'quantity_precision': 8
        },
        'ETH-USD': {
            'symbols': ['ETH/USDT', 'ETH/USD', 'ETH/USDC'],
            'tick_size': 0.01,
            'min_order_size': 0.001,
            'price_precision': 8,
            'quantity_precision': 6
        }
    }
    
    # Optimizasyon parametreleri
    OPTIMIZATION = OptimizationConfig(
        max_slippage=0.003,  # 0.3%
        target_latency=50.0,
        max_execution_time=15.0,
        rebalance_threshold=0.005,
        risk_tolerance=0.01,
        liquidity_weight_alpha=0.4,
        latency_weight_beta=0.3,
        cost_weight_gamma=0.3
    )
    
    # Risk parametreleri
    RISK_PARAMS = {
        'max_position_size': 0.1,  # Max 10% of portfolio per position
        'max_correlation': 0.7,    # Max correlation between positions
        'var_confidence': 0.95,    # VaR confidence level
        'var_window': 252          # VaR lookback period
    }
    
    # API timeouts ve retry ayarları
    API_SETTINGS = {
        'timeout': 10.0,
        'max_retries': 3,
        'retry_delay': 1.0,
        'concurrent_requests': 10
    }
    
    # Log ayarları
    LOGGING = {
        'level': 'INFO',
        'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        'file': 'logs/multi_exchange_optimizer.log'
    }