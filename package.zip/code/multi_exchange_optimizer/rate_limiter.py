"""
API Rate Limiter
Borsa API'leri için rate limiting yönetimi
"""

import asyncio
import time
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from collections import deque
import logging
from datetime import datetime, timedelta
from config import ExchangeConfig, VenueConfig

@dataclass
class RateLimitRule:
    """Rate limit kuralı"""
    venue: str
    endpoint: str
    limit: int
    window: timedelta
    burst_limit: Optional[int] = None
    current_count: int = 0
    window_start: Optional[datetime] = None
    burst_count: int = 0

@dataclass
class APIRequest:
    """API istek yapısı"""
    venue: str
    endpoint: str
    timestamp: datetime
    priority: int = 1  # 1 = highest, 5 = lowest
    timeout: float = 30.0
    retry_count: int = 0
    max_retries: int = 3

@dataclass
class RateLimitStatus:
    """Rate limit durumu"""
    venue: str
    endpoint: str
    current_usage: int
    limit: int
    usage_percentage: float
    window_remaining: timedelta
    can_proceed: bool
    estimated_wait_time: float

class AdvancedRateLimiter:
    """Gelişmiş API rate limiter"""
    
    def __init__(self, config: ExchangeConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Rate limit rules
        self.rate_limits: Dict[str, Dict[str, RateLimitRule]] = {}
        self._initialize_rate_limits()
        
        # Request tracking
        self.request_history: Dict[str, deque] = {}
        self.pending_requests: List[APIRequest] = []
        
        # Concurrency control
        self.concurrent_requests: Dict[str, int] = {}
        self.max_concurrent: Dict[str, int] = {}
        
        # Throttling state
        self.throttled_venues: Dict[str, datetime] = {}
        self.backoff_multipliers: Dict[str, float] = {}
        
    def _initialize_rate_limits(self):
        """Rate limit kurallarını başlat"""
        for venue_name, venue_config in self.config.VENUES.items():
            if not venue_config.enabled:
                continue
            
            self.rate_limits[venue_name] = {}
            self.concurrent_requests[venue_name] = 0
            self.max_concurrent[venue_name] = self.config.API_SETTINGS['concurrent_requests']
            self.backoff_multipliers[venue_name] = 1.0
            
            # Market data endpoints
            self.rate_limits[venue_name]['/api/v3/ticker/price'] = RateLimitRule(
                venue=venue_name,
                endpoint='/api/v3/ticker/price',
                limit=venue_config.rate_limit,
                window=timedelta(minutes=1),
                burst_limit=venue_config.rate_limit // 2
            )
            
            self.rate_limits[venue_name]['/api/v3/depth'] = RateLimitRule(
                venue=venue_name,
                endpoint='/api/v3/depth',
                limit=venue_config.rate_limit // 2,
                window=timedelta(minutes=1)
            )
            
            self.rate_limits[venue_name]['/api/v3/trades'] = RateLimitRule(
                venue=venue_name,
                endpoint='/api/v3/trades',
                limit=venue_config.rate_limit // 4,
                window=timedelta(minutes=1)
            )
            
            # Order management endpoints
            self.rate_limits[venue_name]['/api/v3/order'] = RateLimitRule(
                venue=venue_name,
                endpoint='/api/v3/order',
                limit=venue_config.rate_limit // 10,
                window=timedelta(minutes=1)
            )
            
            self.rate_limits[venue_name]['/api/v3/account'] = RateLimitRule(
                venue=venue_name,
                endpoint='/api/v3/account',
                limit=venue_config.rate_limit // 20,
                window=timedelta(minutes=1)
            )
            
            # Initialize request history
            self.request_history[venue_name] = deque(maxlen=1000)
    
    async def acquire(self, venue: str, endpoint: str, priority: int = 1, 
                     timeout: float = 30.0) -> bool:
        """API istek izni al"""
        
        if venue not in self.rate_limits or endpoint not in self.rate_limits[venue]:
            self.logger.warning(f"No rate limit defined for {venue}:{endpoint}")
            return True
        
        # Check if venue is throttled
        if venue in self.throttled_venues:
            throttle_end = self.throttled_venues[venue]
            if datetime.now() < throttle_end:
                wait_time = (throttle_end - datetime.now()).total_seconds()
                self.logger.info(f"Venue {venue} throttled, waiting {wait_time:.2f}s")
                await asyncio.sleep(wait_time)
            else:
                del self.throttled_venues[venue]
        
        # Check concurrency limits
        if self.concurrent_requests[venue] >= self.max_concurrent[venue]:
            wait_time = await self._wait_for_concurrency_slot(venue)
            if wait_time > timeout:
                self.logger.warning(f"Timeout waiting for concurrency slot at {venue}")
                return False
        
        # Check rate limits
        can_proceed, wait_time = await self._check_rate_limit(venue, endpoint)
        
        if not can_proceed:
            if wait_time > timeout:
                self.logger.warning(f"Timeout waiting for rate limit at {venue}:{endpoint}")
                return False
            
            self.logger.info(f"Rate limited at {venue}:{endpoint}, waiting {wait_time:.2f}s")
            await asyncio.sleep(wait_time)
            
            # Retry after waiting
            return await self.acquire(venue, endpoint, priority, timeout - wait_time)
        
        # Record the request
        self._record_request(venue, endpoint)
        self.concurrent_requests[venue] += 1
        
        return True
    
    async def _check_rate_limit(self, venue: str, endpoint: str) -> Tuple[bool, float]:
        """Rate limit kontrolü"""
        rule = self.rate_limits[venue][endpoint]
        now = datetime.now()
        
        # Reset window if needed
        if (rule.window_start is None or 
            now - rule.window_start >= rule.window):
            rule.window_start = now
            rule.current_count = 0
        
        # Check burst limit first
        if rule.burst_limit and rule.burst_count >= rule.burst_limit:
            # Burst limit exceeded, wait for burst window
            wait_time = self._calculate_wait_time(venue, endpoint)
            return False, wait_time
        
        # Check main limit
        if rule.current_count >= rule.limit:
            wait_time = self._calculate_wait_time(venue, endpoint)
            return False, wait_time
        
        # Can proceed
        return True, 0.0
    
    def _calculate_wait_time(self, venue: str, endpoint: str) -> float:
        """Bekleme süresi hesapla"""
        rule = self.rate_limits[venue][endpoint]
        now = datetime.now()
        
        if rule.window_start is None:
            return 0.0
        
        # Time until current window resets
        window_elapsed = now - rule.window_start
        time_until_reset = rule.window.total_seconds() - window_elapsed.total_seconds()
        
        # Apply backoff multiplier
        backoff = self.backoff_multipliers[venue]
        
        return max(0.1, time_until_reset * backoff)
    
    def _record_request(self, venue: str, endpoint: str):
        """İsteği kaydet"""
        rule = self.rate_limits[venue][endpoint]
        now = datetime.now()
        
        # Update counters
        rule.current_count += 1
        rule.window_start = rule.window_start or now
        
        # Track burst usage
        burst_window = timedelta(seconds=30)  # 30-second burst window
        if now - rule.window_start <= burst_window:
            rule.burst_count += 1
        
        # Add to history
        self.request_history[venue].append({
            'endpoint': endpoint,
            'timestamp': now,
            'rule_limit': rule.limit,
            'current_count': rule.current_count
        })
    
    async def _wait_for_concurrency_slot(self, venue: str) -> float:
        """Concurrency slot bekle"""
        # Simple implementation - in production this would be more sophisticated
        return 0.1
    
    def release(self, venue: str):
        """Concurrency slot serbest bırak"""
        if venue in self.concurrent_requests:
            self.concurrent_requests[venue] = max(0, self.concurrent_requests[venue] - 1)
    
    def add_request(self, request: APIRequest):
        """İstek kuyruğuna ekle"""
        self.pending_requests.append(request)
        self.pending_requests.sort(key=lambda x: x.priority)
    
    async def process_pending_requests(self):
        """Bekleyen istekleri işle"""
        if not self.pending_requests:
            return
        
        # Process requests by priority
        processed = []
        
        for request in self.pending_requests[:]:  # Copy list to avoid modification issues
            success = await self.acquire(
                request.venue, 
                request.endpoint, 
                request.priority,
                request.timeout
            )
            
            if success:
                processed.append(request)
            elif request.retry_count < request.max_retries:
                request.retry_count += 1
                request.timestamp = datetime.now()  # Update timestamp
                # Re-add to queue (will be reprocessed)
            else:
                # Max retries exceeded, remove from queue
                processed.append(request)
        
        # Remove processed requests
        for request in processed:
            if request in self.pending_requests:
                self.pending_requests.remove(request)
    
    def handle_rate_limit_response(self, venue: str, endpoint: str, 
                                 response_headers: Optional[Dict] = None):
        """Rate limit yanıtını işle"""
        now = datetime.now()
        
        # Default headers if not provided
        if not response_headers:
            response_headers = {}
        
        # Extract rate limit info from headers
        limit = response_headers.get('X-RateLimit-Limit', '100')
        remaining = response_headers.get('X-RateLimit-Remaining', '0')
        reset_time = response_headers.get('X-RateLimit-Reset')
        
        try:
            limit_val = int(limit)
            remaining_val = int(remaining)
        except ValueError:
            self.logger.warning(f"Invalid rate limit headers from {venue}:{endpoint}")
            return
        
        # Calculate usage
        usage_percentage = (limit_val - remaining_val) / limit_val if limit_val > 0 else 1
        
        # If we're at 90% capacity, start throttling
        if usage_percentage >= 0.9:
            self._activate_throttling(venue, endpoint, usage_percentage)
        
        # Update rule limits if they changed
        if venue in self.rate_limits and endpoint in self.rate_limits[venue]:
            rule = self.rate_limits[venue][endpoint]
            if limit_val != rule.limit:
                self.logger.info(f"Rate limit changed for {venue}:{endpoint} from {rule.limit} to {limit_val}")
                rule.limit = limit_val
                
                # Adjust burst limit proportionally
                if rule.burst_limit:
                    rule.burst_limit = max(1, int(limit_val * 0.5))
    
    def _activate_throttling(self, venue: str, endpoint: str, usage_percentage: float):
        """Throttling aktifleştir"""
        current_multiplier = self.backoff_multipliers[venue]
        
        # Increase backoff multiplier based on usage
        if usage_percentage >= 0.95:
            new_multiplier = min(5.0, current_multiplier * 2.0)  # Double, max 5x
        elif usage_percentage >= 0.9:
            new_multiplier = min(3.0, current_multiplier * 1.5)  # 1.5x, max 3x
        else:
            new_multiplier = 1.2
        
        if new_multiplier > current_multiplier:
            self.backoff_multipliers[venue] = new_multiplier
            self.logger.info(f"Throttling increased for {venue}: {current_multiplier:.2f}x -> {new_multiplier:.2f}x")
    
    def get_rate_limit_status(self, venue: str, endpoint: str) -> Optional[RateLimitStatus]:
        """Rate limit durumunu al"""
        if venue not in self.rate_limits or endpoint not in self.rate_limits[venue]:
            return None
        
        rule = self.rate_limits[venue][endpoint]
        now = datetime.now()
        
        # Calculate current usage
        current_usage = rule.current_count
        
        # Calculate window remaining
        window_remaining = timedelta(seconds=0)
        if rule.window_start:
            window_elapsed = now - rule.window_start
            window_remaining = max(timedelta(seconds=0), rule.window - window_elapsed)
        
        # Calculate usage percentage
        usage_percentage = (current_usage / rule.limit) if rule.limit > 0 else 1.0
        
        # Estimate wait time
        estimated_wait = self._calculate_wait_time(venue, endpoint)
        
        # Can proceed?
        can_proceed = (current_usage < rule.limit and 
                      venue not in self.throttled_venues and
                      self.concurrent_requests[venue] < self.max_concurrent[venue])
        
        return RateLimitStatus(
            venue=venue,
            endpoint=endpoint,
            current_usage=current_usage,
            limit=rule.limit,
            usage_percentage=usage_percentage,
            window_remaining=window_remaining,
            can_proceed=can_proceed,
            estimated_wait_time=estimated_wait
        )
    
    def get_all_rate_limit_status(self) -> Dict[str, Dict[str, RateLimitStatus]]:
        """Tüm rate limit durumlarını al"""
        status = {}
        
        for venue, endpoints in self.rate_limits.items():
            status[venue] = {}
            for endpoint in endpoints.keys():
                status[venue][endpoint] = self.get_rate_limit_status(venue, endpoint)
        
        return status
    
    def optimize_request_timing(self, requests: List[APIRequest]) -> List[Tuple[APIRequest, float]]:
        """İstek zamanlamasını optimize et"""
        optimized = []
        
        # Group requests by venue
        venue_requests = {}
        for request in requests:
            if request.venue not in venue_requests:
                venue_requests[request.venue] = []
            venue_requests[request.venue].append(request)
        
        # Optimize timing for each venue
        for venue, venue_reqs in venue_requests.items():
            # Sort by priority and endpoint
            venue_reqs.sort(key=lambda x: (x.priority, x.endpoint))
            
            for request in venue_reqs:
                # Calculate optimal delay
                delay = self._calculate_optimal_delay(venue, request.endpoint)
                optimized.append((request, delay))
        
        return optimized
    
    def _calculate_optimal_delay(self, venue: str, endpoint: str) -> float:
        """Optimal gecikme hesapla"""
        rule = self.rate_limits[venue][endpoint]
        now = datetime.now()
        
        # Base delay based on rule frequency
        base_delay = rule.window.total_seconds() / rule.limit
        
        # Adjust for current usage
        usage_factor = rule.current_count / rule.limit if rule.limit > 0 else 1
        
        # Apply venue-specific multiplier
        venue_multiplier = self.backoff_multipliers[venue]
        
        # Calculate total delay
        delay = base_delay * (1 + usage_factor) * venue_multiplier
        
        # Minimum delay
        return max(0.1, delay)
    
    def get_venue_utilization(self, venue: str, window_minutes: int = 60) -> Dict:
        """Venue utilization analizi"""
        if venue not in self.request_history:
            return {}
        
        now = datetime.now()
        cutoff_time = now - timedelta(minutes=window_minutes)
        
        # Filter requests in time window
        recent_requests = [
            req for req in self.request_history[venue]
            if req['timestamp'] > cutoff_time
        ]
        
        # Calculate metrics
        total_requests = len(recent_requests)
        endpoint_counts = {}
        
        for req in recent_requests:
            endpoint = req['endpoint']
            if endpoint not in endpoint_counts:
                endpoint_counts[endpoint] = 0
            endpoint_counts[endpoint] += 1
        
        # Calculate rates per minute
        rate_per_minute = total_requests / window_minutes if window_minutes > 0 else 0
        
        # Get current limits
        limits = {}
        for endpoint, rule in self.rate_limits[venue].items():
            limits[endpoint] = {
                'limit': rule.limit,
                'window': str(rule.window),
                'current_usage': rule.current_count
            }
        
        return {
            'venue': venue,
            'window_minutes': window_minutes,
            'total_requests': total_requests,
            'rate_per_minute': rate_per_minute,
            'endpoint_breakdown': endpoint_counts,
            'current_limits': limits,
            'concurrent_usage': self.concurrent_requests[venue],
            'max_concurrent': self.max_concurrent[venue],
            'backoff_multiplier': self.backoff_multipliers[venue],
            'is_throttled': venue in self.throttled_venues
        }
    
    def reset_rate_limits(self, venue: Optional[str] = None):
        """Rate limit sayaçlarını sıfırla"""
        if venue:
            if venue in self.rate_limits:
                for rule in self.rate_limits[venue].values():
                    rule.current_count = 0
                    rule.burst_count = 0
                    rule.window_start = None
            
            self.concurrent_requests[venue] = 0
            self.backoff_multipliers[venue] = 1.0
            
            if venue in self.throttled_venues:
                del self.throttled_venues[venue]
        else:
            # Reset all venues
            for venue_rules in self.rate_limits.values():
                for rule in venue_rules.values():
                    rule.current_count = 0
                    rule.burst_count = 0
                    rule.window_start = None
            
            self.concurrent_requests.clear()
            self.backoff_multipliers.clear()
            self.throttled_venues.clear()
        
        self.logger.info(f"Rate limits reset for venue: {venue or 'all'}")
    
    def get_performance_metrics(self) -> Dict:
        """Performance metrikleri"""
        metrics = {
            'timestamp': datetime.now(),
            'total_venues': len(self.rate_limits),
            'active_venues': len([v for v in self.rate_limits.keys() 
                                 if v not in self.throttled_venues]),
            'pending_requests': len(self.pending_requests),
            'total_throttled': len(self.throttled_venues),
            'venue_metrics': {}
        }
        
        for venue in self.rate_limits.keys():
            metrics['venue_metrics'][venue] = {
                'concurrent_requests': self.concurrent_requests[venue],
                'max_concurrent': self.max_concurrent[venue],
                'utilization': self.concurrent_requests[venue] / self.max_concurrent[venue] 
                             if self.max_concurrent[venue] > 0 else 0,
                'backoff_multiplier': self.backoff_multipliers[venue],
                'is_throttled': venue in self.throttled_venues,
                'total_endpoints': len(self.rate_limits[venue])
            }
        
        return metrics