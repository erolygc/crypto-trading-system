"""
Real-time Price Aggregator
Farklı borsalardan fiyat verilerini toplar ve agregasyon yapar
"""

import asyncio
import aiohttp
import time
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from collections import deque
import logging
from config import ExchangeConfig, VenueConfig

@dataclass
class PriceData:
    """Fiyat verisi yapısı"""
    venue: str
    symbol: str
    price: float
    bid: float
    ask: float
    volume_24h: float
    timestamp: float
    latency: float
    
@dataclass
class AggregatedPrice:
    """Agregasyon sonucu"""
    symbol: str
    best_bid: float
    best_ask: float
    mid_price: float
    volume_weighted_price: float
    timestamp: float
    venue_count: int
    price_spread: float
    liquidity_score: float

class PriceAggregator:
    """Real-time fiyat agregatörü"""
    
    def __init__(self, config: ExchangeConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.price_cache: Dict[str, Dict[str, PriceData]] = {}
        self.websocket_connections = {}
        self.rate_limiter = RateLimiter()
        
        # Fiyat geçmişi (son 1 saat)
        self.price_history = {}
        
        # Latency tracking
        self.latency_tracker = LatencyTracker()
        
    async def start_price_feeds(self):
        """Tüm borsalardan fiyat feed'lerini başlat"""
        tasks = []
        
        for venue_name, venue_config in self.config.VENUES.items():
            if venue_config.enabled:
                if venue_config.type == VenueType.CEX:
                    task = asyncio.create_task(
                        self._fetch_rest_prices(venue_name, venue_config)
                    )
                else:
                    task = asyncio.create_task(
                        self._fetch_graph_prices(venue_name, venue_config)
                    )
                tasks.append(task)
        
        # Paralel fiyat toplama
        await asyncio.gather(*tasks)
    
    async def _fetch_rest_prices(self, venue_name: str, venue_config: VenueConfig):
        """REST API üzerinden fiyat toplama"""
        session = aiohttp.ClientSession()
        
        try:
            while True:
                start_time = time.time()
                
                # Rate limit kontrolü
                await self.rate_limiter.acquire(venue_name, venue_config.rate_limit)
                
                # Simulated REST API calls (gerçek implementasyonda exchange API'leri kullanılır)
                prices = await self._simulate_venue_prices(venue_name)
                
                for symbol, price_data in prices.items():
                    price_data.latency = (time.time() - start_time) * 1000
                    
                    # Cache'e kaydet
                    if venue_name not in self.price_cache:
                        self.price_cache[venue_name] = {}
                    self.price_cache[venue_name][symbol] = price_data
                    
                    # Latency tracking
                    self.latency_tracker.add_latency(venue_name, price_data.latency)
                
                # Her 5 saniyede bir güncelle
                await asyncio.sleep(5)
                
        except Exception as e:
            self.logger.error(f"Error fetching prices from {venue_name}: {e}")
        finally:
            await session.close()
    
    async def _fetch_graph_prices(self, venue_name: str, venue_config: VenueConfig):
        """DEX'ler için GraphQL üzerinden fiyat toplama"""
        session = aiohttp.ClientSession()
        
        try:
            while True:
                start_time = time.time()
                
                await self.rate_limiter.acquire(venue_name, venue_config.rate_limit)
                
                # DEX fiyat verilerini simüle et
                prices = await self._simulate_dex_prices(venue_name)
                
                for symbol, price_data in prices.items():
                    price_data.latency = (time.time() - start_time) * 1000
                    
                    if venue_name not in self.price_cache:
                        self.price_cache[venue_name] = {}
                    self.price_cache[venue_name][symbol] = price_data
                    
                    self.latency_tracker.add_latency(venue_name, price_data.latency)
                
                await asyncio.sleep(10)  # DEX'ler için daha az frequent
                
        except Exception as e:
            self.logger.error(f"Error fetching DEX prices from {venue_name}: {e}")
        finally:
            await session.close()
    
    async def _simulate_venue_prices(self, venue_name: str) -> Dict[str, PriceData]:
        """Gerçek implementasyonda exchange API'lerini çağırır"""
        # Simulated price data
        symbols = ['BTC-USD', 'ETH-USD']
        prices = {}
        
        for symbol in symbols:
            base_price = 50000 if 'BTC' in symbol else 3000
            volatility = 0.001 if 'BTC' in symbol else 0.002
            
            price = base_price * (1 + np.random.normal(0, volatility))
            spread = price * 0.0001  # 1bp spread
            
            prices[symbol] = PriceData(
                venue=venue_name,
                symbol=symbol,
                price=price,
                bid=price - spread/2,
                ask=price + spread/2,
                volume_24h=np.random.uniform(1000000, 10000000),
                timestamp=time.time(),
                latency=0.0
            )
        
        return prices
    
    async def _simulate_dex_prices(self, venue_name: str) -> Dict[str, PriceData]:
        """DEX fiyat simülasyonu"""
        symbols = ['BTC-ETH']  # DEX'lerde genellikle wrapped token çiftleri
        prices = {}
        
        for symbol in symbols:
            price = 0.06  # BTC/ETH ratio
            spread = price * 0.001  # 10bp spread for DEX
            volume = np.random.uniform(10000, 500000)
            
            prices[symbol] = PriceData(
                venue=venue_name,
                symbol=symbol,
                price=price,
                bid=price - spread/2,
                ask=price + spread/2,
                volume_24h=volume,
                timestamp=time.time(),
                latency=0.0
            )
        
        return prices
    
    def aggregate_prices(self, symbol: str, weights: Optional[Dict[str, float]] = None) -> Optional[AggregatedPrice]:
        """Belirtilen sembol için fiyat agregasyonu"""
        if not weights:
            weights = self._calculate_default_weights()
        
        venue_prices = []
        total_weight = 0
        
        for venue_name, venue_data in self.price_cache.items():
            if symbol in venue_data:
                price_data = venue_data[symbol]
                weight = weights.get(venue_name, 1.0)
                
                venue_prices.append((price_data, weight))
                total_weight += weight
        
        if not venue_prices:
            return None
        
        # Agregasyon hesaplamaları
        best_bid = max([p[0].bid for p, w in venue_prices])
        best_ask = min([p[0].ask for p, w in venue_prices])
        mid_price = (best_bid + best_ask) / 2
        
        # Volume-weighted price
        vwap = self._calculate_vwap(venue_prices)
        
        # Liquidity score hesaplama
        liquidity_score = self._calculate_liquidity_score(venue_prices)
        
        return AggregatedPrice(
            symbol=symbol,
            best_bid=best_bid,
            best_ask=best_ask,
            mid_price=mid_price,
            volume_weighted_price=vwap,
            timestamp=time.time(),
            venue_count=len(venue_prices),
            price_spread=best_ask - best_bid,
            liquidity_score=liquidity_score
        )
    
    def _calculate_vwap(self, venue_prices: List[Tuple[PriceData, float]]) -> float:
        """Volume-weighted average price hesaplama"""
        total_volume_value = 0
        total_volume = 0
        
        for price_data, weight in venue_prices:
            # Her venue için volume hesapla (basitleştirilmiş)
            volume = price_data.volume_24h * weight
            volume_value = price_data.price * volume
            
            total_volume_value += volume_value
            total_volume += volume
        
        return total_volume_value / total_volume if total_volume > 0 else 0
    
    def _calculate_liquidity_score(self, venue_prices: List[Tuple[PriceData, float]]) -> float:
        """Likidite skoru hesaplama"""
        total_liquidity = sum([p[0].volume_24h for p, w in venue_prices])
        
        if total_liquidity == 0:
            return 0
        
        # Her venue'ın likidite katkısını normalize et
        liquidity_scores = []
        for price_data, weight in venue_prices:
            venue_score = (price_data.volume_24h / total_liquidity) * weight
            liquidity_scores.append(venue_score)
        
        return np.mean(liquidity_scores)
    
    def _calculate_default_weights(self) -> Dict[str, float]:
        """Varsayılan venue ağırlıkları"""
        weights = {}
        
        for venue_name, venue_config in self.config.VENUES.items():
            if venue_config.enabled:
                # Priority ve latency'e dayalı ağırlık hesaplama
                latency_weight = max(0.1, 100 / max(venue_config.latency_threshold, 10))
                priority_weight = (5 - venue_config.priority) / 4
                
                weights[venue_name] = latency_weight * priority_weight
        
        # Normalize weights
        total_weight = sum(weights.values())
        if total_weight > 0:
            weights = {k: v/total_weight for k, v in weights.items()}
        
        return weights
    
    def get_best_routing_opportunities(self, symbol: str) -> List[Dict]:
        """En iyi routing fırsatlarını bul"""
        opportunities = []
        aggregated = self.aggregate_prices(symbol)
        
        if not aggregated:
            return opportunities
        
        # Her venue için fırsat analizi
        for venue_name, venue_data in self.price_cache.items():
            if symbol in venue_data:
                price_data = venue_data[symbol]
                
                opportunity = {
                    'venue': venue_name,
                    'price': price_data.price,
                    'bid': price_data.bid,
                    'ask': price_data.ask,
                    'spread': price_data.ask - price_data.bid,
                    'volume': price_data.volume_24h,
                    'latency': price_data.latency,
                    'price_vs_agg': abs(price_data.price - aggregated.mid_price) / aggregated.mid_price,
                    'score': self._calculate_venue_score(price_data, aggregated)
                }
                opportunities.append(opportunity)
        
        # Score'a göre sırala
        opportunities.sort(key=lambda x: x['score'], reverse=True)
        
        return opportunities
    
    def _calculate_venue_score(self, price_data: PriceData, aggregated: AggregatedPrice) -> float:
        """Venue scoring algoritması"""
        config = self.config.OPTIMIZATION
        
        # Fiyat skoru (agg price'a yakınlık)
        price_score = 1 - abs(price_data.price - aggregated.mid_price) / aggregated.mid_price
        
        # Spread skoru (düşük spread daha iyi)
        spread_score = max(0, 1 - (price_data.ask - price_data.bid) / aggregated.price_spread)
        
        # Volume skoru (yüksek volume daha iyor)
        max_volume = max([v.volume_24h for venue_data in self.price_cache.values() 
                         for v in venue_data.values()])
        volume_score = price_data.volume_24h / max_volume if max_volume > 0 else 0
        
        # Latency skoru (düşük latency daha iyi)
        max_latency = max([v.latency for venue_data in self.price_cache.values() 
                          for v in venue_data.values()])
        latency_score = 1 - (price_data.latency / max_latency) if max_latency > 0 else 1
        
        # Ağırlıklı skor
        total_score = (
            config.liquidity_weight_alpha * volume_score +
            config.latency_weight_beta * latency_score +
            (1 - config.liquidity_weight_alpha - config.latency_weight_beta) * 
            (price_score + spread_score) / 2
        )
        
        return total_score
    
    def get_market_summary(self) -> Dict:
        """Piyasa özeti"""
        summary = {
            'timestamp': time.time(),
            'venues': {},
            'symbols': list(self.config.TRADING_PAIRS.keys()),
            'total_venues': len([v for v in self.config.VENUES.values() if v.enabled])
        }
        
        for symbol in summary['symbols']:
            agg_price = self.aggregate_prices(symbol)
            if agg_price:
                summary['venues'][symbol] = {
                    'best_bid': agg_price.best_bid,
                    'best_ask': agg_price.best_ask,
                    'spread_bps': (agg_price.price_spread / agg_price.mid_price) * 10000,
                    'venue_count': agg_price.venue_count,
                    'liquidity_score': agg_price.liquidity_score
                }
        
        return summary

class RateLimiter:
    """API rate limiting yöneticisi"""
    
    def __init__(self):
        self.requests = {}
        self.limits = {}
    
    async def acquire(self, venue: str, limit: int):
        """Rate limit kontrolü"""
        current_time = time.time()
        
        if venue not in self.requests:
            self.requests[venue] = deque()
            self.limits[venue] = limit
        
        # Eski istekleri temizle
        minute_ago = current_time - 60
        while self.requests[venue] and self.requests[venue][0] < minute_ago:
            self.requests[venue].popleft()
        
        # Limit kontrolü
        if len(self.requests[venue]) >= limit:
            sleep_time = 60 - (current_time - self.requests[venue][0])
            if sleep_time > 0:
                await asyncio.sleep(sleep_time)
        
        # Yeni isteği kaydet
        self.requests[venue].append(current_time)

class LatencyTracker:
    """Latency tracking ve analizi"""
    
    def __init__(self, window_size: int = 100):
        self.latency_data = {}
        self.window_size = window_size
    
    def add_latency(self, venue: str, latency: float):
        """Latency verisi ekle"""
        if venue not in self.latency_data:
            self.latency_data[venue] = deque(maxlen=self.window_size)
        
        self.latency_data[venue].append(latency)
    
    def get_avg_latency(self, venue: str) -> float:
        """Ortalama latency"""
        if venue not in self.latency_data or not self.latency_data[venue]:
            return 0
        
        return np.mean(self.latency_data[venue])
    
    def get_latency_stats(self, venue: str) -> Dict:
        """Latency istatistikleri"""
        if venue not in self.latency_data or not self.latency_data[venue]:
            return {}
        
        data = list(self.latency_data[venue])
        return {
            'mean': np.mean(data),
            'median': np.median(data),
            'std': np.std(data),
            'p95': np.percentile(data, 95),
            'p99': np.percentile(data, 99),
            'count': len(data)
        }