"""
Latency Manager
Latency-based routing kararları ve optimizasyon
"""

import time
import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from collections import deque, defaultdict
import logging
from datetime import datetime, timedelta
from scipy import stats
from config import ExchangeConfig

@dataclass
class LatencyMetrics:
    """Latency metrikleri"""
    venue: str
    timestamp: datetime
    latency_ms: float
    success: bool
    endpoint: str
    response_size: int
    network_overhead: float = 0.0
    processing_time: float = 0.0

@dataclass
class LatencyProfile:
    """Latency profili"""
    venue: str
    mean_latency: float
    median_latency: float
    p95_latency: float
    p99_latency: float
    std_latency: float
    jitter: float
    success_rate: float
    reliability_score: float
    
@dataclass
class LatencyRoutingDecision:
    """Latency routing kararı"""
    venue: str
    priority: int
    latency_score: float
    reliability_score: float
    total_score: float
    estimated_time: float
    recommended: bool
    reasons: List[str]

class LatencyManager:
    """Latency yönetimi ve routing kararları"""
    
    def __init__(self, config: ExchangeConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Latency data storage
        self.latency_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=1000))
        self.endpoint_latencies: Dict[str, Dict[str, deque]] = defaultdict(
            lambda: defaultdict(lambda: deque(maxlen=500))
        )
        
        # Performance tracking
        self.success_counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        self.failure_counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        
        # Network analysis
        self.network_conditions: Dict[str, Dict] = {}
        self._init_network_monitoring()
        
        # Caching
        self._latency_cache: Dict[str, LatencyProfile] = {}
        self._cache_ttl = 60  # 1 minute cache
        
        # Routing weights
        self.routing_weights = {
            'latency': 0.4,
            'reliability': 0.3,
            'consistency': 0.2,
            'jitter_penalty': 0.1
        }
        
    def _init_network_monitoring(self):
        """Network monitoring başlat"""
        for venue_name in self.config.VENUES.keys():
            self.network_conditions[venue_name] = {
                'baseline_latency': self.config.VENUES[venue_name].latency_threshold,
                'congestion_level': 0.0,
                'packet_loss': 0.0,
                'bandwidth_estimation': 1000.0,  # Mbps
                'route_quality': 1.0,
                'last_update': datetime.now()
            }
    
    def record_latency(self, metrics: LatencyMetrics):
        """Latency metriği kaydet"""
        
        # Add to main history
        self.latency_history[metrics.venue].append(metrics)
        
        # Add to endpoint-specific history
        self.endpoint_latencies[metrics.venue][metrics.endpoint].append(metrics)
        
        # Update success/failure counts
        if metrics.success:
            self.success_counts[metrics.venue][metrics.endpoint] += 1
        else:
            self.failure_counts[metrics.venue][metrics.endpoint] += 1
        
        # Update network conditions
        self._update_network_conditions(metrics.venue, metrics)
        
        # Invalidate cache
        if metrics.venue in self._latency_cache:
            del self._latency_cache[metrics.venue]
    
    def _update_network_conditions(self, venue: str, metrics: LatencyMetrics):
        """Network koşullarını güncelle"""
        
        if venue not in self.network_conditions:
            return
        
        conditions = self.network_conditions[venue]
        current_time = datetime.now()
        
        # Calculate congestion level based on recent latency spikes
        recent_latencies = [
            m.latency_ms for m in list(self.latency_history[venue])[-20:]
            if current_time - m.timestamp < timedelta(minutes=5)
        ]
        
        if recent_latencies:
            baseline = conditions['baseline_latency']
            recent_avg = np.mean(recent_latencies)
            congestion_level = max(0, (recent_avg - baseline) / baseline)
            conditions['congestion_level'] = min(1.0, congestion_level)
        
        # Estimate packet loss from failure rate
        total_requests = (self.success_counts[venue].get(metrics.endpoint, 0) + 
                         self.failure_counts[venue].get(metrics.endpoint, 0))
        
        if total_requests > 0:
            failure_rate = self.failure_counts[venue][metrics.endpoint] / total_requests
            conditions['packet_loss'] = min(0.1, failure_rate * 2)  # Scale up
        
        # Update bandwidth estimation
        if metrics.response_size > 0 and metrics.latency_ms > 0:
            # Simple bandwidth estimation: size / latency
            bandwidth_kbps = (metrics.response_size * 8) / (metrics.latency_ms / 1000) / 1000
            # Exponential moving average
            alpha = 0.1
            conditions['bandwidth_estimation'] = (
                alpha * bandwidth_kbps + (1 - alpha) * conditions['bandwidth_estimation']
            )
        
        # Calculate route quality
        conditions['route_quality'] = self._calculate_route_quality(venue)
        conditions['last_update'] = current_time
    
    def _calculate_route_quality(self, venue: str) -> float:
        """Route kalite skoru hesapla"""
        if venue not in self.network_conditions:
            return 0.0
        
        conditions = self.network_conditions[venue]
        
        # Factors affecting route quality
        latency_factor = max(0, 1 - (conditions['congestion_level']))
        packet_loss_factor = max(0, 1 - (conditions['packet_loss'] * 10))
        bandwidth_factor = min(1.0, conditions['bandwidth_estimation'] / 1000)
        
        # Weighted combination
        route_quality = (
            latency_factor * 0.4 +
            packet_loss_factor * 0.4 +
            bandwidth_factor * 0.2
        )
        
        return route_quality
    
    def get_latency_profile(self, venue: str, window_minutes: int = 60) -> Optional[LatencyProfile]:
        """Latency profili oluştur"""
        
        # Check cache first
        cache_key = f"{venue}_{window_minutes}"
        if cache_key in self._latency_cache:
            cached_profile = self._latency_cache[cache_key]
            if datetime.now() - cached_profile.timestamp < timedelta(seconds=self._cache_ttl):
                return cached_profile
        
        if venue not in self.latency_history:
            return None
        
        # Filter data by time window
        cutoff_time = datetime.now() - timedelta(minutes=window_minutes)
        recent_metrics = [
            m for m in self.latency_history[venue]
            if m.timestamp > cutoff_time
        ]
        
        if not recent_metrics:
            return None
        
        # Extract latency values
        latencies = [m.latency_ms for m in recent_metrics if m.success]
        if not latencies:
            return None
        
        # Calculate statistics
        mean_latency = np.mean(latencies)
        median_latency = np.median(latencies)
        p95_latency = np.percentile(latencies, 95)
        p99_latency = np.percentile(latencies, 99)
        std_latency = np.std(latencies)
        
        # Jitter calculation (latency variation)
        latency_diffs = np.diff(sorted(latencies))
        jitter = np.std(latency_diffs) if len(latency_diffs) > 0 else 0
        
        # Success rate
        total_requests = len(recent_metrics)
        successful_requests = len(latencies)
        success_rate = successful_requests / total_requests if total_requests > 0 else 0
        
        # Reliability score (combination of success rate and latency consistency)
        latency_consistency = max(0, 1 - (std_latency / mean_latency)) if mean_latency > 0 else 0
        reliability_score = (success_rate * 0.7 + latency_consistency * 0.3)
        
        # Create profile
        profile = LatencyProfile(
            venue=venue,
            mean_latency=mean_latency,
            median_latency=median_latency,
            p95_latency=p95_latency,
            p99_latency=p99_latency,
            std_latency=std_latency,
            jitter=jitter,
            success_rate=success_rate,
            reliability_score=reliability_score
        )
        
        # Cache the result
        self._latency_cache[cache_key] = profile
        profile.timestamp = datetime.now()
        
        return profile
    
    def get_endpoint_latency_analysis(self, venue: str, endpoint: str, 
                                    window_minutes: int = 30) -> Dict:
        """Endpoint-specific latency analizi"""
        
        if venue not in self.endpoint_latencies or endpoint not in self.endpoint_latencies[venue]:
            return {}
        
        # Filter data
        cutoff_time = datetime.now() - timedelta(minutes=window_minutes)
        recent_metrics = [
            m for m in self.endpoint_latencies[venue][endpoint]
            if m.timestamp > cutoff_time
        ]
        
        if not recent_metrics:
            return {}
        
        latencies = [m.latency_ms for m in recent_metrics if m.success]
        
        analysis = {
            'venue': venue,
            'endpoint': endpoint,
            'window_minutes': window_minutes,
            'total_requests': len(recent_metrics),
            'successful_requests': len(latencies),
            'success_rate': len(latencies) / len(recent_metrics),
            'statistics': {}
        }
        
        if latencies:
            analysis['statistics'] = {
                'mean': np.mean(latencies),
                'median': np.median(latencies),
                'p95': np.percentile(latencies, 95),
                'p99': np.percentile(latencies, 99),
                'std': np.std(latencies),
                'min': np.min(latencies),
                'max': np.max(latencies)
            }
            
            # Latency trend
            first_half = latencies[:len(latencies)//2]
            second_half = latencies[len(latencies)//2:]
            
            if first_half and second_half:
                trend = np.mean(second_half) - np.mean(first_half)
                analysis['trend'] = {
                    'direction': 'improving' if trend < 0 else 'degrading' if trend > 0 else 'stable',
                    'change_ms': trend,
                    'change_percent': (trend / np.mean(first_half)) * 100 if np.mean(first_half) > 0 else 0
                }
        
        return analysis
    
    def make_routing_decision(self, venues: List[str], endpoint: str, 
                            urgency_level: str = 'normal') -> List[LatencyRoutingDecision]:
        """Latency-based routing kararı"""
        
        decisions = []
        
        for venue in venues:
            profile = self.get_latency_profile(venue)
            endpoint_analysis = self.get_endpoint_latency_analysis(venue, endpoint)
            
            if not profile:
                continue
            
            # Calculate scores
            latency_score = self._calculate_latency_score(profile, urgency_level)
            reliability_score = profile.reliability_score
            consistency_score = self._calculate_consistency_score(profile)
            jitter_penalty = self._calculate_jitter_penalty(profile)
            
            # Total routing score
            total_score = (
                self.routing_weights['latency'] * latency_score +
                self.routing_weights['reliability'] * reliability_score +
                self.routing_weights['consistency'] * consistency_score +
                self.routing_weights['jitter_penalty'] * jitter_penalty
            )
            
            # Priority determination
            priority = self._calculate_routing_priority(profile, urgency_level)
            
            # Estimated time
            estimated_time = profile.mean_latency / 1000  # Convert to seconds
            
            # Recommended venues
            venue_config = self.config.VENUES[venue]
            is_recommended = (
                total_score > 0.7 and 
                profile.success_rate > 0.95 and
                profile.mean_latency < venue_config.latency_threshold
            )
            
            # Reasons for recommendation
            reasons = self._get_routing_reasons(
                profile, endpoint_analysis, total_score, urgency_level
            )
            
            decision = LatencyRoutingDecision(
                venue=venue,
                priority=priority,
                latency_score=latency_score,
                reliability_score=reliability_score,
                total_score=total_score,
                estimated_time=estimated_time,
                recommended=is_recommended,
                reasons=reasons
            )
            
            decisions.append(decision)
        
        # Sort by total score (highest first)
        decisions.sort(key=lambda x: x.total_score, reverse=True)
        
        # Update priorities after sorting
        for i, decision in enumerate(decisions):
            decision.priority = i + 1
        
        return decisions
    
    def _calculate_latency_score(self, profile: LatencyProfile, urgency_level: str) -> float:
        """Latency skoru hesapla"""
        venue_config = self.config.VENUES[profile.venue]
        
        # Base score from latency percentile
        if urgency_level == 'critical':
            # For critical requests, focus on p99 latency
            target_latency = profile.p99_latency
        elif urgency_level == 'high':
            # For high priority, focus on p95 latency
            target_latency = profile.p95_latency
        else:
            # For normal requests, use mean latency
            target_latency = profile.mean_latency
        
        # Score based on how well we meet the threshold
        threshold = venue_config.latency_threshold
        score = max(0, 1 - (target_latency / threshold))
        
        return score
    
    def _calculate_consistency_score(self, profile: LatencyProfile) -> float:
        """Konsistensi skoru hesapla"""
        # Lower coefficient of variation = higher consistency
        cv = profile.std_latency / profile.mean_latency if profile.mean_latency > 0 else 1
        consistency = max(0, 1 - cv)
        
        return consistency
    
    def _calculate_jitter_penalty(self, profile: LatencyProfile) -> float:
        """Jitter penalty hesapla"""
        # Jitter as percentage of mean latency
        jitter_percentage = (profile.jitter / profile.mean_latency) if profile.mean_latency > 0 else 0
        penalty = max(0, 1 - jitter_percentage)  # Lower jitter = higher penalty score
        
        return penalty
    
    def _calculate_routing_priority(self, profile: LatencyProfile, urgency_level: str) -> int:
        """Routing önceliği hesapla"""
        base_priority = self.config.VENUES[profile.venue].priority
        
        # Adjust priority based on performance
        if profile.success_rate > 0.99 and profile.p95_latency < 50:
            return max(1, base_priority - 1)  # Higher priority
        elif profile.success_rate < 0.9 or profile.p95_latency > 200:
            return min(10, base_priority + 2)  # Lower priority
        
        return base_priority
    
    def _get_routing_reasons(self, profile: LatencyProfile, endpoint_analysis: Dict,
                           total_score: float, urgency_level: str) -> List[str]:
        """Routing sebepleri"""
        reasons = []
        
        # Latency reasons
        if profile.mean_latency < 30:
            reasons.append("Excellent latency performance")
        elif profile.mean_latency < 50:
            reasons.append("Good latency performance")
        elif profile.mean_latency > 100:
            reasons.append("High latency - use for non-urgent requests")
        
        # Reliability reasons
        if profile.success_rate > 0.99:
            reasons.append("Excellent reliability (99%+ success rate)")
        elif profile.success_rate < 0.95:
            reasons.append("Lower reliability - consider alternatives")
        
        # Consistency reasons
        if profile.std_latency / profile.mean_latency < 0.1 if profile.mean_latency > 0 else False:
            reasons.append("Highly consistent performance")
        
        # Urgency-specific reasons
        if urgency_level == 'critical' and profile.p99_latency < 50:
            reasons.append("Suitable for critical requests")
        elif urgency_level == 'normal' and profile.mean_latency < 100:
            reasons.append("Good for normal priority requests")
        
        # Score-based reasons
        if total_score > 0.8:
            reasons.append("Top-tier routing performance")
        elif total_score < 0.5:
            reasons.append("Consider alternative venues for better performance")
        
        return reasons
    
    def get_latency_heatmap_data(self) -> Dict:
        """Latency heatmap verisi"""
        heatmap_data = {
            'timestamp': datetime.now(),
            'venues': {},
            'endpoints': set(),
            'matrix': []
        }
        
        # Collect all endpoints
        for venue_endpoints in self.endpoint_latencies.values():
            heatmap_data['endpoints'].update(venue_endpoints.keys())
        
        heatmap_data['endpoints'] = sorted(list(heatmap_data['endpoints']))
        
        # Build latency matrix
        venues = list(self.config.VENUES.keys())
        for venue in venues:
            if venue not in self.latency_history:
                continue
            
            profile = self.get_latency_profile(venue)
            if not profile:
                continue
            
            venue_data = {
                'venue': venue,
                'mean_latency': profile.mean_latency,
                'p95_latency': profile.p95_latency,
                'success_rate': profile.success_rate,
                'reliability_score': profile.reliability_score,
                'endpoint_latencies': {}
            }
            
            # Add endpoint-specific data
            for endpoint in heatmap_data['endpoints']:
                endpoint_analysis = self.get_endpoint_latency_analysis(venue, endpoint)
                if endpoint_analysis and 'statistics' in endpoint_analysis:
                    stats = endpoint_analysis['statistics']
                    venue_data['endpoint_latencies'][endpoint] = {
                        'mean': stats.get('mean', 0),
                        'p95': stats.get('p95', 0),
                        'success_rate': endpoint_analysis.get('success_rate', 0)
                    }
            
            heatmap_data['venues'][venue] = venue_data
        
        return heatmap_data
    
    def predict_latency(self, venue: str, endpoint: str, 
                       time_horizon_minutes: int = 60) -> Dict:
        """Latency tahmini"""
        
        # Get historical data
        endpoint_analysis = self.get_endpoint_latency_analysis(venue, endpoint, time_horizon_minutes)
        if not endpoint_analysis or 'trend' not in endpoint_analysis:
            return {'prediction': 'insufficient_data'}
        
        trend_data = endpoint_analysis['trend']
        current_latency = endpoint_analysis['statistics']['mean']
        
        # Simple linear trend prediction
        trend_direction = trend_data['direction']
        predicted_change = trend_data['change_ms']
        
        if trend_direction == 'stable':
            predicted_latency = current_latency
            confidence = 0.8
        elif trend_direction == 'improving':
            predicted_latency = current_latency + predicted_change * 0.5  # Moderate improvement
            confidence = 0.6
        else:  # degrading
            predicted_latency = current_latency + predicted_change * 0.8  # Potential degradation
            confidence = 0.7
        
        return {
            'predicted_latency_ms': predicted_latency,
            'confidence': confidence,
            'trend': trend_direction,
            'current_latency_ms': current_latency,
            'predicted_change_ms': predicted_latency - current_latency,
            'time_horizon_minutes': time_horizon_minutes
        }
    
    def get_latency_recommendations(self, trading_volume: str = 'medium') -> Dict:
        """Latency tabanlı venue önerileri"""
        
        recommendations = {
            'timestamp': datetime.now(),
            'trading_volume': trading_volume,
            'recommended_venues': [],
            'avoid_venues': [],
            'general_advice': []
        }
        
        # Volume-specific thresholds
        volume_thresholds = {
            'low': {'max_latency': 100, 'min_success_rate': 0.95},
            'medium': {'max_latency': 50, 'min_success_rate': 0.97},
            'high': {'max_latency': 30, 'min_success_rate': 0.99}
        }
        
        thresholds = volume_thresholds.get(trading_volume, volume_thresholds['medium'])
        
        # Evaluate each venue
        for venue_name in self.config.VENUES.keys():
            if venue_name not in self.latency_history:
                continue
            
            profile = self.get_latency_profile(venue_name)
            if not profile:
                continue
            
            # Check if venue meets criteria
            meets_latency = profile.mean_latency <= thresholds['max_latency']
            meets_reliability = profile.success_rate >= thresholds['min_success_rate']
            
            if meets_latency and meets_reliability:
                recommendations['recommended_venues'].append({
                    'venue': venue_name,
                    'mean_latency': profile.mean_latency,
                    'success_rate': profile.success_rate,
                    'reliability_score': profile.reliability_score
                })
            else:
                reasons = []
                if not meets_latency:
                    reasons.append(f"High latency ({profile.mean_latency:.1f}ms)")
                if not meets_reliability:
                    reasons.append(f"Low reliability ({profile.success_rate:.1%})")
                
                recommendations['avoid_venues'].append({
                    'venue': venue_name,
                    'reasons': reasons
                })
        
        # Sort recommended venues by score
        recommendations['recommended_venues'].sort(
            key=lambda x: x['reliability_score'], reverse=True
        )
        
        # Generate general advice
        recommendations['general_advice'] = self._generate_general_advice(recommendations)
        
        return recommendations
    
    def _generate_general_advice(self, recommendations: Dict) -> List[str]:
        """Genel öneriler oluştur"""
        advice = []
        
        recommended_count = len(recommendations['recommended_venues'])
        avoid_count = len(recommendations['avoid_venues'])
        
        if recommended_count == 0:
            advice.append("No venues meet current latency requirements. Consider reducing trading volume or increasing latency tolerance.")
        elif recommended_count == 1:
            advice.append("Only one venue meets requirements. Consider implementing backup venues or accepting higher latency.")
        elif recommended_count >= 3:
            advice.append("Multiple venues available. Implement load balancing across recommended venues.")
        
        if avoid_count > recommended_count:
            advice.append("Majority of venues have latency issues. Check network connectivity and venue status.")
        
        return advice