"""
Execution Cost Optimizer
Minimum execution cost için optimal order routing
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from scipy.optimize import minimize, differential_evolution
import logging
from config import ExchangeConfig

@dataclass
class CostBreakdown:
    """Cost detayları"""
    explicit_fees: float
    implicit_costs: float
    slippage: float
    market_impact: float
    latency_cost: float
    opportunity_cost: float
    total_cost: float

@dataclass
class OptimizationResult:
    """Optimizasyon sonucu"""
    optimal_allocation: Dict[str, float]
    total_cost: CostBreakdown
    expected_slippage: float
    execution_time: float
    venue_costs: Dict[str, CostBreakdown]
    convergence: bool
    iterations: int

class CostOptimizer:
    """Execution cost minimizasyonu"""
    
    def __init__(self, config: ExchangeConfig, price_aggregator):
        self.config = config
        self.price_aggregator = price_aggregator
        self.logger = logging.getLogger(__name__)
        
        # Cost model parametreleri
        self.cost_models = {}
        self._init_cost_models()
        
        # Historical performance data
        self.performance_history = {}
        
        # Optimization parameters
        self.opt_params = {
            'tolerance': 1e-6,
            'max_iterations': 1000,
            'population_size': 50,
            'mutation_factor': 0.7,
            'recombination': 0.8
        }
    
    def _init_cost_models(self):
        """Cost model parametrelerini başlat"""
        for venue_name, venue_config in self.config.VENUES.items():
            if venue_config.enabled:
                self.cost_models[venue_name] = {
                    'fee_model': self._create_fee_model(venue_config),
                    'slippage_model': self._create_slippage_model(venue_name),
                    'impact_model': self._create_impact_model(venue_name),
                    'latency_model': self._create_latency_model(venue_name)
                }
    
    def _create_fee_model(self, venue_config):
        """Fee model oluştur"""
        return {
            'maker_fee': venue_config.fee_maker,
            'taker_fee': venue_config.fee_taker,
            'withdrawal_fee': 0.0005,  # Base withdrawal fee
            'deposit_fee': 0.0,
            'tier_discounts': {
                'vip1': 0.9,
                'vip2': 0.8,
                'vip3': 0.7
            }
        }
    
    def _create_slippage_model(self, venue_name):
        """Slippage model oluştur"""
        return {
            'base_slippage': 0.0005,  # 5 bps base
            'volatility_factor': 0.1,
            'volume_sensitivity': 0.2,
            'time_factor': 0.05,
            'correlation_multiplier': 1.0
        }
    
    def _create_impact_model(self, venue_name):
        """Market impact model oluştur"""
        return {
            'temporary_impact': {
                'coefficient': 0.05,
                'exponent': 0.5,
                'decay_rate': 0.1
            },
            'permanent_impact': {
                'coefficient': 0.01,
                'exponent': 0.3
            },
            'cross_venue_impact': {
                'coefficient': 0.02,
                'decay_factor': 0.8
            }
        }
    
    def _create_latency_model(self, venue_name):
        """Latency cost model oluştur"""
        avg_latency = self.price_aggregator.latency_tracker.get_avg_latency(venue_name)
        return {
            'base_latency': avg_latency,
            'latency_cost_per_ms': 0.001,  # Cost per millisecond
            'time_priority_cost': 0.0001,
            'order_book_aging': 0.05  # Cost due to order book changes per second
        }
    
    def optimize_execution_cost(self, symbol: str, quantity: float, 
                              side: str = 'buy', 
                              optimization_method: str = 'differential_evolution') -> OptimizationResult:
        """Optimal execution cost hesaplama"""
        
        # Market data topla
        market_data = self._gather_market_data(symbol)
        if not market_data:
            raise ValueError(f"No market data available for {symbol}")
        
        # Venues list
        venues = list(market_data.keys())
        n_venues = len(venues)
        
        if n_venues == 0:
            raise ValueError("No available venues for optimization")
        
        # Define optimization problem
        if optimization_method == 'differential_evolution':
            result = self._differential_evolution_optimization(
                venues, market_data, quantity, side
            )
        elif optimization_method == 'sequential_least_squares':
            result = self._slsqp_optimization(
                venues, market_data, quantity, side
            )
        else:
            raise ValueError(f"Unknown optimization method: {optimization_method}")
        
        # Calculate detailed costs
        cost_breakdown = self._calculate_total_cost_breakdown(
            result.optimal_allocation, market_data, quantity, side
        )
        
        # Expected metrics
        expected_slippage = self._calculate_expected_slippage(
            result.optimal_allocation, market_data, quantity
        )
        
        execution_time = self._calculate_execution_time(
            result.optimal_allocation, market_data
        )
        
        return OptimizationResult(
            optimal_allocation=result.optimal_allocation,
            total_cost=cost_breakdown,
            expected_slippage=expected_slippage,
            execution_time=execution_time,
            venue_costs=self._calculate_venue_costs(
                result.optimal_allocation, market_data, quantity, side
            ),
            convergence=result.convergence,
            iterations=result.iterations
        )
    
    def _gather_market_data(self, symbol: str) -> Dict:
        """Market verilerini topla"""
        market_data = {}
        
        for venue_name, venue_data in self.price_aggregator.price_cache.items():
            if symbol in venue_data and self.config.VENUES[venue_name].enabled:
                price_data = venue_data[symbol]
                
                # Calculate liquidity metrics
                liquidity_metrics = self._calculate_liquidity_metrics(venue_name, price_data)
                
                # Calculate cost components
                cost_components = self._calculate_cost_components(venue_name, price_data, symbol)
                
                market_data[venue_name] = {
                    'price_data': price_data,
                    'liquidity': liquidity_metrics,
                    'costs': cost_components,
                    'venue_config': self.config.VENUES[venue_name]
                }
        
        return market_data
    
    def _calculate_liquidity_metrics(self, venue_name: str, price_data) -> Dict:
        """Likidite metrikleri hesapla"""
        venue_config = self.config.VENUES[venue_name]
        
        # Volume-based liquidity
        volume_liquidity = price_data.volume_24h
        
        # Order book depth (simulated)
        bid_depth = volume_liquidity * 0.1  # Assume 10% volume at bid
        ask_depth = volume_liquidity * 0.1  # Assume 10% volume at ask
        
        # Venue-specific liquidity factors
        if venue_config.type == VenueType.CEX:
            liquidity_factor = 1.0  # Base liquidity
        else:
            liquidity_factor = 0.5  # DEX'lerde daha düşük
        
        return {
            'volume_liquidity': volume_liquidity,
            'bid_depth': bid_depth,
            'ask_depth': ask_depth,
            'total_depth': bid_depth + ask_depth,
            'liquidity_factor': liquidity_factor,
            'available_liquidity': min(volume_liquidity, venue_config.max_trade_size)
        }
    
    def _calculate_cost_components(self, venue_name: str, price_data, symbol: str) -> Dict:
        """Cost bileşenleri hesapla"""
        venue_config = self.config.VENUES[venue_name]
        cost_model = self.cost_models[venue_name]
        
        # Explicit fees
        explicit_fees = venue_config.fee_taker
        
        # Spread cost
        spread = price_data.ask - price_data.bid
        spread_cost = spread / price_data.price
        
        # Base slippage (from historical data)
        base_slippage = cost_model['slippage_model']['base_slippage']
        
        # Latency cost
        avg_latency = self.price_aggregator.latency_tracker.get_avg_latency(venue_name)
        latency_cost = avg_latency * cost_model['latency_model']['latency_cost_per_ms'] / 1000
        
        # Market impact (base estimate)
        impact_cost = cost_model['impact_model']['temporary_impact']['coefficient']
        
        # Total explicit cost
        total_explicit = explicit_fees + spread_cost + latency_cost
        
        return {
            'explicit_fees': explicit_fees,
            'spread_cost': spread_cost,
            'base_slippage': base_slippage,
            'latency_cost': latency_cost,
            'market_impact': impact_cost,
            'total_explicit': total_explicit
        }
    
    def _differential_evolution_optimization(self, venues: List[str], market_data: Dict, 
                                           quantity: float, side: str) -> OptimizationResult:
        """Differential Evolution ile optimizasyon"""
        
        n_venues = len(venues)
        
        # Objective function
        def objective(allocation):
            if np.sum(allocation) == 0:
                return 1e6  # Penalty for no allocation
            
            total_cost = 0
            
            for i, venue in enumerate(venues):
                allocated_qty = allocation[i] * quantity
                if allocated_qty > 0:
                    # Calculate cost for this allocation
                    venue_cost = self._calculate_venue_cost(
                        venue, allocated_qty, market_data[venue], side
                    )
                    total_cost += allocation[i] * venue_cost
            
            return total_cost
        
        # Bounds: each allocation between 0 and 1
        bounds = [(0, 1) for _ in range(n_venues)]
        
        # Constraint: sum of allocations <= 1 (allow for partial fills)
        def constraint(allocation):
            return np.sum(allocation) - 1
        
        # Run optimization
        result = differential_evolution(
            objective,
            bounds,
            seed=42,
            maxiter=self.opt_params['max_iterations'],
            popsize=self.opt_params['population_size'],
            mutation=self.opt_params['mutation_factor'],
            recombination=self.opt_params['recombination'],
            atol=self.opt_params['tolerance'],
            tol=self.opt_params['tolerance'],
            constraints={'type': 'eq', 'fun': constraint}
        )
        
        # Convert result to allocation dict
        optimal_allocation = {
            venues[i]: max(0, result.x[i]) for i in range(n_venues)
        }
        
        return OptimizationResult(
            optimal_allocation=optimal_allocation,
            total_cost=CostBreakdown(0, 0, 0, 0, 0, 0, result.fun),
            venue_costs={},
            convergence=result.success,
            iterations=result.nit
        )
    
    def _slsqp_optimization(self, venues: List[str], market_data: Dict, 
                          quantity: float, side: str) -> OptimizationResult:
        """Sequential Least Squares Programming ile optimizasyon"""
        
        n_venues = len(venues)
        
        def objective(allocation):
            total_cost = 0
            for i, venue in enumerate(venues):
                allocated_qty = allocation[i] * quantity
                if allocated_qty > 0:
                    venue_cost = self._calculate_venue_cost(
                        venue, allocated_qty, market_data[venue], side
                    )
                    total_cost += allocation[i] * venue_cost
            return total_cost
        
        def constraint_sum(allocation):
            return np.sum(allocation) - 1
        
        # Bounds
        bounds = []
        for venue in venues:
            venue_config = self.config.VENUES[venue]
            max_weight = min(1.0, venue_config.max_trade_size / quantity)
            bounds.append((0, max_weight))
        
        # Constraints
        constraints = [{'type': 'eq', 'fun': constraint_sum}]
        
        # Initial guess
        x0 = np.ones(n_venues) / n_venues
        
        # Optimization
        result = minimize(
            objective,
            x0,
            method='SLSQP',
            bounds=bounds,
            constraints=constraints,
            options={
                'maxiter': self.opt_params['max_iterations'],
                'ftol': self.opt_params['tolerance']
            }
        )
        
        optimal_allocation = {
            venues[i]: max(0, result.x[i]) for i in range(n_venues)
        }
        
        return OptimizationResult(
            optimal_allocation=optimal_allocation,
            total_cost=CostBreakdown(0, 0, 0, 0, 0, 0, result.fun),
            venue_costs={},
            convergence=result.success,
            iterations=result.nit
        )
    
    def _calculate_venue_cost(self, venue_name: str, quantity: float, 
                            market_data: Dict, side: str) -> float:
        """Venue-specific cost hesaplama"""
        
        costs = market_data['costs']
        
        # Base cost
        base_cost = costs['total_explicit']
        
        # Volume-based slippage
        liquidity = market_data['liquidity']['available_liquidity']
        volume_ratio = quantity / liquidity if liquidity > 0 else 1
        
        # Slippage model
        cost_model = self.cost_models[venue_name]
        slippage = cost_model['slippage_model']['base_slippage'] * (1 + volume_ratio)
        
        # Market impact model
        impact_model = cost_model['impact_model']['temporary_impact']
        market_impact = impact_model['coefficient'] * (volume_ratio ** impact_model['exponent'])
        
        # Total cost
        total_cost = base_cost + slippage + market_impact
        
        return total_cost
    
    def _calculate_total_cost_breakdown(self, allocation: Dict[str, float], 
                                     market_data: Dict, quantity: float, side: str) -> CostBreakdown:
        """Toplam cost breakdown hesaplama"""
        
        total_fees = 0
        total_slippage = 0
        total_impact = 0
        total_latency = 0
        total_opportunity = 0
        
        for venue_name, weight in allocation.items():
            if venue_name in market_data:
                venue_data = market_data[venue_name]
                allocated_qty = weight * quantity
                
                costs = venue_data['costs']
                
                # Weighted costs
                total_fees += weight * costs['explicit_fees']
                total_slippage += weight * costs['base_slippage']
                total_latency += weight * costs['latency_cost']
                
                # Market impact
                cost_model = self.cost_models[venue_name]
                impact_model = cost_model['impact_model']['temporary_impact']
                volume_ratio = allocated_qty / venue_data['liquidity']['available_liquidity']
                impact = impact_model['coefficient'] * (volume_ratio ** impact_model['exponent'])
                total_impact += weight * impact
        
        # Opportunity cost (from not taking best price)
        aggregated_price = self.price_aggregator.aggregate_prices(list(market_data.values())[0]['price_data'].symbol)
        if aggregated_price:
            best_price = aggregated_price.best_ask if side == 'buy' else aggregated_price.best_bid
            avg_price = np.mean([
                venue_data['price_data'].ask if side == 'buy' else venue_data['price_data'].bid
                for venue_data in market_data.values()
            ])
            total_opportunity = abs(best_price - avg_price) / best_price
        
        implicit_costs = total_slippage + total_impact + total_latency + total_opportunity
        
        return CostBreakdown(
            explicit_fees=total_fees,
            implicit_costs=implicit_costs,
            slippage=total_slippage,
            market_impact=total_impact,
            latency_cost=total_latency,
            opportunity_cost=total_opportunity,
            total_cost=total_fees + implicit_costs
        )
    
    def _calculate_venue_costs(self, allocation: Dict[str, float], market_data: Dict, 
                             quantity: float, side: str) -> Dict[str, CostBreakdown]:
        """Venue-specific cost breakdown"""
        
        venue_costs = {}
        
        for venue_name, weight in allocation.items():
            if venue_name in market_data and weight > 0:
                allocated_qty = weight * quantity
                venue_data = market_data[venue_name]
                costs = venue_data['costs']
                
                venue_costs[venue_name] = CostBreakdown(
                    explicit_fees=weight * costs['explicit_fees'],
                    implicit_costs=weight * costs['base_slippage'],
                    slippage=weight * costs['base_slippage'],
                    market_impact=weight * costs['market_impact'],
                    latency_cost=weight * costs['latency_cost'],
                    opportunity_cost=0,  # Venue-specific opp cost is handled at total level
                    total_cost=weight * (costs['total_explicit'])
                )
        
        return venue_costs
    
    def _calculate_expected_slippage(self, allocation: Dict[str, float], 
                                   market_data: Dict, quantity: float) -> float:
        """Beklenen slippage hesaplama"""
        
        expected_slippage = 0
        
        for venue_name, weight in allocation.items():
            if venue_name in market_data and weight > 0:
                venue_data = market_data[venue_name]
                costs = venue_data['costs']
                
                # Volume-adjusted slippage
                allocated_qty = weight * quantity
                liquidity = venue_data['liquidity']['available_liquidity']
                volume_ratio = allocated_qty / liquidity if liquidity > 0 else 1
                
                slippage = costs['base_slippage'] * (1 + volume_ratio)
                expected_slippage += weight * slippage
        
        return expected_slippage
    
    def _calculate_execution_time(self, allocation: Dict[str, float], market_data: Dict) -> float:
        """Execution time hesaplama"""
        
        max_latency = 0
        
        for venue_name, weight in allocation.items():
            if venue_name in market_data and weight > 0:
                avg_latency = self.price_aggregator.latency_tracker.get_avg_latency(venue_name)
                max_latency = max(max_latency, avg_latency)
        
        return max_latency / 1000  # Convert to seconds
    
    def get_cost_analytics(self, symbol: str, historical_trades: pd.DataFrame) -> Dict:
        """Cost analytics ve historical performance"""
        
        if historical_trades.empty:
            return {}
        
        analytics = {
            'summary': {},
            'venue_performance': {},
            'cost_trends': {},
            'optimization_opportunities': {}
        }
        
        # Summary statistics
        analytics['summary'] = {
            'total_trades': len(historical_trades),
            'avg_cost': historical_trades['total_cost'].mean(),
            'cost_std': historical_trades['total_cost'].std(),
            'avg_slippage': historical_trades['slippage'].mean(),
            'total_savings': 0  # Will be calculated
        }
        
        # Venue performance
        if 'venue' in historical_trades.columns:
            venue_stats = historical_trades.groupby('venue').agg({
                'total_cost': ['mean', 'std', 'count'],
                'slippage': ['mean', 'std'],
                'execution_time': 'mean'
            }).round(6)
            
            analytics['venue_performance'] = venue_stats.to_dict()
        
        # Cost trends over time
        if 'timestamp' in historical_trades.columns:
            analytics['cost_trends'] = {
                'daily_cost_trend': historical_trades.groupby(
                    historical_trades['timestamp'].dt.date
                )['total_cost'].mean().to_dict(),
                'volatility_trend': historical_trades.groupby(
                    historical_trades['timestamp'].dt.date
                )['total_cost'].std().to_dict()
            }
        
        # Optimization opportunities
        analytics['optimization_opportunities'] = self._identify_optimization_opportunities(
            historical_trades
        )
        
        return analytics
    
    def _identify_optimization_opportunities(self, historical_trades: pd.DataFrame) -> Dict:
        """Optimizasyon fırsatlarını tespit et"""
        
        opportunities = {
            'high_cost_trades': [],
            'underutilized_venues': [],
            'latency_issues': [],
            'fee_savings': 0
        }
        
        # High cost trades (top 10%)
        cost_threshold = historical_trades['total_cost'].quantile(0.9)
        high_cost_trades = historical_trades[historical_trades['total_cost'] > cost_threshold]
        opportunities['high_cost_trades'] = high_cost_trades.to_dict('records')
        
        # Underutilized venues (low trade frequency but good metrics)
        if 'venue' in historical_trades.columns:
            venue_counts = historical_trades['venue'].value_counts()
            min_trades = venue_counts.quantile(0.1)
            
            underutilized = venue_counts[venue_counts < min_trades]
            opportunities['underutilized_venues'] = underutilized.index.tolist()
        
        # Latency issues (high execution times)
        if 'execution_time' in historical_trades.columns:
            latency_threshold = historical_trades['execution_time'].quantile(0.9)
            latency_issues = historical_trades[historical_trades['execution_time'] > latency_threshold]
            opportunities['latency_issues'] = len(latency_issues)
        
        return opportunities