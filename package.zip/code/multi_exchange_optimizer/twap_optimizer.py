"""
TWAP Optimizer
Time-Weighted Average Price optimizasyonu ve stratejisi
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging
from collections import deque
from scipy.optimize import minimize
from config import ExchangeConfig

@dataclass
class TWAPSlice:
    """TWAP dilimi"""
    slice_id: int
    start_time: datetime
    end_time: datetime
    planned_quantity: float
    execution_quantity: float = 0.0
    target_price: float = 0.0
    executed_price: float = 0.0
    slippage: float = 0.0
    status: str = 'pending'  # pending, executing, completed, failed
    
@dataclass
class TWAPExecutionPlan:
    """TWAP execution plan"""
    symbol: str
    total_quantity: float
    time_horizon: timedelta
    slice_count: int
    slices: List[TWAPSlice]
    target_twap: float
    execution_strategy: str
    expected_completion: datetime
    
@dataclass
class TWAPPerformance:
    """TWAP performance tracking"""
    planned_twap: float
    executed_twap: float
    tracking_error: float
    execution_quality: float
    market_impact: float
    timing_quality: float
    slippage_analysis: Dict[str, float]

class TWAPOptimizer:
    """Time-Weighted Average Price optimizer"""
    
    def __init__(self, config: ExchangeConfig, price_aggregator=None):
        self.config = config
        self.price_aggregator = price_aggregator
        self.logger = logging.getLogger(__name__)
        
        # TWAP execution tracking
        self.active_twaps: Dict[str, TWAPExecutionPlan] = {}
        self.completed_twaps: List[TWAPExecutionPlan] = []
        self.performance_history: List[TWAPPerformance] = []
        
        # Market analysis
        self.market_conditions: Dict[str, Dict] = {}
        self.volume_patterns: Dict[str, Dict] = {}
        
        # Optimization parameters
        self.default_slice_duration = 300  # 5 minutes
        self.max_slices = 20
        self.min_slice_size = 0.01  # Minimum quantity per slice
        
        # Risk management
        self.max_tracking_error = 0.005  # 0.5%
        self.max_market_impact = 0.01  # 1%
        
        # Initialize market analysis
        self._initialize_market_analysis()
    
    def _initialize_market_analysis(self):
        """Market analysis başlat"""
        for symbol in self.config.TRADING_PAIRS.keys():
            self.market_conditions[symbol] = {
                'volatility': 0.02,  # 2% base volatility
                'trend_strength': 0.0,
                'liquidity_score': 0.5,
                'optimal_execution_hours': [9, 10, 11, 14, 15, 16],  # Market hours
                'volume_peak_hours': [10, 11, 14, 15],  # High volume periods
                'correlation_matrix': {},
                'last_update': datetime.now()
            }
            
            self.volume_patterns[symbol] = {
                'hourly_patterns': {},
                'daily_patterns': {},
                'weekly_patterns': {},
                'intraday_volatility': {}
            }
    
    def create_twap_plan(self, symbol: str, quantity: float, time_hours: float,
                        execution_style: str = 'adaptive') -> TWAPExecutionPlan:
        """TWAP planı oluştur"""
        
        if time_hours < 0.25:  # Minimum 15 minutes
            raise ValueError("TWAP execution time must be at least 15 minutes")
        
        # Calculate slice parameters
        slice_duration = self._calculate_optimal_slice_duration(
            symbol, quantity, time_hours
        )
        
        slice_count = int((time_hours * 3600) / slice_duration)
        slice_count = min(max(slice_count, 1), self.max_slices)
        
        # Get target price
        target_price = self._get_target_price(symbol)
        
        # Generate execution time window
        start_time = datetime.now()
        end_time = start_time + timedelta(hours=time_hours)
        
        # Create slices
        slices = self._create_execution_slices(
            symbol, quantity, slice_count, start_time, end_time,
            target_price, execution_style
        )
        
        # Create execution plan
        plan = TWAPExecutionPlan(
            symbol=symbol,
            total_quantity=quantity,
            time_horizon=end_time - start_time,
            slice_count=slice_count,
            slices=slices,
            target_twap=target_price,
            execution_strategy=execution_style,
            expected_completion=end_time
        )
        
        # Store active plan
        self.active_twaps[f"{symbol}_{start_time.timestamp()}"] = plan
        
        return plan
    
    def _calculate_optimal_slice_duration(self, symbol: str, quantity: float, 
                                        time_hours: float) -> int:
        """Optimal slice süresi hesapla"""
        
        # Base slice duration
        base_duration = int(time_hours * 3600 / 10)  # Default 10 slices
        
        # Adjust based on market conditions
        market_data = self.market_conditions.get(symbol, {})
        volatility = market_data.get('volatility', 0.02)
        liquidity_score = market_data.get('liquidity_score', 0.5)
        
        # Higher volatility = more frequent slices
        volatility_adjustment = 1 + (volatility * 10)
        
        # Lower liquidity = more frequent slices
        liquidity_adjustment = 1 + ((1 - liquidity_score) * 5)
        
        # Total adjustment
        adjusted_duration = int(base_duration / (volatility_adjustment * liquidity_adjustment))
        
        # Apply bounds
        return max(60, min(1800, adjusted_duration))  # Between 1 minute and 30 minutes
    
    def _get_target_price(self, symbol: str) -> float:
        """Hedef fiyat al"""
        if self.price_aggregator:
            aggregated = self.price_aggregator.aggregate_prices(symbol)
            if aggregated:
                return aggregated.mid_price
        
        # Fallback: use most recent price or default
        return 50000.0 if 'BTC' in symbol else 3000.0
    
    def _create_execution_slices(self, symbol: str, total_quantity: float, 
                               slice_count: int, start_time: datetime, end_time: datetime,
                               target_price: float, execution_style: str) -> List[TWAPSlice]:
        """Execution dilimleri oluştur"""
        
        slices = []
        time_per_slice = (end_time - start_time) / slice_count
        base_quantity_per_slice = total_quantity / slice_count
        
        for i in range(slice_count):
            slice_start = start_time + i * time_per_slice
            slice_end = slice_start + time_per_slice
            
            # Calculate quantity based on strategy
            if execution_style == 'fixed':
                planned_quantity = base_quantity_per_slice
            elif execution_style == 'adaptive':
                planned_quantity = self._calculate_adaptive_quantity(
                    symbol, i, slice_count, base_quantity_per_slice
                )
            elif execution_style == 'volume_weighted':
                planned_quantity = self._calculate_volume_weighted_quantity(
                    symbol, slice_start, slice_end, total_quantity
                )
            elif execution_style == 'volatility_weighted':
                planned_quantity = self._calculate_volatility_weighted_quantity(
                    symbol, i, slice_count, base_quantity_per_slice
                )
            else:
                planned_quantity = base_quantity_per_slice
            
            # Ensure minimum slice size
            planned_quantity = max(self.min_slice_size, planned_quantity)
            
            # Adjust last slice to match total
            if i == slice_count - 1:
                remaining_quantity = total_quantity - sum(s.quantity for s in slices)
                planned_quantity = max(self.min_slice_size, remaining_quantity)
            
            slice_obj = TWAPSlice(
                slice_id=i,
                start_time=slice_start,
                end_time=slice_end,
                planned_quantity=planned_quantity,
                target_price=target_price
            )
            
            slices.append(slice_obj)
        
        return slices
    
    def _calculate_adaptive_quantity(self, symbol: str, slice_index: int, 
                                   total_slices: int, base_quantity: float) -> float:
        """Adaptive quantity calculation"""
        
        # Early slices: smaller quantities
        # Late slices: larger quantities
        progress = slice_index / total_slices
        
        if progress < 0.3:  # First 30% - smaller
            return base_quantity * 0.8
        elif progress < 0.7:  # Middle 40% - normal
            return base_quantity * 1.0
        else:  # Last 30% - larger
            return base_quantity * 1.2
    
    def _calculate_volume_weighted_quantity(self, symbol: str, slice_start: datetime,
                                          slice_end: datetime, total_quantity: float) -> float:
        """Volume-weighted quantity calculation"""
        
        # Get typical volume for this time period
        hour = slice_start.hour
        typical_volume_ratio = self._get_typical_volume_ratio(symbol, hour)
        
        return total_quantity * typical_volume_ratio
    
    def _calculate_volatility_weighted_quantity(self, symbol: str, slice_index: int,
                                              total_slices: int, base_quantity: float) -> float:
        """Volatility-weighted quantity calculation"""
        
        # Higher volatility periods = smaller quantities
        # Simulate volatility pattern
        volatility_pattern = 0.5 + 0.5 * np.sin(2 * np.pi * slice_index / total_slices)
        
        return base_quantity * (2 - volatility_pattern)  # Inverse relationship
    
    def _get_typical_volume_ratio(self, symbol: str, hour: int) -> float:
        """Typical volume ratio for hour"""
        
        # Simulate market hours volume patterns
        if 9 <= hour <= 16:  # Market hours
            base_ratio = 0.04  # 4% per hour average
            if 10 <= hour <= 11 or 14 <= hour <= 15:  # Peak hours
                base_ratio *= 1.5
        else:  # After hours
            base_ratio = 0.02  # 2% per hour
        
        return base_ratio
    
    def update_slice_execution(self, slice_id: str, executed_quantity: float,
                             executed_price: float, status: str = 'completed'):
        """Slice execution güncelleme"""
        
        # Find the slice
        slice_found = False
        for plan in self.active_twaps.values():
            for slice_obj in plan.slices:
                if f"{plan.symbol}_{slice_obj.slice_id}" == slice_id:
                    slice_obj.execution_quantity = executed_quantity
                    slice_obj.executed_price = executed_price
                    slice_obj.status = status
                    
                    # Calculate slippage
                    if executed_quantity > 0:
                        slice_obj.slippage = abs(executed_price - slice_obj.target_price) / slice_obj.target_price
                    
                    slice_found = True
                    break
            if slice_found:
                break
        
        if not slice_found:
            self.logger.warning(f"Slice not found: {slice_id}")
        
        # Check if plan is complete
        self._check_plan_completion(slice_id.split('_')[0])
    
    def _check_plan_completion(self, symbol: str):
        """Plan tamamlanma kontrolü"""
        
        # Find active plan for symbol
        active_plan = None
        plan_key = None
        for key, plan in self.active_twaps.items():
            if symbol in key:
                active_plan = plan
                plan_key = key
                break
        
        if not active_plan:
            return
        
        # Check if all slices are completed
        all_completed = all(
            slice_obj.status == 'completed' for slice_obj in active_plan.slices
        )
        
        if all_completed:
            # Calculate performance
            performance = self._calculate_twap_performance(active_plan)
            self.performance_history.append(performance)
            self.completed_twaps.append(active_plan)
            
            # Remove from active plans
            del self.active_twaps[plan_key]
            
            self.logger.info(f"TWAP plan completed for {symbol}")
    
    def _calculate_twap_performance(self, plan: TWAPExecutionPlan) -> TWAPPerformance:
        """TWAP performance hesapla"""
        
        # Extract executed trades
        executed_slices = [s for s in plan.slices if s.executed_quantity > 0]
        
        if not executed_slices:
            return TWAPPerformance(
                planned_twap=plan.target_twap,
                executed_twap=0,
                tracking_error=1.0,
                execution_quality=0,
                market_impact=0,
                timing_quality=0,
                slippage_analysis={}
            )
        
        # Calculate executed TWAP
        total_value = sum(s.executed_quantity * s.executed_price for s in executed_slices)
        total_quantity = sum(s.executed_quantity for s in executed_slices)
        executed_twap = total_value / total_quantity if total_quantity > 0 else 0
        
        # Tracking error
        tracking_error = abs(executed_twap - plan.target_twap) / plan.target_twap
        
        # Execution quality (lower tracking error = higher quality)
        execution_quality = max(0, 1 - tracking_error / self.max_tracking_error)
        
        # Market impact (based on average slippage)
        avg_slippage = np.mean([s.slippage for s in executed_slices])
        market_impact = avg_slippage
        
        # Timing quality (how well we followed the time schedule)
        planned_times = [s.start_time for s in plan.slices]
        actual_times = [s.end_time for s in executed_slices]
        
        timing_quality = 0.8  # Simplified calculation
        
        # Slippage analysis
        slippage_analysis = {
            'mean': np.mean([s.slippage for s in executed_slices]),
            'std': np.std([s.slippage for s in executed_slices]),
            'max': np.max([s.slippage for s in executed_slices]),
            'min': np.min([s.slippage for s in executed_slices])
        }
        
        return TWAPPerformance(
            planned_twap=plan.target_twap,
            executed_twap=executed_twap,
            tracking_error=tracking_error,
            execution_quality=execution_quality,
            market_impact=market_impact,
            timing_quality=timing_quality,
            slippage_analysis=slippage_analysis
        )
    
    def optimize_twap_parameters(self, symbol: str, historical_data: pd.DataFrame) -> Dict:
        """TWAP parametrelerini optimize et"""
        
        if historical_data.empty:
            return self._get_default_parameters()
        
        # Analyze historical performance
        performance_metrics = self._analyze_historical_performance(historical_data)
        
        # Optimize slice duration
        optimal_slice_duration = self._optimize_slice_duration(performance_metrics)
        
        # Optimize execution style
        best_execution_style = self._optimize_execution_style(performance_metrics)
        
        # Optimize slice count
        optimal_slice_count = self._optimize_slice_count(performance_metrics)
        
        return {
            'optimal_slice_duration_seconds': optimal_slice_duration,
            'optimal_execution_style': best_execution_style,
            'optimal_slice_count': optimal_slice_count,
            'performance_metrics': performance_metrics,
            'recommendations': self._generate_optimization_recommendations(performance_metrics)
        }
    
    def _analyze_historical_performance(self, historical_data: pd.DataFrame) -> Dict:
        """Historical performance analizi"""
        
        metrics = {
            'avg_tracking_error': historical_data['tracking_error'].mean(),
            'avg_market_impact': historical_data['market_impact'].mean(),
            'avg_execution_quality': historical_data['execution_quality'].mean(),
            'volatility_impact': np.corrcoef(
                historical_data['market_volatility'], 
                historical_data['tracking_error']
            )[0, 1] if 'market_volatility' in historical_data.columns else 0,
            'volume_impact': np.corrcoef(
                historical_data['trade_size'], 
                historical_data['market_impact']
            )[0, 1] if 'trade_size' in historical_data.columns else 0
        }
        
        return metrics
    
    def _optimize_slice_duration(self, metrics: Dict) -> int:
        """Slice duration optimizasyonu"""
        
        base_duration = self.default_slice_duration
        
        # Adjust based on tracking error
        tracking_error = metrics.get('avg_tracking_error', 0.01)
        if tracking_error > 0.02:  # High tracking error
            base_duration *= 0.8  # More frequent slices
        elif tracking_error < 0.005:  # Low tracking error
            base_duration *= 1.2  # Less frequent slices
        
        # Adjust based on market impact
        market_impact = metrics.get('avg_market_impact', 0.01)
        if market_impact > 0.015:  # High market impact
            base_duration *= 0.9  # More frequent slices
        
        return int(base_duration)
    
    def _optimize_execution_style(self, metrics: Dict) -> str:
        """Execution style optimizasyonu"""
        
        # This would be determined by analyzing which style performed best historically
        # For now, return a default based on metrics
        
        tracking_error = metrics.get('avg_tracking_error', 0.01)
        market_impact = metrics.get('avg_market_impact', 0.01)
        
        if tracking_error > 0.02 and market_impact > 0.015:
            return 'volatility_weighted'  # Use smallest slices during high volatility
        elif market_impact > 0.015:
            return 'volume_weighted'  # Time slices based on market volume
        else:
            return 'adaptive'  # Default to adaptive
    
    def _optimize_slice_count(self, metrics: Dict) -> int:
        """Slice count optimizasyonu"""
        
        base_count = 10
        
        tracking_error = metrics.get('avg_tracking_error', 0.01)
        if tracking_error > 0.02:
            base_count = min(self.max_slices, int(base_count * 1.3))  # More slices
        elif tracking_error < 0.005:
            base_count = max(5, int(base_count * 0.8))  # Fewer slices
        
        return base_count
    
    def _get_default_parameters(self) -> Dict:
        """Default parametreler"""
        return {
            'optimal_slice_duration_seconds': self.default_slice_duration,
            'optimal_execution_style': 'adaptive',
            'optimal_slice_count': 10,
            'performance_metrics': {},
            'recommendations': ['Insufficient historical data - using default parameters']
        }
    
    def _generate_optimization_recommendations(self, metrics: Dict) -> List[str]:
        """Optimizasyon önerileri"""
        
        recommendations = []
        
        tracking_error = metrics.get('avg_tracking_error', 0.01)
        market_impact = metrics.get('avg_market_impact', 0.01)
        
        if tracking_error > 0.02:
            recommendations.append("High tracking error - consider reducing slice duration or increasing slice count")
        
        if market_impact > 0.015:
            recommendations.append("High market impact - consider volume-weighted execution or smaller slice sizes")
        
        if tracking_error < 0.005 and market_impact < 0.01:
            recommendations.append("Good performance - current parameters are well optimized")
        
        volatility_impact = metrics.get('volatility_impact', 0)
        if volatility_impact > 0.3:
            recommendations.append("High volatility impact - consider volatility-weighted execution style")
        
        return recommendations
    
    def get_next_execution_slices(self, symbol: str, max_slices: int = 3) -> List[TWAPSlice]:
        """Sonraki execution dilimlerini al"""
        
        now = datetime.now()
        ready_slices = []
        
        # Find active plan for symbol
        active_plan = None
        for plan in self.active_twaps.values():
            if plan.symbol == symbol:
                active_plan = plan
                break
        
        if not active_plan:
            return ready_slices
        
        # Get slices that should be executed now
        for slice_obj in active_plan.slices:
            if (slice_obj.status == 'pending' and 
                slice_obj.start_time <= now <= slice_obj.end_time and
                len(ready_slices) < max_slices):
                ready_slices.append(slice_obj)
        
        # Sort by start time
        ready_slices.sort(key=lambda x: x.start_time)
        
        return ready_slices
    
    def calculate_twap_pnl(self, plan_id: str, current_market_price: float) -> Dict:
        """TWAP plan P&L hesaplama"""
        
        # Find the plan
        plan = None
        for active_plan in self.active_twaps.values():
            if f"{active_plan.symbol}_{active_plan.expected_completion.timestamp()}" == plan_id:
                plan = active_plan
                break
        
        if not plan:
            # Check completed plans
            for completed_plan in self.completed_twaps:
                if f"{completed_plan.symbol}_{completed_plan.expected_completion.timestamp()}" == plan_id:
                    plan = completed_plan
                    break
        
        if not plan:
            return {'error': 'Plan not found'}
        
        # Calculate current P&L
        executed_value = sum(s.executed_quantity * s.executed_price for s in plan.slices if s.executed_quantity > 0)
        executed_quantity = sum(s.executed_quantity for s in plan.slices if s.executed_quantity > 0)
        remaining_quantity = plan.total_quantity - executed_quantity
        
        # P&L components
        realized_pnl = 0  # Only calculate when position is closed
        unrealized_pnl = remaining_quantity * (plan.target_twap - current_market_price)
        
        return {
            'plan_id': plan_id,
            'symbol': plan.symbol,
            'total_quantity': plan.total_quantity,
            'executed_quantity': executed_quantity,
            'remaining_quantity': remaining_quantity,
            'target_twap': plan.target_twap,
            'current_market_price': current_market_price,
            'realized_pnl': realized_pnl,
            'unrealized_pnl': unrealized_pnl,
            'total_pnl': realized_pnl + unrealized_pnl,
            'execution_progress': (executed_quantity / plan.total_quantity) * 100
        }
    
    def get_twap_performance_report(self, days: int = 30) -> Dict:
        """TWAP performance raporu"""
        
        cutoff_date = datetime.now() - timedelta(days=days)
        
        # Filter recent performance
        recent_performance = [
            p for p in self.performance_history
            if hasattr(p, 'planned_twap') and 
            datetime.now() - timedelta(seconds=0) > cutoff_date
        ]
        
        if not recent_performance:
            return {'message': 'No recent TWAP performance data available'}
        
        # Calculate summary statistics
        tracking_errors = [p.tracking_error for p in recent_performance]
        execution_qualities = [p.execution_quality for p in recent_performance]
        market_impacts = [p.market_impact for p in recent_performance]
        
        report = {
            'period_days': days,
            'total_executions': len(recent_performance),
            'summary': {
                'avg_tracking_error': np.mean(tracking_errors),
                'avg_execution_quality': np.mean(execution_qualities),
                'avg_market_impact': np.mean(market_impacts),
                'tracking_error_std': np.std(tracking_errors),
                'execution_quality_std': np.std(execution_qualities)
            },
            'performance_distribution': {
                'tracking_error_percentiles': {
                    'p25': np.percentile(tracking_errors, 25),
                    'p50': np.percentile(tracking_errors, 50),
                    'p75': np.percentile(tracking_errors, 75),
                    'p95': np.percentile(tracking_errors, 95)
                },
                'execution_quality_percentiles': {
                    'p25': np.percentile(execution_qualities, 25),
                    'p50': np.percentile(execution_qualities, 50),
                    'p75': np.percentile(execution_qualities, 75),
                    'p95': np.percentile(execution_qualities, 95)
                }
            },
            'performance_metrics': [p.__dict__ for p in recent_performance]
        }
        
        return report