"""
Utility Functions
Multi-exchange optimizer için yardımcı fonksiyonlar
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from datetime import datetime, timedelta
import json
import logging
from dataclasses import asdict
import hashlib
import asyncio
import aiohttp
import time
from scipy.stats import norm

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class MathUtils:
    """Matematik yardımcı fonksiyonları"""
    
    @staticmethod
    def calculate_sharpe_ratio(returns: np.ndarray, risk_free_rate: float = 0.0) -> float:
        """Sharpe ratio hesaplama"""
        if len(returns) == 0 or np.std(returns) == 0:
            return 0.0
        
        excess_returns = returns - risk_free_rate
        return np.mean(excess_returns) / np.std(returns) * np.sqrt(252)  # Annualized
    
    @staticmethod
    def calculate_max_drawdown(equity_curve: np.ndarray) -> float:
        """Maximum drawdown hesaplama"""
        peak = np.maximum.accumulate(equity_curve)
        drawdown = (equity_curve - peak) / peak
        return np.min(drawdown)
    
    @staticmethod
    def calculate_var(returns: np.ndarray, confidence_level: float = 0.05) -> float:
        """Value at Risk hesaplama"""
        return np.percentile(returns, confidence_level * 100)
    
    @staticmethod
    def calculate_cvar(returns: np.ndarray, confidence_level: float = 0.05) -> float:
        """Conditional Value at Risk hesaplama"""
        var = MathUtils.calculate_var(returns, confidence_level)
        return np.mean(returns[returns <= var])
    
    @staticmethod
    def calculate_information_ratio(portfolio_returns: np.ndarray, 
                                  benchmark_returns: np.ndarray) -> float:
        """Information ratio hesaplama"""
        if len(portfolio_returns) != len(benchmark_returns):
            raise ValueError("Portfolio and benchmark returns must have same length")
        
        active_returns = portfolio_returns - benchmark_returns
        tracking_error = np.std(active_returns)
        
        if tracking_error == 0:
            return 0.0
        
        return np.mean(active_returns) / tracking_error * np.sqrt(252)  # Annualized
    
    @staticmethod
    def calculate_beta(portfolio_returns: np.ndarray, market_returns: np.ndarray) -> float:
        """Beta hesaplama"""
        if len(portfolio_returns) != len(market_returns):
            raise ValueError("Portfolio and market returns must have same length")
        
        covariance = np.cov(portfolio_returns, market_returns)[0, 1]
        market_variance = np.var(market_returns)
        
        if market_variance == 0:
            return 0.0
        
        return covariance / market_variance
    
    @staticmethod
    def calculate_correlation_matrix(returns_data: pd.DataFrame) -> pd.DataFrame:
        """Correlation matrix hesaplama"""
        return returns_data.corr()
    
    @staticmethod
    def normalize_weights(weights: np.ndarray) -> np.ndarray:
        """Weights normalize etme"""
        if np.sum(weights) == 0:
            return np.ones_like(weights) / len(weights)
        return weights / np.sum(weights)
    
    @staticmethod
    def calculate_portfolio_metrics(returns: np.ndarray, weights: np.ndarray) -> Dict:
        """Portfolio metrikleri hesaplama"""
        portfolio_returns = returns @ weights
        
        return {
            'return': np.mean(portfolio_returns),
            'volatility': np.std(portfolio_returns),
            'sharpe_ratio': MathUtils.calculate_sharpe_ratio(portfolio_returns),
            'max_drawdown': MathUtils.calculate_max_drawdown(1 + portfolio_returns),
            'var_95': MathUtils.calculate_var(portfolio_returns, 0.05),
            'cvar_95': MathUtils.calculate_cvar(portfolio_returns, 0.05)
        }

class TimeUtils:
    """Zaman yardımcı fonksiyonları"""
    
    @staticmethod
    def get_market_hours(tz: str = 'UTC') -> Dict[str, int]:
        """Market saatleri (basitleştirilmiş)"""
        return {
            'market_open': 9,   # 9 AM
            'market_close': 16, # 4 PM
            'lunch_break_start': 12, # 12 PM
            'lunch_break_end': 13    # 1 PM
        }
    
    @staticmethod
    def is_market_hours(timestamp: datetime = None, tz: str = 'UTC') -> bool:
        """Market saatlerinde mi kontrolü"""
        if timestamp is None:
            timestamp = datetime.now()
        
        hours = TimeUtils.get_market_hours(tz)
        hour = timestamp.hour
        
        return (hours['market_open'] <= hour < hours['lunch_break_start'] or
                hours['lunch_break_end'] <= hour < hours['market_close'])
    
    @staticmethod
    def get_next_market_open(current_time: datetime = None) -> datetime:
        """Sonraki market açılış saati"""
        if current_time is None:
            current_time = datetime.now()
        
        hours = TimeUtils.get_market_hours()
        market_open = current_time.replace(
            hour=hours['market_open'], 
            minute=0, 
            second=0, 
            microsecond=0
        )
        
        # Eğer bugün market kapanmışsa, yarını döndür
        if current_time.time() >= datetime.strptime('16:00', '%H:%M').time():
            market_open += timedelta(days=1)
        
        # Eğer hafta sonu ise, Pazartesi'yi döndür
        while market_open.weekday() >= 5:  # Saturday=5, Sunday=6
            market_open += timedelta(days=1)
        
        return market_open
    
    @staticmethod
    def calculate_session_duration(start_time: datetime, end_time: datetime) -> Dict:
        """Session süresi hesaplama"""
        duration = end_time - start_time
        
        # Market saatleri içindeki süreyi hesapla
        current_time = start_time
        market_seconds = 0
        
        while current_time < end_time:
            if TimeUtils.is_market_hours(current_time):
                next_hour = current_time.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
                if next_hour > end_time:
                    next_hour = end_time
                market_seconds += (next_hour - current_time).total_seconds()
            
            current_time += timedelta(hours=1)
        
        return {
            'total_duration': duration,
            'market_hours_duration': timedelta(seconds=market_seconds),
            'percentage_market_hours': market_seconds / duration.total_seconds() * 100
        }
    
    @staticmethod
    def parse_timeframe(timeframe: str) -> timedelta:
        """Timeframe string'ini timedelta'ye çevirme"""
        timeframe_map = {
            '1m': timedelta(minutes=1),
            '5m': timedelta(minutes=5),
            '15m': timedelta(minutes=15),
            '30m': timedelta(minutes=30),
            '1h': timedelta(hours=1),
            '4h': timedelta(hours=4),
            '1d': timedelta(days=1),
            '1w': timedelta(weeks=1)
        }
        
        return timeframe_map.get(timeframe.lower(), timedelta(minutes=1))

class DataUtils:
    """Veri işleme yardımcı fonksiyonları"""
    
    @staticmethod
    def clean_price_data(prices: List[float], method: str = 'remove_outliers') -> List[float]:
        """Price data temizleme"""
        if not prices:
            return []
        
        if method == 'remove_outliers':
            # IQR method
            q1 = np.percentile(prices, 25)
            q3 = np.percentile(prices, 75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            
            return [p for p in prices if lower_bound <= p <= upper_bound]
        
        elif method == 'winsorize':
            # Winsorization
            lower_percentile = np.percentile(prices, 1)
            upper_percentile = np.percentile(prices, 99)
            
            return [max(lower_percentile, min(p, upper_percentile)) for p in prices]
        
        else:
            return prices
    
    @staticmethod
    def calculate_returns(prices: List[float], method: str = 'log') -> List[float]:
        """Return hesaplama"""
        if len(prices) < 2:
            return []
        
        if method == 'log':
            return [np.log(prices[i] / prices[i-1]) for i in range(1, len(prices))]
        else:
            return [(prices[i] - prices[i-1]) / prices[i-1] for i in range(1, len(prices))]
    
    @staticmethod
    def resample_data(data: pd.DataFrame, timeframe: str, 
                     agg_func: str = 'mean') -> pd.DataFrame:
        """Veri resampling"""
        if 'timestamp' not in data.columns:
            raise ValueError("Data must contain 'timestamp' column")
        
        data['timestamp'] = pd.to_datetime(data['timestamp'])
        data.set_index('timestamp', inplace=True)
        
        return data.resample(timeframe).agg(agg_func).dropna()
    
    @staticmethod
    def detect_outliers(data: np.ndarray, method: str = 'zscore', 
                       threshold: float = 3.0) -> np.ndarray:
        """Outlier detection"""
        if method == 'zscore':
            z_scores = np.abs((data - np.mean(data)) / np.std(data))
            return z_scores > threshold
        
        elif method == 'iqr':
            q1 = np.percentile(data, 25)
            q3 = np.percentile(data, 75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            return (data < lower_bound) | (data > upper_bound)
        
        else:
            raise ValueError(f"Unknown outlier detection method: {method}")
    
    @staticmethod
    def interpolate_missing_data(data: pd.Series, method: str = 'linear') -> pd.Series:
        """Missing data interpolation"""
        if method == 'linear':
            return data.interpolate(method='linear')
        elif method == 'forward_fill':
            return data.ffill()
        elif method == 'backward_fill':
            return data.bfill()
        elif method == 'mean':
            return data.fillna(data.mean())
        else:
            return data.dropna()

class StringUtils:
    """String yardımcı fonksiyonları"""
    
    @staticmethod
    def generate_request_id(prefix: str = 'req') -> str:
        """Unique request ID oluşturma"""
        timestamp = int(time.time() * 1000)
        random_suffix = np.random.randint(1000, 9999)
        return f"{prefix}_{timestamp}_{random_suffix}"
    
    @staticmethod
    def hash_data(data: str) -> str:
        """Data hash'leme"""
        return hashlib.md5(data.encode()).hexdigest()
    
    @staticmethod
    def format_currency(amount: float, currency: str = 'USD', 
                       decimals: int = 2) -> str:
        """Para birimi formatı"""
        if currency == 'USD':
            return f"${amount:,.{decimals}f}"
        elif currency == 'EUR':
            return f"€{amount:,.{decimals}f}"
        elif currency == 'GBP':
            return f"£{amount:,.{decimals}f}"
        else:
            return f"{amount:,.{decimals}f} {currency}"
    
    @staticmethod
    def format_percentage(value: float, decimals: int = 2) -> str:
        """Yüzde formatı"""
        return f"{value * 100:.{decimals}f}%"
    
    @staticmethod
    def truncate_text(text: str, max_length: int, suffix: str = '...') -> str:
        """Text truncation"""
        if len(text) <= max_length:
            return text
        return text[:max_length - len(suffix)] + suffix

class AsyncUtils:
    """Async yardımcı fonksiyonları"""
    
    @staticmethod
    async def retry_async(func, max_retries: int = 3, 
                         delay: float = 1.0, backoff: float = 2.0):
        """Async function retry decorator"""
        for attempt in range(max_retries + 1):
            try:
                return await func()
            except Exception as e:
                if attempt == max_retries:
                    logger.error(f"Max retries reached. Last error: {e}")
                    raise e
                
                wait_time = delay * (backoff ** attempt)
                logger.warning(f"Attempt {attempt + 1} failed. Retrying in {wait_time}s...")
                await asyncio.sleep(wait_time)
    
    @staticmethod
    async def timeout_async(coro, timeout: float):
        """Async timeout wrapper"""
        return await asyncio.wait_for(coro, timeout=timeout)
    
    @staticmethod
    async def gather_with_semaphore(coros, semaphore: asyncio.Semaphore):
        """Semaphore ile coroutine gathering"""
        async def bounded_coro(coro):
            async with semaphore:
                return await coro
        
        return await asyncio.gather(*(bounded_coro(coro) for coro in coros))

class ValidationUtils:
    """Validation yardımcı fonksiyonları"""
    
    @staticmethod
    def is_valid_symbol(symbol: str, allowed_symbols: List[str] = None) -> bool:
        """Symbol validation"""
        if not symbol or not isinstance(symbol, str):
            return False
        
        if allowed_symbols:
            return symbol.upper() in [s.upper() for s in allowed_symbols]
        
        # Basic format validation (e.g., BTC-USD, ETH-USD)
        parts = symbol.upper().split('-')
        return len(parts) == 2 and all(len(part) >= 3 for part in parts)
    
    @staticmethod
    def is_valid_quantity(quantity: float, min_size: float = 0.001) -> bool:
        """Quantity validation"""
        return isinstance(quantity, (int, float)) and quantity >= min_size
    
    @staticmethod
    def is_valid_side(side: str) -> bool:
        """Side validation (buy/sell)"""
        return side.lower() in ['buy', 'sell', 'long', 'short']
    
    @staticmethod
    def is_valid_timeframe(timeframe: str) -> bool:
        """Timeframe validation"""
        valid_timeframes = ['1m', '5m', '15m', '30m', '1h', '4h', '1d', '1w']
        return timeframe in valid_timeframes
    
    @staticmethod
    def validate_trade_parameters(symbol: str, quantity: float, side: str) -> Tuple[bool, List[str]]:
        """Trade parameters validation"""
        errors = []
        
        if not ValidationUtils.is_valid_symbol(symbol):
            errors.append("Invalid symbol format")
        
        if not ValidationUtils.is_valid_quantity(quantity):
            errors.append("Invalid quantity")
        
        if not ValidationUtils.is_valid_side(side):
            errors.append("Invalid side (must be 'buy' or 'sell')")
        
        return len(errors) == 0, errors

class ConfigUtils:
    """Configuration yardımcı fonksiyonları"""
    
    @staticmethod
    def load_config(config_path: str) -> Dict:
        """Config dosyası yükleme"""
        try:
            with open(config_path, 'r') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"Failed to load config from {config_path}: {e}")
            return {}
    
    @staticmethod
    def save_config(config: Dict, config_path: str):
        """Config dosyası kaydetme"""
        try:
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2, default=str)
        except Exception as e:
            logger.error(f"Failed to save config to {config_path}: {e}")
    
    @staticmethod
    def merge_configs(*configs: Dict) -> Dict:
        """Config'ları birleştirme"""
        merged = {}
        for config in configs:
            merged.update(config)
        return merged
    
    @staticmethod
    def validate_config(config: Dict, required_keys: List[str]) -> Tuple[bool, List[str]]:
        """Config validation"""
        errors = []
        for key in required_keys:
            if key not in config:
                errors.append(f"Missing required config key: {key}")
        
        return len(errors) == 0, errors

class MetricsUtils:
    """Metrik hesaplama yardımcı fonksiyonları"""
    
    @staticmethod
    def calculate_latency_metrics(latencies: List[float]) -> Dict:
        """Latency metrikleri"""
        if not latencies:
            return {}
        
        return {
            'mean': np.mean(latencies),
            'median': np.median(latencies),
            'std': np.std(latencies),
            'p95': np.percentile(latencies, 95),
            'p99': np.percentile(latencies, 99),
            'min': np.min(latencies),
            'max': np.max(latencies)
        }
    
    @staticmethod
    def calculate_success_rate(successes: List[bool]) -> float:
        """Success rate hesaplama"""
        if not successes:
            return 0.0
        return sum(successes) / len(successes)
    
    @staticmethod
    def calculate_cost_metrics(costs: List[float]) -> Dict:
        """Cost metrikleri"""
        if not costs:
            return {}
        
        return {
            'mean': np.mean(costs),
            'median': np.median(costs),
            'std': np.std(costs),
            'p95': np.percentile(costs, 95),
            'min': np.min(costs),
            'max': np.max(costs)
        }
    
    @staticmethod
    def calculate_slippage_metrics(slippage_data: List[float]) -> Dict:
        """Slippage metrikleri"""
        if not slippage_data:
            return {}
        
        positive_slippage = [s for s in slippage_data if s > 0]
        negative_slippage = [abs(s) for s in slippage_data if s < 0]
        
        return {
            'mean_slippage': np.mean(slippage_data),
            'positive_slippage_mean': np.mean(positive_slippage) if positive_slippage else 0,
            'negative_slippage_mean': np.mean(negative_slippage) if negative_slippage else 0,
            'slippage_std': np.std(slippage_data),
            'slippage_count': len(slippage_data)
        }

class SerializationUtils:
    """Serialization yardımcı fonksiyonları"""
    
    @staticmethod
    def dataclass_to_dict(obj) -> Dict:
        """Dataclass'i dict'e çevirme"""
        return asdict(obj)
    
    @staticmethod
    def dict_to_dataclass(data: Dict, dataclass_type):
        """Dict'i dataclass'e çevirme"""
        return dataclass_type(**data)
    
    @staticmethod
    def json_serialize(obj, default_handler=None) -> str:
        """JSON serialization"""
        try:
            return json.dumps(obj, default=default_handler or str, indent=2)
        except Exception as e:
            logger.error(f"JSON serialization failed: {e}")
            return "{}"
    
    @staticmethod
    def json_deserialize(json_str: str) -> Dict:
        """JSON deserialization"""
        try:
            return json.loads(json_str)
        except Exception as e:
            logger.error(f"JSON deserialization failed: {e}")
            return {}

class PerformanceUtils:
    """Performance monitoring yardımcı fonksiyonları"""
    
    @staticmethod
    def time_function(func):
        """Function timing decorator"""
        async def async_wrapper(*args, **kwargs):
            start_time = time.time()
            result = await func(*args, **kwargs)
            end_time = time.time()
            logger.info(f"{func.__name__} took {end_time - start_time:.3f} seconds")
            return result
        
        def sync_wrapper(*args, **kwargs):
            start_time = time.time()
            result = func(*args, **kwargs)
            end_time = time.time()
            logger.info(f"{func.__name__} took {end_time - start_time:.3f} seconds")
            return result
        
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    @staticmethod
    def memory_usage_mb() -> float:
        """Memory usage (MB)"""
        import psutil
        import os
        process = psutil.Process(os.getpid())
        return process.memory_info().rss / 1024 / 1024
    
    @staticmethod
    def cpu_usage_percent() -> float:
        """CPU usage percentage"""
        import psutil
        return psutil.cpu_percent(interval=1)

class LoggingUtils:
    """Logging yardımcı fonksiyonları"""
    
    @staticmethod
    def setup_logger(name: str, level: str = 'INFO', 
                    log_file: str = None) -> logging.Logger:
        """Logger setup"""
        logger = logging.getLogger(name)
        logger.setLevel(getattr(logging, level.upper()))
        
        # Clear existing handlers
        logger.handlers.clear()
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        console_handler.setFormatter(console_formatter)
        logger.addHandler(console_handler)
        
        # File handler
        if log_file:
            file_handler = logging.FileHandler(log_file)
            file_formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s'
            )
            file_handler.setFormatter(file_formatter)
            logger.addHandler(file_handler)
        
        return logger
    
    @staticmethod
    def log_performance_metrics(metrics: Dict, logger: logging.Logger):
        """Performance metrics logging"""
        logger.info("Performance Metrics:")
        for key, value in metrics.items():
            if isinstance(value, float):
                logger.info(f"  {key}: {value:.4f}")
            else:
                logger.info(f"  {key}: {value}")

class FormatUtils:
    """Format yardımcı fonksiyonları"""
    
    @staticmethod
    def format_number(num: float, precision: int = 2) -> str:
        """Number formatting"""
        return f"{num:.{precision}f}"
    
    @staticmethod
    def format_large_number(num: float) -> str:
        """Large number formatting (K, M, B)"""
        abs_num = abs(num)
        if abs_num >= 1e9:
            return f"{num/1e9:.1f}B"
        elif abs_num >= 1e6:
            return f"{num/1e6:.1f}M"
        elif abs_num >= 1e3:
            return f"{num/1e3:.1f}K"
        else:
            return FormatUtils.format_number(num)
    
    @staticmethod
    def format_duration(seconds: float) -> str:
        """Duration formatting"""
        if seconds < 60:
            return f"{seconds:.1f}s"
        elif seconds < 3600:
            minutes = seconds / 60
            return f"{minutes:.1f}m"
        else:
            hours = seconds / 3600
            return f"{hours:.1f}h"
    
    @staticmethod
    def format_bytes(bytes_count: int) -> str:
        """Bytes formatting"""
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if bytes_count < 1024.0:
                return f"{bytes_count:.1f} {unit}"
            bytes_count /= 1024.0
        return f"{bytes_count:.1f} PB"