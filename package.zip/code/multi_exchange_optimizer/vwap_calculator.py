"""
VWAP Calculator
Volume-Weighted Average Price hesaplama ve analizi
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import logging
from collections import defaultdict, deque
from config import ExchangeConfig

@dataclass
class TradeData:
    """Trade verisi"""
    venue: str
    timestamp: datetime
    price: float
    quantity: float
    side: str  # 'buy' or 'sell'
    trade_id: str
    is_taker: bool = True
    
@dataclass
class VWAPResult:
    """VWAP hesaplama sonucu"""
    symbol: str
    window_start: datetime
    window_end: datetime
    vwap: float
    total_volume: float
    total_value: float
    venue_breakdown: Dict[str, Dict]
    time_breakdown: Dict[datetime, float]
    price_range: Tuple[float, float]
    volume_profile: Dict[float, float]
    
@dataclass
class VolumeAnalysis:
    """Volume analizi"""
    venue: str
    total_volume: float
    avg_trade_size: float
    trade_frequency: float
    volume_concentration: float
    time_distribution: Dict[str, float]  # hour -> volume percentage
    price_impact_factor: float

class VWAPCalculator:
    """Volume-Weighted Average Price hesaplayıcısı"""
    
    def __init__(self, config: ExchangeConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Trade data storage
        self.trade_history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=10000))
        self.venue_trades: Dict[str, Dict[str, deque]] = defaultdict(
            lambda: defaultdict(lambda: deque(maxlen=5000))
        )
        
        # VWAP calculation cache
        self.vwap_cache: Dict[str, VWAPResult] = {}
        self.cache_ttl = 300  # 5 minutes
        
        # Volume analysis
        self.volume_profiles: Dict[str, VolumeAnalysis] = {}
        
        # Rolling calculations
        self.rolling_windows = [1, 5, 15, 30, 60]  # minutes
        self.max_window_hours = 24
        
    def add_trade_data(self, trade: TradeData):
        """Trade verisi ekle"""
        
        # Add to main history
        self.trade_history[trade.symbol].append(trade)
        
        # Add to venue-specific history
        self.venue_trades[trade.symbol][trade.venue].append(trade)
        
        # Update volume analysis
        self._update_volume_analysis(trade.symbol, trade)
        
        # Invalidate VWAP cache
        if trade.symbol in self.vwap_cache:
            del self.vwap_cache[trade.symbol]
    
    def _update_volume_analysis(self, symbol: str, trade: TradeData):
        """Volume analizini güncelle"""
        
        if symbol not in self.volume_profiles:
            self.volume_profiles[symbol] = VolumeAnalysis(
                venue=trade.venue,
                total_volume=0,
                avg_trade_size=0,
                trade_frequency=0,
                volume_concentration=0,
                time_distribution={},
                price_impact_factor=0
            )
        
        analysis = self.volume_profiles[symbol]
        
        # Update basic metrics
        old_total = analysis.total_volume
        analysis.total_volume += trade.quantity
        
        # Update average trade size
        if old_total > 0:
            analysis.avg_trade_size = (
                (analysis.avg_trade_size * old_total + trade.quantity * trade.price) / 
                analysis.total_volume
            )
        else:
            analysis.avg_trade_size = trade.quantity
        
        # Update time distribution
        hour = trade.timestamp.hour
        if hour not in analysis.time_distribution:
            analysis.time_distribution[hour] = 0
        analysis.time_distribution[hour] += trade.quantity
    
    def calculate_vwap(self, symbol: str, window_minutes: int = 60, 
                      start_time: Optional[datetime] = None,
                      venue_filter: Optional[List[str]] = None) -> Optional[VWAPResult]:
        """VWAP hesapla"""
        
        # Check cache first
        cache_key = f"{symbol}_{window_minutes}_{start_time}_{venue_filter}"
        if cache_key in self.vwap_cache:
            cached_result = self.vwap_cache[cache_key]
            if datetime.now() - cached_result.window_end < timedelta(seconds=self.cache_ttl):
                return cached_result
        
        # Get trade data
        trades = self._get_trades_in_window(symbol, window_minutes, start_time, venue_filter)
        
        if not trades:
            return None
        
        # Calculate VWAP
        result = self._calculate_vwap_result(trades, symbol, window_minutes, start_time)
        
        # Cache result
        self.vwap_cache[cache_key] = result
        
        return result
    
    def _get_trades_in_window(self, symbol: str, window_minutes: int, 
                            start_time: Optional[datetime],
                            venue_filter: Optional[List[str]]) -> List[TradeData]:
        """Belirtilen zaman aralığındaki trade'leri al"""
        
        # Default to current time if not specified
        if start_time is None:
            start_time = datetime.now()
        
        # Calculate window boundaries
        window_start = start_time - timedelta(minutes=window_minutes)
        
        # Get trades from history
        trades = []
        for trade in self.trade_history.get(symbol, []):
            # Time filter
            if trade.timestamp < window_start or trade.timestamp > start_time:
                continue
            
            # Venue filter
            if venue_filter and trade.venue not in venue_filter:
                continue
            
            trades.append(trade)
        
        return sorted(trades, key=lambda x: x.timestamp)
    
    def _calculate_vwap_result(self, trades: List[TradeData], symbol: str,
                             window_minutes: int, start_time: Optional[datetime]) -> VWAPResult:
        
        # Calculate basic VWAP
        total_volume = sum(trade.quantity for trade in trades)
        total_value = sum(trade.quantity * trade.price for trade in trades)
        
        vwap = total_value / total_volume if total_volume > 0 else 0
        
        # Venue breakdown
        venue_breakdown = self._calculate_venue_breakdown(trades)
        
        # Time breakdown (hourly)
        time_breakdown = self._calculate_time_breakdown(trades)
        
        # Price range
        prices = [trade.price for trade in trades]
        price_range = (min(prices), max(prices)) if prices else (0, 0)
        
        # Volume profile (price vs volume)
        volume_profile = self._calculate_volume_profile(trades)
        
        # Calculate window boundaries
        if trades:
            window_end = trades[-1].timestamp
            window_start = trades[0].timestamp
        else:
            window_end = start_time or datetime.now()
            window_start = window_end - timedelta(minutes=window_minutes)
        
        return VWAPResult(
            symbol=symbol,
            window_start=window_start,
            window_end=window_end,
            vwap=vwap,
            total_volume=total_volume,
            total_value=total_value,
            venue_breakdown=venue_breakdown,
            time_breakdown=time_breakdown,
            price_range=price_range,
            volume_profile=volume_profile
        )
    
    def _calculate_venue_breakdown(self, trades: List[TradeData]) -> Dict[str, Dict]:
        """Venue bazında breakdown"""
        breakdown = defaultdict(lambda: {
            'volume': 0,
            'value': 0,
            'trade_count': 0,
            'avg_price': 0,
            'vwap_contribution': 0
        })
        
        for trade in trades:
            venue_data = breakdown[trade.venue]
            venue_data['volume'] += trade.quantity
            venue_data['value'] += trade.quantity * trade.price
            venue_data['trade_count'] += 1
        
        # Calculate derived metrics
        for venue, data in breakdown.items():
            data['avg_price'] = data['value'] / data['volume'] if data['volume'] > 0 else 0
            data['vwap_contribution'] = data['value']
        
        # Convert to regular dict
        return dict(breakdown)
    
    def _calculate_time_breakdown(self, trades: List[TradeData]) -> Dict[datetime, float]:
        """Zaman bazında breakdown (saatlik)"""
        time_volumes = defaultdict(float)
        
        for trade in trades:
            hour_timestamp = trade.timestamp.replace(minute=0, second=0, microsecond=0)
            time_volumes[hour_timestamp] += trade.quantity
        
        return dict(time_volumes)
    
    def _calculate_volume_profile(self, trades: List[TradeData]) -> Dict[float, float]:
        """Volume profili (fiyat vs volume)"""
        price_bins = np.linspace(
            min(trade.price for trade in trades) if trades else 0,
            max(trade.price for trade in trades) if trades else 1,
            20  # 20 price bins
        )
        
        profile = {}
        
        for i in range(len(price_bins) - 1):
            bin_start = price_bins[i]
            bin_end = price_bins[i + 1]
            bin_volume = sum(
                trade.quantity for trade in trades
                if bin_start <= trade.price < bin_end
            )
            profile[(bin_start + bin_end) / 2] = bin_volume
        
        return profile
    
    def calculate_rolling_vwap(self, symbol: str, window_minutes: int = 60,
                             step_minutes: int = 5) -> List[VWAPResult]:
        """Rolling VWAP hesaplama"""
        
        results = []
        current_time = datetime.now()
        
        # Calculate multiple rolling windows
        for start_offset in range(0, window_minutes, step_minutes):
            window_end = current_time - timedelta(minutes=start_offset)
            window_start = window_end - timedelta(minutes=step_minutes)
            
            trades = self._get_trades_in_window(
                symbol, window_minutes, window_end, None
            )
            
            # Filter to specific time slice
            slice_trades = [
                trade for trade in trades
                if window_start <= trade.timestamp <= window_end
            ]
            
            if slice_trades:
                result = self._calculate_vwap_result(slice_trades, symbol, step_minutes, window_end)
                results.append(result)
        
        return results
    
    def calculate_cross_venue_vwap(self, symbol: str, window_minutes: int = 60) -> Dict[str, VWAPResult]:
        """Cross-venue VWAP karşılaştırması"""
        
        results = {}
        
        # Calculate VWAP for each venue
        for venue_name in self.config.VENUES.keys():
            if venue_name not in self.venue_trades.get(symbol, {}):
                continue
            
            vwap_result = self.calculate_vwap(symbol, window_minutes, venue_filter=[venue_name])
            if vwap_result:
                results[venue_name] = vwap_result
        
        # Calculate overall VWAP
        overall_vwap = self.calculate_vwap(symbol, window_minutes)
        if overall_vwap:
            results['overall'] = overall_vwap
        
        return results
    
    def calculate_vwap_deviation(self, symbol: str, window_minutes: int = 60,
                               price_source: str = 'current_market') -> Dict[str, float]:
        """VWAP'tan sapma hesaplama"""
        
        vwap_result = self.calculate_vwap(symbol, window_minutes)
        if not vwap_result:
            return {}
        
        vwap_price = vwap_result.vwap
        
        # Get current market price (simulated)
        current_price = self._get_current_market_price(symbol)
        
        deviations = {}
        
        if current_price:
            # Price deviation from VWAP
            absolute_deviation = abs(current_price - vwap_price)
            percentage_deviation = (absolute_deviation / vwap_price) * 100
            
            deviations['current_price'] = current_price
            deviations['vwap_price'] = vwap_price
            deviations['absolute_deviation'] = absolute_deviation
            deviations['percentage_deviation'] = percentage_deviation
        
        # Venue-specific deviations
        for venue_name, venue_data in vwap_result.venue_breakdown.items():
            venue_price = venue_data['avg_price']
            absolute_dev = abs(venue_price - vwap_price)
            percentage_dev = (absolute_dev / vwap_price) * 100 if vwap_price > 0 else 0
            
            deviations[f'{venue_name}_deviation'] = percentage_dev
        
        return deviations
    
    def _get_current_market_price(self, symbol: str) -> Optional[float]:
        """Mevcut piyasa fiyatını al"""
        # In a real implementation, this would get live market data
        # For now, return the most recent trade price
        trades = list(self.trade_history.get(symbol, []))
        if trades:
            return trades[-1].price
        return None
    
    def get_volume_analysis(self, symbol: str) -> Dict[str, VolumeAnalysis]:
        """Volume analizi"""
        
        analysis = {}
        
        # Overall analysis
        if symbol in self.volume_profiles:
            analysis['overall'] = self.volume_profiles[symbol]
        
        # Venue-specific analysis
        for venue_name, venue_trades in self.venue_trades.get(symbol, {}).items():
            if not venue_trades:
                continue
            
            venue_analysis = self._calculate_venue_volume_analysis(venue_name, list(venue_trades))
            analysis[venue_name] = venue_analysis
        
        return analysis
    
    def _calculate_venue_volume_analysis(self, venue_name: str, trades: List[TradeData]) -> VolumeAnalysis:
        """Venue-specific volume analizi"""
        
        total_volume = sum(trade.quantity for trade in trades)
        
        # Average trade size
        avg_trade_size = total_volume / len(trades) if trades else 0
        
        # Trade frequency (trades per hour)
        if trades:
            time_span = (trades[-1].timestamp - trades[0].timestamp).total_seconds() / 3600
            trade_frequency = len(trades) / max(1, time_span)
        else:
            trade_frequency = 0
        
        # Volume concentration (Herfindahl-Hirschman Index)
        if total_volume > 0:
            venue_volumes = {}
            for trade in trades:
                if trade.venue not in venue_volumes:
                    venue_volumes[trade.venue] = 0
                venue_volumes[trade.venue] += trade.quantity
            
            concentration = sum((vol / total_volume) ** 2 for vol in venue_volumes.values())
        else:
            concentration = 0
        
        # Time distribution
        time_dist = {}
        for trade in trades:
            hour = trade.timestamp.hour
            if hour not in time_dist:
                time_dist[hour] = 0
            time_dist[hour] += trade.quantity
        
        # Normalize time distribution to percentages
        if total_volume > 0:
            time_dist = {hour: (vol / total_volume) * 100 for hour, vol in time_dist.items()}
        
        # Price impact factor (volume vs price change)
        price_impact_factor = self._calculate_price_impact_factor(trades)
        
        return VolumeAnalysis(
            venue=venue_name,
            total_volume=total_volume,
            avg_trade_size=avg_trade_size,
            trade_frequency=trade_frequency,
            volume_concentration=concentration,
            time_distribution=time_dist,
            price_impact_factor=price_impact_factor
        )
    
    def _calculate_price_impact_factor(self, trades: List[TradeData]) -> float:
        """Price impact faktörü hesapla"""
        if len(trades) < 2:
            return 0
        
        # Calculate correlation between trade size and price change
        prices = [trade.price for trade in trades]
        volumes = [trade.quantity for trade in trades]
        
        if len(prices) != len(volumes) or len(prices) < 2:
            return 0
        
        # Calculate price changes
        price_changes = [prices[i] - prices[i-1] for i in range(1, len(prices))]
        trade_sizes = volumes[1:]  # Exclude first volume as there's no previous price
        
        if len(price_changes) != len(trade_sizes) or len(price_changes) == 0:
            return 0
        
        # Simple correlation (abs values to capture impact magnitude)
        correlation = np.corrcoef([abs(pc) for pc in price_changes], trade_sizes)[0, 1]
        
        return correlation if not np.isnan(correlation) else 0
    
    def generate_vwap_report(self, symbol: str, window_minutes: int = 60) -> Dict:
        """VWAP raporu oluştur"""
        
        report = {
            'symbol': symbol,
            'timestamp': datetime.now(),
            'window_minutes': window_minutes,
            'vwap_analysis': {},
            'cross_venue_comparison': {},
            'deviation_analysis': {},
            'volume_insights': {}
        }
        
        # Main VWAP analysis
        vwap_result = self.calculate_vwap(symbol, window_minutes)
        if vwap_result:
            report['vwap_analysis'] = {
                'vwap_price': vwap_result.vwap,
                'total_volume': vwap_result.total_volume,
                'total_value': vwap_result.total_value,
                'price_range': vwap_result.price_range,
                'trade_count': sum(data['trade_count'] for data in vwap_result.venue_breakdown.values())
            }
        
        # Cross-venue comparison
        cross_venue_results = self.calculate_cross_venue_vwap(symbol, window_minutes)
        if cross_venue_results:
            comparison = {}
            for venue, result in cross_venue_results.items():
                comparison[venue] = {
                    'vwap_price': result.vwap,
                    'volume': result.total_volume,
                    'market_share': (result.total_volume / sum(r.total_volume for r in cross_venue_results.values())) * 100
                }
            report['cross_venue_comparison'] = comparison
        
        # Deviation analysis
        deviation_analysis = self.calculate_vwap_deviation(symbol, window_minutes)
        if deviation_analysis:
            report['deviation_analysis'] = deviation_analysis
        
        # Volume insights
        volume_analysis = self.get_volume_analysis(symbol)
        if volume_analysis:
            insights = {}
            for venue, analysis in volume_analysis.items():
                insights[venue] = {
                    'total_volume': analysis.total_volume,
                    'avg_trade_size': analysis.avg_trade_size,
                    'trade_frequency_per_hour': analysis.trade_frequency,
                    'volume_concentration': analysis.volume_concentration,
                    'top_hours': sorted(analysis.time_distribution.items(), 
                                      key=lambda x: x[1], reverse=True)[:3]
                }
            report['volume_insights'] = insights
        
        return report
    
    def simulate_trade_impact(self, symbol: str, trade_quantity: float,
                            trade_venue: str = 'best_venue') -> Dict:
        """Trade impact simülasyonu"""
        
        # Get recent VWAP data
        vwap_result = self.calculate_vwap(symbol, 60)
        if not vwap_result:
            return {'error': 'Insufficient data for impact analysis'}
        
        current_vwap = vwap_result.vwap
        total_recent_volume = vwap_result.total_volume
        
        # Estimate impact based on trade size relative to recent volume
        volume_ratio = trade_quantity / max(total_recent_volume, 1)
        
        # Simple market impact model
        # Impact = k * (trade_volume / market_volume)^alpha
        impact_coefficient = 0.01  # 1% base impact
        impact_exponent = 0.5
        
        estimated_impact = impact_coefficient * (volume_ratio ** impact_exponent)
        
        # Price change estimation
        estimated_price_change = current_vwap * estimated_impact
        
        # Venue-specific considerations
        venue_impact_adjustment = 1.0
        if trade_venue in vwap_result.venue_breakdown:
            venue_volume = vwap_result.venue_breakdown[trade_venue]['volume']
            venue_volume_ratio = trade_quantity / max(venue_volume, 1)
            venue_impact_adjustment = min(1.5, 1 + venue_volume_ratio)
        
        adjusted_impact = estimated_impact * venue_impact_adjustment
        
        return {
            'symbol': symbol,
            'trade_quantity': trade_quantity,
            'current_vwap': current_vwap,
            'estimated_impact_percent': adjusted_impact * 100,
            'estimated_price_change': estimated_price_change,
            'new_expected_price': current_vwap + estimated_price_change,
            'volume_ratio': volume_ratio,
            'impact_model': {
                'coefficient': impact_coefficient,
                'exponent': impact_exponent,
                'venue_adjustment': venue_impact_adjustment
            },
            'warnings': self._generate_impact_warnings(volume_ratio, adjusted_impact)
        }
    
    def _generate_impact_warnings(self, volume_ratio: float, impact: float) -> List[str]:
        """Impact uyarıları oluştur"""
        warnings = []
        
        if volume_ratio > 0.1:  # Trade > 10% of recent volume
            warnings.append("Large trade relative to recent volume - significant impact expected")
        
        if volume_ratio > 0.2:  # Trade > 20% of recent volume
            warnings.append("Very large trade - consider splitting into smaller orders")
        
        if impact > 0.02:  # Impact > 2%
            warnings.append("High price impact predicted - review order size and timing")
        
        if impact > 0.05:  # Impact > 5%
            warnings.append("Severe price impact - strongly consider order splitting or venue selection")
        
        return warnings