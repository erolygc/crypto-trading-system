"""
Venue Constraints Manager
Borsa-spesifik kısıtlamalar ve kuralları yönetir
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass
from enum import Enum
import logging
from datetime import datetime, timedelta
from config import ExchangeConfig, VenueConfig

class ConstraintType(Enum):
    """Kısıtlama türleri"""
    ORDER_SIZE = "order_size"
    ORDER_FREQUENCY = "order_frequency"
    VOLUME = "volume"
    TRADING_HOURS = "trading_hours"
    GEOGRAPHIC = "geographic"
    ASSET_RESTRICTION = "asset_restriction"
    API_RATE = "api_rate"
    LATENCY = "latency"
    LIQUIDITY = "liquidity"
    REGULATORY = "regulatory"

@dataclass
class VenueConstraint:
    """Venue kısıtlama yapısı"""
    venue_name: str
    constraint_type: ConstraintType
    limit_value: float
    current_usage: float = 0.0
    time_window: Optional[timedelta] = None
    description: str = ""
    severity: str = "normal"  # normal, warning, critical
    last_reset: Optional[datetime] = None
    
@dataclass
class ConstraintViolation:
    """Kısıtlama ihlali"""
    venue_name: str
    constraint_type: ConstraintType
    current_value: float
    limit_value: float
    violation_severity: str
    timestamp: datetime
    recommended_action: str

class VenueConstraintManager:
    """Venue kısıtlama yöneticisi"""
    
    def __init__(self, config: ExchangeConfig):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Kısıtlamaları yükle
        self.constraints: Dict[str, Dict[ConstraintType, VenueConstraint]] = {}
        self._initialize_constraints()
        
        # Kullanım geçmişi
        self.usage_history: Dict[str, List[Tuple[datetime, float]]] = {}
        
        # Violation tracking
        self.violations: List[ConstraintViolation] = []
        
        # Circuit breakers
        self.circuit_breakers: Dict[str, bool] = {}
        
    def _initialize_constraints(self):
        """Tüm venue'lar için kısıtlamaları başlat"""
        for venue_name, venue_config in self.config.VENUES.items():
            if not venue_config.enabled:
                continue
                
            self.constraints[venue_name] = {}
            
            # Order size constraints
            self.constraints[venue_name][ConstraintType.ORDER_SIZE] = VenueConstraint(
                venue_name=venue_name,
                constraint_type=ConstraintType.ORDER_SIZE,
                limit_value=venue_config.max_trade_size,
                description=f"Maximum order size: {venue_config.max_trade_size}",
                time_window=timedelta(seconds=1)
            )
            
            # Volume constraints (daily)
            daily_volume_limit = venue_config.rate_limit * 1000  # Volume per day estimate
            self.constraints[venue_name][ConstraintType.VOLUME] = VenueConstraint(
                venue_name=venue_name,
                constraint_type=ConstraintType.VOLUME,
                limit_value=daily_volume_limit,
                description=f"Daily volume limit: {daily_volume_limit}",
                time_window=timedelta(days=1)
            )
            
            # API rate constraints
            self.constraints[venue_name][ConstraintType.API_RATE] = VenueConstraint(
                venue_name=venue_name,
                constraint_type=ConstraintType.API_RATE,
                limit_value=venue_config.rate_limit,
                description=f"API rate limit: {venue_config.rate_limit} req/min",
                time_window=timedelta(minutes=1)
            )
            
            # Latency constraints
            self.constraints[venue_name][ConstraintType.LATENCY] = VenueConstraint(
                venue_name=venue_name,
                constraint_type=ConstraintType.LATENCY,
                limit_value=venue_config.latency_threshold,
                description=f"Maximum acceptable latency: {venue_config.latency_threshold}ms",
                time_window=timedelta(seconds=10)
            )
            
            # Trading hours (simulated - some venues may have restrictions)
            if venue_config.type.value == "dex":
                # DEX'ler genellikle 7/24 açık
                trading_hours = (0, 24)  # 24/7
            else:
                # CEX'ler genellikle 24/7 açık ancak maintenance olabilir
                trading_hours = (0, 24)
            
            self.constraints[venue_name][ConstraintType.TRADING_HOURS] = VenueConstraint(
                venue_name=venue_name,
                constraint_type=ConstraintType.TRADING_HOURS,
                limit_value=sum(trading_hours),
                description=f"Trading hours: {trading_hours[0]}:00-{trading_hours[1]}:00",
                time_window=timedelta(days=1)
            )
            
            # Asset restrictions
            if "university" in venue_name.lower():
                # Uniswap'ın restricted assets policy simülasyonu
                restricted_assets = ["USDC", "DAI", "USDT"]  # Stablecoin lisansları
                self.constraints[venue_name][ConstraintType.ASSET_RESTRICTION] = VenueConstraint(
                    venue_name=venue_name,
                    constraint_type=ConstraintType.ASSET_RESTRICTION,
                    limit_value=len(restricted_assets),
                    description=f"Restricted assets: {restricted_assets}",
                    time_window=timedelta(days=1)
                )
            
    def check_constraints(self, venue_name: str, trade_size: float, 
                         order_frequency: int = 1, 
                         symbol: Optional[str] = None) -> Tuple[bool, List[str]]:
        """Kısıtlama kontrolü"""
        
        if venue_name not in self.constraints:
            return False, [f"No constraints defined for venue: {venue_name}"]
        
        violations = []
        venue_config = self.config.VENUES.get(venue_name)
        
        # Circuit breaker check
        if self.circuit_breakers.get(venue_name, False):
            violations.append(f"Circuit breaker active for {venue_name}")
            return False, violations
        
        # Order size check
        size_constraint = self.constraints[venue_name][ConstraintType.ORDER_SIZE]
        if trade_size > size_constraint.limit_value:
            violations.append(
                f"Order size {trade_size} exceeds limit {size_constraint.limit_value} for {venue_name}"
            )
        
        # Minimum order size check
        if trade_size < venue_config.min_trade_size:
            violations.append(
                f"Order size {trade_size} below minimum {venue_config.min_trade_size} for {venue_name}"
            )
        
        # API rate check
        rate_constraint = self.constraints[venue_name][ConstraintType.API_RATE]
        current_rate_usage = self._calculate_api_usage(venue_name)
        if current_rate_usage + order_frequency > rate_constraint.limit_value:
            violations.append(
                f"API rate would exceed limit {rate_constraint.limit_value} for {venue_name}"
            )
        
        # Volume check
        volume_constraint = self.constraints[venue_name][ConstraintType.VOLUME]
        current_volume = self._calculate_volume_usage(venue_name)
        if current_volume + trade_size > volume_constraint.limit_value:
            violations.append(
                f"Volume would exceed daily limit {volume_constraint.limit_value} for {venue_name}"
            )
        
        # Asset restriction check
        if symbol and ConstraintType.ASSET_RESTRICTION in self.constraints[venue_name]:
            asset_constraint = self.constraints[venue_name][ConstraintType.ASSET_RESTRICTION]
            if self._is_restricted_asset(venue_name, symbol):
                violations.append(f"Asset {symbol} restricted for {venue_name}")
        
        # Latency check
        if hasattr(self, 'price_aggregator'):
            avg_latency = self.price_aggregator.latency_tracker.get_avg_latency(venue_name)
            latency_constraint = self.constraints[venue_name][ConstraintType.LATENCY]
            if avg_latency > latency_constraint.limit_value:
                violations.append(
                    f"Latency {avg_latency}ms exceeds threshold {latency_constraint.limit_value}ms for {venue_name}"
                )
        
        is_valid = len(violations) == 0
        
        if not is_valid:
            self._log_violations(venue_name, violations)
        
        return is_valid, violations
    
    def update_constraint_usage(self, venue_name: str, constraint_type: ConstraintType, 
                              usage_value: float, timestamp: Optional[datetime] = None):
        """Kısıtlama kullanımını güncelle"""
        
        if venue_name not in self.constraints:
            return
        
        if constraint_type not in self.constraints[venue_name]:
            return
        
        current_time = timestamp or datetime.now()
        constraint = self.constraints[venue_name][constraint_type]
        
        # Reset if time window passed
        if (constraint.time_window and constraint.last_reset and 
            current_time - constraint.last_reset > constraint.time_window):
            constraint.current_usage = 0
            constraint.last_reset = current_time
        
        # Update usage
        constraint.current_usage += usage_value
        
        # Store in history
        if venue_name not in self.usage_history:
            self.usage_history[venue_name] = []
        self.usage_history[venue_name].append((current_time, usage_value))
        
        # Clean old history (keep last 24 hours)
        cutoff_time = current_time - timedelta(hours=24)
        self.usage_history[venue_name] = [
            (ts, val) for ts, val in self.usage_history[venue_name] 
            if ts > cutoff_time
        ]
        
        # Check for threshold violations
        if constraint.current_usage > constraint.limit_value:
            severity = "critical" if constraint.current_usage > constraint.limit_value * 1.1 else "warning"
            constraint.severity = severity
            
            violation = ConstraintViolation(
                venue_name=venue_name,
                constraint_type=constraint_type,
                current_value=constraint.current_usage,
                limit_value=constraint.limit_value,
                violation_severity=severity,
                timestamp=current_time,
                recommended_action=self._get_recommended_action(venue_name, constraint_type)
            )
            self.violations.append(violation)
            
            # Activate circuit breaker for critical violations
            if severity == "critical" and constraint_type in [ConstraintType.API_RATE, ConstraintType.VOLUME]:
                self._activate_circuit_breaker(venue_name)
    
    def _calculate_api_usage(self, venue_name: str, window_minutes: int = 1) -> int:
        """API kullanımını hesapla"""
        if venue_name not in self.usage_history:
            return 0
        
        current_time = datetime.now()
        window_start = current_time - timedelta(minutes=window_minutes)
        
        usage_count = sum(
            1 for ts, val in self.usage_history.get(venue_name, [])
            if ts > window_start and ConstraintType.API_RATE.value in str(val)
        )
        
        return usage_count
    
    def _calculate_volume_usage(self, venue_name: str, window_days: int = 1) -> float:
        """Volume kullanımını hesapla"""
        if venue_name not in self.usage_history:
            return 0.0
        
        current_time = datetime.now()
        window_start = current_time - timedelta(days=window_days)
        
        total_volume = sum(
            val for ts, val in self.usage_history.get(venue_name, [])
            if ts > window_start
        )
        
        return total_volume
    
    def _is_restricted_asset(self, venue_name: str, symbol: str) -> bool:
        """Asset kısıtlaması kontrolü"""
        # Simplified asset restriction check
        restricted_patterns = [
            "PEPE", "SHIB", "DOGE"  # Örnek restricted tokens
        ]
        
        return any(pattern in symbol.upper() for pattern in restricted_patterns)
    
    def _log_violations(self, venue_name: str, violations: List[str]):
        """Kısıtlama ihlallerini logla"""
        for violation in violations:
            self.logger.warning(f"Constraint violation at {venue_name}: {violation}")
    
    def _get_recommended_action(self, venue_name: str, constraint_type: ConstraintType) -> str:
        """Tavsiye edilen aksiyon"""
        actions = {
            ConstraintType.ORDER_SIZE: f"Reduce order size or split into smaller orders for {venue_name}",
            ConstraintType.API_RATE: f"Implement rate limiting or reduce API calls for {venue_name}",
            ConstraintType.VOLUME: f"Wait for volume reset or reduce trading volume for {venue_name}",
            ConstraintType.LATENCY: f"Check network connectivity or switch to faster venue",
            ConstraintType.TRADING_HOURS: f"Wait for trading hours to resume for {venue_name}",
            ConstraintType.ASSET_RESTRICTION: f"Use alternative venue for this asset or remove asset"
        }
        
        return actions.get(constraint_type, f"Review constraints for {venue_name}")
    
    def _activate_circuit_breaker(self, venue_name: str):
        """Circuit breaker aktifleştir"""
        self.circuit_breakers[venue_name] = True
        self.logger.critical(f"Circuit breaker activated for {venue_name}")
        
        # Auto-reset after 1 hour
        def reset_circuit_breaker():
            import threading
            def delayed_reset():
                import time
                time.sleep(3600)  # 1 hour
                self.circuit_breakers[venue_name] = False
                self.logger.info(f"Circuit breaker reset for {venue_name}")
            
            thread = threading.Thread(target=delayed_reset)
            thread.daemon = True
            thread.start()
        
        reset_circuit_breaker()
    
    def get_constraint_status(self, venue_name: str) -> Dict:
        """Venue kısıtlama durumunu al"""
        if venue_name not in self.constraints:
            return {}
        
        status = {
            'venue': venue_name,
            'circuit_breaker': self.circuit_breakers.get(venue_name, False),
            'constraints': {}
        }
        
        for constraint_type, constraint in self.constraints[venue_name].items():
            status['constraints'][constraint_type.value] = {
                'current_usage': constraint.current_usage,
                'limit_value': constraint.limit_value,
                'usage_percentage': (constraint.current_usage / constraint.limit_value * 100) if constraint.limit_value > 0 else 0,
                'severity': constraint.severity,
                'description': constraint.description,
                'time_window': str(constraint.time_window) if constraint.time_window else None
            }
        
        return status
    
    def get_all_constraint_status(self) -> Dict:
        """Tüm venue'lar için kısıtlama durumu"""
        return {
            venue_name: self.get_constraint_status(venue_name)
            for venue_name in self.constraints.keys()
        }
    
    def optimize_with_constraints(self, desired_allocation: Dict[str, float], 
                                trade_size: float, symbol: str) -> Dict[str, float]:
        """Kısıtlamalar dahilinde allocation optimize et"""
        
        optimized_allocation = {}
        remaining_size = trade_size
        
        # Sort venues by priority and constraint availability
        sorted_venues = sorted(
            self.constraints.keys(),
            key=lambda v: self.config.VENUES[v].priority
        )
        
        for venue_name in sorted_venues:
            if remaining_size <= 0:
                break
            
            # Check if venue can handle this trade
            is_valid, violations = self.check_constraints(venue_name, remaining_size, symbol=symbol)
            
            if is_valid and remaining_size > 0:
                # Calculate maximum possible allocation
                size_constraint = self.constraints[venue_name][ConstraintType.ORDER_SIZE]
                max_possible = min(
                    remaining_size,
                    size_constraint.limit_value - size_constraint.current_usage
                )
                
                if max_possible > 0:
                    optimized_allocation[venue_name] = max_possible
                    remaining_size -= max_possible
                    
                    # Update constraint usage
                    self.update_constraint_usage(
                        venue_name, ConstraintType.ORDER_SIZE, max_possible
                    )
                    self.update_constraint_usage(
                        venue_name, ConstraintType.VOLUME, max_possible
                    )
        
        # If we couldn't allocate the full amount, return what we have
        if remaining_size > 0:
            self.logger.warning(f"Could not allocate full trade size. Remaining: {remaining_size}")
        
        # Normalize allocation
        total_allocated = sum(optimized_allocation.values())
        if total_allocated > 0:
            optimized_allocation = {
                k: v / total_allocated for k, v in optimized_allocation.items()
            }
        
        return optimized_allocation
    
    def reset_constraints(self, venue_name: Optional[str] = None):
        """Kısıtlamaları sıfırla"""
        if venue_name:
            if venue_name in self.constraints:
                for constraint in self.constraints[venue_name].values():
                    constraint.current_usage = 0
                    constraint.last_reset = datetime.now()
                    constraint.severity = "normal"
            
            if venue_name in self.circuit_breakers:
                self.circuit_breakers[venue_name] = False
        else:
            # Reset all
            for venue_constraints in self.constraints.values():
                for constraint in venue_constraints.values():
                    constraint.current_usage = 0
                    constraint.last_reset = datetime.now()
                    constraint.severity = "normal"
            
            self.circuit_breakers.clear()
        
        self.logger.info(f"Constraints reset for venue: {venue_name or 'all'}")
    
    def get_constraint_report(self) -> Dict:
        """Kısıtlama raporu"""
        report = {
            'timestamp': datetime.now(),
            'venues': {},
            'violations': [],
            'circuit_breakers': [],
            'summary': {}
        }
        
        # Venue status
        for venue_name in self.constraints.keys():
            report['venues'][venue_name] = self.get_constraint_status(venue_name)
        
        # Recent violations (last 24 hours)
        cutoff_time = datetime.now() - timedelta(hours=24)
        recent_violations = [
            v for v in self.violations if v.timestamp > cutoff_time
        ]
        
        for violation in recent_violations:
            report['violations'].append({
                'venue': violation.venue_name,
                'type': violation.constraint_type.value,
                'current_value': violation.current_value,
                'limit_value': violation.limit_value,
                'severity': violation.violation_severity,
                'timestamp': violation.timestamp.isoformat(),
                'action': violation.recommended_action
            })
        
        # Active circuit breakers
        for venue_name, active in self.circuit_breakers.items():
            if active:
                report['circuit_breakers'].append(venue_name)
        
        # Summary statistics
        report['summary'] = {
            'total_venues': len(self.constraints),
            'active_venues': len([v for v in self.constraints.keys() 
                                if not self.circuit_breakers.get(v, False)]),
            'total_violations_24h': len(recent_violations),
            'critical_violations': len([v for v in recent_violations 
                                      if v.violation_severity == 'critical']),
            'circuit_breakers_active': len(report['circuit_breakers'])
        }
        
        return report