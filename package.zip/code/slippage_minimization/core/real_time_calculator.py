"""
Real-time Slippage Calculation Module
Anlık slippage hesaplamaları ve market data analizi
"""

import asyncio
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from collections import deque
import time

@dataclass
class SlippageCalculation:
    """Slippage hesaplama sonucu"""
    symbol: str
    predicted_slippage_bps: float
    confidence_score: float
    components: Dict[str, float]
    market_factors: Dict[str, float]
    timestamp: datetime
    calculation_method: str

@dataclass
class MarketSnapshot:
    """Market snapshot"""
    symbol: str
    bid: float
    ask: float
    mid_price: float
    spread_bps: float
    bid_size: float
    ask_size: float
    volume_24h: float
    volatility_1m: float
    volatility_5m: float
    volatility_15m: float
    timestamp: datetime

class RealTimeSlippageCalculator:
    """
    Real-time Slippage Calculator
    Anlık market data ile slippage hesaplamaları
    """
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Calculation parameters
        self.update_frequency_ms = config.update_frequency_ms
        self.max_history_minutes = config.max_history_minutes
        
        # Market data storage
        self.market_snapshots: Dict[str, deque] = {}
        self.price_history: Dict[str, deque] = {}
        self.volume_history: Dict[str, deque] = {}
        
        # Calculation cache
        self.slippage_cache: Dict[str, SlippageCalculation] = {}
        self.last_calculation_time: Dict[str, datetime] = {}
        
        # Market metrics
        self.market_metrics = {
            'volatility_models': {},
            'volume_profiles': {},
            'liquidity_metrics': {}
        }
        
        # Cache settings
        self.cache_ttl_seconds = 5  # 5 seconds cache
        self.max_snapshots_per_symbol = 1000
        
        # Calculation methods
        self.calculation_methods = {
            'spread_based': self._calculate_spread_based_slippage,
            'market_impact': self._calculate_market_impact_slippage,
            'volume_weighted': self._calculate_volume_weighted_slippage,
            'historical_based': self._calculate_historical_based_slippage,
            'hybrid': self._calculate_hybrid_slippage
        }
        
        self.logger.info("Real-time Slippage Calculator oluşturuldu")
    
    async def initialize(self) -> bool:
        """Calculator'ı başlat"""
        try:
            self.logger.info("Real-time Slippage Calculator başlatılıyor...")
            
            # Initialize data structures
            for symbol in ['BTC/USDT', 'ETH/USDT', 'BNB/USDT', 'ADA/USDT']:
                self.market_snapshots[symbol] = deque(maxlen=self.max_snapshots_per_symbol)
                self.price_history[symbol] = deque(maxlen=1000)
                self.volume_history[symbol] = deque(maxlen=1000)
            
            # Initialize volatility models
            await self._initialize_volatility_models()
            
            # Load historical data for calibration
            await self._load_historical_calibration_data()
            
            self.logger.info("Real-time Slippage Calculator başarıyla başlatıldı")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Real-time Calculator başlatma hatası: {e}")
            return False
    
    async def calculate_slippage(self, symbol: str, quantity: float, 
                               side: str, market_data: Dict) -> Optional[SlippageCalculation]:
        """
        Ana slippage hesaplama fonksiyonu
        """
        try:
            # Check cache first
            cache_key = f"{symbol}_{quantity}_{side}"
            
            if cache_key in self.slippage_cache:
                cached_result = self.slippage_cache[cache_key]
                if (datetime.now() - cached_result.timestamp).total_seconds() < self.cache_ttl_seconds:
                    return cached_result
            
            # Get or create market snapshot
            snapshot = await self._create_market_snapshot(symbol, market_data)
            if not snapshot:
                return None
            
            # Add to history
            self._update_history(snapshot, market_data)
            
            # Calculate slippage using multiple methods
            calculations = {}
            
            for method_name, method_func in self.calculation_methods.items():
                try:
                    calc_result = await method_func(symbol, quantity, side, snapshot)
                    if calc_result is not None:
                        calculations[method_name] = calc_result
                except Exception as e:
                    self.logger.warning(f"Slippage calculation method {method_name} hatası: {e}")
            
            if not calculations:
                return None
            
            # Combine results
            final_slippage = self._combine_calculations(calculations)
            
            # Calculate confidence score
            confidence = self._calculate_confidence_score(calculations, snapshot)
            
            # Create result
            result = SlippageCalculation(
                symbol=symbol,
                predicted_slippage_bps=final_slippage,
                confidence_score=confidence,
                components=calculations,
                market_factors=self._extract_market_factors(snapshot),
                timestamp=datetime.now(),
                calculation_method="hybrid"
            )
            
            # Cache result
            self.slippage_cache[cache_key] = result
            self.last_calculation_time[symbol] = datetime.now()
            
            return result
            
        except Exception as e:
            self.logger.error(f"Slippage hesaplama hatası: {e}")
            return None
    
    async def _create_market_snapshot(self, symbol: str, market_data: Dict) -> Optional[MarketSnapshot]:
        """Market snapshot oluştur"""
        try:
            # Extract data from market_data
            order_book = market_data.get('order_book', {})
            price_data = market_data.get('price_data', {})
            
            bids = order_book.get('bids', [])
            asks = order_book.get('asks', [])
            
            if not bids or not asks:
                return None
            
            best_bid = float(bids[0][0])
            best_ask = float(asks[0][0])
            bid_size = float(bids[0][1])
            ask_size = float(asks[0][1])
            
            mid_price = (best_bid + best_ask) / 2
            spread = best_ask - best_bid
            spread_bps = (spread / mid_price) * 10000 if mid_price > 0 else 0
            
            # Volume and volatility from market_data
            volume_24h = market_data.get('volume_24h', 1000000)
            
            volatility_1m = self._calculate_volatility(symbol, 1)
            volatility_5m = self._calculate_volatility(symbol, 5)
            volatility_15m = self._calculate_volatility(symbol, 15)
            
            return MarketSnapshot(
                symbol=symbol,
                bid=best_bid,
                ask=best_ask,
                mid_price=mid_price,
                spread_bps=spread_bps,
                bid_size=bid_size,
                ask_size=ask_size,
                volume_24h=volume_24h,
                volatility_1m=volatility_1m,
                volatility_5m=volatility_5m,
                volatility_15m=volatility_15m,
                timestamp=datetime.now()
            )
            
        except Exception as e:
            self.logger.error(f"Market snapshot oluşturma hatası: {e}")
            return None
    
    def _update_history(self, snapshot: MarketSnapshot, market_data: Dict):
        """History güncelle"""
        symbol = snapshot.symbol
        
        # Add snapshot to history
        self.market_snapshots[symbol].append(snapshot)
        
        # Add price history
        self.price_history[symbol].append({
            'timestamp': snapshot.timestamp,
            'price': snapshot.mid_price,
            'volume': market_data.get('volume', 0)
        })
        
        # Add volume history
        self.volume_history[symbol].append({
            'timestamp': snapshot.timestamp,
            'volume': market_data.get('volume_24h', 0)
        })
    
    async def _calculate_spread_based_slippage(self, symbol: str, quantity: float,
                                             side: str, snapshot: MarketSnapshot) -> float:
        """Spread bazlı slippage hesaplama"""
        # Basic spread-based slippage
        half_spread = snapshot.spread_bps / 2
        
        # Size adjustment based on available liquidity
        if side.lower() == 'buy':
            available_liquidity = snapshot.ask_size
        else:
            available_liquidity = snapshot.bid_size
        
        # Calculate how much of the order will hit the spread
        size_ratio = quantity / max(available_liquidity, 1)
        
        # Additional slippage for larger orders
        size_penalty = min(size_ratio * 0.5, 0.02)  # Max 2%
        
        # Volatility adjustment
        volatility_factor = 1 + snapshot.volatility_5m * 10
        
        # Time of day factor (simplified)
        hour = datetime.now().hour
        if 2 <= hour <= 6:  # Low activity
            time_factor = 1.2
        elif 8 <= hour <= 18:  # High activity
            time_factor = 0.9
        else:
            time_factor = 1.0
        
        total_slippage = (half_spread + size_penalty) * volatility_factor * time_factor
        
        return max(total_slippage, 0)
    
    async def _calculate_market_impact_slippage(self, symbol: str, quantity: float,
                                              side: str, snapshot: MarketSnapshot) -> float:
        """Market impact bazlı slippage hesaplama"""
        # Calculate volume ratio
        avg_volume = self._get_average_volume(symbol)
        volume_ratio = quantity / max(avg_volume, 1)
        
        # Base market impact model
        # Permanent impact
        permanent_impact = 0.1 * (volume_ratio ** 0.5)
        
        # Temporary impact  
        temporary_impact = 0.05 * volume_ratio
        
        # Volatility multiplier
        volatility_multiplier = 1 + snapshot.volatility_15m * 20
        
        # Liquidity adjustment
        total_liquidity = snapshot.bid_size + snapshot.ask_size
        liquidity_factor = 1 + (quantity / max(total_liquidity, 1)) * 0.5
        
        # Market impact slippage
        market_impact_slippage = (permanent_impact + temporary_impact) * volatility_multiplier * liquidity_factor
        
        return max(market_impact_slippage * 10000, 0)  # Convert to bps
    
    async def _calculate_volume_weighted_slippage(self, symbol: str, quantity: float,
                                                side: str, snapshot: MarketSnapshot) -> float:
        """Volume ağırlıklı slippage hesaplama"""
        # Get recent volume profile
        volume_profile = self._get_volume_profile(symbol)
        
        if not volume_profile:
            return 0
        
        # Calculate expected volume during execution
        expected_volume = quantity * 2  # Assume 2x volume during execution
        
        # Find impact based on volume profile
        cumulative_volume = 0
        price_impact = 0
        
        for price_level, volume in volume_profile.items():
            if cumulative_volume + volume >= expected_volume:
                # Calculate impact for this level
                price_diff = abs(price_level - snapshot.mid_price)
                price_impact = (price_diff / snapshot.mid_price) * 10000
                break
            
            cumulative_volume += volume
        
        # Add spread component
        total_slippage = price_impact + snapshot.spread_bps / 2
        
        return max(total_slippage, 0)
    
    async def _calculate_historical_based_slippage(self, symbol: str, quantity: float,
                                                 side: str, snapshot: MarketSnapshot) -> float:
        """Historical data bazlı slippage hesaplama"""
        # Get historical slippage data for similar conditions
        similar_trades = self._find_similar_historical_trades(symbol, quantity, snapshot)
        
        if not similar_trades:
            return await self._calculate_spread_based_slippage(symbol, quantity, side, snapshot)
        
        # Calculate average slippage from similar trades
        similar_slippage = [trade['slippage_bps'] for trade in similar_trades]
        
        if not similar_slippage:
            return 0
        
        # Apply market conditions adjustment
        current_conditions_score = self._assess_market_conditions(snapshot)
        
        # Historical average adjusted for current conditions
        avg_historical_slippage = np.mean(similar_slippage)
        adjusted_slippage = avg_historical_slippage * current_conditions_score
        
        return max(adjusted_slippage, 0)
    
    async def _calculate_hybrid_slippage(self, symbol: str, quantity: float,
                                       side: str, snapshot: MarketSnapshot) -> float:
        """Hybrid slippage hesaplama (en iyi method)"""
        # Calculate all components
        spread_slippage = await self._calculate_spread_based_slippage(symbol, quantity, side, snapshot)
        impact_slippage = await self._calculate_market_impact_slippage(symbol, quantity, side, snapshot)
        volume_slippage = await self._calculate_volume_weighted_slippage(symbol, quantity, side, snapshot)
        historical_slippage = await self._calculate_historical_based_slippage(symbol, quantity, side, snapshot)
        
        # Weighted combination based on data availability and confidence
        weights = {
            'spread': 0.3,
            'impact': 0.3,
            'volume': 0.2,
            'historical': 0.2
        }
        
        # Adjust weights based on data quality
        if len(self.price_history.get(symbol, [])) < 50:
            weights['historical'] = 0.1
            weights['spread'] = 0.4
            weights['impact'] = 0.5
        
        if len(self.volume_history.get(symbol, [])) < 100:
            weights['volume'] = 0.1
            weights['spread'] = 0.4
            weights['impact'] = 0.5
        
        # Calculate weighted average
        hybrid_slippage = (
            weights['spread'] * spread_slippage +
            weights['impact'] * impact_slippage +
            weights['volume'] * volume_slippage +
            weights['historical'] * historical_slippage
        )
        
        return max(hybrid_slippage, 0)
    
    def _combine_calculations(self, calculations: Dict[str, float]) -> float:
        """Slippage hesaplamalarını birleştir"""
        if not calculations:
            return 0
        
        # Use the hybrid method as primary if available
        if 'hybrid' in calculations:
            return calculations['hybrid']
        
        # Otherwise, use weighted average
        weights = {
            'spread_based': 0.3,
            'market_impact': 0.4,
            'volume_weighted': 0.2,
            'historical_based': 0.1
        }
        
        weighted_sum = 0
        total_weight = 0
        
        for method, slippage in calculations.items():
            weight = weights.get(method, 0.1)
            weighted_sum += slippage * weight
            total_weight += weight
        
        return weighted_sum / max(total_weight, 0.1)
    
    def _calculate_confidence_score(self, calculations: Dict[str, float], 
                                  snapshot: MarketSnapshot) -> float:
        """Confidence score hesaplama"""
        base_confidence = 0.5
        
        # Data quality factors
        if snapshot.spread_bps < 20:  # Tight spreads
            base_confidence += 0.2
        
        if snapshot.volatility_15m < 0.05:  # Low volatility
            base_confidence += 0.1
        
        # Historical data availability
        history_length = len(self.price_history.get(snapshot.symbol, []))
        if history_length > 500:
            base_confidence += 0.2
        elif history_length > 100:
            base_confidence += 0.1
        
        # Number of calculation methods
        method_count = len(calculations)
        if method_count >= 4:
            base_confidence += 0.1
        
        return min(base_confidence, 1.0)
    
    def _extract_market_factors(self, snapshot: MarketSnapshot) -> Dict[str, float]:
        """Market faktörlerini çıkar"""
        return {
            'spread_bps': snapshot.spread_bps,
            'volatility_1m': snapshot.volatility_1m,
            'volatility_5m': snapshot.volatility_5m,
            'volatility_15m': snapshot.volatility_15m,
            'bid_size': snapshot.bid_size,
            'ask_size': snapshot.ask_size,
            'liquidity_score': min((snapshot.bid_size + snapshot.ask_size) / 100000, 1.0),
            'volume_ratio': self._get_volume_ratio(snapshot.symbol),
            'market_stress': self._calculate_market_stress(snapshot)
        }
    
    def _calculate_volatility(self, symbol: str, minutes: int) -> float:
        """Volatilite hesaplama"""
        price_data = list(self.price_history.get(symbol, []))
        
        if len(price_data) < 2:
            return 0.02  # Default volatility
        
        # Get price data for specified time window
        cutoff_time = datetime.now() - timedelta(minutes=minutes)
        recent_prices = [
            data['price'] for data in price_data 
            if data['timestamp'] > cutoff_time
        ]
        
        if len(recent_prices) < 2:
            return 0.02
        
        # Calculate returns and volatility
        returns = np.diff(recent_prices) / recent_prices[:-1]
        return np.std(returns)
    
    def _get_average_volume(self, symbol: str, hours: int = 24) -> float:
        """Ortalama hacim"""
        volume_data = list(self.volume_history.get(symbol, []))
        
        if len(volume_data) < 2:
            return 1000000  # Default volume
        
        cutoff_time = datetime.now() - timedelta(hours=hours)
        recent_volumes = [
            data['volume'] for data in volume_data
            if data['timestamp'] > cutoff_time
        ]
        
        return np.mean(recent_volumes) if recent_volumes else 1000000
    
    def _get_volume_profile(self, symbol: str) -> Dict[float, float]:
        """Volume profil analizi (simplified)"""
        # This would analyze order book depth in a real implementation
        # For now, return a basic profile
        snapshot_data = list(self.market_snapshots.get(symbol, []))
        
        if not snapshot_data:
            return {}
        
        latest_snapshot = snapshot_data[-1]
        
        # Create a simple volume profile based on available data
        profile = {
            latest_snapshot.bid: latest_snapshot.bid_size,
            latest_snapshot.ask: latest_snapshot.ask_size,
            latest_snapshot.mid_price * 0.999: latest_snapshot.bid_size * 0.5,
            latest_snapshot.mid_price * 1.001: latest_snapshot.ask_size * 0.5
        }
        
        return profile
    
    def _find_similar_historical_trades(self, symbol: str, quantity: float, 
                                      snapshot: MarketSnapshot) -> List[Dict]:
        """Benzer historical trades bul"""
        # This would search for similar trade conditions in real implementation
        # For now, return empty list (no historical data)
        return []
    
    def _assess_market_conditions(self, snapshot: MarketSnapshot) -> float:
        """Market koşulları değerlendirmesi"""
        conditions_score = 1.0
        
        # Volatility assessment
        if snapshot.volatility_15m > 0.1:
            conditions_score *= 1.5  # High volatility
        elif snapshot.volatility_15m < 0.02:
            conditions_score *= 0.8  # Low volatility
        
        # Spread assessment
        if snapshot.spread_bps > 50:
            conditions_score *= 1.3  # Wide spreads
        
        # Liquidity assessment
        total_liquidity = snapshot.bid_size + snapshot.ask_size
        if total_liquidity < 10000:
            conditions_score *= 1.2  # Low liquidity
        
        return conditions_score
    
    def _get_volume_ratio(self, symbol: str) -> float:
        """Volume ratio hesaplama"""
        avg_volume = self._get_average_volume(symbol)
        # Assume current order size is 1% of average volume
        return 0.01
    
    def _calculate_market_stress(self, snapshot: MarketSnapshot) -> float:
        """Market stress hesaplama"""
        stress_score = 0.0
        
        # Spread-based stress
        if snapshot.spread_bps > 100:
            stress_score += 0.3
        
        # Volatility stress
        if snapshot.volatility_15m > 0.1:
            stress_score += 0.4
        
        # Liquidity stress
        total_liquidity = snapshot.bid_size + snapshot.ask_size
        if total_liquidity < 10000:
            stress_score += 0.3
        
        return min(stress_score, 1.0)
    
    async def _initialize_volatility_models(self):
        """Volatilite modeli başlat"""
        # Initialize placeholder volatility models
        self.market_metrics['volatility_models'] = {
            'garch': True,
            'ewma': True,
            'realized': True
        }
        
        self.logger.info("Volatility models initialized")
    
    async def _load_historical_calibration_data(self):
        """Historical calibration data yükle"""
        # Placeholder for historical data loading
        self.logger.info("Historical calibration data loaded")
    
    async def update_calculations(self, market_data_cache: Dict):
        """Tüm aktif hesaplamaları güncelle"""
        current_time = datetime.now()
        
        symbols_to_update = []
        
        # Find symbols that need updates
        for symbol in market_data_cache.keys():
            last_update = self.last_calculation_time.get(symbol)
            
            if (last_update is None or 
                (current_time - last_update).total_seconds() > self.cache_ttl_seconds):
                symbols_to_update.append(symbol)
        
        # Update calculations in parallel
        if symbols_to_update:
            tasks = []
            for symbol in symbols_to_update:
                market_data = market_data_cache.get(symbol, {})
                task = asyncio.create_task(
                    self.calculate_slippage(symbol, 1000, 'buy', market_data)
                )
                tasks.append(task)
            
            await asyncio.gather(*tasks, return_exceptions=True)
    
    def get_calculation_status(self) -> Dict:
        """Hesaplama durumu"""
        return {
            'cache_size': len(self.slippage_cache),
            'symbols_tracked': len(self.market_snapshots),
            'history_sizes': {
                symbol: len(history) 
                for symbol, history in self.market_snapshots.items()
            },
            'last_updates': {
                symbol: last_update.isoformat() 
                for symbol, last_update in self.last_calculation_time.items()
            },
            'calculation_methods': list(self.calculation_methods.keys())
        }
    
    async def shutdown(self):
        """Calculator'ı kapat"""
        self.logger.info("Real-time Slippage Calculator kapatılıyor...")
        
        # Clear caches
        self.slippage_cache.clear()
        self.market_snapshots.clear()
        self.price_history.clear()
        self.volume_history.clear()
        
        self.logger.info("Real-time Slippage Calculator kapatıldı")