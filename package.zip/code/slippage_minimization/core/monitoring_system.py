"""
Real-time Monitoring System Module
Anlık sistem izleme ve alert yönetimi
"""

import asyncio
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Callable
from dataclasses import dataclass, asdict
from enum import Enum
import json
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

class AlertSeverity(Enum):
    """Alert önem seviyeleri"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

class SystemComponent(Enum):
    """Sistem bileşenleri"""
    MARKET_DATA = "market_data"
    SLIPPAGE_CALCULATOR = "slippage_calculator"
    STRATEGY_OPTIMIZER = "strategy_optimizer"
    TRANSACTION_ANALYZER = "transaction_analyzer"
    PERFORMANCE_ATTRIBUTION = "performance_attribution"
    ML_PREDICTOR = "ml_predictor"
    ADAPTIVE_ALGORITHMS = "adaptive_algorithms"
    INTEGRATION_HUB = "integration_hub"

@dataclass
class Alert:
    """Alert formatı"""
    id: str
    severity: AlertSeverity
    component: SystemComponent
    title: str
    message: str
    metric_value: float
    threshold_value: float
    timestamp: datetime
    acknowledged: bool = False
    resolved: bool = False
    metadata: Optional[Dict] = None

@dataclass
class SystemHealthStatus:
    """Sistem sağlık durumu"""
    component: SystemComponent
    status: str  # 'healthy', 'warning', 'unhealthy'
    uptime_percentage: float
    last_update: datetime
    metrics: Dict[str, float]
    issues: List[str]

@dataclass
class MonitoringMetrics:
    """İzleme metrikleri"""
    component: SystemComponent
    timestamp: datetime
    cpu_usage: float
    memory_usage: float
    response_time_ms: float
    throughput: float
    error_rate: float
    custom_metrics: Dict[str, float]

class RealTimeMonitoringSystem:
    """
    Real-time Monitoring System
    Kapsamlı sistem izleme ve alert yönetimi
    """
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Alert thresholds
        self.alert_thresholds = config.alert_thresholds
        
        # Alert handlers
        self.alert_handlers = {
            AlertSeverity.INFO: self._handle_info_alert,
            AlertSeverity.WARNING: self._handle_warning_alert,
            AlertSeverity.ERROR: self._handle_error_alert,
            AlertSeverity.CRITICAL: self._handle_critical_alert
        }
        
        # Monitoring state
        self.active_alerts: Dict[str, Alert] = {}
        self.health_status: Dict[SystemComponent, SystemHealthStatus] = {}
        self.metrics_history: Dict[SystemComponent, List[MonitoringMetrics]] = {}
        self.alert_history: List[Alert] = []
        
        # Component performance tracking
        self.component_performance = {}
        self.last_health_check = {}
        
        # Alert suppression
        self.alert_suppression: Dict[str, datetime] = {}
        self.suppression_duration_minutes = 5
        
        # Email configuration (if needed)
        self.email_config = {
            'smtp_server': 'localhost',
            'smtp_port': 587,
            'username': '',
            'password': '',
            'from_email': 'alerts@bitwisers.com',
            'to_emails': ['admin@bitwisers.com']
        }
        
        # Dashboard data
        self.dashboard_data = {}
        
        self.logger.info("Real-time Monitoring System oluşturuldu")
    
    async def initialize(self) -> bool:
        """Monitoring sistemini başlat"""
        try:
            self.logger.info("Real-time Monitoring System başlatılıyor...")
            
            # Initialize component health statuses
            for component in SystemComponent:
                self.health_status[component] = SystemHealthStatus(
                    component=component,
                    status='healthy',
                    uptime_percentage=100.0,
                    last_update=datetime.now(),
                    metrics={},
                    issues=[]
                )
            
            # Initialize metrics history
            for component in SystemComponent:
                self.metrics_history[component] = []
            
            # Start monitoring tasks
            await self._start_monitoring_tasks()
            
            self.logger.info("Real-time Monitoring System başarıyla başlatıldı")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Monitoring System başlatma hatası: {e}")
            return False
    
    async def check_system_health(self):
        """Sistem sağlık kontrolü"""
        try:
            current_time = datetime.now()
            
            # Check each component
            for component in SystemComponent:
                try:
                    health_status = await self._check_component_health(component)
                    self.health_status[component] = health_status
                    
                    # Check for alerts
                    await self._check_component_alerts(component, health_status)
                    
                    self.last_health_check[component] = current_time
                    
                except Exception as e:
                    self.logger.error(f"Component health check hatası {component.value}: {e}")
                    
                    # Create error alert
                    await self._create_alert(
                        severity=AlertSeverity.ERROR,
                        component=component,
                        title=f"{component.value} Health Check Failed",
                        message=f"Health check failed: {str(e)}",
                        metric_value=0,
                        threshold_value=1
                    )
            
        except Exception as e:
            self.logger.error(f"Sistem sağlık kontrolü hatası: {e}")
    
    async def check_alerts(self):
        """Alert kontrolü"""
        try:
            current_time = datetime.now()
            
            # Check for alert timeouts
            alerts_to_resolve = []
            
            for alert_id, alert in self.active_alerts.items():
                if not alert.resolved and alert.acknowledged:
                    # Check if alert should be resolved based on conditions
                    should_resolve = await self._should_resolve_alert(alert)
                    if should_resolve:
                        alert.resolved = True
                        alerts_to_resolve.append(alert_id)
            
            # Clean up resolved alerts
            for alert_id in alerts_to_resolve:
                resolved_alert = self.active_alerts.pop(alert_id)
                self.alert_history.append(resolved_alert)
                
                # Keep only recent alerts in history
                cutoff_time = current_time - timedelta(days=7)
                self.alert_history = [
                    a for a in self.alert_history if a.timestamp > cutoff_time
                ]
            
            # Update dashboard data
            await self._update_dashboard_data()
            
        except Exception as e:
            self.logger.error(f"Alert kontrolü hatası: {e}")
    
    async def check_execution_alerts(self, execution_result: Any):
        """Execution alert kontrolü"""
        try:
            # Check slippage thresholds
            slippage_bps = execution_result.slippage_bps
            
            if slippage_bps > self.alert_thresholds.get('slippage_critical', 10.0):
                await self._create_alert(
                    severity=AlertSeverity.CRITICAL,
                    component=SystemComponent.SLIPPAGE_CALCULATOR,
                    title="Critical Slippage Detected",
                    message=f"Slippage {slippage_bps:.2f} bps exceeded critical threshold",
                    metric_value=slippage_bps,
                    threshold_value=self.alert_thresholds['slippage_critical']
                )
            
            elif slippage_bps > self.alert_thresholds.get('slippage_warning', 5.0):
                await self._create_alert(
                    severity=AlertSeverity.WARNING,
                    component=SystemComponent.SLIPPAGE_CALCULATOR,
                    title="High Slippage Warning",
                    message=f"Slippage {slippage_bps:.2f} bps exceeded warning threshold",
                    metric_value=slippage_bps,
                    threshold_value=self.alert_thresholds['slippage_warning']
                )
            
            # Check execution time
            execution_time_ms = execution_result.execution_time_ms
            
            if execution_time_ms > self.alert_thresholds.get('execution_time_warning', 5000):
                await self._create_alert(
                    severity=AlertSeverity.WARNING,
                    component=SystemComponent.INTEGRATION_HUB,
                    title="Slow Execution Detected",
                    message=f"Execution took {execution_time_ms:.0f}ms, exceeded threshold",
                    metric_value=execution_time_ms,
                    threshold_value=self.alert_thresholds['execution_time_warning']
                )
            
            # Check success rate
            if not execution_result.success:
                await self._create_alert(
                    severity=AlertSeverity.ERROR,
                    component=SystemComponent.INTEGRATION_HUB,
                    title="Execution Failed",
                    message=f"Order {execution_result.order_id} execution failed",
                    metric_value=0,
                    threshold_value=1
                )
            
        except Exception as e:
            self.logger.error(f"Execution alert kontrolü hatası: {e}")
    
    async def _check_component_health(self, component: SystemComponent) -> SystemHealthStatus:
        """Component sağlık kontrolü"""
        # Get recent metrics for this component
        recent_metrics = self.metrics_history.get(component, [])
        
        if not recent_metrics:
            # No metrics yet, assume healthy
            return SystemHealthStatus(
                component=component,
                status='healthy',
                uptime_percentage=100.0,
                last_update=datetime.now(),
                metrics={},
                issues=[]
            )
        
        # Calculate health metrics
        latest_metrics = recent_metrics[-1] if recent_metrics else None
        if not latest_metrics:
            status = 'warning'
            issues = ['No recent metrics']
        else:
            status, issues = self._evaluate_component_health(latest_metrics)
        
        # Calculate uptime percentage
        uptime_percentage = self._calculate_uptime_percentage(component)
        
        return SystemHealthStatus(
            component=component,
            status=status,
            uptime_percentage=uptime_percentage,
            last_update=datetime.now(),
            metrics=latest_metrics.__dict__ if latest_metrics else {},
            issues=issues
        )
    
    def _evaluate_component_health(self, metrics: MonitoringMetrics) -> Tuple[str, List[str]]:
        """Component sağlık değerlendirmesi"""
        issues = []
        status = 'healthy'
        
        # Check CPU usage
        if metrics.cpu_usage > 90:
            issues.append(f"High CPU usage: {metrics.cpu_usage:.1f}%")
            status = 'unhealthy'
        elif metrics.cpu_usage > 70:
            issues.append(f"Elevated CPU usage: {metrics.cpu_usage:.1f}%")
            if status == 'healthy':
                status = 'warning'
        
        # Check memory usage
        if metrics.memory_usage > 90:
            issues.append(f"High memory usage: {metrics.memory_usage:.1f}%")
            status = 'unhealthy'
        elif metrics.memory_usage > 70:
            issues.append(f"Elevated memory usage: {metrics.memory_usage:.1f}%")
            if status == 'healthy':
                status = 'warning'
        
        # Check response time
        if metrics.response_time_ms > 1000:
            issues.append(f"Slow response time: {metrics.response_time_ms:.0f}ms")
            status = 'unhealthy'
        elif metrics.response_time_ms > 500:
            issues.append(f"Elevated response time: {metrics.response_time_ms:.0f}ms")
            if status == 'healthy':
                status = 'warning'
        
        # Check error rate
        if metrics.error_rate > 0.05:  # 5%
            issues.append(f"High error rate: {metrics.error_rate:.2%}")
            status = 'unhealthy'
        elif metrics.error_rate > 0.01:  # 1%
            issues.append(f"Elevated error rate: {metrics.error_rate:.2%}")
            if status == 'healthy':
                status = 'warning'
        
        return status, issues
    
    def _calculate_uptime_percentage(self, component: SystemComponent) -> float:
        """Uptime yüzdesi hesaplama"""
        recent_metrics = self.metrics_history.get(component, [])
        
        if not recent_metrics:
            return 100.0
        
        # Calculate based on error rates
        recent_errors = [m.error_rate for m in recent_metrics[-60:]]  # Last hour
        avg_error_rate = np.mean(recent_errors) if recent_errors else 0
        
        return max(0, (1 - avg_error_rate) * 100)
    
    async def _check_component_alerts(self, component: SystemComponent, 
                                    health_status: SystemHealthStatus):
        """Component alert kontrolü"""
        for issue in health_status.issues:
            severity = AlertSeverity.WARNING
            if 'High' in issue or 'unhealthy' in health_status.status:
                severity = AlertSeverity.ERROR
            
            await self._create_alert(
                severity=severity,
                component=component,
                title=f"{component.value} Health Issue",
                message=issue,
                metric_value=0,  # Would extract actual metric value
                threshold_value=0,
                metadata={'health_status': health_status.__dict__}
            )
    
    async def _create_alert(self, severity: AlertSeverity, component: SystemComponent,
                          title: str, message: str, metric_value: float, 
                          threshold_value: float, metadata: Optional[Dict] = None):
        """Alert oluştur"""
        try:
            # Check if alert is suppressed
            alert_key = f"{component.value}_{title}"
            if alert_key in self.alert_suppression:
                suppression_time = self.alert_suppression[alert_key]
                if datetime.now() - suppression_time < timedelta(minutes=self.suppression_duration_minutes):
                    return  # Alert is suppressed
            
            # Create alert
            alert_id = f"{component.value}_{int(datetime.now().timestamp())}"
            
            alert = Alert(
                id=alert_id,
                severity=severity,
                component=component,
                title=title,
                message=message,
                metric_value=metric_value,
                threshold_value=threshold_value,
                timestamp=datetime.now(),
                metadata=metadata
            )
            
            # Store alert
            self.active_alerts[alert_id] = alert
            
            # Handle alert
            await self._handle_alert(alert)
            
            # Set suppression
            self.alert_suppression[alert_key] = datetime.now()
            
            # Clean up old suppressions
            cutoff_time = datetime.now() - timedelta(hours=1)
            keys_to_remove = [
                key for key, time in self.alert_suppression.items()
                if time < cutoff_time
            ]
            for key in keys_to_remove:
                self.alert_suppression.pop(key, None)
            
        except Exception as e:
            self.logger.error(f"Alert oluşturma hatası: {e}")
    
    async def _handle_alert(self, alert: Alert):
        """Alert yönetimi"""
        try:
            # Get appropriate handler
            handler = self.alert_handlers.get(alert.severity, self._handle_info_alert)
            
            # Execute handler
            await handler(alert)
            
            # Log alert
            log_level = {
                AlertSeverity.INFO: logging.INFO,
                AlertSeverity.WARNING: logging.WARNING,
                AlertSeverity.ERROR: logging.ERROR,
                AlertSeverity.CRITICAL: logging.CRITICAL
            }.get(alert.severity, logging.INFO)
            
            self.logger.log(log_level, f"ALERT [{alert.severity.value}] {alert.title}: {alert.message}")
            
        except Exception as e:
            self.logger.error(f"Alert handling hatası: {e}")
    
    async def _handle_info_alert(self, alert: Alert):
        """Info alert handler"""
        # Just log info alerts
        pass
    
    async def _handle_warning_alert(self, alert: Alert):
        """Warning alert handler"""
        # Log warning and potentially send to dashboard
        await self._update_dashboard_alert(alert)
    
    async def _handle_error_alert(self, alert: Alert):
        """Error alert handler"""
        # Log error and send notification
        await self._update_dashboard_alert(alert)
        
        # Could also trigger email or other notifications
        await self._send_email_notification(alert)
    
    async def _handle_critical_alert(self, alert: Alert):
        """Critical alert handler"""
        # Immediate notification required
        await self._update_dashboard_alert(alert)
        await self._send_email_notification(alert)
        
        # Could trigger other emergency procedures
        self.logger.critical(f"CRITICAL ALERT: {alert.title} - {alert.message}")
    
    async def _should_resolve_alert(self, alert: Alert) -> bool:
        """Alert çözülmeli mi kontrolü"""
        # Simple logic - in production this would be more sophisticated
        # Check if conditions that triggered the alert are no longer present
        
        if alert.component == SystemComponent.SLIPPAGE_CALCULATOR:
            # Would check if current slippage is below threshold
            return True
        
        return False
    
    async def _update_dashboard_alert(self, alert: Alert):
        """Dashboard alert güncelle"""
        if 'alerts' not in self.dashboard_data:
            self.dashboard_data['alerts'] = []
        
        self.dashboard_data['alerts'].append(asdict(alert))
        
        # Keep only recent alerts
        cutoff_time = datetime.now() - timedelta(hours=24)
        self.dashboard_data['alerts'] = [
            a for a in self.dashboard_data['alerts']
            if datetime.fromisoformat(a['timestamp']) > cutoff_time
        ]
    
    async def _send_email_notification(self, alert: Alert):
        """Email bildirimi gönder"""
        try:
            if not self.email_config.get('username') or not self.email_config.get('to_emails'):
                return  # Email not configured
            
            msg = MIMEMultipart()
            msg['From'] = self.email_config['from_email']
            msg['To'] = ', '.join(self.email_config['to_emails'])
            msg['Subject'] = f"[{alert.severity.value.upper()}] Bitwisers Alert: {alert.title}"
            
            body = f"""
            Alert Details:
            - Severity: {alert.severity.value}
            - Component: {alert.component.value}
            - Title: {alert.title}
            - Message: {alert.message}
            - Timestamp: {alert.timestamp}
            - Metric Value: {alert.metric_value}
            - Threshold: {alert.threshold_value}
            
            Please check the monitoring dashboard for more details.
            """
            
            msg.attach(MIMEText(body, 'plain'))
            
            server = smtplib.SMTP(self.email_config['smtp_server'], self.email_config['smtp_port'])
            server.starttls()
            server.login(self.email_config['username'], self.email_config['password'])
            server.send_message(msg)
            server.quit()
            
            self.logger.info(f"Email notification sent for alert: {alert.id}")
            
        except Exception as e:
            self.logger.error(f"Email notification hatası: {e}")
    
    async def _update_dashboard_data(self):
        """Dashboard verilerini güncelle"""
        try:
            # System overview
            self.dashboard_data['system_overview'] = {
                'total_components': len(SystemComponent),
                'healthy_components': sum(
                    1 for status in self.health_status.values() 
                    if status.status == 'healthy'
                ),
                'warning_components': sum(
                    1 for status in self.health_status.values() 
                    if status.status == 'warning'
                ),
                'unhealthy_components': sum(
                    1 for status in self.health_status.values() 
                    if status.status == 'unhealthy'
                ),
                'active_alerts': len([a for a in self.active_alerts.values() if not a.resolved]),
                'last_update': datetime.now().isoformat()
            }
            
            # Component details
            self.dashboard_data['components'] = {}
            for component, status in self.health_status.items():
                self.dashboard_data['components'][component.value] = {
                    'status': status.status,
                    'uptime_percentage': status.uptime_percentage,
                    'last_update': status.last_update.isoformat(),
                    'issues': status.issues,
                    'metrics': status.metrics
                }
            
            # Performance metrics
            self.dashboard_data['performance'] = {}
            for component in SystemComponent:
                metrics = self.metrics_history.get(component, [])
                if metrics:
                    recent_metrics = metrics[-10:]  # Last 10 measurements
                    self.dashboard_data['performance'][component.value] = {
                        'avg_response_time_ms': np.mean([m.response_time_ms for m in recent_metrics]),
                        'avg_error_rate': np.mean([m.error_rate for m in recent_metrics]),
                        'avg_throughput': np.mean([m.throughput for m in recent_metrics]),
                        'data_points': len(recent_metrics)
                    }
            
        except Exception as e:
            self.logger.error(f"Dashboard data güncelleme hatası: {e}")
    
    async def _start_monitoring_tasks(self):
        """Monitoring taskları başlat"""
        # This would start background tasks for continuous monitoring
        self.logger.info("Monitoring tasks started")
    
    def update_component_metrics(self, component: SystemComponent, metrics: MonitoringMetrics):
        """Component metriklerini güncelle"""
        try:
            if component not in self.metrics_history:
                self.metrics_history[component] = []
            
            self.metrics_history[component].append(metrics)
            
            # Keep only recent metrics
            cutoff_time = datetime.now() - timedelta(hours=24)
            self.metrics_history[component] = [
                m for m in self.metrics_history[component]
                if m.timestamp > cutoff_time
            ]
            
        except Exception as e:
            self.logger.error(f"Component metrics güncelleme hatası: {e}")
    
    def acknowledge_alert(self, alert_id: str) -> bool:
        """Alert'i onayla"""
        if alert_id in self.active_alerts:
            self.active_alerts[alert_id].acknowledged = True
            return True
        return False
    
    def resolve_alert(self, alert_id: str) -> bool:
        """Alert'i çöz"""
        if alert_id in self.active_alerts:
            self.active_alerts[alert_id].resolved = True
            return True
        return False
    
    def get_system_status(self) -> Dict:
        """Sistem durumu"""
        return {
            'system_overview': self.dashboard_data.get('system_overview', {}),
            'components': self.dashboard_data.get('components', {}),
            'active_alerts': len([a for a in self.active_alerts.values() if not a.resolved]),
            'recent_alerts': [
                asdict(alert) for alert in list(self.active_alerts.values())[-10:]
            ],
            'performance': self.dashboard_data.get('performance', {})
        }
    
    def get_alert_report(self, days: int = 1) -> Dict:
        """Alert raporu"""
        cutoff_time = datetime.now() - timedelta(days=days)
        
        # Active alerts
        active_alerts = [a for a in self.active_alerts.values() if not a.resolved]
        
        # Recent alerts from history
        recent_alerts = [
            a for a in self.alert_history 
            if a.timestamp > cutoff_time
        ]
        
        # Statistics
        severity_counts = {}
        component_counts = {}
        
        for alert in active_alerts + recent_alerts:
            # Severity counts
            severity = alert.severity.value
            severity_counts[severity] = severity_counts.get(severity, 0) + 1
            
            # Component counts
            component = alert.component.value
            component_counts[component] = component_counts.get(component, 0) + 1
        
        return {
            'period_days': days,
            'active_alerts': len(active_alerts),
            'resolved_alerts': len(recent_alerts),
            'severity_breakdown': severity_counts,
            'component_breakdown': component_counts,
            'top_alerts': [
                asdict(alert) for alert in sorted(
                    active_alerts + recent_alerts,
                    key=lambda a: (a.severity.value, a.timestamp),
                    reverse=True
                )[:20]
            ]
        }
    
    async def shutdown(self):
        """Monitoring sistemini kapat"""
        self.logger.info("Real-time Monitoring System kapatılıyor...")
        
        # Clear all data
        self.active_alerts.clear()
        self.health_status.clear()
        self.metrics_history.clear()
        self.alert_suppression.clear()
        self.dashboard_data.clear()
        
        self.logger.info("Real-time Monitoring System kapatıldı")