"""
Market Impact Modeling Module
Gelişmiş market impact modelleme ve hesaplama
"""

import asyncio
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from scipy import optimize
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler

@dataclass
class MarketImpactResult:
    """Market impact sonucu"""
    impact_bps: float
    impact_cost: float
    confidence_interval: Tuple[float, float]
    components: Dict[str, float]
    regime_impact: float
    venue_specific_impact: Dict[str, float]
    timestamp: datetime

@dataclass
class ImpactFactors:
    """Impact faktörleri"""
    volume_ratio: float  # Trade size / average volume
    volatility: float
    liquidity_score: float
    spread_bps: float
    order_book_depth: float
    market_regime: str
    time_of_day: float
    venue_concentration: float

class MarketImpactModel:
    """
    Gelişmiş Market Impact Model
    Multiple impact models ve machine learning based predictions
    """
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Impact model parametreleri
        self.alpha = config.market_impact_alpha  # Temporary impact coefficient
        self.beta = config.market_impact_beta    # Permanent impact coefficient  
        self.gamma = config.market_impact_gamma  # Market regime multiplier
        
        # Model state
        self.is_initialized = False
        self.ml_model = None
        self.scaler = StandardScaler()
        self.impact_history = []
        self.regime_models = {}
        
        # Venue specific models
        self.venue_models = {}
        
        # Market data
        self.market_data_cache = {}
        self.volume_history = {}
        
        # Calibration data
        self.calibration_data = {
            'historical_trades': [],
            'market_regimes': [],
            'venue_characteristics': {}
        }
        
        self.logger.info("Market Impact Model oluşturuldu")
    
    async def initialize(self) -> bool:
        """Model'i başlat"""
        try:
            self.logger.info("Market Impact Model başlatılıyor...")
            
            # ML model'i başlat
            self.ml_model = RandomForestRegressor(
                n_estimators=100,
                max_depth=10,
                random_state=42
            )
            
            # Model calibrations
            await self._calibrate_models()
            
            # Load historical data
            await self._load_historical_data()
            
            # Train initial models
            if len(self.impact_history) > 100:
                await self._train_models()
            
            self.is_initialized = True
            self.logger.info("Market Impact Model başarıyla başlatıldı")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Market Impact Model başlatma hatası: {e}")
            return False
    
    async def calculate_market_impact(self, symbol: str, quantity: float, 
                                    side: str, market_data: Dict) -> Optional[MarketImpactResult]:
        """
        Ana market impact hesaplama fonksiyonu
        """
        if not self.is_initialized:
            self.logger.warning("Market Impact Model henüz başlatılmadı")
            return None
        
        try:
            # Impact faktörlerini hazırla
            impact_factors = await self._prepare_impact_factors(
                symbol, quantity, side, market_data
            )
            
            if not impact_factors:
                return None
            
            # Multiple model approaches
            permanent_impact = await self._calculate_permanent_impact(
                symbol, quantity, side, impact_factors
            )
            
            temporary_impact = await self._calculate_temporary_impact(
                symbol, quantity, side, impact_factors
            )
            
            ml_impact = await self._calculate_ml_impact(
                symbol, quantity, side, impact_factors
            )
            
            # Weighted combination
            combined_impact = self._combine_impact_estimates(
                permanent_impact, temporary_impact, ml_impact
            )
            
            # Regime adjustment
            regime_adjustment = await self._apply_regime_adjustment(
                symbol, impact_factors.market_regime
            )
            
            # Venue specific adjustments
            venue_impacts = await self._calculate_venue_specific_impacts(
                symbol, quantity, side, market_data
            )
            
            # Final impact calculation
            total_impact = combined_impact * regime_adjustment
            
            # Confidence interval
            confidence_interval = self._calculate_confidence_interval(
                permanent_impact, temporary_impact, ml_impact
            )
            
            result = MarketImpactResult(
                impact_bps=total_impact * 10000,  # Convert to bps
                impact_cost=total_impact * quantity * market_data.get('price', 0),
                confidence_interval=confidence_interval,
                components={
                    'permanent_impact_bps': permanent_impact * 10000,
                    'temporary_impact_bps': temporary_impact * 10000,
                    'ml_impact_bps': ml_impact * 10000,
                    'regime_adjustment': regime_adjustment
                },
                regime_impact=regime_adjustment,
                venue_specific_impact=venue_impacts,
                timestamp=datetime.now()
            )
            
            return result
            
        except Exception as e:
            self.logger.error(f"Market impact hesaplama hatası: {e}")
            return None
    
    async def _prepare_impact_factors(self, symbol: str, quantity: float, 
                                    side: str, market_data: Dict) -> Optional[ImpactFactors]:
        """Impact faktörlerini hazırla"""
        try:
            # Volume ratio hesapla
            avg_volume = self._get_average_volume(symbol)
            volume_ratio = quantity / max(avg_volume, 1)
            
            # Volatility hesapla
            volatility = self._calculate_volatility(symbol, market_data)
            
            # Liquidity score
            liquidity_score = self._calculate_liquidity_score(symbol, market_data)
            
            # Spread hesapla
            spread_bps = self._calculate_spread_bps(market_data)
            
            # Order book depth
            order_book_depth = self._calculate_order_book_depth(market_data)
            
            # Market regime
            market_regime = self._detect_market_regime(symbol, market_data)
            
            # Time of day factor
            time_of_day = self._calculate_time_of_day_factor()
            
            # Venue concentration
            venue_concentration = self._calculate_venue_concentration(market_data)
            
            return ImpactFactors(
                volume_ratio=volume_ratio,
                volatility=volatility,
                liquidity_score=liquidity_score,
                spread_bps=spread_bps,
                order_book_depth=order_book_depth,
                market_regime=market_regime,
                time_of_day=time_of_day,
                venue_concentration=venue_concentration
            )
            
        except Exception as e:
            self.logger.error(f"Impact factors hazırlama hatası: {e}")
            return None
    
    def _get_average_volume(self, symbol: str, window_hours: int = 24) -> float:
        """Ortalama hacim hesapla"""
        if symbol not in self.volume_history:
            return 1000000.0  # Default volume
        
        volume_data = self.volume_history[symbol]
        if len(volume_data) < 10:
            return 1000000.0
        
        # Son N saatin volume ortalaması
        recent_volumes = volume_data[-min(len(volume_data), window_hours):]
        return np.mean(recent_volumes)
    
    def _calculate_volatility(self, symbol: str, market_data: Dict) -> float:
        """Volatilite hesapla"""
        price_data = market_data.get('price_history', [])
        if len(price_data) < 2:
            return 0.02  # Default volatility
        
        returns = np.diff(price_data) / price_data[:-1]
        return np.std(returns)
    
    def _calculate_liquidity_score(self, symbol: str, market_data: Dict) -> float:
        """Likidite skoru hesapla"""
        # Order book derinliği ve spread bazlı likidite skoru
        order_book = market_data.get('order_book', {})
        
        bid_depth = sum(level[1] for level in order_book.get('bids', [])[:5])
        ask_depth = sum(level[1] for level in order_book.get('asks', [])[:5])
        
        total_depth = bid_depth + ask_depth
        if total_depth == 0:
            return 0.0
        
        # Normalize to 0-1 scale
        liquidity_score = min(total_depth / 1000000, 1.0)  # 1M unit normalization
        
        return liquidity_score
    
    def _calculate_spread_bps(self, market_data: Dict) -> float:
        """Spread hesapla (bps)"""
        order_book = market_data.get('order_book', {})
        
        bids = order_book.get('bids', [])
        asks = order_book.get('asks', [])
        
        if not bids or not asks:
            return 10.0  # Default 10 bps
        
        best_bid = float(bids[0][0])
        best_ask = float(asks[0][0])
        
        mid_price = (best_bid + best_ask) / 2
        spread = best_ask - best_bid
        
        return (spread / mid_price) * 10000 if mid_price > 0 else 10.0
    
    def _calculate_order_book_depth(self, market_data: Dict) -> float:
        """Order book derinliği hesapla"""
        order_book = market_data.get('order_book', {})
        
        total_bid_depth = sum(level[1] for level in order_book.get('bids', [])[:10])
        total_ask_depth = sum(level[1] for level in order_book.get('asks', [])[:10])
        
        return (total_bid_depth + total_ask_depth) / 2
    
    def _detect_market_regime(self, symbol: str, market_data: Dict) -> str:
        """Market rejimini tespit et"""
        # Basit regime detection
        volatility = self._calculate_volatility(symbol, market_data)
        
        if volatility > 0.05:
            return 'high_volatility'
        elif volatility > 0.02:
            return 'normal_volatility'
        else:
            return 'low_volatility'
    
    def _calculate_time_of_day_factor(self) -> float:
        """Günün saati factorı"""
        now = datetime.now()
        hour = now.hour
        
        # Market hours (assuming crypto - 24/7 but vary activity)
        if 8 <= hour <= 18:  # High activity hours
            return 1.2
        elif 2 <= hour <= 6:  # Low activity hours
            return 0.8
        else:
            return 1.0
    
    def _calculate_venue_concentration(self, market_data: Dict) -> float:
        """Venue konsantrasyonu hesapla"""
        venues = market_data.get('venues', {})
        if len(venues) <= 1:
            return 1.0  # High concentration
        
        # Calculate Herfindahl index
        market_shares = []
        total_volume = 0
        
        for venue, data in venues.items():
            volume = data.get('volume', 0)
            market_shares.append(volume)
            total_volume += volume
        
        if total_volume == 0:
            return 1.0
        
        # Normalize shares
        shares = [v / total_volume for v in market_shares]
        
        # Herfindahl index (0-1, higher = more concentrated)
        hhi = sum(s**2 for s in shares)
        
        return hhi
    
    async def _calculate_permanent_impact(self, symbol: str, quantity: float, 
                                        side: str, factors: ImpactFactors) -> float:
        """Permanent impact hesapla"""
        # Kyle's model based permanent impact
        base_impact = self.beta * factors.volume_ratio ** 0.5
        
        # Volatility adjustment
        volatility_adj = 1 + factors.volatility * 2
        
        # Liquidity adjustment (inverse)
        liquidity_adj = 1 / max(factors.liquidity_score, 0.1)
        
        # Time of day adjustment
        time_adj = factors.time_of_day
        
        # Market regime adjustment
        regime_multiplier = {
            'high_volatility': 1.5,
            'normal_volatility': 1.0,
            'low_volatility': 0.8
        }.get(factors.market_regime, 1.0)
        
        total_impact = base_impact * volatility_adj * liquidity_adj * time_adj * regime_multiplier
        
        return max(total_impact, 0)
    
    async def _calculate_temporary_impact(self, symbol: str, quantity: float,
                                        side: str, factors: ImpactFactors) -> float:
        """Temporary impact hesapla"""
        # Obizhaeva & Wang model based temporary impact
        base_impact = self.alpha * factors.volume_ratio
        
        # Market microstructure factors
        spread_adj = 1 + factors.spread_bps / 100  # Normalized spread
        
        # Order book depth adjustment (inverse)
        depth_adj = 1 / max(factors.order_book_depth / 100000, 0.1)
        
        # Venue concentration adjustment
        concentration_adj = 1 + factors.venue_concentration
        
        total_impact = base_impact * spread_adj * depth_adj * concentration_adj
        
        return max(total_impact, 0)
    
    async def _calculate_ml_impact(self, symbol: str, quantity: float,
                                 side: str, factors: ImpactFactors) -> float:
        """ML-based impact hesapla"""
        if self.ml_model is None or len(self.impact_history) < 100:
            # Fallback to analytical model
            return await self._calculate_permanent_impact(symbol, quantity, side, factors)
        
        # Prepare features
        features = np.array([
            factors.volume_ratio,
            factors.volatility,
            factors.liquidity_score,
            factors.spread_bps / 100,  # Normalize
            factors.order_book_depth / 100000,  # Normalize
            factors.time_of_day,
            factors.venue_concentration
        ]).reshape(1, -1)
        
        # Scale features
        features_scaled = self.scaler.transform(features)
        
        # Predict
        predicted_impact = self.ml_model.predict(features_scaled)[0]
        
        return max(predicted_impact, 0)
    
    def _combine_impact_estimates(self, permanent: float, temporary: float, ml: float) -> float:
        """Impact tahminlerini birleştir"""
        # Weighted combination based on confidence and data availability
        weights = {
            'permanent': 0.4,
            'temporary': 0.3,
            'ml': 0.3
        }
        
        combined = (
            weights['permanent'] * permanent +
            weights['temporary'] * temporary +
            weights['ml'] * ml
        )
        
        return combined
    
    async def _apply_regime_adjustment(self, symbol: str, regime: str) -> float:
        """Market regime adjustment uygula"""
        regime_multipliers = {
            'high_volatility': 1.5,
            'normal_volatility': 1.0,
            'low_volatility': 0.8,
            'bull_market': 0.9,
            'bear_market': 1.3,
            'trending': 1.1
        }
        
        return regime_multipliers.get(regime, 1.0)
    
    async def _calculate_venue_specific_impacts(self, symbol: str, quantity: float,
                                              side: str, market_data: Dict) -> Dict[str, float]:
        """Venue-specific impact hesapla"""
        venue_impacts = {}
        
        venues = market_data.get('venues', {})
        for venue_name, venue_data in venues.items():
            # Venue-specific adjustments
            venue_volume = venue_data.get('volume', 100000)
            venue_liquidity = venue_data.get('liquidity_score', 0.5)
            
            # Venue impact = base_impact * venue_adjustment
            base_impact = 0.001 * (quantity / venue_volume) ** 0.5
            venue_adjustment = 1 / max(venue_liquidity, 0.1)
            
            venue_impacts[venue_name] = base_impact * venue_adjustment
        
        return venue_impacts
    
    def _calculate_confidence_interval(self, permanent: float, temporary: float, ml: float) -> Tuple[float, float]:
        """Confidence interval hesapla"""
        # Standard deviation of estimates
        estimates = [permanent, temporary, ml]
        std_dev = np.std(estimates)
        
        combined = self._combine_impact_estimates(permanent, temporary, ml)
        
        # 95% confidence interval
        margin = 1.96 * std_dev
        
        return (max(combined - margin, 0), combined + margin)
    
    async def _calibrate_models(self):
        """Model kalibrasyonu"""
        self.logger.info("Market Impact Model kalibrasyonu başlatılıyor...")
        
        # Default parameters
        self.alpha = 0.001  # Temporary impact coefficient
        self.beta = 0.5     # Permanent impact coefficient
        self.gamma = 0.1    # Regime multiplier
        
        # Market regime specific parameters
        self.regime_models = {
            'high_volatility': {'alpha': 0.002, 'beta': 0.7},
            'normal_volatility': {'alpha': 0.001, 'beta': 0.5},
            'low_volatility': {'alpha': 0.0005, 'beta': 0.3}
        }
        
        self.logger.info("Model kalibrasyonu tamamlandı")
    
    async def _load_historical_data(self):
        """Historical data yükle"""
        # Placeholder for historical data loading
        # In production, this would load from database or files
        self.logger.info("Historical data yükleniyor...")
        
        # Generate sample historical data for demo
        self.impact_history = []
        for i in range(1000):
            self.impact_history.append({
                'volume_ratio': np.random.exponential(0.1),
                'volatility': np.random.exponential(0.02),
                'liquidity_score': np.random.beta(2, 2),
                'spread_bps': np.random.exponential(10),
                'actual_impact': np.random.exponential(0.001)
            })
        
        self.logger.info(f"{len(self.impact_history)} historical record yüklendi")
    
    async def _train_models(self):
        """ML model eğitimi"""
        if len(self.impact_history) < 100:
            return
        
        self.logger.info("ML model eğitimi başlatılıyor...")
        
        # Prepare training data
        features = []
        targets = []
        
        for record in self.impact_history:
            feature_vector = [
                record['volume_ratio'],
                record['volatility'],
                record['liquidity_score'],
                record['spread_bps'] / 100
            ]
            features.append(feature_vector)
            targets.append(record['actual_impact'])
        
        features = np.array(features)
        targets = np.array(targets)
        
        # Scale features
        features_scaled = self.scaler.fit_transform(features)
        
        # Train model
        self.ml_model.fit(features_scaled, targets)
        
        self.logger.info("ML model eğitimi tamamlandı")
    
    async def add_execution_data(self, order_data: Dict):
        """Execution data ekle (for model learning)"""
        try:
            # Extract features from execution data
            execution_features = {
                'volume_ratio': order_data.get('volume_ratio', 0),
                'volatility': order_data.get('volatility', 0),
                'liquidity_score': order_data.get('liquidity_score', 0),
                'spread_bps': order_data.get('spread_bps', 0),
                'actual_impact': order_data.get('actual_impact', 0)
            }
            
            self.impact_history.append(execution_features)
            
            # Keep only recent data
            if len(self.impact_history) > 5000:
                self.impact_history = self.impact_history[-5000:]
            
            # Retrain if enough new data
            if len(self.impact_history) % 100 == 0:
                await self._train_models()
            
        except Exception as e:
            self.logger.error(f"Execution data ekleme hatası: {e}")
    
    async def update_volume_data(self, symbol: str, volume: float):
        """Volume data güncelle"""
        if symbol not in self.volume_history:
            self.volume_history[symbol] = []
        
        self.volume_history[symbol].append(volume)
        
        # Keep only recent data
        if len(self.volume_history[symbol]) > 168:  # 7 days * 24 hours
            self.volume_history[symbol] = self.volume_history[symbol][-168:]
    
    def get_model_status(self) -> Dict:
        """Model durumu"""
        return {
            'is_initialized': self.is_initialized,
            'has_ml_model': self.ml_model is not None,
            'historical_data_points': len(self.impact_history),
            'volume_symbols': len(self.volume_history),
            'model_parameters': {
                'alpha': self.alpha,
                'beta': self.beta,
                'gamma': self.gamma
            },
            'regime_models': self.regime_models,
            'last_update': datetime.now()
        }
    
    async def shutdown(self):
        """Model'i kapat"""
        self.logger.info("Market Impact Model kapatılıyor...")
        
        # Save model state if needed
        # In production, save to persistent storage
        
        self.is_initialized = False
        self.logger.info("Market Impact Model kapatıldı")