"""
Execution Strategy Optimizer Module
Akıllı execution stratejileri optimizasyonu
"""

import asyncio
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Union
from dataclasses import dataclass
from enum import Enum
import itertools
from scipy import optimize

from .real_time_calculator import SlippageCalculation
from .market_impact import MarketImpactResult

class ExecutionStrategy(Enum):
    """Execution stratejileri"""
    IMMEDIATE = "immediate"
    TWAP = "twap"
    VWAP = "vwap"
    ICEBERG = "iceberg"
    POV = "pov"  # Participation of Volume
    SNIPER = "sniper"
    ADAPTIVE = "adaptive"
    ALGORITHMIC = "algorithmic"

@dataclass
class StrategyParameters:
    """Strategy parametreleri"""
    strategy: ExecutionStrategy
    time_horizon_seconds: int
    slice_count: int
    max_slice_size: float
    participation_rate: Optional[float] = None
    price_limits: Optional[Tuple[float, float]] = None
    venue_allocation: Optional[Dict[str, float]] = None
    dynamic_sizing: bool = False
    risk_tolerance: float = 0.5  # 0-1 scale

@dataclass
class StrategyEvaluation:
    """Strategy değerlendirme sonucu"""
    strategy: ExecutionStrategy
    expected_slippage_bps: float
    execution_time_seconds: float
    risk_score: float
    success_probability: float
    cost_breakdown: Dict[str, float]
    venue_allocation: Dict[str, float]
    performance_score: float
    parameters: StrategyParameters

@dataclass
class OptimizationResult:
    """Optimizasyon sonucu"""
    selected_strategy: str
    expected_slippage_bps: float
    optimization_score: float
    strategy_evaluations: List[StrategyEvaluation]
    recommended_parameters: StrategyParameters
    alternatives: List[Dict]
    risk_analysis: Dict
    effectiveness_score: float

class ExecutionStrategyOptimizer:
    """
    Execution Strategy Optimizer
    Optimal execution stratejisi seçimi ve parametre optimizasyonu
    """
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Optimization parameters
        self.max_strategies_considered = config.max_strategies_considered
        self.optimization_timeout_ms = config.optimization_timeout_ms
        
        # Strategy configurations
        self.strategy_configs = {
            ExecutionStrategy.IMMEDIATE: {
                'base_risk': 0.8,
                'speed_multiplier': 1.0,
                'cost_efficiency': 0.3
            },
            ExecutionStrategy.TWAP: {
                'base_risk': 0.4,
                'speed_multiplier': 0.3,
                'cost_efficiency': 0.7,
                'optimal_time_horizons': [300, 900, 1800, 3600]
            },
            ExecutionStrategy.VWAP: {
                'base_risk': 0.3,
                'speed_multiplier': 0.4,
                'cost_efficiency': 0.8,
                'optimal_horizons': [300, 1800, 3600]
            },
            ExecutionStrategy.ICEBERG: {
                'base_risk': 0.2,
                'speed_multiplier': 0.6,
                'cost_efficiency': 0.6,
                'slice_ratios': [0.1, 0.2, 0.3]
            },
            ExecutionStrategy.POV: {
                'base_risk': 0.5,
                'speed_multiplier': 0.5,
                'cost_efficiency': 0.7,
                'participation_rates': [0.05, 0.1, 0.15, 0.2]
            },
            ExecutionStrategy.SNIPER: {
                'base_risk': 0.9,
                'speed_multiplier': 0.2,
                'cost_efficiency': 0.9,
                'spread_thresholds': [2, 5, 10, 20]
            },
            ExecutionStrategy.ADAPTIVE: {
                'base_risk': 0.3,
                'speed_multiplier': 0.7,
                'cost_efficiency': 0.8,
                'adaptation_frequency': 30
            },
            ExecutionStrategy.ALGORITHMIC: {
                'base_risk': 0.4,
                'speed_multiplier': 0.6,
                'cost_efficiency': 0.8,
                'algorithms': ['arrival_price', 'implementation_shortfall', 'market_on_close']
            }
        }
        
        # Performance tracking
        self.strategy_performance = {}
        self.market_regime_strategies = {}
        self.venue_characteristics = {}
        
        # Optimization cache
        self.optimization_cache = {}
        self.cache_ttl_seconds = 30
        
        self.logger.info("Execution Strategy Optimizer oluşturuldu")
    
    async def initialize(self) -> bool:
        """Optimizer'ı başlat"""
        try:
            self.logger.info("Execution Strategy Optimizer başlatılıyor...")
            
            # Load historical performance data
            await self._load_strategy_performance_data()
            
            # Initialize market regime mappings
            await self._initialize_market_regime_strategies()
            
            # Load venue characteristics
            await self._load_venue_characteristics()
            
            self.logger.info("Execution Strategy Optimizer başarıyla başlatıldı")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Strategy Optimizer başlatma hatası: {e}")
            return False
    
    async def optimize_strategy(self, order_request: Any, market_data: Dict,
                              market_impact: Optional[MarketImpactResult],
                              slippage_calculation: Optional[SlippageCalculation],
                              ml_prediction: Optional[Any] = None) -> OptimizationResult:
        """
        Ana strategy optimizasyon fonksiyonu
        """
        try:
            start_time = time.time()
            
            # Extract order details
            symbol = order_request.symbol
            quantity = order_request.quantity
            side = order_request.side
            urgency = order_request.urgency
            
            # Market regime detection
            market_regime = self._detect_market_regime(market_data)
            
            # Generate candidate strategies
            candidate_strategies = self._generate_candidate_strategies(
                order_request, market_data, market_regime
            )
            
            # Evaluate each strategy
            strategy_evaluations = []
            for strategy in candidate_strategies:
                try:
                    evaluation = await self._evaluate_strategy(
                        strategy, order_request, market_data, market_impact, 
                        slippage_calculation, ml_prediction
                    )
                    if evaluation:
                        strategy_evaluations.append(evaluation)
                except Exception as e:
                    self.logger.warning(f"Strategy evaluation hatası {strategy.strategy.value}: {e}")
            
            if not strategy_evaluations:
                # Fallback to immediate execution
                fallback_strategy = StrategyParameters(
                    strategy=ExecutionStrategy.IMMEDIATE,
                    time_horizon_seconds=0,
                    slice_count=1,
                    max_slice_size=quantity
                )
                
                evaluation = await self._evaluate_strategy(
                    fallback_strategy, order_request, market_data,
                    market_impact, slippage_calculation, ml_prediction
                )
                
                if evaluation:
                    strategy_evaluations.append(evaluation)
            
            # Select optimal strategy
            optimal_strategy = self._select_optimal_strategy(strategy_evaluations, urgency)
            
            # Generate alternatives
            alternatives = self._generate_alternatives(strategy_evaluations, optimal_strategy)
            
            # Risk analysis
            risk_analysis = await self._analyze_strategy_risks(
                optimal_strategy, order_request, market_data
            )
            
            # Calculate overall effectiveness score
            effectiveness_score = self._calculate_effectiveness_score(
                optimal_strategy, strategy_evaluations
            )
            
            optimization_time = (time.time() - start_time) * 1000
            
            result = OptimizationResult(
                selected_strategy=optimal_strategy.strategy.value,
                expected_slippage_bps=optimal_strategy.expected_slippage_bps,
                optimization_score=optimal_strategy.performance_score,
                strategy_evaluations=strategy_evaluations,
                recommended_parameters=optimal_strategy.parameters,
                alternatives=alternatives,
                risk_analysis=risk_analysis,
                effectiveness_score=effectiveness_score
            )
            
            self.logger.info(
                f"Strategy optimization completed in {optimization_time:.2f}ms. "
                f"Selected: {optimal_strategy.strategy.value}, "
                f"Expected slippage: {optimal_strategy.expected_slippage_bps:.2f} bps"
            )
            
            return result
            
        except Exception as e:
            self.logger.error(f"Strategy optimization hatası: {e}")
            return OptimizationResult(
                selected_strategy="immediate",
                expected_slippage_bps=50.0,  # Conservative estimate
                optimization_score=0.0,
                strategy_evaluations=[],
                recommended_parameters=StrategyParameters(
                    strategy=ExecutionStrategy.IMMEDIATE,
                    time_horizon_seconds=0,
                    slice_count=1,
                    max_slice_size=order_request.quantity
                ),
                alternatives=[],
                risk_analysis={'error': str(e)},
                effectiveness_score=0.0
            )
    
    def _detect_market_regime(self, market_data: Dict) -> str:
        """Market rejimi tespiti"""
        # Simplified regime detection based on volatility and volume
        price_data = market_data.get('price_history', [])
        
        if len(price_data) < 2:
            return 'normal'
        
        # Calculate volatility
        returns = np.diff(price_data) / price_data[:-1]
        volatility = np.std(returns)
        
        # Volume analysis
        volume_data = market_data.get('volume_24h', 1000000)
        
        # Regime classification
        if volatility > 0.05:
            return 'high_volatility'
        elif volatility > 0.02:
            return 'normal_volatility'
        else:
            return 'low_volatility'
    
    def _generate_candidate_strategies(self, order_request: Any, 
                                     market_data: Dict, market_regime: str) -> List[StrategyParameters]:
        """Candidate stratejileri oluştur"""
        candidates = []
        
        symbol = order_request.symbol
        quantity = order_request.quantity
        urgency = order_request.urgency
        execution_style = order_request.execution_style
        
        # Base strategies based on execution style
        if execution_style.value == 'immediate':
            candidates.append(StrategyParameters(
                strategy=ExecutionStrategy.IMMEDIATE,
                time_horizon_seconds=0,
                slice_count=1,
                max_slice_size=quantity
            ))
        
        elif execution_style.value == 'twap':
            # TWAP strategies with different time horizons
            for horizon in [300, 900, 1800, 3600]:  # 5min to 1 hour
                candidates.append(StrategyParameters(
                    strategy=ExecutionStrategy.TWAP,
                    time_horizon_seconds=horizon,
                    slice_count=max(horizon // 60, 3),  # At least 3 slices
                    max_slice_size=quantity / 10
                ))
        
        elif execution_style.value == 'vwap':
            candidates.append(StrategyParameters(
                strategy=ExecutionStrategy.VWAP,
                time_horizon_seconds=3600,
                slice_count=12,
                max_slice_size=quantity / 10
            ))
        
        # Always consider adaptive as fallback
        candidates.append(StrategyParameters(
            strategy=ExecutionStrategy.ADAPTIVE,
            time_horizon_seconds=1800,
            slice_count=6,
            max_slice_size=quantity / 10,
            dynamic_sizing=True
        ))
        
        # Market regime specific strategies
        if market_regime == 'high_volatility':
            candidates.append(StrategyParameters(
                strategy=ExecutionStrategy.SNIPER,
                time_horizon_seconds=300,
                slice_count=5,
                max_slice_size=quantity / 20
            ))
            candidates.append(StrategyParameters(
                strategy=ExecutionStrategy.ICEBERG,
                time_horizon_seconds=900,
                slice_count=10,
                max_slice_size=quantity / 50
            ))
        elif market_regime == 'low_volatility':
            candidates.append(StrategyParameters(
                strategy=ExecutionStrategy.TWAP,
                time_horizon_seconds=3600,
                slice_count=20,
                max_slice_size=quantity / 30
            ))
            candidates.append(StrategyParameters(
                strategy=ExecutionStrategy.POV,
                time_horizon_seconds=1800,
                slice_count=6,
                max_slice_size=quantity / 10,
                participation_rate=0.1
            ))
        
        # Urgency based adjustments
        if urgency == 'critical':
            # More aggressive strategies for critical orders
            candidates.insert(0, StrategyParameters(
                strategy=ExecutionStrategy.IMMEDIATE,
                time_horizon_seconds=0,
                slice_count=1,
                max_slice_size=quantity
            ))
        elif urgency == 'low':
            # More conservative strategies
            candidates.append(StrategyParameters(
                strategy=ExecutionStrategy.VWAP,
                time_horizon_seconds=7200,  # 2 hours
                slice_count=24,
                max_slice_size=quantity / 30
            ))
        
        # Limit to max strategies
        return candidates[:self.max_strategies_considered]
    
    async def _evaluate_strategy(self, strategy: StrategyParameters, 
                               order_request: Any, market_data: Dict,
                               market_impact: Optional[MarketImpactResult],
                               slippage_calculation: Optional[SlippageCalculation],
                               ml_prediction: Optional[Any]) -> Optional[StrategyEvaluation]:
        """Strategy değerlendirmesi"""
        try:
            symbol = order_request.symbol
            quantity = order_request.quantity
            side = order_request.side
            
            # Calculate expected slippage
            expected_slippage = await self._calculate_expected_slippage(
                strategy, order_request, market_data, slippage_calculation
            )
            
            # Calculate execution time
            execution_time = await self._calculate_execution_time(strategy, market_data)
            
            # Calculate risk score
            risk_score = await self._calculate_strategy_risk(strategy, market_data)
            
            # Calculate success probability
            success_probability = self._calculate_success_probability(
                strategy, market_data, risk_score
            )
            
            # Calculate cost breakdown
            cost_breakdown = await self._calculate_cost_breakdown(
                strategy, expected_slippage, market_data
            )
            
            # Calculate venue allocation
            venue_allocation = await self._calculate_venue_allocation(
                strategy, market_data
            )
            
            # Calculate performance score
            performance_score = self._calculate_performance_score(
                expected_slippage, execution_time, risk_score, success_probability
            )
            
            return StrategyEvaluation(
                strategy=strategy.strategy,
                expected_slippage_bps=expected_slippage,
                execution_time_seconds=execution_time,
                risk_score=risk_score,
                success_probability=success_probability,
                cost_breakdown=cost_breakdown,
                venue_allocation=venue_allocation,
                performance_score=performance_score,
                parameters=strategy
            )
            
        except Exception as e:
            self.logger.error(f"Strategy evaluation hatası: {e}")
            return None
    
    async def _calculate_expected_slippage(self, strategy: StrategyParameters, 
                                         order_request: Any, market_data: Dict,
                                         slippage_calculation: Optional[SlippageCalculation]) -> float:
        """Expected slippage hesaplama"""
        base_slippage = 0
        
        if slippage_calculation:
            base_slippage = slippage_calculation.predicted_slippage_bps
        
        # Strategy-specific adjustments
        if strategy.strategy == ExecutionStrategy.IMMEDIATE:
            # Higher slippage for immediate execution
            return base_slippage * 1.2
        
        elif strategy.strategy == ExecutionStrategy.TWAP:
            # Slippage reduction through time diversification
            time_reduction = min(strategy.time_horizon_seconds / 3600, 1.0) * 0.3
            return base_slippage * (1.0 - time_reduction)
        
        elif strategy.strategy == ExecutionStrategy.VWAP:
            # VWAP typically reduces slippage
            return base_slippage * 0.7
        
        elif strategy.strategy == ExecutionStrategy.ICEBERG:
            # Iceberg reduces market impact
            impact_reduction = min(strategy.slice_count / 20, 0.5)
            return base_slippage * (1.0 - impact_reduction)
        
        elif strategy.strategy == ExecutionStrategy.POV:
            # POV maintains market participation rate
            participation_adjustment = 1.0 - (strategy.participation_rate or 0.1) * 0.5
            return base_slippage * participation_adjustment
        
        elif strategy.strategy == ExecutionStrategy.SNIPER:
            # Sniper waits for optimal conditions
            return base_slippage * 0.6
        
        elif strategy.strategy == ExecutionStrategy.ADAPTIVE:
            # Adaptive adjusts to market conditions
            return base_slippage * 0.8
        
        else:
            return base_slippage
    
    async def _calculate_execution_time(self, strategy: StrategyParameters, market_data: Dict) -> float:
        """Execution time hesaplama"""
        if strategy.strategy == ExecutionStrategy.IMMEDIATE:
            return 1.0  # 1 second
        
        elif strategy.strategy in [ExecutionStrategy.TWAP, ExecutionStrategy.VWAP]:
            return strategy.time_horizon_seconds
        
        elif strategy.strategy == ExecutionStrategy.ICEBERG:
            # Iceberg execution time based on slice count
            return min(strategy.slice_count * 30, 3600)  # 30s per slice, max 1 hour
        
        elif strategy.strategy == ExecutionStrategy.POV:
            # POV based on participation rate
            base_time = 1800  # 30 minutes
            participation_factor = (strategy.participation_rate or 0.1) / 0.1
            return base_time / participation_factor
        
        elif strategy.strategy == ExecutionStrategy.SNIPER:
            # Sniper waits for opportunities
            return 300  # 5 minutes average
        
        elif strategy.strategy == ExecutionStrategy.ADAPTIVE:
            return strategy.time_horizon_seconds * 0.8
        
        else:
            return 300  # Default 5 minutes
    
    async def _calculate_strategy_risk(self, strategy: StrategyParameters, market_data: Dict) -> float:
        """Strategy risk hesaplama"""
        base_risk = self.strategy_configs.get(strategy.strategy, {}).get('base_risk', 0.5)
        
        # Market condition adjustments
        volatility = market_data.get('volatility_15m', 0.02)
        spread = market_data.get('spread_bps', 10)
        
        if volatility > 0.05:  # High volatility
            base_risk *= 1.5
        elif volatility < 0.02:  # Low volatility
            base_risk *= 0.8
        
        if spread > 50:  # Wide spreads
            base_risk *= 1.3
        
        # Strategy specific adjustments
        if strategy.strategy == ExecutionStrategy.IMMEDIATE:
            # Immediate execution risk increases with order size
            size_risk = min(strategy.max_slice_size / 100000, 1.0)
            base_risk += size_risk * 0.3
        
        elif strategy.strategy == ExecutionStrategy.ADAPTIVE and strategy.dynamic_sizing:
            # Adaptive sizing reduces risk
            base_risk *= 0.7
        
        return min(base_risk, 1.0)
    
    def _calculate_success_probability(self, strategy: StrategyParameters, 
                                     market_data: Dict, risk_score: float) -> float:
        """Success probability hesaplama"""
        base_probability = 1.0 - risk_score
        
        # Market condition adjustments
        liquidity_score = market_data.get('liquidity_score', 0.5)
        base_probability *= liquidity_score
        
        # Venue availability
        venue_count = len(market_data.get('venues', {}))
        if venue_count < 2:
            base_probability *= 0.8
        
        # Strategy specific adjustments
        if strategy.strategy == ExecutionStrategy.SNIPER:
            # Sniper may fail if good opportunities don't arise
            base_probability *= 0.8
        
        return max(base_probability, 0.1)
    
    async def _calculate_cost_breakdown(self, strategy: StrategyParameters, 
                                      expected_slippage: float, market_data: Dict) -> Dict[str, float]:
        """Cost breakdown hesaplama"""
        total_cost = expected_slippage / 10000  # Convert bps to decimal
        
        breakdown = {
            'slippage_cost': total_cost * 0.7,
            'commission_cost': 0.0001,  # 1 bps
            'market_impact_cost': total_cost * 0.2,
            'opportunity_cost': total_cost * 0.1
        }
        
        # Strategy specific adjustments
        if strategy.strategy == ExecutionStrategy.ICEBERG:
            # Iceberg may have higher opportunity cost
            breakdown['opportunity_cost'] *= 1.5
        
        return breakdown
    
    async def _calculate_venue_allocation(self, strategy: StrategyParameters, 
                                        market_data: Dict) -> Dict[str, float]:
        """Venue allocation hesaplama"""
        venues = market_data.get('venues', {})
        
        if not venues:
            return {}
        
        # Equal allocation as default
        equal_allocation = 1.0 / len(venues)
        allocation = {venue: equal_allocation for venue in venues.keys()}
        
        # Strategy specific allocation logic
        if strategy.strategy == ExecutionStrategy.POV:
            # POV may prefer venues with best volume
            for venue, data in venues.items():
                volume = data.get('volume', 100000)
                allocation[venue] = volume
        
        elif strategy.strategy == ExecutionStrategy.ADAPTIVE:
            # Adaptive strategy considers multiple factors
            for venue, data in venues.items():
                score = (
                    data.get('liquidity_score', 0.5) * 0.4 +
                    (data.get('volume', 100000) / 1000000) * 0.3 +
                    (1 - data.get('fee_rate', 0.001)) * 0.3
                )
                allocation[venue] = score
        
        # Normalize allocations
        total_allocation = sum(allocation.values())
        if total_allocation > 0:
            allocation = {venue: alloc / total_allocation for venue, alloc in allocation.items()}
        
        return allocation
    
    def _calculate_performance_score(self, expected_slippage: float, execution_time: float,
                                   risk_score: float, success_probability: float) -> float:
        """Performance score hesaplama"""
        # Lower slippage is better
        slippage_score = 1.0 / (1.0 + expected_slippage / 100)
        
        # Shorter execution time is better for immediate orders, longer for algorithmic
        time_score = 1.0 / (1.0 + execution_time / 3600)
        
        # Lower risk is better
        risk_score_normalized = 1.0 - risk_score
        
        # Higher success probability is better
        success_score = success_probability
        
        # Weighted combination
        weights = {
            'slippage': 0.4,
            'time': 0.2,
            'risk': 0.2,
            'success': 0.2
        }
        
        performance_score = (
            weights['slippage'] * slippage_score +
            weights['time'] * time_score +
            weights['risk'] * risk_score_normalized +
            weights['success'] * success_score
        )
        
        return performance_score
    
    def _select_optimal_strategy(self, strategy_evaluations: List[StrategyEvaluation], 
                               urgency: str) -> StrategyEvaluation:
        """Optimal strategy seçimi"""
        if not strategy_evaluations:
            # Fallback
            return StrategyEvaluation(
                strategy=ExecutionStrategy.IMMEDIATE,
                expected_slippage_bps=50.0,
                execution_time_seconds=1.0,
                risk_score=0.5,
                success_probability=0.8,
                cost_breakdown={},
                venue_allocation={},
                performance_score=0.5,
                parameters=StrategyParameters(
                    strategy=ExecutionStrategy.IMMEDIATE,
                    time_horizon_seconds=0,
                    slice_count=1,
                    max_slice_size=1000
                )
            )
        
        # Urgency-adjusted selection
        if urgency == 'critical':
            # For critical orders, prioritize speed and success probability
            best_strategy = max(
                strategy_evaluations,
                key=lambda s: s.performance_score * 0.5 + s.success_probability * 0.5
            )
        elif urgency == 'low':
            # For low urgency, prioritize cost efficiency
            best_strategy = min(
                strategy_evaluations,
                key=lambda s: s.expected_slippage_bps
            )
        else:
            # Default: balance all factors
            best_strategy = max(
                strategy_evaluations,
                key=lambda s: s.performance_score
            )
        
        return best_strategy
    
    def _generate_alternatives(self, strategy_evaluations: List[StrategyEvaluation],
                             optimal: StrategyEvaluation) -> List[Dict]:
        """Alternatif stratejiler oluştur"""
        alternatives = []
        
        # Top 3 alternatives by performance
        sorted_strategies = sorted(
            strategy_evaluations,
            key=lambda s: s.performance_score,
            reverse=True
        )[1:4]  # Exclude the optimal one
        
        for strategy in sorted_strategies:
            alternatives.append({
                'strategy': strategy.strategy.value,
                'expected_slippage_bps': strategy.expected_slippage_bps,
                'risk_score': strategy.risk_score,
                'success_probability': strategy.success_probability,
                'performance_score': strategy.performance_score,
                'reason': f"Benzer performans, farklı risk/profit profili"
            })
        
        return alternatives
    
    async def _analyze_strategy_risks(self, strategy: StrategyEvaluation,
                                    order_request: Any, market_data: Dict) -> Dict:
        """Strategy risk analizi"""
        risks = {
            'execution_risk': strategy.risk_score,
            'market_risk': market_data.get('volatility_15m', 0.02) * 10,
            'liquidity_risk': 1.0 - market_data.get('liquidity_score', 0.5),
            'venue_risk': 1.0 / max(len(market_data.get('venues', {})), 1)
        }
        
        # Overall risk score
        overall_risk = sum(risks.values()) / len(risks)
        
        # Risk mitigation suggestions
        suggestions = []
        
        if overall_risk > 0.7:
            suggestions.append("Yüksek risk - daha küçük slices kullanın")
            suggestions.append("Daha fazla venue kullanın")
        
        if strategy.strategy == ExecutionStrategy.IMMEDIATE and order_request.quantity > 100000:
            suggestions.append("Büyük emirler için immediate execution riskli olabilir")
        
        if market_data.get('spread_bps', 0) > 50:
            suggestions.append("Geniş spread - TWAP veya VWAP düşünün")
        
        return {
            'individual_risks': risks,
            'overall_risk': overall_risk,
            'risk_level': 'high' if overall_risk > 0.7 else 'medium' if overall_risk > 0.4 else 'low',
            'mitigation_suggestions': suggestions
        }
    
    def _calculate_effectiveness_score(self, optimal_strategy: StrategyEvaluation,
                                     all_evaluations: List[StrategyEvaluation]) -> float:
        """Strategy effectiveness score hesaplama"""
        if not all_evaluations:
            return 0.5
        
        # Compare optimal strategy to alternatives
        avg_performance = np.mean([s.performance_score for s in all_evaluations])
        optimal_performance = optimal_strategy.performance_score
        
        # Effectiveness is how much better the optimal strategy is
        effectiveness = (optimal_performance - avg_performance) / max(avg_performance, 0.1)
        
        return max(0.0, min(1.0, 0.5 + effectiveness))
    
    async def _load_strategy_performance_data(self):
        """Strategy performance data yükle"""
        # Placeholder for loading historical performance data
        self.logger.info("Strategy performance data loaded")
    
    async def _initialize_market_regime_strategies(self):
        """Market regime strategy mappings"""
        self.market_regime_strategies = {
            'high_volatility': [ExecutionStrategy.SNIPER, ExecutionStrategy.ICEBERG],
            'normal_volatility': [ExecutionStrategy.TWAP, ExecutionStrategy.VWAP],
            'low_volatility': [ExecutionStrategy.POV, ExecutionStrategy.TWAP]
        }
        
        self.logger.info("Market regime strategy mappings initialized")
    
    async def _load_venue_characteristics(self):
        """Venue characteristics yükle"""
        self.venue_characteristics = {
            'binance': {'latency': 10, 'liquidity': 0.9, 'fees': 0.001},
            'coinbase': {'latency': 15, 'liquidity': 0.8, 'fees': 0.005},
            'kraken': {'latency': 20, 'liquidity': 0.7, 'fees': 0.0026}
        }
        
        self.logger.info("Venue characteristics loaded")
    
    def get_optimizer_status(self) -> Dict:
        """Optimizer durumu"""
        return {
            'strategy_configs': list(self.strategy_configs.keys()),
            'market_regime_mappings': self.market_regime_strategies,
            'venue_characteristics': self.venue_characteristics,
            'cache_size': len(self.optimization_cache)
        }
    
    async def shutdown(self):
        """Optimizer'ı kapat"""
        self.logger.info("Execution Strategy Optimizer kapatılıyor...")
        
        # Clear caches
        self.optimization_cache.clear()
        
        self.logger.info("Execution Strategy Optimizer kapatıldı")