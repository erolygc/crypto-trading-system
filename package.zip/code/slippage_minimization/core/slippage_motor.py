"""
Bitwisers 2.0 Slippage Minimizasyon Motoru - Ana Koordinatör
Tüm execution bileşenlerini birleştiren ana motor
"""

import asyncio
import logging
import time
import json
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Union
from dataclasses import dataclass, asdict
from enum import Enum
import numpy as np
import pandas as pd

from .market_impact import MarketImpactModel
from .real_time_calculator import RealTimeSlippageCalculator
from .strategy_optimizer import ExecutionStrategyOptimizer
from .transaction_analyzer import TransactionCostAnalyzer
from .performance_attribution import PerformanceAttributionEngine
from .monitoring_system import RealTimeMonitoringSystem
from .backtesting_framework import BacktestingFramework
from .ml_predictor import MLSlippagePredictor
from .adaptive_algorithms import AdaptiveExecutionAlgorithms
from .integration_hub import IntegrationHub

class ExecutionStyle(Enum):
    """Execution stil enum"""
    IMMEDIATE = "immediate"
    TWAP = "twap"
    VWAP = "vwap"
    ICEBERG = "iceberg"
    ADAPTIVE = "adaptive"

class MarketRegime(Enum):
    """Market rejim enum"""
    BULL_MARKET = "bull"
    BEAR_MARKET = "bear"
    SIDEWAYS = "sideways"
    HIGH_VOLATILITY = "high_vol"
    LOW_VOLATILITY = "low_vol"
    TRENDING = "trending"
    RANGING = "ranging"

@dataclass
class SlippageConfig:
    """Slippage motor konfigürasyonu"""
    # Market Impact Model Settings
    market_impact_alpha: float = 0.001
    market_impact_beta: float = 0.5
    market_impact_gamma: float = 0.1
    
    # Real-time Calculator Settings
    update_frequency_ms: int = 100
    max_history_minutes: int = 60
    
    # Strategy Optimizer Settings
    optimization_timeout_ms: int = 500
    max_strategies_considered: int = 10
    
    # ML Predictor Settings
    ml_model_path: Optional[str] = None
    prediction_horizon_seconds: int = 300
    
    # Monitoring Settings
    alert_thresholds: Dict[str, float] = None
    monitoring_enabled: bool = True
    
    def __post_init__(self):
        if self.alert_thresholds is None:
            self.alert_thresholds = {
                'slippage_warning': 0.005,  # 0.5%
                'slippage_critical': 0.01,  # 1%
                'market_impact_warning': 0.003,  # 0.3%
                'execution_time_warning': 5.0  # 5 seconds
            }

@dataclass
class OrderRequest:
    """Order istek formatı"""
    order_id: str
    symbol: str
    side: str  # 'buy' or 'sell'
    quantity: float
    price: Optional[float] = None
    execution_style: ExecutionStyle = ExecutionStyle.IMMEDIATE
    time_horizon_seconds: Optional[int] = None
    urgency: str = 'normal'  # 'low', 'normal', 'high', 'critical'
    max_slippage: Optional[float] = None
    venue_constraints: Optional[List[str]] = None
    metadata: Optional[Dict] = None

@dataclass
class ExecutionResult:
    """Execution sonucu formatı"""
    order_id: str
    success: bool
    execution_time_ms: float
    total_filled: float
    avg_fill_price: float
    slippage_bps: float
    market_impact_bps: float
    transaction_cost_bps: float
    venue_breakdown: List[Dict]
    strategy_used: str
    performance_metrics: Dict
    timestamp: datetime
    
class SlippageMinimizationEngine:
    """
    Ana Slippage Minimizasyon Motoru
    Tüm execution bileşenlerini birleştiren koordinatör
    """
    
    def __init__(self, config: SlippageConfig = None):
        self.config = config or SlippageConfig()
        self.logger = self._setup_logger()
        
        # Core Components
        self.market_impact_model: Optional[MarketImpactModel] = None
        self.real_time_calculator: Optional[RealTimeSlippageCalculator] = None
        self.strategy_optimizer: Optional[ExecutionStrategyOptimizer] = None
        self.transaction_analyzer: Optional[TransactionCostAnalyzer] = None
        self.performance_attribution: Optional[PerformanceAttributionEngine] = None
        self.monitoring_system: Optional[RealTimeMonitoringSystem] = None
        self.backtesting_framework: Optional[BacktestingFramework] = None
        self.ml_predictor: Optional[MLSlippagePredictor] = None
        self.adaptive_algorithms: Optional[AdaptiveExecutionAlgorithms] = None
        self.integration_hub: Optional[IntegrationHub] = None
        
        # State Management
        self.is_running = False
        self.active_orders: Dict[str, Dict] = {}
        self.order_history: List[Dict] = []
        self.performance_metrics = {
            'total_orders': 0,
            'successful_orders': 0,
            'total_slippage_saved': 0.0,
            'avg_execution_time': 0.0,
            'avg_slippage_bps': 0.0
        }
        
        # Market Data Cache
        self.market_data_cache = {}
        self.last_update_time = {}
        
        self.logger.info("Slippage Minimization Engine oluşturuldu")
    
    def _setup_logger(self) -> logging.Logger:
        """Logger setup"""
        logger = logging.getLogger("SlippageMotor")
        logger.setLevel(logging.INFO)
        
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        
        return logger
    
    async def initialize(self) -> bool:
        """Motoru başlat"""
        try:
            self.logger.info("Slippage Minimization Engine başlatılıyor...")
            
            # Core bileşenleri başlat
            self.market_impact_model = MarketImpactModel(self.config)
            await self.market_impact_model.initialize()
            
            self.real_time_calculator = RealTimeSlippageCalculator(self.config)
            await self.real_time_calculator.initialize()
            
            self.strategy_optimizer = ExecutionStrategyOptimizer(self.config)
            await self.strategy_optimizer.initialize()
            
            self.transaction_analyzer = TransactionCostAnalyzer(self.config)
            await self.transaction_analyzer.initialize()
            
            self.performance_attribution = PerformanceAttributionEngine(self.config)
            await self.performance_attribution.initialize()
            
            self.ml_predictor = MLSlippagePredictor(self.config)
            await self.ml_predictor.initialize()
            
            self.adaptive_algorithms = AdaptiveExecutionAlgorithms(self.config)
            await self.adaptive_algorithms.initialize()
            
            # Monitoring sistemini başlat
            if self.config.monitoring_enabled:
                self.monitoring_system = RealTimeMonitoringSystem(self.config)
                await self.monitoring_system.initialize()
            
            # Integration hub'ı başlat
            self.integration_hub = IntegrationHub(self.config)
            await self.integration_hub.initialize()
            
            # Background taskları başlat
            await self._start_background_tasks()
            
            self.is_running = True
            self.logger.info("Slippage Minimization Engine başarıyla başlatıldı")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Motor başlatma hatası: {e}")
            return False
    
    async def _start_background_tasks(self):
        """Background taskları başlat"""
        tasks = [
            asyncio.create_task(self._market_data_loop()),
            asyncio.create_task(self._performance_monitoring_loop()),
            asyncio.create_task(self._model_update_loop()),
            asyncio.create_task(self._cleanup_loop())
        ]
        
        self.background_tasks = tasks
        
        if self.monitoring_system:
            tasks.append(asyncio.create_task(self._monitoring_loop()))
        
        self.logger.info(f"{len(tasks)} background task başlatıldı")
    
    async def _market_data_loop(self):
        """Market data güncelleme döngüsü"""
        while self.is_running:
            try:
                # Market data'yı güncelle
                await self._update_market_data()
                
                # Real-time slippage hesaplamaları
                await self.real_time_calculator.update_calculations(self.market_data_cache)
                
                await asyncio.sleep(self.config.update_frequency_ms / 1000)
                
            except Exception as e:
                self.logger.error(f"Market data loop hatası: {e}")
                await asyncio.sleep(1)
    
    async def _performance_monitoring_loop(self):
        """Performance monitoring döngüsü"""
        while self.is_running:
            try:
                # Performance metriklerini güncelle
                await self._update_performance_metrics()
                
                # Performance attribution hesapla
                if self.performance_metrics['total_orders'] > 0:
                    await self.performance_attribution.update_attribution(
                        self.order_history[-100:]  # Son 100 order
                    )
                
                await asyncio.sleep(60)  # Her dakika
                
            except Exception as e:
                self.logger.error(f"Performance monitoring hatası: {e}")
                await asyncio.sleep(60)
    
    async def _monitoring_loop(self):
        """Monitoring sistemi döngüsü"""
        while self.is_running:
            try:
                await self.monitoring_system.check_system_health()
                await self.monitoring_system.check_alerts()
                await asyncio.sleep(30)
                
            except Exception as e:
                self.logger.error(f"Monitoring loop hatası: {e}")
                await asyncio.sleep(30)
    
    async def _model_update_loop(self):
        """ML model güncelleme döngüsü"""
        while self.is_running:
            try:
                # Order history'den model eğitimi
                if len(self.order_history) > 100:
                    await self.ml_predictor.update_model(self.order_history[-1000:])
                
                # Adaptive algorithm güncellemeleri
                await self.adaptive_algorithms.update_strategies(self.order_history)
                
                await asyncio.sleep(3600)  # Her saat
                
            except Exception as e:
                self.logger.error(f"Model update loop hatası: {e}")
                await asyncio.sleep(3600)
    
    async def _cleanup_loop(self):
        """Cleanup döngüsü"""
        while self.is_running:
            try:
                # Eski order history'yi temizle
                cutoff_time = datetime.now() - timedelta(days=30)
                self.order_history = [
                    order for order in self.order_history
                    if order['timestamp'] > cutoff_time
                ]
                
                # Market data cache'i temizle
                self._cleanup_market_cache()
                
                await asyncio.sleep(3600)  # Her saat
                
            except Exception as e:
                self.logger.error(f"Cleanup loop hatası: {e}")
                await asyncio.sleep(3600)
    
    def _cleanup_market_cache(self):
        """Market data cache'ini temizle"""
        cutoff_time = datetime.now() - timedelta(minutes=30)
        
        symbols_to_remove = []
        for symbol, last_update in self.last_update_time.items():
            if last_update < cutoff_time:
                symbols_to_remove.append(symbol)
        
        for symbol in symbols_to_remove:
            self.market_data_cache.pop(symbol, None)
            self.last_update_time.pop(symbol, None)
        
        if symbols_to_remove:
            self.logger.debug(f"Cache'den {len(symbols_to_remove)} sembol temizlendi")
    
    async def _update_market_data(self):
        """Market data güncelle"""
        # Integration hub'dan market data al
        if self.integration_hub:
            market_data = await self.integration_hub.get_market_data()
            
            for symbol, data in market_data.items():
                self.market_data_cache[symbol] = data
                self.last_update_time[symbol] = datetime.now()
    
    async def execute_order(self, order_request: OrderRequest) -> ExecutionResult:
        """
        Ana order execution fonksiyonu
        Slippage minimizasyonu ile akıllı execution
        """
        start_time = time.time()
        
        try:
            self.logger.info(f"Order execution başlatıldı: {order_request.order_id}")
            
            # Market data hazırla
            market_data = self.market_data_cache.get(order_request.symbol)
            if not market_data:
                self.logger.warning(f"Market data bulunamadı: {order_request.symbol}")
            
            # Market impact modelleme
            market_impact = await self.market_impact_model.calculate_market_impact(
                order_request.symbol,
                order_request.quantity,
                order_request.side,
                market_data
            )
            
            # Real-time slippage hesaplama
            slippage_calculation = await self.real_time_calculator.calculate_slippage(
                order_request.symbol,
                order_request.quantity,
                order_request.side,
                market_data
            )
            
            # ML-based slippage prediction
            ml_prediction = await self.ml_predictor.predict_slippage(
                order_request.symbol,
                order_request.quantity,
                order_request.side,
                market_data
            )
            
            # Execution strategy optimizasyonu
            strategy_optimization = await self.strategy_optimizer.optimize_strategy(
                order_request,
                market_data,
                market_impact,
                slippage_calculation,
                ml_prediction
            )
            
            # Adaptive algorithm execution
            execution_plan = await self.adaptive_algorithms.create_execution_plan(
                order_request,
                strategy_optimization
            )
            
            # Transaction cost analysis
            cost_analysis = await self.transaction_analyzer.analyze_costs(
                order_request,
                execution_plan,
                market_data
            )
            
            # Execution simülasyonu/gerçek execution
            execution_result = await self._execute_order_plan(
                order_request,
                execution_plan,
                cost_analysis
            )
            
            # Performance attribution
            performance_attribution = await self.performance_attribution.attribute_performance(
                execution_result,
                strategy_optimization,
                ml_prediction
            )
            
            # Sonuç oluştur
            result = ExecutionResult(
                order_id=order_request.order_id,
                success=execution_result['success'],
                execution_time_ms=(time.time() - start_time) * 1000,
                total_filled=execution_result['total_filled'],
                avg_fill_price=execution_result['avg_fill_price'],
                slippage_bps=execution_result['slippage_bps'],
                market_impact_bps=market_impact.impact_bps if market_impact else 0,
                transaction_cost_bps=cost_analysis.total_cost_bps,
                venue_breakdown=execution_result['venue_breakdown'],
                strategy_used=strategy_optimization.selected_strategy,
                performance_metrics={
                    'slippage_prediction_error': abs(
                        (execution_result['slippage_bps'] - ml_prediction.predicted_slippage_bps)
                        if ml_prediction else 0
                    ),
                    'market_impact_realized': market_impact.impact_bps if market_impact else 0,
                    'cost_breakdown': cost_analysis.breakdown,
                    'performance_attribution': performance_attribution,
                    'strategy_effectiveness': strategy_optimization.effectiveness_score
                },
                timestamp=datetime.now()
            )
            
            # Order history'ye ekle
            self.order_history.append(asdict(result))
            
            # Performance metrics güncelle
            self._update_execution_metrics(result)
            
            # Monitoring alerts
            if self.monitoring_system:
                await self.monitoring_system.check_execution_alerts(result)
            
            self.logger.info(f"Order execution tamamlandı: {order_request.order_id}, "
                           f"Slippage: {result.slippage_bps:.2f} bps")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Order execution hatası: {e}")
            
            return ExecutionResult(
                order_id=order_request.order_id,
                success=False,
                execution_time_ms=(time.time() - start_time) * 1000,
                total_filled=0.0,
                avg_fill_price=0.0,
                slippage_bps=0.0,
                market_impact_bps=0.0,
                transaction_cost_bps=0.0,
                venue_breakdown=[],
                strategy_used="failed",
                performance_metrics={'error': str(e)},
                timestamp=datetime.now()
            )
    
    async def _execute_order_plan(self, order_request: OrderRequest, 
                                 execution_plan: Dict, cost_analysis: Any) -> Dict:
        """
        Order planını execute et
        Integration hub üzerinden gerçek execution veya simülasyon
        """
        try:
            # Integration hub ile execution
            if self.integration_hub:
                result = await self.integration_hub.execute_order(
                    order_request,
                    execution_plan
                )
                return result
            else:
                # Fallback: Simulated execution
                return await self._simulate_execution(order_request, execution_plan)
                
        except Exception as e:
            self.logger.error(f"Order execution plan hatası: {e}")
            return {
                'success': False,
                'total_filled': 0.0,
                'avg_fill_price': 0.0,
                'slippage_bps': 0.0,
                'venue_breakdown': []
            }
    
    async def _simulate_execution(self, order_request: OrderRequest, execution_plan: Dict) -> Dict:
        """Execution simülasyonu"""
        # Basit simülasyon logic'i
        total_filled = order_request.quantity * 0.99  # 99% fill assumption
        
        # Venue breakdown simülasyonu
        venue_breakdown = []
        if 'venues' in execution_plan:
            for venue in execution_plan['venues']:
                venue_breakdown.append({
                    'venue': venue['name'],
                    'quantity': venue['quantity'],
                    'price': venue['price'],
                    'filled': venue['quantity'] * 0.99
                })
        
        return {
            'success': True,
            'total_filled': total_filled,
            'avg_fill_price': execution_plan.get('avg_price', 0),
            'slippage_bps': 5.0,  # Simulated slippage
            'venue_breakdown': venue_breakdown
        }
    
    def _update_execution_metrics(self, result: ExecutionResult):
        """Execution metriklerini güncelle"""
        self.performance_metrics['total_orders'] += 1
        
        if result.success:
            self.performance_metrics['successful_orders'] += 1
        
        # Ortalama hesaplamaları
        total_orders = self.performance_metrics['total_orders']
        
        # Sliding average calculations
        self.performance_metrics['avg_slippage_bps'] = (
            (self.performance_metrics['avg_slippage_bps'] * (total_orders - 1) + result.slippage_bps) / total_orders
        )
        
        self.performance_metrics['avg_execution_time'] = (
            (self.performance_metrics['avg_execution_time'] * (total_orders - 1) + result.execution_time_ms) / total_orders
        )
    
    async def _update_performance_metrics(self):
        """Performance metriklerini güncelle"""
        if not self.order_history:
            return
        
        recent_orders = self.order_history[-100:]  # Son 100 order
        
        # Başarılı order oranı
        successful_orders = sum(1 for order in recent_orders if order['success'])
        success_rate = successful_orders / len(recent_orders)
        
        # Ortalama slippage
        avg_slippage = np.mean([order['slippage_bps'] for order in recent_orders if order['success']])
        
        # Toplam slippage tasarrufu
        total_saved = sum(
            order.get('performance_metrics', {}).get('slippage_saved_bps', 0)
            for order in recent_orders
        )
        
        self.performance_metrics.update({
            'success_rate': success_rate,
            'avg_slippage_bps': avg_slippage,
            'total_slippage_saved': total_saved,
            'last_update': datetime.now()
        })
    
    async def get_performance_report(self, days: int = 7) -> Dict:
        """Performance raporu getir"""
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_orders = [
            order for order in self.order_history
            if order['timestamp'] > cutoff_date
        ]
        
        if not recent_orders:
            return {'message': 'Belirtilen dönemde order bulunamadı'}
        
        # Summary statistics
        total_orders = len(recent_orders)
        successful_orders = sum(1 for order in recent_orders if order['success'])
        success_rate = successful_orders / total_orders
        
        avg_slippage = np.mean([order['slippage_bps'] for order in recent_orders if order['success']])
        avg_execution_time = np.mean([order['execution_time_ms'] for order in recent_orders])
        
        # Strategy breakdown
        strategy_breakdown = {}
        for order in recent_orders:
            strategy = order.get('strategy_used', 'unknown')
            if strategy not in strategy_breakdown:
                strategy_breakdown[strategy] = {'count': 0, 'success_rate': 0, 'avg_slippage': 0}
            
            strategy_breakdown[strategy]['count'] += 1
            if order['success']:
                strategy_breakdown[strategy]['success_rate'] += 1
        
        # Calculate success rates
        for strategy, stats in strategy_breakdown.items():
            stats['success_rate'] = stats['success_rate'] / stats['count']
        
        return {
            'period_days': days,
            'summary': {
                'total_orders': total_orders,
                'successful_orders': successful_orders,
                'success_rate': success_rate,
                'avg_slippage_bps': avg_slippage,
                'avg_execution_time_ms': avg_execution_time
            },
            'strategy_breakdown': strategy_breakdown,
            'performance_metrics': self.performance_metrics,
            'generated_at': datetime.now()
        }
    
    async def run_backtest(self, config: Dict) -> Dict:
        """Backtesting çalıştır"""
        if not self.backtesting_framework:
            self.backtesting_framework = BacktestingFramework(self.config)
            await self.backtesting_framework.initialize()
        
        return await self.backtesting_framework.run_backtest(config)
    
    async def shutdown(self):
        """Motoru kapat"""
        self.logger.info("Slippage Minimization Engine kapatılıyor...")
        
        self.is_running = False
        
        # Background taskları durdur
        if hasattr(self, 'background_tasks'):
            for task in self.background_tasks:
                task.cancel()
            
            await asyncio.gather(*self.background_tasks, return_exceptions=True)
        
        # Bileşenleri kapat
        components = [
            self.market_impact_model,
            self.real_time_calculator,
            self.strategy_optimizer,
            self.transaction_analyzer,
            self.performance_attribution,
            self.ml_predictor,
            self.adaptive_algorithms,
            self.integration_hub
        ]
        
        for component in components:
            if component and hasattr(component, 'shutdown'):
                await component.shutdown()
        
        if self.monitoring_system:
            await self.monitoring_system.shutdown()
        
        self.logger.info("Slippage Minimization Engine kapatıldı")

# Global instance
_slippage_engine_instance = None

async def get_slippage_engine(config: SlippageConfig = None) -> SlippageMinimizationEngine:
    """Global slippage engine instance"""
    global _slippage_engine_instance
    
    if _slippage_engine_instance is None:
        _slippage_engine_instance = SlippageMinimizationEngine(config)
        await _slippage_engine_instance.initialize()
    
    return _slippage_engine_instance

async def shutdown_slippage_engine():
    """Slippage engine'i kapat"""
    global _slippage_engine_instance
    
    if _slippage_engine_instance:
        await _slippage_engine_instance.shutdown()
        _slippage_engine_instance = None