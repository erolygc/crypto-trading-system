"""
Transaction Cost Analysis Module
Kapsamlı transaction cost analizi ve hesaplama
"""

import asyncio
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum
import json

@dataclass
class CostComponent:
    """Cost bileşeni"""
    name: str
    cost: float
    cost_bps: float
    description: str
    venue_specific: Dict[str, float]
    calculation_method: str

@dataclass
class CostAnalysis:
    """Cost analiz sonucu"""
    total_cost: float
    total_cost_bps: float
    components: List[CostComponent]
    breakdown_by_venue: Dict[str, float]
    breakdown_by_category: Dict[str, float]
    comparison_benchmark: Dict[str, float]
    optimization_opportunities: List[str]
    timestamp: datetime

class TransactionCostCategory(Enum):
    """Transaction cost kategorileri"""
    COMMISSIONS = "commissions"
    SLIPPAGE = "slippage"
    MARKET_IMPACT = "market_impact"
    OPPORTUNITY_COST = "opportunity_cost"
    FUNDING_COST = "funding_cost"
    BID_ASK_SPREAD = "bid_ask_spread"
    DELAY_COST = "delay_cost"
    VENUE_COST = "venue_cost"

class TransactionCostAnalyzer:
    """
    Transaction Cost Analyzer
    Kapsamlı transaction cost analizi ve optimizasyon
    """
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Fee structures by venue
        self.venue_fees = {
            'binance': {'maker': 0.001, 'taker': 0.001, 'withdrawal': 0.0005},
            'coinbase': {'maker': 0.005, 'taker': 0.005, 'withdrawal': 0.001},
            'kraken': {'maker': 0.0016, 'taker': 0.0026, 'withdrawal': 0.0015},
            'bitfinex': {'maker': 0.001, 'taker': 0.002, 'withdrawal': 0.0004},
            'okx': {'maker': 0.0008, 'taker': 0.001, 'withdrawal': 0.0004}
        }
        
        # Cost calculation models
        self.cost_models = {
            'slippage': self._calculate_slippage_cost,
            'market_impact': self._calculate_market_impact_cost,
            'commission': self._calculate_commission_cost,
            'bid_ask_spread': self._calculate_spread_cost,
            'opportunity_cost': self._calculate_opportunity_cost,
            'delay_cost': self._calculate_delay_cost,
            'funding_cost': self._calculate_funding_cost
        }
        
        # Historical cost data
        self.cost_history = []
        self.venue_cost_profiles = {}
        
        # Benchmark data
        self.benchmark_data = {
            'industry_average': {
                'slippage_bps': 8.0,
                'commission_bps': 5.0,
                'total_cost_bps': 15.0
            },
            'best_practice': {
                'slippage_bps': 3.0,
                'commission_bps': 2.0,
                'total_cost_bps': 6.0
            },
            'cost_breakdown_benchmarks': {
                'slippage': 0.4,
                'commission': 0.25,
                'market_impact': 0.2,
                'other': 0.15
            }
        }
        
        self.logger.info("Transaction Cost Analyzer oluşturuldu")
    
    async def initialize(self) -> bool:
        """Analyzer'ı başlat"""
        try:
            self.logger.info("Transaction Cost Analyzer başlatılıyor...")
            
            # Load venue cost profiles
            await self._load_venue_cost_profiles()
            
            # Load historical cost data
            await self._load_historical_cost_data()
            
            # Initialize cost calculation parameters
            await self._initialize_cost_parameters()
            
            self.logger.info("Transaction Cost Analyzer başarıyla başlatıldı")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Transaction Cost Analyzer başlatma hatası: {e}")
            return False
    
    async def analyze_costs(self, order_request: Any, execution_plan: Dict, 
                          market_data: Dict) -> CostAnalysis:
        """
        Ana cost analiz fonksiyonu
        """
        try:
            self.logger.info(f"Cost analysis başlatıldı: {order_request.order_id}")
            
            # Extract order details
            symbol = order_request.symbol
            quantity = order_request.quantity
            side = order_request.side
            
            # Cost components calculation
            cost_components = []
            
            # 1. Commission costs
            commission_costs = await self._calculate_commission_costs(
                execution_plan, market_data
            )
            cost_components.extend(commission_costs)
            
            # 2. Slippage costs
            slippage_costs = await self._calculate_slippage_costs(
                execution_plan, market_data
            )
            cost_components.extend(slippage_costs)
            
            # 3. Market impact costs
            impact_costs = await self._calculate_impact_costs(
                execution_plan, market_data
            )
            cost_components.extend(impact_costs)
            
            # 4. Bid-ask spread costs
            spread_costs = await self._calculate_spread_costs(
                execution_plan, market_data
            )
            cost_components.extend(spread_costs)
            
            # 5. Opportunity costs
            opportunity_costs = await self._calculate_opportunity_costs(
                execution_plan, market_data
            )
            cost_components.extend(opportunity_costs)
            
            # 6. Delay costs
            delay_costs = await self._calculate_delay_costs(
                execution_plan, market_data
            )
            cost_components.extend(delay_costs)
            
            # 7. Venue-specific costs
            venue_costs = await self._calculate_venue_specific_costs(
                execution_plan, market_data
            )
            cost_components.extend(venue_costs)
            
            # Calculate totals
            total_cost = sum(component.cost for component in cost_components)
            total_cost_bps = self._calculate_total_bps(cost_components, quantity, market_data)
            
            # Venue breakdown
            venue_breakdown = self._calculate_venue_breakdown(cost_components)
            
            # Category breakdown
            category_breakdown = self._calculate_category_breakdown(cost_components)
            
            # Benchmark comparison
            benchmark_comparison = self._compare_to_benchmarks(total_cost_bps, category_breakdown)
            
            # Optimization opportunities
            optimization_opportunities = self._identify_optimization_opportunities(
                cost_components, category_breakdown
            )
            
            # Create analysis result
            analysis = CostAnalysis(
                total_cost=total_cost,
                total_cost_bps=total_cost_bps,
                components=cost_components,
                breakdown_by_venue=venue_breakdown,
                breakdown_by_category=category_breakdown,
                comparison_benchmark=benchmark_comparison,
                optimization_opportunities=optimization_opportunities,
                timestamp=datetime.now()
            )
            
            # Store in history
            await self._store_cost_analysis(order_request, analysis)
            
            self.logger.info(
                f"Cost analysis tamamlandı. Toplam maliyet: {total_cost_bps:.2f} bps"
            )
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Cost analysis hatası: {e}")
            return CostAnalysis(
                total_cost=0.0,
                total_cost_bps=0.0,
                components=[],
                breakdown_by_venue={},
                breakdown_by_category={},
                comparison_benchmark={},
                optimization_opportunities=[f"Analysis error: {str(e)}"],
                timestamp=datetime.now()
            )
    
    async def _calculate_commission_costs(self, execution_plan: Dict, 
                                        market_data: Dict) -> List[CostComponent]:
        """Commission cost hesaplama"""
        components = []
        
        execution_details = execution_plan.get('execution_details', [])
        
        for execution in execution_details:
            venue = execution.get('venue', 'unknown')
            filled_quantity = execution.get('filled_quantity', 0)
            price = execution.get('price', 0)
            
            if filled_quantity <= 0 or price <= 0:
                continue
            
            # Get venue fee structure
            venue_fee = self.venue_fees.get(venue, {'taker': 0.001})
            fee_rate = venue_fee.get('taker', 0.001)  # Assume taker fees
            
            # Calculate commission cost
            trade_value = filled_quantity * price
            commission_cost = trade_value * fee_rate
            
            # Calculate cost in bps
            commission_cost_bps = fee_rate * 10000
            
            components.append(CostComponent(
                name=f"commission_{venue}",
                cost=commission_cost,
                cost_bps=commission_cost_bps,
                description=f"{venue} komisyon maliyeti",
                venue_specific={venue: commission_cost},
                calculation_method="percentage_of_trade_value"
            ))
        
        return components
    
    async def _calculate_slippage_costs(self, execution_plan: Dict, 
                                      market_data: Dict) -> List[CostComponent]:
        """Slippage cost hesaplama"""
        components = []
        
        # Calculate overall slippage
        total_filled = execution_plan.get('total_filled', 0)
        expected_price = market_data.get('expected_price', 0)
        actual_avg_price = execution_plan.get('avg_fill_price', 0)
        
        if total_filled > 0 and expected_price > 0 and actual_avg_price > 0:
            # Calculate slippage
            price_difference = abs(actual_avg_price - expected_price)
            slippage_percentage = price_difference / expected_price
            slippage_cost = total_filled * price_difference
            
            # Convert to bps
            slippage_cost_bps = slippage_percentage * 10000
            
            components.append(CostComponent(
                name="slippage_cost",
                cost=slippage_cost,
                cost_bps=slippage_cost_bps,
                description="Slippage maliyeti (beklenen vs gerçekleşen fiyat)",
                venue_specific={},  # Applies to entire order
                calculation_method="price_difference_percentage"
            ))
        
        return components
    
    async def _calculate_impact_costs(self, execution_plan: Dict, 
                                    market_data: Dict) -> List[CostComponent]:
        """Market impact cost hesaplama"""
        components = []
        
        # Estimate market impact based on order size and market depth
        total_quantity = execution_plan.get('total_quantity', 0)
        market_depth = market_data.get('market_depth', 100000)
        
        if total_quantity > 0 and market_depth > 0:
            # Simple market impact model
            impact_ratio = total_quantity / market_depth
            impact_percentage = 0.001 * (impact_ratio ** 0.5)  # Square root model
            
            # Calculate impact cost
            avg_price = execution_plan.get('avg_fill_price', 0)
            impact_cost = total_quantity * avg_price * impact_percentage
            
            # Convert to bps
            impact_cost_bps = impact_percentage * 10000
            
            components.append(CostComponent(
                name="market_impact_cost",
                cost=impact_cost,
                cost_bps=impact_cost_bps,
                description="Market impact maliyeti (büyük emirlerin piyasa etkisi)",
                venue_specific={},
                calculation_method="square_root_impact_model"
            ))
        
        return components
    
    async def _calculate_spread_costs(self, execution_plan: Dict, 
                                    market_data: Dict) -> List[CostComponent]:
        """Bid-ask spread cost hesaplama"""
        components = []
        
        # Get spread information
        bid_ask_spread = market_data.get('bid_ask_spread_bps', 10)
        total_filled = execution_plan.get('total_filled', 0)
        
        if total_filled > 0 and bid_ask_spread > 0:
            # Spread cost assumes paying half the spread
            spread_cost_percentage = bid_ask_spread / 20000  # Half of spread in decimal
            
            # Calculate spread cost
            avg_price = execution_plan.get('avg_fill_price', 0)
            spread_cost = total_filled * avg_price * spread_cost_percentage
            
            components.append(CostComponent(
                name="bid_ask_spread_cost",
                cost=spread_cost,
                cost_bps=bid_ask_spread / 2,  # Half spread in bps
                description="Alım-satım fiyat farkı maliyeti",
                venue_specific={},
                calculation_method="half_spread_model"
            ))
        
        return components
    
    async def _calculate_opportunity_costs(self, execution_plan: Dict, 
                                         market_data: Dict) -> List[CostComponent]:
        """Opportunity cost hesaplama"""
        components = []
        
        # Calculate opportunity cost based on execution time and market movement
        execution_time_seconds = execution_plan.get('execution_time_seconds', 0)
        market_volatility = market_data.get('volatility_15m', 0.02)
        
        if execution_time_seconds > 0 and market_volatility > 0:
            # Estimate potential price movement during execution
            time_factor = execution_time_seconds / 3600  # Convert to hours
            potential_movement = market_volatility * np.sqrt(time_factor)
            
            # Opportunity cost is potential missed gain
            total_value = execution_plan.get('total_filled', 0) * execution_plan.get('avg_fill_price', 0)
            opportunity_cost = total_value * potential_movement * 0.5  # Assume 50% of potential movement
            
            components.append(CostComponent(
                name="opportunity_cost",
                cost=opportunity_cost,
                cost_bps=potential_movement * 5000,  # Convert to bps
                description="Fırsat maliyeti (execution süresince kaçırılan kazanç)",
                venue_specific={},
                calculation_method="volatility_time_model"
            ))
        
        return components
    
    async def _calculate_delay_costs(self, execution_plan: Dict, 
                                   market_data: Dict) -> List[CostComponent]:
        """Delay cost hesaplama"""
        components = []
        
        # Calculate delay cost due to order processing time
        order_delay_seconds = execution_plan.get('order_delay_seconds', 0)
        
        if order_delay_seconds > 5:  # Only if significant delay
            # Estimate cost of delay
            delay_cost_percentage = (order_delay_seconds / 3600) * 0.001  # 0.1% per hour of delay
            
            total_value = execution_plan.get('total_filled', 0) * execution_plan.get('avg_fill_price', 0)
            delay_cost = total_value * delay_cost_percentage
            
            components.append(CostComponent(
                name="delay_cost",
                cost=delay_cost,
                cost_bps=delay_cost_percentage * 10000,
                description="Gecikme maliyeti (emir işlem gecikmesi)",
                venue_specific={},
                calculation_method="time_based_delay_model"
            ))
        
        return components
    
    async def _calculate_venue_specific_costs(self, execution_plan: Dict, 
                                            market_data: Dict) -> List[CostComponent]:
        """Venue-specific cost hesaplama"""
        components = []
        
        # Additional venue costs (withdrawal fees, network fees, etc.)
        execution_details = execution_plan.get('execution_details', [])
        
        venue_additional_costs = {}
        
        for execution in execution_details:
            venue = execution.get('venue', 'unknown')
            filled_quantity = execution.get('filled_quantity', 0)
            
            # Estimate withdrawal or transfer costs
            if venue in self.venue_fees:
                withdrawal_fee = self.venue_fees[venue].get('withdrawal', 0.0005)
                withdrawal_cost = filled_quantity * withdrawal_fee
                
                if withdrawal_cost > 0:
                    if venue not in venue_additional_costs:
                        venue_additional_costs[venue] = 0
                    venue_additional_costs[venue] += withdrawal_cost
        
        # Add venue-specific costs as separate components
        for venue, cost in venue_additional_costs.items():
            if cost > 0:
                avg_price = execution_plan.get('avg_fill_price', 0)
                cost_bps = (cost / (execution_plan.get('total_filled', 1) * avg_price)) * 10000
                
                components.append(CostComponent(
                    name=f"venue_specific_{venue}",
                    cost=cost,
                    cost_bps=cost_bps,
                    description=f"{venue} özel maliyetleri",
                    venue_specific={venue: cost},
                    calculation_method="fixed_percentage_withdrawal"
                ))
        
        return components
    
    def _calculate_total_bps(self, components: List[CostComponent], 
                           quantity: float, market_data: Dict) -> float:
        """Total cost in bps hesaplama"""
        if not components or quantity <= 0:
            return 0.0
        
        # Get average price
        avg_price = market_data.get('avg_price', market_data.get('expected_price', 0))
        
        if avg_price <= 0:
            return 0.0
        
        total_value = quantity * avg_price
        total_cost = sum(component.cost for component in components)
        
        return (total_cost / total_value) * 10000 if total_value > 0 else 0.0
    
    def _calculate_venue_breakdown(self, components: List[CostComponent]) -> Dict[str, float]:
        """Venue bazlı breakdown"""
        venue_breakdown = {}
        
        for component in components:
            for venue, cost in component.venue_specific.items():
                if venue not in venue_breakdown:
                    venue_breakdown[venue] = 0
                venue_breakdown[venue] += cost
        
        return venue_breakdown
    
    def _calculate_category_breakdown(self, components: List[CostComponent]) -> Dict[str, float]:
        """Kategori bazlı breakdown"""
        category_breakdown = {}
        
        for component in components:
            category = component.name.split('_')[0]  # First part of name as category
            
            if category not in category_breakdown:
                category_breakdown[category] = 0
            
            category_breakdown[category] += component.cost
        
        return category_breakdown
    
    def _compare_to_benchmarks(self, total_cost_bps: float, 
                             category_breakdown: Dict[str, float]) -> Dict[str, float]:
        """Benchmark karşılaştırması"""
        benchmarks = self.benchmark_data
        
        comparison = {
            'total_cost_vs_industry': total_cost_bps - benchmarks['industry_average']['total_cost_bps'],
            'total_cost_vs_best_practice': total_cost_bps - benchmarks['best_practice']['total_cost_bps'],
            'cost_category_breakdown': {}
        }
        
        # Compare individual categories
        for category, cost in category_breakdown.items():
            benchmark_slippage = benchmarks['cost_breakdown_benchmarks'].get(category, 0.2)
            comparison['cost_category_breakdown'][category] = {
                'actual_percentage': cost / sum(category_breakdown.values()) if sum(category_breakdown.values()) > 0 else 0,
                'benchmark_percentage': benchmark_slippage,
                'difference': (cost / sum(category_breakdown.values()) if sum(category_breakdown.values()) > 0 else 0) - benchmark_slippage
            }
        
        return comparison
    
    def _identify_optimization_opportunities(self, components: List[CostComponent],
                                           category_breakdown: Dict[str, float]) -> List[str]:
        """Optimizasyon fırsatları"""
        opportunities = []
        
        total_cost = sum(category_breakdown.values())
        if total_cost == 0:
            return opportunities
        
        # Check for high commission costs
        commission_cost = category_breakdown.get('commission', 0)
        commission_percentage = commission_cost / total_cost
        if commission_percentage > 0.3:
            opportunities.append("Komisyon maliyetleri yüksek - düşük komisyonlu venue'ları tercih edin")
        
        # Check for high slippage costs
        slippage_cost = category_breakdown.get('slippage', 0)
        slippage_percentage = slippage_cost / total_cost
        if slippage_percentage > 0.5:
            opportunities.append("Slippage maliyetleri yüksek - TWAP/VWAP execution kullanmayı düşünün")
        
        # Check for high market impact
        impact_cost = category_breakdown.get('market', 0)
        impact_percentage = impact_cost / total_cost
        if impact_percentage > 0.3:
            opportunities.append("Market impact yüksek - küçük slices veya iceberg execution kullanın")
        
        # Check for high opportunity cost
        opportunity_cost = category_breakdown.get('opportunity', 0)
        opportunity_percentage = opportunity_cost / total_cost
        if opportunity_percentage > 0.2:
            opportunities.append("Fırsat maliyeti yüksek - daha hızlı execution stratejileri kullanın")
        
        # Check for spread costs
        spread_cost = category_breakdown.get('bid', 0)
        spread_percentage = spread_cost / total_cost
        if spread_percentage > 0.3:
            opportunities.append("Spread maliyeti yüksek - spread'i dar olan venue'ları tercih edin")
        
        return opportunities
    
    async def _store_cost_analysis(self, order_request: Any, analysis: CostAnalysis):
        """Cost analizini history'ye ekle"""
        try:
            # Store for future optimization
            self.cost_history.append({
                'order_id': order_request.order_id,
                'symbol': order_request.symbol,
                'quantity': order_request.quantity,
                'total_cost_bps': analysis.total_cost_bps,
                'timestamp': analysis.timestamp,
                'components': [component.__dict__ for component in analysis.components]
            })
            
            # Keep only recent history
            cutoff_date = datetime.now() - timedelta(days=30)
            self.cost_history = [
                record for record in self.cost_history
                if record['timestamp'] > cutoff_date
            ]
            
        except Exception as e:
            self.logger.error(f"Cost history kaydetme hatası: {e}")
    
    async def _load_venue_cost_profiles(self):
        """Venue cost profillerini yükle"""
        # This would load from a database or configuration file in production
        self.logger.info("Venue cost profiles loaded")
    
    async def _load_historical_cost_data(self):
        """Historical cost data yükle"""
        # This would load historical cost data for benchmarking
        self.logger.info("Historical cost data loaded")
    
    async def _initialize_cost_parameters(self):
        """Cost parametrelerini başlat"""
        self.logger.info("Cost calculation parameters initialized")
    
    def get_cost_statistics(self, days: int = 7) -> Dict:
        """Cost istatistikleri"""
        cutoff_date = datetime.now() - timedelta(days=days)
        recent_costs = [
            record for record in self.cost_history
            if record['timestamp'] > cutoff_date
        ]
        
        if not recent_costs:
            return {'message': 'No cost data available for the specified period'}
        
        # Calculate statistics
        total_orders = len(recent_costs)
        avg_cost_bps = np.mean([record['total_cost_bps'] for record in recent_costs])
        cost_std = np.std([record['total_cost_bps'] for record in recent_costs])
        
        # Category averages
        category_averages = {}
        all_categories = set()
        for record in recent_costs:
            for component in record.get('components', []):
                category = component['name'].split('_')[0]
                all_categories.add(category)
        
        for category in all_categories:
            category_costs = []
            for record in recent_costs:
                for component in record.get('components', []):
                    if component['name'].startswith(category):
                        category_costs.append(component['cost_bps'])
            
            if category_costs:
                category_averages[category] = {
                    'avg_cost_bps': np.mean(category_costs),
                    'std_cost_bps': np.std(category_costs)
                }
        
        return {
            'period_days': days,
            'total_orders': total_orders,
            'average_cost_bps': avg_cost_bps,
            'cost_std_bps': cost_std,
            'category_averages': category_averages,
            'benchmark_comparison': self._compare_to_benchmarks(avg_cost_bps, {})
        }
    
    async def shutdown(self):
        """Analyzer'ı kapat"""
        self.logger.info("Transaction Cost Analyzer kapatılıyor...")
        
        # Clear history
        self.cost_history.clear()
        
        self.logger.info("Transaction Cost Analyzer kapatıldı")