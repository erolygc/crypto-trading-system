"""
Performance Attribution Engine Module
Execution performansını detaylı analiz ve attribution
"""

import asyncio
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum
import json
from scipy import stats

@dataclass
class PerformanceAttribution:
    """Performance attribution sonucu"""
    order_id: str
    total_attribution: Dict[str, float]
    strategy_contribution: Dict[str, float]
    venue_contribution: Dict[str, float]
    market_timing_contribution: Dict[str, float]
    execution_quality_contribution: Dict[str, float]
    slippage_savings: float
    opportunity_cost: float
    overall_score: float
    timestamp: datetime

@dataclass
class AttributionFactor:
    """Attribution faktörü"""
    factor_name: str
    contribution: float
    contribution_bps: float
    significance: float
    description: str

class PerformanceAttributionEngine:
    """
    Performance Attribution Engine
    Execution performansını faktör bazında analiz
    """
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Attribution models
        self.attribution_models = {
            'brinson': self._brinson_attribution,
            'factor_based': self._factor_based_attribution,
            'transaction_cost': self._transaction_cost_attribution,
            'benchmark_relative': self._benchmark_relative_attribution
        }
        
        # Performance benchmarks
        self.benchmarks = {
            'arrival_price': {
                'slippage_bps': 5.0,
                'execution_quality': 0.8
            },
            'implementation_shortfall': {
                'slippage_bps': 8.0,
                'execution_quality': 0.7
            },
            'vwap': {
                'slippage_bps': 3.0,
                'execution_quality': 0.9
            },
            'market_on_close': {
                'slippage_bps': 10.0,
                'execution_quality': 0.6
            }
        }
        
        # Market factor models
        self.market_factors = {
            'volatility_regime': self._volatility_regime_impact,
            'liquidity_conditions': self._liquidity_conditions_impact,
            'market_timing': self._market_timing_impact,
            'venue_selection': self._venue_selection_impact,
            'strategy_selection': self._strategy_selection_impact
        }
        
        # Historical performance data
        self.performance_history = []
        self.factor_returns = {}
        self.attribution_cache = {}
        
        # Attribution configuration
        self.attribution_horizon_days = 30
        self.minimum_observations = 10
        
        self.logger.info("Performance Attribution Engine oluşturuldu")
    
    async def initialize(self) -> bool:
        """Engine'i başlat"""
        try:
            self.logger.info("Performance Attribution Engine başlatılıyor...")
            
            # Load historical performance data
            await self._load_performance_history()
            
            # Initialize factor models
            await self._initialize_factor_models()
            
            # Load attribution benchmarks
            await self._load_attribution_benchmarks()
            
            self.logger.info("Performance Attribution Engine başarıyla başlatıldı")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Performance Attribution Engine başlatma hatası: {e}")
            return False
    
    async def attribute_performance(self, execution_result: Any, 
                                  strategy_optimization: Any,
                                  ml_prediction: Optional[Any] = None) -> Dict[str, Any]:
        """
        Ana performance attribution fonksiyonu
        """
        try:
            order_id = execution_result.order_id
            self.logger.info(f"Performance attribution başlatıldı: {order_id}")
            
            # Get or calculate benchmarks
            benchmark_data = await self._get_benchmark_data(
                execution_result, strategy_optimization
            )
            
            # Calculate attribution components
            total_attribution = await self._calculate_total_attribution(
                execution_result, benchmark_data
            )
            
            # Strategy contribution
            strategy_contribution = await self._calculate_strategy_contribution(
                execution_result, strategy_optimization
            )
            
            # Venue contribution
            venue_contribution = await self._calculate_venue_contribution(
                execution_result
            )
            
            # Market timing contribution
            market_timing_contribution = await self._calculate_market_timing_contribution(
                execution_result
            )
            
            # Execution quality contribution
            execution_quality_contribution = await self._calculate_execution_quality(
                execution_result, benchmark_data
            )
            
            # Calculate specific metrics
            slippage_savings = await self._calculate_slippage_savings(
                execution_result, benchmark_data
            )
            
            opportunity_cost = await self._calculate_opportunity_cost(
                execution_result, benchmark_data
            )
            
            # Overall performance score
            overall_score = self._calculate_overall_score(
                total_attribution, strategy_contribution, 
                venue_contribution, execution_quality_contribution
            )
            
            # Create attribution result
            attribution = PerformanceAttribution(
                order_id=order_id,
                total_attribution=total_attribution,
                strategy_contribution=strategy_contribution,
                venue_contribution=venue_contribution,
                market_timing_contribution=market_timing_contribution,
                execution_quality_contribution=execution_quality_contribution,
                slippage_savings=slippage_savings,
                opportunity_cost=opportunity_cost,
                overall_score=overall_score,
                timestamp=datetime.now()
            )
            
            # Store attribution
            await self._store_attribution(attribution)
            
            # Convert to dict for return
            result = {
                'total_attribution': attribution.total_attribution,
                'strategy_contribution': attribution.strategy_contribution,
                'venue_contribution': attribution.venue_contribution,
                'market_timing_contribution': attribution.market_timing_contribution,
                'execution_quality_contribution': attribution.execution_quality_contribution,
                'slippage_savings_bps': attribution.slippage_savings,
                'opportunity_cost_bps': attribution.opportunity_cost,
                'overall_score': attribution.overall_score,
                'breakdown': await self._create_detailed_breakdown(attribution)
            }
            
            self.logger.info(
                f"Performance attribution tamamlandı. Overall score: {overall_score:.2f}"
            )
            
            return result
            
        except Exception as e:
            self.logger.error(f"Performance attribution hatası: {e}")
            return {
                'total_attribution': {'error': str(e)},
                'strategy_contribution': {},
                'venue_contribution': {},
                'market_timing_contribution': {},
                'execution_quality_contribution': {},
                'slippage_savings_bps': 0.0,
                'opportunity_cost_bps': 0.0,
                'overall_score': 0.0,
                'error': str(e)
            }
    
    async def update_attribution(self, recent_orders: List[Dict]):
        """Attribution modelini güncelle"""
        try:
            # Add new orders to history
            for order in recent_orders:
                if isinstance(order, dict) and order.get('success'):
                    self.performance_history.append(order)
            
            # Keep only recent history
            cutoff_date = datetime.now() - timedelta(days=self.attribution_horizon_days)
            self.performance_history = [
                record for record in self.performance_history
                if record.get('timestamp', datetime.now()) > cutoff_date
            ]
            
            # Update factor models if enough data
            if len(self.performance_history) >= self.minimum_observations:
                await self._update_factor_models()
            
            self.logger.debug(f"Attribution updated with {len(recent_orders)} new orders")
            
        except Exception as e:
            self.logger.error(f"Attribution update hatası: {e}")
    
    async def _calculate_total_attribution(self, execution_result: Any, 
                                         benchmark_data: Dict) -> Dict[str, float]:
        """Total attribution hesaplama"""
        # Actual vs benchmark performance
        actual_slippage = execution_result.slippage_bps
        benchmark_slippage = benchmark_data.get('slippage_bps', 8.0)
        
        total_attribution = {
            'relative_performance': benchmark_slippage - actual_slippage,
            'absolute_performance': -actual_slippage,  # Negative is good for slippage
            'benchmark_outperformance': max(0, benchmark_slippage - actual_slippage),
            'cost_efficiency': (benchmark_slippage - actual_slippage) / benchmark_slippage if benchmark_slippage > 0 else 0
        }
        
        return total_attribution
    
    async def _calculate_strategy_contribution(self, execution_result: Any, 
                                             strategy_optimization: Any) -> Dict[str, float]:
        """Strategy contribution hesaplama"""
        strategy_used = execution_result.strategy_used
        strategy_effectiveness = getattr(strategy_optimization, 'effectiveness_score', 0.5)
        
        # Strategy-specific contribution
        strategy_benchmarks = {
            'immediate': {'slippage_bps': 12.0, 'speed_score': 1.0},
            'twap': {'slippage_bps': 6.0, 'speed_score': 0.7},
            'vwap': {'slippage_bps': 4.0, 'speed_score': 0.8},
            'iceberg': {'slippage_bps': 5.0, 'speed_score': 0.9},
            'adaptive': {'slippage_bps': 3.0, 'speed_score': 0.8}
        }
        
        benchmark = strategy_benchmarks.get(strategy_used, strategy_benchmarks['immediate'])
        actual_slippage = execution_result.slippage_bps
        
        strategy_contribution = {
            'strategy_selection_impact': benchmark['slippage_bps'] - actual_slippage,
            'strategy_effectiveness': strategy_effectiveness * 10,  # Scale to bps
            'speed_vs_cost_tradeoff': benchmark['speed_score'] * (1 - actual_slippage/benchmark['slippage_bps']),
            'strategy_optimization_gain': strategy_effectiveness * (benchmark['slippage_bps'] - actual_slippage)
        }
        
        return strategy_contribution
    
    async def _calculate_venue_contribution(self, execution_result: Any) -> Dict[str, float]:
        """Venue contribution hesaplama"""
        venue_breakdown = execution_result.venue_breakdown
        
        if not venue_breakdown:
            return {'venue_selection_impact': 0}
        
        # Calculate venue-specific performance
        venue_performance = {}
        total_quantity = 0
        
        for venue_data in venue_breakdown:
            venue = venue_data.get('venue', 'unknown')
            filled_quantity = venue_data.get('filled', 0)
            total_quantity += filled_quantity
            
            # Estimated venue-specific slippage
            venue_slippage = self._estimate_venue_slippage(venue, filled_quantity)
            venue_performance[venue] = venue_slippage
        
        # Calculate overall venue contribution
        if venue_performance:
            weighted_avg_slippage = sum(
                perf * (venue_breakdown[i].get('filled', 0) / total_quantity)
                for i, (venue, perf) in enumerate(venue_performance.items())
                if total_quantity > 0
            )
            
            # Compare to worst venue performance
            worst_venue_slippage = max(venue_performance.values())
            
            venue_contribution = {
                'venue_selection_impact': worst_venue_slippage - weighted_avg_slippage,
                'venue_diversification_benefit': worst_venue_slippage - weighted_avg_slippage,
                'best_venue_performance': min(venue_performance.values()),
                'venue_allocation_efficiency': 1 - (weighted_avg_slippage / worst_venue_slippage) if worst_venue_slippage > 0 else 0
            }
        else:
            venue_contribution = {'venue_selection_impact': 0}
        
        return venue_contribution
    
    def _estimate_venue_slippage(self, venue: str, quantity: float) -> float:
        """Venue-specific slippage tahmini"""
        # Simple venue characteristics
        venue_characteristics = {
            'binance': {'liquidity': 0.9, 'spread': 2.0},
            'coinbase': {'liquidity': 0.8, 'spread': 5.0},
            'kraken': {'liquidity': 0.7, 'spread': 8.0},
            'bitfinex': {'liquidity': 0.6, 'spread': 10.0},
            'okx': {'liquidity': 0.85, 'spread': 3.0}
        }
        
        characteristics = venue_characteristics.get(venue, {'liquidity': 0.5, 'spread': 10.0})
        
        # Base slippage = spread/2 + size impact
        base_slippage = characteristics['spread'] / 2
        
        # Size impact based on liquidity
        size_impact = (quantity / 100000) * (1 - characteristics['liquidity']) * 10
        
        return base_slippage + size_impact
    
    async def _calculate_market_timing_contribution(self, execution_result: Any) -> Dict[str, float]:
        """Market timing contribution hesaplama"""
        # This would analyze market conditions during execution
        # For now, return a simplified calculation
        
        execution_time_ms = execution_result.execution_time_ms
        
        # Estimate timing based on execution speed
        if execution_time_ms < 1000:  # Fast execution
            timing_factor = 1.0
        elif execution_time_ms < 10000:  # Medium execution
            timing_factor = 0.8
        else:  # Slow execution
            timing_factor = 0.6
        
        # Market timing impact
        market_timing_contribution = {
            'execution_timing_impact': (1 - timing_factor) * 5,  # Assume 5 bps max timing impact
            'market_condition_alignment': timing_factor * 3,
            'volatility_timing': timing_factor * 2,
            'liquidity_timing': timing_factor * 1
        }
        
        return market_timing_contribution
    
    async def _calculate_execution_quality(self, execution_result: Any, 
                                         benchmark_data: Dict) -> Dict[str, float]:
        """Execution quality hesaplama"""
        actual_slippage = execution_result.slippage_bps
        benchmark_slippage = benchmark_data.get('slippage_bps', 8.0)
        
        # Calculate various quality metrics
        fill_rate = execution_result.total_filled / max(execution_result.total_filled + 
                                                       getattr(execution_result, 'unfilled_quantity', 0), 1)
        
        price_alignment = 1 - (abs(execution_result.avg_fill_price - 
                                 benchmark_data.get('expected_price', execution_result.avg_fill_price)) / 
                              benchmark_data.get('expected_price', execution_result.avg_fill_price))
        
        execution_quality = {
            'slippage_vs_benchmark': benchmark_slippage - actual_slippage,
            'fill_quality': fill_rate * 5,  # Scale to bps equivalent
            'price_alignment': price_alignment * 3,
            'execution_consistency': 1 - (actual_slippage / benchmark_slippage) if benchmark_slippage > 0 else 0,
            'overall_quality_score': ((benchmark_slippage - actual_slippage) + fill_rate * 5 + price_alignment * 3) / 3
        }
        
        return execution_quality
    
    async def _calculate_slippage_savings(self, execution_result: Any, 
                                        benchmark_data: Dict) -> float:
        """Slippage tasarrufu hesaplama"""
        actual_slippage = execution_result.slippage_bps
        worst_case_slippage = 20.0  # Assume 20 bps worst case
        
        return max(0, worst_case_slippage - actual_slippage)
    
    async def _calculate_opportunity_cost(self, execution_result: Any, 
                                        benchmark_data: Dict) -> float:
        """Opportunity cost hesaplama"""
        # Opportunity cost from execution delay
        execution_time_ms = execution_result.execution_time_ms
        market_volatility = 0.02  # Assume 2% volatility
        
        # Estimate potential price movement during execution
        time_hours = execution_time_ms / (1000 * 3600)
        potential_movement = market_volatility * np.sqrt(time_hours)
        
        return potential_movement * 5000  # Convert to bps
    
    def _calculate_overall_score(self, total_attribution: Dict, strategy_contribution: Dict,
                               venue_contribution: Dict, execution_quality: Dict) -> float:
        """Overall performance score hesaplama"""
        # Weighted combination of all attribution factors
        weights = {
            'relative_performance': 0.3,
            'strategy_selection_impact': 0.2,
            'venue_selection_impact': 0.15,
            'execution_timing_impact': 0.15,
            'overall_quality_score': 0.2
        }
        
        score = 0
        for factor, weight in weights.items():
            # Extract relevant values from different dictionaries
            value = 0
            if factor in total_attribution:
                value = total_attribution[factor]
            elif factor in strategy_contribution:
                value = strategy_contribution[factor]
            elif factor in venue_contribution:
                value = venue_contribution[factor]
            elif factor in execution_quality:
                value = execution_quality[factor]
            
            # Normalize to 0-1 scale and apply weight
            normalized_value = max(0, min(1, (value + 10) / 20))  # Assuming values range -10 to +10
            score += weight * normalized_value
        
        return score
    
    async def _create_detailed_breakdown(self, attribution: PerformanceAttribution) -> Dict:
        """Detaylı breakdown oluştur"""
        return {
            'performance_summary': {
                'total_performance_gain_bps': sum(attribution.total_attribution.values()),
                'strategy_effectiveness': attribution.strategy_contribution,
                'venue_optimization': attribution.venue_contribution,
                'timing_quality': attribution.market_timing_contribution,
                'execution_excellence': attribution.execution_quality_contribution
            },
            'savings_analysis': {
                'slippage_saved_bps': attribution.slippage_savings,
                'opportunity_cost_bps': attribution.opportunity_cost,
                'net_benefit_bps': attribution.slippage_savings - attribution.opportunity_cost
            },
            'quality_metrics': {
                'overall_score': attribution.overall_score,
                'score_breakdown': {
                    'strategy_selection': np.mean(list(attribution.strategy_contribution.values())),
                    'venue_selection': np.mean(list(attribution.venue_contribution.values())),
                    'market_timing': np.mean(list(attribution.market_timing_contribution.values())),
                    'execution_quality': np.mean(list(attribution.execution_quality_contribution.values()))
                }
            }
        }
    
    async def _get_benchmark_data(self, execution_result: Any, 
                                strategy_optimization: Any) -> Dict:
        """Benchmark data al"""
        # Get benchmark based on strategy
        strategy = execution_result.strategy_used
        benchmark = self.benchmarks.get(strategy, self.benchmarks['implementation_shortfall'])
        
        # Add market-specific adjustments
        return {
            'slippage_bps': benchmark['slippage_bps'],
            'execution_quality': benchmark['execution_quality'],
            'expected_price': execution_result.avg_fill_price,  # Simplified
            'strategy_adjustment': getattr(strategy_optimization, 'optimization_score', 0) * 2
        }
    
    async def _brinson_attribution(self, order_data: Dict) -> Dict:
        """Brinson attribution modeli"""
        # Traditional performance attribution
        return {'allocation_effect': 0, 'selection_effect': 0, 'interaction_effect': 0}
    
    async def _factor_based_attribution(self, order_data: Dict) -> Dict:
        """Factor-based attribution modeli"""
        # Multi-factor attribution analysis
        return {'factor_contributions': {}}
    
    async def _transaction_cost_attribution(self, order_data: Dict) -> Dict:
        """Transaction cost attribution modeli"""
        # Focus on transaction cost components
        return {'cost_attribution': {}}
    
    async def _benchmark_relative_attribution(self, order_data: Dict) -> Dict:
        """Benchmark relative attribution modeli"""
        # Relative to benchmark performance
        return {'relative_attribution': {}}
    
    async def _volatility_regime_impact(self, order_data: Dict) -> float:
        """Volatilite rejimi etkisi"""
        return 0.0  # Simplified
    
    async def _liquidity_conditions_impact(self, order_data: Dict) -> float:
        """Likidite koşulları etkisi"""
        return 0.0  # Simplified
    
    async def _market_timing_impact(self, order_data: Dict) -> float:
        """Market timing etkisi"""
        return 0.0  # Simplified
    
    async def _venue_selection_impact(self, order_data: Dict) -> float:
        """Venue seçimi etkisi"""
        return 0.0  # Simplified
    
    async def _strategy_selection_impact(self, order_data: Dict) -> float:
        """Strategy seçimi etkisi"""
        return 0.0  # Simplified
    
    async def _load_performance_history(self):
        """Performance history yükle"""
        # Placeholder for loading historical performance data
        self.logger.info("Performance history loaded")
    
    async def _initialize_factor_models(self):
        """Factor modellerini başlat"""
        self.logger.info("Factor models initialized")
    
    async def _load_attribution_benchmarks(self):
        """Attribution benchmarks yükle"""
        self.logger.info("Attribution benchmarks loaded")
    
    async def _update_factor_models(self):
        """Factor modellerini güncelle"""
        if len(self.performance_history) < self.minimum_observations:
            return
        
        # Update factor return calculations
        self.factor_returns = {
            'strategy_factor': self._calculate_strategy_factor_returns(),
            'venue_factor': self._calculate_venue_factor_returns(),
            'timing_factor': self._calculate_timing_factor_returns()
        }
        
        self.logger.debug("Factor models updated")
    
    def _calculate_strategy_factor_returns(self) -> Dict:
        """Strategy factor returns hesaplama"""
        # Calculate returns attributed to strategy selection
        return {}
    
    def _calculate_venue_factor_returns(self) -> Dict:
        """Venue factor returns hesaplama"""
        # Calculate returns attributed to venue selection
        return {}
    
    def _calculate_timing_factor_returns(self) -> Dict:
        """Timing factor returns hesaplama"""
        # Calculate returns attributed to market timing
        return {}
    
    async def _store_attribution(self, attribution: PerformanceAttribution):
        """Attribution sonucunu kaydet"""
        try:
            self.attribution_cache[attribution.order_id] = attribution
            
            # Keep cache size manageable
            if len(self.attribution_cache) > 1000:
                # Remove oldest entries
                sorted_items = sorted(
                    self.attribution_cache.items(),
                    key=lambda x: x[1].timestamp
                )
                
                self.attribution_cache = dict(sorted_items[-500:])  # Keep last 500
            
        except Exception as e:
            self.logger.error(f"Attribution storage hatası: {e}")
    
    def get_attribution_report(self, days: int = 7) -> Dict:
        """Attribution raporu"""
        cutoff_date = datetime.now() - timedelta(days=days)
        
        recent_attributions = [
            attr for attr in self.attribution_cache.values()
            if attr.timestamp > cutoff_date
        ]
        
        if not recent_attributions:
            return {'message': 'No attribution data available for the specified period'}
        
        # Calculate summary statistics
        avg_overall_score = np.mean([attr.overall_score for attr in recent_attributions])
        avg_slippage_savings = np.mean([attr.slippage_savings for attr in recent_attributions])
        
        # Strategy breakdown
        strategy_scores = {}
        for attr in recent_attributions:
            strategy_contributions = attr.strategy_contribution
            for factor, contribution in strategy_contributions.items():
                if factor not in strategy_scores:
                    strategy_scores[factor] = []
                strategy_scores[factor].append(contribution)
        
        strategy_summary = {
            factor: {
                'mean': np.mean(values),
                'std': np.std(values),
                'count': len(values)
            }
            for factor, values in strategy_scores.items()
        }
        
        return {
            'period_days': days,
            'total_attributions': len(recent_attributions),
            'summary': {
                'average_overall_score': avg_overall_score,
                'average_slippage_savings_bps': avg_slippage_savings,
                'performance_consistency': 1 - np.std([attr.overall_score for attr in recent_attributions])
            },
            'factor_analysis': strategy_summary,
            'top_performers': sorted(
                [(attr.order_id, attr.overall_score) for attr in recent_attributions],
                key=lambda x: x[1],
                reverse=True
            )[:10]
        }
    
    async def shutdown(self):
        """Engine'i kapat"""
        self.logger.info("Performance Attribution Engine kapatılıyor...")
        
        # Clear caches
        self.attribution_cache.clear()
        self.performance_history.clear()
        self.factor_returns.clear()
        
        self.logger.info("Performance Attribution Engine kapatıldı")