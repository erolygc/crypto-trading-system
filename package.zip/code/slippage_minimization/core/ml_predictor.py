"""
ML-based Slippage Predictor Module
Machine Learning tabanlı slippage tahmin sistemi
"""

import asyncio
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum
import joblib
import warnings
warnings.filterwarnings('ignore')

# ML libraries
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.feature_selection import SelectKBest, f_regression
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

@dataclass
class SlippagePrediction:
    """Slippage tahmin sonucu"""
    symbol: str
    predicted_slippage_bps: float
    confidence_score: float
    prediction_interval: Tuple[float, float]
    model_used: str
    feature_importance: Dict[str, float]
    market_conditions: Dict[str, float]
    timestamp: datetime

@dataclass
class TrainingData:
    """Training data formatı"""
    features: np.ndarray
    target: np.ndarray
    timestamps: List[datetime]
    symbols: List[str]
    metadata: Dict[str, Any]

class MLPredictorType(Enum):
    """ML predictor türleri"""
    RANDOM_FOREST = "random_forest"
    GRADIENT_BOOSTING = "gradient_boosting"
    NEURAL_NETWORK = "neural_network"
    ENSEMBLE = "ensemble"

class MLSlippagePredictor:
    """
    ML-based Slippage Predictor
    Machine learning models for slippage prediction
    """
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Model configuration
        self.model_path = config.ml_model_path
        self.prediction_horizon_seconds = config.prediction_horizon_seconds
        
        # ML Models
        self.models = {}
        self.scalers = {}
        self.feature_selectors = {}
        
        # Model types to use
        self.model_types = [
            MLPredictorType.RANDOM_FOREST,
            MLPredictorType.GRADIENT_BOOSTING,
            MLPredictorType.NEURAL_NETWORK
        ]
        
        # Feature engineering
        self.feature_columns = [
            'volume_ratio',
            'volatility_1m',
            'volatility_5m',
            'volatility_15m',
            'volatility_1h',
            'spread_bps',
            'bid_ask_ratio',
            'order_book_imbalance',
            'market_depth_ratio',
            'price_momentum_5m',
            'price_momentum_15m',
            'volume_momentum',
            'liquidity_score',
            'time_of_day',
            'day_of_week',
            'market_regime',
            'venue_concentration',
            'previous_slippage',
            'market_impact_score',
            'volatility_regime'
        ]
        
        # Training data
        self.training_data = None
        self.model_performance = {}
        
        # Prediction cache
        self.prediction_cache = {}
        self.cache_ttl_seconds = 30
        
        # Model update settings
        self.min_training_samples = 1000
        self.update_frequency_hours = 24
        self.last_model_update = None
        
        self.logger.info("ML Slippage Predictor oluşturuldu")
    
    async def initialize(self) -> bool:
        """Predictor'ı başlat"""
        try:
            self.logger.info("ML Slippage Predictor başlatılıyor...")
            
            # Initialize models
            await self._initialize_models()
            
            # Load pre-trained models if available
            if self.model_path:
                await self._load_pretrained_models()
            
            # Load training data
            await self._load_training_data()
            
            # Train initial models
            if self._should_train_initial_models():
                await self._train_initial_models()
            
            self.logger.info("ML Slippage Predictor başarıyla başlatıldı")
            
            return True
            
        except Exception as e:
            self.logger.error(f"ML Predictor başlatma hatası: {e}")
            return False
    
    async def predict_slippage(self, symbol: str, quantity: float, 
                             side: str, market_data: Dict) -> Optional[SlippagePrediction]:
        """
        Ana slippage tahmin fonksiyonu
        """
        try:
            # Check cache first
            cache_key = f"{symbol}_{quantity}_{side}_{hash(str(market_data))}"
            
            if cache_key in self.prediction_cache:
                cached_prediction = self.prediction_cache[cache_key]
                if (datetime.now() - cached_prediction.timestamp).total_seconds() < self.cache_ttl_seconds:
                    return cached_prediction
            
            # Prepare features
            features = await self._prepare_features(symbol, quantity, side, market_data)
            if features is None:
                return None
            
            # Generate predictions using all models
            predictions = {}
            
            for model_type in self.model_types:
                try:
                    prediction = await self._predict_with_model(model_type, features)
                    if prediction is not None:
                        predictions[model_type.value] = prediction
                except Exception as e:
                    self.logger.warning(f"Model {model_type.value} prediction hatası: {e}")
            
            if not predictions:
                return None
            
            # Ensemble prediction
            ensemble_prediction = self._ensemble_predictions(predictions)
            
            # Calculate confidence
            confidence = self._calculate_confidence(predictions, features)
            
            # Get prediction interval
            prediction_interval = self._calculate_prediction_interval(predictions)
            
            # Get feature importance
            feature_importance = self._get_feature_importance(features)
            
            # Market conditions
            market_conditions = self._extract_market_conditions(market_data)
            
            # Create result
            result = SlippagePrediction(
                symbol=symbol,
                predicted_slippage_bps=ensemble_prediction,
                confidence_score=confidence,
                prediction_interval=prediction_interval,
                model_used=','.join(predictions.keys()),
                feature_importance=feature_importance,
                market_conditions=market_conditions,
                timestamp=datetime.now()
            )
            
            # Cache result
            self.prediction_cache[cache_key] = result
            
            return result
            
        except Exception as e:
            self.logger.error(f"Slippage prediction hatası: {e}")
            return None
    
    async def update_model(self, execution_history: List[Dict]):
        """Model güncelleme"""
        try:
            self.logger.info("ML model güncelleme başlatılıyor...")
            
            # Prepare training data from execution history
            new_training_data = await self._prepare_training_data(execution_history)
            
            if new_training_data is None or len(new_training_data.features) < 100:
                self.logger.warning("Yetersiz training data")
                return
            
            # Add to existing training data
            if self.training_data is None:
                self.training_data = new_training_data
            else:
                self.training_data = self._merge_training_data(self.training_data, new_training_data)
            
            # Retrain models
            await self._retrain_models()
            
            # Save updated models
            if self.model_path:
                await self._save_models()
            
            self.last_model_update = datetime.now()
            
            self.logger.info(f"Model güncelleme tamamlandı. Training samples: {len(self.training_data.features)}")
            
        except Exception as e:
            self.logger.error(f"Model güncelleme hatası: {e}")
    
    async def _initialize_models(self):
        """Models başlat"""
        # Random Forest
        self.models[MLPredictorType.RANDOM_FOREST] = RandomForestRegressor(
            n_estimators=100,
            max_depth=15,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1
        )
        
        # Gradient Boosting
        self.models[MLPredictorType.GRADIENT_BOOSTING] = GradientBoostingRegressor(
            n_estimators=100,
            max_depth=6,
            learning_rate=0.1,
            subsample=0.8,
            random_state=42
        )
        
        # Neural Network
        self.models[MLPredictorType.NEURAL_NETWORK] = MLPRegressor(
            hidden_layer_sizes=(100, 50, 25),
            activation='relu',
            solver='adam',
            alpha=0.001,
            learning_rate='adaptive',
            max_iter=500,
            random_state=42
        )
        
        # Initialize scalers
        for model_type in self.model_types:
            self.scalers[model_type] = StandardScaler()
            self.feature_selectors[model_type] = SelectKBest(score_func=f_regression, k=15)
        
        self.logger.info("Models initialized")
    
    async def _prepare_features(self, symbol: str, quantity: float, 
                              side: str, market_data: Dict) -> Optional[np.ndarray]:
        """Features hazırlama"""
        try:
            features = []
            
            # Volume ratio
            avg_volume = market_data.get('avg_volume', 1000000)
            volume_ratio = quantity / max(avg_volume, 1)
            features.append(volume_ratio)
            
            # Volatility features
            vol_1m = market_data.get('volatility_1m', 0.02)
            vol_5m = market_data.get('volatility_5m', 0.02)
            vol_15m = market_data.get('volatility_15m', 0.02)
            vol_1h = market_data.get('volatility_1h', 0.02)
            
            features.extend([vol_1m, vol_5m, vol_15m, vol_1h])
            
            # Spread and liquidity
            spread_bps = market_data.get('spread_bps', 10)
            bid_ask_ratio = market_data.get('bid_ask_ratio', 1.0)
            order_book_imbalance = market_data.get('order_book_imbalance', 0.0)
            market_depth_ratio = market_data.get('market_depth_ratio', 1.0)
            
            features.extend([spread_bps, bid_ask_ratio, order_book_imbalance, market_depth_ratio])
            
            # Price momentum
            price_momentum_5m = market_data.get('price_momentum_5m', 0.0)
            price_momentum_15m = market_data.get('price_momentum_15m', 0.0)
            volume_momentum = market_data.get('volume_momentum', 0.0)
            
            features.extend([price_momentum_5m, price_momentum_15m, volume_momentum])
            
            # Market conditions
            liquidity_score = market_data.get('liquidity_score', 0.5)
            time_of_day = datetime.now().hour / 24.0
            day_of_week = datetime.now().weekday() / 7.0
            market_regime = self._encode_market_regime(market_data.get('market_regime', 'normal'))
            
            features.extend([liquidity_score, time_of_day, day_of_week, market_regime])
            
            # Additional features
            venue_concentration = market_data.get('venue_concentration', 0.5)
            previous_slippage = market_data.get('previous_slippage', 0.0)
            market_impact_score = market_data.get('market_impact_score', 0.0)
            volatility_regime = market_data.get('volatility_regime', 0.0)
            
            features.extend([venue_concentration, previous_slippage, market_impact_score, volatility_regime])
            
            # Ensure we have the right number of features
            if len(features) != len(self.feature_columns):
                self.logger.warning(f"Feature count mismatch: {len(features)} vs {len(self.feature_columns)}")
                return None
            
            return np.array(features).reshape(1, -1)
            
        except Exception as e:
            self.logger.error(f"Feature preparation hatası: {e}")
            return None
    
    def _encode_market_regime(self, regime: str) -> float:
        """Market regime encoding"""
        regime_mapping = {
            'bull': 1.0,
            'bear': -1.0,
            'sideways': 0.0,
            'high_vol': 1.0,
            'low_vol': -1.0,
            'normal': 0.0
        }
        return regime_mapping.get(regime, 0.0)
    
    async def _predict_with_model(self, model_type: MLPredictorType, 
                                features: np.ndarray) -> Optional[float]:
        """Model ile tahmin"""
        try:
            if model_type not in self.models:
                return None
            
            model = self.models[model_type]
            scaler = self.scalers[model_type]
            feature_selector = self.feature_selectors[model_type]
            
            # Scale features
            features_scaled = scaler.transform(features)
            
            # Feature selection
            if len(self.training_data.features) > self.min_training_samples:
                features_selected = feature_selector.transform(features_scaled)
            else:
                features_selected = features_scaled
            
            # Predict
            prediction = model.predict(features_selected)[0]
            
            return max(0, prediction)  # Ensure non-negative slippage
            
        except Exception as e:
            self.logger.error(f"Model prediction hatası {model_type.value}: {e}")
            return None
    
    def _ensemble_predictions(self, predictions: Dict[str, float]) -> float:
        """Ensemble prediction"""
        if not predictions:
            return 0.0
        
        # Weighted average based on model confidence
        weights = {
            'random_forest': 0.4,
            'gradient_boosting': 0.4,
            'neural_network': 0.2
        }
        
        weighted_sum = 0
        total_weight = 0
        
        for model_name, prediction in predictions.items():
            weight = weights.get(model_name, 0.1)
            weighted_sum += prediction * weight
            total_weight += weight
        
        return weighted_sum / max(total_weight, 0.1)
    
    def _calculate_confidence(self, predictions: Dict[str, float], features: np.ndarray) -> float:
        """Confidence score hesaplama"""
        if len(predictions) < 2:
            return 0.5
        
        # Calculate prediction variance
        pred_values = list(predictions.values())
        pred_std = np.std(pred_values)
        pred_mean = np.mean(pred_values)
        
        # Confidence inversely related to variance
        relative_std = pred_std / max(pred_mean, 0.001)
        confidence = max(0.1, min(1.0, 1.0 / (1.0 + relative_std)))
        
        return confidence
    
    def _calculate_prediction_interval(self, predictions: Dict[str, float]) -> Tuple[float, float]:
        """Prediction interval hesaplama"""
        if not predictions:
            return (0.0, 0.0)
        
        pred_values = list(predictions.values())
        mean_pred = np.mean(pred_values)
        std_pred = np.std(pred_values)
        
        # 95% confidence interval
        margin = 1.96 * std_pred
        
        return (max(0, mean_pred - margin), mean_pred + margin)
    
    def _get_feature_importance(self, features: np.ndarray) -> Dict[str, float]:
        """Feature importance"""
        importance_dict = {}
        
        # Use Random Forest feature importance if available
        if MLPredictorType.RANDOM_FOREST in self.models:
            try:
                model = self.models[MLPredictorType.RANDOM_FOREST]
                if hasattr(model, 'feature_importances_'):
                    importances = model.feature_importances_
                    
                    for i, feature_name in enumerate(self.feature_columns):
                        if i < len(importances):
                            importance_dict[feature_name] = float(importances[i])
            except Exception as e:
                self.logger.warning(f"Feature importance extraction hatası: {e}")
        
        # Fallback: uniform importance
        if not importance_dict:
            uniform_importance = 1.0 / len(self.feature_columns)
            importance_dict = {name: uniform_importance for name in self.feature_columns}
        
        return importance_dict
    
    def _extract_market_conditions(self, market_data: Dict) -> Dict[str, float]:
        """Market conditions çıkar"""
        return {
            'volatility_level': market_data.get('volatility_15m', 0.02),
            'liquidity_level': market_data.get('liquidity_score', 0.5),
            'spread_level': market_data.get('spread_bps', 10),
            'volume_level': market_data.get('volume_ratio', 1.0),
            'market_stress': market_data.get('market_stress', 0.0)
        }
    
    async def _prepare_training_data(self, execution_history: List[Dict]) -> Optional[TrainingData]:
        """Training data hazırlama"""
        try:
            features_list = []
            targets_list = []
            timestamps_list = []
            symbols_list = []
            
            for execution in execution_history:
                if not execution.get('success', False):
                    continue
                
                # Extract features (would be more sophisticated in production)
                features = [
                    execution.get('volume_ratio', 0.1),
                    execution.get('volatility_1m', 0.02),
                    execution.get('volatility_5m', 0.02),
                    execution.get('volatility_15m', 0.02),
                    execution.get('volatility_1h', 0.02),
                    execution.get('spread_bps', 10),
                    execution.get('bid_ask_ratio', 1.0),
                    execution.get('order_book_imbalance', 0.0),
                    execution.get('market_depth_ratio', 1.0),
                    execution.get('price_momentum_5m', 0.0),
                    execution.get('price_momentum_15m', 0.0),
                    execution.get('volume_momentum', 0.0),
                    execution.get('liquidity_score', 0.5),
                    execution.get('time_of_day', 0.5),
                    execution.get('day_of_week', 0.5),
                    execution.get('market_regime_encoded', 0.0),
                    execution.get('venue_concentration', 0.5),
                    execution.get('previous_slippage', 0.0),
                    execution.get('market_impact_score', 0.0),
                    execution.get('volatility_regime', 0.0)
                ]
                
                target = execution.get('slippage_bps', 0.0)
                
                features_list.append(features)
                targets_list.append(target)
                timestamps_list.append(execution.get('timestamp', datetime.now()))
                symbols_list.append(execution.get('symbol', 'UNKNOWN'))
            
            if len(features_list) < 100:
                return None
            
            return TrainingData(
                features=np.array(features_list),
                target=np.array(targets_list),
                timestamps=timestamps_list,
                symbols=symbols_list,
                metadata={'source': 'execution_history', 'count': len(features_list)}
            )
            
        except Exception as e:
            self.logger.error(f"Training data preparation hatası: {e}")
            return None
    
    def _merge_training_data(self, existing: TrainingData, new: TrainingData) -> TrainingData:
        """Training data birleştir"""
        return TrainingData(
            features=np.vstack([existing.features, new.features]),
            target=np.concatenate([existing.target, new.target]),
            timestamps=existing.timestamps + new.timestamps,
            symbols=existing.symbols + new.symbols,
            metadata={
                'source': 'merged',
                'total_count': len(existing.features) + len(new.features)
            }
        )
    
    async def _train_initial_models(self):
        """Initial model eğitimi"""
        if self.training_data is None or len(self.training_data.features) < self.min_training_samples:
            return
        
        self.logger.info("Initial model training başlatılıyor...")
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            self.training_data.features,
            self.training_data.target,
            test_size=0.2,
            random_state=42
        )
        
        # Train each model
        for model_type in self.model_types:
            try:
                model = self.models[model_type]
                scaler = self.scalers[model_type]
                
                # Scale features
                X_train_scaled = scaler.fit_transform(X_train)
                X_test_scaled = scaler.transform(X_test)
                
                # Feature selection
                feature_selector = self.feature_selectors[model_type]
                if len(X_train_scaled) > self.min_training_samples:
                    X_train_selected = feature_selector.fit_transform(X_train_scaled, y_train)
                    X_test_selected = feature_selector.transform(X_test_scaled)
                else:
                    X_train_selected = X_train_scaled
                    X_test_selected = X_test_scaled
                
                # Train model
                model.fit(X_train_selected, y_train)
                
                # Evaluate
                train_score = model.score(X_train_selected, y_train)
                test_score = model.score(X_test_selected, y_test)
                
                self.model_performance[model_type.value] = {
                    'train_r2': train_score,
                    'test_r2': test_score,
                    'train_samples': len(X_train),
                    'test_samples': len(X_test)
                }
                
                self.logger.info(
                    f"Model {model_type.value} trained - Train R²: {train_score:.3f}, Test R²: {test_score:.3f}"
                )
                
            except Exception as e:
                self.logger.error(f"Model {model_type.value} training hatası: {e}")
        
        self.logger.info("Initial model training tamamlandı")
    
    async def _retrain_models(self):
        """Models yeniden eğit"""
        if self.training_data is None:
            return
        
        # Check if retraining is needed
        if self.last_model_update:
            hours_since_update = (datetime.now() - self.last_model_update).total_seconds() / 3600
            if hours_since_update < self.update_frequency_hours:
                return
        
        await self._train_initial_models()
    
    async def _load_pretrained_models(self):
        """Pre-trained models yükle"""
        try:
            for model_type in self.model_types:
                model_file = f"{self.model_path}/{model_type.value}_model.joblib"
                scaler_file = f"{self.model_path}/{model_type.value}_scaler.joblib"
                
                # Load model
                if Path(model_file).exists():
                    self.models[model_type] = joblib.load(model_file)
                
                # Load scaler
                if Path(scaler_file).exists():
                    self.scalers[model_type] = joblib.load(scaler_file)
            
            self.logger.info("Pre-trained models loaded")
            
        except Exception as e:
            self.logger.error(f"Pre-trained model loading hatası: {e}")
    
    async def _save_models(self):
        """Models kaydet"""
        try:
            for model_type in self.model_types:
                model_file = f"{self.model_path}/{model_type.value}_model.joblib"
                scaler_file = f"{self.model_path}/{model_type.value}_scaler.joblib"
                
                # Save model
                if model_type in self.models:
                    joblib.dump(self.models[model_type], model_file)
                
                # Save scaler
                if model_type in self.scalers:
                    joblib.dump(self.scalers[model_type], scaler_file)
            
            self.logger.info("Models saved")
            
        except Exception as e:
            self.logger.error(f"Model saving hatası: {e}")
    
    async def _load_training_data(self):
        """Training data yükle"""
        # This would load historical training data
        # For now, initialize empty
        self.training_data = None
        self.logger.info("Training data loaded (empty)")
    
    def _should_train_initial_models(self) -> bool:
        """Initial model training gerekli mi"""
        return (
            self.training_data is not None and 
            len(self.training_data.features) >= self.min_training_samples
        )
    
    def get_prediction_statistics(self) -> Dict:
        """Prediction istatistikleri"""
        return {
            'cached_predictions': len(self.prediction_cache),
            'models_trained': list(self.models.keys()),
            'model_performance': self.model_performance,
            'training_data_size': len(self.training_data.features) if self.training_data else 0,
            'last_update': self.last_model_update.isoformat() if self.last_model_update else None
        }
    
    async def shutdown(self):
        """Predictor'ı kapat"""
        self.logger.info("ML Slippage Predictor kapatılıyor...")
        
        # Save models if needed
        if self.model_path and self.models:
            await self._save_models()
        
        # Clear caches
        self.prediction_cache.clear()
        self.model_performance.clear()
        
        self.logger.info("ML Slippage Predictor kapatıldı")