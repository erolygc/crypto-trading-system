"""
Genetik Programlama Motoru - Primitive Set Tanımları
Bu modül finansal indikatörler, matematik operatörleri ve veri kaynaklarını tanımlar.
"""

import numpy as np
import pandas as pd
from typing import List, Callable, Union, Any
from abc import ABC, abstractmethod


class Primitive(ABC):
    """Temel primitif sınıfı"""
    def __init__(self, name: str, arity: int, description: str):
        self.name = name
        self.arity = arity
        self.description = description
    
    @abstractmethod
    def __call__(self, *args):
        pass


class Terminal(Primitive):
    """Terminal düğümler - veri kaynakları"""
    def __init__(self, name: str, description: str):
        super().__init__(name, 0, description)
    
    def __call__(self):
        return self.name
    
    def __repr__(self):
        return f"{self.name}"


class Function(Primitive):
    """Fonksiyon düğümleri - indikatörler ve operatörler"""
    def __init__(self, name: str, function: Callable, arity: int, description: str):
        super().__init__(name, arity, description)
        self.function = function
    
    def __call__(self, *args):
        return self.function(*args)
    
    def __repr__(self):
        return f"{self.name}"


class PriceData:
    """Fiyat veri terminali"""
    @staticmethod
    def open() -> float:
        return "OPEN"
    
    @staticmethod
    def high() -> float:
        return "HIGH"
    
    @staticmethod
    def low() -> float:
        return "LOW"
    
    @staticmethod
    def close() -> float:
        return "CLOSE"
    
    @staticmethod
    def volume() -> float:
        return "VOLUME"


class TechnicalIndicators:
    """Teknik indikatörler"""
    
    @staticmethod
    def sma(period: int) -> Callable[[np.ndarray], np.ndarray]:
        """Simple Moving Average"""
        def _sma(data):
            return pd.Series(data).rolling(window=period).mean().values
        return _sma
    
    @staticmethod
    def ema(period: int) -> Callable[[np.ndarray], np.ndarray]:
        """Exponential Moving Average"""
        def _ema(data):
            return pd.Series(data).ewm(span=period).mean().values
        return _ema
    
    @staticmethod
    def rsi(period: int = 14) -> Callable[[np.ndarray], np.ndarray]:
        """Relative Strength Index"""
        def _rsi(data):
            delta = pd.Series(data).diff()
            gain = delta.where(delta > 0, 0).rolling(window=period).mean()
            loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
            rs = gain / loss
            return 100 - (100 / (1 + rs))
        return _rsi
    
    @staticmethod
    def macd(fast: int = 12, slow: int = 26, signal: int = 9) -> Callable[[np.ndarray], np.ndarray]:
        """MACD Indicator"""
        def _macd(data):
            ema_fast = pd.Series(data).ewm(span=fast).mean()
            ema_slow = pd.Series(data).ewm(span=slow).mean()
            macd_line = ema_fast - ema_slow
            signal_line = macd_line.ewm(span=signal).mean()
            return (macd_line - signal_line).values
        return _macd
    
    @staticmethod
    def bollinger_bands(period: int = 20, std: float = 2.0) -> Callable[[np.ndarray], np.ndarray]:
        """Bollinger Bands"""
        def _bb(data):
            middle = pd.Series(data).rolling(window=period).mean()
            std_dev = pd.Series(data).rolling(window=period).std()
            upper = middle + (std_dev * std)
            return (data - middle) / (std_dev * std)  # Normalize deviation
        return _bb
    
    @staticmethod
    def stochastic_k(period: int = 14) -> Callable[[np.ndarray, np.ndarray, np.ndarray], np.ndarray]:
        """Stochastic %K"""
        def _stoch_k(high, low, close):
            lowest_low = pd.Series(low).rolling(window=period).min()
            highest_high = pd.Series(high).rolling(window=period).max()
            k_percent = 100 * ((pd.Series(close) - lowest_low) / (highest_high - lowest_low))
            return k_percent.values
        return _stoch_k
    
    @staticmethod
    def williams_r(period: int = 14) -> Callable[[np.ndarray, np.ndarray, np.ndarray], np.ndarray]:
        """Williams %R"""
        def _williams_r(high, low, close):
            highest_high = pd.Series(high).rolling(window=period).max()
            lowest_low = pd.Series(low).rolling(window=period).min()
            williams_r = -100 * ((highest_high - pd.Series(close)) / (highest_high - lowest_low))
            return williams_r.values
        return _williams_r
    
    # Helper functions for primitives (pickle-safe)
    @staticmethod
    def create_sma(data, period=10):
        """Create SMA indicator function"""
        return TechnicalIndicators.sma(period)(data)
    
    @staticmethod
    def create_ema(data, period=10):
        """Create EMA indicator function"""
        return TechnicalIndicators.ema(period)(data)
    
    @staticmethod
    def create_rsi(data, period=14):
        """Create RSI indicator function"""
        return TechnicalIndicators.rsi(period)(data)
    
    @staticmethod
    def create_macd(data):
        """Create MACD indicator function"""
        return TechnicalIndicators.macd()(data)
    
    @staticmethod
    def create_bollinger(data):
        """Create Bollinger Bands indicator function"""
        return TechnicalIndicators.bollinger_bands()(data)
    
    @staticmethod
    def create_stochastic_k(high, low, close, period=14):
        """Create Stochastic K indicator function"""
        return TechnicalIndicators.stochastic_k(period)(high, low, close)
    
    @staticmethod
    def create_williams_r(high, low, close, period=14):
        """Create Williams %R indicator function"""
        return TechnicalIndicators.williams_r(period)(high, low, close)


class MathOperators:
    """Matematik operatörleri"""
    
    @staticmethod
    def add(a, b) -> Union[float, np.ndarray]:
        """Toplama"""
        return a + b
    
    @staticmethod
    def sub(a, b) -> Union[float, np.ndarray]:
        """Çıkarma"""
        return a - b
    
    @staticmethod
    def mul(a, b) -> Union[float, np.ndarray]:
        """Çarpma"""
        return a * b
    
    @staticmethod
    def div(a, b) -> Union[float, np.ndarray]:
        """Bölme - sıfıra bölme koruması"""
        with np.errstate(divide='ignore', invalid='ignore'):
            result = a / b
            return np.where(b == 0, 0, result)
    
    @staticmethod
    def sqrt(x) -> Union[float, np.ndarray]:
        """Karekök"""
        return np.sqrt(np.maximum(x, 0))
    
    @staticmethod
    def abs_val(x) -> Union[float, np.ndarray]:
        """Mutlak değer"""
        return np.abs(x)
    
    @staticmethod
    def max(a, b) -> Union[float, np.ndarray]:
        """Maksimum"""
        return np.maximum(a, b)
    
    @staticmethod
    def min(a, b) -> Union[float, np.ndarray]:
        """Minimum"""
        return np.minimum(a, b)
    
    @staticmethod
    def greater(a, b) -> Union[float, np.ndarray]:
        """Büyüktür"""
        return (a > b).astype(float)
    
    @staticmethod
    def less(a, b) -> Union[float, np.ndarray]:
        """Küçüktür"""
        return (a < b).astype(float)
    
    @staticmethod
    def equal(a, b) -> Union[float, np.ndarray]:
        """Eşittir"""
        return (a == b).astype(float)
    
    @staticmethod
    def and_op(a, b) -> Union[float, np.ndarray]:
        """VE operatörü"""
        return ((a > 0) & (b > 0)).astype(float)
    
    @staticmethod
    def or_op(a, b) -> Union[float, np.ndarray]:
        """VEYA operatörü"""
        return ((a > 0) | (b > 0)).astype(float)
    
    @staticmethod
    def not_op(a) -> Union[float, np.ndarray]:
        """DEĞİL operatörü"""
        return (a <= 0).astype(float)
    
    @staticmethod
    def exp(x) -> Union[float, np.ndarray]:
        """Üssel fonksiyon"""
        return np.exp(x)
    
    @staticmethod
    def log(x) -> Union[float, np.ndarray]:
        """Logaritma"""
        return np.log(np.maximum(x, 1e-8))
    
    @staticmethod
    def sin(x) -> Union[float, np.ndarray]:
        """Sinüs"""
        return np.sin(x)
    
    @staticmethod
    def cos(x) -> Union[float, np.ndarray]:
        """Kosinüs"""
        return np.cos(x)


class PrimitiveSet:
    """Primitif seti yönetimi"""
    
    def __init__(self):
        self.terminals = {}
        self.functions = {}
        self._initialize_primitives()
    
    def _initialize_primitives(self):
        """Primitifleri başlat"""
        # Terminals (veri kaynakları)
        self.add_terminal("OPEN", "Açılış fiyatı")
        self.add_terminal("HIGH", "En yüksek fiyat")
        self.add_terminal("LOW", "En düşük fiyat")
        self.add_terminal("CLOSE", "Kapanış fiyatı")
        self.add_terminal("VOLUME", "İşlem hacmi")
        self.add_terminal("TIMESTAMP", "Zaman damgası")
        
        # Price-based indicators
        self.add_function("SMA", TechnicalIndicators.create_sma, 2)  # (data, period)
        self.add_function("EMA", TechnicalIndicators.create_ema, 2)  # (data, period)
        self.add_function("RSI", TechnicalIndicators.create_rsi, 2)  # (data, period)
        self.add_function("MACD", TechnicalIndicators.create_macd, 1)  # (data)
        self.add_function("BB", TechnicalIndicators.create_bollinger, 1)  # (data)
        self.add_function("STOCH_K", TechnicalIndicators.create_stochastic_k, 4)  # (high, low, close, period)
        self.add_function("WILLIAMS_R", TechnicalIndicators.create_williams_r, 4)  # (high, low, close, period)
        
        # Math operators
        self.add_function("ADD", MathOperators.add, 2)
        self.add_function("SUB", MathOperators.sub, 2)
        self.add_function("MUL", MathOperators.mul, 2)
        self.add_function("DIV", MathOperators.div, 2)
        self.add_function("SQRT", MathOperators.sqrt, 1)
        self.add_function("ABS", MathOperators.abs_val, 1)
        self.add_function("MAX", MathOperators.max, 2)
        self.add_function("MIN", MathOperators.min, 2)
        self.add_function("GT", MathOperators.greater, 2)
        self.add_function("LT", MathOperators.less, 2)
        self.add_function("EQ", MathOperators.equal, 2)
        self.add_function("AND", MathOperators.and_op, 2)
        self.add_function("OR", MathOperators.or_op, 2)
        self.add_function("NOT", MathOperators.not_op, 1)
        self.add_function("EXP", MathOperators.exp, 1)
        self.add_function("LOG", MathOperators.log, 1)
        self.add_function("SIN", MathOperators.sin, 1)
        self.add_function("COS", MathOperators.cos, 1)
    
    def add_terminal(self, name: str, description: str):
        """Terminal ekle"""
        self.terminals[name] = Terminal(name, description)
    
    def add_function(self, name: str, function: Callable, arity: int):
        """Fonksiyon ekle"""
        self.functions[name] = Function(name, function, arity, "")
    
    def get_all_primitives(self) -> dict:
        """Tüm primitifleri getir"""
        return {**self.terminals, **self.functions}
    
    def get_functions(self) -> dict:
        """Sadece fonksiyonları getir"""
        return self.functions
    
    def get_terminals(self) -> dict:
        """Sadece terminalleri getir"""
        return self.terminals


class PrimitiveRegistry:
    """Primitif kayıt ve yönetim sistemi"""
    
    def __init__(self):
        self.primitive_sets = {}
        self.active_set = "default"
    
    def register_primitive_set(self, name: str, primitive_set: PrimitiveSet):
        """Primitif seti kaydet"""
        self.primitive_sets[name] = primitive_set
    
    def set_active_set(self, name: str):
        """Aktif primitif setini değiştir"""
        if name in self.primitive_sets:
            self.active_set = name
        else:
            raise ValueError(f"Primitive set '{name}' bulunamadı")
    
    def get_active_set(self) -> PrimitiveSet:
        """Aktif primitif setini getir"""
        return self.primitive_sets[self.active_set]
    
    def get_primitive(self, name: str) -> Primitive:
        """Belirli bir primitif getir"""
        active_set = self.get_active_set()
        primitives = active_set.get_all_primitives()
        if name in primitives:
            return primitives[name]
        raise ValueError(f"Primitif '{name}' bulunamadı")


# Global primitif kayıt sistemi
primitive_registry = PrimitiveRegistry()

# Varsayılan primitif seti
default_primitive_set = PrimitiveSet()
primitive_registry.register_primitive_set("default", default_primitive_set)
primitive_registry.set_active_set("default")