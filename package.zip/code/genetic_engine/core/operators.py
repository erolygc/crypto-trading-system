"""
Genetik Programlama Motoru - Genetik Operatörler
Bu modül crossover, mutation ve selection operatörlerini içerir.
"""

import random
import copy
import numpy as np
from typing import List, Tuple, Any, Callable, Optional, Dict
from abc import ABC, abstractmethod
from deap import algorithms, base, creator, tools
from deap.gp import cxOnePoint, mutUniform

# Simplified imports for better compatibility
try:
    from deap.gp import expr
except ImportError:
    expr = None

# Placeholder classes for Primitive/Terminal
class Primitive:
    def __init__(self, name, arity, description):
        self.name = name
        self.arity = arity
        self.description = description

class Terminal:
    def __init__(self, name, description):
        self.name = name
        self.description = description
        self.arity = 0
import operator


class GeneticOperator(ABC):
    """Genetik operatör base sınıfı"""
    
    @abstractmethod
    def __call__(self, individual1, individual2=None, *args):
        pass


class TreeNode:
    """Ağaç düğümü sınıfı"""
    
    def __init__(self, value: Any, children: List['TreeNode'] = None, parent: Optional['TreeNode'] = None):
        self.value = value
        self.children = children or []
        self.parent = parent
    
    def copy(self) -> 'TreeNode':
        """Derin kopya oluştur"""
        if self.children:
            children_copy = [child.copy() for child in self.children]
            for child in children_copy:
                child.parent = None  # Reset parent
            return TreeNode(copy.deepcopy(self.value), children_copy)
        return TreeNode(copy.deepcopy(self.value))
    
    def to_list(self) -> List:
        """Ağacı liste formatına çevir (prefix notation)"""
        if not self.children:
            return [self.value]
        result = [self.value]
        for child in self.children:
            result.extend(child.to_list())
        return result
    
    @classmethod
    def from_list(cls, data: List) -> 'TreeNode':
        """Liste formatından ağaç oluştur"""
        def build_tree(data_list):
            if not data_list:
                return None
            
            value = data_list[0]
            if hasattr(value, 'arity'):
                # Function node
                children_count = value.arity
                children = []
                remaining_data = data_list[1:]
                
                for _ in range(children_count):
                    child_data_len = len(remaining_data)
                    child_node, remaining_data = build_tree_with_length(remaining_data, None)
                    if child_node:
                        children.append(child_node)
                
                return cls(value, children)
            else:
                # Terminal node
                return cls(value)
        
        def build_tree_with_length(data_list, max_length):
            if not data_list:
                return None, []
            
            value = data_list[0]
            if hasattr(value, 'arity') and max_length is None:
                # Function node
                children_count = value.arity
                children = []
                remaining_data = data_list[1:]
                
                # Build each child
                for i in range(children_count):
                    child, remaining_data = build_tree_with_length(remaining_data, None)
                    if child:
                        children.append(child)
                
                node = cls(value, children)
                total_size = 1
                for child in children:
                    total_size += get_tree_size(child)
                
                return node, data_list[total_size:]
            else:
                # Terminal node
                return cls(value), data_list[1:] if max_length is None else data_list[1:]
        
        def get_tree_size(node):
            if not node.children:
                return 1
            return 1 + sum(get_tree_size(child) for child in node.children)
        
        return build_tree(data)


class AdvancedCrossover(GeneticOperator):
    """Gelişmiş çaprazlama operatörü"""
    
    def __init__(self, toolbox: base.Toolbox, max_depth: int = 10):
        self.toolbox = toolbox
        self.max_depth = max_depth
    
    def __call__(self, individual1, individual2):
        """Çaprazlama işlemi"""
        if len(individual1) < 2 or len(individual2) < 2:
            return individual1, individual2
        
        # Random crossover point seç
        point1 = random.randint(1, len(individual1) - 1)
        point2 = random.randint(1, len(individual2) - 1)
        
        # Ağaç formatına çevir
        tree1 = TreeNode.from_list(individual1)
        tree2 = TreeNode.from_list(individual2)
        
        # Çaprazlama noktalarını bul
        node1 = self._get_node_at_position(tree1, point1)
        node2 = self._get_node_at_position(tree2, point2)
        
        if node1 and node2:
            # Subtree swap
            parent1 = node1.parent
            parent2 = node2.parent
            
            if parent1:
                idx1 = parent1.children.index(node1)
                old_child1 = parent1.children[idx1]
                parent1.children[idx1] = node2.copy()
                node2.parent = parent1
            
            if parent2:
                idx2 = parent2.children.index(node2)
                old_child2 = parent2.children[idx1]
                parent2.children[idx2] = node1.copy()
                node1.parent = parent2
        
        # Yeni bireyleri oluştur
        new_individual1 = TreeNode.to_list(tree1) if tree1 else individual1
        new_individual2 = TreeNode.to_list(tree2) if tree2 else individual2
        
        # Depth kontrolü
        if self._check_depth_constraint(new_individual1) and self._check_depth_constraint(new_individual2):
            return new_individual1, new_individual2
        
        return individual1, individual2
    
    def _get_node_at_position(self, tree: TreeNode, position: int) -> Optional[TreeNode]:
        """Belirtilen pozisyondaki düğümü getir"""
        current_pos = 0
        
        def traverse(node: TreeNode) -> Optional[TreeNode]:
            nonlocal current_pos
            if current_pos == position:
                return node
            
            current_pos += 1
            for child in node.children:
                result = traverse(child)
                if result:
                    return result
            
            return None
        
        return traverse(tree)
    
    def _check_depth_constraint(self, individual) -> bool:
        """Derinlik kısıtlamasını kontrol et"""
        try:
            tree = TreeNode.from_list(individual)
            depth = self._calculate_depth(tree)
            return depth <= self.max_depth
        except:
            return False
    
    def _calculate_depth(self, node: TreeNode) -> int:
        """Ağaç derinliğini hesapla"""
        if not node.children:
            return 1
        return 1 + max(self._calculate_depth(child) for child in node.children)


class UniformCrossover(GeneticOperator):
    """Uniform çaprazlama operatörü"""
    
    def __init__(self, probability: float = 0.5):
        self.probability = probability
    
    def __call__(self, individual1, individual2):
        """Uniform crossover"""
        if len(individual1) != len(individual2):
            min_len = min(len(individual1), len(individual2))
            individual1 = individual1[:min_len]
            individual2 = individual2[:min_len]
        
        # Her pozisyon için crossover kararı
        for i in range(len(individual1)):
            if random.random() < self.probability:
                individual1[i], individual2[i] = individual2[i], individual1[i]
        
        return individual1, individual2


class AdvancedMutation(GeneticOperator):
    """Gelişmiş mutasyon operatörü"""
    
    def __init__(self, toolbox: base.Toolbox, max_depth: int = 10):
        self.toolbox = toolbox
        self.max_depth = max_depth
        self.mutation_types = [
            self._point_mutation,
            self._subtree_mutation,
            self._hoist_mutation,
            self._shrink_mutation
        ]
    
    def __call__(self, individual):
        """Mutasyon işlemi"""
        if len(individual) < 2:
            return individual
        
        # Rastgele mutasyon tipi seç
        mutation_func = random.choice(self.mutation_types)
        
        try:
            mutated = mutation_func(individual)
            return mutated if mutated else individual
        except:
            return individual
    
    def _point_mutation(self, individual):
        """Nokta mutasyonu"""
        if not individual:
            return individual
        
        # Rastgele pozisyon seç
        pos = random.randint(0, len(individual) - 1)
        old_value = individual[pos]
        
        # Yeni değer üret
        if hasattr(old_value, 'arity'):
            # Function node - yeni function seç
            functions = self.toolbox.symbols['function']
            new_value = random.choice(functions)
        else:
            # Terminal - yeni terminal seç
            terminals = self.toolbox.symbols['terminal']
            new_value = random.choice(terminals)
        
        # Yeni birey oluştur
        new_individual = individual.copy()
        new_individual[pos] = new_value
        
        return new_individual
    
    def _subtree_mutation(self, individual):
        """Alt ağaç mutasyonu"""
        if len(individual) < 2:
            return individual
        
        tree = TreeNode.from_list(individual)
        if not tree:
            return individual
        
        # Rastgele node seç
        position = random.randint(0, len(individual) - 1)
        node = self._get_node_at_position(tree, position)
        
        if node:
            # Yeni subtree oluştur
            primitive_set = self.toolbox.primitives
            new_subtree = self.toolbox.genFull(primitive_set, min_=1, max_=3)
            
            if node.parent:
                idx = node.parent.children.index(node)
                node.parent.children[idx] = TreeNode.from_list(new_subtree)
            else:
                tree = TreeNode.from_list(new_subtree)
        
        return TreeNode.to_list(tree) if tree else individual
    
    def _hoist_mutation(self, individual):
        """Hoist mutasyonu - subtree'yi küçült"""
        if len(individual) < 3:
            return individual
        
        tree = TreeNode.from_list(individual)
        if not tree or not tree.children:
            return individual
        
        # Rastgele alt node seç
        position = random.randint(1, len(individual) - 1)
        node = self._get_node_at_position(tree, position)
        
        if node and node.children:
            # Alt node'un bir child'ını parent'a taşı
            parent = node.parent
            child = random.choice(node.children)
            
            if parent:
                idx = parent.children.index(node)
                parent.children[idx] = child.copy()
                child.parent = parent
        
        return TreeNode.to_list(tree) if tree else individual
    
    def _shrink_mutation(self, individual):
        """Shrink mutasyonu - ağacı küçült"""
        tree = TreeNode.from_list(individual)
        if not tree or not tree.children:
            return individual
        
        # Rastgele function node seç
        position = random.randint(0, len(individual) - 1)
        node = self._get_node_at_position(tree, position)
        
        if node and node.children:
            # Function node'u terminal ile değiştir
            terminals = self.toolbox.symbols.get('terminal', [])
            if terminals:
                node.value = random.choice(terminals)
                node.children = []
        
        return TreeNode.to_list(tree) if tree else individual
    
    def _get_node_at_position(self, tree: TreeNode, position: int) -> Optional[TreeNode]:
        """Belirtilen pozisyondaki düğümü getir (uniform crossover'daki ile aynı)"""
        current_pos = 0
        
        def traverse(node: TreeNode) -> Optional[TreeNode]:
            nonlocal current_pos
            if current_pos == position:
                return node
            
            current_pos += 1
            for child in node.children:
                result = traverse(child)
                if result:
                    return result
            
            return None
        
        return traverse(tree)


class AdaptiveMutation(GeneticOperator):
    """Adaptif mutasyon operatörü"""
    
    def __init__(self, toolbox: base.Toolbox, adaptation_rate: float = 0.1):
        self.toolbox = toolbox
        self.adaptation_rate = adaptation_rate
        self.mutation_rate = 0.1
        self.generation = 0
    
    def __call__(self, individual, fitness_history: List[float] = None):
        """Adaptif mutasyon"""
        # Fitness trendine göre mutasyon oranını ayarla
        if fitness_history and len(fitness_history) > 10:
            recent_avg = np.mean(fitness_history[-10:])
            overall_avg = np.mean(fitness_history)
            
            if recent_avg < overall_avg * 0.9:  # Performans düşüyor
                self.mutation_rate = min(0.3, self.mutation_rate * (1 + self.adaptation_rate))
            elif recent_avg > overall_avg * 1.1:  # Performans artıyor
                self.mutation_rate = max(0.01, self.mutation_rate * (1 - self.adaptation_rate))
        
        self.generation += 1
        
        # Probabilistic mutation
        if random.random() < self.mutation_rate:
            mutation_op = AdvancedMutation(self.toolbox)
            return mutation_op(individual)
        
        return individual


class TournamentSelection:
    """Turnuva seçimi"""
    
    def __init__(self, tournament_size: int = 3):
        self.tournament_size = tournament_size
    
    def select(self, population: List, fitnesses: List[float], count: int) -> List:
        """Seçim işlemi"""
        selected = []
        
        for _ in range(count):
            # Turnuva oluştur
            tournament_indices = random.sample(range(len(population)), 
                                             min(self.tournament_size, len(population)))
            tournament_fitnesses = [fitnesses[i] for i in tournament_indices]
            
            # En iyiyi seç
            winner_index = tournament_indices[tournament_fitnesses.index(max(tournament_fitnesses))]
            selected.append(population[winner_index])
        
        return selected


class RankSelection:
    """Rank tabanlı seçim"""
    
    def __init__(self):
        pass
    
    def select(self, population: List, fitnesses: List[float], count: int) -> List:
        """Rank tabanlı seçim"""
        # Fitness değerlerine göre sırala
        sorted_indices = np.argsort(fitnesses)
        ranks = np.arange(1, len(fitnesses) + 1)
        
        # Rank-based probabilities
        selection_probs = 2 * (len(fitnesses) + 1 - ranks) / (len(fitnesses) * (len(fitnesses) + 1))
        selection_probs /= selection_probs.sum()
        
        # Selection
        selected_indices = np.random.choice(len(population), size=count, p=selection_probs, replace=True)
        
        return [population[i] for i in selected_indices]


class RouletteWheelSelection:
    """Rulet çarkı seçimi"""
    
    def __init__(self):
        pass
    
    def select(self, population: List, fitnesses: List[float], count: int) -> List:
        """Rulet çarkı seçimi"""
        # Negative fitness değerlerini pozitif yap
        min_fitness = min(fitnesses)
        if min_fitness < 0:
            fitnesses = [f - min_fitness for f in fitnesses]
        
        # Toplam fitness
        total_fitness = sum(fitnesses)
        
        if total_fitness == 0:
            # Tüm bireyler eşit fitness'a sahip
            selected_indices = np.random.choice(len(population), size=count, replace=True)
        else:
            # Probabilities
            selection_probs = [f / total_fitness for f in fitnesses]
            selected_indices = np.random.choice(len(population), size=count, p=selection_probs, replace=True)
        
        return [population[i] for i in selected_indices]


class DiversityPreservation:
    """Çeşitlilik koruma mekanizması"""
    
    def __init__(self, diversity_threshold: float = 0.1):
        self.diversity_threshold = diversity_threshold
    
    def calculate_diversity(self, population: List) -> float:
        """Popülasyon çeşitliliğini hesapla"""
        if len(population) < 2:
            return 0.0
        
        # Basit çeşitlilik metriği - bireyler arası farklılık
        total_distance = 0.0
        count = 0
        
        for i in range(len(population)):
            for j in range(i + 1, len(population)):
                distance = self._calculate_tree_distance(population[i], population[j])
                total_distance += distance
                count += 1
        
        return total_distance / count if count > 0 else 0.0
    
    def _calculate_tree_distance(self, tree1, tree2) -> float:
        """İki ağaç arasındaki mesafe"""
        # Basit edit distance yaklaşımı
        if len(tree1) != len(tree2):
            return abs(len(tree1) - len(tree2))
        
        # Pozisyon bazlı farklılık
        differences = sum(1 for i in range(len(tree1)) if tree1[i] != tree2[i])
        return differences / len(tree1)
    
    def promote_diversity(self, population: List, fitnesses: List[float]) -> List:
        """Çeşitliliği artır"""
        diversity = self.calculate_diversity(population)
        
        if diversity < self.diversity_threshold:
            # Rastgele bireyleri yenile
            num_to_replace = int(len(population) * 0.2)  # %20'sini yenile
            indices_to_replace = random.sample(range(len(population)), num_to_replace)
            
            for idx in indices_to_replace:
                # Rastgele yeni birey üret (simplified)
                population[idx] = [random.choice(['ADD', 'SUB', 'MUL', 'CLOSE', 'VOLUME']) 
                                 for _ in range(random.randint(3, 10))]
        
        return population


class GeneticOperatorsManager:
    """Genetik operatör yöneticisi"""
    
    def __init__(self, toolbox: base.Toolbox, config: Dict[str, Any]):
        self.toolbox = toolbox
        self.config = config
        
        # Crossover operators
        self.crossover_ops = {
            'advanced': AdvancedCrossover(toolbox, config.get('max_depth', 10)),
            'uniform': UniformCrossover(config.get('crossover_prob', 0.5))
        }
        
        # Mutation operators
        self.mutation_ops = {
            'advanced': AdvancedMutation(toolbox, config.get('max_depth', 10)),
            'adaptive': AdaptiveMutation(toolbox, config.get('adaptation_rate', 0.1))
        }
        
        # Selection operators
        self.selection_ops = {
            'tournament': TournamentSelection(config.get('tournament_size', 3)),
            'rank': RankSelection(),
            'roulette': RouletteWheelSelection()
        }
        
        self.diversity_preservation = DiversityPreservation(
            config.get('diversity_threshold', 0.1)
        )
    
    def crossover(self, individual1, individual2, method: str = 'advanced') -> Tuple:
        """Çaprazlama işlemi"""
        if method in self.crossover_ops:
            return self.crossover_ops[method](individual1, individual2)
        else:
            # Default DEAP crossover
            return cxOnePoint(individual1, individual2)
    
    def mutate(self, individual, method: str = 'adaptive', fitness_history: List[float] = None) -> Tuple:
        """Mutasyon işlemi"""
        if method in self.mutation_ops:
            if method == 'adaptive':
                return self.mutation_ops[method](individual, fitness_history),
            else:
                return self.mutation_ops[method](individual),
        else:
            # Default DEAP mutation
            return mutUniform(individual, self.toolbox.expr_mut)
    
    def select(self, population: List, fitnesses: List[float], count: int, method: str = 'tournament') -> List:
        """Seçim işlemi"""
        if method in self.selection_ops:
            return self.selection_ops[method].select(population, fitnesses, count)
        else:
            # Default tournament selection
            return tools.selTournament(population, count, self.config.get('tournament_size', 3))
    
    def preserve_diversity(self, population: List, fitnesses: List[float]) -> List:
        """Çeşitlilik koruma"""
        return self.diversity_preservation.promote_diversity(population, fitnesses)


def create_toolbox(primitive_set) -> base.Toolbox:
    """DEAP toolbox oluştur"""
    toolbox = base.Toolbox()
    
    # Primitive set symbols
    functions = list(primitive_set.get_functions().values())
    terminals = list(primitive_set.get_terminals().values())
    
    toolbox.symbols = {'function': functions, 'terminal': terminals}
    toolbox.primitives = primitive_set
    
    # Expression generation (fallback for compatibility)
    if expr is not None:
        toolbox.register("expr", expr.genHalfAndHalf, pset=primitive_set, min_=1, max_=3)
        toolbox.register("expr_mut", expr.genUniform, pset=primitive_set, min_=0, max_=2)
    else:
        # Simple fallback expression generation
        def simple_gen(pset, min_, max_):
            import random
            functions = list(pset.get_functions().values())
            terminals = list(pset.get_terminals().values())
            
            if random.random() < 0.5 or min_ == 0:
                return [random.choice(terminals)]
            else:
                func = random.choice(functions)
                args = []
                for _ in range(func.arity):
                    args.extend(simple_gen(pset, 0, max_ - 1))
                return [func] + args
        
        toolbox.register("expr", simple_gen, primitive_set, 1, 3)
        toolbox.register("expr_mut", simple_gen, primitive_set, 0, 2)
    
    # Individual creation
    toolbox.register("individual", tools.initIterate, list, toolbox.expr)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)
    
    return toolbox


# Operator configurations
DEFAULT_OPERATOR_CONFIG = {
    'crossover_prob': 0.8,
    'mutation_prob': 0.1,
    'max_depth': 10,
    'tournament_size': 3,
    'diversity_threshold': 0.1,
    'adaptation_rate': 0.1
}