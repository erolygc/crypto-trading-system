"""
Genetik Programlama Motoru - Ana Engine
Bu modül popülasyon yönetimi, GPU entegrasyonu ve real-time deployment'ı içerir.
"""

import numpy as np
import pandas as pd
import pickle
import json
import time
import threading
from typing import List, Dict, Any, Optional, Tuple, Callable
from dataclasses import dataclass, asdict
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from multiprocessing import Pool, cpu_count
import warnings
import logging

# GPU support
try:
    import cupy as cp
    import cupyx.scipy.sparse as sp
    GPU_AVAILABLE = True
except ImportError:
    cp = None
    sp = None
    GPU_AVAILABLE = False

# DEAP
from deap import base, creator, tools, algorithms
import random

from .primitives import PrimitiveSet, primitive_registry
from .fitness import AdvancedFitnessCalculator, create_fitness_calculator
from .operators import GeneticOperatorsManager, create_toolbox


@dataclass
class EvolutionConfig:
    """Evrim konfigürasyonu"""
    population_size: int = 10000
    generations: int = 1000
    crossover_prob: float = 0.8
    mutation_prob: float = 0.1
    elitism_rate: float = 0.1
    max_depth: int = 10
    tournament_size: int = 3
    fitness_config: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.fitness_config is None:
            self.fitness_config = {
                'use_profit': True,
                'use_sharpe': True,
                'use_sortino': True,
                'use_drawdown': True,
                'use_win_rate': False,
                'use_profit_factor': True,
                'use_calmar': True,
                'risk_free_rate': 0.02
            }


@dataclass
class EvolutionStats:
    """Evrim istatistikleri"""
    generation: int
    best_fitness: float
    avg_fitness: float
    worst_fitness: float
    best_individual: Any
    diversity: float
    elapsed_time: float
    fitness_history: List[float] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class StrategyResult:
    """Strateji sonucu"""
    strategy_id: str
    individual: Any
    fitness: float
    metrics: Dict[str, float]
    creation_time: float
    performance_score: float
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'strategy_id': self.strategy_id,
            'fitness': self.fitness,
            'metrics': self.metrics,
            'creation_time': self.creation_time,
            'performance_score': self.performance_score
        }


class GPUManager:
    """GPU yönetim sınıfı"""
    
    def __init__(self):
        self.gpu_available = GPU_AVAILABLE
        self.gpu_memory_pool = {}
        self.current_device = 0
        
        if self.gpu_available:
            self._initialize_gpu()
    
    def _initialize_gpu(self):
        """GPU'yu başlat"""
        try:
            cp.cuda.Device(self.current_device).use()
            logging.info(f"GPU başlatıldı: {cp.cuda.get_device_name()}")
        except Exception as e:
            logging.warning(f"GPU başlatma hatası: {e}")
            self.gpu_available = False
    
    def allocate_memory(self, size_bytes: int, name: str) -> Any:
        """GPU bellek tahsisi"""
        if not self.gpu_available:
            return None
        
        try:
            device_array = cp.zeros(size_bytes // 8, dtype=cp.float64)
            self.gpu_memory_pool[name] = device_array
            return device_array
        except Exception as e:
            logging.warning(f"GPU bellek tahsisi hatası: {e}")
            return None
    
    def free_memory(self, name: str):
        """GPU bellek boşalt"""
        if name in self.gpu_memory_pool:
            del self.gpu_memory_pool[name]
    
    def array_to_gpu(self, data: np.ndarray) -> Any:
        """NumPy array'ini GPU'ya taşı"""
        if not self.gpu_available:
            return data
        
        try:
            return cp.asarray(data)
        except Exception as e:
            logging.warning(f"GPU taşıma hatası: {e}")
            return data
    
    def gpu_to_cpu(self, gpu_array: Any) -> np.ndarray:
        """GPU array'ini CPU'ya taşı"""
        if not self.gpu_available or not hasattr(gpu_array, 'get'):
            return gpu_array
        
        try:
            return gpu_array.get()
        except Exception as e:
            logging.warning(f"CPU taşıma hatası: {e}")
            return gpu_array


class DataProcessor:
    """Veri işleme sınıfı"""
    
    def __init__(self, gpu_manager: GPUManager):
        self.gpu_manager = gpu_manager
        self.data_cache = {}
    
    def prepare_data(self, data: Dict[str, np.ndarray], use_gpu: bool = True) -> Dict[str, Any]:
        """Veriyi işlemeye hazırla"""
        processed_data = {}
        
        for key, value in data.items():
            if use_gpu and self.gpu_manager.gpu_available:
                processed_data[key] = self.gpu_manager.array_to_gpu(value)
            else:
                processed_data[key] = value
        
        return processed_data
    
    def batch_process(self, data: Dict[str, np.ndarray], batch_size: int = 1000) -> List[Dict[str, Any]]:
        """Veriyi batch'lere böl"""
        batches = []
        total_length = len(list(data.values())[0])
        
        for i in range(0, total_length, batch_size):
            batch = {}
            for key, values in data.items():
                batch[key] = values[i:i+batch_size]
            batches.append(batch)
        
        return batches


class ParallelEvaluator:
    """Paralel fitness değerlendirme"""
    
    def __init__(self, fitness_calculator: AdvancedFitnessCalculator, 
                 n_jobs: int = -1, use_gpu: bool = True):
        self.fitness_calculator = fitness_calculator
        self.n_jobs = n_jobs if n_jobs > 0 else cpu_count()
        self.use_gpu = use_gpu
        self.gpu_manager = GPUManager()
    
    def evaluate_population(self, population: List[Any], 
                          data: Dict[str, np.ndarray]) -> List[float]:
        """Popülasyonu paralel değerlendir"""
        if self.n_jobs == 1:
            # Sequential evaluation
            fitnesses = []
            for individual in population:
                try:
                    signals = self._evaluate_individual(individual, data)
                    fitness = self.fitness_calculator.evaluate(signals, data['close'])
                    fitnesses.append(fitness)
                except Exception as e:
                    logging.warning(f"Fitness evaluation hatası: {e}")
                    fitnesses.append(0.0)
        else:
            # Parallel evaluation
            with ProcessPoolExecutor(max_workers=self.n_jobs) as executor:
                futures = []
                for individual in population:
                    future = executor.submit(self._evaluate_individual_safe, 
                                           individual, data)
                    futures.append(future)
                
                fitnesses = []
                for future in futures:
                    try:
                        fitness = future.result(timeout=30)  # 30 second timeout
                        fitnesses.append(fitness)
                    except Exception as e:
                        logging.warning(f"Paralel fitness evaluation hatası: {e}")
                        fitnesses.append(0.0)
        
        return fitnesses
    
    def _evaluate_individual(self, individual: Any, data: Dict[str, np.ndarray]) -> np.ndarray:
        """Genetic program tree'sini evaluate et ve trading signals üret"""
        n_periods = len(data['close'])
        
        try:
            # Genetic program tree'sini recursive olarak evaluate et
            signals = self._evaluate_genetic_program(individual, data)
            
            # Ensure signals array matches price data length
            if len(signals) != n_periods:
                if len(signals) > n_periods:
                    signals = signals[:n_periods]
                else:
                    # Pad with zeros if needed
                    padding = np.zeros(n_periods - len(signals))
                    signals = np.concatenate([signals, padding])
            
            # Ensure signals are within valid range
            signals = np.clip(signals, -1.0, 1.0)
            
            return signals
            
        except Exception as e:
            logging.warning(f"Genetic program evaluation error: {e}")
            # Fallback: simple trend-based signals
            return self._fallback_signal_generation(data)
    
    def _evaluate_genetic_program(self, individual: Any, data: Dict[str, np.ndarray]) -> np.ndarray:
        """Genetic program tree'sini recursive evaluate et"""
        # Individual'ın tipini kontrol et
        if hasattr(individual, '__iter__') and not isinstance(individual, (str, np.ndarray)):
            # Tree node - recursive evaluation
            if len(individual) == 0:
                return np.zeros(len(data['close']))
            
            # First element is the operator/function
            operator = individual[0]
            
            # Get remaining elements as arguments
            args = individual[1:] if len(individual) > 1 else []
            
            return self._evaluate_node(operator, args, data)
        else:
            # Terminal node - return corresponding data
            return self._evaluate_terminal(individual, data)
    
    def _evaluate_node(self, operator: Any, args: List[Any], data: Dict[str, np.ndarray]) -> np.ndarray:
        """Tree node'sini evaluate et"""
        try:
            # String operator kontrolü
            if isinstance(operator, str):
                return self._evaluate_string_operator(operator, args, data)
            
            # Callable operator kontrolü  
            elif callable(operator):
                arg_values = [self._evaluate_node(arg, [], data) if hasattr(arg, '__iter__') and not isinstance(arg, str) 
                             else self._evaluate_terminal(arg, data) for arg in args]
                return operator(*arg_values)
            
            # Number constant
            elif isinstance(operator, (int, float)):
                return np.full(len(data['close']), operator)
            
            else:
                # Unknown operator type
                return np.zeros(len(data['close']))
                
        except Exception as e:
            logging.warning(f"Node evaluation error: {e}")
            return np.zeros(len(data['close']))
    
    def _evaluate_string_operator(self, operator: str, args: List[Any], data: Dict[str, np.ndarray]) -> np.ndarray:
        """String operatörü evaluate et"""
        from .primitives import primitive_registry
        
        try:
            active_primitive_set = primitive_registry.get_active_set()
            primitives = active_primitive_set.get_all_primitives()
            
            if operator in primitives:
                primitive = primitives[operator]
                
                if hasattr(primitive, 'arity') and primitive.arity > 0:
                    # Function node
                    arg_values = []
                    for arg in args:
                        if hasattr(arg, '__iter__') and not isinstance(arg, str):
                            # Recursive evaluation for sub-tree
                            arg_values.append(self._evaluate_node(arg, [], data))
                        else:
                            # Terminal evaluation
                            arg_values.append(self._evaluate_terminal(arg, data))
                    
                    # Execute primitive function
                    result = primitive(*arg_values)
                    return result
                else:
                    # Terminal node
                    return self._evaluate_terminal(operator, data)
            
            else:
                # Unknown operator
                logging.warning(f"Unknown operator: {operator}")
                return np.zeros(len(data['close']))
                
        except Exception as e:
            logging.warning(f"String operator evaluation error for {operator}: {e}")
            return np.zeros(len(data['close']))
    
    def _evaluate_terminal(self, terminal: Any, data: Dict[str, np.ndarray]) -> np.ndarray:
        """Terminal node'u evaluate et"""
        try:
            if isinstance(terminal, str):
                # Terminal is a data field name
                if terminal in data:
                    return np.array(data[terminal])
                else:
                    # Return zeros if data field not found
                    return np.zeros(len(data.get('close', [0])))
            
            elif isinstance(terminal, (int, float)):
                # Constant value
                n_periods = len(data.get('close', [0]))
                return np.full(n_periods, float(terminal))
            
            else:
                # Unknown terminal type
                n_periods = len(data.get('close', [0]))
                return np.zeros(n_periods)
                
        except Exception as e:
            logging.warning(f"Terminal evaluation error: {e}")
            n_periods = len(data.get('close', [0]))
            return np.zeros(n_periods)
    
    def _fallback_signal_generation(self, data: Dict[str, np.ndarray]) -> np.ndarray:
        """Fallback signal generation - basit trend analizi"""
        try:
            close_prices = data['close']
            n_periods = len(close_prices)
            signals = np.zeros(n_periods)
            
            if n_periods < 2:
                return signals
            
            # Simple moving average crossover
            if n_periods >= 20:
                short_ma = pd.Series(close_prices).rolling(5).mean().values
                long_ma = pd.Series(close_prices).rolling(20).mean().values
                
                # Buy signal: short MA > long MA
                # Sell signal: short MA < long MA
                signals = np.where(short_ma > long_ma, 1.0, -1.0)
                
                # Handle NaN values
                signals = np.nan_to_num(signals, nan=0.0)
            else:
                # Simple price change based signals
                price_changes = np.diff(close_prices) / close_prices[:-1]
                signals[1:] = np.where(price_changes > 0, 1.0, -1.0)
                signals[0] = 0.0
            
            return np.clip(signals, -1.0, 1.0)
            
        except Exception as e:
            logging.warning(f"Fallback signal generation error: {e}")
            n_periods = len(data.get('close', [0]))
            return np.random.uniform(-0.5, 0.5, n_periods)
    
    def _evaluate_individual_safe(self, individual: Any, data: Dict[str, np.ndarray]) -> float:
        """Güvenli fitness değerlendirme"""
        try:
            signals = self._evaluate_individual(individual, data)
            fitness = self.fitness_calculator.evaluate(signals, data['close'])
            return fitness if not np.isnan(fitness) and not np.isinf(fitness) else 0.0
        except Exception as e:
            logging.warning(f"Individual evaluation hatası: {e}")
            return 0.0


class EvolutionEngine:
    """Ana evrim motoru"""
    
    def __init__(self, config: EvolutionConfig):
        self.config = config
        self.gpu_manager = GPUManager()
        self.data_processor = DataProcessor(self.gpu_manager)
        
        # Initialize components
        primitive_set = primitive_registry.get_active_set()
        self.toolbox = create_toolbox(primitive_set)
        
        self.fitness_calculator = create_fitness_calculator(config.fitness_config)
        self.parallel_evaluator = ParallelEvaluator(
            self.fitness_calculator, 
            n_jobs=-1, 
            use_gpu=self.gpu_manager.gpu_available
        )
        
        self.operators_manager = GeneticOperatorsManager(
            self.toolbox, 
            {
                'max_depth': config.max_depth,
                'crossover_prob': config.crossover_prob,
                'mutation_prob': config.mutation_prob,
                'tournament_size': config.tournament_size
            }
        )
        
        # Initialize DEAP
        self._initialize_deap()
        
        # State tracking
        self.population = []
        self.stats = []
        self.hall_of_fame = tools.HallOfFame(100)
        self.evolution_log = []
        
        # Threading for real-time updates
        self.is_running = False
        self.evolution_thread = None
        
        # Strategy management
        self.active_strategies = {}
        self.strategy_results = []
        
    def _initialize_deap(self):
        """DEAP'i başlat"""
        creator.create("FitnessMax", base.Fitness, weights=(1.0,))
        creator.create("Individual", list, fitness=creator.FitnessMax)
        
        self.toolbox.register("evaluate", self._evaluate_individual)
        self.toolbox.register("mate", self.operators_manager.crossover)
        self.toolbox.register("mutate", self.operators_manager.mutate)
        self.toolbox.register("select", self.operators_manager.select)
    
    def _evaluate_individual(self, individual, data):
        """Birey fitness değerlendirme wrapper - gerçek trading performansı hesapla"""
        try:
            # Genetic program tree evaluation
            raw_signals = self.parallel_evaluator._evaluate_individual(individual, data)
            
            # Ensure signals array matches price data length
            n_periods = len(data['close'])
            if len(raw_signals) != n_periods:
                if len(raw_signals) > n_periods:
                    raw_signals = raw_signals[:n_periods]
                else:
                    # Pad with zeros if needed
                    padding = np.zeros(n_periods - len(raw_signals))
                    raw_signals = np.concatenate([raw_signals, padding])
            
            # Convert raw signals to trading positions and calculate real P&L
            positions = self._convert_signals_to_positions(raw_signals)
            portfolio_returns = self._calculate_portfolio_returns(positions, data)
            
            # Calculate fitness based on actual trading performance
            if len(portfolio_returns) > 0:
                # Multiple fitness components
                fitness_components = []
                
                # Total return
                total_return = np.prod(1 + portfolio_returns) - 1
                fitness_components.append(max(0, total_return * 100))  # Scale to positive
                
                # Sharpe ratio
                if np.std(portfolio_returns) > 0:
                    sharpe = np.mean(portfolio_returns) / np.std(portfolio_returns) * np.sqrt(252)
                    fitness_components.append(max(0, sharpe))
                
                # Win rate
                win_rate = np.sum(portfolio_returns > 0) / len(portfolio_returns)
                fitness_components.append(win_rate * 100)
                
                # Profit factor
                profits = portfolio_returns[portfolio_returns > 0]
                losses = portfolio_returns[portfolio_returns < 0]
                if len(losses) > 0 and np.sum(np.abs(losses)) > 0:
                    profit_factor = np.sum(profits) / np.sum(np.abs(losses))
                    fitness_components.append(max(0, profit_factor * 10))
                
                # Combine fitness components
                if fitness_components:
                    fitness = np.mean(fitness_components)
                else:
                    fitness = 0.0
            else:
                fitness = 0.0
            
            return fitness if not np.isnan(fitness) and not np.isinf(fitness) else 0.0,
            
        except Exception as e:
            logging.warning(f"Individual evaluation error: {e}")
            return 0.0,
    
    def _convert_signals_to_positions(self, signals: np.ndarray) -> np.ndarray:
        """Trading signal'ları position'lara çevir"""
        try:
            # Convert signal strength to position sizes
            # signals: -1 (strong sell) to +1 (strong buy)
            positions = np.zeros(len(signals))
            
            # Simple position sizing based on signal strength
            for i in range(len(signals)):
                signal = signals[i]
                
                if signal > 0.5:
                    positions[i] = 1.0  # Full long position
                elif signal < -0.5:
                    positions[i] = -1.0  # Full short position
                elif signal > 0.1:
                    positions[i] = 0.5  # Half long position
                elif signal < -0.1:
                    positions[i] = -0.5  # Half short position
                else:
                    positions[i] = 0.0  # Neutral/no position
            
            return positions
            
        except Exception as e:
            logging.warning(f"Position conversion error: {e}")
            return np.zeros(len(signals))
    
    def _calculate_portfolio_returns(self, positions: np.ndarray, data: Dict[str, np.ndarray]) -> np.ndarray:
        """Position'lardan portfolio returns hesapla"""
        try:
            close_prices = data['close']
            
            if len(positions) != len(close_prices):
                if len(positions) > len(close_prices):
                    positions = positions[:len(close_prices)]
                else:
                    padding = np.zeros(len(close_prices) - len(positions))
                    positions = np.concatenate([positions, padding])
            
            # Calculate price changes
            price_changes = np.diff(close_prices) / close_prices[:-1]
            
            # Portfolio returns = position * price change
            portfolio_returns = positions[1:] * price_changes
            
            # Add transaction costs
            transaction_cost = 0.001  # 0.1% per trade
            position_changes = np.abs(np.diff(positions))
            transaction_costs = position_changes * transaction_cost
            
            # Net returns after transaction costs
            net_returns = portfolio_returns - transaction_costs
            
            return net_returns
            
        except Exception as e:
            logging.warning(f"Portfolio returns calculation error: {e}")
            return np.array([])
    
    def run_evolution(self, data: Dict[str, np.ndarray], 
                     checkpoint_interval: int = 10) -> List[EvolutionStats]:
        """Evrim süreci başlat"""
        logging.info(f"Evrim başlatılıyor: Popülasyon={self.config.population_size}, "
                   f"Nesiller={self.config.generations}")
        
        # Veriyi hazırla
        processed_data = self.data_processor.prepare_data(data)
        
        # Popülasyon oluştur
        self.population = self.toolbox.population(n=self.config.population_size)
        
        # DEAP creator ile individual'ları wrapper'la
        if not hasattr(creator, 'Individual'):
            creator.create("FitnessMax", base.Fitness, weights=(1.0,))
            creator.create("Individual", list, fitness=creator.FitnessMax)
        
        # Individual'ları DEAP wrapper'ına çevir
        wrapped_population = []
        for ind in self.population:
            wrapped_ind = creator.Individual(ind)
            wrapped_population.append(wrapped_ind)
        
        self.population = wrapped_population
        
        # Fitness değerlerini hesapla
        fitnesses = self.parallel_evaluator.evaluate_population(self.population, processed_data)
        
        # Fitness değerlerini ata
        for individual, fitness in zip(self.population, fitnesses):
            individual.fitness.values = (fitness,)
        
        # Stats başlat
        stats = tools.Statistics(lambda ind: ind.fitness.values)
        stats.register("avg", np.mean)
        stats.register("std", np.std)
        stats.register("min", np.min)
        stats.register("max", np.max)
        
        # Evolution loop
        for generation in range(self.config.generations):
            start_time = time.time()
            
            # Select offspring
            offspring = self.operators_manager.select(
                self.population, 
                [ind.fitness.values[0] for ind in self.population],
                len(self.population),
                method='tournament'
            )
            
            # Clone for variation
            offspring = [self.toolbox.clone(ind) for ind in offspring]
            
            # Apply crossover
            for child1, child2 in zip(offspring[::2], offspring[1::2]):
                if random.random() < self.config.crossover_prob:
                    self.toolbox.mate(child1, child2)
                    del child1.fitness.values
                    del child2.fitness.values
            
            # Apply mutation
            for mutant in offspring:
                if random.random() < self.config.mutation_prob:
                    self.toolbox.mutate(mutant)
                    del mutant.fitness.values
            
            # Evaluate invalid individuals
            invalid_ind = [ind for ind in offspring if not ind.fitness.valid]
            
            if invalid_ind:
                invalid_fitnesses = self.parallel_evaluator.evaluate_population(
                    invalid_ind, processed_data
                )
                for ind, fitness in zip(invalid_ind, invalid_fitnesses):
                    ind.fitness.values = (fitness,)
            
            # Select next generation
            self.population[:] = self.operators_manager.select(
                self.population + offspring,
                [ind.fitness.values[0] for ind in self.population + offspring],
                self.config.population_size,
                method='tournament'
            )
            
            # Update hall of fame
            self.hall_of_fame.update(self.population)
            
            # Calculate statistics
            generation_stats = stats.compile(self.population)
            
            # Calculate diversity
            diversity = self.operators_manager.diversity_preservation.calculate_diversity(
                self.population
            )
            
            elapsed_time = time.time() - start_time
            
            # Store stats
            evolution_stats = EvolutionStats(
                generation=generation,
                best_fitness=generation_stats['max'],
                avg_fitness=generation_stats['avg'],
                worst_fitness=generation_stats['min'],
                best_individual=self.hall_of_fame[0] if len(self.hall_of_fame) > 0 else None,
                diversity=diversity,
                elapsed_time=elapsed_time,
                fitness_history=[ind.fitness.values[0] for ind in self.population]
            )
            
            self.stats.append(evolution_stats)
            
            # Logging
            if generation % 10 == 0:
                logging.info(f"Generation {generation}: "
                           f"Best={evolution_stats.best_fitness:.4f}, "
                           f"Avg={evolution_stats.avg_fitness:.4f}, "
                           f"Diversity={diversity:.4f}")
            
            # Checkpoint
            if generation % checkpoint_interval == 0:
                self.save_checkpoint(f"checkpoint_gen_{generation}")
            
            # Early stopping if no improvement
            if self._check_early_stopping(generation):
                logging.info("Early stopping triggered")
                break
        
        logging.info("Evolution completed")
        return self.stats
    
    def _check_early_stopping(self, generation: int, patience: int = 50) -> bool:
        """Erken durdurma kontrolü"""
        if generation < patience:
            return False
        
        recent_stats = self.stats[-patience:]
        best_improvements = []
        
        for i in range(1, len(recent_stats)):
            improvement = recent_stats[i].best_fitness - recent_stats[i-1].best_fitness
            best_improvements.append(improvement)
        
        # Stop if no significant improvement
        return np.mean(best_improvements) < 1e-6
    
    def deploy_strategy(self, individual: Any, strategy_id: str) -> str:
        """Strateji dağıt"""
        try:
            # Generate strategy code
            strategy_code = self._generate_strategy_code(individual)
            
            # Store active strategy
            self.active_strategies[strategy_id] = {
                'individual': individual,
                'strategy_code': strategy_code,
                'deployment_time': time.time(),
                'status': 'active'
            }
            
            logging.info(f"Strateji dağıtıldı: {strategy_id}")
            return strategy_id
            
        except Exception as e:
            logging.error(f"Strategy deployment error: {e}")
            raise
    
    def _generate_strategy_code(self, individual: Any) -> str:
        """Strateji kodu üret"""
        # Simplified code generation
        code_lines = [
            "def trading_strategy(data):",
            "    signals = []",
            f"    # Genetic Program: {individual}",
            "    for i in range(len(data['close'])):",
            "        # Simplified signal generation",
            "        signal = 1.0 if data['close'][i] > data['open'][i] else -1.0",
            "        signals.append(signal)",
            "    return np.array(signals)"
        ]
        
        return "\n".join(code_lines)
    
    def stop_strategy(self, strategy_id: str):
        """Strateji durdur"""
        if strategy_id in self.active_strategies:
            self.active_strategies[strategy_id]['status'] = 'inactive'
            logging.info(f"Strateji durduruldu: {strategy_id}")
    
    def get_best_strategies(self, count: int = 10) -> List[StrategyResult]:
        """En iyi stratejileri getir"""
        results = []
        
        for i, ind in enumerate(self.hall_of_fame):
            metrics = self._calculate_strategy_metrics(ind)
            result = StrategyResult(
                strategy_id=f"strategy_{i}",
                individual=ind,
                fitness=ind.fitness.values[0],
                metrics=metrics,
                creation_time=time.time(),
                performance_score=self._calculate_performance_score(metrics)
            )
            results.append(result)
        
        return sorted(results, key=lambda x: x.fitness, reverse=True)[:count]
    
    def _calculate_strategy_metrics(self, individual: Any) -> Dict[str, float]:
        """Strateji metriklerini hesapla"""
        try:
            signals = self.parallel_evaluator._evaluate_individual(individual, {})
            portfolio_metrics = self.fitness_calculator.calculate_portfolio_metrics(
                np.array(signals), np.random.random(100)  # Dummy data
            )
            
            return {
                'total_return': portfolio_metrics.total_return,
                'sharpe_ratio': portfolio_metrics.sharpe_ratio,
                'max_drawdown': portfolio_metrics.max_drawdown,
                'win_rate': portfolio_metrics.win_rate,
                'profit_factor': portfolio_metrics.profit_factor
            }
        except:
            return {'total_return': 0.0, 'sharpe_ratio': 0.0}
    
    def _calculate_performance_score(self, metrics: Dict[str, float]) -> float:
        """Performans skoru hesapla"""
        # Weighted score calculation
        weights = {
            'total_return': 0.3,
            'sharpe_ratio': 0.25,
            'max_drawdown': 0.2,
            'win_rate': 0.15,
            'profit_factor': 0.1
        }
        
        score = 0.0
        for metric, value in metrics.items():
            if metric in weights:
                score += value * weights[metric]
        
        return score
    
    def save_checkpoint(self, filename: str):
        """Checkpoint kaydet"""
        checkpoint = {
            'config': asdict(self.config),
            'population': self.population,
            'hall_of_fame': self.hall_of_fame,
            'stats': [stat.to_dict() for stat in self.stats],
            'generation': len(self.stats)
        }
        
        with open(f"{filename}.pkl", 'wb') as f:
            pickle.dump(checkpoint, f)
    
    def load_checkpoint(self, filename: str):
        """Checkpoint yükle"""
        with open(filename, 'rb') as f:
            checkpoint = pickle.load(f)
        
        self.population = checkpoint['population']
        self.hall_of_fame = checkpoint['hall_of_fame']
        self.stats = [EvolutionStats(**stat) for stat in checkpoint['stats']]
        
        logging.info(f"Checkpoint yüklendi: {filename}")
    
    def export_strategies(self, filename: str, format: str = 'json'):
        """Stratejileri dışa aktar"""
        best_strategies = self.get_best_strategies()
        
        export_data = {
            'export_time': time.time(),
            'config': asdict(self.config),
            'strategies': [result.to_dict() for result in best_strategies]
        }
        
        if format == 'json':
            with open(f"{filename}.json", 'w') as f:
                json.dump(export_data, f, indent=2)
        elif format == 'pickle':
            with open(f"{filename}.pkl", 'wb') as f:
                pickle.dump(export_data, f)
        
        logging.info(f"Stratejiler dışa aktarıldı: {filename}")


def create_engine(config) -> EvolutionEngine:
    """Engine fabrikası"""
    if isinstance(config, EvolutionConfig):
        evolution_config = config
    elif isinstance(config, dict):
        evolution_config = EvolutionConfig(**config)
    else:
        # Default configuration
        evolution_config = EvolutionConfig()
    
    return EvolutionEngine(evolution_config)


# Default configuration
DEFAULT_ENGINE_CONFIG = {
    'population_size': 10000,
    'generations': 1000,
    'crossover_prob': 0.8,
    'mutation_prob': 0.1,
    'elitism_rate': 0.1,
    'max_depth': 10,
    'tournament_size': 3,
    'fitness_config': {
        'use_profit': True,
        'use_sharpe': True,
        'use_sortino': True,
        'use_drawdown': True,
        'use_win_rate': False,
        'use_profit_factor': True,
        'use_calmar': True,
        'risk_free_rate': 0.02
    }
}