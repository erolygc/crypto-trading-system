"""
Genetik Programlama Motoru - Fitness Fonksiyonları
Bu modül strateji performansını değerlendiren fitness fonksiyonlarını içerir.
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Tuple, Any, Optional
from abc import ABC, abstractmethod
from dataclasses import dataclass
import warnings


@dataclass
class Trade:
    """İşlem kaydı"""
    entry_time: int
    entry_price: float
    exit_time: int
    exit_price: float
    quantity: float
    pnl: float
    pnl_percent: float
    direction: str  # 'long' or 'short'
    strategy_id: str


@dataclass
class PortfolioMetrics:
    """Portföy metrikleri"""
    total_return: float
    annualized_return: float
    volatility: float
    sharpe_ratio: float
    sortino_ratio: float
    max_drawdown: float
    calmar_ratio: float
    win_rate: float
    profit_factor: float
    total_trades: int
    winning_trades: int
    losing_trades: int
    avg_win: float
    avg_loss: float
    avg_trade: float
    consecutive_wins: int
    consecutive_losses: int
    var_95: float  # Value at Risk 95%
    cvar_95: float  # Conditional VaR 95%
    skewness: float
    kurtosis: float


class FitnessFunction(ABC):
    """Fitness fonksiyonu base sınıfı"""
    
    def __init__(self, name: str, weight: float = 1.0):
        self.name = name
        self.weight = weight
    
    @abstractmethod
    def evaluate(self, signals: np.ndarray, prices: np.ndarray, **kwargs) -> float:
        """Fitness değerini hesapla"""
        pass
    
    def normalize(self, value: float, min_val: float, max_val: float) -> float:
        """Değeri [0, 1] aralığına normalize et"""
        if max_val == min_val:
            return 0.5
        return (value - min_val) / (max_val - min_val)


class ProfitFitness(FitnessFunction):
    """Kar odaklı fitness fonksiyonu"""
    
    def __init__(self, weight: float = 1.0):
        super().__init__("profit", weight)
    
    def evaluate(self, signals: np.ndarray, prices: np.ndarray, **kwargs) -> float:
        """Toplam karı hesapla"""
        if len(signals) != len(prices):
            # Adjust to minimum length to avoid index errors
            min_len = min(len(signals), len(prices))
            signals = signals[:min_len]
            prices = prices[:min_len]
        
        # Sinyal değişimlerini bul
        signal_changes = np.diff(np.concatenate(([0], np.signbit(signals[:-1]))))
        buy_signals = signal_changes > 0  # Pozitif değişim = alış
        sell_signals = signal_changes < 0  # Negatif değişim = satış
        
        # Basit PnL hesabı
        total_pnl = 0.0
        position = 0.0
        entry_price = 0.0
        
        for i in range(1, len(signals)):
            prev_position = position
            
            if buy_signals[i] and position == 0:
                position = 1.0
                entry_price = prices[i]
            elif sell_signals[i] and position > 0:
                position = 0.0
                exit_price = prices[i]
                total_pnl += (exit_price - entry_price) / entry_price
        
        return max(0, total_pnl)  # Negatif karı 0 yap


class SharpeRatioFitness(FitnessFunction):
    """Sharpe oranı fitness fonksiyonu"""
    
    def __init__(self, risk_free_rate: float = 0.02, weight: float = 1.0):
        super().__init__("sharpe", weight)
        self.risk_free_rate = risk_free_rate
    
    def evaluate(self, returns: np.ndarray, **kwargs) -> float:
        """Sharpe oranını hesapla"""
        if len(returns) == 0:
            return 0.0
        
        # Günlük risk-free rate'i hesapla
        daily_rf = (1 + self.risk_free_rate) ** (1/252) - 1
        
        # Excess returns
        excess_returns = returns - daily_rf
        
        if np.std(excess_returns) == 0:
            return 0.0
        
        sharpe = np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252)
        
        # Limit to reasonable range
        return np.clip(sharpe, -5.0, 5.0)


class SortinoRatioFitness(FitnessFunction):
    """Sortino oranı fitness fonksiyonu"""
    
    def __init__(self, risk_free_rate: float = 0.02, weight: float = 1.0):
        super().__init__("sortino", weight)
        self.risk_free_rate = risk_free_rate
    
    def evaluate(self, returns: np.ndarray, **kwargs) -> float:
        """Sortino oranını hesapla"""
        if len(returns) == 0:
            return 0.0
        
        daily_rf = (1 + self.risk_free_rate) ** (1/252) - 1
        excess_returns = returns - daily_rf
        
        if np.std(excess_returns) == 0:
            return 0.0
        
        # Downside deviation
        downside_returns = excess_returns[excess_returns < 0]
        if len(downside_returns) == 0:
            return 5.0  # Maximum score if no downside
        
        downside_deviation = np.std(downside_returns)
        sortino = np.mean(excess_returns) / downside_deviation * np.sqrt(252)
        
        return np.clip(sortino, -5.0, 5.0)


class MaxDrawdownFitness(FitnessFunction):
    """Maksimum düşüş fitness fonksiyonu"""
    
    def __init__(self, weight: float = 0.5):
        super().__init__("max_drawdown", weight)
    
    def evaluate(self, cumulative_returns: np.ndarray, **kwargs) -> float:
        """Maksimum düşüşü hesapla"""
        if len(cumulative_returns) == 0:
            return 0.0
        
        peak = np.maximum.accumulate(cumulative_returns)
        drawdown = (cumulative_returns - peak) / peak
        max_drawdown = np.abs(np.min(drawdown))
        
        # Fitness score (lower drawdown = higher fitness)
        return 1.0 - min(max_drawdown, 1.0)


class WinRateFitness(FitnessFunction):
    """Kazanma oranı fitness fonksiyonu"""
    
    def __init__(self, weight: float = 0.5):
        super().__init__("win_rate", weight)
    
    def evaluate(self, trades: List[Trade], **kwargs) -> float:
        """Kazanma oranını hesapla"""
        if len(trades) == 0:
            return 0.0
        
        winning_trades = [t for t in trades if t.pnl > 0]
        win_rate = len(winning_trades) / len(trades)
        
        return win_rate


class ProfitFactorFitness(FitnessFunction):
    """Kar faktörü fitness fonksiyonu"""
    
    def __init__(self, weight: float = 1.0):
        super().__init__("profit_factor", weight)
    
    def evaluate(self, trades: List[Trade], **kwargs) -> float:
        """Kar faktörünü hesapla"""
        if len(trades) == 0:
            return 0.0
        
        total_wins = sum(t.pnl for t in trades if t.pnl > 0)
        total_losses = abs(sum(t.pnl for t in trades if t.pnl < 0))
        
        if total_losses == 0:
            return 10.0 if total_wins > 0 else 0.0
        
        profit_factor = total_wins / total_losses
        return min(profit_factor, 10.0)  # Cap at 10


class CalmarRatioFitness(FitnessFunction):
    """Calmar oranı fitness fonksiyonu"""
    
    def __init__(self, weight: float = 0.8):
        super().__init__("calmar", weight)
    
    def evaluate(self, total_return: float, max_drawdown: float, **kwargs) -> float:
        """Calmar oranını hesapla"""
        if max_drawdown == 0:
            return 0.0
        
        # Annualized return assumption
        annualized_return = (1 + total_return) ** (252 / len(kwargs.get('returns', [1]))) - 1
        calmar = annualized_return / max_drawdown
        
        return np.clip(calmar, -2.0, 2.0)


class CompositeFitness(FitnessFunction):
    """Bileşik fitness fonksiyonu"""
    
    def __init__(self, fitness_functions: List[FitnessFunction]):
        super().__init__("composite")
        self.fitness_functions = fitness_functions
    
    def evaluate(self, **kwargs) -> float:
        """Bileşik fitness değerini hesapla"""
        total_score = 0.0
        total_weight = 0.0
        
        for fitness_func in self.fitness_functions:
            score = fitness_func.evaluate(**kwargs)
            total_score += score * fitness_func.weight
            total_weight += fitness_func.weight
        
        if total_weight == 0:
            return 0.0
        
        return total_score / total_weight


class AdvancedFitnessCalculator:
    """Gelişmiş fitness hesaplama sınıfı"""
    
    def __init__(self, 
                 use_profit: bool = True,
                 use_sharpe: bool = True,
                 use_sortino: bool = True,
                 use_drawdown: bool = True,
                 use_win_rate: bool = False,
                 use_profit_factor: bool = True,
                 use_calmar: bool = True,
                 risk_free_rate: float = 0.02):
        
        self.fitness_functions = []
        
        if use_profit:
            self.fitness_functions.append(ProfitFitness())
        
        if use_sharpe:
            self.fitness_functions.append(SharpeRatioFitness(risk_free_rate))
        
        if use_sortino:
            self.fitness_functions.append(SortinoRatioFitness(risk_free_rate))
        
        if use_drawdown:
            self.fitness_functions.append(MaxDrawdownFitness())
        
        if use_win_rate:
            self.fitness_functions.append(WinRateFitness())
        
        if use_profit_factor:
            self.fitness_functions.append(ProfitFactorFitness())
        
        if use_calmar:
            self.fitness_functions.append(CalmarRatioFitness())
        
        self.composite_fitness = CompositeFitness(self.fitness_functions)
    
    def calculate_portfolio_metrics(self, signals: np.ndarray, prices: np.ndarray, 
                                  volumes: Optional[np.ndarray] = None) -> PortfolioMetrics:
        """Portföy metriklerini hesapla"""
        
        if len(signals) != len(prices):
            # Adjust to minimum length to avoid index errors
            min_len = min(len(signals), len(prices))
            signals = signals[:min_len]
            prices = prices[:min_len]
        
        # Returns hesapla (guard against index errors)
        if len(prices) > 1:
            returns = np.diff(prices) / prices[:-1]
            signal_returns = signals[:-1] * returns
            
            # Cumulative returns
            cumulative_returns = np.cumprod(1 + signal_returns) - 1
        else:
            returns = np.array([0])
            signal_returns = np.array([0])
            cumulative_returns = np.array([0])
        
        # Trading simulation
        trades = self._simulate_trades(signals, prices)
        
        # Basic metrics
        total_return = cumulative_returns[-1] if len(cumulative_returns) > 0 else 0.0
        volatility = np.std(signal_returns) * np.sqrt(252) if len(signal_returns) > 0 else 0.0
        
        # Sharpe ratio
        daily_rf = (1 + 0.02) ** (1/252) - 1
        excess_returns = signal_returns - daily_rf
        sharpe_ratio = np.mean(excess_returns) / np.std(excess_returns) * np.sqrt(252) if np.std(excess_returns) > 0 else 0.0
        
        # Sortino ratio
        downside_returns = excess_returns[excess_returns < 0]
        downside_deviation = np.std(downside_returns) if len(downside_returns) > 0 else 0
        sortino_ratio = np.mean(excess_returns) / downside_deviation * np.sqrt(252) if downside_deviation > 0 else 0.0
        
        # Max drawdown
        peak = np.maximum.accumulate(1 + cumulative_returns)
        drawdown = (1 + cumulative_returns) / peak - 1
        max_drawdown = abs(np.min(drawdown)) if len(drawdown) > 0 else 0.0
        
        # Win rate ve diğer trade metrics
        winning_trades = [t for t in trades if t.pnl > 0]
        win_rate = len(winning_trades) / len(trades) if len(trades) > 0 else 0.0
        
        total_wins = sum(t.pnl for t in trades if t.pnl > 0)
        total_losses = abs(sum(t.pnl for t in trades if t.pnl < 0))
        profit_factor = total_wins / total_losses if total_losses > 0 else 0.0
        
        # Average trade metrics
        avg_win = np.mean([t.pnl_percent for t in trades if t.pnl > 0]) if winning_trades else 0.0
        avg_loss = np.mean([t.pnl_percent for t in trades if t.pnl < 0]) if [t for t in trades if t.pnl < 0] else 0.0
        avg_trade = np.mean([t.pnl_percent for t in trades]) if trades else 0.0
        
        # VaR and CVaR
        var_95 = np.percentile(signal_returns, 5) if len(signal_returns) > 0 else 0.0
        cvar_95 = np.mean(signal_returns[signal_returns <= var_95]) if len(signal_returns) > 0 else 0.0
        
        # Higher moments
        skewness = self._calculate_skewness(signal_returns)
        kurtosis = self._calculate_kurtosis(signal_returns)
        
        # Annualized return
        periods = len(cumulative_returns)
        if periods > 0:
            annualized_return = (1 + total_return) ** (252 / periods) - 1
        else:
            annualized_return = 0.0
        
        # Calmar ratio
        calmar_ratio = annualized_return / max_drawdown if max_drawdown > 0 else 0.0
        
        return PortfolioMetrics(
            total_return=total_return,
            annualized_return=annualized_return,
            volatility=volatility,
            sharpe_ratio=sharpe_ratio,
            sortino_ratio=sortino_ratio,
            max_drawdown=max_drawdown,
            calmar_ratio=calmar_ratio,
            win_rate=win_rate,
            profit_factor=profit_factor,
            total_trades=len(trades),
            winning_trades=len(winning_trades),
            losing_trades=len(trades) - len(winning_trades),
            avg_win=avg_win,
            avg_loss=avg_loss,
            avg_trade=avg_trade,
            consecutive_wins=self._max_consecutive_wins(trades),
            consecutive_losses=self._max_consecutive_losses(trades),
            var_95=var_95,
            cvar_95=cvar_95,
            skewness=skewness,
            kurtosis=kurtosis
        )
    
    def _simulate_trades(self, signals: np.ndarray, prices: np.ndarray) -> List[Trade]:
        """İşlem simülasyonu"""
        trades = []
        position = 0.0
        entry_price = 0.0
        entry_time = 0
        
        for i in range(1, len(signals)):
            signal_change = signals[i] - signals[i-1]
            
            if signal_change > 0.5 and position == 0:  # Long entry
                position = 1.0
                entry_price = prices[i]
                entry_time = i
            elif signal_change < -0.5 and position > 0:  # Long exit
                exit_price = prices[i]
                pnl = (exit_price - entry_price) / entry_price
                pnl_percent = pnl * 100
                
                trades.append(Trade(
                    entry_time=entry_time,
                    entry_price=entry_price,
                    exit_time=i,
                    exit_price=exit_price,
                    quantity=position,
                    pnl=pnl,
                    pnl_percent=pnl_percent,
                    direction="long",
                    strategy_id="gp_strategy"
                ))
                position = 0.0
        
        return trades
    
    def _calculate_skewness(self, data: np.ndarray) -> float:
        """Çarpıklık hesapla"""
        if len(data) < 2:
            return 0.0
        return pd.Series(data).skew()
    
    def _calculate_kurtosis(self, data: np.ndarray) -> float:
        """Basıklık hesapla"""
        if len(data) < 2:
            return 0.0
        return pd.Series(data).kurtosis()
    
    def _max_consecutive_wins(self, trades: List[Trade]) -> int:
        """Maksimum ardışık kazanç"""
        if not trades:
            return 0
        
        max_consecutive = 0
        current_consecutive = 0
        
        for trade in trades:
            if trade.pnl > 0:
                current_consecutive += 1
                max_consecutive = max(max_consecutive, current_consecutive)
            else:
                current_consecutive = 0
        
        return max_consecutive
    
    def _max_consecutive_losses(self, trades: List[Trade]) -> int:
        """Maksimum ardışık kayıp"""
        if not trades:
            return 0
        
        max_consecutive = 0
        current_consecutive = 0
        
        for trade in trades:
            if trade.pnl < 0:
                current_consecutive += 1
                max_consecutive = max(max_consecutive, current_consecutive)
            else:
                current_consecutive = 0
        
        return max_consecutive
    
    def evaluate(self, signals: np.ndarray, prices: np.ndarray, **kwargs) -> float:
        """Bileşik fitness değerini hesapla"""
        try:
            # Ensure signals and prices have the same length
            if len(signals) != len(prices):
                min_len = min(len(signals), len(prices))
                signals = signals[:min_len]
                prices = prices[:min_len]
            
            portfolio_metrics = self.calculate_portfolio_metrics(signals, prices, kwargs.get('volumes'))
            
            # Calculate returns carefully to avoid index errors
            if len(prices) > 1:
                price_returns = np.diff(prices) / prices[:-1]
                signal_returns = signals[:-1] * price_returns
                cumulative_returns = np.cumprod(1 + signal_returns) - 1
            else:
                price_returns = np.array([])
                signal_returns = np.array([])
                cumulative_returns = np.array([])
            
            # Fitness hesabı için gerekli verileri hazırla
            fitness_data = {
                'signals': signals,
                'prices': prices,
                'returns': signal_returns,
                'cumulative_returns': cumulative_returns,
                'trades': self._simulate_trades(signals, prices),
                'total_return': portfolio_metrics.total_return,
                'max_drawdown': portfolio_metrics.max_drawdown
            }
            
            return self.composite_fitness.evaluate(**fitness_data)
            
        except Exception as e:
            warnings.warn(f"Fitness hesaplama hatası: {str(e)}")
            return 0.0


# Fitness calculator factory
def create_fitness_calculator(config: Dict[str, Any]) -> AdvancedFitnessCalculator:
    """Fitness hesaplayıcı fabrikası"""
    return AdvancedFitnessCalculator(
        use_profit=config.get('use_profit', True),
        use_sharpe=config.get('use_sharpe', True),
        use_sortino=config.get('use_sortino', True),
        use_drawdown=config.get('use_drawdown', True),
        use_win_rate=config.get('use_win_rate', False),
        use_profit_factor=config.get('use_profit_factor', True),
        use_calmar=config.get('use_calmar', True),
        risk_free_rate=config.get('risk_free_rate', 0.02)
    )


# Default fitness configuration
DEFAULT_FITNESS_CONFIG = {
    'use_profit': True,
    'use_sharpe': True,
    'use_sortino': True,
    'use_drawdown': True,
    'use_win_rate': False,
    'use_profit_factor': True,
    'use_calmar': True,
    'risk_free_rate': 0.02
}