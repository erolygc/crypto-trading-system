"""
Genetik Programlama Motoru - Real-time Deployment ve A/B Testing
Bu modül real-time strateji dağıtımı ve A/B testing framework'ünü içerir.
"""

import asyncio
import json

# Optional imports
try:
    import websockets
    HAS_WEBSOCKETS = True
except ImportError:
    websockets = None
    HAS_WEBSOCKETS = False
import time
import threading
import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Callable, Tuple
from dataclasses import dataclass, asdict
from enum import Enum
import logging
import uuid
from collections import deque
import statistics
from concurrent.futures import ThreadPoolExecutor


class DeploymentStatus(Enum):
    """Dağıtım durumu"""
    PENDING = "pending"
    ACTIVE = "active"
    PAUSED = "paused"
    FAILED = "failed"
    STOPPED = "stopped"


class ABTestStatus(Enum):
    """A/B test durumu"""
    PLANNED = "planned"
    RUNNING = "running"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


@dataclass
class StrategyDeployment:
    """Strateji dağıtım bilgileri"""
    deployment_id: str
    strategy_id: str
    individual: Any
    strategy_code: str
    status: DeploymentStatus
    deployment_time: float
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    performance_metrics: Dict[str, float] = None
    risk_limits: Dict[str, float] = None
    capital_allocation: float = 1.0
    websocket_connection: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data['status'] = self.status.value
        return data


@dataclass
class ABTest:
    """A/B test konfigürasyonu"""
    test_id: str
    test_name: str
    strategy_a_id: str
    strategy_b_id: str
    status: ABTestStatus
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    test_duration: int = 86400  # 24 hours in seconds
    allocation_a: float = 0.5
    allocation_b: float = 0.5
    success_criteria: Dict[str, float] = None
    results: Dict[str, Any] = None
    statistical_significance: float = 0.05
    
    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data['status'] = self.status.value
        return data


@dataclass
class MarketData:
    """Piyasa verisi"""
    timestamp: float
    symbol: str
    price: float
    volume: float
    bid: float
    ask: float
    high: float
    low: float
    open: float
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class TradeExecution:
    """İşlem gerçekleştirme"""
    execution_id: str
    strategy_id: str
    symbol: str
    side: str  # 'buy' or 'sell'
    quantity: float
    price: float
    timestamp: float
    status: str  # 'filled', 'partial', 'rejected'
    
    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class RealTimeStrategy:
    """Real-time strateji sınıfı"""
    
    def __init__(self, strategy_id: str, individual: Any, 
                 performance_callback: Optional[Callable] = None):
        self.strategy_id = strategy_id
        self.individual = individual
        self.performance_callback = performance_callback
        
        # State tracking
        self.position = 0.0
        self.cash = 100000.0  # Initial capital
        self.trades = []
        self.performance_history = deque(maxlen=1000)
        
        # Real-time data
        self.data_buffer = deque(maxlen=100)
        self.last_signal = 0.0
        self.signal_history = deque(maxlen=100)
        
        # Risk management
        self.max_position = 1.0
        self.stop_loss = -0.05  # -5%
        self.take_profit = 0.10  # 10%
        
        # Threading
        self.running = False
        self.update_thread = None
        self.update_interval = 1.0  # 1 second
        
    def start(self):
        """Stratejiyi başlat"""
        if not self.running:
            self.running = True
            self.update_thread = threading.Thread(target=self._update_loop)
            self.update_thread.daemon = True
            self.update_thread.start()
    
    def stop(self):
        """Stratejiyi durdur"""
        self.running = False
        if self.update_thread:
            self.update_thread.join(timeout=5.0)
    
    def update_market_data(self, market_data: MarketData):
        """Piyasa verisini güncelle"""
        self.data_buffer.append(market_data)
        
        if len(self.data_buffer) >= 2:
            # Generate signal
            signal = self._generate_signal()
            
            if signal != self.last_signal:
                self.last_signal = signal
                self.signal_history.append({
                    'timestamp': market_data.timestamp,
                    'signal': signal,
                    'price': market_data.price
                })
    
    def _generate_signal(self) -> float:
        """Sinyal üret"""
        if len(self.data_buffer) < 10:
            return 0.0
        
        try:
            # Convert buffer to arrays for processing
            prices = np.array([d.price for d in self.data_buffer])
            volumes = np.array([d.volume for d in self.data_buffer])
            
            # Simplified signal generation based on genetic program
            # In real implementation, this would interpret the GP tree
            
            # Dummy signal based on price momentum
            returns = np.diff(prices) / prices[:-1]
            signal = np.mean(returns[-5:]) * 10  # Scale factor
            
            # Apply position limits
            return np.clip(signal, -self.max_position, self.max_position)
            
        except Exception as e:
            logging.warning(f"Signal generation error: {e}")
            return 0.0
    
    def _update_loop(self):
        """Güncelleme döngüsü"""
        while self.running:
            try:
                if len(self.data_buffer) > 0:
                    latest_data = self.data_buffer[-1]
                    
                    # Check for trade signals
                    self._check_trade_signals(latest_data)
                    
                    # Update performance metrics
                    self._update_performance()
                
                time.sleep(self.update_interval)
                
            except Exception as e:
                logging.error(f"Strategy update error: {e}")
                time.sleep(1.0)
    
    def _check_trade_signals(self, market_data: MarketData):
        """İşlem sinyallerini kontrol et"""
        if abs(self.last_signal) < 0.1:  # Deadzone
            return
        
        # Simple position management
        if self.last_signal > 0 and self.position <= 0:
            self._execute_trade('buy', market_data)
        elif self.last_signal < 0 and self.position >= 0:
            self._execute_trade('sell', market_data)
    
    def _execute_trade(self, side: str, market_data: MarketData):
        """İşlem gerçekleştir"""
        if side == 'buy' and self.cash > 1000:  # Minimum cash
            quantity = min(1000 / market_data.price, self.cash / market_data.price)
            self.cash -= quantity * market_data.price
            self.position += quantity
        elif side == 'sell' and self.position > 0:
            self.position -= self.position * 0.1  # Sell 10% of position
            self.cash += self.position * 0.1 * market_data.price
        
        # Record trade
        trade = TradeExecution(
            execution_id=str(uuid.uuid4()),
            strategy_id=self.strategy_id,
            symbol=market_data.symbol,
            side=side,
            quantity=quantity if side == 'buy' else self.position * 0.1,
            price=market_data.price,
            timestamp=market_data.timestamp,
            status='filled'
        )
        
        self.trades.append(trade)
    
    def _update_performance(self):
        """Performans güncelle"""
        if len(self.data_buffer) > 0:
            current_price = self.data_buffer[-1].price
            
            # Calculate portfolio value
            portfolio_value = self.cash + self.position * current_price
            initial_value = 100000.0
            total_return = (portfolio_value - initial_value) / initial_value
            
            # Store performance metrics
            performance = {
                'timestamp': time.time(),
                'portfolio_value': portfolio_value,
                'total_return': total_return,
                'position': self.position,
                'cash': self.cash,
                'signal': self.last_signal
            }
            
            self.performance_history.append(performance)
            
            # Callback if available
            if self.performance_callback:
                self.performance_callback(self.strategy_id, performance)
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Performans özeti"""
        if not self.performance_history:
            return {}
        
        returns = [p['total_return'] for p in self.performance_history]
        
        return {
            'total_return': returns[-1] if returns else 0.0,
            'max_return': max(returns) if returns else 0.0,
            'min_return': min(returns) if returns else 0.0,
            'avg_return': statistics.mean(returns) if returns else 0.0,
            'volatility': statistics.stdev(returns) if len(returns) > 1 else 0.0,
            'sharpe_ratio': statistics.mean(returns) / statistics.stdev(returns) if len(returns) > 1 else 0.0,
            'total_trades': len(self.trades),
            'position': self.position,
            'cash': self.cash
        }


class DeploymentManager:
    """Dağıtım yöneticisi"""
    
    def __init__(self):
        self.deployments: Dict[str, StrategyDeployment] = {}
        self.strategies: Dict[str, RealTimeStrategy] = {}
        self.market_data_stream = None
        self.performance_history = {}
        
    async def deploy_strategy(self, individual: Any, strategy_id: str,
                            websocket_url: Optional[str] = None) -> str:
        """Strateji dağıt"""
        deployment_id = str(uuid.uuid4())
        
        try:
            # Generate strategy code
            strategy_code = self._generate_strategy_code(individual)
            
            # Create deployment record
            deployment = StrategyDeployment(
                deployment_id=deployment_id,
                strategy_id=strategy_id,
                individual=individual,
                strategy_code=strategy_code,
                status=DeploymentStatus.PENDING,
                deployment_time=time.time(),
                websocket_connection=websocket_url
            )
            
            self.deployments[deployment_id] = deployment
            
            # Create and start strategy instance
            strategy = RealTimeStrategy(
                strategy_id=strategy_id,
                individual=individual,
                performance_callback=self._on_performance_update
            )
            
            self.strategies[deployment_id] = strategy
            strategy.start()
            
            # Update status
            deployment.status = DeploymentStatus.ACTIVE
            deployment.start_time = time.time()
            
            logging.info(f"Strateji dağıtıldı: {deployment_id}")
            return deployment_id
            
        except Exception as e:
            logging.error(f"Strategy deployment error: {e}")
            if deployment_id in self.deployments:
                self.deployments[deployment_id].status = DeploymentStatus.FAILED
            raise
    
    def undeploy_strategy(self, deployment_id: str):
        """Strateji geri al"""
        if deployment_id in self.strategies:
            self.strategies[deployment_id].stop()
            del self.strategies[deployment_id]
        
        if deployment_id in self.deployments:
            deployment = self.deployments[deployment_id]
            deployment.status = DeploymentStatus.STOPPED
            deployment.end_time = time.time()
            
            logging.info(f"Strateji geri alındı: {deployment_id}")
    
    def pause_strategy(self, deployment_id: str):
        """Stratejiyi duraklat"""
        if deployment_id in self.strategies:
            self.strategies[deployment_id].running = False
        
        if deployment_id in self.deployments:
            self.deployments[deployment_id].status = DeploymentStatus.PAUSED
    
    def resume_strategy(self, deployment_id: str):
        """Stratejiyi devam ettir"""
        if deployment_id in self.strategies:
            self.strategies[deployment_id].running = True
        
        if deployment_id in self.deployments:
            self.deployments[deployment_id].status = DeploymentStatus.ACTIVE
    
    def get_deployment_status(self, deployment_id: str) -> Optional[Dict[str, Any]]:
        """Dağıtım durumunu getir"""
        if deployment_id not in self.deployments:
            return None
        
        deployment = self.deployments[deployment_id]
        
        # Add current performance
        if deployment_id in self.strategies:
            strategy = self.strategies[deployment_id]
            performance = strategy.get_performance_summary()
            deployment.performance_metrics = performance
        
        return deployment.to_dict()
    
    def _generate_strategy_code(self, individual: Any) -> str:
        """Strateji kodu üret"""
        # Simplified code generation
        return f"""
def trading_strategy(market_data):
    # Genetic Program: {str(individual)[:100]}...
    # Simplified strategy implementation
    return 1.0 if market_data.price > market_data.open else -1.0
"""
    
    def _on_performance_update(self, strategy_id: str, performance: Dict[str, Any]):
        """Performans güncelleme callback"""
        if strategy_id not in self.performance_history:
            self.performance_history[strategy_id] = []
        
        self.performance_history[strategy_id].append(performance)
    
    async def stream_market_data(self, symbol: str, interval: float = 1.0):
        """Piyasa verisi stream et"""
        # Simplified market data simulation
        price = 100.0
        
        while True:
            # Simulate price movement
            price += np.random.normal(0, 0.1)
            
            market_data = MarketData(
                timestamp=time.time(),
                symbol=symbol,
                price=price,
                volume=np.random.randint(1000, 10000),
                bid=price - 0.05,
                ask=price + 0.05,
                high=price + np.random.uniform(0, 1),
                low=price - np.random.uniform(0, 1),
                open=price + np.random.normal(0, 0.1)
            )
            
            # Send to all active strategies
            for strategy in self.strategies.values():
                if strategy.running:
                    strategy.update_market_data(market_data)
            
            await asyncio.sleep(interval)


class ABTestFramework:
    """A/B test framework"""
    
    def __init__(self, deployment_manager: DeploymentManager):
        self.deployment_manager = deployment_manager
        self.tests: Dict[str, ABTest] = {}
        self.test_results = {}
    
    async def create_test(self, test_name: str, strategy_a_id: str, strategy_b_id: str,
                         test_duration: int = 86400, allocation_a: float = 0.5,
                         success_criteria: Optional[Dict[str, float]] = None) -> str:
        """A/B test oluştur"""
        test_id = str(uuid.uuid4())
        
        test = ABTest(
            test_id=test_id,
            test_name=test_name,
            strategy_a_id=strategy_a_id,
            strategy_b_id=strategy_b_id,
            status=ABTestStatus.PLANNED,
            test_duration=test_duration,
            allocation_a=allocation_a,
            allocation_b=1.0 - allocation_a,
            success_criteria=success_criteria or {
                'return_threshold': 0.05,  # 5% minimum return
                'sharpe_threshold': 1.0,   # Minimum Sharpe ratio
                'max_drawdown_threshold': 0.1  # 10% max drawdown
            }
        )
        
        self.tests[test_id] = test
        logging.info(f"A/B test oluşturuldu: {test_id}")
        return test_id
    
    async def start_test(self, test_id: str):
        """Testi başlat"""
        if test_id not in self.tests:
            raise ValueError(f"Test bulunamadı: {test_id}")
        
        test = self.tests[test_id]
        test.status = ABTestStatus.RUNNING
        test.start_time = time.time()
        
        # Deploy both strategies
        deployment_a = await self.deployment_manager.deploy_strategy(
            self._get_strategy_individual(test.strategy_a_id),
            f"{test_id}_A"
        )
        
        deployment_b = await self.deployment_manager.deploy_strategy(
            self._get_strategy_individual(test.strategy_b_id),
            f"{test_id}_B"
        )
        
        # Store deployment IDs
        test.results = {
            'deployment_a': deployment_a,
            'deployment_b': deployment_b,
            'start_time': test.start_time
        }
        
        logging.info(f"A/B test başlatıldı: {test_id}")
        
        # Schedule test end
        await asyncio.sleep(test.test_duration)
        await self.end_test(test_id)
    
    async def end_test(self, test_id: str):
        """Testi bitir"""
        if test_id not in self.tests:
            return
        
        test = self.tests[test_id]
        test.status = ABTestStatus.COMPLETED
        test.end_time = time.time()
        
        # Get results
        results = self._analyze_test_results(test)
        test.results = {**test.results, **results}
        
        # Undeploy strategies
        if test.results and 'deployment_a' in test.results:
            self.deployment_manager.undeploy_strategy(test.results['deployment_a'])
            self.deployment_manager.undeploy_strategy(test.results['deployment_b'])
        
        logging.info(f"A/B test tamamlandı: {test_id}")
    
    def _analyze_test_results(self, test: ABTest) -> Dict[str, Any]:
        """Test sonuçlarını analiz et"""
        if not test.results or 'deployment_a' not in test.results:
            return {}
        
        deployment_a = test.results['deployment_a']
        deployment_b = test.results['deployment_b']
        
        # Get performance data
        perf_a = self.deployment_manager.performance_history.get(deployment_a, [])
        perf_b = self.deployment_manager.performance_history.get(deployment_b, [])
        
        if not perf_a or not perf_b:
            return {'error': 'Insufficient data'}
        
        # Calculate metrics
        returns_a = [p['total_return'] for p in perf_a]
        returns_b = [p['total_return'] for p in perf_b]
        
        metrics_a = {
            'total_return': returns_a[-1] if returns_a else 0.0,
            'sharpe_ratio': np.mean(returns_a) / np.std(returns_a) if len(returns_a) > 1 else 0.0,
            'avg_return': np.mean(returns_a),
            'volatility': np.std(returns_a) if len(returns_a) > 1 else 0.0
        }
        
        metrics_b = {
            'total_return': returns_b[-1] if returns_b else 0.0,
            'sharpe_ratio': np.mean(returns_b) / np.std(returns_b) if len(returns_b) > 1 else 0.0,
            'avg_return': np.mean(returns_b),
            'volatility': np.std(returns_b) if len(returns_b) > 1 else 0.0
        }
        
        # Statistical significance test (simplified t-test)
        if len(returns_a) > 1 and len(returns_b) > 1:
            t_stat, p_value = self._t_test(returns_a, returns_b)
            is_significant = p_value < test.statistical_significance
        else:
            t_stat, p_value = 0.0, 1.0
            is_significant = False
        
        # Determine winner
        winner = 'A' if metrics_a['total_return'] > metrics_b['total_return'] else 'B'
        
        return {
            'metrics_a': metrics_a,
            'metrics_b': metrics_b,
            'statistical_significance': {
                't_statistic': t_stat,
                'p_value': p_value,
                'is_significant': is_significant
            },
            'winner': winner,
            'test_duration': test.end_time - test.start_time if test.end_time else 0
        }
    
    def _t_test(self, sample_a: List[float], sample_b: List[float]) -> Tuple[float, float]:
        """Basit t-test"""
        if len(sample_a) < 2 or len(sample_b) < 2:
            return 0.0, 1.0
        
        mean_a = np.mean(sample_a)
        mean_b = np.mean(sample_b)
        var_a = np.var(sample_a, ddof=1)
        var_b = np.var(sample_b, ddof=1)
        
        n_a = len(sample_a)
        n_b = len(sample_b)
        
        # Pooled standard error
        pooled_se = np.sqrt(var_a / n_a + var_b / n_b)
        
        if pooled_se == 0:
            return 0.0, 1.0
        
        # T-statistic
        t_stat = (mean_a - mean_b) / pooled_se
        
        # Degrees of freedom (Welch's t-test approximation)
        df = ((var_a / n_a + var_b / n_b) ** 2) / (
            (var_a / n_a) ** 2 / (n_a - 1) + (var_b / n_b) ** 2 / (n_b - 1)
        )
        
        # P-value approximation (simplified)
        p_value = 2 * (1 - self._t_cdf(abs(t_stat), df))
        
        return t_stat, p_value
    
    def _t_cdf(self, t: float, df: float) -> float:
        """T-distribution CDF approximation"""
        # Simplified approximation using normal distribution for large df
        if df > 30:
            return 0.5 * (1 + self._erf(t / np.sqrt(2)))
        
        # For small df, use a simple approximation
        return 0.5 + 0.3 * t / np.sqrt(df + t**2)
    
    def _erf(self, x: float) -> float:
        """Error function approximation"""
        # Abramowitz and Stegun approximation
        a1 =  0.254829592
        a2 = -0.284496736
        a3 =  1.421413741
        a4 = -1.453152027
        a5 =  1.061405429
        p  =  0.3275911
        
        sign = 1 if x >= 0 else -1
        x = abs(x)
        
        t = 1.0 / (1.0 + p * x)
        y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * np.exp(-x * x)
        
        return sign * y
    
    def _get_strategy_individual(self, strategy_id: str) -> Any:
        """Strateji bireyini getir (simplified)"""
        # In real implementation, this would retrieve from database
        return ['ADD', 'SUB', 'CLOSE', 'VOLUME', 'GT']
    
    def get_test_results(self, test_id: str) -> Optional[Dict[str, Any]]:
        """Test sonuçlarını getir"""
        if test_id not in self.tests:
            return None
        
        test = self.tests[test_id]
        return test.to_dict()


class RealTimeEngine:
    """Ana real-time engine"""
    
    def __init__(self):
        self.deployment_manager = DeploymentManager()
        self.ab_test_framework = ABTestFramework(self.deployment_manager)
        self.market_data_simulator = None
        
    async def start_market_simulation(self, symbol: str = "BTCUSDT"):
        """Piyasa simülasyonunu başlat"""
        self.market_data_simulator = asyncio.create_task(
            self.deployment_manager.stream_market_data(symbol)
        )
    
    def stop_market_simulation(self):
        """Piyasa simülasyonunu durdur"""
        if self.market_data_simulator:
            self.market_data_simulator.cancel()
    
    async def deploy_strategy(self, individual: Any, strategy_id: str) -> str:
        """Strateji dağıt"""
        return await self.deployment_manager.deploy_strategy(individual, strategy_id)
    
    async def create_ab_test(self, test_name: str, strategy_a_id: str, strategy_b_id: str,
                           test_duration: int = 86400, allocation_a: float = 0.5) -> str:
        """A/B test oluştur"""
        return await self.ab_test_framework.create_test(
            test_name, strategy_a_id, strategy_b_id, test_duration, allocation_a
        )
    
    async def start_ab_test(self, test_id: str):
        """A/B testi başlat"""
        await self.ab_test_framework.start_test(test_id)
    
    def get_status(self, deployment_id: str) -> Optional[Dict[str, Any]]:
        """Dağıtım durumunu getir"""
        return self.deployment_manager.get_deployment_status(deployment_id)
    
    def get_ab_test_results(self, test_id: str) -> Optional[Dict[str, Any]]:
        """A/B test sonuçlarını getir"""
        return self.ab_test_framework.get_test_results(test_id)