"""
Genetik Programlama Motoru - Test Dosyası
Bileşenlerin unit testleri
"""

import unittest
import numpy as np
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.primitives import PrimitiveSet, PrimitiveRegistry, MathOperators, TechnicalIndicators
from core.fitness import AdvancedFitnessCalculator, ProfitFitness, SharpeRatioFitness
from core.operators import GeneticOperatorsManager, TreeNode
from core.engine import EvolutionEngine, EvolutionConfig
from utils.test_data import (
    generate_sample_market_data, create_test_population, 
    create_test_individual, assert_fitness_bounds
)


class TestPrimitives(unittest.TestCase):
    """Primitive set testleri"""
    
    def setUp(self):
        self.primitive_set = PrimitiveSet()
        self.registry = PrimitiveRegistry()
    
    def test_primitive_set_initialization(self):
        """Primitive set başlatma testi"""
        self.assertIn('CLOSE', self.primitive_set.terminals)
        self.assertIn('ADD', self.primitive_set.functions)
        self.assertIn('SMA', self.primitive_set.functions)
    
    def test_math_operators(self):
        """Matematik operatör testleri"""
        # Addition
        result = MathOperators.add(5, 3)
        self.assertEqual(result, 8)
        
        # Multiplication
        result = MathOperators.mul(4, 6)
        self.assertEqual(result, 24)
        
        # Division with zero protection
        result = MathOperators.div(10, 0)
        np.testing.assert_array_equal(result, np.array([0]))
    
    def test_technical_indicators(self):
        """Teknik indikatör testleri"""
        # Simple moving average
        data = np.array([1, 2, 3, 4, 5])
        sma_func = TechnicalIndicators.sma(3)
        result = sma_func(data)
        
        expected = np.array([np.nan, np.nan, 2.0, 3.0, 4.0])
        np.testing.assert_array_equal(result, expected, equal_nan=True)
    
    def test_tree_node(self):
        """Tree node testleri"""
        # Create simple tree
        root = TreeNode('ADD')
        child1 = TreeNode('CLOSE')
        child2 = TreeNode('VOLUME')
        
        root.children = [child1, child2]
        
        # Test list conversion
        tree_list = root.to_list()
        self.assertEqual(tree_list, ['ADD', 'CLOSE', 'VOLUME'])
        
        # Test copy
        copied = root.copy()
        self.assertIsNot(copied, root)
        self.assertEqual(copied.to_list(), tree_list)


class TestFitness(unittest.TestCase):
    """Fitness fonksiyon testleri"""
    
    def setUp(self):
        self.fitness_calculator = AdvancedFitnessCalculator()
        self.test_data = generate_sample_market_data(n_periods=100)
    
    def test_profit_fitness(self):
        """Profit fitness testi"""
        profit_fitness = ProfitFitness()
        
        # Create simple signal
        signals = np.array([0, 1, 1, 0, -1, -1, 0])
        prices = np.array([100, 101, 102, 103, 104, 105, 106])
        
        fitness = profit_fitness.evaluate(signals, prices)
        assert_fitness_bounds(fitness)
        self.assertIsInstance(fitness, float)
    
    def test_sharpe_ratio_fitness(self):
        """Sharpe ratio fitness testi"""
        sharpe_fitness = SharpeRatioFitness()
        
        # Create returns
        returns = np.array([0.01, -0.005, 0.015, -0.002, 0.008])
        
        fitness = sharpe_fitness.evaluate(returns)
        self.assertIsInstance(fitness, float)
        self.assertGreaterEqual(fitness, -5.0)
        self.assertLessEqual(fitness, 5.0)
    
    def test_portfolio_metrics_calculation(self):
        """Portföy metrikleri hesaplama testi"""
        signals = np.random.random(len(self.test_data['close']))
        prices = self.test_data['close']
        
        metrics = self.fitness_calculator.calculate_portfolio_metrics(
            signals, prices
        )
        
        self.assertIsInstance(metrics.total_return, float)
        self.assertIsInstance(metrics.sharpe_ratio, float)
        self.assertIsInstance(metrics.max_drawdown, float)
        
        # Check bounds
        self.assertGreaterEqual(metrics.win_rate, 0.0)
        self.assertLessEqual(metrics.win_rate, 1.0)
        self.assertGreaterEqual(metrics.max_drawdown, 0.0)
    
    def test_edge_cases(self):
        """Edge case testleri"""
        # Empty arrays
        with self.assertRaises(ValueError):
            self.fitness_calculator.evaluate(np.array([]), np.array([]))
        
        # Length mismatch
        with self.assertRaises(ValueError):
            self.fitness_calculator.evaluate(
                np.array([1, 2, 3]), 
                np.array([100, 101])
            )
        
        # All zeros signals
        signals = np.zeros(50)
        prices = np.random.random(50) * 100 + 100
        fitness = self.fitness_calculator.evaluate(signals, prices)
        self.assertIsInstance(fitness, float)


class TestGeneticOperators(unittest.TestCase):
    """Genetik operatör testleri"""
    
    def setUp(self):
        # Create mock toolbox
        from deap import base
        self.toolbox = base.Toolbox()
        self.toolbox.register("expr", lambda pset, min_, max_: ['ADD', 'CLOSE', 'VOLUME'])
        
        self.operators_manager = GeneticOperatorsManager(
            self.toolbox, 
            {'max_depth': 5, 'crossover_prob': 0.8, 'mutation_prob': 0.1}
        )
    
    def test_crossover(self):
        """Çaprazlama testi"""
        parent1 = ['ADD', 'CLOSE', 'VOLUME']
        parent2 = ['SUB', 'HIGH', 'LOW']
        
        child1, child2 = self.operators_manager.crossover(parent1, parent2, 'uniform')
        
        # Children should be different lengths or content
        self.assertTrue(
            len(child1) != len(parent1) or 
            len(child2) != len(parent2) or
            child1 != parent1 or child2 != parent2
        )
    
    def test_mutation(self):
        """Mutasyon testi"""
        individual = ['ADD', 'CLOSE', 'VOLUME']
        
        mutated = self.operators_manager.mutate(individual, 'advanced')[0]
        
        # Should either stay the same or be mutated
        self.assertTrue(mutated == individual or mutated != individual)
    
    def test_selection(self):
        """Seçim testi"""
        population = [
            ['ADD', 'CLOSE', 'VOLUME'],
            ['SUB', 'HIGH', 'LOW'],
            ['MUL', 'OPEN', 'CLOSE']
        ]
        
        fitnesses = [0.8, 0.6, 0.9]
        
        selected = self.operators_manager.select(population, fitnesses, 2, 'tournament')
        
        self.assertEqual(len(selected), 2)
        # Should select individuals with higher fitness (simplified)


class TestEvolutionEngine(unittest.TestCase):
    """Evolution engine testleri"""
    
    def setUp(self):
        config = EvolutionConfig(
            population_size=10,
            generations=5,
            max_depth=5
        )
        self.engine = EvolutionEngine(config)
        self.test_data = generate_sample_market_data(n_periods=100)
    
    def test_engine_initialization(self):
        """Engine başlatma testi"""
        self.assertIsNotNone(self.engine.population)
        self.assertIsInstance(self.engine.fitness_calculator, AdvancedFitnessCalculator)
        self.assertIsInstance(self.engine.operators_manager, GeneticOperatorsManager)
    
    def test_evolution_run(self):
        """Evolution run testi"""
        # Short evolution run
        stats = self.engine.run_evolution(self.test_data, checkpoint_interval=3)
        
        self.assertGreater(len(stats), 0)
        
        # Check stats structure
        for stat in stats:
            self.assertIsInstance(stat.generation, int)
            self.assertIsInstance(stat.best_fitness, float)
            self.assertIsInstance(stat.diversity, float)
        
        # Check that fitness improves over time (at least doesn't decrease much)
        if len(stats) > 1:
            fitness_improvement = stats[-1].best_fitness - stats[0].best_fitness
            # Allow for some randomness, but should not decrease dramatically
            self.assertGreater(fitness_improvement, -2.0)
    
    def test_checkpoint_operations(self):
        """Checkpoint işlemleri testi"""
        # Save checkpoint
        checkpoint_file = "/tmp/test_checkpoint"
        self.engine.save_checkpoint(checkpoint_file)
        
        # Check file was created
        self.assertTrue(os.path.exists(f"{checkpoint_file}.pkl"))
        
        # Load checkpoint
        self.engine.load_checkpoint(f"{checkpoint_file}.pkl")
        
        # Clean up
        os.remove(f"{checkpoint_file}.pkl")
    
    def test_strategy_export(self):
        """Strateji export testi"""
        # Create some test results
        if len(self.engine.hall_of_fame) == 0:
            # Create a dummy individual for testing
            test_individual = ['ADD', 'CLOSE', 'VOLUME']
            test_individual.fitness.values = (0.5,)
            self.engine.hall_of_fame.update([test_individual])
        
        # Export strategies
        export_file = "/tmp/test_strategies"
        self.engine.export_strategies(export_file, format='json')
        
        # Check file was created
        self.assertTrue(os.path.exists(f"{export_file}.json"))
        
        # Clean up
        os.remove(f"{export_file}.json")


class TestIntegration(unittest.TestCase):
    """Entegrasyon testleri"""
    
    def test_full_workflow(self):
        """Tam iş akışı testi"""
        # 1. Generate test data
        test_data = generate_sample_market_data(n_periods=200)
        
        # 2. Create engine
        config = EvolutionConfig(
            population_size=20,
            generations=3,
            max_depth=5
        )
        engine = EvolutionEngine(config)
        
        # 3. Run evolution
        stats = engine.run_evolution(test_data)
        
        # 4. Check results
        self.assertGreater(len(stats), 0)
        
        # 5. Test deployment if we have good individuals
        if len(engine.hall_of_fame) > 0:
            best_individual = engine.hall_of_fame[0]
            strategy_id = engine.deploy_strategy(best_individual, "test_strategy")
            
            self.assertIsInstance(strategy_id, str)
            self.assertIn(strategy_id, engine.active_strategies)
            
            # Test stop
            engine.stop_strategy(strategy_id)
    
    def test_multiple_assets(self):
        """Çoklu varlık testi"""
        from utils.test_data import generate_multiple_assets
        
        assets = generate_multiple_assets(n_assets=2, n_periods=100)
        
        self.assertEqual(len(assets), 2)
        self.assertIn('BTCUSDT', assets)
        self.assertIn('ETHUSDT', assets)
        
        # Check data structure
        for symbol, data in assets.items():
            required_keys = ['open', 'high', 'low', 'close', 'volume']
            for key in required_keys:
                self.assertIn(key, data)
                self.assertIsInstance(data[key], np.ndarray)


class TestPerformance(unittest.TestCase):
    """Performans testleri"""
    
    def test_fitness_calculation_speed(self):
        """Fitness hesaplama hız testi"""
        import time
        
        calculator = AdvancedFitnessCalculator()
        test_data = generate_sample_market_data(n_periods=1000)
        signals = np.random.random(len(test_data['close']))
        
        start_time = time.time()
        fitness = calculator.evaluate(signals, test_data['close'])
        end_time = time.time()
        
        calculation_time = end_time - start_time
        
        # Should complete within 1 second for 1000 periods
        self.assertLess(calculation_time, 1.0)
        self.assertIsInstance(fitness, float)
    
    def test_large_population_handling(self):
        """Büyük popülasyon işleme testi"""
        config = EvolutionConfig(
            population_size=100,
            generations=2,
            max_depth=3
        )
        engine = EvolutionEngine(config)
        test_data = generate_sample_market_data(n_periods=50)
        
        start_time = time.time()
        stats = engine.run_evolution(test_data)
        end_time = time.time()
        
        execution_time = end_time - start_time
        
        # Should complete within reasonable time
        self.assertLess(execution_time, 60.0)  # 60 seconds max
        self.assertGreater(len(stats), 0)


class TestEdgeCases(unittest.TestCase):
    """Edge case testleri"""
    
    def test_extreme_price_data(self):
        """Aşırı fiyat verisi testi"""
        # Very high volatility
        extreme_data = {
            'close': np.array([100, 200, 50, 300, 25, 400]),
            'volume': np.array([1000, 5000, 100, 10000, 50, 15000])
        }
        
        calculator = AdvancedFitnessCalculator()
        
        # Should not crash
        try:
            metrics = calculator.calculate_portfolio_metrics(
                np.array([1, -1, 1, -1, 1, -1]),
                extreme_data['close'],
                extreme_data['volume']
            )
            
            # All metrics should be valid numbers
            self.assertFalse(np.isnan(metrics.total_return))
            self.assertFalse(np.isnan(metrics.sharpe_ratio))
            
        except Exception as e:
            self.fail(f"Extreme data handling failed: {e}")
    
    def test_zero_and_negative_prices(self):
        """Sıfır ve negatif fiyat testi"""
        problematic_data = {
            'close': np.array([100, 0, 50, -10, 200, 0]),
            'volume': np.array([1000, 1100, 900, 1200, 800, 1300])
        }
        
        calculator = AdvancedFitnessCalculator()
        
        # Should handle gracefully
        signals = np.array([1, -1, 1, -1, 1, -1])
        
        try:
            metrics = calculator.calculate_portfolio_metrics(
                signals,
                problematic_data['close'],
                problematic_data['volume']
            )
            
            # Should return valid metrics even with problematic data
            self.assertIsInstance(metrics.total_return, float)
            
        except Exception as e:
            self.fail(f"Zero/negative price handling failed: {e}")
    
    def test_single_period_data(self):
        """Tek periyot veri testi"""
        minimal_data = {
            'close': np.array([100]),
            'volume': np.array([1000])
        }
        
        calculator = AdvancedFitnessCalculator()
        
        # Should handle single data point
        signals = np.array([1])
        
        try:
            metrics = calculator.calculate_portfolio_metrics(
                signals,
                minimal_data['close'],
                minimal_data['volume']
            )
            
            self.assertIsInstance(metrics.total_return, float)
            
        except Exception as e:
            self.fail(f"Single period data handling failed: {e}")


def run_performance_benchmark():
    """Performans benchmark'ı çalıştır"""
    print("Running performance benchmarks...")
    
    # Test different population sizes
    population_sizes = [10, 50, 100]
    
    for pop_size in population_sizes:
        print(f"\nTesting population size: {pop_size}")
        
        config = EvolutionConfig(
            population_size=pop_size,
            generations=3,
            max_depth=5
        )
        
        engine = EvolutionEngine(config)
        test_data = generate_sample_market_data(n_periods=200)
        
        import time
        start_time = time.time()
        
        stats = engine.run_evolution(test_data)
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        print(f"  Execution time: {execution_time:.2f} seconds")
        print(f"  Generations completed: {len(stats)}")
        print(f"  Best fitness: {stats[-1].best_fitness:.4f}" if stats else "  No stats")
        
        # Benchmark criteria
        if pop_size <= 10:
            max_time = 30
        elif pop_size <= 50:
            max_time = 120
        else:
            max_time = 300
        
        if execution_time > max_time:
            print(f"  ⚠️  SLOW: Exceeded expected time ({max_time}s)")
        else:
            print(f"  ✅ PASS: Within time limit")


if __name__ == '__main__':
    # Set up logging for tests
    import logging
    logging.basicConfig(level=logging.WARNING)  # Reduce noise during tests
    
    # Run unit tests
    unittest.main(verbosity=2, exit=False)
    
    # Run performance benchmarks
    print("\n" + "="*50)
    print("PERFORMANCE BENCHMARKS")
    print("="*50)
    run_performance_benchmark()