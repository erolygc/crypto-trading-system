"""Tests modülü - Test dosyaları"""

# Test suite configuration
TEST_CONFIG = {
    'verbose': True,
    'parallel': False,
    'coverage': False,
    'benchmark': True
}

# Test data paths
TEST_DATA_PATHS = {
    'sample_market_data': 'data/sample_market_data.npz',
    'backtest_data': 'data/backtest_data.csv',
    'test_config': 'config/test_config.json'
}

def run_all_tests():
    """Tüm testleri çalıştır"""
    import unittest
    import sys
    
    # Discover and run tests
    loader = unittest.TestLoader()
    suite = loader.discover('.', pattern='test_*.py')
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    return result.wasSuccessful()

def run_benchmarks():
    """Benchmark testlerini çalıştır"""
    print("Running performance benchmarks...")
    
    # Import and run benchmark
    from test_engine import run_performance_benchmark
    run_performance_benchmark()

__all__ = [
    'TEST_CONFIG',
    'TEST_DATA_PATHS', 
    'run_all_tests',
    'run_benchmarks'
]