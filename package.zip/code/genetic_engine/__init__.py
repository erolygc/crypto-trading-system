"""
Genetik Programlama Motoru - Ana Paket
Bu modül DEAP tabanlı genetik programlama motorunu içerir.
"""

__version__ = "1.0.0"
__author__ = "Bitwisers Team"
__email__ = "team@bitwisers.com"

from .core.primitives import PrimitiveSet, primitive_registry, Primitive, Terminal, Function
from .core.fitness import (
    AdvancedFitnessCalculator, 
    ProfitFitness, 
    SharpeRatioFitness, 
    SortinoRatioFitness,
    create_fitness_calculator
)
from .core.operators import GeneticOperatorsManager, TreeNode, create_toolbox
from .core.engine import EvolutionEngine, EvolutionConfig, create_engine
from .core.realtime import RealTimeEngine, DeploymentManager, ABTestFramework

# Public API
__all__ = [
    'EvolutionEngine',
    'EvolutionConfig', 
    'AdvancedFitnessCalculator',
    'PrimitiveSet',
    'GeneticOperatorsManager',
    'RealTimeEngine',
    'DeploymentManager',
    'ABTestFramework',
    'create_engine',
    'create_fitness_calculator',
    'create_toolbox',
    'primitive_registry'
]

# Version info
VERSION_INFO = {
    'major': 1,
    'minor': 0,
    'patch': 0,
    'release': 'stable'
}

def get_version():
    """Versiyon bilgisini getir"""
    return __version__

def get_version_info():
    """Detaylı versiyon bilgisini getir"""
    return VERSION_INFO.copy()

def check_dependencies():
    """Bağımlılıkları kontrol et"""
    missing_deps = []
    
    try:
        import deap
    except ImportError:
        missing_deps.append('deap')
    
    try:
        import numpy
    except ImportError:
        missing_deps.append('numpy')
    
    try:
        import pandas
    except ImportError:
        missing_deps.append('pandas')
    
    try:
        import cupy
        has_gpu = True
    except ImportError:
        has_gpu = False
    
    return {
        'all_deps_available': len(missing_deps) == 0,
        'missing_dependencies': missing_deps,
        'gpu_available': has_gpu
    }

def initialize_engine(config=None):
    """Engine'i başlat (convenience function)"""
    if config is None:
        from .core.engine import DEFAULT_ENGINE_CONFIG
        config = DEFAULT_ENGINE_CONFIG
    
    return create_engine(config)

# Auto-initialization check
def _check_system_requirements():
    """Sistem gereksinimlerini kontrol et"""
    dep_status = check_dependencies()
    
    if not dep_status['all_deps_available']:
        print(f"⚠️  Warning: Missing dependencies: {', '.join(dep_status['missing_dependencies'])}")
        print("   Please install missing packages: pip install deap numpy pandas")
    
    if not dep_status['gpu_available']:
        print("ℹ️  Info: GPU acceleration not available. Install CuPy for GPU support:")
        print("   pip install cupy-cuda11x")
    else:
        print("✅ GPU acceleration available")
    
    return dep_status

# Run system check on import
_check_system_requirements()