#!/usr/bin/env python3
"""
Genetik Programlama Motoru - Ana Çalıştırma Dosyası
DEAP tabanlı genetic programming engine'in ana giriş noktası
"""

import asyncio
import numpy as np
import sys
import os
import argparse
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from genetic_engine import (
    initialize_engine, 
    check_dependencies,
    EvolutionConfig,
    EvolutionEngine,
    RealTimeEngine
)
from genetic_engine.utils.test_data import (
    generate_sample_market_data,
    run_integration_test,
    setup_test_environment,
    cleanup_test_environment
)


def print_banner():
    """Banner yazdır"""
    banner = """
╔══════════════════════════════════════════════════════════════════╗
║                 GENETIC PROGRAMMING ENGINE                       ║
║                    DEAP-Based Trading Bot                        ║
║                      Version 1.0.0                              ║
║                   Bitwisers Trading Team                        ║
╚══════════════════════════════════════════════════════════════════╝
"""
    print(banner)


def check_system():
    """Sistem gereksinimlerini kontrol et"""
    print("🔍 Sistem kontrolü başlatılıyor...")
    
    status = check_dependencies()
    
    if status['all_deps_available']:
        print("✅ Tüm bağımlılıklar yüklü")
    else:
        print(f"⚠️  Eksik bağımlılıklar: {', '.join(status['missing_dependencies'])}")
        print("   pip install deap numpy pandas scikit-learn")
    
    if status['gpu_available']:
        print("✅ GPU hızlandırma aktif")
    else:
        print("ℹ️  GPU hızlandırma mevcut değil")
        print("   pip install cupy-cuda11x (CUDA 11.x için)")
    
    print()


def run_basic_example():
    """Temel örnek çalıştır"""
    print("🚀 Temel örnek çalıştırılıyor...")
    
    # Konfigürasyon
    config = EvolutionConfig(
        population_size=100,  # Test için küçük
        generations=10,       # Hızlı test
        max_depth=5
    )
    
    # Engine oluştur
    engine = initialize_engine(config)
    
    # Test verisi
    print("📊 Test verisi oluşturuluyor...")
    test_data = generate_sample_market_data(n_periods=500)
    
    # Evolution başlat
    print("🧬 Evolution başlatılıyor...")
    stats = engine.run_evolution(test_data, checkpoint_interval=5)
    
    # Sonuçları göster
    print(f"\n📈 EVOLUTION SONUÇLARI:")
    print(f"   Toplam Nesil: {len(stats)}")
    print(f"   En İyi Fitness: {stats[-1].best_fitness:.4f}")
    print(f"   Ortalama Fitness: {stats[-1].avg_fitness:.4f}")
    print(f"   Çeşitlilik: {stats[-1].diversity:.4f}")
    
    # En iyi stratejileri al
    best_strategies = engine.get_best_strategies(count=3)
    
    print(f"\n🏆 EN İYİ 3 STRATEJİ:")
    for i, strategy in enumerate(best_strategies, 1):
        print(f"   {i}. Fitness: {strategy.fitness:.4f}")
        print(f"      Total Return: {strategy.metrics['total_return']:.4f}")
        print(f"      Sharpe Ratio: {strategy.metrics['sharpe_ratio']:.4f}")
        print(f"      Max Drawdown: {strategy.metrics['max_drawdown']:.4f}")
    
    return engine, best_strategies


async def run_realtime_example(best_strategies):
    """Real-time örnek çalıştır"""
    print("\n⚡ Real-time deployment örneği...")
    
    rt_engine = RealTimeEngine()
    
    try:
        # Piyasa simülasyonu başlat
        print("📡 Piyasa simülasyonu başlatılıyor...")
        await rt_engine.start_market_simulation("BTCUSDT")
        
        # İlk stratejiyi dağıt
        if best_strategies:
            strategy = best_strategies[0]
            deployment_id = await rt_engine.deploy_strategy(
                individual=strategy.individual,
                strategy_id="demo_strategy"
            )
            
            print(f"🎯 Strateji dağıtıldı: {deployment_id}")
            
            # 30 saniye izle
            print("⏱️  30 saniye performans izlemesi...")
            await asyncio.sleep(30)
            
            # Durum sorgulama
            status = rt_engine.get_status(deployment_id)
            if status:
                print(f"📊 Deployment Durumu:")
                print(f"   Status: {status['status']}")
                if 'performance_metrics' in status:
                    metrics = status['performance_metrics']
                    print(f"   Total Return: {metrics.get('total_return', 0):.4f}")
                    print(f"   Position: {metrics.get('position', 0):.2f}")
                    print(f"   Cash: ${metrics.get('cash', 0):.2f}")
        
        print("✅ Real-time örnek tamamlandı")
        
    except Exception as e:
        print(f"❌ Real-time örnek hatası: {e}")
    finally:
        rt_engine.stop_market_simulation()


def run_ab_test_example():
    """A/B test örneği çalıştır"""
    print("\n🧪 A/B test örneği...")
    
    # Demo stratejiler
    strategy_a = ['GT', ['SMA', 'CLOSE', 20], ['EMA', 'CLOSE', 10]]
    strategy_b = ['AND', ['GT', 'RSI', 70], ['LT', 'VOLUME', 1000000]]
    
    print("📋 A/B test planlanıyor...")
    print("   Strateji A: SMA vs EMA crossover")
    print("   Strateji B: RSI + Volume filter")
    print("   Süre: 60 saniye (demo)")
    print("   Dağılım: %60 A, %40 B")
    
    # Real-time engine kullanarak A/B test simülasyonu
    # Bu gerçek trading ortamında çalışır
    print("ℹ️  A/B test demo modunda - gerçek deployment için")
    print("   await rt_engine.create_ab_test(...) kullanın")


def run_performance_test():
    """Performans testi çalıştır"""
    print("\n⚡ Performans testi...")
    
    # Test ortamı
    test_env = setup_test_environment()
    
    try:
        config = EvolutionConfig(
            population_size=50,  # Hızlı test
            generations=5,
            max_depth=5
        )
        
        engine = initialize_engine(config)
        test_data = generate_sample_market_data(n_periods=200)
        
        print("🏃 Performans benchmark başlatılıyor...")
        
        import time
        start_time = time.time()
        
        stats = run_integration_test(engine)
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        print(f"⏱️  Toplam Süre: {execution_time:.2f} saniye")
        
        if stats['evolution_success']:
            print("✅ Evolution başarılı")
            print(f"   Nesiller: {stats['generations_completed']}")
            print(f"   En İyi Fitness: {stats.get('best_fitness', 0):.4f}")
        else:
            print("❌ Evolution başarısız")
        
        if stats.get('fitness_calculation_success'):
            print("✅ Fitness hesaplama başarılı")
        else:
            print("❌ Fitness hesaplama hatası")
        
    except Exception as e:
        print(f"❌ Performans testi hatası: {e}")
    
    finally:
        cleanup_test_environment(test_env)


def run_large_scale_test():
    """Büyük ölçekli test çalıştır (10K popülasyon, 100 nesil)"""
    print("\n🚀 BÜYÜK ÖLÇEKLI TEST BAŞLATILIYOR")
    print("="*50)
    print("📊 Konfigürasyon:")
    print("   • Popülasyon: 10,000")
    print("   • Nesil: 100")
    print("   • Max Depth: 6")
    print("   • Veri Boyutu: 2000 bar")
    print("="*50)
    
    # Büyük konfigürasyon
    config = EvolutionConfig(
        population_size=10000,
        generations=100,
        max_depth=6,
        checkpoint_interval=10  # Her 10 nesilde checkpoint
    )
    
    # Engine oluştur
    print("🔧 Engine başlatılıyor...")
    engine = initialize_engine(config)
    
    # Gerçekçi market verisi
    print("📈 Gerçekçi market verisi oluşturuluyor...")
    test_data = generate_sample_market_data(n_periods=2000, 
                                          volatility=0.02,
                                          trend_strength=0.1)
    
    print(f"📊 Veri Özellikleri:")
    print(f"   • Periyot Sayısı: {len(test_data['close'])}")
    print(f"   • Fiyat Aralığı: ${test_data['close'].min():.2f} - ${test_data['close'].max():.2f}")
    print(f"   • Ortalama Hacim: {test_data['volume'].mean():.0f}")
    
    # Evolution başlat
    print("\n🧬 Evolution başlatılıyor...")
    print("⏱️  Bu işlem biraz zaman alabilir (GPU'da hızlı, CPU'da yavaş)")
    
    import time
    start_time = time.time()
    
    try:
        stats = engine.run_evolution(test_data)
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        # Detaylı sonuçlar
        print(f"\n" + "="*50)
        print(f"📊 BÜYÜK ÖLÇEKLI TEST SONUÇLARI")
        print(f"="*50)
        print(f"⏱️  Toplam Süre: {execution_time:.2f} saniye ({execution_time/60:.1f} dakika)")
        print(f"🔄 Tamamlanan Nesil: {len(stats)}")
        print(f"🏆 En İyi Fitness: {stats[-1].best_fitness:.6f}")
        print(f"📊 Ortalama Fitness: {stats[-1].avg_fitness:.6f}")
        print(f"🌟 Çeşitlilik: {stats[-1].diversity:.6f}")
        
        # En iyi 10 strateji
        print(f"\n🏆 EN İYİ 10 STRATEJİ:")
        print("="*50)
        
        best_strategies = engine.get_best_strategies(count=10)
        
        for i, strategy in enumerate(best_strategies, 1):
            print(f"\n{i}. STRATEJİ DETAYLARI:")
            print(f"   📈 Fitness Skoru: {strategy.fitness:.6f}")
            print(f"   💰 Total Return: {strategy.metrics['total_return']:.4f} (%{strategy.metrics['total_return']*100:.2f})")
            print(f"   ⚡ Sharpe Ratio: {strategy.metrics['sharpe_ratio']:.4f}")
            print(f"   📉 Max Drawdown: {strategy.metrics['max_drawdown']:.4f} (%{strategy.metrics['max_drawdown']*100:.2f})")
            print(f"   🎯 Win Rate: {strategy.metrics['win_rate']:.4f} (%{strategy.metrics['win_rate']*100:.1f})")
            print(f"   🔄 Total Trades: {strategy.metrics['total_trades']}")
            print(f"   🌳 Ağaç Derinliği: {strategy.depth}")
            print(f"   📝 Strateji Kodu: {strategy.individual}")
        
        # Evolution progress analizi
        print(f"\n📊 EVOLUTION PROGRESS ANALİZİ:")
        print("="*50)
        
        fitness_improvements = []
        for i in range(1, len(stats)):
            improvement = stats[i].best_fitness - stats[i-1].best_fitness
            fitness_improvements.append(improvement)
        
        avg_improvement = np.mean(fitness_improvements) if fitness_improvements else 0
        max_improvement = max(fitness_improvements) if fitness_improvements else 0
        
        print(f"📈 Ortalama İyileşme/Nesil: {avg_improvement:.6f}")
        print(f"🚀 Maksimum İyileşme: {max_improvement:.6f}")
        print(f"🔄 Stabil Nesiller: {len([x for x in fitness_improvements if abs(x) < 1e-6])}")
        
        # Performans metrikleri
        print(f"\n⚡ PERFORMANS METRİKLERİ:")
        print("="*30)
        time_per_generation = execution_time / len(stats) if len(stats) > 0 else 0
        print(f"⏱️  Ortalama Süre/Nesil: {time_per_generation:.2f} saniye")
        print(f"🎯 Popülasyon/Nesil: {config.population_size:,}")
        print(f"📊 Toplam Değerlendirme: {config.population_size * len(stats):,}")
        
        if execution_time > 60:
            print(f"💡 İpuçlar:")
            if execution_time > 300:
                print(f"   • GPU kullanımı önerilir (şu anda CPU)")
            print(f"   • checkpoint_interval artırılabilir")
            print(f"   • Popülasyon azaltılabilir")
        
        print(f"\n✅ BÜYÜK ÖLÇEKLI TEST BAŞARIYLA TAMAMLANDI!")
        return engine, best_strategies, stats
        
    except Exception as e:
        print(f"\n❌ Test hatası: {e}")
        import traceback
        traceback.print_exc()
        return None, None, None


def run_stress_test():
    """Stres testi çalıştır"""
    print("\n💪 Stres testi...")
    
    # Edge case verileri
    test_cases = [
        ("Missing Data", {"close": np.array([100, np.nan, 102]), 
                         "volume": np.array([1000, 1100, 900])}),
        ("Zero Volume", {"close": np.array([100, 101, 102]), 
                        "volume": np.array([0, 0, 0])}),
        ("Extreme Volatility", {"close": np.array([100, 200, 50, 300]), 
                               "volume": np.array([1000, 5000, 100, 10000])})
    ]
    
    config = EvolutionConfig(
        population_size=10,
        generations=3,
        max_depth=3
    )
    
    for test_name, test_data in test_cases:
        try:
            print(f"🧪 Test: {test_name}")
            
            engine = initialize_engine(config)
            
            # NaN değerleri sıfırla
            clean_data = {}
            for key, values in test_data.items():
                if isinstance(values, np.ndarray):
                    clean_data[key] = np.nan_to_num(values, nan=0.0, posinf=1000.0, neginf=-1000.0)
                else:
                    clean_data[key] = values
            
            stats = engine.run_evolution(clean_data)
            
            if stats and stats[-1].best_fitness != np.nan:
                print(f"   ✅ Başarılı - Fitness: {stats[-1].best_fitness:.4f}")
            else:
                print(f"   ⚠️  Uyarı - Fitness hesaplanamadı")
                
        except Exception as e:
            print(f"   ❌ Hata: {e}")


def interactive_menu():
    """İnteraktif menü"""
    while True:
        print("\n" + "="*50)
        print("🎯 GENETIC PROGRAMMING ENGINE - ANA MENÜ")
        print("="*50)
        print("1. 🚀 Temel Örnek")
        print("2. 🔥 BÜYÜK ÖLÇEK TEST (10K Pop, 100 Nesil)")
        print("3. ⚡ Real-time Deployment")
        print("4. 🧪 A/B Test Demo")
        print("5. ⚡ Performans Testi") 
        print("6. 💪 Stres Testi")
        print("7. 🔍 Sistem Kontrolü")
        print("8. ❌ Çıkış")
        print("="*50)
        
        try:
            choice = input("\nSeçiminizi yapın (1-8): ").strip()
            
            if choice == '1':
                engine, strategies = run_basic_example()
            elif choice == '2':
                print("🔥 BÜYÜK ÖLÇEK TEST - Bu seçim biraz zaman alabilir!")
                confirm = input("Devam etmek istediğinizden emin misiniz? (y/n): ")
                if confirm.lower() == 'y':
                    engine, strategies, stats = run_large_scale_test()
                else:
                    print("İptal edildi.")
                    continue
            elif choice == '3':
                print("⚡ Real-time için önce temel örneği çalıştırın!")
                continue
            elif choice == '4':
                run_ab_test_example()
            elif choice == '5':
                run_performance_test()
            elif choice == '6':
                run_stress_test()
            elif choice == '7':
                check_system()
            elif choice == '8':
                print("👋 Görüşürüz!")
                break
            else:
                print("❌ Geçersiz seçim!")
                continue
                
        except KeyboardInterrupt:
            print("\n\n👋 Çıkış...")
            break
        except Exception as e:
            print(f"❌ Hata: {e}")
            continue


def main():
    """Ana fonksiyon"""
    parser = argparse.ArgumentParser(
        description="Genetik Programlama Motoru - DEAP Tabanlı Trading Engine",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Örnekler:
  python main.py                    # İnteraktif menü
  python main.py --example basic    # Temel örnek
  python main.py --example realtime # Real-time demo
  python main.py --benchmark        # Performans testi
  python main.py --stress-test      # Stres testi
        """
    )
    
    parser.add_argument('--example', choices=['basic', 'realtime'], 
                       help='Örnek çalıştır')
    parser.add_argument('--benchmark', action='store_true',
                       help='Performans benchmark')
    parser.add_argument('--stress-test', action='store_true',
                       help='Stres testi')
    parser.add_argument('--system-check', action='store_true',
                       help='Sistem kontrolü')
    parser.add_argument('--config', type=str,
                       help='Yapılandırma dosyası')
    
    args = parser.parse_args()
    
    # Banner
    print_banner()
    
    # Sistem kontrolü
    check_system()
    
    # Argümanlara göre çalıştır
    try:
        if args.example == 'basic':
            engine, strategies = run_basic_example()
            
            # Real-time demo sor
            response = input("\nReal-time demo çalıştırmak ister misiniz? (y/n): ")
            if response.lower() == 'y':
                asyncio.run(run_realtime_example(strategies))
                
        elif args.example == 'realtime':
            engine, strategies = run_basic_example()
            asyncio.run(run_realtime_example(strategies))
            
        elif args.benchmark:
            run_performance_test()
            
        elif args.stress_test:
            run_stress_test()
            
        elif args.system_check:
            pass  # Zaten yukarıda yapıldı
            
        else:
            # İnteraktif menü
            interactive_menu()
            
    except KeyboardInterrupt:
        print("\n👋 Program sonlandırıldı")
    except Exception as e:
        print(f"\n❌ Kritik hata: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    # Fast test mode - direkt genetic evaluation test
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--test":
        print("🧪 GENETIC PROGRAM EVALUATION TEST")
        print("=" * 40)
        
        # Test data
        import numpy as np
        test_data = {
            'close': np.random.random(50) * 100 + 50,
            'open': np.random.random(50) * 100 + 50,
            'high': np.random.random(50) * 100 + 55,
            'low': np.random.random(50) * 100 + 45,
            'volume': np.random.randint(1000, 10000, 50)
        }
        
        print(f"✅ Test data created: {len(test_data['close'])} periods")
        
        # Create engine
        from core.engine import EvolutionEngine, EvolutionConfig
        config = EvolutionConfig(population_size=10, generations=2)
        engine = EvolutionEngine(config)
        print("✅ Engine created")
        
        # Test individual
        test_individual = [
            "GT",  # Greater than
            ["SMA", "CLOSE", 10],  # SMA(CLOSE, 10)
            ["SMA", "OPEN", 10]    # SMA(OPEN, 10)
        ]
        print(f"📊 Test individual: {test_individual}")
        
        # Test evaluation
        try:
            signals = engine.parallel_evaluator._evaluate_individual(test_individual, test_data)
            print(f"✅ Signals generated: {len(signals)} values")
            print(f"Signal range: [{np.min(signals):.3f}, {np.max(signals):.3f}]")
            
            # Test fitness
            fitness = engine._evaluate_individual(test_individual, test_data)
            print(f"🎯 Fitness değeri: {fitness[0]:.4f}")
            
            if fitness[0] > 0:
                print("🎉 SUCCESS: Gerçek fitness değerleri hesaplanıyor!")
            else:
                print("⚠️  Fitness hala 0 - daha detaylı debugging gerekli")
                
        except Exception as e:
            print(f"❌ Test error: {e}")
            import traceback
            traceback.print_exc()
            
        print("✅ Test completed")
        sys.exit(0)
    
    main()