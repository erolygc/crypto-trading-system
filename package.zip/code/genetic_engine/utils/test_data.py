"""
Genetik Programlama Motoru - Test Yardımcı Fonksiyonları
Bu modül test verileri ve yardımcı fonksiyonları içerir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional
import os
import tempfile
from datetime import datetime, timedelta


def generate_sample_market_data(n_periods: int = 1000, 
                               start_price: float = 100.0,
                               volatility: float = 0.02) -> Dict[str, np.ndarray]:
    """Örnek piyasa verisi oluştur"""
    np.random.seed(42)  # Reproducible results
    
    # Generate price data using geometric Brownian motion
    dt = 1/252  # Daily steps (252 trading days per year)
    prices = [start_price]
    
    for i in range(n_periods - 1):
        drift = 0.05 * dt  # 5% annual drift
        shock = np.random.normal(0, volatility * np.sqrt(dt))
        new_price = prices[-1] * np.exp(drift + shock)
        prices.append(max(new_price, 0.01))  # Prevent negative prices
    
    prices = np.array(prices)
    
    # Generate OHLCV data
    opens = np.roll(prices, 1)
    opens[0] = start_price
    
    # High and low prices with random intraday movements
    intraday_range = prices * 0.01  # 1% intraday range
    highs = prices + np.random.uniform(0, 1, len(prices)) * intraday_range
    lows = prices - np.random.uniform(0, 1, len(prices)) * intraday_range
    
    # Volume data
    base_volume = 1000000
    volumes = np.random.lognormal(np.log(base_volume), 0.5, len(prices))
    
    # Timestamps
    start_date = datetime(2023, 1, 1)
    timestamps = [start_date + timedelta(days=i) for i in range(n_periods)]
    
    return {
        'timestamp': np.array([t.timestamp() for t in timestamps]),
        'open': opens,
        'high': highs,
        'low': lows,
        'close': prices,
        'volume': volumes,
        'timestamps': timestamps
    }


def generate_multiple_assets(n_assets: int = 5, n_periods: int = 1000) -> Dict[str, Dict[str, np.ndarray]]:
    """Birden fazla varlık için piyasa verisi oluştur"""
    assets = {}
    symbols = ['BTCUSDT', 'ETHUSDT', 'ADAUSDT', 'DOTUSDT', 'LINKUSDT']
    
    for i in range(min(n_assets, len(symbols))):
        symbol = symbols[i]
        start_price = 50.0 * (i + 1)  # Different starting prices
        volatility = 0.02 + 0.01 * i  # Different volatilities
        
        assets[symbol] = generate_sample_market_data(
            n_periods, start_price, volatility
        )
    
    return assets


def create_test_population(size: int = 100) -> List[List[str]]:
    """Test popülasyonu oluştur"""
    # Basic genetic programs
    primitives = ['CLOSE', 'VOLUME', 'HIGH', 'LOW', 'SMA', 'EMA', 'RSI', 'ADD', 'SUB', 'MUL', 'DIV', 'GT', 'LT']
    
    population = []
    for _ in range(size):
        # Random tree with 3-10 nodes
        tree_size = np.random.randint(3, 10)
        tree = np.random.choice(primitives, tree_size).tolist()
        population.append(tree)
    
    return population


def create_test_individual() -> List[str]:
    """Test bireyi oluştur"""
    # Simple moving average crossover strategy
    return ['GT', ['SMA', 'CLOSE', 20], ['SMA', 'CLOSE', 50]]


def save_test_data(data: Dict[str, np.ndarray], filename: str):
    """Test verisini dosyaya kaydet"""
    np.savez_compressed(filename, **data)
    print(f"Test verisi kaydedildi: {filename}")


def load_test_data(filename: str) -> Dict[str, np.ndarray]:
    """Test verisini dosyadan yükle"""
    loaded_data = np.load(filename)
    return dict(loaded_data)


def create_backtest_data(symbol: str = "BTCUSDT", period: str = "1h") -> pd.DataFrame:
    """Backtest için DataFrame oluştur"""
    n_periods = 8760  # One year of hourly data
    
    # Generate realistic OHLCV data
    np.random.seed(42)
    
    # Start with base price
    base_price = 50000.0
    prices = [base_price]
    
    # Generate price series with trends and volatility
    for i in range(n_periods):
        # Add trend component
        trend = 0.0001 * np.sin(2 * np.pi * i / 168)  # Weekly cycle
        # Add random walk component
        volatility = 0.02
        random_change = np.random.normal(0, volatility / np.sqrt(24))  # Hourly volatility
        
        new_price = prices[-1] * (1 + trend + random_change)
        prices.append(max(new_price, 100))  # Minimum price floor
    
    prices = np.array(prices[1:])  # Remove initial price
    
    # Generate OHLC from close prices
    opens = np.roll(prices, 1)
    opens[0] = base_price
    
    # High and low prices with intraday volatility
    intraday_volatility = 0.005
    highs = prices + np.random.uniform(0, 1, len(prices)) * prices * intraday_volatility
    lows = prices - np.random.uniform(0, 1, len(prices)) * prices * intraday_volatility
    
    # Generate volumes with realistic patterns
    base_volume = 1000
    volume_trend = 1 + 0.5 * np.sin(2 * np.pi * np.arange(len(prices)) / 24)  # Daily volume pattern
    volumes = np.random.lognormal(np.log(base_volume), 0.5, len(prices)) * volume_trend
    
    # Create timestamp index
    start_date = pd.Timestamp('2023-01-01')
    timestamps = pd.date_range(start=start_date, periods=len(prices), freq=period)
    
    # Create DataFrame
    df = pd.DataFrame({
        'timestamp': timestamps,
        'symbol': symbol,
        'open': opens,
        'high': highs,
        'low': lows,
        'close': prices,
        'volume': volumes
    })
    
    df.set_index('timestamp', inplace=True)
    
    return df


def calculate_expected_metrics() -> Dict[str, float]:
    """Beklenen test metrikleri"""
    return {
        'total_return': 0.15,  # 15% annual return expectation
        'sharpe_ratio': 1.2,   # Good risk-adjusted return
        'max_drawdown': 0.08,  # 8% maximum drawdown
        'win_rate': 0.55,      # 55% win rate
        'profit_factor': 1.3,  # 1.3 profit factor
        'volatility': 0.18     # 18% annual volatility
    }


def assert_fitness_bounds(fitness: float, min_val: float = -10.0, max_val: float = 10.0):
    """Fitness değeri sınır kontrolü"""
    assert -10.0 <= fitness <= 10.0, f"Fitness değeri sınır dışında: {fitness}"


def assert_positive_returns(returns: np.ndarray):
    """Pozitif getiri kontrolü"""
    assert len(returns) > 0, "Returns array boş"
    assert not np.any(np.isnan(returns)), "Returns array'inde NaN değerler var"
    assert not np.any(np.isinf(returns)), "Returns array'inde sonsuz değerler var"


def create_market_data_with_patterns(pattern: str = 'trending') -> Dict[str, np.ndarray]:
    """Belirli pattern'lere sahip piyasa verisi oluştur"""
    n_periods = 1000
    start_price = 100.0
    
    if pattern == 'trending':
        # Strong upward trend with noise
        trend = np.linspace(0, 0.5, n_periods)  # 50% trend
        noise = np.random.normal(0, 0.02, n_periods)
        prices = start_price * (1 + trend + noise)
        
    elif pattern == 'sideways':
        # Sideways market with mean reversion
        prices = [start_price]
        for i in range(n_periods - 1):
            # Mean reversion
            deviation = prices[-1] - start_price
            reversion = -0.1 * deviation
            noise = np.random.normal(0, 0.01)
            new_price = prices[-1] + reversion + noise
            prices.append(new_price)
        prices = np.array(prices)
        
    elif pattern == 'volatile':
        # High volatility market
        volatility = 0.05  # 5% per period
        returns = np.random.normal(0, volatility, n_periods)
        prices = start_price * np.cumprod(1 + returns)
        
    else:
        # Random walk (default)
        returns = np.random.normal(0, 0.02, n_periods)
        prices = start_price * np.cumprod(1 + returns)
    
    # Generate other OHLCV data
    opens = np.roll(prices, 1)
    opens[0] = start_price
    
    intraday_range = prices * 0.005
    highs = prices + np.random.uniform(0, 1, len(prices)) * intraday_range
    lows = prices - np.random.uniform(0, 1, len(prices)) * intraday_range
    
    base_volume = 100000
    volumes = np.random.lognormal(np.log(base_volume), 0.5, len(prices))
    
    start_date = datetime(2023, 1, 1)
    timestamps = [start_date + timedelta(days=i) for i in range(n_periods)]
    
    return {
        'timestamp': np.array([t.timestamp() for t in timestamps]),
        'open': opens,
        'high': highs,
        'low': lows,
        'close': prices,
        'volume': volumes,
        'timestamps': timestamps
    }


def benchmark_individual_complexity() -> List[Dict[str, Any]]:
    """Farklı karmaşıklıktaki bireyler için benchmark"""
    individuals = []
    
    # Simple individual
    individuals.append({
        'name': 'simple',
        'individual': ['ADD', 'CLOSE', 'VOLUME'],
        'complexity': 1,
        'expected_fitness_range': (-0.5, 0.5)
    })
    
    # Medium complexity
    individuals.append({
        'name': 'medium',
        'individual': ['GT', ['SMA', 'CLOSE', 20], ['EMA', 'CLOSE', 10]],
        'complexity': 3,
        'expected_fitness_range': (-1.0, 1.0)
    })
    
    # High complexity
    individuals.append({
        'name': 'complex',
        'individual': ['AND', ['GT', 'CLOSE', ['SMA', 'CLOSE', 20]], ['LT', 'RSI', 70]],
        'complexity': 5,
        'expected_fitness_range': (-2.0, 2.0)
    })
    
    return individuals


def create_stress_test_data() -> List[Dict[str, Any]]:
    """Stres test verisi oluştur"""
    stress_tests = []
    
    # Test 1: Missing data
    stress_tests.append({
        'name': 'missing_data',
        'data': {
            'close': np.array([100, np.nan, 102, 103, np.nan, 105]),
            'volume': np.array([1000, 1100, 900, 1200, 800, 1300])
        },
        'expected_behavior': 'Handle NaN values gracefully'
    })
    
    # Test 2: Extreme volatility
    stress_tests.append({
        'name': 'extreme_volatility',
        'data': {
            'close': np.array([100, 200, 50, 300, 75, 250]),
            'volume': np.array([1000, 5000, 800, 10000, 600, 8000])
        },
        'expected_behavior': 'Handle extreme price movements'
    })
    
    # Test 3: Zero volume
    stress_tests.append({
        'name': 'zero_volume',
        'data': {
            'close': np.array([100, 101, 102, 103, 104, 105]),
            'volume': np.array([0, 0, 0, 0, 0, 0])
        },
        'expected_behavior': 'Handle zero volume periods'
    })
    
    # Test 4: Very small dataset
    stress_tests.append({
        'name': 'small_dataset',
        'data': {
            'close': np.array([100, 101]),
            'volume': np.array([1000, 1100])
        },
        'expected_behavior': 'Handle very small datasets'
    })
    
    return stress_tests


def setup_test_environment():
    """Test ortamı kurulumu"""
    # Create temporary directory for test files
    temp_dir = tempfile.mkdtemp(prefix='genetic_engine_test_')
    
    # Create test data files
    test_data = generate_sample_market_data()
    test_data_file = os.path.join(temp_dir, 'test_data.npz')
    save_test_data(test_data, test_data_file)
    
    # Create backtest data
    backtest_data = create_backtest_data()
    backtest_file = os.path.join(temp_dir, 'backtest_data.csv')
    backtest_data.to_csv(backtest_file)
    
    return {
        'temp_dir': temp_dir,
        'test_data_file': test_data_file,
        'backtest_file': backtest_file
    }


def cleanup_test_environment(test_env: Dict[str, str]):
    """Test ortamı temizliği"""
    import shutil
    
    if os.path.exists(test_env['temp_dir']):
        shutil.rmtree(test_env['temp_dir'])


def run_integration_test(engine) -> Dict[str, Any]:
    """Entegrasyon testi"""
    results = {}
    
    try:
        # Test data
        test_data = generate_sample_market_data()
        
        # Run evolution (short run for testing)
        config = {
            'population_size': 10,
            'generations': 5,
            'max_depth': 5
        }
        
        # Run evolution
        stats = engine.run_evolution(test_data)
        results['evolution_success'] = True
        results['generations_completed'] = len(stats)
        results['best_fitness'] = stats[-1].best_fitness if stats else 0.0
        
        # Test deployment (simplified)
        if hasattr(engine, 'hall_of_fame') and len(engine.hall_of_fame) > 0:
            best_individual = engine.hall_of_fame[0]
            
            # Calculate performance
            try:
                from .fitness import AdvancedFitnessCalculator
                fitness_calc = AdvancedFitnessCalculator()
                signals = np.random.random(len(test_data['close']))
                fitness = fitness_calc.evaluate(signals, test_data['close'])
                
                results['deployment_success'] = True
                results['fitness_calculation_success'] = True
                results['calculated_fitness'] = fitness
                
            except Exception as e:
                results['deployment_success'] = False
                results['fitness_calculation_success'] = False
                results['fitness_error'] = str(e)
        
    except Exception as e:
        results['evolution_success'] = False
        results['error'] = str(e)
    
    return results


# Performance benchmarks
PERFORMANCE_BENCHMARKS = {
    'population_100': {
        'max_time_seconds': 30,
        'min_fitness': -1.0
    },
    'population_1000': {
        'max_time_seconds': 120,
        'min_fitness': -0.5
    },
    'population_10000': {
        'max_time_seconds': 600,
        'min_fitness': 0.0
    }
}


def validate_performance(results: Dict[str, Any], benchmark_name: str) -> Dict[str, Any]:
    """Performans doğrulama"""
    if benchmark_name not in PERFORMANCE_BENCHMARKS:
        return {'valid': False, 'error': 'Benchmark not found'}
    
    benchmark = PERFORMANCE_BENCHMARKS[benchmark_name]
    validation = {'valid': True, 'issues': []}
    
    # Check execution time
    if 'elapsed_time' in results:
        if results['elapsed_time'] > benchmark['max_time_seconds']:
            validation['valid'] = False
            validation['issues'].append(f"Execution time {results['elapsed_time']:.2f}s exceeds limit {benchmark['max_time_seconds']}s")
    
    # Check fitness
    if 'best_fitness' in results:
        if results['best_fitness'] < benchmark['min_fitness']:
            validation['issues'].append(f"Best fitness {results['best_fitness']:.4f} below minimum {benchmark['min_fitness']}")
    
    return validation