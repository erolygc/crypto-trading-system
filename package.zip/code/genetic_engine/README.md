# Genetik Programlama Motoru - DEAP Tabanlı Trading Bot

## 🚀 Özet

Bu proje DEAP (Distributed Evolutionary Algorithms in Python) framework'ünü kullanarak geliştirilmiş kapsamlı bir genetik programlama motorudur. Sistem otomatik olarak finansal trading stratejileri üretir ve bunları real-time ortamda deploy eder.

## 📁 Proje Yapısı

```
code/genetic_engine/
├── core/
│   ├── primitives.py      # Primitive set tanımları
│   ├── fitness.py         # Fitness fonksiyonları
│   ├── operators.py       # Genetik operatörler
│   ├── engine.py          # Ana evrim motoru
│   └── realtime.py        # Real-time deployment
├── utils/
│   └── test_data.py       # Test verileri ve yardımcılar
├── tests/
│   └── test_engine.py     # Unit testler
├── main.py               # Ana çalıştırma dosyası
├── __init__.py
└── README.md

docs/
└── genetic_engine.md     # Kapsamlı dokümantasyon
```

## 🏗️ Ana Bileşenler

### 1. **Primitive Set (primitives.py)**
- **Fiyat Verileri**: OPEN, HIGH, LOW, CLOSE, VOLUME
- **Teknik İndikatörler**: SMA, EMA, RSI, MACD, Bollinger Bands
- **Matematik Operatörleri**: +, -, ×, ÷, √, |x|, max, min, sin, cos
- **Mantıksal Operatörler**: >, <, =, AND, OR, NOT

### 2. **Fitness Fonksiyonları (fitness.py)**
- **Profit Fitness**: Toplam kar odaklı değerlendirme
- **Sharpe Ratio**: Risk-ayarlı getiri
- **Sortino Ratio**: Downside risk odaklı
- **Max Drawdown**: Maksimum düşüş ölçümü
- **Win Rate**: Kazanma oranı
- **Profit Factor**: Kar faktörü
- **Composite Fitness**: Bileşik skorlama

### 3. **Genetik Operatörler (operators.py)**
- **Çaprazlama**: Advanced crossover, Uniform crossover
- **Mutasyon**: Point, Subtree, Hoist, Shrink mutations
- **Seçim**: Tournament, Rank, Roulette Wheel
- **Çeşitlilik Koruma**: Diversity preservation

### 4. **Evolution Engine (engine.py)**
- **Popülasyon Yönetimi**: 10,000 strateji kapasitesi
- **GPU Desteği**: CuPy ile hızlandırma
- **Paralel Değerlendirme**: Multiprocessing
- **Checkpoint Sistemi**: Evrim durumu kaydetme
- **Real-time Monitoring**: Performans takibi

### 5. **Real-time Deployment (realtime.py)**
- **Live Trading**: Canlı ortamda strateji çalıştırma
- **Risk Yönetimi**: Position limit, stop-loss
- **A/B Testing**: Strateji karşılaştırma
- **WebSocket**: Real-time veri akışı
- **Portfolio Tracking**: Portföy performans izleme

## 🛠️ Kurulum

### Gereksinimler
```bash
pip install deap numpy pandas scikit-learn
```

### GPU Desteği (Opsiyonel)
```bash
pip install cupy-cuda11x  # CUDA 11.x için
```

## 🎯 Hızlı Başlangıç

### Temel Kullanım
```python
from genetic_engine import EvolutionEngine, EvolutionConfig
from genetic_engine.utils.test_data import generate_sample_market_data

# Konfigürasyon
config = EvolutionConfig(
    population_size=1000,
    generations=100,
    max_depth=8
)

# Engine başlatma
engine = EvolutionEngine(config)

# Test verisi
data = generate_sample_market_data(n_periods=1000)

# Evolution
stats = engine.run_evolution(data)

# En iyi stratejiler
best_strategies = engine.get_best_strategies(count=10)
```

### Real-time Deployment
```python
import asyncio
from genetic_engine import RealTimeEngine

async def deploy_strategy():
    rt_engine = RealTimeEngine()
    
    # Piyasa simülasyonu
    await rt_engine.start_market_simulation("BTCUSDT")
    
    # Strateji dağıtımı
    deployment_id = await rt_engine.deploy_strategy(
        individual=best_strategies[0].individual,
        strategy_id="btc_strategy"
    )
    
    print(f"Strateji dağıtıldı: {deployment_id}")

asyncio.run(deploy_strategy())
```

## 🎮 Komut Satırı Kullanımı

```bash
# İnteraktif menü
python main.py

# Temel örnek
python main.py --example basic

# Real-time demo
python main.py --example realtime

# Performans testi
python main.py --benchmark

# Stres testi
python main.py --stress-test

# Sistem kontrolü
python main.py --system-check
```

## 📊 Performans Metrikleri

Sistem şu metrikleri hesaplar:
- **Total Return**: Toplam getiri
- **Sharpe Ratio**: Risk-ayarlı getiri oranı
- **Sortino Ratio**: Downside risk odaklı oran
- **Max Drawdown**: Maksimum değer kaybı
- **Win Rate**: Kazanma oranı
- **Profit Factor**: Kar faktörü
- **Volatility**: Volatilite
- **VaR/CVaR**: Risk değeri metrikleri

## 🧪 Test ve Doğrulama

```bash
# Tüm testleri çalıştır
python -m unittest discover tests/

# Performans benchmark
python tests/test_engine.py

# Stres testi
python main.py --stress-test
```

## 📈 Özellikler

### ✅ Tamamlanan
- [x] DEAP tabanlı genetik programlama motoru
- [x] Kapsamlı primitive set (fiyat, indikatör, matematik)
- [x] Gelişmiş fitness fonksiyonları
- [x] Multiple crossover/mutation operatörleri
- [x] Popülasyon yönetimi (10K birey, 1000 nesil)
- [x] GPU cluster desteği (CuPy)
- [x] Real-time strateji deployment
- [x] A/B testing framework
- [x] Portfolio risk yönetimi
- [x] Comprehensive documentation
- [x] Unit test suite

### 🔄 Test Edilmiş
- [x] Engine initialization
- [x] Evolution process
- [x] Population management
- [x] Fitness calculation
- [x] Strategy export
- [x] Checkpoint operations

## 🚀 Deployment

Engine production ortamında şu şekilde çalıştırılabilir:

1. **Research Environment**: Strateji geliştirme
2. **Paper Trading**: Risk-free test ortamı
3. **Live Trading**: Gerçek piyasada deployment
4. **Portfolio Management**: Çoklu strateji yönetimi

## 📚 Dokümantasyon

Detaylı kullanım kılavuzu: `docs/genetic_engine.md`

## 🤝 Katkıda Bulunma

1. Fork yapın
2. Feature branch oluşturun
3. Commit yapın
4. Pull Request oluşturun

## 📄 Lisans

MIT License - Detaylar için LICENSE dosyasına bakın.

## 👥 Ekip

**Bitwisers Trading Team**
- Email: team@bitwisers.com
- GitHub: @bitwisers

---

© 2025 Bitwisers Team. Tüm hakları saklıdır.