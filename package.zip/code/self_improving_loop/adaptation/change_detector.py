"""
Change Detection Module
Detects changes that require system adaptation
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass
import numpy as np
import pandas as pd
from collections import deque

@dataclass
class ChangeEvent:
    """Detected change event"""
    id: str
    type: str
    severity: float
    description: str
    detected_at: datetime
    confidence: float
    data: Dict[str, Any]

class ChangeDetector:
    """
    Change Detector for system adaptation
    Monitors various aspects of system performance and detects significant changes
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Monitoring history
        self.performance_history = deque(maxlen=1000)
        self.model_history = deque(maxlen=1000)
        self.regime_history = deque(maxlen=100)
        self.health_history = deque(maxlen=1000)
        
        # Change detection thresholds
        self.thresholds = {
            'performance_degradation': 0.05,  # 5% performance drop
            'drift_detection': 0.3,           # Drift score threshold
            'regime_change': 0.7,             # Regime change confidence
            'health_degradation': 0.2         # 20% health degradation
        }
        
        # Detection statistics
        self.detection_stats = {
            'changes_detected': 0,
            'false_positives': 0,
            'avg_detection_time': 0.0,
            'last_detection': None
        }
    
    async def initialize(self) -> None:
        """Initialize change detector"""
        try:
            # Start background monitoring
            asyncio.create_task(self._background_monitoring_loop())
            
            self.logger.info("Change Detector initialized")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize change detector: {e}")
            raise
    
    async def detect_performance_changes(self) -> List[Dict[str, Any]]:
        """Detect performance degradation or improvements"""
        try:
            changes = []
            
            if len(self.performance_history) < 10:
                return changes
            
            recent_metrics = list(self.performance_history)[-10:]
            baseline_metrics = list(self.performance_history)[-30:-10] if len(self.performance_history) >= 30 else recent_metrics[:20]
            
            # Calculate baseline averages
            baseline_avg = self._calculate_baseline_average(baseline_metrics)
            recent_avg = self._calculate_baseline_average(recent_metrics)
            
            # Detect degradation
            for metric, current_value in recent_avg.items():
                if metric in baseline_avg:
                    degradation = (baseline_avg[metric] - current_value) / baseline_avg[metric]
                    
                    if degradation > self.thresholds['performance_degradation']:
                        change = ChangeEvent(
                            id=f"perf_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                            type="performance_degradation",
                            severity=degradation,
                            description=f"{metric} degraded by {degradation:.1%}",
                            detected_at=datetime.now(),
                            confidence=min(1.0, degradation / 0.2),  # Scale confidence
                            data={
                                'metric': metric,
                                'baseline_value': baseline_avg[metric],
                                'current_value': current_value,
                                'degradation': degradation,
                                'baseline_window': len(baseline_metrics),
                                'recent_window': len(recent_metrics)
                            }
                        )
                        changes.append(self._event_to_dict(change))
            
            # Detect improvements (less critical but worth noting)
            for metric, current_value in recent_avg.items():
                if metric in baseline_avg:
                    improvement = (current_value - baseline_avg[metric]) / baseline_avg[metric]
                    
                    if improvement > 0.1:  # 10% improvement
                        change = ChangeEvent(
                            id=f"imp_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                            type="performance_improvement",
                            severity=improvement,
                            description=f"{metric} improved by {improvement:.1%}",
                            detected_at=datetime.now(),
                            confidence=min(1.0, improvement / 0.3),
                            data={
                                'metric': metric,
                                'baseline_value': baseline_avg[metric],
                                'current_value': current_value,
                                'improvement': improvement
                            }
                        )
                        changes.append(self._event_to_dict(change))
            
            if changes:
                self.detection_stats['changes_detected'] += len(changes)
                self.detection_stats['last_detection'] = datetime.now()
            
            self.logger.debug(f"Detected {len(changes)} performance changes")
            return changes
            
        except Exception as e:
            self.logger.error(f"Performance change detection failed: {e}")
            return []
    
    async def detect_model_drift(self) -> List[Dict[str, Any]]:
        """Detect model drift"""
        try:
            changes = []
            
            if len(self.model_history) < 20:
                return changes
            
            recent_models = list(self.model_history)[-10:]
            older_models = list(self.model_history)[-20:-10]
            
            # Calculate drift scores for different aspects
            drift_scores = self._calculate_drift_scores(recent_models, older_models)
            
            for aspect, drift_score in drift_scores.items():
                if drift_score > self.thresholds['drift_detection']:
                    change = ChangeEvent(
                        id=f"drift_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                        type="model_drift",
                        severity=drift_score,
                        description=f"Model drift detected in {aspect} (score: {drift_score:.3f})",
                        detected_at=datetime.now(),
                        confidence=min(1.0, drift_score),
                        data={
                            'aspect': aspect,
                            'drift_score': drift_score,
                            'recent_models_count': len(recent_models),
                            'baseline_models_count': len(older_models)
                        }
                    )
                    changes.append(self._event_to_dict(change))
            
            if changes:
                self.detection_stats['changes_detected'] += len(changes)
            
            return changes
            
        except Exception as e:
            self.logger.error(f"Model drift detection failed: {e}")
            return []
    
    async def detect_regime_changes(self) -> List[Dict[str, Any]]:
        """Detect market regime changes"""
        try:
            changes = []
            
            if len(self.regime_history) < 5:
                return changes
            
            recent_regimes = list(self.regime_history)[-5:]
            
            # Analyze regime transitions
            for i in range(1, len(recent_regimes)):
                current = recent_regimes[i]
                previous = recent_regimes[i-1]
                
                if current.get('regime') != previous.get('regime'):
                    confidence = current.get('confidence', 0.0)
                    
                    if confidence > self.thresholds['regime_change']:
                        change = ChangeEvent(
                            id=f"regime_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                            type="regime_change",
                            severity=confidence,
                            description=f"Market regime changed from {previous.get('regime')} to {current.get('regime')}",
                            detected_at=datetime.now(),
                            confidence=confidence,
                            data={
                                'previous_regime': previous.get('regime'),
                                'new_regime': current.get('regime'),
                                'transition_confidence': confidence,
                                'volatility_change': current.get('volatility', 0) - previous.get('volatility', 0)
                            }
                        )
                        changes.append(self._event_to_dict(change))
            
            return changes
            
        except Exception as e:
            self.logger.error(f"Regime change detection failed: {e}")
            return []
    
    async def detect_health_changes(self) -> List[Dict[str, Any]]:
        """Detect system health changes"""
        try:
            changes = []
            
            if len(self.health_history) < 20:
                return changes
            
            recent_health = list(self.health_history)[-10:]
            baseline_health = list(self.health_history)[-20:-10]
            
            # Calculate health metrics
            baseline_health_score = np.mean([h.get('overall_health', 1.0) for h in baseline_health])
            recent_health_score = np.mean([h.get('overall_health', 1.0) for h in recent_health])
            
            health_degradation = (baseline_health_score - recent_health_score) / baseline_health_score
            
            if health_degradation > self.thresholds['health_degradation']:
                change = ChangeEvent(
                    id=f"health_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                    type="health_degradation",
                    severity=health_degradation,
                    description=f"System health degraded by {health_degradation:.1%}",
                    detected_at=datetime.now(),
                    confidence=min(1.0, health_degradation / 0.3),
                    data={
                        'baseline_health': baseline_health_score,
                        'current_health': recent_health_score,
                        'degradation': health_degradation,
                        'affected_components': self._identify_affected_components(recent_health)
                    }
                )
                changes.append(self._event_to_dict(change))
            
            # Detect critical system issues
            for health_data in recent_health:
                if health_data.get('error_rate', 0) > 0.1:  # 10% error rate
                    change = ChangeEvent(
                        id=f"critical_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                        type="critical_performance_loss",
                        severity=0.9,
                        description=f"Critical system performance loss detected",
                        detected_at=datetime.now(),
                        confidence=1.0,
                        data=health_data
                    )
                    changes.append(self._event_to_dict(change))
            
            return changes
            
        except Exception as e:
            self.logger.error(f"Health change detection failed: {e}")
            return []
    
    def _calculate_baseline_average(self, metrics_list: List[Dict[str, float]]) -> Dict[str, float]:
        """Calculate average of metrics over time window"""
        if not metrics_list:
            return {}
        
        # Initialize with first metric keys
        all_keys = set()
        for metrics in metrics_list:
            all_keys.update(metrics.keys())
        
        averages = {}
        for key in all_keys:
            values = [m.get(key, 0) for m in metrics_list if key in m]
            if values:
                averages[key] = np.mean(values)
        
        return averages
    
    def _calculate_drift_scores(self, recent: List[Dict], baseline: List[Dict]) -> Dict[str, float]:
        """Calculate drift scores for different model aspects"""
        try:
            drift_scores = {}
            
            # Performance drift
            recent_perf = [m.get('accuracy', 0) for m in recent]
            baseline_perf = [m.get('accuracy', 0) for m in baseline]
            
            if recent_perf and baseline_perf:
                perf_variance = np.var(recent_perf + baseline_perf)
                drift_scores['performance'] = min(1.0, perf_variance)
            
            # Feature drift
            if recent and baseline:
                # Compare feature importance distributions
                recent_features = []
                baseline_features = []
                
                for m in recent:
                    if 'feature_importance' in m:
                        recent_features.extend(m['feature_importance'].values())
                
                for m in baseline:
                    if 'feature_importance' in m:
                        baseline_features.extend(m['feature_importance'].values())
                
                if recent_features and baseline_features:
                    feature_drift = abs(np.mean(recent_features) - np.mean(baseline_features))
                    drift_scores['features'] = min(1.0, feature_drift)
            
            # Prediction drift
            recent_pred = [m.get('prediction_variance', 0) for m in recent]
            baseline_pred = [m.get('prediction_variance', 0) for m in baseline]
            
            if recent_pred and baseline_pred:
                pred_drift = abs(np.mean(recent_pred) - np.mean(baseline_pred))
                drift_scores['predictions'] = min(1.0, pred_drift)
            
            return drift_scores
            
        except Exception as e:
            self.logger.error(f"Drift score calculation failed: {e}")
            return {}
    
    def _identify_affected_components(self, health_data: List[Dict]) -> List[str]:
        """Identify which components are most affected by health degradation"""
        affected_components = []
        
        for data in health_data:
            # Check individual component health
            for component, health in data.get('component_health', {}).items():
                if health < 0.8:  # Below 80% health
                    affected_components.append(component)
        
        return list(set(affected_components))  # Remove duplicates
    
    def _event_to_dict(self, event: ChangeEvent) -> Dict[str, Any]:
        """Convert ChangeEvent to dictionary"""
        return {
            'id': event.id,
            'type': event.type,
            'severity': event.severity,
            'description': event.description,
            'detected_at': event.detected_at.isoformat(),
            'confidence': event.confidence,
            'data': event.data
        }
    
    async def _background_monitoring_loop(self) -> None:
        """Background loop for continuous monitoring"""
        while True:
            try:
                # Collect current metrics
                current_metrics = await self._collect_current_metrics()
                current_health = await self._collect_current_health()
                
                # Update history
                self.performance_history.append(current_metrics)
                self.health_history.append(current_health)
                
                # Simulate regime detection
                await self._update_regime_detection()
                
                # Simulate model monitoring
                await self._update_model_monitoring()
                
                await asyncio.sleep(30)  # Monitor every 30 seconds
                
            except Exception as e:
                self.logger.error(f"Background monitoring error: {e}")
                await asyncio.sleep(5)
    
    async def _collect_current_metrics(self) -> Dict[str, float]:
        """Collect current performance metrics"""
        try:
            import random
            random.seed(42)
            
            return {
                'accuracy': random.uniform(0.7, 0.95),
                'latency': random.uniform(50, 200),
                'throughput': random.uniform(100, 500),
                'sharpe_ratio': random.uniform(0.5, 2.0),
                'max_drawdown': random.uniform(0.05, 0.2),
                'win_rate': random.uniform(0.45, 0.65)
            }
            
        except Exception as e:
            self.logger.error(f"Metrics collection failed: {e}")
            return {}
    
    async def _collect_current_health(self) -> Dict[str, Any]:
        """Collect current system health metrics"""
        try:
            import random
            random.seed(43)
            
            return {
                'overall_health': random.uniform(0.8, 0.99),
                'error_rate': random.uniform(0, 0.05),
                'response_time': random.uniform(50, 150),
                'cpu_usage': random.uniform(0.2, 0.8),
                'memory_usage': random.uniform(0.3, 0.7),
                'component_health': {
                    'data_processor': random.uniform(0.85, 0.99),
                    'model_engine': random.uniform(0.80, 0.95),
                    'adaptation_system': random.uniform(0.90, 0.99),
                    'monitoring_system': random.uniform(0.95, 0.99)
                }
            }
            
        except Exception as e:
            self.logger.error(f"Health collection failed: {e}")
            return {}
    
    async def _update_regime_detection(self) -> None:
        """Update regime detection"""
        try:
            import random
            random.seed(hash(str(datetime.now().date())) % 1000)
            
            regimes = ['trending_up', 'trending_down', 'sideways', 'volatile', 'calm']
            
            regime_data = {
                'regime': random.choice(regimes),
                'confidence': random.uniform(0.6, 0.95),
                'volatility': random.uniform(0.1, 0.8),
                'timestamp': datetime.now()
            }
            
            self.regime_history.append(regime_data)
            
        except Exception as e:
            self.logger.error(f"Regime detection update failed: {e}")
    
    async def _update_model_monitoring(self) -> None:
        """Update model monitoring"""
        try:
            import random
            random.seed(hash(str(datetime.now().hour)) % 1000)
            
            model_data = {
                'accuracy': random.uniform(0.7, 0.95),
                'prediction_variance': random.uniform(0.01, 0.1),
                'feature_importance': {
                    f'feature_{i}': random.uniform(0, 1) for i in range(5)
                },
                'model_id': f'model_{random.randint(1000, 9999)}',
                'timestamp': datetime.now()
            }
            
            self.model_history.append(model_data)
            
        except Exception as e:
            self.logger.error(f"Model monitoring update failed: {e}")
    
    def get_detection_stats(self) -> Dict[str, Any]:
        """Get detection statistics"""
        return {
            **self.detection_stats,
            'performance_history_size': len(self.performance_history),
            'model_history_size': len(self.model_history),
            'regime_history_size': len(self.regime_history),
            'health_history_size': len(self.health_history)
        }
    
    async def get_state(self) -> Dict[str, Any]:
        """Get current change detector state"""
        return {
            'stats': self.get_detection_stats(),
            'thresholds': self.thresholds,
            'recent_changes': len([h for h in self.performance_history if h.get('change_detected', False)])
        }
