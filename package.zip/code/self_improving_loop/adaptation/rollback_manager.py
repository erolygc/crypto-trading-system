"""
Rollback Manager Module
Manages system rollbacks and recovery
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
import json
import os
import copy

class RollbackType(Enum):
    """Types of rollbacks"""
    PARAMETER_ROLLBACK = "parameter_rollback"
    MODEL_ROLLBACK = "model_rollback"
    STRATEGY_ROLLBACK = "strategy_rollback"
    ARCHITECTURE_ROLLBACK = "architecture_rollback"
    FULL_SYSTEM_ROLLBACK = "full_system_rollback"

class RollbackStatus(Enum):
    """Status of rollback process"""
    INITIATED = "initiated"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    PARTIAL = "partial"

@dataclass
class RollbackPlan:
    """Plan for system rollback"""
    id: str
    rollback_type: RollbackType
    trigger_reason: str
    backup_state: Dict[str, Any]
    target_state: Dict[str, Any]
    rollback_steps: List[Dict[str, Any]] = field(default_factory=list)
    estimated_duration: float = 0.0
    priority: int = 1
    created_at: datetime = field(default_factory=datetime.now)

@dataclass
class RollbackExecution:
    """Rollback execution details"""
    rollback_plan_id: str
    status: RollbackStatus
    start_time: datetime
    end_time: Optional[datetime] = None
    steps_completed: int = 0
    total_steps: int = 0
    success: bool = False
    error_message: Optional[str] = None
    performance_impact: Dict[str, float] = field(default_factory=dict)

class RollbackManager:
    """
    Rollback Manager for system recovery
    Manages rollback processes, state management, and recovery procedures
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Rollback storage
        self.backup_states: Dict[str, Dict[str, Any]] = {}
        self.rollback_plans: Dict[str, RollbackPlan] = {}
        self.rollback_history: List[RollbackExecution] = []
        
        # Configuration
        self.retention_policy = {
            'backup_retention_days': 30,
            'max_backups_per_component': 10,
            'auto_cleanup_enabled': True
        }
        
        # Rollback thresholds
        self.rollback_thresholds = {
            'performance_degradation': 0.15,  # 15% degradation triggers rollback
            'error_rate_increase': 0.05,      # 5% error rate increase
            'timeout_threshold': 300,         # 5 minutes
            'success_threshold': 0.8          # 80% success rate minimum
        }
        
        # Recovery settings
        self.recovery_settings = {
            'parallel_rollback': True,
            'rollback_timeout': 600,  # 10 minutes
            'verification_enabled': True,
            'auto_rollback_enabled': True
        }
        
        # Metrics
        self.rollback_metrics = {
            'total_rollbacks': 0,
            'successful_rollbacks': 0,
            'failed_rollbacks': 0,
            'average_rollback_time': 0.0,
            'rollbacks_prevented': 0,
            'last_rollback': None
        }
        
        # Rollback monitoring
        self.monitoring_active = False
        self.health_check_interval = 30  # seconds
        
        self.logger.info("Rollback Manager initialized")
    
    async def initialize(self) -> None:
        """Initialize rollback manager"""
        try:
            # Load existing backup states
            await self._load_backup_states()
            
            # Start health monitoring
            if self.recovery_settings['auto_rollback_enabled']:
                asyncio.create_task(self._health_monitoring_loop())
            
            # Start cleanup task
            if self.retention_policy['auto_cleanup_enabled']:
                asyncio.create_task(self._cleanup_loop())
            
            self.logger.info("Rollback Manager initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize rollback manager: {e}")
            raise
    
    async def create_backup(self, component_name: str, state: Dict[str, Any]) -> str:
        """Create backup of component state"""
        try:
            backup_id = f"backup_{component_name}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
            
            backup_data = {
                'id': backup_id,
                'component': component_name,
                'state': copy.deepcopy(state),
                'timestamp': datetime.now(),
                'version': self._get_next_version(component_name)
            }
            
            # Store backup
            self.backup_states[backup_id] = backup_data
            
            # Clean up old backups for this component
            await self._cleanup_component_backups(component_name)
            
            self.logger.info(f"Created backup {backup_id} for component {component_name}")
            return backup_id
            
        except Exception as e:
            self.logger.error(f"Backup creation failed for {component_name}: {e}")
            raise
    
    async def execute_rollback(
        self, 
        adaptation_request: Dict[str, Any], 
        adaptation_result: Any
    ) -> bool:
        """Execute rollback for failed adaptation"""
        try:
            self.logger.info(f"Executing rollback for adaptation {adaptation_request.get('id', 'unknown')}")
            
            # Analyze failure
            failure_analysis = await self._analyze_failure(adaptation_request, adaptation_result)
            
            if not failure_analysis['rollback_recommended']:
                self.logger.info("Rollback not recommended based on analysis")
                return False
            
            # Determine rollback type and scope
            rollback_type = self._determine_rollback_type(adaptation_request, failure_analysis)
            
            # Get appropriate backup
            backup_state = await self._get_backup_state(adaptation_request, rollback_type)
            
            if not backup_state:
                self.logger.warning("No backup state available for rollback")
                return False
            
            # Create rollback plan
            rollback_plan = await self._create_rollback_plan(
                rollback_type, failure_analysis, backup_state
            )
            
            # Execute rollback
            rollback_execution = await self._execute_rollback_plan(rollback_plan)
            
            # Record rollback in history
            self.rollback_history.append(rollback_execution)
            self.rollback_metrics['total_rollbacks'] += 1
            
            if rollback_execution.success:
                self.rollback_metrics['successful_rollbacks'] += 1
                self.rollback_metrics['last_rollback'] = datetime.now()
                
                self.logger.info(f"Rollback completed successfully: {rollback_plan.id}")
                return True
            else:
                self.rollback_metrics['failed_rollbacks'] += 1
                
                self.logger.error(f"Rollback failed: {rollback_plan.id}")
                return False
            
        except Exception as e:
            self.logger.error(f"Rollback execution failed: {e}")
            self.rollback_metrics['failed_rollbacks'] += 1
            return False
    
    async def _analyze_failure(
        self, 
        adaptation_request: Dict[str, Any], 
        adaptation_result: Any
    ) -> Dict[str, Any]:
        """Analyze adaptation failure and determine rollback needs"""
        try:
            analysis = {
                'rollback_recommended': False,
                'failure_severity': 0.0,
                'affected_components': [],
                'performance_impact': {},
                'rollback_type': RollbackType.PARAMETER_ROLLBACK,
                'rollback_scope': 'partial',
                'reasoning': []
            }
            
            # Check adaptation status
            if hasattr(adaptation_result, 'status'):
                if str(adaptation_result.status) == 'FAILED':
                    analysis['rollback_recommended'] = True
                    analysis['failure_severity'] = 0.8
                    analysis['reasoning'].append('Adaptation failed completely')
                
                if hasattr(adaptation_result, 'rollback_performed') and adaptation_result.rollback_performed:
                    analysis['rollback_recommended'] = True
                    analysis['failure_severity'] = 0.9
                    analysis['reasoning'].append('Previous rollback was performed')
            
            # Check performance impact
            if (hasattr(adaptation_result, 'performance_before') and 
                hasattr(adaptation_result, 'performance_after') and
                adaptation_result.performance_before and adaptation_result.performance_after):
                
                before = adaptation_result.performance_before
                after = adaptation_result.performance_after
                
                for metric in before:
                    if metric in after:
                        if metric == 'error_rate':
                            # Higher error rate is bad
                            impact = (after[metric] - before[metric]) / before[metric] if before[metric] > 0 else 0
                        else:
                            # Lower metric values are bad for positive metrics
                            impact = (before[metric] - after[metric]) / before[metric] if before[metric] > 0 else 0
                        
                        analysis['performance_impact'][metric] = impact
                        
                        if impact > self.rollback_thresholds['performance_degradation']:
                            analysis['rollback_recommended'] = True
                            analysis['affected_components'].append(f"performance_{metric}")
                            analysis['reasoning'].append(f"{metric} degraded by {impact:.1%}")
            
            # Check error rate specifically
            error_impact = analysis['performance_impact'].get('error_rate', 0)
            if error_impact > self.rollback_thresholds['error_rate_increase']:
                analysis['rollback_recommended'] = True
                analysis['failure_severity'] = max(analysis['failure_severity'], 0.7)
                analysis['reasoning'].append(f"Error rate increased by {error_impact:.1%}")
            
            # Determine rollback scope based on severity
            if analysis['failure_severity'] > 0.7:
                analysis['rollback_scope'] = 'full'
            elif analysis['failure_severity'] > 0.4:
                analysis['rollback_scope'] = 'major'
            else:
                analysis['rollback_scope'] = 'minor'
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Failure analysis failed: {e}")
            return {
                'rollback_recommended': True,  # Conservative approach
                'failure_severity': 0.5,
                'reasoning': [f'Analysis failed: {str(e)}']
            }
    
    def _determine_rollback_type(
        self, 
        adaptation_request: Dict[str, Any],
        failure_analysis: Dict[str, Any]
    ) -> RollbackType:
        """Determine appropriate rollback type based on failure analysis"""
        try:
            adaptation_type = adaptation_request.get('type', 'unknown')
            severity = failure_analysis['failure_severity']
            scope = failure_analysis['rollback_scope']
            
            # Map adaptation types to rollback types
            if 'model' in adaptation_type.lower():
                if scope == 'full':
                    return RollbackType.FULL_SYSTEM_ROLLBACK
                else:
                    return RollbackType.MODEL_ROLLBACK
            elif 'strategy' in adaptation_type.lower():
                return RollbackType.STRATEGY_ROLLBACK
            elif 'parameter' in adaptation_type.lower():
                return RollbackType.PARAMETER_ROLLBACK
            elif 'architecture' in adaptation_type.lower():
                return RollbackType.ARCHITECTURE_ROLLBACK
            else:
                return RollbackType.PARAMETER_ROLLBACK  # Default
                
        except Exception as e:
            self.logger.error(f"Rollback type determination failed: {e}")
            return RollbackType.PARAMETER_ROLLBACK
    
    async def _get_backup_state(
        self, 
        adaptation_request: Dict[str, Any], 
        rollback_type: RollbackType
    ) -> Optional[Dict[str, Any]]:
        """Get appropriate backup state for rollback"""
        try:
            # For demonstration, create a simulated backup
            # In practice, would fetch from actual backup storage
            
            component_mapping = {
                RollbackType.MODEL_ROLLBACK: 'model_engine',
                RollbackType.STRATEGY_ROLLBACK: 'strategy_engine',
                RollbackType.PARAMETER_ROLLBACK: 'parameter_store',
                RollbackType.ARCHITECTURE_ROLLBACK: 'system_config',
                RollbackType.FULL_SYSTEM_ROLLBACK: 'full_system'
            }
            
            target_component = component_mapping.get(rollback_type, 'default')
            
            # Check if we have recent backups
            recent_backups = [
                backup for backup in self.backup_states.values()
                if target_component in backup.get('component', '').lower()
            ]
            
            if recent_backups:
                # Return the most recent backup
                latest_backup = max(recent_backups, key=lambda x: x['timestamp'])
                return latest_backup['state']
            
            # If no backup exists, create a minimal fallback state
            fallback_state = {
                'parameters': {'version': '1.0', 'last_valid_config': True},
                'model': {'model_id': 'fallback_model_v1', 'accuracy': 0.85},
                'strategy': {'active_strategy': 'conservative', 'risk_level': 'low'},
                'timestamp': datetime.now()
            }
            
            return fallback_state
            
        except Exception as e:
            self.logger.error(f"Backup state retrieval failed: {e}")
            return None
    
    async def _create_rollback_plan(
        self, 
        rollback_type: RollbackType,
        failure_analysis: Dict[str, Any],
        backup_state: Dict[str, Any]
    ) -> RollbackPlan:
        """Create detailed rollback plan"""
        try:
            plan_id = f"rollback_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
            
            # Determine rollback steps based on type
            if rollback_type == RollbackType.PARAMETER_ROLLBACK:
                steps = [
                    {'step': 1, 'action': 'freeze_current_state', 'component': 'parameter_store'},
                    {'step': 2, 'action': 'restore_parameters', 'component': 'parameter_store', 'backup': True},
                    {'step': 3, 'action': 'validate_parameters', 'component': 'parameter_store'},
                    {'step': 4, 'action': 'restart_affected_services', 'component': 'parameter_consumer'}
                ]
                estimated_duration = 120.0  # 2 minutes
                
            elif rollback_type == RollbackType.MODEL_ROLLBACK:
                steps = [
                    {'step': 1, 'action': 'drain_model_requests', 'component': 'model_engine'},
                    {'step': 2, 'action': 'restore_model', 'component': 'model_engine', 'backup': True},
                    {'step': 3, 'action': 'warmup_model', 'component': 'model_engine'},
                    {'step': 4, 'action': 'validate_model_performance', 'component': 'model_engine'},
                    {'step': 5, 'action': 'resume_model_requests', 'component': 'model_engine'}
                ]
                estimated_duration = 300.0  # 5 minutes
                
            elif rollback_type == RollbackType.STRATEGY_ROLLBACK:
                steps = [
                    {'step': 1, 'action': 'suspend_strategy_execution', 'component': 'strategy_engine'},
                    {'step': 2, 'action': 'restore_strategy_config', 'component': 'strategy_engine', 'backup': True},
                    {'step': 3, 'action': 'validate_strategy', 'component': 'strategy_engine'},
                    {'step': 4, 'action': 'resume_strategy_execution', 'component': 'strategy_engine'}
                ]
                estimated_duration = 180.0  # 3 minutes
                
            else:  # Default for other types
                steps = [
                    {'step': 1, 'action': 'stop_all_components', 'component': 'system'},
                    {'step': 2, 'action': 'restore_full_state', 'component': 'system', 'backup': True},
                    {'step': 3, 'action': 'restart_system', 'component': 'system'},
                    {'step': 4, 'action': 'validate_system_health', 'component': 'system'}
                ]
                estimated_duration = 600.0  # 10 minutes
            
            # Create rollback plan
            rollback_plan = RollbackPlan(
                id=plan_id,
                rollback_type=rollback_type,
                trigger_reason='; '.join(failure_analysis['reasoning']),
                backup_state=backup_state,
                target_state=failure_analysis.get('current_state', {}),
                rollback_steps=steps,
                estimated_duration=estimated_duration,
                priority=1 if failure_analysis['failure_severity'] > 0.7 else 2
            )
            
            self.rollback_plans[plan_id] = rollback_plan
            
            self.logger.info(f"Created rollback plan: {plan_id}")
            return rollback_plan
            
        except Exception as e:
            self.logger.error(f"Rollback plan creation failed: {e}")
            raise
    
    async def _execute_rollback_plan(self, rollback_plan: RollbackPlan) -> RollbackExecution:
        """Execute rollback plan"""
        try:
            execution = RollbackExecution(
                rollback_plan_id=rollback_plan.id,
                status=RollbackStatus.INITIATED,
                start_time=datetime.now(),
                total_steps=len(rollback_plan.rollback_steps)
            )
            
            self.logger.info(f"Starting rollback execution: {rollback_plan.id}")
            
            execution.status = RollbackStatus.IN_PROGRESS
            
            for i, step in enumerate(rollback_plan.rollback_steps):
                try:
                    self.logger.debug(f"Executing rollback step {step['step']}: {step['action']}")
                    
                    # Execute step
                    step_success = await self._execute_rollback_step(step, rollback_plan)
                    
                    if step_success:
                        execution.steps_completed += 1
                        self.logger.debug(f"Rollback step {step['step']} completed")
                    else:
                        execution.error_message = f"Rollback step {step['step']} failed: {step['action']}"
                        execution.status = RollbackStatus.FAILED
                        break
                        
                    # Verify step (if verification is enabled)
                    if self.recovery_settings['verification_enabled']:
                        verification_success = await self._verify_rollback_step(step)
                        if not verification_success:
                            execution.error_message = f"Rollback step {step['step']} verification failed"
                            execution.status = RollbackStatus.FAILED
                            break
                
                except Exception as e:
                    execution.error_message = f"Rollback step {step['step']} error: {str(e)}"
                    execution.status = RollbackStatus.FAILED
                    self.logger.error(f"Rollback step {step['step']} failed: {e}")
                    break
            
            # Finalize execution
            execution.end_time = datetime.now()
            
            if execution.steps_completed == execution.total_steps:
                execution.status = RollbackStatus.COMPLETED
                execution.success = True
                
                # Measure performance impact
                execution.performance_impact = await self._measure_rollback_impact()
                
                self.logger.info(f"Rollback completed successfully: {rollback_plan.id}")
            elif execution.steps_completed > 0:
                execution.status = RollbackStatus.PARTIAL
                execution.success = False
                
                self.logger.warning(f"Rollback partially completed: {rollback_plan.id}")
            else:
                execution.success = False
                
                self.logger.error(f"Rollback failed completely: {rollback_plan.id}")
            
            return execution
            
        except Exception as e:
            self.logger.error(f"Rollback execution failed: {e}")
            return RollbackExecution(
                rollback_plan_id=rollback_plan.id,
                status=RollbackStatus.FAILED,
                start_time=datetime.now(),
                end_time=datetime.now(),
                success=False,
                error_message=str(e)
            )
    
    async def _execute_rollback_step(
        self, 
        step: Dict[str, Any], 
        rollback_plan: RollbackPlan
    ) -> bool:
        """Execute individual rollback step"""
        try:
            action = step['action']
            component = step['component']
            
            if action == 'freeze_current_state':
                # Simulate freezing current state
                await asyncio.sleep(0.1)
                return True
                
            elif action == 'restore_parameters' or action == 'restore_model' or action == 'restore_strategy_config':
                # Simulate state restoration
                if 'backup' in step and step['backup']:
                    # Apply backup state
                    await asyncio.sleep(0.5)  # Restoration time
                    return True
                else:
                    return False
                    
            elif action == 'validate_parameters' or action == 'validate_model_performance' or action == 'validate_strategy':
                # Validate restored state
                await asyncio.sleep(0.2)  # Validation time
                return True
                
            elif action == 'restart_affected_services' or action == 'restart_system':
                # Restart services
                await asyncio.sleep(1.0)  # Restart time
                return True
                
            elif action == 'warmup_model':
                # Warmup model
                await asyncio.sleep(2.0)  # Warmup time
                return True
                
            elif action == 'resume_model_requests' or action == 'resume_strategy_execution':
                # Resume operations
                await asyncio.sleep(0.1)  # Resume time
                return True
                
            elif action == 'stop_all_components':
                # Stop all components
                await asyncio.sleep(0.5)  # Stop time
                return True
                
            elif action == 'restore_full_state':
                # Restore full system state
                await asyncio.sleep(1.0)  # Full restoration time
                return True
                
            else:
                self.logger.warning(f"Unknown rollback action: {action}")
                return False
                
        except Exception as e:
            self.logger.error(f"Rollback step execution failed: {e}")
            return False
    
    async def _verify_rollback_step(self, step: Dict[str, Any]) -> bool:
        """Verify that rollback step was successful"""
        try:
            # Simulate verification
            await asyncio.sleep(0.1)
            
            # In practice, would check actual system state
            import random
            random.seed(hash(step['action']) % 1000)
            
            return random.random() > 0.05  # 95% success rate for verification
            
        except Exception as e:
            self.logger.error(f"Rollback step verification failed: {e}")
            return False
    
    async def _measure_rollback_impact(self) -> Dict[str, float]:
        """Measure performance impact of rollback"""
        try:
            # Simulate performance measurement
            import random
            random.seed(42)
            
            return {
                'recovery_time': random.uniform(30, 300),
                'data_consistency': random.uniform(0.95, 1.0),
                'service_availability': random.uniform(0.85, 0.99),
                'performance_degradation': random.uniform(0, 0.1)
            }
            
        except Exception as e:
            self.logger.error(f"Rollback impact measurement failed: {e}")
            return {}
    
    async def _cleanup_component_backups(self, component_name: str) -> None:
        """Clean up old backups for a component"""
        try:
            component_backups = [
                (backup_id, backup) for backup_id, backup in self.backup_states.items()
                if component_name in backup.get('component', '')
            ]
            
            # Keep only the most recent backups
            if len(component_backups) > self.retention_policy['max_backups_per_component']:
                # Sort by timestamp and remove oldest
                sorted_backups = sorted(component_backups, key=lambda x: x[1]['timestamp'])
                backups_to_remove = sorted_backups[:-self.retention_policy['max_backups_per_component']]
                
                for backup_id, _ in backups_to_remove:
                    del self.backup_states[backup_id]
                
                self.logger.info(f"Cleaned up {len(backups_to_remove)} old backups for {component_name}")
            
        except Exception as e:
            self.logger.error(f"Backup cleanup failed for {component_name}: {e}")
    
    def _get_next_version(self, component_name: str) -> int:
        """Get next version number for component backups"""
        try:
            component_versions = [
                backup['version'] for backup in self.backup_states.values()
                if component_name in backup.get('component', '')
            ]
            return max(component_versions) + 1 if component_versions else 1
        except Exception as e:
            self.logger.error(f"Version calculation failed for {component_name}: {e}")
            return 1
    
    async def _load_backup_states(self) -> None:
        """Load existing backup states"""
        try:
            # In practice, would load from persistent storage
            self.logger.info("Backup states loaded")
        except Exception as e:
            self.logger.error(f"Backup states loading failed: {e}")
    
    async def _health_monitoring_loop(self) -> None:
        """Background health monitoring for rollback decisions"""
        while True:
            try:
                # Monitor system health
                health_status = await self._check_system_health()
                
                # Check if rollback is needed
                if health_status['rollback_recommended']:
                    self.logger.warning("System health degraded - rollback may be needed")
                    
                    # Create emergency rollback plan if needed
                    await self._create_emergency_rollback(health_status)
                
                await asyncio.sleep(self.health_check_interval)
                
            except Exception as e:
                self.logger.error(f"Health monitoring error: {e}")
                await asyncio.sleep(5)
    
    async def _check_system_health(self) -> Dict[str, Any]:
        """Check current system health"""
        try:
            # Simulate health check
            import random
            random.seed(hash(str(datetime.now())) % 1000)
            
            return {
                'overall_health': random.uniform(0.7, 0.99),
                'error_rate': random.uniform(0, 0.1),
                'response_time': random.uniform(50, 500),
                'rollback_recommended': random.random() < 0.1  # 10% chance
            }
            
        except Exception as e:
            self.logger.error(f"System health check failed: {e}")
            return {'rollback_recommended': False}
    
    async def _create_emergency_rollback(self, health_status: Dict[str, Any]) -> None:
        """Create emergency rollback plan"""
        try:
            # This would create a high-priority emergency rollback
            self.logger.info("Emergency rollback plan created")
        except Exception as e:
            self.logger.error(f"Emergency rollback creation failed: {e}")
    
    async def _cleanup_loop(self) -> None:
        """Background cleanup loop for old backups"""
        while True:
            try:
                # Clean up old backups based on retention policy
                cutoff_date = datetime.now() - timedelta(days=self.retention_policy['backup_retention_days'])
                
                expired_backups = [
                    backup_id for backup_id, backup in self.backup_states.items()
                    if backup['timestamp'] < cutoff_date
                ]
                
                for backup_id in expired_backups:
                    del self.backup_states[backup_id]
                
                if expired_backups:
                    self.logger.info(f"Cleaned up {len(expired_backups)} expired backups")
                
                await asyncio.sleep(3600)  # Run every hour
                
            except Exception as e:
                self.logger.error(f"Cleanup loop error: {e}")
                await asyncio.sleep(300)
    
    def get_rollback_stats(self) -> Dict[str, Any]:
        """Get rollback statistics"""
        return {
            **self.rollback_metrics,
            'active_plans': len(self.rollback_plans),
            'stored_backups': len(self.backup_states),
            'rollback_history_length': len(self.rollback_history)
        }
    
    async def get_state(self) -> Dict[str, Any]:
        """Get current rollback manager state"""
        return {
            'stats': self.get_rollback_stats(),
            'thresholds': self.rollback_thresholds,
            'recovery_settings': self.recovery_settings,
            'backup_count_by_component': self._get_backup_counts_by_component()
        }
    
    def _get_backup_counts_by_component(self) -> Dict[str, int]:
        """Get backup counts by component"""
        counts = {}
        for backup in self.backup_states.values():
            component = backup.get('component', 'unknown')
            counts[component] = counts.get(component, 0) + 1
        return counts
