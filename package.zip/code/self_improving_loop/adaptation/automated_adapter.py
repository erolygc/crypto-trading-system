"""
Automated System Adapter
Implements Phase 2: Automated system adaptation and change management
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
import json
import os
import copy

from .change_detector import ChangeDetector
from .adaptation_strategies import AdaptationStrategy
from .rollback_manager import RollbackManager

class AdaptationType(Enum):
    """Types of system adaptations"""
    PARAMETER_UPDATE = "parameter_update"
    MODEL_REPLACEMENT = "model_replacement"
    STRATEGY_SWITCH = "strategy_switch"
    ARCHITECTURE_CHANGE = "architecture_change"
    THRESHOLD_ADJUSTMENT = "threshold_adjustment"
    FEATURE_UPDATE = "feature_update"

class AdaptationStatus(Enum):
    """Status of adaptation process"""
    PENDING = "pending"
    TESTING = "testing"
    DEPLOYING = "deploying"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"

@dataclass
class AdaptationRequest:
    """Request for system adaptation"""
    id: str
    type: AdaptationType
    description: str
    parameters: Dict[str, Any]
    priority: int = 1  # 1=high, 2=medium, 3=low
    trigger_conditions: Dict[str, Any] = field(default_factory=dict)
    rollback_criteria: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    target_components: List[str] = field(default_factory=list)
    expected_impact: Dict[str, float] = field(default_factory=dict)

@dataclass
class AdaptationResult:
    """Result of adaptation process"""
    request_id: str
    status: AdaptationStatus
    start_time: datetime
    end_time: Optional[datetime] = None
    changes_applied: Dict[str, Any] = field(default_factory=dict)
    performance_before: Optional[Dict[str, float]] = None
    performance_after: Optional[Dict[str, float]] = None
    rollback_performed: bool = False
    error_message: Optional[str] = None
    success_score: float = 0.0

class AutomatedSystemAdapter:
    """
    Automated System Adapter for Phase 2
    Manages automated adaptations based on performance monitoring and system changes
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Initialize components
        self.change_detector = ChangeDetector(config)
        self.adaptation_strategies = AdaptationStrategy(config)
        self.rollback_manager = RollbackManager(config)
        
        # Adaptation state
        self.adaptation_queue: List[AdaptationRequest] = []
        self.adaptation_history: List[AdaptationResult] = []
        self.active_adaptations: Dict[str, AdaptationResult] = {}
        self.system_state: Dict[str, Any] = {}
        
        # Performance baseline
        self.performance_baseline: Dict[str, float] = {}
        self.adaptation_thresholds = config.get('adaptation', {})
        
        # Adaptation metrics
        self.adaptation_metrics = {
            'total_adaptations': 0,
            'successful_adaptations': 0,
            'failed_adaptations': 0,
            'rollback_count': 0,
            'average_success_time': 0.0,
            'adaptation_frequency': 0.0
        }
        
        # Risk management
        self.risk_controls = {
            'max_concurrent_adaptations': 3,
            'min_time_between_adaptations': 300,  # 5 minutes
            'max_adaptation_impact': 0.1,  # 10% performance impact allowed
            'emergency_stop_enabled': True
        }
        
        self.logger.info("Automated System Adapter initialized")
    
    async def initialize(self) -> None:
        """Initialize the adaptation system"""
        try:
            await self.change_detector.initialize()
            await self.adaptation_strategies.initialize()
            await self.rollback_manager.initialize()
            
            # Load baseline performance
            await self._load_performance_baseline()
            
            # Start background monitoring
            asyncio.create_task(self._adaptation_monitoring_loop())
            
            self.logger.info("Automated System Adapter initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize adapter: {e}")
            raise
    
    async def run_adaptation_cycle(self) -> Dict[str, Any]:
        """Execute one adaptation cycle"""
        try:
            self.logger.info("Starting adaptation cycle")
            
            cycle_results = {
                'cycle_id': f"cycle_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                'timestamp': datetime.now().isoformat(),
                'status': 'started',
                'changes': [],
                'adaptations_performed': 0,
                'performance_impact': {}
            }
            
            # Step 1: Detect changes requiring adaptation
            detected_changes = await self._detect_required_changes()
            
            # Step 2: Generate adaptation requests
            adaptation_requests = await self._generate_adaptation_requests(detected_changes)
            
            # Step 3: Process adaptation queue
            results = await self._process_adaptation_queue(adaptation_requests)
            
            # Step 4: Update system state
            await self._update_system_state(results)
            
            # Step 5: Monitor adaptation performance
            await self._monitor_adaptation_performance(results)
            
            # Step 6: Cleanup completed adaptations
            await self._cleanup_completed_adaptations()
            
            cycle_results.update({
                'status': 'completed',
                'changes': results,
                'adaptations_performed': len(results),
                'system_state': self.system_state,
                'metrics': self.adaptation_metrics
            })
            
            self.logger.info(f"Adaptation cycle completed: {len(results)} adaptations performed")
            
            return cycle_results
            
        except Exception as e:
            self.logger.error(f"Adaptation cycle failed: {e}")
            return {
                'cycle_id': 'failed',
                'status': 'failed',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    async def _detect_required_changes(self) -> List[Dict[str, Any]]:
        """Detect changes that require system adaptation"""
        try:
            detected_changes = []
            
            # Detect performance degradation
            performance_changes = await self.change_detector.detect_performance_changes()
            if performance_changes:
                detected_changes.extend(performance_changes)
            
            # Detect model drift
            drift_changes = await self.change_detector.detect_model_drift()
            if drift_changes:
                detected_changes.extend(drift_changes)
            
            # Detect market regime changes
            regime_changes = await self.change_detector.detect_regime_changes()
            if regime_changes:
                detected_changes.extend(regime_changes)
            
            # Detect system health changes
            health_changes = await self.change_detector.detect_health_changes()
            if health_changes:
                detected_changes.extend(health_changes)
            
            # Add change timestamps
            for change in detected_changes:
                change['detected_at'] = datetime.now()
            
            self.logger.info(f"Detected {len(detected_changes)} changes requiring adaptation")
            
            return detected_changes
            
        except Exception as e:
            self.logger.error(f"Change detection failed: {e}")
            return []
    
    async def _generate_adaptation_requests(
        self, 
        detected_changes: List[Dict[str, Any]]
    ) -> List[AdaptationRequest]:
        """Generate adaptation requests based on detected changes"""
        try:
            requests = []
            
            for change in detected_changes:
                change_type = change.get('type', 'unknown')
                
                if change_type == 'performance_degradation':
                    request = await self._create_performance_adaptation_request(change)
                elif change_type == 'model_drift':
                    request = await self._create_model_adaptation_request(change)
                elif change_type == 'regime_change':
                    request = await self._create_regime_adaptation_request(change)
                elif change_type == 'health_degradation':
                    request = await self._create_health_adaptation_request(change)
                else:
                    continue
                
                # Set priority based on change severity
                request.priority = self._calculate_adaptation_priority(change)
                
                requests.append(request)
            
            # Sort by priority
            requests.sort(key=lambda x: x.priority)
            
            self.logger.info(f"Generated {len(requests)} adaptation requests")
            
            return requests
            
        except Exception as e:
            self.logger.error(f"Adaptation request generation failed: {e}")
            return []
    
    async def _create_performance_adaptation_request(
        self, 
        change: Dict[str, Any]
    ) -> AdaptationRequest:
        """Create adaptation request for performance degradation"""
        degradation = change.get('degradation', 0.0)
        
        if degradation > 0.15:  # Significant degradation
            return AdaptationRequest(
                id=f"perf_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                type=AdaptationType.MODEL_REPLACEMENT,
                description=f"Model replacement due to {degradation:.1%} performance degradation",
                parameters={
                    'degradation_threshold': degradation,
                    'new_model_required': True,
                    'fallback_strategy': 'use_best_historical_model'
                },
                target_components=['prediction_models'],
                expected_impact={'performance_improvement': 0.2}
            )
        elif degradation > 0.05:  # Moderate degradation
            return AdaptationRequest(
                id=f"param_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                type=AdaptationType.PARAMETER_UPDATE,
                description=f"Parameter tuning due to {degradation:.1%} performance degradation",
                parameters={
                    'tuning_target': 'all_parameters',
                    'tuning_method': 'bayesian_optimization',
                    'expected_improvement': 0.1
                },
                target_components=['parameter_optimizer'],
                expected_impact={'performance_improvement': 0.1}
            )
        else:
            # Minor degradation - threshold adjustment
            return AdaptationRequest(
                id=f"thresh_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                type=AdaptationType.THRESHOLD_ADJUSTMENT,
                description=f"Threshold adjustment due to {degradation:.1%} performance degradation",
                parameters={
                    'adjustment_type': 'sensitivity_reduction',
                    'adjustment_factor': 0.9
                },
                target_components=['decision_engine'],
                expected_impact={'stability_improvement': 0.05}
            )
    
    async def _create_model_adaptation_request(
        self, 
        change: Dict[str, Any]
    ) -> AdaptationRequest:
        """Create adaptation request for model drift"""
        drift_score = change.get('drift_score', 0.0)
        
        return AdaptationRequest(
            id=f"drift_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
            type=AdaptationType.MODEL_REPLACEMENT,
            description=f"Model retraining due to drift detection (score: {drift_score:.3f})",
            parameters={
                'drift_threshold': 0.3,
                'retrain_required': True,
                'feature_importance_update': True
            },
            target_components=['prediction_models'],
            expected_impact={'model_accuracy': 0.15}
        )
    
    async def _create_regime_adaptation_request(
        self, 
        change: Dict[str, Any]
    ) -> AdaptationRequest:
        """Create adaptation request for market regime change"""
        new_regime = change.get('new_regime', 'unknown')
        regime_confidence = change.get('confidence', 0.0)
        
        return AdaptationRequest(
            id=f"regime_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
            type=AdaptationType.STRATEGY_SWITCH,
            description=f"Strategy adaptation for new regime: {new_regime}",
            parameters={
                'target_regime': new_regime,
                'regime_confidence': regime_confidence,
                'strategy_adaptation': True
            },
            target_components=['trading_strategy', 'risk_management'],
            expected_impact={'regime_fit_improvement': 0.25}
        )
    
    async def _create_health_adaptation_request(
        self, 
        change: Dict[str, Any]
    ) -> AdaptationRequest:
        """Create adaptation request for system health degradation"""
        health_score = change.get('health_score', 1.0)
        
        return AdaptationRequest(
            id=f"health_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
            type=AdaptationType.ARCHITECTURE_CHANGE,
            description=f"Architecture adjustment due to health degradation (score: {health_score:.3f})",
            parameters={
                'health_threshold': 0.8,
                'load_reduction': 0.2,
                'optimization_target': 'system_stability'
            },
            target_components=['system_architecture'],
            expected_impact={'health_improvement': 0.3}
        )
    
    def _calculate_adaptation_priority(self, change: Dict[str, Any]) -> int:
        """Calculate adaptation priority based on change severity"""
        try:
            change_type = change.get('type', 'unknown')
            severity = change.get('severity', 0.0)
            
            # High priority conditions
            if severity > 0.2 or change_type in ['health_degradation', 'critical_performance_loss']:
                return 1
            elif severity > 0.1 or change_type in ['model_drift', 'regime_change']:
                return 2
            else:
                return 3
                
        except Exception as e:
            self.logger.error(f"Priority calculation failed: {e}")
            return 3
    
    async def _process_adaptation_queue(
        self, 
        requests: List[AdaptationRequest]
    ) -> List[AdaptationResult]:
        """Process adaptation requests from queue"""
        try:
            results = []
            
            # Check if we can process new adaptations
            if len(self.active_adaptations) >= self.risk_controls['max_concurrent_adaptations']:
                self.logger.warning("Maximum concurrent adaptations reached")
                return results
            
            # Process each request
            for request in requests[:self.risk_controls['max_concurrent_adaptations'] - len(self.active_adaptations)]:
                try:
                    # Check if enough time has passed since last adaptation
                    if not await self._can_trigger_adaptation(request):
                        continue
                    
                    # Execute adaptation
                    result = await self._execute_adaptation(request)
                    results.append(result)
                    
                    # Add to active adaptations if still processing
                    if result.status in [AdaptationStatus.TESTING, AdaptationStatus.DEPLOYING]:
                        self.active_adaptations[request.id] = result
                    
                except Exception as e:
                    self.logger.error(f"Adaptation execution failed for {request.id}: {e}")
                    results.append(AdaptationResult(
                        request_id=request.id,
                        status=AdaptationStatus.FAILED,
                        start_time=datetime.now(),
                        error_message=str(e)
                    ))
            
            return results
            
        except Exception as e:
            self.logger.error(f"Adaptation queue processing failed: {e}")
            return []
    
    async def _can_trigger_adaptation(self, request: AdaptationRequest) -> bool:
        """Check if adaptation can be triggered based on timing and conditions"""
        try:
            # Check minimum time between adaptations
            if self.adaptation_history:
                last_adaptation = max(self.adaptation_history, key=lambda x: x.start_time)
                time_since_last = (datetime.now() - last_adaptation.start_time).total_seconds()
                
                if time_since_last < self.risk_controls['min_time_between_adaptations']:
                    return False
            
            # Check if we have baseline performance data
            if not self.performance_baseline:
                self.logger.warning("No performance baseline available")
                return False
            
            return True
            
        except Exception as e:
            self.logger.error(f"Adaptation trigger check failed: {e}")
            return False
    
    async def _execute_adaptation(self, request: AdaptationRequest) -> AdaptationResult:
        """Execute a single adaptation"""
        try:
            self.logger.info(f"Executing adaptation: {request.id}")
            
            result = AdaptationResult(
                request_id=request.id,
                status=AdaptationStatus.TESTING,
                start_time=datetime.now(),
                performance_before=await self._get_current_performance()
            )
            
            # Get performance before adaptation
            result.performance_before = await self._get_current_performance()
            
            # Execute adaptation based on type
            if request.type == AdaptationType.PARAMETER_UPDATE:
                await self._execute_parameter_update(request, result)
            elif request.type == AdaptationType.MODEL_REPLACEMENT:
                await self._execute_model_replacement(request, result)
            elif request.type == AdaptationType.STRATEGY_SWITCH:
                await self._execute_strategy_switch(request, result)
            elif request.type == AdaptationType.ARCHITECTURE_CHANGE:
                await self._execute_architecture_change(request, result)
            elif request.type == AdaptationType.THRESHOLD_ADJUSTMENT:
                await self._execute_threshold_adjustment(request, result)
            else:
                raise ValueError(f"Unknown adaptation type: {request.type}")
            
            # Test the adaptation
            await self._test_adaptation(request, result)
            
            # Mark as completed if successful
            if result.status == AdaptationStatus.TESTING:
                result.status = AdaptationStatus.COMPLETED
            
            result.end_time = datetime.now()
            
            # Calculate success score
            await self._calculate_success_score(request, result)
            
            # Add to history
            self.adaptation_history.append(result)
            self.adaptation_metrics['total_adaptations'] += 1
            
            if result.status == AdaptationStatus.COMPLETED:
                self.adaptation_metrics['successful_adaptations'] += 1
            else:
                self.adaptation_metrics['failed_adaptations'] += 1
            
            self.logger.info(f"Adaptation completed: {request.id} - {result.status.value}")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Adaptation execution failed: {e}")
            return AdaptationResult(
                request_id=request.id,
                status=AdaptationStatus.FAILED,
                start_time=datetime.now(),
                end_time=datetime.now(),
                error_message=str(e)
            )
    
    async def _execute_parameter_update(
        self, 
        request: AdaptationRequest, 
        result: AdaptationResult
    ) -> None:
        """Execute parameter update adaptation"""
        try:
            # Simulate parameter update
            tuning_method = request.parameters.get('tuning_method', 'bayesian_optimization')
            
            # Generate new parameters (simulated)
            import random
            random.seed(hash(request.id) % 1000)
            
            new_parameters = {
                f"param_{i}": random.uniform(0.5, 2.0) 
                for i in range(5)
            }
            
            result.changes_applied['new_parameters'] = new_parameters
            result.changes_applied['tuning_method'] = tuning_method
            
            self.logger.debug(f"Parameter update applied: {len(new_parameters)} parameters updated")
            
        except Exception as e:
            raise Exception(f"Parameter update failed: {e}")
    
    async def _execute_model_replacement(
        self, 
        request: AdaptationRequest, 
        result: AdaptationResult
    ) -> None:
        """Execute model replacement adaptation"""
        try:
            # Simulate model replacement
            import random
            random.seed(hash(request.id) % 1000)
            
            new_model_id = f"model_{random.randint(1000, 9999)}"
            model_accuracy = random.uniform(0.7, 0.95)
            
            result.changes_applied['new_model_id'] = new_model_id
            result.changes_applied['model_accuracy'] = model_accuracy
            result.changes_applied['replacement_time'] = datetime.now().isoformat()
            
            self.logger.debug(f"Model replacement applied: {new_model_id}")
            
        except Exception as e:
            raise Exception(f"Model replacement failed: {e}")
    
    async def _execute_strategy_switch(
        self, 
        request: AdaptationRequest, 
        result: AdaptationResult
    ) -> None:
        """Execute strategy switch adaptation"""
        try:
            target_regime = request.parameters.get('target_regime', 'unknown')
            
            # Simulate strategy adaptation
            result.changes_applied['new_regime'] = target_regime
            result.changes_applied['strategy_updated'] = True
            result.changes_applied['regime_confidence'] = request.parameters.get('regime_confidence', 0.5)
            
            self.logger.debug(f"Strategy switch applied for regime: {target_regime}")
            
        except Exception as e:
            raise Exception(f"Strategy switch failed: {e}")
    
    async def _execute_architecture_change(
        self, 
        request: AdaptationRequest, 
        result: AdaptationResult
    ) -> None:
        """Execute architecture change adaptation"""
        try:
            load_reduction = request.parameters.get('load_reduction', 0.1)
            
            result.changes_applied['load_reduction'] = load_reduction
            result.changes_applied['architecture_optimized'] = True
            result.changes_applied['health_threshold'] = request.parameters.get('health_threshold', 0.8)
            
            self.logger.debug(f"Architecture change applied: {load_reduction:.1%} load reduction")
            
        except Exception as e:
            raise Exception(f"Architecture change failed: {e}")
    
    async def _execute_threshold_adjustment(
        self, 
        request: AdaptationRequest, 
        result: AdaptationResult
    ) -> None:
        """Execute threshold adjustment adaptation"""
        try:
            adjustment_factor = request.parameters.get('adjustment_factor', 0.9)
            
            result.changes_applied['threshold_multiplier'] = adjustment_factor
            result.changes_applied['stability_improved'] = True
            
            self.logger.debug(f"Threshold adjustment applied: factor {adjustment_factor}")
            
        except Exception as e:
            raise Exception(f"Threshold adjustment failed: {e}")
    
    async def _test_adaptation(
        self, 
        request: AdaptationRequest, 
        result: AdaptationResult
    ) -> None:
        """Test adaptation before marking as completed"""
        try:
            # Simulate testing period
            await asyncio.sleep(2)  # Short test period
            
            # Get performance after adaptation
            result.performance_after = await self._get_current_performance()
            
            # Check if performance improved
            if result.performance_before and result.performance_after:
                improvement = self._calculate_performance_improvement(
                    result.performance_before, result.performance_after
                )
                
                # Check if improvement meets expectations
                expected_impact = request.expected_impact
                if improvement.get('overall', 0) > 0:
                    result.status = AdaptationStatus.TESTING  # Passed tests
                else:
                    # Trigger rollback if performance degraded
                    self.logger.warning(f"Adaptation {request.id} degraded performance - triggering rollback")
                    await self._rollback_adaptation(request, result)
            
        except Exception as e:
            self.logger.error(f"Adaptation testing failed: {e}")
            result.status = AdaptationStatus.FAILED
            result.error_message = str(e)
    
    async def _rollback_adaptation(
        self, 
        request: AdaptationRequest, 
        result: AdaptationResult
    ) -> None:
        """Rollback adaptation if it fails"""
        try:
            self.logger.info(f"Rolling back adaptation: {request.id}")
            
            # Execute rollback
            rollback_result = await self.rollback_manager.execute_rollback(
                request, result
            )
            
            if rollback_result:
                result.status = AdaptationStatus.ROLLED_BACK
                result.rollback_performed = True
                self.adaptation_metrics['rollback_count'] += 1
                
                self.logger.info(f"Adaptation {request.id} successfully rolled back")
            else:
                result.status = AdaptationStatus.FAILED
                result.error_message = "Rollback failed"
                
        except Exception as e:
            self.logger.error(f"Rollback failed for {request.id}: {e}")
            result.status = AdaptationStatus.FAILED
            result.error_message = f"Rollback error: {str(e)}"
    
    async def _calculate_success_score(
        self, 
        request: AdaptationRequest, 
        result: AdaptationResult
    ) -> None:
        """Calculate success score for adaptation"""
        try:
            if not result.performance_before or not result.performance_after:
                result.success_score = 0.5  # Neutral score
                return
            
            # Calculate performance improvement
            improvement = self._calculate_performance_improvement(
                result.performance_before, result.performance_after
            )
            
            # Calculate success score based on multiple factors
            performance_score = max(0, improvement.get('overall', 0))
            
            # Completion score
            completion_score = 1.0 if result.status == AdaptationStatus.COMPLETED else 0.0
            
            # Speed score (faster is better)
            duration = (result.end_time - result.start_time).total_seconds()
            speed_score = max(0, 1.0 - (duration / 3600))  # 1 hour max for full score
            
            # Combined score
            result.success_score = (
                performance_score * 0.5 + 
                completion_score * 0.3 + 
                speed_score * 0.2
            )
            
        except Exception as e:
            self.logger.error(f"Success score calculation failed: {e}")
            result.success_score = 0.0
    
    def _calculate_performance_improvement(
        self, 
        before: Dict[str, float], 
        after: Dict[str, float]
    ) -> Dict[str, float]:
        """Calculate performance improvement metrics"""
        try:
            improvements = {}
            
            for metric in before.keys():
                if metric in after:
                    before_value = before[metric]
                    after_value = after[metric]
                    
                    if before_value != 0:
                        improvement = (after_value - before_value) / abs(before_value)
                        improvements[metric] = improvement
            
            # Calculate overall improvement
            if improvements:
                improvements['overall'] = sum(improvements.values()) / len(improvements)
            else:
                improvements['overall'] = 0.0
            
            return improvements
            
        except Exception as e:
            self.logger.error(f"Performance improvement calculation failed: {e}")
            return {'overall': 0.0}
    
    async def _get_current_performance(self) -> Dict[str, float]:
        """Get current system performance metrics"""
        try:
            # Simulated performance metrics
            import random
            random.seed(42)
            
            return {
                'accuracy': random.uniform(0.7, 0.95),
                'latency': random.uniform(50, 200),
                'throughput': random.uniform(100, 500),
                'reliability': random.uniform(0.95, 0.99),
                'sharpe_ratio': random.uniform(0.5, 2.0),
                'max_drawdown': random.uniform(0.05, 0.2),
                'win_rate': random.uniform(0.45, 0.65)
            }
            
        except Exception as e:
            self.logger.error(f"Performance retrieval failed: {e}")
            return {}
    
    async def _load_performance_baseline(self) -> None:
        """Load performance baseline from storage"""
        try:
            # Simulated baseline loading
            import random
            random.seed(42)
            
            self.performance_baseline = {
                'accuracy': 0.85,
                'latency': 100.0,
                'throughput': 300.0,
                'reliability': 0.98,
                'sharpe_ratio': 1.2,
                'max_drawdown': 0.1,
                'win_rate': 0.55
            }
            
            self.logger.info("Performance baseline loaded")
            
        except Exception as e:
            self.logger.error(f"Baseline loading failed: {e}")
    
    async def _update_system_state(self, results: List[AdaptationResult]) -> None:
        """Update system state with adaptation results"""
        try:
            for result in results:
                if result.status == AdaptationStatus.COMPLETED:
                    # Update system parameters based on changes
                    for component, changes in result.changes_applied.items():
                        if component not in self.system_state:
                            self.system_state[component] = {}
                        
                        if isinstance(changes, dict):
                            self.system_state[component].update(changes)
            
            self.logger.debug("System state updated with adaptation results")
            
        except Exception as e:
            self.logger.error(f"System state update failed: {e}")
    
    async def _monitor_adaptation_performance(self, results: List[AdaptationResult]) -> None:
        """Monitor adaptation performance"""
        try:
            completed_results = [
                r for r in results 
                if r.status in [AdaptationStatus.COMPLETED, AdaptationStatus.ROLLED_BACK]
            ]
            
            if completed_results:
                # Update adaptation metrics
                total_time = sum([
                    (r.end_time - r.start_time).total_seconds() 
                    for r in completed_results if r.end_time
                ] or [0])
                
                if completed_results:
                    avg_time = total_time / len(completed_results)
                    self.adaptation_metrics['average_success_time'] = avg_time
                
                # Calculate adaptation frequency
                recent_adaptations = [
                    r for r in self.adaptation_history 
                    if (datetime.now() - r.start_time).total_seconds() < 3600  # Last hour
                ]
                
                if recent_adaptations:
                    self.adaptation_metrics['adaptation_frequency'] = len(recent_adaptations) / 3600
            
            self.logger.debug("Adaptation performance monitoring completed")
            
        except Exception as e:
            self.logger.error(f"Adaptation monitoring failed: {e}")
    
    async def _cleanup_completed_adaptations(self) -> None:
        """Clean up completed adaptations from active list"""
        try:
            # Remove completed adaptations from active list
            completed_ids = [
                request_id for request_id, result in self.active_adaptations.items()
                if result.status in [AdaptationStatus.COMPLETED, AdaptationStatus.FAILED, AdaptationStatus.ROLLED_BACK]
            ]
            
            for request_id in completed_ids:
                del self.active_adaptations[request_id]
            
            # Keep only recent history
            cutoff_time = datetime.now() - timedelta(days=7)
            self.adaptation_history = [
                result for result in self.adaptation_history 
                if result.start_time > cutoff_time
            ]
            
            self.logger.debug("Adaptation cleanup completed")
            
        except Exception as e:
            self.logger.error(f"Adaptation cleanup failed: {e}")
    
    async def _adaptation_monitoring_loop(self) -> None:
        """Background loop for monitoring active adaptations"""
        while True:
            try:
                # Monitor active adaptations
                for request_id, result in list(self.active_adaptations.items()):
                    # Check if adaptation has timed out
                    duration = (datetime.now() - result.start_time).total_seconds()
                    
                    if duration > 3600:  # 1 hour timeout
                        self.logger.warning(f"Adaptation {request_id} timed out")
                        await self._rollback_adaptation(
                            AdaptationRequest(id=request_id, type=AdaptationType.PARAMETER_UPDATE, description="timeout"),
                            result
                        )
                
                await asyncio.sleep(60)  # Check every minute
                
            except Exception as e:
                self.logger.error(f"Adaptation monitoring error: {e}")
                await asyncio.sleep(5)
    
    async def get_state(self) -> Dict[str, Any]:
        """Get current adaptation system state"""
        return {
            'active_adaptations': len(self.active_adaptations),
            'queued_adaptations': len(self.adaptation_queue),
            'completed_adaptations': len(self.adaptation_history),
            'metrics': self.adaptation_metrics,
            'system_state': self.system_state,
            'performance_baseline': self.performance_baseline
        }
    
    def get_adaptation_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent adaptation history"""
        recent_history = sorted(
            self.adaptation_history, 
            key=lambda x: x.start_time, 
            reverse=True
        )
        
        return [
            {
                'request_id': result.request_id,
                'status': result.status.value,
                'start_time': result.start_time.isoformat(),
                'duration': (result.end_time - result.start_time).total_seconds() if result.end_time else None,
                'success_score': result.success_score,
                'rollback_performed': result.rollback_performed
            }
            for result in recent_history[:limit]
        ]
