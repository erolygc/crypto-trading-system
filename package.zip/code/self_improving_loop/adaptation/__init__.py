"""
Automated System Adaptation Module
Phase 2: Automated system adaptation and change management
"""

from .automated_adapter import AutomatedSystemAdapter
from .adaptation_strategies import AdaptationStrategy
from .change_detector import ChangeDetector
from .rollback_manager import RollbackManager

__all__ = [
    'AutomatedSystemAdapter',
    'AdaptationStrategy',
    'ChangeDetector',
    'RollbackManager'
]
