"""
Integration Modülü Testleri

Self-Improving Feedback Loop sistemi integration bileşenlerinin testleri.
System integrator ve API interface bileşenlerinin fonksiyonalite testlerini içerir.
"""

import asyncio
import pytest
import json
from unittest.mock import Mock, patch, AsyncMock
from datetime import datetime

from ..integration.system_integrator import (
    BitwisersSystemIntegrator,
    IntegrationStatus,
    ComponentInfo
)

from ..integration.api_interface import (
    SelfImprovingAPIInterface,
    create_api_interface,
    MockOrchestrator,
    APIStatus,
    SystemHealthResponse,
    PerformanceMetricsResponse
)

class TestBitwisersSystemIntegrator:
    """System Integrator test sınıfı"""
    
    @pytest.fixture
    def integrator(self):
        """Test için integrator instance"""
        config = {
            'connection_strategy': 'parallel',
            'health_check_interval_seconds': 30,
            'timeout_seconds': 30
        }
        return BitwisersSystemIntegrator(config)
    
    @pytest.fixture
    def mock_components(self):
        """Mock bileşenler"""
        return {
            'genetic_engine': ComponentInfo(
                name='genetic_engine',
                type='core',
                version='1.0.0',
                status=IntegrationStatus.DISCONNECTED,
                capabilities=['optimization', 'evolution']
            ),
            'meta_learning_engine': ComponentInfo(
                name='meta_learning_engine',
                type='core',
                version='1.0.0',
                status=IntegrationStatus.DISCONNECTED,
                capabilities=['adaptation', 'learning']
            )
        }
    
    def test_initialization(self, integrator):
        """Test başlatma işlemi"""
        assert integrator.config is not None
        assert integrator.connected == False
        assert len(integrator.integration_hooks) >= 0
    
    def test_component_discovery(self, integrator):
        """Test bileşen keşfi"""
        with patch('importlib.import_module') as mock_import:
            # Mock modül
            mock_module = Mock()
            mock_module.__file__ = '/test/path/genetic_engine.py'
            mock_import.return_value = mock_module
            
            # Bileşen keşfi
            integrator._discover_components()
            
            # En az bir bileşen keşfedilmeli (mock modül)
            assert len(integrator.components) >= 0
    
    @pytest.mark.asyncio
    async def test_connect_components(self, integrator):
        """Test bileşen bağlantısı"""
        # Mock bileşenler ekle
        for name in ['test_component_1', 'test_component_2']:
            integrator.components[name] = ComponentInfo(
                name=name,
                type='test',
                version='1.0.0',
                status=IntegrationStatus.DISCONNECTED,
                capabilities=['test_capability']
            )
        
        # Bağlantı kur
        with patch.object(integrator, '_connect_component', new_callable=AsyncMock) as mock_connect:
            mock_connect.return_value = True
            
            result = await integrator.connect_components()
            
            # Her bileşen için bağlantı fonksiyonu çağrılmalı
            assert mock_connect.call_count >= 2
            assert result == True
    
    @pytest.mark.asyncio
    async def test_integration_workflow(self, integrator):
        """Test entegrasyon iş akışları"""
        # Workflow test verisi
        test_data = {
            'current_params': {'learning_rate': 0.001},
            'strategy': 'default',
            'performance_data': [0.8, 0.85, 0.9]
        }
        
        # Hook fonksiyonlarını mock'la
        with patch.object(integrator, '_execute_hook') as mock_hook:
            mock_hook.return_value = {'optimized_params': {'learning_rate': 0.002}}
            
            # Optimizasyon döngüsü iş akışı test et
            result = await integrator.execute_integration_workflow('optimization_cycle', test_data)
            
            assert result is not None
            assert 'optimized_params' in result
            assert 'workflow_status' in result
    
    def test_health_check(self, integrator):
        """Test sağlık kontrolü"""
        # Healthy bileşenler ekle
        integrator.components['test_component'] = ComponentInfo(
            name='test_component',
            type='test',
            version='1.0.0',
            status=IntegrationStatus.CONNECTED,
            capabilities=['test'],
            last_heartbeat=datetime.now()
        )
        
        # Sağlık kontrolü yap
        health_result = asyncio.run(integrator.health_check())
        
        assert health_result['overall_health_score'] > 0
        assert 'healthy_components' in health_result
        assert 'integration_status' in health_result
    
    def test_get_component_status(self, integrator):
        """Test bileşen durumu alma"""
        # Test bileşeni ekle
        integrator.components['test_component'] = ComponentInfo(
            name='test_component',
            type='test',
            version='1.0.0',
            status=IntegrationStatus.CONNECTED,
            capabilities=['test_capability']
        )
        
        # Durum raporu al
        status_report = integrator.get_component_status()
        
        assert 'test_component' in status_report
        assert status_report['test_component']['status'] == 'connected'
        assert status_report['test_component']['capabilities_count'] == 1
    
    def test_get_integration_report(self, integrator):
        """Test entegrasyon raporu"""
        # Test bileşenleri ekle
        integrator.components['test1'] = ComponentInfo(
            name='test1',
            type='test',
            version='1.0.0',
            status=IntegrationStatus.CONNECTED,
            capabilities=['cap1']
        )
        
        integrator.components['test2'] = ComponentInfo(
            name='test2',
            type='test',
            version='1.0.0',
            status=IntegrationStatus.DISCONNECTED,
            capabilities=['cap2']
        )
        
        integrator.connected = True
        
        # Rapor al
        report = integrator.get_integration_report()
        
        assert 'integration_summary' in report
        assert report['integration_summary']['total_components'] == 2
        assert report['integration_summary']['connected_components'] == 1
        assert report['integration_summary']['connection_rate'] == 0.5
        assert report['integration_summary']['integration_status'] == 'active'
    
    @pytest.mark.asyncio
    async def test_disconnect(self, integrator):
        """Test bağlantı kesme"""
        # Test bileşenleri ekle
        for i in range(3):
            integrator.components[f'test_component_{i}'] = ComponentInfo(
                name=f'test_component_{i}',
                type='test',
                version='1.0.0',
                status=IntegrationStatus.CONNECTED,
                capabilities=['test'],
                last_heartbeat=datetime.now()
            )
        
        # Bağlantıyı kes
        await integrator.disconnect()
        
        # Tüm bileşenler DISCONNECTED olmalı
        for component in integrator.components.values():
            assert component.status == IntegrationStatus.DISCONNECTED
        
        assert integrator.connected == False
        assert len(integrator.integration_hooks) == 0

class TestSelfImprovingAPIInterface:
    """API Interface test sınıfı"""
    
    @pytest.fixture
    def api_interface(self):
        """Test için API interface instance"""
        mock_orchestrator = MockOrchestrator()
        return SelfImprovingAPIInterface(mock_orchestrator)
    
    @pytest.fixture
    def mock_orchestrator(self):
        """Mock orchestrator"""
        return MockOrchestrator()
    
    def test_api_initialization(self, api_interface):
        """Test API başlatma"""
        assert api_interface.app is not None
        assert api_interface.connected_clients == []
        assert api_interface.start_time is not None
    
    def test_api_status_response(self, api_interface):
        """Test API status response model"""
        status = APIStatus(
            status="active",
            timestamp=datetime.now(),
            uptime=3600.0
        )
        
        assert status.status == "active"
        assert status.uptime > 0
    
    def test_health_response_model(self):
        """Test health response model"""
        health = SystemHealthResponse(
            overall_health_score=0.85,
            component_status={'core': 'healthy'},
            integration_status='active',
            timestamp=datetime.now()
        )
        
        assert health.overall_health_score == 0.85
        assert health.integration_status == 'active'
    
    def test_performance_metrics_model(self):
        """Test performance metrics response model"""
        metrics = PerformanceMetricsResponse(
            current_metrics={'accuracy': 0.85, 'precision': 0.82},
            historical_data=[{'timestamp': '2024-01-01', 'accuracy': 0.80}],
            trends={'accuracy': 'improving'},
            timestamp=datetime.now()
        )
        
        assert metrics.current_metrics['accuracy'] == 0.85
        assert metrics.trends['accuracy'] == 'improving'
    
    def test_create_api_interface(self):
        """Test API interface factory fonksiyonu"""
        api = create_api_interface()
        
        assert isinstance(api, SelfImprovingAPIInterface)
    
    @pytest.mark.asyncio
    async def test_broadcast_message(self, api_interface):
        """Test WebSocket mesaj broadcast"""
        # Mock WebSocket bağlantıları
        mock_websocket_1 = AsyncMock()
        mock_websocket_2 = AsyncMock()
        
        api_interface.connected_clients = [mock_websocket_1, mock_websocket_2]
        
        # Test mesajı
        test_message = {
            'type': 'test_message',
            'data': {'test': 'data'},
            'timestamp': datetime.now()
        }
        
        # Mesaj gönder
        await api_interface.broadcast_message(test_message)
        
        # Her WebSocket'e mesaj gönderilmeli
        mock_websocket_1.send_json.assert_called_once()
        mock_websocket_2.send_json.assert_called_once()
        
        # Event history'ye eklenmeli
        assert len(api_interface.event_history) == 1
    
    @pytest.mark.asyncio
    async def test_send_system_alert(self, api_interface):
        """Test sistem uyarısı gönderimi"""
        # Mock WebSocket
        mock_websocket = AsyncMock()
        api_interface.connected_clients = [mock_websocket]
        
        # Uyarı gönder
        await api_interface.send_system_alert('error', 'Test error message', 'high')
        
        # WebSocket'e uyarı gönderilmeli
        mock_websocket.send_json.assert_called_once()
        call_args = mock_websocket.send_json.call_args[0][0]
        assert call_args['type'] == 'system_alert'
        assert call_args['data']['alert_type'] == 'error'
        assert call_args['data']['severity'] == 'high'
    
    def test_api_stats(self, api_interface):
        """Test API istatistikleri"""
        # Test verisi ekle
        api_interface.connected_clients = [Mock(), Mock()]
        api_interface.event_history = [{'test': 'event'}] * 5
        
        stats = api_interface.get_api_stats()
        
        assert stats['connected_websockets'] == 2
        assert stats['total_events'] == 5
        assert stats['uptime_seconds'] > 0
        assert stats['endpoints_count'] == 8
    
    @pytest.mark.asyncio
    async def test_websocket_handler(self, api_interface):
        """Test WebSocket handler"""
        # Mock WebSocket
        mock_websocket = AsyncMock()
        mock_websocket.accept = AsyncMock()
        
        # Ping mesajı
        ping_message = json.dumps({
            'type': 'ping',
            'data': {}
        })
        
        # receive_text'i mesaj dönüşü ile mock'la
        mock_websocket.receive_text = AsyncMock(return_value=ping_message)
        
        # WebSocket handler çalıştır (timeout ile)
        try:
            await asyncio.wait_for(
                api_interface.websocket_handler(mock_websocket),
                timeout=0.1
            )
        except asyncio.TimeoutError:
            pass  # Timeout beklenen
        
        # accept ve send_json çağrılmalı
        mock_websocket.accept.assert_called_once()
        mock_websocket.send_json.assert_called()
    
    @pytest.mark.asyncio
    async def test_send_performance_update(self, api_interface):
        """Test performans güncellemesi gönderimi"""
        # Mock WebSocket
        mock_websocket = AsyncMock()
        api_interface.connected_clients = [mock_websocket]
        
        # Performans metrikleri
        metrics = {
            'accuracy': 0.87,
            'learning_rate': 0.001,
            'loss': 0.23
        }
        
        # Performans güncellemesi gönder
        await api_interface.send_performance_update(metrics)
        
        # WebSocket'e mesaj gönderilmeli
        mock_websocket.send_json.assert_called_once()
        call_args = mock_websocket.send_json.call_args[0][0]
        assert call_args['type'] == 'performance_update'
        assert call_args['data']['accuracy'] == 0.87

class TestIntegrationWorkflows:
    """Entegrasyon iş akışları test sınıfı"""
    
    @pytest.fixture
    def integrator(self):
        """Test için integrator"""
        return BitwisersSystemIntegrator()
    
    @pytest.mark.asyncio
    async def test_optimization_cycle_workflow(self, integrator):
        """Test optimizasyon döngüsü iş akışı"""
        # Test verisi
        test_data = {
            'current_params': {'param1': 1.0, 'param2': 2.0},
            'objective': 'maximize_accuracy',
            'performance_data': [0.8, 0.85, 0.9]
        }
        
        # Hook fonksiyonlarını mock'la
        with patch.object(integrator, '_execute_hook') as mock_hook:
            mock_hook.side_effect = [
                {'optimized_params': {'param1': 1.2}, 'fitness_score': 0.9},  # genetic_optimization
                {'adapted_strategy': 'optimized_v2', 'learning_progress': 0.15}  # meta_learning_update
            ]
            
            result = await integrator._optimization_cycle_workflow(test_data)
            
            assert result is not None
            assert 'optimized_params' in result
            assert 'adapted_strategy' in result
            assert 'improvement_score' in result
            assert result['workflow_status'] == 'completed'
    
    @pytest.mark.asyncio
    async def test_learning_adaptation_workflow(self, integrator):
        """Test öğrenme adaptasyonu iş akışı"""
        test_data = {
            'new_data': [1, 2, 3, 4, 5],
            'current_strategy': 'baseline',
            'feedback_data': [0.8, 0.85, 0.9]
        }
        
        with patch.object(integrator, '_execute_hook') as mock_hook:
            mock_hook.side_effect = [
                {'processed_count': 5, 'features_extracted': 25},  # data_processing
                {'adapted_strategy': 'adapted_v1', 'learning_progress': 0.2},  # meta_learning_update
                {'new_strategy': 'adapted_v2', 'adaptation_success': True}  # strategy_adaptation
            ]
            
            result = await integrator._learning_adaptation_workflow(test_data)
            
            assert result is not None
            assert 'new_strategy' in result
            assert 'adaptation_success' in result
            assert 'data_processed' in result
            assert result['workflow_status'] == 'completed'
    
    @pytest.mark.asyncio
    async def test_performance_analysis_workflow(self, integrator):
        """Test performans analizi iş akışı"""
        test_data = {
            'current_params': {'learning_rate': 0.001},
            'performance_data': [0.75, 0.80, 0.85, 0.87]
        }
        
        with patch.object(integrator, '_execute_hook') as mock_hook:
            mock_hook.side_effect = [
                {'feature_importance': [0.8, 0.6, 0.4]},  # feature_engineering
                {'optimized_params': {'learning_rate': 0.002}, 'fitness_score': 0.9}  # genetic_optimization
            ]
            
            result = await integrator._performance_analysis_workflow(test_data)
            
            assert result is not None
            assert 'analysis_metrics' in result
            assert 'optimization_suggestions' in result
            assert 'performance_trend' in result
            assert result['workflow_status'] == 'completed'

if __name__ == "__main__":
    pytest.main([__file__])
