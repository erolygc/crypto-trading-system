"""
Utils Modülü Testleri

Self-Improving Feedback Loop sistemi utility bileşenlerinin testleri.
Config manager, logger ve helpers modüllerinin fonksiyonalite testlerini içerir.
"""

import pytest
import json
import tempfile
import os
import threading
import time
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime, timedelta
from pathlib import Path

from ..utils.config_manager import (
    ConfigManager,
    get_config_manager,
    get_config,
    update_config,
    SystemConfig,
    PipelineConfig,
    ConfigValidationError
)

from ..utils.logger import (
    LoggerManager,
    get_logger_manager,
    get_logger,
    get_performance_logger,
    ContextLogger,
    PerformanceLogger,
    StructuredFormatter,
    TextFormatter
)

from ..utils.helpers import (
    DataValidator,
    DataProcessor,
    MathUtils,
    FileUtils,
    TimeUtils,
    AsyncUtils,
    PerformanceMonitor,
    Timer,
    timer_context,
    Serializer,
    Cache,
    Registry,
    get_cache,
    get_registry,
    get_performance_monitor,
    ValidationError,
    PerformanceError,
    TimerResult,
    MemorySnapshot
)

class TestConfigManager:
    """Config Manager test sınıfı"""
    
    @pytest.fixture
    def temp_config_dir(self):
        """Geçici konfigürasyon dizini"""
        with tempfile.TemporaryDirectory() as temp_dir:
            yield Path(temp_dir)
    
    @pytest.fixture
    def config_manager(self, temp_config_dir):
        """Test için config manager"""
        return ConfigManager(temp_config_dir, auto_load=True)
    
    def test_initialization(self, config_manager):
        """Test başlatma"""
        assert config_manager.config_dir.exists()
        assert len(config_manager._configs) > 0  # Varsayılan konfigürasyonlar yüklenmiş olmalı
        assert len(config_manager._metadata) > 0
    
    def test_get_config(self, config_manager):
        """Test konfigürasyon alma"""
        # Mevcut konfigürasyonları test et
        system_config = config_manager.get_config('system')
        assert system_config is not None
        assert 'debug_mode' in system_config
        
        # Olmayan konfigürasyon için default değer
        missing_config = config_manager.get_config('nonexistent', default='default_value')
        assert missing_config == 'default_value'
    
    def test_get_nested_config(self, config_manager):
        """Test nested konfigürasyon alma"""
        # Nested konfigürasyon değeri al
        debug_mode = config_manager.get_nested_config('system.debug_mode')
        assert debug_mode is not None
        
        # Olmayan nested konfigürasyon için default
        missing_nested = config_manager.get_nested_config('system.nonexistent', default='default')
        assert missing_nested == 'default'
    
    def test_update_config(self, config_manager):
        """Test konfigürasyon güncelleme"""
        # Geçerli konfigürasyon güncelleme
        original_debug = config_manager.get_nested_config('system.debug_mode')
        
        success = config_manager.update_config('system', {'debug_mode': True})
        assert success == True
        
        updated_debug = config_manager.get_nested_config('system.debug_mode')
        assert updated_debug == True
        
        # Metadata güncellenmiş olmalı
        assert config_manager._metadata['system'].updated_at is not None
        
        # Orijinal değere geri dön
        config_manager.update_config('system', {'debug_mode': original_debug})
    
    def test_config_validation(self, config_manager):
        """Test konfigürasyon doğrulama"""
        # Geçersiz konfigürasyon test et (çok düşük worker sayısı)
        with pytest.raises(ConfigValidationError):
            config_manager.update_config('system', {'max_workers': 0})
        
        # Geçersiz memory limit
        with pytest.raises(ConfigValidationError):
            config_manager.update_config('system', {'memory_limit_mb': 50})
    
    def test_environment_override(self, temp_config_dir):
        """Test environment değişken override"""
        # Environment değişkenleri ayarla
        os.environ['SIFL_SYSTEM_DEBUG_MODE'] = 'false'
        os.environ['SIFL_SYSTEM_MAX_WORKERS'] = '8'
        
        # Config manager oluştur (auto_load ile)
        config_manager = ConfigManager(temp_config_dir, auto_load=True)
        
        # Override değerlerini kontrol et
        debug_mode = config_manager.get_nested_config('system.debug_mode')
        max_workers = config_manager.get_nested_config('system.max_workers')
        
        assert debug_mode == False
        assert max_workers == 8
        
        # Environment değişkenlerini temizle
        del os.environ['SIFL_SYSTEM_DEBUG_MODE']
        del os.environ['SIFL_SYSTEM_MAX_WORKERS']
    
    def test_save_config(self, config_manager, temp_config_dir):
        """Test konfigürasyon kaydetme"""
        # Konfigürasyon güncelle
        config_manager.update_config('system', {'debug_mode': True})
        
        # Dosyaya kaydet
        test_file = temp_config_dir / 'system_test.yaml'
        success = config_manager.save_config('system', test_file)
        
        assert success == True
        assert test_file.exists()
        
        # Dosya içeriğini kontrol et
        with open(test_file, 'r') as f:
            content = f.read()
            assert 'debug_mode: true' in content
    
    def test_export_configs(self, config_manager, temp_config_dir):
        """Test konfigürasyon export"""
        # Export dizini oluştur
        export_dir = temp_config_dir / 'export'
        
        # JSON formatında export et
        success = config_manager.export_configs(export_dir, format='json')
        
        assert success == True
        assert export_dir.exists()
        
        # Export edilen dosyaları kontrol et
        exported_files = list(export_dir.glob('*.json'))
        assert len(exported_files) > 0
    
    def test_config_summary(self, config_manager):
        """Test konfigürasyon özeti"""
        summary = config_manager.get_config_summary()
        
        assert 'total_configs' in summary
        assert 'configs' in summary
        assert 'metadata' in summary
        assert 'config_dir' in summary
        assert 'last_updated' in summary
        
        assert summary['total_configs'] > 0
        assert len(summary['configs']) > 0
    
    def test_clone_config(self, config_manager):
        """Test konfigürasyon klonlama"""
        # Sistem konfigürasyonunu klonla
        success = config_manager.clone_config('system', 'system_clone')
        
        assert success == True
        assert 'system_clone' in config_manager._configs
        
        # Klonlanmış konfigürasyon değerleri aynı olmalı
        original_debug = config_manager.get_nested_config('system.debug_mode')
        cloned_debug = config_manager.get_nested_config('system_clone.debug_mode')
        assert original_debug == cloned_debug

class TestLogger:
    """Logger test sınıfı"""
    
    @pytest.fixture
    def temp_log_dir(self):
        """Geçici log dizini"""
        with tempfile.TemporaryDirectory() as temp_dir:
            yield Path(temp_dir)
    
    @pytest.fixture
    def logger_manager(self, temp_log_dir):
        """Test için logger manager"""
        # Log dizinini config'e ekle
        config = {
            'handlers': {
                'file': {
                    'class': 'LogRotationHandler',
                    'filename': str(temp_log_dir / 'test.log'),
                    'maxBytes': 10485760,  # 10MB
                    'backupCount': 2
                }
            }
        }
        return LoggerManager(config)
    
    def test_logger_manager_initialization(self, logger_manager):
        """Test logger manager başlatma"""
        assert logger_manager is not None
        assert len(logger_manager.loggers) >= 0
    
    def test_get_logger(self, logger_manager):
        """Test logger alma"""
        logger = logger_manager.get_logger('test_logger')
        
        assert isinstance(logger, ContextLogger)
        assert 'test_logger' in logger_manager.loggers
    
    def test_get_performance_logger(self, logger_manager):
        """Test performans logger alma"""
        perf_logger = logger_manager.get_performance_logger('test_operation')
        
        assert isinstance(perf_logger, PerformanceLogger)
        assert 'test_operation' in logger_manager.performance_loggers
    
    def test_context_logger(self, logger_manager):
        """Test context logger özellikleri"""
        logger = logger_manager.get_logger('context_test')
        
        # Context bilgilerini ayarla
        logger.set_correlation_id('test-corr-123')
        logger.set_user_id('test-user')
        logger.set_session_id('test-sess-456')
        
        # Log seviyesi testleri
        logger.debug("Debug message", extra_field="test")
        logger.info("Info message")
        logger.warning("Warning message")
        logger.error("Error message")
        logger.critical("Critical message")
        
        # Exception log test
        try:
            raise ValueError("Test exception")
        except ValueError:
            logger.exception("Exception occurred")
    
    def test_performance_logger(self, logger_manager):
        """Test performans logger"""
        perf_logger = logger_manager.get_performance_logger('test_perf')
        
        # Operation timing
        perf_logger.start_operation('test_operation', 'test-corr-123')
        time.sleep(0.01)  # 10ms bekle
        result = perf_logger.end_operation('test_operation', {'test': 'metadata'})
        
        assert result is not None
        assert 'operation' in result
        assert 'duration_ms' in result
        assert result['duration_ms'] > 0
        assert result['correlation_id'] == 'test-corr-123'
        assert result['metadata']['test'] == 'metadata'
    
    def test_performance_logger_with_error(self, logger_manager):
        """Test performans logger hata durumu"""
        perf_logger = logger_manager.get_performance_logger('error_test')
        
        # Bilinmeyen operation
        result = perf_logger.end_operation('unknown_operation')
        assert result is None  # Operation bulunamadığında None döner
    
    def test_timer_context(self):
        """Test timer context manager"""
        with timer_context('test_timer', {'test': 'context'}) as timer:
            time.sleep(0.01)  # 10ms bekle
            elapsed = timer.elapsed
            
        assert elapsed >= 0.01
        assert timer.operation_name == 'test_timer'
    
    def test_structured_formatter(self):
        """Test structured formatter"""
        formatter = StructuredFormatter()
        
        # Mock log record oluştur
        record = Mock()
        record.created = time.time()
        record.levelname = 'INFO'
        record.name = 'test_logger'
        record.getMessage.return_value = 'Test message'
        record.module = 'test_module'
        record.funcName = 'test_function'
        record.lineno = 123
        record.thread = 1234
        record.process = 5678
        
        # Format test
        formatted = formatter.format(record)
        assert isinstance(formatted, str)
        
        # JSON parse edilebilir olmalı
        parsed = json.loads(formatted)
        assert parsed['level'] == 'INFO'
        assert parsed['message'] == 'Test message'
        assert parsed['module'] == 'test_module'
    
    def test_text_formatter(self):
        """Test text formatter"""
        # Renkli formatter
        formatter_colored = TextFormatter(use_colors=True)
        # Düz formatter
        formatter_plain = TextFormatter(use_colors=False)
        
        record = Mock()
        record.created = time.time()
        record.levelname = 'INFO'
        record.name = 'test_logger'
        record.getMessage.return_value = 'Test message'
        record.module = 'test_module'
        record.funcName = 'test_function'
        record.lineno = 123
        record.exc_info = None
        record.stack_info = None
        
        # Format test
        formatted_colored = formatter_colored.format(record)
        formatted_plain = formatter_plain.format(record)
        
        assert isinstance(formatted_colored, str)
        assert isinstance(formatted_plain, str)
        assert 'Test message' in formatted_colored
        assert 'Test message' in formatted_plain
    
    def test_logger_statistics(self, logger_manager):
        """Test logger istatistikleri"""
        # Birkaç logger oluştur
        logger_manager.get_logger('test1')
        logger_manager.get_logger('test2')
        perf_logger = logger_manager.get_performance_logger('perf_test')
        
        stats = logger_manager.get_log_statistics()
        
        assert 'total_loggers' in stats
        assert 'total_performance_loggers' in stats
        assert 'handler_groups' in stats
        assert 'stream_listeners' in stats
        
        assert stats['total_loggers'] >= 2
        assert stats['total_performance_loggers'] >= 1

class TestHelpers:
    """Helpers test sınıfı"""
    
    def test_data_validator(self):
        """Test data validator"""
        validator = DataValidator()
        
        # Required fields validation
        data = {'field1': 'value1', 'field2': 'value2'}
        required_fields = ['field1', 'field2']
        assert validator.validate_required_fields(data, required_fields) == True
        
        # Missing required field
        with pytest.raises(ValidationError):
            validator.validate_required_fields(data, ['field1', 'field3'])
        
        # Data type validation
        type_specs = {'field1': str, 'field2': str}
        assert validator.validate_data_types(data, type_specs) == True
        
        # Wrong data type
        with pytest.raises(ValidationError):
            validator.validate_data_types({'field1': 123}, {'field1': str})
        
        # Range validation
        range_specs = {'field1': (1, 10)}
        assert validator.validate_range({'field1': 5}, range_specs) == True
        
        # Out of range
        with pytest.raises(ValidationError):
            validator.validate_range({'field1': 15}, range_specs)
    
    def test_data_processor(self):
        """Test data processor"""
        processor = DataProcessor()
        
        # Dictionary flattening
        nested_dict = {'a': {'b': {'c': 1}}, 'd': 2}
        flattened = processor.flatten_dict(nested_dict)
        assert 'a.b.c' in flattened
        assert flattened['a.b.c'] == 1
        assert flattened['d'] == 2
        
        # Dictionary unflattening
        unflattened = processor.unflatten_dict(flattened)
        assert unflattened == nested_dict
        
        # Data normalization
        data = [1, 2, 3, 4, 5]
        normalized = processor.normalize_data(data, 'min_max')
        assert len(normalized) == len(data)
        assert min(normalized) == 0.0
        assert max(normalized) == 1.0
        
        # Outlier detection
        data_with_outliers = [1, 2, 3, 4, 5, 100]
        outliers = processor.detect_outliers(data_with_outliers, 'iqr')
        assert len(outliers) == len(data_with_outliers)
        assert outliers[-1] == True  # 100 outlier olmalı
    
    def test_math_utils(self):
        """Test math utilities"""
        math_utils = MathUtils()
        
        # Correlation calculation
        x = [1, 2, 3, 4, 5]
        y = [2, 4, 6, 8, 10]  # Perfect positive correlation
        correlation = math_utils.calculate_correlation(x, y)
        assert abs(correlation - 1.0) < 0.001
        
        # Moving average
        data = [1, 2, 3, 4, 5]
        moving_avg = math_utils.moving_average(data, window_size=3)
        assert len(moving_avg) == len(data)
        assert moving_avg[2] == 2.0  # (1+2+3)/3
        
        # Exponential moving average
        ema = math_utils.exponential_moving_average(data, alpha=0.5)
        assert len(ema) == len(data)
        assert ema[0] == 1.0
        assert ema[1] == 2.0  # 0.5*2 + 0.5*1
    
    def test_file_utils(self):
        """Test file utilities"""
        file_utils = FileUtils()
        
        with tempfile.TemporaryDirectory() as temp_dir:
            # Ensure directory
            test_dir = Path(temp_dir) / 'test_subdir'
            ensured_dir = file_utils.ensure_directory(test_dir)
            assert ensured_dir.exists()
            
            # Safe filename
            unsafe_filename = 'test<>:"/\\|?*file.txt'
            safe_filename = file_utils.safe_filename(unsafe_filename)
            assert '<' not in safe_filename
            assert '>' not in safe_filename
            
            # Get file size (0 bytes for empty file)
            test_file = Path(temp_dir) / 'test.txt'
            test_file.write_text('test content')
            size_mb = file_utils.get_file_size_mb(test_file)
            assert size_mb > 0
    
    def test_time_utils(self):
        """Test time utilities"""
        time_utils = TimeUtils()
        
        # Duration formatting
        assert 's' in time_utils.format_duration(30)  # Seconds
        assert 'm' in time_utils.format_duration(120)  # Minutes
        assert 'h' in time_utils.format_duration(7200)  # Hours
        
        # Timezone aware now
        now = time_utils.get_timezone_aware_now()
        assert now.tzinfo is not None
        
        # Time difference calculation
        start_time = datetime.now()
        time.sleep(0.01)
        diff = time_utils.calculate_time_difference(start_time)
        assert diff.total_seconds() >= 0.01
    
    def test_performance_monitor(self):
        """Test performance monitor"""
        monitor = PerformanceMonitor()
        
        # Record operation
        monitor.record_operation('test_op', 0.1, memory_usage_mb=100.5)
        
        # Get operation stats
        stats = monitor.get_operation_stats('test_op')
        assert stats['count'] == 1
        assert stats['avg_duration'] == 0.1
        assert stats['avg_memory_mb'] == 100.5
        
        # Multiple operations
        monitor.record_operation('test_op', 0.2, memory_usage_mb=101.0)
        monitor.record_operation('test_op', 0.15, memory_usage_mb=99.5)
        
        updated_stats = monitor.get_operation_stats('test_op')
        assert updated_stats['count'] == 3
        assert updated_stats['avg_duration'] == pytest.approx(0.15, rel=1e-1)
    
    def test_timer(self):
        """Test timer"""
        timer = Timer('test_operation', {'test': 'metadata'})
        
        with timer:
            time.sleep(0.01)
            elapsed = timer.elapsed
            
        assert elapsed >= 0.01
        assert timer.operation_name == 'test_operation'
    
    def test_serializer(self):
        """Test serializer"""
        serializer = Serializer()
        
        # JSON serialization
        test_data = {'key': 'value', 'number': 42, 'list': [1, 2, 3]}
        json_str = serializer.to_json(test_data)
        assert isinstance(json_str, str)
        
        # JSON deserialization
        deserialized = serializer.from_json(json_str)
        assert deserialized == test_data
        
        # Base64 encoding/decoding
        test_bytes = b'test data for encoding'
        encoded = serializer.to_base64(test_bytes)
        decoded = serializer.from_base64(encoded)
        assert decoded == test_bytes
    
    def test_cache(self):
        """Test cache"""
        cache = Cache(max_size=3, default_ttl=60)
        
        # Set and get
        cache.set('key1', 'value1')
        assert cache.get('key1') == 'value1'
        
        # TTL test (hızlı test için TTL değeri düşürülmeli)
        cache_with_short_ttl = Cache(max_size=3, default_ttl=1)
        cache_with_short_ttl.set('key2', 'value2')
        time.sleep(0.1)  # 100ms bekle, TTL 1 saniye olduğu için hala geçerli
        assert cache_with_short_ttl.get('key2') == 'value2'
        
        # Delete
        cache.set('key3', 'value3')
        assert cache.delete('key3') == True
        assert cache.get('key3') is None
        assert cache.delete('nonexistent') == False
        
        # Size and keys
        cache.set('key4', 'value4')
        assert cache.size() == 3
        assert len(cache.keys()) == 3
    
    def test_registry(self):
        """Test registry"""
        registry = Registry()
        
        # Register and get
        test_object = {'test': 'data'}
        registry.register('test_key', test_object)
        assert registry.get('test_key') == test_object
        
        # Unregister
        assert registry.unregister('test_key') == True
        assert registry.get('test_key') is None
        assert registry.unregister('nonexistent') == False
        
        # List keys
        registry.register('key1', 'value1')
        registry.register('key2', 'value2')
        keys = registry.list()
        assert 'key1' in keys
        assert 'key2' in keys
        
        # Clear
        registry.clear()
        assert len(registry.list()) == 0
    
    def test_global_instances(self):
        """Test global instances"""
        # Cache
        cache1 = get_cache()
        cache2 = get_cache()
        assert cache1 is cache2  # Aynı instance olmalı
        
        # Registry
        registry1 = get_registry()
        registry2 = get_registry()
        assert registry1 is registry2
        
        # Performance Monitor
        monitor1 = get_performance_monitor()
        monitor2 = get_performance_monitor()
        assert monitor1 is monitor2
    
    @pytest.mark.asyncio
    async def test_async_utils(self):
        """Test async utilities"""
        async_utils = AsyncUtils()
        
        # Test function
        def sync_function(x):
            time.sleep(0.01)
            return x * 2
        
        # Run in executor
        result = await async_utils.run_in_executor(sync_function, 5)
        assert result == 10
        
        # Gather with limit
        async def async_task(x):
            await asyncio.sleep(0.01)
            return x * 2
        
        tasks = [async_task(i) for i in range(5)]
        results = await async_utils.gather_with_limit(tasks, limit=3)
        
        assert len(results) == 5
        assert all(isinstance(r, int) for r in results)
    
    def test_global_config_functions(self, temp_config_dir):
        """Test global config functions"""
        # Environment değişkeni ayarla
        os.environ['SIFL_SYSTEM_DEBUG_MODE'] = 'true'
        
        # Config manager'ı başlat
        config_manager = get_config_manager(temp_config_dir)
        
        # Global config fonksiyonlarını test et
        debug_mode = get_config('system.debug_mode', default=False)
        assert debug_mode == True
        
        # Update config
        success = update_config('system.max_workers', 8)
        assert success == True
        
        updated_workers = get_config('system.max_workers', default=4)
        assert updated_workers == 8
        
        # Environment değişkenini temizle
        del os.environ['SIFL_SYSTEM_DEBUG_MODE']

if __name__ == "__main__":
    pytest.main([__file__])
