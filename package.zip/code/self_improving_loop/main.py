"""
Self-Improving Feedback Loop Ana Giriş Noktası

Bu dosya Bitwisers 2.0 Self-Improving Feedback Loop sisteminin 
ana giriş noktasıdır. Sistemin başlatılması, konfigürasyonu ve 
çeşitli çalışma modları için entry point sağlar.
"""

import asyncio
import argparse
import sys
import os
import logging
from pathlib import Path
from typing import Optional, Dict, Any

# Core imports
from core.orchestrator import SelfImprovingOrchestrator

# Integration imports
from integration.system_integrator import BitwisersSystemIntegrator
from integration.api_interface import start_api_server, create_api_interface

# Utils imports
from utils.config_manager import get_config_manager
from utils.logger import get_logger, get_performance_logger, LoggerManager
from utils.helpers import timer_context, PerformanceContext, get_performance_monitor

class SelfImprovingLoopApplication:
    """
    Self-Improving Feedback Loop uygulama sınıfı
    
    Bu sınıf sistemin başlatılması, konfigürasyonu ve çeşitli çalışma 
    modlarını (standalone, API server, demo mode, test mode) yönetir.
    """
    
    def __init__(self, config_dir: str = "./config", log_level: str = "INFO"):
        """Uygulama başlatıcısı"""
        self.config_dir = Path(config_dir)
        self.log_level = log_level
        
        # Logger sistemi
        self.logger_manager = None
        self.logger = None
        
        # Sistem bileşenleri
        self.config_manager = None
        self.orchestrator = None
        self.system_integrator = None
        self.api_interface = None
        
        # Çalışma modu
        self.running = False
        
        self._initialize_logging()
        self._initialize_config()
    
    def _initialize_logging(self):
        """Logger sistemini başlatır"""
        # Log dizinini oluştur
        log_dir = Path("./logs")
        log_dir.mkdir(exist_ok=True)
        
        # Logger configuration
        log_config = {
            'version': 1,
            'disable_existing_loggers': False,
            'formatters': {
                'text': {
                    'use_colors': True
                },
                'json': {}
            },
            'handlers': {
                'console': {
                    'class': 'logging.StreamHandler',
                    'level': self.log_level,
                    'formatter': 'text',
                    'stream': 'ext://sys.stdout'
                },
                'file': {
                    'class': 'LogRotationHandler',
                    'level': 'DEBUG',
                    'formatter': 'json',
                    'filename': str(log_dir / 'system.log'),
                    'maxBytes': 10485760,  # 10MB
                    'backupCount': 5,
                    'compress': True
                }
            },
            'root': {
                'level': self.log_level,
                'handlers': ['console', 'file']
            },
            'loggers': {
                'self_improving_loop': {
                    'level': self.log_level,
                    'handlers': ['console', 'file'],
                    'propagate': False
                }
            }
        }
        
        # Logger manager'ı başlat
        self.logger_manager = LoggerManager(log_config)
        self.logger = get_logger('main')
    
    def _initialize_config(self):
        """Konfigürasyon sistemini başlatır"""
        self.config_manager = get_config_manager(self.config_dir)
        
        # Varsayılan konfigürasyonları yükle
        default_config = self._get_default_config()
        self._apply_default_config(default_config)
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Varsayılan sistem konfigürasyonunu döndürür"""
        return {
            'system': {
                'system_name': 'SelfImprovingFeedbackLoop',
                'version': '1.0.0',
                'debug_mode': False,
                'log_level': self.log_level,
                'max_workers': 4,
                'memory_limit_mb': 1024,
                'data_directory': './data',
                'cache_directory': './cache',
                'temp_directory': './temp'
            },
            'pipeline': {
                'continuous_learning': {
                    'enabled': True,
                    'learning_interval_minutes': 30,
                    'batch_size': 100,
                    'learning_rate': 0.001,
                    'retention_days': 7
                },
                'data_processor': {
                    'buffer_size': 10000,
                    'processing_threads': 2,
                    'feature_engineering': {
                        'enabled': True,
                        'max_features': 100,
                        'selection_method': 'correlation'
                    }
                },
                'knowledge_manager': {
                    'storage_backend': 'memory',
                    'max_knowledge_items': 1000,
                    'compression_enabled': True,
                    'backup_interval_hours': 24
                }
            },
            'adaptation': {
                'automated_adapter': {
                    'enabled': True,
                    'adaptation_threshold': 0.05,
                    'max_adaptation_frequency': 3600,
                    'rollback_enabled': True
                },
                'change_detector': {
                    'drift_detection': {
                        'enabled': True,
                        'window_size': 1000,
                        'threshold': 0.1
                    },
                    'regime_detection': {
                        'enabled': True,
                        'min_regime_length': 100
                    }
                },
                'rollback_manager': {
                    'max_snapshots': 10,
                    'auto_rollback': False,
                    'snapshot_interval_minutes': 60
                }
            },
            'optimization': {
                'performance_optimizer': {
                    'enabled': True,
                    'optimization_interval_hours': 6,
                    'objectives': ['accuracy', 'speed', 'memory'],
                    'constraints': {
                        'max_optimization_time': 3600,
                        'max_resource_usage': 0.8
                    }
                },
                'parameter_tuner': {
                    'enabled': True,
                    'tuning_methods': ['bayesian', 'genetic'],
                    'bayesian_config': {
                        'sampler': 'TPE',
                        'n_trials': 100,
                        'timeout': 1800
                    },
                    'genetic_config': {
                        'population_size': 50,
                        'generations': 20,
                        'mutation_rate': 0.1
                    }
                }
            },
            'monitoring': {
                'system_monitor': {
                    'enabled': True,
                    'monitoring_interval_seconds': 30,
                    'alert_thresholds': {
                        'cpu_usage': 0.8,
                        'memory_usage': 0.8,
                        'error_rate': 0.05
                    },
                    'notification_channels': ['log', 'websocket']
                },
                'performance_tracker': {
                    'enabled': True,
                    'metrics_retention_days': 30,
                    'reporting_interval_hours': 24,
                    'trend_analysis': {
                        'enabled': True,
                        'lookback_days': 7
                    }
                }
            },
            'integration': {
                'system_integrator': {
                    'enabled': True,
                    'connection_strategy': 'parallel',
                    'health_check_interval_seconds': 60,
                    'timeout_seconds': 30,
                    'retry_attempts': 3
                },
                'bitwisers_components': {
                    'genetic_engine': {
                        'enabled': True,
                        'config': {}
                    },
                    'meta_learning_engine': {
                        'enabled': True,
                        'config': {}
                    },
                    'dvk_engine': {
                        'enabled': True,
                        'config': {}
                    },
                    'strategy_calibration': {
                        'enabled': True,
                        'config': {}
                    }
                }
            },
            'api': {
                'api_interface': {
                    'enabled': True,
                    'host': '0.0.0.0',
                    'port': 8000,
                    'cors_enabled': True,
                    'rate_limiting': {
                        'enabled': False,
                        'requests_per_minute': 100
                    },
                    'websocket': {
                        'enabled': True,
                        'max_connections': 100,
                        'heartbeat_interval': 30
                    }
                }
            },
            'mlflow': {
                'tracking_uri': 'http://localhost:5000',
                'experiment_name': 'self_improving_feedback_loop',
                'artifact_location': './mlartifacts',
                'backend_store_uri': 'sqlite:///mlflow.db',
                'registry_store_uri': 'sqlite:///mlflow_registry.db',
                'create_experiment_if_not_exists': True
            },
            'airflow': {
                'dag_folder': './airflow/dags',
                'schedule_interval': '0 2 * * *',
                'catchup': False,
                'max_active_runs': 1,
                'depends_on_past': False,
                'retries': 1,
                'retry_delay_minutes': 5
            }
        }
    
    def _apply_default_config(self, default_config: Dict[str, Any]):
        """Varsayılan konfigürasyonu uygular"""
        for config_name, config_data in default_config.items():
            # Sadece mevcut olmayan konfigürasyonları ekle
            existing_config = self.config_manager.get_config(config_name)
            if existing_config is None:
                self.config_manager.update_config(config_name, config_data, validate=False)
        
        self.logger.info("Default configuration applied")
    
    async def initialize_system(self):
        """Sistem bileşenlerini başlatır"""
        with PerformanceContext("system_initialization"):
            try:
                self.logger.info("Self-Improving Feedback Loop sistemi başlatılıyor...")
                
                # Ana orchestrator'ı başlat
                orchestrator_config = self.config_manager.get_config('system')
                self.orchestrator = SelfImprovingOrchestrator(orchestrator_config)
                
                # System integrator'ı başlat
                integration_config = self.config_manager.get_config('integration')
                self.system_integrator = BitwisersSystemIntegrator(integration_config)
                
                # API interface'ı başlat
                api_config = self.config_manager.get_config('api')
                self.api_interface = create_api_interface(self.orchestrator, api_config)
                
                self.logger.info("Sistem bileşenleri başarıyla başlatıldı")
                
            except Exception as e:
                self.logger.error(f"Sistem başlatma hatası: {e}")
                raise
    
    async def run_standalone(self):
        """Standalone çalışma modu"""
        self.logger.info("Standalone mode başlatılıyor...")
        
        try:
            await self.initialize_system()
            
            # Ana sistem döngüsünü başlat
            self.running = True
            await self._main_system_loop()
            
        except KeyboardInterrupt:
            self.logger.info("Kullanıcı tarafından durduruldu")
        except Exception as e:
            self.logger.error(f"Standalone mode hatası: {e}")
            raise
        finally:
            await self.cleanup()
    
    async def run_api_server(self, host: str = "0.0.0.0", port: int = 8000):
        """API Server çalışma modu"""
        self.logger.info(f"API Server modu başlatılıyor... {host}:{port}")
        
        try:
            await self.initialize_system()
            
            # API server'ı başlat
            await start_api_server(self.orchestrator, host=host, port=port)
            
        except KeyboardInterrupt:
            self.logger.info("API Server kullanıcı tarafından durduruldu")
        except Exception as e:
            self.logger.error(f"API Server hatası: {e}")
            raise
        finally:
            await self.cleanup()
    
    async def run_demo(self):
        """Demo çalışma modu"""
        self.logger.info("Demo mode başlatılıyor...")
        
        try:
            # Demo'yu import et ve çalıştır
            from demo import SelfImprovingLoopDemo
            
            demo = SelfImprovingLoopDemo(str(self.config_dir), self.log_level)
            await demo.run_full_demo()
            
        except KeyboardInterrupt:
            self.logger.info("Demo kullanıcı tarafından durduruldu")
        except Exception as e:
            self.logger.error(f"Demo hatası: {e}")
            raise
    
    async def run_test(self):
        """Test çalışma modu"""
        self.logger.info("Test mode başlatılıyor...")
        
        try:
            import subprocess
            import sys
            
            # Pytest ile testleri çalıştır
            result = subprocess.run([
                sys.executable, '-m', 'pytest', 
                './tests/', 
                '-v', 
                '--tb=short'
            ], check=True)
            
            self.logger.info("Tüm testler başarıyla geçti")
            
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Test hatası: {e}")
            raise
        except Exception as e:
            self.logger.error(f"Test mode hatası: {e}")
            raise
    
    async def _main_system_loop(self):
        """Ana sistem döngüsü"""
        self.logger.info("Ana sistem döngüsü başlatılıyor...")
        
        # Sistem döngüsü konfigürasyonu
        cycle_interval = 60  # 60 saniye
        integration_interval = 300  # 5 dakika
        
        last_integration = 0
        
        while self.running:
            try:
                with PerformanceContext("main_system_cycle"):
                    # Continuous learning
                    await self._execute_continuous_learning()
                    
                    # Adaptation checks
                    await self._execute_adaptation_checks()
                    
                    # Performance optimization
                    await self._execute_performance_optimization()
                    
                    # System monitoring
                    await self._execute_system_monitoring()
                    
                    # Integration (her 5 dakikada bir)
                    import time
                    current_time = time.time()
                    if current_time - last_integration >= integration_interval:
                        await self._execute_integration_cycle()
                        last_integration = current_time
                
                # Döngü bekleme süresi
                await asyncio.sleep(cycle_interval)
                
            except Exception as e:
                self.logger.error(f"Sistem döngüsü hatası: {e}")
                await asyncio.sleep(5)  # Hata durumunda daha sık kontrol
    
    async def _execute_continuous_learning(self):
        """Continuous learning işlemlerini gerçekleştirir"""
        try:
            from pipeline.continuous_learner import ContinuousLearner
            
            # Continuous learner'ı başlat
            pipeline_config = self.config_manager.get_config('pipeline')
            continuous_learner = ContinuousLearner(pipeline_config)
            
            # Learning işlemini başlat
            await continuous_learner.start_learning(
                data_source='system_data',
                learning_type='incremental'
            )
            
        except Exception as e:
            self.logger.error(f"Continuous learning hatası: {e}")
    
    async def _execute_adaptation_checks(self):
        """Adaptasyon kontrollerini gerçekleştirir"""
        try:
            from adaptation.automated_adapter import AutomatedSystemAdapter
            
            adaptation_config = self.config_manager.get_config('adaptation')
            automated_adapter = AutomatedSystemAdapter(adaptation_config)
            
            # Change detection
            await automated_adapter.detect_changes()
            
        except Exception as e:
            self.logger.error(f"Adaptation check hatası: {e}")
    
    async def _execute_performance_optimization(self):
        """Performans optimizasyonunu gerçekleştirir"""
        try:
            from optimization.performance_optimizer import PerformanceOptimizer
            
            optimization_config = self.config_manager.get_config('optimization')
            performance_optimizer = PerformanceOptimizer(optimization_config)
            
            # Performance optimization
            await performance_optimizer.optimize_system()
            
        except Exception as e:
            self.logger.error(f"Performance optimization hatası: {e}")
    
    async def _execute_system_monitoring(self):
        """Sistem monitoring'ini gerçekleştirir"""
        try:
            from monitoring.system_monitor import SystemMonitor
            
            monitoring_config = self.config_manager.get_config('monitoring')
            system_monitor = SystemMonitor(monitoring_config)
            
            # Health check
            await system_monitor.check_system_health()
            
            # Performance metrics
            await system_monitor.collect_performance_metrics()
            
        except Exception as e:
            self.logger.error(f"System monitoring hatası: {e}")
    
    async def _execute_integration_cycle(self):
        """Entegrasyon döngüsünü gerçekleştirir"""
        try:
            # Integration workflow'u çalıştır
            await self.system_integrator.connect_components()
            
            # Integration workflows
            workflows = ['optimization_cycle', 'learning_adaptation']
            for workflow in workflows:
                await self.system_integrator.execute_integration_workflow(
                    workflow_type=workflow,
                    data={}
                )
            
        except Exception as e:
            self.logger.error(f"Integration cycle hatası: {e}")
    
    async def cleanup(self):
        """Sistem kaynaklarını temizler"""
        self.logger.info("Sistem temizliği başlatılıyor...")
        
        try:
            if self.system_integrator:
                await self.system_integrator.disconnect()
            
            if self.orchestrator:
                await self.orchestrator.shutdown()
            
            if self.logger_manager:
                self.logger_manager.cleanup()
            
            self.running = False
            self.logger.info("Sistem temizliği tamamlandı")
            
        except Exception as e:
            self.logger.error(f"Sistem temizliği hatası: {e}")
    
    def show_status(self):
        """Sistem durumunu gösterir"""
        print("\n" + "=" * 50)
        print("Self-Improving Feedback Loop System Status")
        print("=" * 50)
        
        # Configuration summary
        config_summary = self.config_manager.get_config_summary()
        print(f"Total Configurations: {config_summary['total_configs']}")
        print(f"Config Directory: {config_summary['config_dir']}")
        
        # Logger statistics
        if self.logger_manager:
            log_stats = self.logger_manager.get_log_statistics()
            print(f"Active Loggers: {log_stats['total_loggers']}")
            print(f"Log Handler Groups: {log_stats['handler_groups']}")
        
        print("=" * 50 + "\n")

def create_argument_parser() -> argparse.ArgumentParser:
    """Argument parser oluşturur"""
    parser = argparse.ArgumentParser(
        description='Bitwisers 2.0 Self-Improving Feedback Loop System',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Çalışma Modları:
  standalone    Sistem standalone olarak çalışır
  api          API server modu (REST API + WebSocket)
  demo         Demo senaryolarını çalıştırır
  test         Sistem testlerini çalıştırır
  status       Sistem durumunu gösterir

Örnekler:
  python main.py standalone          # Standalone mod
  python main.py api --port 8080     # API server (port 8080)
  python main.py demo                # Demo çalıştır
  python main.py test                # Test çalıştır
  python main.py status              # Durum göster
        """
    )
    
    parser.add_argument(
        'mode',
        choices=['standalone', 'api', 'demo', 'test', 'status'],
        help='Çalışma modu'
    )
    
    parser.add_argument(
        '--config-dir',
        default='./config',
        help='Konfigürasyon dizini (varsayılan: ./config)'
    )
    
    parser.add_argument(
        '--log-level',
        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
        default='INFO',
        help='Log seviyesi (varsayılan: INFO)'
    )
    
    parser.add_argument(
        '--host',
        default='0.0.0.0',
        help='API server host (sadece api modu için)'
    )
    
    parser.add_argument(
        '--port',
        type=int,
        default=8000,
        help='API server port (sadece api modu için)'
    )
    
    return parser

async def main():
    """Ana fonksiyon"""
    parser = create_argument_parser()
    args = parser.parse_args()
    
    try:
        # Uygulamayı oluştur
        app = SelfImprovingLoopApplication(
            config_dir=args.config_dir,
            log_level=args.log_level
        )
        
        # Mod seçimine göre çalıştır
        if args.mode == 'standalone':
            await app.run_standalone()
        
        elif args.mode == 'api':
            await app.run_api_server(host=args.host, port=args.port)
        
        elif args.mode == 'demo':
            await app.run_demo()
        
        elif args.mode == 'test':
            await app.run_test()
        
        elif args.mode == 'status':
            app.show_status()
        
    except KeyboardInterrupt:
        print("\nKullanıcı tarafından durduruldu")
        sys.exit(0)
    except Exception as e:
        print(f"Sistem hatası: {e}")
        sys.exit(1)

if __name__ == "__main__":
    # Ana çalışma
    asyncio.run(main())
