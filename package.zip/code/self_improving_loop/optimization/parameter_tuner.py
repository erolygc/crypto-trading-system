"""
Parameter Tuner
Implements Phase 4: Feedback-driven parameter tuning
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional, Tuple, Union
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
import numpy as np
import pandas as pd
from collections import deque
import json
import os

class TuningAlgorithm(Enum):
    """Types of parameter tuning algorithms"""
    GRID_SEARCH = "grid_search"
    RANDOM_SEARCH = "random_search"
    BAYESIAN_TUNING = "bayesian_tuning"
    HYPEROPT = "hyperopt"
    OPTUNA = "optuna"
    GENETIC_TUNING = "genetic_tuning"

class ParameterType(Enum):
    """Types of parameters"""
    CONTINUOUS = "continuous"
    INTEGER = "integer"
    CATEGORICAL = "categorical"
    BOOLEAN = "boolean"

@dataclass
class ParameterRange:
    """Parameter range specification"""
    name: str
    param_type: ParameterType
    low: Optional[float] = None
    high: Optional[float] = None
    choices: Optional[List[Any]] = None
    default: Optional[Any] = None
    step: Optional[float] = None

@dataclass
class TuningResult:
    """Result of parameter tuning"""
    algorithm: TuningAlgorithm
    best_parameters: Dict[str, Any]
    best_score: float
    tuning_history: List[Dict[str, Any]]
    convergence_achieved: bool
    tuning_time: float
    iterations_completed: int
    parameter_importance: Dict[str, float]
    confidence_intervals: Dict[str, Tuple[float, float]]
    performance_metrics: Dict[str, float]
    timestamp: datetime = field(default_factory=datetime.now)

@dataclass
class TuningRequest:
    """Request for parameter tuning"""
    id: str
    algorithm: TuningAlgorithm
    parameter_ranges: List[ParameterRange]
    objective_function: str
    evaluation_metric: str
    max_iterations: int = 100
    validation_method: str = "cross_validation"
    tuning_config: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)

class ParameterTuner:
    """
    Parameter Tuner for Phase 4
    Implements feedback-driven parameter tuning using multiple algorithms
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Tuning state
        self.active_tunings: Dict[str, TuningRequest] = {}
        self.tuning_results: List[TuningResult] = []
        self.tuning_history = deque(maxlen=1000)
        
        # Parameter management
        self.parameter_registry: Dict[str, ParameterRange] = {}
        self.tuned_parameters_history: List[Dict[str, Any]] = []
        
        # Performance tracking
        self.tuning_metrics = {
            'total_tunings': 0,
            'successful_tunings': 0,
            'failed_tunings': 0,
            'average_improvement': 0.0,
            'parameter_stability': 0.0,
            'tuning_frequency': 0.0
        }
        
        # Algorithm configurations
        self.algorithm_configs = {
            TuningAlgorithm.GRID_SEARCH: {
                'grid_density': 'medium',  # low, medium, high
                'parallel_evaluation': True,
                'early_stopping': True
            },
            TuningAlgorithm.RANDOM_SEARCH: {
                'random_samples': 100,
                'sampling_strategy': 'uniform',
                'parallel_evaluation': True
            },
            TuningAlgorithm.BAYESIAN_TUNING: {
                'acquisition_function': 'expected_improvement',
                'initial_samples': 10,
                'n_calls': 100,
                'alpha': 1e-3
            },
            TuningAlgorithm.HYPEROPT: {
                'max_evals': 100,
                'algo': 'tpe',
                'space': {},
                'trials': None
            },
            TuningAlgorithm.OPTUNA: {
                'n_trials': 100,
                'sampler': 'TPE',
                'pruner': 'Median',
                'direction': 'maximize'
            },
            TuningAlgorithm.GENETIC_TUNING: {
                'population_size': 50,
                'generations': 50,
                'mutation_rate': 0.1,
                'crossover_rate': 0.8,
                'elitism_rate': 0.1
            }
        }
        
        # Tuning settings
        self.tuning_settings = {
            'max_concurrent_tunings': 2,
            'default_timeout': 3600,  # 1 hour
            'convergence_threshold': 0.001,
            'stability_window': 10,
            'parameter_change_threshold': 0.05,
            'auto_tuning_enabled': True
        }
        
        self.logger.info("Parameter Tuner initialized")
    
    async def initialize(self) -> None:
        """Initialize the parameter tuner"""
        try:
            # Load parameter registry
            await self._load_parameter_registry()
            
            # Start background monitoring
            asyncio.create_task(self._tuning_monitoring_loop())
            
            # Start auto-tuning if enabled
            if self.tuning_settings['auto_tuning_enabled']:
                asyncio.create_task(self._auto_tuning_loop())
            
            self.logger.info("Parameter Tuner initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize tuner: {e}")
            raise
    
    async def run_tuning_cycle(self) -> Dict[str, Any]:
        """Execute one tuning cycle"""
        try:
            self.logger.info("Starting parameter tuning cycle")
            
            cycle_results = {
                'cycle_id': f"tuning_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                'timestamp': datetime.now().isoformat(),
                'status': 'started',
                'tunings_performed': 0,
                'parameter_updates': {},
                'stability_metrics': {}
            }
            
            # Step 1: Analyze parameter stability
            stability_analysis = await self._analyze_parameter_stability()
            
            # Step 2: Identify parameters requiring tuning
            tuning_opportunities = await self._identify_tuning_opportunities(stability_analysis)
            
            # Step 3: Execute tunings
            if tuning_opportunities:
                tuning_results = await self._execute_tunings(tuning_opportunities)
                
                cycle_results.update({
                    'status': 'completed',
                    'tunings_performed': len(tuning_results),
                    'tunings': tuning_results,
                    'stability_analysis': stability_analysis,
                    'parameter_updates': {
                        f"param_{result.algorithm.value}": result.best_parameters
                        for result in tuning_results
                    }
                })
            else:
                cycle_results.update({
                    'status': 'completed',
                    'tunings_performed': 0,
                    'message': 'No parameters requiring tuning identified',
                    'stability_analysis': stability_analysis
                })
            
            # Step 4: Update parameter registry
            await self._update_parameter_registry(cycle_results)
            
            self.logger.info(f"Tuning cycle completed: {cycle_results['tunings_performed']} tunings performed")
            
            return cycle_results
            
        except Exception as e:
            self.logger.error(f"Tuning cycle failed: {e}")
            return {
                'cycle_id': 'failed',
                'status': 'failed',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    async def _analyze_parameter_stability(self) -> Dict[str, Any]:
        """Analyze parameter stability over time"""
        try:
            stability_analysis = {
                'unstable_parameters': [],
                'stable_parameters': [],
                'parameter_drift': {},
                'stability_scores': {},
                'overall_stability': 1.0
            }
            
            if len(self.tuned_parameters_history) < self.tuning_settings['stability_window']:
                # Not enough history for stability analysis
                return stability_analysis
            
            recent_history = list(self.tuned_parameters_history)[-self.tuning_settings['stability_window']:]
            
            # Analyze each parameter
            all_parameter_names = set()
            for history_entry in recent_history:
                if 'parameters' in history_entry:
                    all_parameter_names.update(history_entry['parameters'].keys())
            
            for param_name in all_parameter_names:
                # Get parameter values over time
                param_values = []
                for history_entry in recent_history:
                    if 'parameters' in history_entry and param_name in history_entry['parameters']:
                        param_values.append(history_entry['parameters'][param_name])
                
                if len(param_values) >= 2:
                    # Calculate stability metrics
                    if isinstance(param_values[0], (int, float)):
                        # Numerical parameter
                        stability_score = self._calculate_numerical_stability(param_values)
                        drift_magnitude = np.std(param_values) / np.mean(param_values) if np.mean(param_values) != 0 else 0
                    else:
                        # Categorical parameter
                        stability_score = self._calculate_categorical_stability(param_values)
                        drift_magnitude = 1.0 - stability_score
                    
                    stability_analysis['stability_scores'][param_name] = stability_score
                    stability_analysis['parameter_drift'][param_name] = drift_magnitude
                    
                    # Classify parameter stability
                    if stability_score < 0.8:
                        stability_analysis['unstable_parameters'].append({
                            'name': param_name,
                            'stability_score': stability_score,
                            'drift_magnitude': drift_magnitude
                        })
                    else:
                        stability_analysis['stable_parameters'].append({
                            'name': param_name,
                            'stability_score': stability_score,
                            'drift_magnitude': drift_magnitude
                        })
            
            # Calculate overall stability
            if stability_analysis['stability_scores']:
                stability_analysis['overall_stability'] = np.mean(list(stability_analysis['stability_scores'].values()))
            
            self.logger.debug(f"Stability analysis: {len(stability_analysis['unstable_parameters'])} unstable parameters")
            
            return stability_analysis
            
        except Exception as e:
            self.logger.error(f"Stability analysis failed: {e}")
            return {'unstable_parameters': []}
    
    def _calculate_numerical_stability(self, values: List[float]) -> float:
        """Calculate stability score for numerical parameters"""
        try:
            if len(values) < 2:
                return 1.0
            
            # Calculate coefficient of variation
            mean_val = np.mean(values)
            std_val = np.std(values)
            
            if mean_val == 0:
                return 1.0 if std_val == 0 else 0.0
            
            cv = std_val / abs(mean_val)
            
            # Convert to stability score (1.0 = perfectly stable, 0.0 = highly unstable)
            stability_score = max(0.0, 1.0 - cv)
            
            return stability_score
            
        except Exception as e:
            self.logger.error(f"Numerical stability calculation failed: {e}")
            return 0.5
    
    def _calculate_categorical_stability(self, values: List[Any]) -> float:
        """Calculate stability score for categorical parameters"""
        try:
            if len(values) < 2:
                return 1.0
            
            # Count frequency of each value
            value_counts = pd.Series(values).value_counts()
            
            # Stability is the proportion of the most frequent value
            most_frequent_count = value_counts.iloc[0]
            total_count = len(values)
            
            stability_score = most_frequent_count / total_count
            
            return stability_score
            
        except Exception as e:
            self.logger.error(f"Categorical stability calculation failed: {e}")
            return 0.5
    
    async def _identify_tuning_opportunities(
        self, 
        stability_analysis: Dict[str, Any]
    ) -> List[TuningRequest]:
        """Identify parameters that need tuning based on stability analysis"""
        try:
            opportunities = []
            
            unstable_parameters = stability_analysis.get('unstable_parameters', [])
            
            for param_info in unstable_parameters:
                param_name = param_info['name']
                stability_score = param_info['stability_score']
                drift_magnitude = param_info['drift_magnitude']
                
                # Skip if drift is too small
                if drift_magnitude < self.tuning_settings['parameter_change_threshold']:
                    continue
                
                # Get parameter definition from registry
                param_range = self.parameter_registry.get(param_name)
                if not param_range:
                    continue
                
                # Determine tuning algorithm based on parameter type and instability
                algorithm = self._select_tuning_algorithm(param_range, drift_magnitude)
                
                # Create tuning request
                request = TuningRequest(
                    id=f"tune_{param_name}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                    algorithm=algorithm,
                    parameter_ranges=[param_range],
                    objective_function='parameter_stability',
                    evaluation_metric='stability_score',
                    max_iterations=self._calculate_iterations(drift_magnitude),
                    tuning_config={
                        'target_parameter': param_name,
                        'current_stability': stability_score,
                        'drift_magnitude': drift_magnitude,
                        'tuning_priority': self._calculate_tuning_priority(stability_score, drift_magnitude)
                    }
                )
                
                opportunities.append(request)
            
            # Add multi-parameter tuning opportunities
            if len(unstable_parameters) > 1:
                multi_param_request = await self._create_multi_parameter_tuning_request(unstable_parameters)
                if multi_param_request:
                    opportunities.append(multi_param_request)
            
            self.logger.info(f"Identified {len(opportunities)} tuning opportunities")
            
            return opportunities
            
        except Exception as e:
            self.logger.error(f"Tuning opportunity identification failed: {e}")
            return []
    
    def _select_tuning_algorithm(self, param_range: ParameterRange, drift_magnitude: float) -> TuningAlgorithm:
        """Select optimal tuning algorithm based on parameter characteristics"""
        try:
            # Algorithm selection logic based on parameter type and drift
            if param_range.param_type in [ParameterType.CONTINUOUS, ParameterType.INTEGER]:
                if drift_magnitude > 0.3:  # Large drift - use global search
                    return TuningAlgorithm.GENETIC_TUNING
                elif drift_magnitude > 0.15:  # Medium drift - use Bayesian
                    return TuningAlgorithm.BAYESIAN_TUNING
                else:  # Small drift - use local search
                    return TuningAlgorithm.RANDOM_SEARCH
            elif param_range.param_type == ParameterType.CATEGORICAL:
                if len(param_range.choices or []) <= 5:  # Few choices - use grid search
                    return TuningAlgorithm.GRID_SEARCH
                else:  # Many choices - use random search
                    return TuningAlgorithm.RANDOM_SEARCH
            else:  # Default
                return TuningAlgorithm.BAYESIAN_TUNING
                
        except Exception as e:
            self.logger.error(f"Algorithm selection failed: {e}")
            return TuningAlgorithm.RANDOM_SEARCH  # Default
    
    def _calculate_iterations(self, drift_magnitude: float) -> int:
        """Calculate number of iterations based on drift magnitude"""
        try:
            base_iterations = 50
            
            if drift_magnitude > 0.3:
                return int(base_iterations * 2)
            elif drift_magnitude > 0.15:
                return int(base_iterations * 1.5)
            else:
                return base_iterations
                
        except Exception as e:
            self.logger.error(f"Iteration calculation failed: {e}")
            return 50
    
    def _calculate_tuning_priority(self, stability_score: float, drift_magnitude: float) -> int:
        """Calculate tuning priority (1=high, 2=medium, 3=low)"""
        try:
            instability_score = (1.0 - stability_score) + drift_magnitude
            
            if instability_score > 0.5:
                return 1  # High priority
            elif instability_score > 0.25:
                return 2  # Medium priority
            else:
                return 3  # Low priority
                
        except Exception as e:
            self.logger.error(f"Tuning priority calculation failed: {e}")
            return 2
    
    async def _create_multi_parameter_tuning_request(
        self, 
        unstable_parameters: List[Dict[str, Any]]
    ) -> Optional[TuningRequest]:
        """Create multi-parameter tuning request for correlated parameters"""
        try:
            # Select most unstable parameters for multi-parameter tuning
            sorted_params = sorted(unstable_parameters, key=lambda x: x['drift_magnitude'], reverse=True)
            selected_params = sorted_params[:5]  # Max 5 parameters at once
            
            # Get parameter ranges
            parameter_ranges = []
            for param_info in selected_params:
                param_range = self.parameter_registry.get(param_info['name'])
                if param_range:
                    parameter_ranges.append(param_range)
            
            if len(parameter_ranges) >= 2:
                return TuningRequest(
                    id=f"multi_tune_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                    algorithm=TuningAlgorithm.GENETIC_TUNING,
                    parameter_ranges=parameter_ranges,
                    objective_function='joint_parameter_stability',
                    evaluation_metric='joint_stability_score',
                    max_iterations=100,
                    tuning_config={
                        'target_parameters': [param['name'] for param in selected_params],
                        'tuning_type': 'multi_parameter',
                        'priority': 1
                    }
                )
            
            return None
            
        except Exception as e:
            self.logger.error(f"Multi-parameter tuning request creation failed: {e}")
            return None
    
    async def _execute_tunings(
        self, 
        opportunities: List[TuningRequest]
    ) -> List[TuningResult]:
        """Execute tuning requests"""
        try:
            results = []
            
            # Check if we can process more tunings
            if len(self.active_tunings) >= self.tuning_settings['max_concurrent_tunings']:
                self.logger.warning("Maximum concurrent tunings reached")
                return results
            
            # Process each opportunity
            for opportunity in opportunities[:self.tuning_settings['max_concurrent_tunings'] - len(self.active_tunings)]:
                try:
                    # Execute tuning
                    result = await self._execute_single_tuning(opportunity)
                    
                    if result:
                        results.append(result)
                        self.tuning_results.append(result)
                        self.active_tunings[opportunity.id] = opportunity
                        
                        # Update metrics
                        self.tuning_metrics['total_tunings'] += 1
                        
                        if result.convergence_achieved:
                            self.tuning_metrics['successful_tunings'] += 1
                        else:
                            self.tuning_metrics['failed_tunings'] += 1
                
                except Exception as e:
                    self.logger.error(f"Tuning execution failed for {opportunity.id}: {e}")
            
            return results
            
        except Exception as e:
            self.logger.error(f"Tuning execution failed: {e}")
            return []
    
    async def _execute_single_tuning(self, request: TuningRequest) -> Optional[TuningResult]:
        """Execute a single tuning operation"""
        try:
            self.logger.info(f"Executing tuning: {request.id} using {request.algorithm.value}")
            
            start_time = asyncio.get_event_loop().time()
            
            # Get algorithm configuration
            algorithm_config = self.algorithm_configs.get(request.algorithm, {})
            
            # Execute tuning based on algorithm
            if request.algorithm == TuningAlgorithm.GRID_SEARCH:
                result = await self._execute_grid_search_tuning(request, algorithm_config)
            elif request.algorithm == TuningAlgorithm.RANDOM_SEARCH:
                result = await self._execute_random_search_tuning(request, algorithm_config)
            elif request.algorithm == TuningAlgorithm.BAYESIAN_TUNING:
                result = await self._execute_bayesian_tuning(request, algorithm_config)
            elif request.algorithm == TuningAlgorithm.GENETIC_TUNING:
                result = await self._execute_genetic_tuning(request, algorithm_config)
            elif request.algorithm == TuningAlgorithm.HYPEROPT:
                result = await self._execute_hyperopt_tuning(request, algorithm_config)
            elif request.algorithm == TuningAlgorithm.OPTUNA:
                result = await self._execute_optuna_tuning(request, algorithm_config)
            else:
                raise ValueError(f"Unsupported tuning algorithm: {request.algorithm}")
            
            # Calculate tuning time
            tuning_time = asyncio.get_event_loop().time() - start_time
            result.tuning_time = tuning_time
            
            self.logger.info(f"Tuning completed: {request.id} - Score: {result.best_score:.4f}")
            
            return result
            
        except Exception as e:
            self.logger.error(f"Single tuning execution failed: {e}")
            return None
    
    async def _execute_grid_search_tuning(
        self, 
        request: TuningRequest, 
        config: Dict[str, Any]
    ) -> TuningResult:
        """Execute grid search tuning"""
        try:
            grid_density = config.get('grid_density', 'medium')
            
            # Generate grid points
            grid_points = self._generate_grid_points(request.parameter_ranges, grid_density)
            
            # Evaluate each point
            results = []
            for i, point in enumerate(grid_points):
                score = await self._evaluate_parameter_set(point, request)
                
                result_entry = {
                    'iteration': i,
                    'parameters': point,
                    'score': score,
                    'point_index': i
                }
                results.append(result_entry)
                
                # Early stopping
                if config.get('early_stopping', True) and i >= 10:
                    recent_scores = [r['score'] for r in results[-5:]]
                    if np.std(recent_scores) < self.tuning_settings['convergence_threshold']:
                        break
            
            # Find best result
            best_result = max(results, key=lambda x: x['score'])
            
            # Calculate parameter importance
            parameter_importance = self._calculate_parameter_importance(results)
            
            # Calculate confidence intervals
            confidence_intervals = self._calculate_confidence_intervals(results)
            
            return TuningResult(
                algorithm=request.algorithm,
                best_parameters=best_result['parameters'],
                best_score=best_result['score'],
                tuning_history=results,
                convergence_achieved=self._check_tuning_convergence(results),
                tuning_time=0.0,
                iterations_completed=len(results),
                parameter_importance=parameter_importance,
                confidence_intervals=confidence_intervals,
                performance_metrics={'grid_points_evaluated': len(results)}
            )
            
        except Exception as e:
            self.logger.error(f"Grid search tuning failed: {e}")
            raise
    
    async def _execute_random_search_tuning(
        self, 
        request: TuningRequest, 
        config: Dict[str, Any]
    ) -> TuningResult:
        """Execute random search tuning"""
        try:
            num_samples = config.get('random_samples', 100)
            sampling_strategy = config.get('sampling_strategy', 'uniform')
            
            # Generate random samples
            random_points = self._generate_random_samples(request.parameter_ranges, num_samples)
            
            # Evaluate each sample
            results = []
            for i, point in enumerate(random_points):
                score = await self._evaluate_parameter_set(point, request)
                
                result_entry = {
                    'iteration': i,
                    'parameters': point,
                    'score': score,
                    'sample_index': i
                }
                results.append(result_entry)
            
            # Find best result
            best_result = max(results, key=lambda x: x['score'])
            
            # Calculate parameter importance
            parameter_importance = self._calculate_parameter_importance(results)
            
            return TuningResult(
                algorithm=request.algorithm,
                best_parameters=best_result['parameters'],
                best_score=best_result['score'],
                tuning_history=results,
                convergence_achieved=self._check_tuning_convergence(results),
                tuning_time=0.0,
                iterations_completed=len(results),
                parameter_importance=parameter_importance,
                confidence_intervals={},
                performance_metrics={'samples_evaluated': len(results)}
            )
            
        except Exception as e:
            self.logger.error(f"Random search tuning failed: {e}")
            raise
    
    async def _execute_bayesian_tuning(
        self, 
        request: TuningRequest, 
        config: Dict[str, Any]
    ) -> TuningResult:
        """Execute Bayesian optimization tuning"""
        try:
            n_calls = config.get('n_calls', 100)
            initial_samples = config.get('initial_samples', 10)
            
            # Generate initial random samples
            initial_points = self._generate_random_samples(request.parameter_ranges, initial_samples)
            
            # Evaluate initial points
            results = []
            for i, point in enumerate(initial_points):
                score = await self._evaluate_parameter_set(point, request)
                
                result_entry = {
                    'iteration': i,
                    'parameters': point,
                    'score': score,
                    'is_initial': True
                }
                results.append(result_entry)
            
            # Bayesian optimization iterations
            for i in range(n_calls - initial_samples):
                # Select next point using acquisition function
                next_point = self._select_next_point_bayesian_tuning(
                    results, request.parameter_ranges
                )
                
                # Evaluate next point
                score = await self._evaluate_parameter_set(next_point, request)
                
                result_entry = {
                    'iteration': i + initial_samples,
                    'parameters': next_point,
                    'score': score,
                    'acquisition_value': self._calculate_acquisition_value_tuning(next_point, results)
                }
                results.append(result_entry)
                
                # Early stopping
                if self._check_tuning_convergence(results[-10:]):
                    break
            
            # Find best result
            best_result = max(results, key=lambda x: x['score'])
            
            return TuningResult(
                algorithm=request.algorithm,
                best_parameters=best_result['parameters'],
                best_score=best_result['score'],
                tuning_history=results,
                convergence_achieved=self._check_tuning_convergence(results[-10:]),
                tuning_time=0.0,
                iterations_completed=len(results),
                parameter_importance={},
                confidence_intervals={},
                performance_metrics={'bayesian_evaluations': len(results)}
            )
            
        except Exception as e:
            self.logger.error(f"Bayesian tuning failed: {e}")
            raise
    
    async def _execute_genetic_tuning(
        self, 
        request: TuningRequest, 
        config: Dict[str, Any]
    ) -> TuningResult:
        """Execute genetic algorithm tuning"""
        try:
            population_size = config.get('population_size', 50)
            generations = config.get('generations', 50)
            mutation_rate = config.get('mutation_rate', 0.1)
            crossover_rate = config.get('crossover_rate', 0.8)
            elitism_rate = config.get('elitism_rate', 0.1)
            
            # Initialize population
            population = self._initialize_tuning_population(request.parameter_ranges, population_size)
            
            results = []
            best_individual = None
            best_score = float('-inf')
            
            for generation in range(generations):
                # Evaluate population
                generation_results = []
                for individual in population:
                    score = await self._evaluate_parameter_set(individual, request)
                    
                    result_entry = {
                        'generation': generation,
                        'individual': individual,
                        'score': score
                    }
                    generation_results.append(result_entry)
                    
                    if score > best_score:
                        best_score = score
                        best_individual = individual.copy()
                
                results.extend(generation_results)
                
                # Early stopping
                if self._check_tuning_convergence(results[-population_size:]):
                    break
                
                # Evolution
                population = self._evolve_tuning_population(
                    population, generation_results, crossover_rate, mutation_rate, elitism_rate
                )
            
            return TuningResult(
                algorithm=request.algorithm,
                best_parameters=best_individual or {},
                best_score=best_score,
                tuning_history=results,
                convergence_achieved=self._check_tuning_convergence(results[-population_size:]),
                tuning_time=0.0,
                iterations_completed=len(set(r['generation'] for r in results)),
                parameter_importance={},
                confidence_intervals={},
                performance_metrics={'generations': len(set(r['generation'] for r in results))}
            )
            
        except Exception as e:
            self.logger.error(f"Genetic tuning failed: {e}")
            raise
    
    async def _execute_hyperopt_tuning(
        self, 
        request: TuningRequest, 
        config: Dict[str, Any]
    ) -> TuningResult:
        """Execute Hyperopt tuning (simplified implementation)"""
        try:
            # This is a simplified Hyperopt-like implementation
            # In practice, would use actual Hyperopt library
            
            max_evals = config.get('max_evals', 100)
            
            # Generate and evaluate samples
            results = []
            for i in range(max_evals):
                # Generate trial parameters
                trial_params = self._generate_random_samples(request.parameter_ranges, 1)[0]
                
                # Evaluate
                score = await self._evaluate_parameter_set(trial_params, request)
                
                results.append({
                    'iteration': i,
                    'parameters': trial_params,
                    'score': score,
                    'trial_id': i
                })
                
                # Early stopping
                if self._check_tuning_convergence(results[-10:]):
                    break
            
            # Find best result
            best_result = max(results, key=lambda x: x['score'])
            
            return TuningResult(
                algorithm=request.algorithm,
                best_parameters=best_result['parameters'],
                best_score=best_result['score'],
                tuning_history=results,
                convergence_achieved=self._check_tuning_convergence(results[-10:]),
                tuning_time=0.0,
                iterations_completed=len(results),
                parameter_importance={},
                confidence_intervals={},
                performance_metrics={'hyperopt_trials': len(results)}
            )
            
        except Exception as e:
            self.logger.error(f"Hyperopt tuning failed: {e}")
            raise
    
    async def _execute_optuna_tuning(
        self, 
        request: TuningRequest, 
        config: Dict[str, Any]
    ) -> TuningResult:
        """Execute Optuna tuning (simplified implementation)"""
        try:
            # This is a simplified Optuna-like implementation
            # In practice, would use actual Optuna library
            
            n_trials = config.get('n_trials', 100)
            
            # Generate and evaluate trials
            results = []
            for i in range(n_trials):
                # Generate trial parameters
                trial_params = self._generate_random_samples(request.parameter_ranges, 1)[0]
                
                # Evaluate
                score = await self._evaluate_parameter_set(trial_params, request)
                
                results.append({
                    'trial': i,
                    'parameters': trial_params,
                    'score': score,
                    'pruned': False
                })
                
                # Early stopping
                if self._check_tuning_convergence(results[-10:]):
                    break
            
            # Find best result
            best_result = max(results, key=lambda x: x['score'])
            
            return TuningResult(
                algorithm=request.algorithm,
                best_parameters=best_result['parameters'],
                best_score=best_result['score'],
                tuning_history=results,
                convergence_achieved=self._check_tuning_convergence(results[-10:]),
                tuning_time=0.0,
                iterations_completed=len(results),
                parameter_importance={},
                confidence_intervals={},
                performance_metrics={'optuna_trials': len(results)}
            )
            
        except Exception as e:
            self.logger.error(f"Optuna tuning failed: {e}")
            raise
    
    # Helper methods for tuning algorithms
    
    def _generate_grid_points(
        self, 
        parameter_ranges: List[ParameterRange], 
        density: str
    ) -> List[Dict[str, Any]]:
        """Generate grid points for grid search"""
        try:
            grid_points = []
            
            # Determine number of grid points per dimension
            if density == 'low':
                points_per_dim = 5
            elif density == 'medium':
                points_per_dim = 10
            else:  # high
                points_per_dim = 20
            
            # Generate points for each parameter
            all_points = []
            for param_range in parameter_ranges:
                param_points = []
                
                if param_range.param_type == ParameterType.CONTINUOUS:
                    if param_range.low is not None and param_range.high is not None:
                        if param_range.step:
                            param_points = np.arange(
                                param_range.low, 
                                param_range.high + param_range.step, 
                                param_range.step
                            ).tolist()
                        else:
                            param_points = np.linspace(
                                param_range.low, 
                                param_range.high, 
                                points_per_dim
                            ).tolist()
                elif param_range.param_type == ParameterType.INTEGER:
                    if param_range.low is not None and param_range.high is not None:
                        param_points = list(range(int(param_range.low), int(param_range.high) + 1))
                elif param_range.param_type == ParameterType.CATEGORICAL:
                    if param_range.choices:
                        param_points = param_range.choices
                elif param_range.param_type == ParameterType.BOOLEAN:
                    param_points = [True, False]
                
                all_points.append(param_points)
            
            # Generate all combinations (Cartesian product)
            import itertools
            for combination in itertools.product(*all_points):
                point = {}
                for i, param_range in enumerate(parameter_ranges):
                    point[param_range.name] = combination[i]
                grid_points.append(point)
            
            return grid_points
            
        except Exception as e:
            self.logger.error(f"Grid point generation failed: {e}")
            return []
    
    def _generate_random_samples(
        self, 
        parameter_ranges: List[ParameterRange], 
        count: int
    ) -> List[Dict[str, Any]]:
        """Generate random samples for parameter space"""
        try:
            samples = []
            
            for _ in range(count):
                sample = {}
                for param_range in parameter_ranges:
                    if param_range.param_type == ParameterType.CONTINUOUS:
                        if param_range.low is not None and param_range.high is not None:
                            sample[param_range.name] = np.random.uniform(param_range.low, param_range.high)
                        else:
                            sample[param_range.name] = param_range.default or 0.0
                    elif param_range.param_type == ParameterType.INTEGER:
                        if param_range.low is not None and param_range.high is not None:
                            sample[param_range.name] = np.random.randint(int(param_range.low), int(param_range.high) + 1)
                        else:
                            sample[param_range.name] = param_range.default or 0
                    elif param_range.param_type == ParameterType.CATEGORICAL:
                        if param_range.choices:
                            sample[param_range.name] = np.random.choice(param_range.choices)
                        else:
                            sample[param_range.name] = param_range.default
                    elif param_range.param_type == ParameterType.BOOLEAN:
                        sample[param_range.name] = np.random.choice([True, False])
                
                samples.append(sample)
            
            return samples
            
        except Exception as e:
            self.logger.error(f"Random sample generation failed: {e}")
            return []
    
    async def _evaluate_parameter_set(
        self, 
        parameters: Dict[str, Any], 
        request: TuningRequest
    ) -> float:
        """Evaluate a parameter set"""
        try:
            # This would call the actual objective function
            # For now, simulate evaluation based on parameter values
            
            base_score = 1.0
            
            # Apply penalties/bonuses based on parameter values
            for param_name, value in parameters.items():
                param_range = next((pr for pr in request.parameter_ranges if pr.name == param_name), None)
                if param_range:
                    if param_range.param_type == ParameterType.CONTINUOUS:
                        # Penalty for extreme values
                        if param_range.low is not None and param_range.high is not None:
                            range_size = param_range.high - param_range.low
                            center = (param_range.low + param_range.high) / 2
                            distance_from_center = abs(value - center)
                            penalty = distance_from_center / (range_size / 2) if range_size > 0 else 0
                            base_score -= penalty * 0.1
                    elif param_range.param_type == ParameterType.INTEGER:
                        # Slight bonus for integer parameters in middle range
                        if param_range.low is not None and param_range.high is not None:
                            center = (param_range.low + param_range.high) / 2
                            distance_from_center = abs(value - center)
                            base_score -= distance_from_center * 0.01
            
            # Add noise to simulate real evaluation
            noise = np.random.normal(0, 0.01)
            score = max(0.0, base_score + noise)
            
            return score
            
        except Exception as e:
            self.logger.error(f"Parameter evaluation failed: {e}")
            return 0.0
    
    def _calculate_parameter_importance(self, results: List[Dict[str, Any]]) -> Dict[str, float]:
        """Calculate parameter importance from tuning results"""
        try:
            if not results:
                return {}
            
            parameter_names = set()
            for result in results:
                if 'parameters' in result:
                    parameter_names.update(result['parameters'].keys())
            
            importance_scores = {}
            
            for param_name in parameter_names:
                # Calculate correlation between parameter value and score
                param_values = []
                scores = []
                
                for result in results:
                    if 'parameters' in result and param_name in result['parameters'] and 'score' in result:
                        param_values.append(result['parameters'][param_name])
                        scores.append(result['score'])
                
                if len(param_values) > 1:
                    # Calculate correlation coefficient
                    correlation = np.corrcoef(param_values, scores)[0, 1] if len(set(param_values)) > 1 else 0
                    importance_scores[param_name] = abs(correlation)
                else:
                    importance_scores[param_name] = 0.0
            
            return importance_scores
            
        except Exception as e:
            self.logger.error(f"Parameter importance calculation failed: {e}")
            return {}
    
    def _calculate_confidence_intervals(
        self, 
        results: List[Dict[str, Any]]
    ) -> Dict[str, Tuple[float, float]]:
        """Calculate confidence intervals for parameters"""
        try:
            if not results:
                return {}
            
            confidence_intervals = {}
            parameter_names = set()
            for result in results:
                if 'parameters' in result:
                    parameter_names.update(result['parameters'].keys())
            
            for param_name in parameter_names:
                param_values = []
                for result in results:
                    if 'parameters' in result and param_name in result['parameters']:
                        param_values.append(result['parameters'][param_name])
                
                if param_values:
                    mean_val = np.mean(param_values)
                    std_val = np.std(param_values)
                    ci_lower = mean_val - 1.96 * std_val  # 95% CI
                    ci_upper = mean_val + 1.96 * std_val
                    confidence_intervals[param_name] = (ci_lower, ci_upper)
            
            return confidence_intervals
            
        except Exception as e:
            self.logger.error(f"Confidence interval calculation failed: {e}")
            return {}
    
    def _check_tuning_convergence(self, recent_results: List[Dict[str, Any]]) -> bool:
        """Check if tuning has converged"""
        try:
            if len(recent_results) < 5:
                return False
            
            # Check if score improvement has stagnated
            scores = [r.get('score', 0) for r in recent_results]
            if len(scores) >= 5:
                score_variance = np.var(scores[-5:])
                return score_variance < self.tuning_settings['convergence_threshold']
            return False
            
        except Exception as e:
            self.logger.error(f"Tuning convergence check failed: {e}")
            return False
    
    def _initialize_tuning_population(
        self, 
        parameter_ranges: List[ParameterRange], 
        size: int
    ) -> List[Dict[str, Any]]:
        """Initialize population for genetic tuning"""
        return self._generate_random_samples(parameter_ranges, size)
    
    def _evolve_tuning_population(
        self, 
        population: List[Dict[str, Any]], 
        results: List[Dict[str, Any]],
        crossover_rate: float, 
        mutation_rate: float, 
        elitism_rate: float
    ) -> List[Dict[str, Any]]:
        """Evolve population for genetic tuning"""
        try:
            # Sort by fitness
            sorted_indices = np.argsort([r['score'] for r in results])[::-1]
            
            new_population = []
            
            # Keep elite individuals
            elite_count = max(1, int(len(population) * elitism_rate))
            for i in range(elite_count):
                idx = sorted_indices[i]
                new_population.append(results[idx]['individual'].copy())
            
            # Generate offspring
            while len(new_population) < len(population):
                # Selection (tournament selection)
                parent1 = self._tournament_selection_tuning(population, results)
                parent2 = self._tournament_selection_tuning(population, results)
                
                # Crossover
                if np.random.random() < crossover_rate:
                    offspring1, offspring2 = self._crossover_tuning(parent1, parent2)
                else:
                    offspring1, offspring2 = parent1.copy(), parent2.copy()
                
                # Mutation
                offspring1 = self._mutate_tuning(offspring1, mutation_rate)
                offspring2 = self._mutate_tuning(offspring2, mutation_rate)
                
                new_population.extend([offspring1, offspring2])
            
            return new_population[:len(population)]
            
        except Exception as e:
            self.logger.error(f"Tuning population evolution failed: {e}")
            return population
    
    def _tournament_selection_tuning(
        self, 
        population: List[Dict[str, Any]], 
        results: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Tournament selection for genetic tuning"""
        tournament_size = 3
        tournament_indices = np.random.choice(len(population), tournament_size, replace=False)
        
        tournament_results = [results[i] for i in tournament_indices]
        winner_result = max(tournament_results, key=lambda x: x['score'])
        winner_idx = tournament_indices[tournament_results.index(winner_result)]
        
        return population[winner_idx].copy()
    
    def _crossover_tuning(
        self, 
        parent1: Dict[str, Any], 
        parent2: Dict[str, Any]
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """Crossover for genetic tuning"""
        offspring1, offspring2 = {}, {}
        
        for param_name in parent1.keys():
            if np.random.random() < 0.5:
                offspring1[param_name] = parent1[param_name]
                offspring2[param_name] = parent2[param_name]
            else:
                offspring1[param_name] = parent2[param_name]
                offspring2[param_name] = parent1[param_name]
        
        return offspring1, offspring2
    
    def _mutate_tuning(self, individual: Dict[str, Any], mutation_rate: float) -> Dict[str, Any]:
        """Mutation for genetic tuning"""
        mutated = individual.copy()
        
        for param_name in individual:
            if np.random.random() < mutation_rate:
                # Simple mutation - add small random noise
                if isinstance(individual[param_name], (int, float)):
                    noise = np.random.normal(0, 0.1)
                    mutated[param_name] += noise
        
        return mutated
    
    def _select_next_point_bayesian_tuning(
        self, 
        results: List[Dict[str, Any]], 
        parameter_ranges: List[ParameterRange]
    ) -> Dict[str, Any]:
        """Select next point for Bayesian tuning"""
        # Simplified implementation
        return self._generate_random_samples(parameter_ranges, 1)[0]
    
    def _calculate_acquisition_value_tuning(
        self, 
        point: Dict[str, Any], 
        results: List[Dict[str, Any]]
    ) -> float:
        """Calculate acquisition value for Bayesian tuning"""
        # Simplified implementation
        return abs(np.random.random())
    
    async def _load_parameter_registry(self) -> None:
        """Load parameter registry from configuration"""
        try:
            # Add default parameters to registry
            default_parameters = [
                ParameterRange(
                    name="learning_rate",
                    param_type=ParameterType.CONTINUOUS,
                    low=0.0001,
                    high=0.1,
                    default=0.001,
                    step=None
                ),
                ParameterRange(
                    name="batch_size",
                    param_type=ParameterType.INTEGER,
                    low=16,
                    high=512,
                    default=32
                ),
                ParameterRange(
                    name="optimizer",
                    param_type=ParameterType.CATEGORICAL,
                    choices=["adam", "sgd", "rmsprop"],
                    default="adam"
                ),
                ParameterRange(
                    name="dropout_rate",
                    param_type=ParameterType.CONTINUOUS,
                    low=0.0,
                    high=0.5,
                    default=0.2
                ),
                ParameterRange(
                    name="use_regularization",
                    param_type=ParameterType.BOOLEAN,
                    default=True
                )
            ]
            
            for param in default_parameters:
                self.parameter_registry[param.name] = param
            
            self.logger.info(f"Loaded {len(self.parameter_registry)} parameters into registry")
            
        except Exception as e:
            self.logger.error(f"Parameter registry loading failed: {e}")
    
    async def _update_parameter_registry(self, cycle_results: Dict[str, Any]) -> None:
        """Update parameter registry with tuning results"""
        try:
            # Store tuning results in history
            if 'tunings' in cycle_results:
                for tuning_result in cycle_results['tunings']:
                    if isinstance(tuning_result, TuningResult):
                        self.tuned_parameters_history.append({
                            'timestamp': tuning_result.timestamp,
                            'algorithm': tuning_result.algorithm.value,
                            'parameters': tuning_result.best_parameters,
                            'score': tuning_result.best_score,
                            'iterations': tuning_result.iterations_completed
                        })
                        
                        # Update parameter registry with new values if needed
                        for param_name, value in tuning_result.best_parameters.items():
                            if param_name in self.parameter_registry:
                                self.parameter_registry[param_name].default = value
            
            # Update metrics
            self.tuning_metrics['parameter_stability'] = await self._calculate_overall_stability()
            
            self.logger.debug("Parameter registry updated")
            
        except Exception as e:
            self.logger.error(f"Parameter registry update failed: {e}")
    
    async def _calculate_overall_stability(self) -> float:
        """Calculate overall parameter stability"""
        try:
            if not self.tuned_parameters_history:
                return 1.0
            
            recent_history = list(self.tuned_parameters_history)[-10:]
            
            # Get all parameter names
            all_param_names = set()
            for entry in recent_history:
                if 'parameters' in entry:
                    all_param_names.update(entry['parameters'].keys())
            
            stability_scores = []
            for param_name in all_param_names:
                # Get recent values for this parameter
                recent_values = []
                for entry in recent_history:
                    if 'parameters' in entry and param_name in entry['parameters']:
                        recent_values.append(entry['parameters'][param_name])
                
                if len(recent_values) >= 2:
                    if isinstance(recent_values[0], (int, float)):
                        stability = self._calculate_numerical_stability(recent_values)
                    else:
                        stability = self._calculate_categorical_stability(recent_values)
                    
                    stability_scores.append(stability)
            
            return np.mean(stability_scores) if stability_scores else 1.0
            
        except Exception as e:
            self.logger.error(f"Overall stability calculation failed: {e}")
            return 1.0
    
    async def _tuning_monitoring_loop(self) -> None:
        """Background loop for monitoring tunings"""
        while True:
            try:
                # Monitor active tunings
                current_time = datetime.now()
                
                # Check for timed-out tunings
                timeout_tunings = []
                for tuning_id, request in self.active_tunings.items():
                    age = (current_time - request.created_at).total_seconds()
                    if age > self.tuning_settings['default_timeout']:
                        timeout_tunings.append(tuning_id)
                
                # Remove timed-out tunings
                for tuning_id in timeout_tunings:
                    del self.active_tunings[tuning_id]
                    self.logger.warning(f"Tuning {tuning_id} timed out")
                
                await asyncio.sleep(60)  # Check every minute
                
            except Exception as e:
                self.logger.error(f"Tuning monitoring error: {e}")
                await asyncio.sleep(5)
    
    async def _auto_tuning_loop(self) -> None:
        """Background loop for automatic tuning"""
        while True:
            try:
                # Check if auto-tuning should be triggered
                if self.tuning_metrics.get('parameter_stability', 1.0) < 0.8:
                    self.logger.info("Auto-tuning triggered due to low parameter stability")
                    
                    # Create auto-tuning request
                    auto_request = TuningRequest(
                        id=f"auto_tune_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                        algorithm=TuningAlgorithm.BAYESIAN_TUNING,
                        parameter_ranges=list(self.parameter_registry.values()),
                        objective_function='parameter_stability',
                        evaluation_metric='overall_stability',
                        max_iterations=50,
                        tuning_config={'auto_tuning': True}
                    )
                    
                    # Execute auto-tuning
                    result = await self._execute_single_tuning(auto_request)
                    
                    if result:
                        self.tuning_results.append(result)
                        self.logger.info(f"Auto-tuning completed with score: {result.best_score:.4f}")
                
                await asyncio.sleep(1800)  # Check every 30 minutes
                
            except Exception as e:
                self.logger.error(f"Auto-tuning loop error: {e}")
                await asyncio.sleep(60)
    
    async def get_state(self) -> Dict[str, Any]:
        """Get current tuning state"""
        return {
            'active_tunings': len(self.active_tunings),
            'completed_tunings': len(self.tuning_results),
            'metrics': self.tuning_metrics,
            'parameter_count': len(self.parameter_registry),
            'tuning_history_length': len(self.tuned_parameters_history)
        }
    
    def get_tuning_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get recent tuning history"""
        recent_results = sorted(
            self.tuning_results,
            key=lambda x: x.timestamp,
            reverse=True
        )
        
        return [
            {
                'algorithm': result.algorithm.value,
                'best_score': result.best_score,
                'iterations_completed': result.iterations_completed,
                'convergence_achieved': result.convergence_achieved,
                'tuning_time': result.tuning_time,
                'timestamp': result.timestamp.isoformat()
            }
            for result in recent_results[:limit]
        ]
