"""
Gelişmiş Log Yönetimi

Self-Improving Feedback Loop sistemi için kapsamlı log yönetimi sistemi.
Structured logging, log rotation, multiple output channels, log correlation ID,
performance logging ve real-time log streaming desteği sağlar.
"""

import os
import sys
import json
import logging
import logging.handlers
import asyncio
from typing import Dict, Any, Optional, List, Union
from datetime import datetime, timezone
from pathlib import Path
from dataclasses import dataclass, asdict
from enum import Enum
import threading
import traceback
from contextvars import ContextVar
import uuid
import queue
import gzip

class LogLevel(Enum):
    """Log seviyeleri"""
    DEBUG = "DEBUG"
    INFO = "INFO"
    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"

class LogFormat(Enum):
    """Log format tipleri"""
    TEXT = "text"
    JSON = "json"
    STRUCTURED = "structured"

class LogChannel(Enum):
    """Log kanalları"""
    CONSOLE = "console"
    FILE = "file"
    DATABASE = "database"
    WEBHOOK = "webhook"
    WEBSOCKET = "websocket"
    ELASTICSEARCH = "elasticsearch"

@dataclass
class LogEntry:
    """Log entry veri yapısı"""
    timestamp: datetime
    level: str
    logger_name: str
    message: str
    module: str
    function: str
    line_number: int
    correlation_id: Optional[str] = None
    user_id: Optional[str] = None
    session_id: Optional[str] = None
    performance_metrics: Optional[Dict[str, float]] = None
    extra_fields: Optional[Dict[str, Any]] = None
    exception_info: Optional[str] = None

@dataclass
class PerformanceLogEntry:
    """Performans log entry"""
    operation: str
    duration_ms: float
    memory_usage_mb: float
    cpu_usage_percent: float
    correlation_id: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None

class ContextLogger:
    """
    Context-aware logger that includes correlation IDs and context information
    """
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self._correlation_id_var: ContextVar[Optional[str]] = ContextVar('correlation_id', default=None)
        self._user_id_var: ContextVar[Optional[str]] = ContextVar('user_id', default=None)
        self._session_id_var: ContextVar[Optional[str]] = ContextVar('session_id', default=None)
    
    def set_correlation_id(self, correlation_id: str):
        """Set correlation ID for current context"""
        self._correlation_id_var.set(correlation_id)
    
    def set_user_id(self, user_id: str):
        """Set user ID for current context"""
        self._user_id_var.set(user_id)
    
    def set_session_id(self, session_id: str):
        """Set session ID for current context"""
        self._session_id_var.set(session_id)
    
    def _get_context_info(self) -> Dict[str, str]:
        """Get current context information"""
        return {
            'correlation_id': self._correlation_id_var.get(),
            'user_id': self._user_id_var.get(),
            'session_id': self._session_id_var.get()
        }
    
    def log(self, level: str, message: str, **kwargs):
        """Log with context information"""
        context = self._get_context_info()
        extra = {
            'context': context,
            **kwargs
        }
        self.logger.log(getattr(logging, level.upper()), message, extra=extra)
    
    def debug(self, message: str, **kwargs):
        """Debug level log"""
        self.log('DEBUG', message, **kwargs)
    
    def info(self, message: str, **kwargs):
        """Info level log"""
        self.log('INFO', message, **kwargs)
    
    def warning(self, message: str, **kwargs):
        """Warning level log"""
        self.log('WARNING', message, **kwargs)
    
    def error(self, message: str, **kwargs):
        """Error level log"""
        self.log('ERROR', message, **kwargs)
    
    def critical(self, message: str, **kwargs):
        """Critical level log"""
        self.log('CRITICAL', message, **kwargs)
    
    def exception(self, message: str, exc_info: bool = True, **kwargs):
        """Exception log with traceback"""
        if exc_info:
            kwargs['exc_info'] = sys.exc_info()
        self.log('ERROR', message, **kwargs)

class StructuredFormatter(logging.Formatter):
    """JSON Structured logging formatter"""
    
    def format(self, record: logging.LogRecord) -> str:
        # Base log data
        log_data = {
            'timestamp': datetime.fromtimestamp(record.created, timezone.utc).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno,
            'thread': record.thread,
            'process': record.process
        }
        
        # Add context information if available
        if hasattr(record, 'context') and record.context:
            log_data['context'] = record.context
        
        # Add extra fields
        for key, value in record.__dict__.items():
            if key not in ['name', 'msg', 'args', 'levelname', 'levelno', 'pathname',
                          'filename', 'module', 'lineno', 'funcName', 'created', 'msecs',
                          'relativeCreated', 'thread', 'threadName', 'processName',
                          'process', 'getMessage', 'exc_info', 'exc_text', 'stack_info']:
                log_data[key] = value
        
        # Add exception info if present
        if record.exc_info:
            log_data['exception'] = self.formatException(record.exc_info)
        
        # Add stack info if present
        if record.stack_info:
            log_data['stack_trace'] = record.stack_info
        
        return json.dumps(log_data, ensure_ascii=False)

class TextFormatter(logging.Formatter):
    """Readable text formatter with colors"""
    
    # Color codes for different log levels
    COLORS = {
        'DEBUG': '\033[36m',      # Cyan
        'INFO': '\033[32m',       # Green
        'WARNING': '\033[33m',    # Yellow
        'ERROR': '\033[31m',      # Red
        'CRITICAL': '\033[35m',   # Magenta
    }
    RESET = '\033[0m'
    
    def __init__(self, use_colors: bool = True):
        super().__init__()
        self.use_colors = use_colors and sys.stdout.isatty()
    
    def format(self, record: logging.LogRecord) -> str:
        # Add context information if available
        context_parts = []
        if hasattr(record, 'context') and record.context:
            ctx = record.context
            if ctx.get('correlation_id'):
                context_parts.append(f"corr:{ctx['correlation_id'][:8]}")
            if ctx.get('user_id'):
                context_parts.append(f"user:{ctx['user_id']}")
            if ctx.get('session_id'):
                context_parts.append(f"sess:{ctx['session_id'][:8]}")
        
        context_str = f" [{', '.join(context_parts)}]" if context_parts else ""
        
        # Format the log message
        level_color = self.COLORS.get(record.levelname, '') if self.use_colors else ''
        level_reset = self.RESET if self.use_colors else ''
        
        timestamp = datetime.fromtimestamp(record.created).strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]
        
        base_format = f"{timestamp} {level_color}{record.levelname:<8}{level_reset} {record.name}{context_str}: {record.getMessage()}"
        
        # Add exception info if present
        if record.exc_info:
            base_format += '\n' + self.formatException(record.exc_info)
        
        # Add stack info if present
        if record.stack_info:
            base_format += '\n' + record.stack_info
        
        return base_format

class LogRotationHandler(logging.handlers.RotatingFileHandler):
    """Custom rotating file handler with compression support"""
    
    def __init__(self, filename, mode='a', maxBytes=0, backupCount=0, encoding=None, delay=False,
                 errors=None, compress=True, compress_delay_hours=24):
        super().__init__(filename, mode, maxBytes, backupCount, encoding, delay, errors)
        self.compress = compress
        self.compress_delay_hours = compress_delay_hours
        self.compression_thread = None
    
    def doRollover(self):
        """Override rollover to add compression"""
        super().doRollover()
        
        if self.compress and self.compression_thread is None:
            # Start compression in background thread
            self.compression_thread = threading.Thread(target=self._compress_old_files)
            self.compression_thread.daemon = True
            self.compression_thread.start()
    
    def _compress_old_files(self):
        """Compress old log files"""
        try:
            base_name = Path(self.baseFilename)
            log_dir = base_name.parent
            base_name_stem = base_name.stem
            
            # Find all backup files older than delay
            cutoff_time = datetime.now().timestamp() - (self.compress_delay_hours * 3600)
            
            for log_file in log_dir.glob(f"{base_name_stem}.*"):
                if (log_file.stat().st_mtime < cutoff_time and 
                    log_file.suffix != '.gz' and 
                    log_file.name != base_name.name):
                    
                    try:
                        compressed_file = f"{log_file}.gz"
                        with open(log_file, 'rb') as f_in:
                            with gzip.open(compressed_file, 'wb') as f_out:
                                f_out.writelines(f_in)
                        log_file.unlink()
                    except Exception as e:
                        # Log compression error but don't crash
                        print(f"Log compression error: {e}")
        
        except Exception as e:
            print(f"Log compression thread error: {e}")
        finally:
            self.compression_thread = None

class DatabaseLogHandler(logging.Handler):
    """Database log handler"""
    
    def __init__(self, db_connection, table_name='system_logs'):
        super().__init__()
        self.db_connection = db_connection
        self.table_name = table_name
        self._create_table()
    
    def _create_table(self):
        """Create logs table if not exists"""
        try:
            # This would depend on the specific database being used
            # For SQLite example:
            create_sql = f"""
                CREATE TABLE IF NOT EXISTS {self.table_name} (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME,
                    level TEXT,
                    logger_name TEXT,
                    message TEXT,
                    module TEXT,
                    function TEXT,
                    line_number INTEGER,
                    correlation_id TEXT,
                    user_id TEXT,
                    session_id TEXT,
                    extra_data TEXT,
                    exception_info TEXT
                )
            """
            self.db_connection.execute(create_sql)
            self.db_connection.commit()
        except Exception as e:
            print(f"Database table creation error: {e}")
    
    def emit(self, record: logging.LogRecord):
        """Emit log record to database"""
        try:
            log_entry = self._format_log_entry(record)
            
            insert_sql = f"""
                INSERT INTO {self.table_name} 
                (timestamp, level, logger_name, message, module, function, line_number,
                 correlation_id, user_id, session_id, extra_data, exception_info)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
            
            self.db_connection.execute(insert_sql, log_entry)
            self.db_connection.commit()
        except Exception as e:
            print(f"Database log error: {e}")
    
    def _format_log_entry(self, record: logging.LogRecord) -> tuple:
        """Format log record for database insertion"""
        return (
            datetime.fromtimestamp(record.created).isoformat(),
            record.levelname,
            record.name,
            record.getMessage(),
            record.module,
            record.funcName,
            record.lineno,
            getattr(record, 'context', {}).get('correlation_id'),
            getattr(record, 'context', {}).get('user_id'),
            getattr(record, 'context', {}).get('session_id'),
            json.dumps({k: v for k, v in record.__dict__.items() 
                       if k not in ['name', 'msg', 'args', 'levelname', 'levelno', 'pathname',
                                   'filename', 'module', 'lineno', 'funcName', 'created', 'msecs',
                                   'relativeCreated', 'thread', 'threadName', 'processName',
                                   'process', 'getMessage', 'exc_info', 'exc_text', 'stack_info']}),
            self.format(record) if record.exc_info else None
        )

class WebhookLogHandler(logging.Handler):
    """Webhook log handler for external notifications"""
    
    def __init__(self, webhook_url: str, webhook_headers: Optional[Dict[str, str]] = None):
        super().__init__()
        self.webhook_url = webhook_url
        self.webhook_headers = webhook_headers or {}
    
    def emit(self, record: logging.LogRecord):
        """Send log record to webhook"""
        try:
            import aiohttp
            
            log_data = {
                'timestamp': datetime.fromtimestamp(record.created).isoformat(),
                'level': record.levelname,
                'message': record.getMessage(),
                'logger': record.name,
                'context': getattr(record, 'context', {})
            }
            
            if record.exc_info:
                log_data['exception'] = self.format(record)
            
            # This would need to be made async for proper async handling
            # For now, it's a placeholder implementation
            print(f"Webhook: {self.webhook_url} - {json.dumps(log_data)}")
            
        except Exception as e:
            print(f"Webhook log error: {e}")

class PerformanceLogger:
    """
    Dedicated performance logger for tracking operation timing and resource usage
    """
    
    def __init__(self, logger: ContextLogger):
        self.logger = logger
        self._operation_start_times: Dict[str, float] = {}
    
    def start_operation(self, operation_name: str, correlation_id: Optional[str] = None):
        """Start timing an operation"""
        import psutil
        import os
        
        self._operation_start_times[operation_name] = {
            'start_time': datetime.now().timestamp(),
            'start_memory': psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024,  # MB
            'start_cpu': psutil.cpu_percent(),
            'correlation_id': correlation_id or str(uuid.uuid4())
        }
        
        self.logger.debug(f"Started operation: {operation_name}", 
                         operation=operation_name,
                         correlation_id=self._operation_start_times[operation_name]['correlation_id'])
    
    def end_operation(self, operation_name: str, metadata: Optional[Dict[str, Any]] = None):
        """End timing an operation and log performance metrics"""
        if operation_name not in self._operation_start_times:
            self.logger.warning(f"Operation not found: {operation_name}")
            return
        
        import psutil
        import os
        
        start_info = self._operation_start_times.pop(operation_name)
        
        end_time = datetime.now().timestamp()
        end_memory = psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024  # MB
        end_cpu = psutil.cpu_percent()
        
        duration_ms = (end_time - start_info['start_time']) * 1000
        memory_delta = end_memory - start_info['start_memory']
        
        performance_data = {
            'operation': operation_name,
            'duration_ms': duration_ms,
            'memory_usage_mb': end_memory,
            'memory_delta_mb': memory_delta,
            'cpu_usage_percent': end_cpu,
            'correlation_id': start_info['correlation_id']
        }
        
        if metadata:
            performance_data['metadata'] = metadata
        
        # Log performance metrics
        self.logger.info(f"Operation completed: {operation_name} ({duration_ms:.2f}ms)",
                        performance=performance_data)
        
        return performance_data
    
    def log_custom_metrics(self, metrics: Dict[str, float], correlation_id: Optional[str] = None):
        """Log custom performance metrics"""
        self.logger.info("Custom performance metrics", 
                        custom_metrics=metrics,
                        correlation_id=correlation_id)

class LoggerManager:
    """
    Comprehensive logger management system
    
    Provides:
    - Multiple log formats (text, JSON, structured)
    - Multiple output channels (console, file, database, webhook, websocket)
    - Log rotation and compression
    - Performance logging
    - Context-aware logging with correlation IDs
    - Real-time log streaming
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or self._get_default_config()
        self.loggers: Dict[str, ContextLogger] = {}
        self.performance_loggers: Dict[str, PerformanceLogger] = {}
        self.log_handlers: Dict[str, List[logging.Handler]] = {}
        self.log_queue = queue.Queue()
        self.log_stream_listeners: List[callable] = []
        
        # Initialize logging system
        self._setup_logging()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default logging configuration"""
        return {
            'version': 1,
            'disable_existing_loggers': False,
            'formatters': {
                'text': {
                    'class': 'TextFormatter',
                    'use_colors': True
                },
                'json': {
                    'class': 'StructuredFormatter'
                }
            },
            'handlers': {
                'console': {
                    'class': 'logging.StreamHandler',
                    'level': 'INFO',
                    'formatter': 'text',
                    'stream': 'ext://sys.stdout'
                },
                'file': {
                    'class': 'LogRotationHandler',
                    'level': 'DEBUG',
                    'formatter': 'json',
                    'filename': './logs/system.log',
                    'maxBytes': 10485760,  # 10MB
                    'backupCount': 5,
                    'compress': True
                }
            },
            'root': {
                'level': 'INFO',
                'handlers': ['console', 'file']
            },
            'loggers': {
                'self_improving_loop': {
                    'level': 'DEBUG',
                    'handlers': ['console', 'file'],
                    'propagate': False
                }
            }
        }
    
    def _setup_logging(self):
        """Setup the logging system"""
        try:
            # Create logs directory
            log_dir = Path("./logs")
            log_dir.mkdir(exist_ok=True)
            
            # Setup root logger
            root_logger = logging.getLogger()
            root_logger.setLevel(getattr(logging, self.config.get('root', {}).get('level', 'INFO')))
            
            # Clear existing handlers
            for handler in root_logger.handlers[:]:
                root_logger.removeHandler(handler)
            
            # Setup handlers
            handlers_config = self.config.get('handlers', {})
            
            for handler_name, handler_config in handlers_config.items():
                try:
                    handler = self._create_handler(handler_name, handler_config)
                    if handler:
                        # Set formatter
                        formatter_name = handler_config.get('formatter', 'text')
                        formatter = self._create_formatter(formatter_name)
                        if formatter:
                            handler.setFormatter(formatter)
                        
                        # Set level
                        level = handler_config.get('level', 'INFO')
                        handler.setLevel(getattr(logging, level))
                        
                        root_logger.addHandler(handler)
                        
                        # Store handler for management
                        if handler_name not in self.log_handlers:
                            self.log_handlers[handler_name] = []
                        self.log_handlers[handler_name].append(handler)
                        
                except Exception as e:
                    print(f"Handler creation error {handler_name}: {e}")
            
            print(f"Logger system initialized with {len(self.log_handlers)} handler groups")
            
        except Exception as e:
            print(f"Logging setup error: {e}")
    
    def _create_handler(self, handler_name: str, handler_config: Dict[str, Any]) -> Optional[logging.Handler]:
        """Create a log handler based on configuration"""
        handler_class = handler_config.get('class', '')
        
        if 'StreamHandler' in handler_class:
            return logging.StreamHandler()
        elif 'LogRotationHandler' in handler_class:
            return LogRotationHandler(
                filename=handler_config.get('filename', './logs/system.log'),
                maxBytes=handler_config.get('maxBytes', 10485760),
                backupCount=handler_config.get('backupCount', 5),
                compress=handler_config.get('compress', True)
            )
        elif 'RotatingFileHandler' in handler_class:
            return logging.handlers.RotatingFileHandler(
                filename=handler_config.get('filename', './logs/system.log'),
                maxBytes=handler_config.get('maxBytes', 10485760),
                backupCount=handler_config.get('backupCount', 5)
            )
        elif 'TimedRotatingFileHandler' in handler_class:
            return logging.handlers.TimedRotatingFileHandler(
                filename=handler_config.get('filename', './logs/system.log'),
                when=handler_config.get('when', 'midnight'),
                interval=handler_config.get('interval', 1),
                backupCount=handler_config.get('backupCount', 5)
            )
        
        return None
    
    def _create_formatter(self, formatter_name: str) -> Optional[logging.Formatter]:
        """Create a log formatter based on configuration"""
        if formatter_name == 'text':
            use_colors = self.config.get('formatters', {}).get('text', {}).get('use_colors', True)
            return TextFormatter(use_colors=use_colors)
        elif formatter_name == 'json':
            return StructuredFormatter()
        
        return None
    
    def get_logger(self, name: str) -> ContextLogger:
        """Get or create a context-aware logger"""
        if name not in self.loggers:
            base_logger = logging.getLogger(name)
            self.loggers[name] = ContextLogger(base_logger)
        
        return self.loggers[name]
    
    def get_performance_logger(self, name: str) -> PerformanceLogger:
        """Get or create a performance logger"""
        if name not in self.performance_loggers:
            context_logger = self.get_logger(f"{name}_performance")
            self.performance_loggers[name] = PerformanceLogger(context_logger)
        
        return self.performance_loggers[name]
    
    def add_log_stream_listener(self, listener: callable):
        """Add a real-time log stream listener"""
        self.log_stream_listeners.append(listener)
    
    def remove_log_stream_listener(self, listener: callable):
        """Remove a log stream listener"""
        if listener in self.log_stream_listeners:
            self.log_stream_listeners.remove(listener)
    
    def stream_log(self, log_entry: LogEntry):
        """Stream log entry to all listeners"""
        for listener in self.log_stream_listeners:
            try:
                listener(log_entry)
            except Exception as e:
                print(f"Log stream listener error: {e}")
    
    def log_system_event(self, event_type: str, message: str, data: Optional[Dict[str, Any]] = None):
        """Log a system event with structured data"""
        logger = self.get_logger('system_events')
        
        event_data = {
            'event_type': event_type,
            'timestamp': datetime.now().isoformat(),
            'data': data or {}
        }
        
        logger.info(message, event=event_data)
    
    def set_log_level(self, logger_name: str, level: str):
        """Set log level for a specific logger"""
        logger = logging.getLogger(logger_name)
        logger.setLevel(getattr(logging, level.upper()))
    
    def get_log_statistics(self) -> Dict[str, Any]:
        """Get logging system statistics"""
        stats = {
            'total_loggers': len(self.loggers),
            'total_performance_loggers': len(self.performance_loggers),
            'handler_groups': len(self.log_handlers),
            'stream_listeners': len(self.log_stream_listeners),
            'active_operations': {},
            'timestamp': datetime.now().isoformat()
        }
        
        # Get handler statistics
        for handler_name, handlers in self.log_handlers.items():
            stats[f'{handler_name}_handlers'] = len(handlers)
        
        return stats
    
    def cleanup(self):
        """Cleanup logging system"""
        try:
            # Close all handlers
            for handlers in self.log_handlers.values():
                for handler in handlers:
                    handler.close()
            
            # Clear loggers
            self.loggers.clear()
            self.performance_loggers.clear()
            self.log_stream_listeners.clear()
            
            print("Logger system cleaned up")
            
        except Exception as e:
            print(f"Logger cleanup error: {e}")

# Global logger manager instance
_global_logger_manager = None

def get_logger_manager(config: Optional[Dict[str, Any]] = None) -> LoggerManager:
    """Get global logger manager instance"""
    global _global_logger_manager
    
    if _global_logger_manager is None:
        _global_logger_manager = LoggerManager(config)
    
    return _global_logger_manager

def get_logger(name: str) -> ContextLogger:
    """Get a logger instance"""
    manager = get_logger_manager()
    return manager.get_logger(name)

def get_performance_logger(name: str) -> PerformanceLogger:
    """Get a performance logger instance"""
    manager = get_logger_manager()
    return manager.get_performance_logger(name)

def log_system_event(event_type: str, message: str, data: Optional[Dict[str, Any]] = None):
    """Log a system event"""
    manager = get_logger_manager()
    manager.log_system_event(event_type, message, data)

# Performance logging decorator
def performance_log(operation_name: str, correlation_id: Optional[str] = None):
    """Decorator for automatic performance logging"""
    def decorator(func):
        async def async_wrapper(*args, **kwargs):
            perf_logger = get_performance_logger(func.__module__)
            perf_logger.start_operation(operation_name, correlation_id)
            try:
                result = await func(*args, **kwargs)
                return result
            finally:
                perf_logger.end_operation(operation_name)
        
        def sync_wrapper(*args, **kwargs):
            perf_logger = get_performance_logger(func.__module__)
            perf_logger.start_operation(operation_name, correlation_id)
            try:
                result = func(*args, **kwargs)
                return result
            finally:
                perf_logger.end_operation(operation_name)
        
        # Return appropriate wrapper based on function type
        import inspect
        if inspect.iscoroutinefunction(func):
            return async_wrapper
        else:
            return sync_wrapper
    
    return decorator

# Context manager for performance logging
class PerformanceContext:
    """Context manager for performance logging"""
    
    def __init__(self, operation_name: str, logger: Optional[ContextLogger] = None, 
                 correlation_id: Optional[str] = None):
        self.operation_name = operation_name
        self.logger = logger or get_logger('performance_context')
        self.correlation_id = correlation_id
        self.perf_logger = get_performance_logger('context')
    
    def __enter__(self):
        self.perf_logger.start_operation(self.operation_name, self.correlation_id)
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.perf_logger.end_operation(self.operation_name)
        if exc_type:
            self.logger.error(f"Operation failed: {self.operation_name}", 
                            exc_info=True,
                            operation=self.operation_name,
                            correlation_id=self.correlation_id)

if __name__ == "__main__":
    # Test the logging system
    import asyncio
    
    async def test_logging():
        # Get logger and performance logger
        logger = get_logger('test')
        perf_logger = get_performance_logger('test')
        
        # Test basic logging
        logger.info("Test log message", extra_field="test_value")
        logger.set_correlation_id("test-correlation-123")
        logger.info("Test log with correlation ID")
        
        # Test performance logging
        with PerformanceContext("test_operation"):
            await asyncio.sleep(0.1)
        
        # Test system event logging
        log_system_event("test_event", "Test system event", {"test": "data"})
        
        # Get statistics
        manager = get_logger_manager()
        stats = manager.get_log_statistics()
        print("Logger Statistics:", json.dumps(stats, indent=2, default=str))
    
    asyncio.run(test_logging())
