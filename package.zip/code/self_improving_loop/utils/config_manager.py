"""
Konfigürasyon Yönetimi

Self-Improving Feedback Loop sistemi için kapsamlı konfigürasyon yönetimi.
JSON/YAML dosyalarından konfigürasyon yükleme, doğrulama, güncelleme ve
environment değişkenleri ile override desteği sağlar.
"""

import os
import json
import yaml
import logging
from typing import Dict, Any, Optional, Union, List
from pathlib import Path
from dataclasses import dataclass, field, asdict
from datetime import datetime
import copy
from enum import Enum

class ConfigValidationError(Exception):
    """Konfigürasyon doğrulama hatası"""
    pass

class ConfigType(Enum):
    """Konfigürasyon tipleri"""
    SYSTEM = "system"
    PIPELINE = "pipeline"
    ADAPTATION = "adaptation"
    OPTIMIZATION = "optimization"
    MONITORING = "monitoring"
    INTEGRATION = "integration"
    API = "api"

@dataclass
class ConfigMetadata:
    """Konfigürasyon metadata bilgileri"""
    name: str
    version: str = "1.0.0"
    description: str = ""
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: Optional[datetime] = None
    author: str = "system"
    tags: List[str] = field(default_factory=list)

@dataclass
class SystemConfig:
    """Ana sistem konfigürasyonu"""
    system_name: str = "SelfImprovingFeedbackLoop"
    version: str = "1.0.0"
    debug_mode: bool = False
    log_level: str = "INFO"
    max_workers: int = 4
    memory_limit_mb: int = 1024
    data_directory: str = "./data"
    cache_directory: str = "./cache"
    temp_directory: str = "./temp"
    
@dataclass
class PipelineConfig:
    """Pipeline konfigürasyonu"""
    continuous_learning: Dict[str, Any] = field(default_factory=lambda: {
        "enabled": True,
        "learning_interval_minutes": 30,
        "batch_size": 100,
        "learning_rate": 0.001,
        "retention_days": 7
    })
    data_processor: Dict[str, Any] = field(default_factory=lambda: {
        "buffer_size": 10000,
        "processing_threads": 2,
        "feature_engineering": {
            "enabled": True,
            "max_features": 100,
            "selection_method": "correlation"
        }
    })
    knowledge_manager: Dict[str, Any] = field(default_factory=lambda: {
        "storage_backend": "memory",
        "max_knowledge_items": 1000,
        "compression_enabled": True,
        "backup_interval_hours": 24
    })

@dataclass
class AdaptationConfig:
    """Adaptasyon konfigürasyonu"""
    automated_adapter: Dict[str, Any] = field(default_factory=lambda: {
        "enabled": True,
        "adaptation_threshold": 0.05,
        "max_adaptation_frequency": 3600,
        "rollback_enabled": True
    })
    change_detector: Dict[str, Any] = field(default_factory=lambda: {
        "drift_detection": {
            "enabled": True,
            "window_size": 1000,
            "threshold": 0.1
        },
        "regime_detection": {
            "enabled": True,
            "min_regime_length": 100
        }
    })
    rollback_manager: Dict[str, Any] = field(default_factory=lambda: {
        "max_snapshots": 10,
        "auto_rollback": False,
        "snapshot_interval_minutes": 60
    })

@dataclass
class OptimizationConfig:
    """Optimizasyon konfigürasyonu"""
    performance_optimizer: Dict[str, Any] = field(default_factory=lambda: {
        "enabled": True,
        "optimization_interval_hours": 6,
        "objectives": ["accuracy", "speed", "memory"],
        "constraints": {
            "max_optimization_time": 3600,
            "max_resource_usage": 0.8
        }
    })
    parameter_tuner: Dict[str, Any] = field(default_factory=lambda: {
        "enabled": True,
        "tuning_methods": ["bayesian", "genetic"],
        "bayesian_config": {
            "sampler": "TPE",
            "n_trials": 100,
            "timeout": 1800
        },
        "genetic_config": {
            "population_size": 50,
            "generations": 20,
            "mutation_rate": 0.1
        }
    })

@dataclass
class MonitoringConfig:
    """Monitoring konfigürasyonu"""
    system_monitor: Dict[str, Any] = field(default_factory=lambda: {
        "enabled": True,
        "monitoring_interval_seconds": 30,
        "alert_thresholds": {
            "cpu_usage": 0.8,
            "memory_usage": 0.8,
            "error_rate": 0.05
        },
        "notification_channels": ["log", "websocket"]
    })
    performance_tracker: Dict[str, Any] = field(default_factory=lambda: {
        "enabled": True,
        "metrics_retention_days": 30,
        "reporting_interval_hours": 24,
        "trend_analysis": {
            "enabled": True,
            "lookback_days": 7
        }
    })

@dataclass
class IntegrationConfig:
    """Entegrasyon konfigürasyonu"""
    system_integrator: Dict[str, Any] = field(default_factory=lambda: {
        "enabled": True,
        "connection_strategy": "parallel",
        "health_check_interval_seconds": 60,
        "timeout_seconds": 30,
        "retry_attempts": 3
    })
    bitwisers_components: Dict[str, Any] = field(default_factory=lambda: {
        "genetic_engine": {
            "enabled": True,
            "config": {}
        },
        "meta_learning_engine": {
            "enabled": True,
            "config": {}
        },
        "dvk_engine": {
            "enabled": True,
            "config": {}
        },
        "strategy_calibration": {
            "enabled": True,
            "config": {}
        }
    })

@dataclass
class APIConfig:
    """API konfigürasyonu"""
    api_interface: Dict[str, Any] = field(default_factory=lambda: {
        "enabled": True,
        "host": "0.0.0.0",
        "port": 8000,
        "cors_enabled": True,
        "rate_limiting": {
            "enabled": False,
            "requests_per_minute": 100
        },
        "websocket": {
            "enabled": True,
            "max_connections": 100,
            "heartbeat_interval": 30
        }
    })

@dataclass
class MLflowConfig:
    """MLflow konfigürasyonu"""
    tracking_uri: str = "http://localhost:5000"
    experiment_name: str = "self_improving_feedback_loop"
    artifact_location: str = "./mlartifacts"
    backend_store_uri: str = "sqlite:///mlflow.db"
    registry_store_uri: str = "sqlite:///mlflow_registry.db"
    create_experiment_if_not_exists: bool = True

@dataclass
class AirflowConfig:
    """Airflow konfigürasyonu"""
    dag_folder: str = "./airflow/dags"
    schedule_interval: str = "0 2 * * *"  # Her gün 02:00
    catchup: bool = False
    max_active_runs: int = 1
    depends_on_past: bool = False
    retries: int = 1
    retry_delay_minutes: int = 5

class ConfigManager:
    """
    Kapsamlı konfigürasyon yöneticisi
    
    Bu sınıf self-improving feedback loop sisteminin tüm bileşenleri için
    konfigürasyon yönetimi sağlar. JSON/YAML dosyalarından konfigürasyon yükleme,
    environment değişkenleri ile override, doğrulama ve hot-reloading desteği içerir.
    """
    
    def __init__(self, config_dir: str = "./config", auto_load: bool = True):
        self.logger = logging.getLogger(__name__)
        self.config_dir = Path(config_dir)
        self.config_dir.mkdir(exist_ok=True)
        
        # Konfigürasyon storage
        self._configs: Dict[str, Any] = {}
        self._metadata: Dict[str, ConfigMetadata] = {}
        self._watchers: List[callable] = []
        
        # Environment overrides
        self._env_prefix = "SIFL_"
        
        if auto_load:
            self.load_all_configs()
    
    def load_all_configs(self):
        """Tüm konfigürasyon dosyalarını yükler"""
        try:
            self.logger.info(f"Konfigürasyon dizininden yükleme: {self.config_dir}")
            
            # Ana konfigürasyon dosyalarını yükle
            config_files = list(self.config_dir.glob("*.yaml")) + list(self.config_dir.glob("*.yml")) + list(self.config_dir.glob("*.json"))
            
            for config_file in config_files:
                try:
                    self.load_config_file(config_file)
                except Exception as e:
                    self.logger.error(f"Konfigürasyon yükleme hatası {config_file}: {e}")
            
            # Varsayılan konfigürasyonları oluştur
            self._create_default_configs()
            
            # Environment variables ile override uygula
            self._apply_environment_overrides()
            
            self.logger.info(f"Toplam {len(self._configs)} konfigürasyon yüklendi")
            
        except Exception as e:
            self.logger.error(f"Konfigürasyon yükleme hatası: {e}")
            raise
    
    def load_config_file(self, file_path: Union[str, Path]):
        """Belirli bir konfigürasyon dosyasını yükler"""
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"Konfigürasyon dosyası bulunamadı: {file_path}")
        
        # Dosya içeriğini oku
        with open(file_path, 'r', encoding='utf-8') as f:
            if file_path.suffix.lower() in ['.yaml', '.yml']:
                config_data = yaml.safe_load(f)
            elif file_path.suffix.lower() == '.json':
                config_data = json.load(f)
            else:
                raise ValueError(f"Desteklenmeyen dosya formatı: {file_path.suffix}")
        
        # Konfigürasyon tipini belirle
        config_type = self._determine_config_type(file_path.stem)
        
        # Konfigürasyonu kaydet
        config_name = file_path.stem
        self._configs[config_name] = config_data
        self._metadata[config_name] = ConfigMetadata(
            name=config_name,
            description=f"Yüklenen konfigürasyon dosyası: {file_path.name}"
        )
        
        self.logger.info(f"Konfigürasyon yüklendi: {config_name}")
    
    def _determine_config_type(self, config_name: str) -> ConfigType:
        """Konfigürasyon adından tipini belirler"""
        name_lower = config_name.lower()
        
        if "system" in name_lower:
            return ConfigType.SYSTEM
        elif "pipeline" in name_lower:
            return ConfigType.PIPELINE
        elif "adaptation" in name_lower:
            return ConfigType.ADAPTATION
        elif "optimization" in name_lower:
            return ConfigType.OPTIMIZATION
        elif "monitoring" in name_lower:
            return ConfigType.MONITORING
        elif "integration" in name_lower:
            return ConfigType.INTEGRATION
        elif "api" in name_lower:
            return ConfigType.API
        else:
            return ConfigType.SYSTEM
    
    def _create_default_configs(self):
        """Varsayılan konfigürasyonları oluşturur"""
        try:
            # Sistem konfigürasyonu
            if "system" not in self._configs:
                self._configs["system"] = asdict(SystemConfig())
                self._metadata["system"] = ConfigMetadata(
                    name="system",
                    description="Ana sistem konfigürasyonu"
                )
            
            # Pipeline konfigürasyonu
            if "pipeline" not in self._configs:
                self._configs["pipeline"] = asdict(PipelineConfig())
                self._metadata["pipeline"] = ConfigMetadata(
                    name="pipeline",
                    description="Pipeline bileşen konfigürasyonu"
                )
            
            # Adaptation konfigürasyonu
            if "adaptation" not in self._configs:
                self._configs["adaptation"] = asdict(AdaptationConfig())
                self._metadata["adaptation"] = ConfigMetadata(
                    name="adaptation",
                    description="Adaptasyon bileşen konfigürasyonu"
                )
            
            # Optimization konfigürasyonu
            if "optimization" not in self._configs:
                self._configs["optimization"] = asdict(OptimizationConfig())
                self._metadata["optimization"] = ConfigMetadata(
                    name="optimization",
                    description="Optimizasyon bileşen konfigürasyonu"
                )
            
            # Monitoring konfigürasyonu
            if "monitoring" not in self._configs:
                self._configs["monitoring"] = asdict(MonitoringConfig())
                self._metadata["monitoring"] = ConfigMetadata(
                    name="monitoring",
                    description="Monitoring bileşen konfigürasyonu"
                )
            
            # Integration konfigürasyonu
            if "integration" not in self._configs:
                self._configs["integration"] = asdict(IntegrationConfig())
                self._metadata["integration"] = ConfigMetadata(
                    name="integration",
                    description="Entegrasyon bileşen konfigürasyonu"
                )
            
            # API konfigürasyonu
            if "api" not in self._configs:
                self._configs["api"] = asdict(APIConfig())
                self._metadata["api"] = ConfigMetadata(
                    name="api",
                    description="API arayüzü konfigürasyonu"
                )
            
            # MLflow konfigürasyonu
            if "mlflow" not in self._configs:
                self._configs["mlflow"] = asdict(MLflowConfig())
                self._metadata["mlflow"] = ConfigMetadata(
                    name="mlflow",
                    description="MLflow experiment tracking konfigürasyonu"
                )
            
            # Airflow konfigürasyonu
            if "airflow" not in self._configs:
                self._configs["airflow"] = asdict(AirflowConfig())
                self._metadata["airflow"] = ConfigMetadata(
                    name="airflow",
                    description="Airflow workflow orchestration konfigürasyonu"
                )
            
            self.logger.info("Varsayılan konfigürasyonlar oluşturuldu")
            
        except Exception as e:
            self.logger.error(f"Varsayılan konfigürasyon oluşturma hatası: {e}")
            raise
    
    def _apply_environment_overrides(self):
        """Environment değişkenleri ile konfigürasyon override'ı uygular"""
        try:
            for env_var, value in os.environ.items():
                if env_var.startswith(self._env_prefix):
                    # Environment değişkeninden konfigürasyon yolunu çıkar
                    config_path = env_var[len(self._env_prefix):].lower().replace('_', '.')
                    self._set_nested_config(config_path, value)
            
            self.logger.info("Environment değişken override'ları uygulandı")
            
        except Exception as e:
            self.logger.error(f"Environment override hatası: {e}")
    
    def _set_nested_config(self, path: str, value: str):
        """Nested konfigürasyon değerini ayarlar"""
        keys = path.split('.')
        
        # İlk iki anahtar config_type.config_key olmalı
        if len(keys) >= 2:
            config_type = keys[0]
            config_key = '.'.join(keys[1:])
            
            if config_type in self._configs:
                # String değeri uygun tipe çevir
                converted_value = self._convert_env_value(value)
                
                # Nested key'e değeri ayarla
                self._set_nested_value(self._configs[config_type], config_key, converted_value)
                
                self.logger.debug(f"Environment override uygulandı: {path} = {converted_value}")
    
    def _convert_env_value(self, value: str) -> Any:
        """Environment değişkeni değerini uygun tipe çevirir"""
        # Boolean kontrolü
        if value.lower() in ('true', '1', 'yes', 'on'):
            return True
        elif value.lower() in ('false', '0', 'no', 'off'):
            return False
        
        # Sayısal kontrol
        try:
            if '.' in value:
                return float(value)
            else:
                return int(value)
        except ValueError:
            pass
        
        # JSON kontrolü
        try:
            return json.loads(value)
        except (json.JSONDecodeError, ValueError):
            pass
        
        # String olarak döndür
        return value
    
    def _set_nested_value(self, config_dict: Dict[str, Any], key_path: str, value: Any):
        """Nested dictionary'ye değer atar"""
        keys = key_path.split('.')
        current = config_dict
        
        for key in keys[:-1]:
            if key not in current:
                current[key] = {}
            current = current[key]
        
        current[keys[-1]] = value
    
    def get_config(self, config_name: str, default: Optional[Any] = None) -> Any:
        """Konfigürasyon değerini getirir"""
        return self._configs.get(config_name, default)
    
    def get_nested_config(self, config_path: str, default: Optional[Any] = None) -> Any:
        """Nested konfigürasyon değerini getirir"""
        keys = config_path.split('.')
        current = self._configs
        
        try:
            for key in keys:
                current = current[key]
            return current
        except (KeyError, TypeError):
            return default
    
    def update_config(self, config_name: str, config_data: Dict[str, Any], validate: bool = True) -> bool:
        """Konfigürasyonu günceller"""
        try:
            if validate:
                self._validate_config(config_name, config_data)
            
            # Mevcut konfigürasyonu güncelle
            self._configs[config_name].update(config_data)
            
            # Metadata güncelle
            if config_name in self._metadata:
                self._metadata[config_name].updated_at = datetime.now()
            
            # Watcher'lara bildir
            self._notify_watchers(config_name, config_data)
            
            self.logger.info(f"Konfigürasyon güncellendi: {config_name}")
            return True
            
        except ConfigValidationError as e:
            self.logger.error(f"Konfigürasyon doğrulama hatası: {e}")
            return False
        except Exception as e:
            self.logger.error(f"Konfigürasyon güncelleme hatası: {e}")
            return False
    
    def _validate_config(self, config_name: str, config_data: Dict[str, Any]):
        """Konfigürasyon doğrulaması yapar"""
        validators = {
            'system': self._validate_system_config,
            'pipeline': self._validate_pipeline_config,
            'optimization': self._validate_optimization_config,
            'monitoring': self._validate_monitoring_config,
            'api': self._validate_api_config
        }
        
        if config_name in validators:
            validators[config_name](config_data)
    
    def _validate_system_config(self, config_data: Dict[str, Any]):
        """Sistem konfigürasyonu doğrulaması"""
        if 'max_workers' in config_data and config_data['max_workers'] < 1:
            raise ConfigValidationError("max_workers en az 1 olmalıdır")
        
        if 'memory_limit_mb' in config_data and config_data['memory_limit_mb'] < 100:
            raise ConfigValidationError("memory_limit_mb en az 100 MB olmalıdır")
    
    def _validate_pipeline_config(self, config_data: Dict[str, Any]):
        """Pipeline konfigürasyonu doğrulaması"""
        if 'continuous_learning' in config_data:
            cl_config = config_data['continuous_learning']
            if 'learning_interval_minutes' in cl_config and cl_config['learning_interval_minutes'] < 1:
                raise ConfigValidationError("learning_interval_minutes en az 1 olmalıdır")
    
    def _validate_optimization_config(self, config_data: Dict[str, Any]):
        """Optimizasyon konfigürasyonu doğrulaması"""
        if 'performance_optimizer' in config_data:
            opt_config = config_data['performance_optimizer']
            if 'constraints' in opt_config:
                constraints = opt_config['constraints']
                if 'max_optimization_time' in constraints and constraints['max_optimization_time'] < 60:
                    raise ConfigValidationError("max_optimization_time en az 60 saniye olmalıdır")
    
    def _validate_monitoring_config(self, config_data: Dict[str, Any]):
        """Monitoring konfigürasyonu doğrulaması"""
        if 'system_monitor' in config_data:
            monitor_config = config_data['system_monitor']
            if 'alert_thresholds' in monitor_config:
                thresholds = monitor_config['alert_thresholds']
                for threshold, value in thresholds.items():
                    if not (0 <= value <= 1):
                        raise ConfigValidationError(f"{threshold} threshold değeri 0-1 arasında olmalıdır")
    
    def _validate_api_config(self, config_data: Dict[str, Any]):
        """API konfigürasyonu doğrulaması"""
        if 'api_interface' in config_data:
            api_config = config_data['api_interface']
            if 'port' in api_config:
                port = api_config['port']
                if not (1024 <= port <= 65535):
                    raise ConfigValidationError("Port değeri 1024-65535 arasında olmalıdır")
    
    def save_config(self, config_name: str, file_path: Optional[Path] = None) -> bool:
        """Konfigürasyonu dosyaya kaydeder"""
        try:
            if config_name not in self._configs:
                raise ValueError(f"Konfigürasyon bulunamadı: {config_name}")
            
            if file_path is None:
                file_path = self.config_dir / f"{config_name}.yaml"
            
            config_data = self._configs[config_name]
            
            # Dosyaya kaydet
            with open(file_path, 'w', encoding='utf-8') as f:
                yaml.dump(config_data, f, default_flow_style=False, allow_unicode=True)
            
            self.logger.info(f"Konfigürasyon kaydedildi: {file_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Konfigürasyon kaydetme hatası: {e}")
            return False
    
    def export_configs(self, export_dir: Path, format: str = "yaml") -> bool:
        """Tüm konfigürasyonları belirtilen formata aktarır"""
        try:
            export_dir = Path(export_dir)
            export_dir.mkdir(exist_ok=True)
            
            for config_name, config_data in self._configs.items():
                file_path = export_dir / f"{config_name}.{format}"
                
                if format.lower() == "yaml":
                    with open(file_path, 'w', encoding='utf-8') as f:
                        yaml.dump(config_data, f, default_flow_style=False, allow_unicode=True)
                elif format.lower() == "json":
                    with open(file_path, 'w', encoding='utf-8') as f:
                        json.dump(config_data, f, indent=2, ensure_ascii=False)
                else:
                    raise ValueError(f"Desteklenmeyen format: {format}")
            
            self.logger.info(f"Konfigürasyonlar {export_dir} dizinine aktarıldı")
            return True
            
        except Exception as e:
            self.logger.error(f"Konfigürasyon export hatası: {e}")
            return False
    
    def add_config_watcher(self, watcher_function: callable):
        """Konfigürasyon değişiklik watcher'ı ekler"""
        self._watchers.append(watcher_function)
        self.logger.debug(f"Konfigürasyon watcher eklendi: {watcher_function}")
    
    def _notify_watchers(self, config_name: str, config_data: Dict[str, Any]):
        """Tüm watcher'lara konfigürasyon değişikliğini bildirir"""
        for watcher in self._watchers:
            try:
                watcher(config_name, config_data)
            except Exception as e:
                self.logger.error(f"Watcher hatası: {e}")
    
    def get_config_summary(self) -> Dict[str, Any]:
        """Konfigürasyon özetini döndürür"""
        summary = {
            'total_configs': len(self._configs),
            'configs': {},
            'metadata': {},
            'config_dir': str(self.config_dir),
            'last_updated': datetime.now().isoformat()
        }
        
        for name, config in self._configs.items():
            summary['configs'][name] = {
                'type': type(config).__name__,
                'size': len(str(config)),
                'has_changes': name in self._metadata and self._metadata[name].updated_at is not None
            }
        
        for name, meta in self._metadata.items():
            summary['metadata'][name] = asdict(meta)
        
        return summary
    
    def reset_to_defaults(self, config_name: Optional[str] = None):
        """Konfigürasyonu varsayılan değerlere sıfırlar"""
        try:
            if config_name:
                # Belirli bir konfigürasyonu sıfırla
                if config_name in self._configs:
                    del self._configs[config_name]
                if config_name in self._metadata:
                    del self._metadata[config_name]
                
                # Varsayılan konfigürasyonu yeniden oluştur
                self._create_default_configs()
            else:
                # Tüm konfigürasyonları sıfırla
                self._configs.clear()
                self._metadata.clear()
                self._create_default_configs()
            
            self.logger.info(f"Konfigürasyon sıfırlandı: {config_name or 'all'}")
            
        except Exception as e:
            self.logger.error(f"Konfigürasyon sıfırlama hatası: {e}")
    
    def clone_config(self, source_name: str, target_name: str) -> bool:
        """Konfigürasyonu kopyalar"""
        try:
            if source_name not in self._configs:
                raise ValueError(f"Kaynak konfigürasyon bulunamadı: {source_name}")
            
            # Derin kopya oluştur
            self._configs[target_name] = copy.deepcopy(self._configs[source_name])
            
            # Metadata kopyala
            if source_name in self._metadata:
                self._metadata[target_name] = copy.deepcopy(self._metadata[source_name])
                self._metadata[target_name].name = target_name
            
            self.logger.info(f"Konfigürasyon kopyalandı: {source_name} -> {target_name}")
            return True
            
        except Exception as e:
            self.logger.error(f"Konfigürasyon kopyalama hatası: {e}")
            return False

# Global config manager instance
_global_config_manager = None

def get_config_manager(config_dir: str = "./config", auto_load: bool = True) -> ConfigManager:
    """Global konfigürasyon yöneticisi instance'ını döndürür"""
    global _global_config_manager
    
    if _global_config_manager is None:
        _global_config_manager = ConfigManager(config_dir, auto_load)
    
    return _global_config_manager

def get_config(config_path: str, default: Optional[Any] = None) -> Any:
    """Global config manager üzerinden konfigürasyon değerini getirir"""
    manager = get_config_manager()
    return manager.get_nested_config(config_path, default)

def update_config(config_path: str, value: Any, validate: bool = True) -> bool:
    """Global config manager üzerinden konfigürasyon değerini günceller"""
    manager = get_config_manager()
    
    # config_path'i parse et (örn: "system.debug_mode")
    keys = config_path.split('.')
    if len(keys) >= 2:
        config_name = keys[0]
        nested_key = '.'.join(keys[1:])
        
        if config_name in manager._configs:
            current_config = manager._configs[config_name]
            manager._set_nested_value(current_config, nested_key, value)
            
            if validate:
                manager._validate_config(config_name, current_config)
            
            return True
    
    return False

# Konfigürasyon değişkenleri için decorator
def config_value(config_path: str, default: Optional[Any] = None):
    """Konfigürasyon değeri için decorator"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            value = get_config(config_path, default)
            return func(value, *args, **kwargs)
        return wrapper
    return decorator

if __name__ == "__main__":
    # Test için örnek kullanım
    import asyncio
    
    async def test_config_manager():
        # Config manager oluştur
        config_manager = ConfigManager("./config", auto_load=True)
        
        # Konfigürasyon özetini al
        summary = config_manager.get_config_summary()
        print("Config Summary:", json.dumps(summary, indent=2, default=str))
        
        # Konfigürasyon değeri okuma
        debug_mode = config_manager.get_nested_config("system.debug_mode", False)
        print(f"Debug Mode: {debug_mode}")
        
        # Konfigürasyon güncelleme
        success = config_manager.update_config("system", {"debug_mode": True})
        print(f"Update Success: {success}")
        
        # Environment variable override test
        os.environ["SIFL_SYSTEM_DEBUG_MODE"] = "false"
        config_manager._apply_environment_overrides()
        
        updated_debug = config_manager.get_nested_config("system.debug_mode")
        print(f"Updated Debug Mode: {updated_debug}")
    
    asyncio.run(test_config_manager())
