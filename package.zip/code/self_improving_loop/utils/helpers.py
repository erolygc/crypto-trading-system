"""
Yardımcı Fonksiyonlar ve Utilities

Self-Improving Feedback Loop sistemi için genel amaçlı yardımcı fonksiyonlar:
- Veri işleme utilities
- Matematik ve istatistik fonksiyonları
- Dosya ve dizin işlemleri
- Zaman ve tarih utilities
- Validation ve type checking
- Async utilities
- Memory ve performance monitoring
- Data serialization utilities
"""

import os
import sys
import json
import pickle
import asyncio
import hashlib
import time
import uuid
import functools
import inspect
import warnings
import weakref
from typing import Dict, Any, Optional, List, Union, Callable, Type, Generic, TypeVar, Awaitable
from datetime import datetime, timedelta, timezone
from pathlib import Path
from dataclasses import dataclass, field, asdict
from collections import defaultdict, deque
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import gzip
import base64
import zlib
from contextlib import contextmanager, asynccontextmanager
import logging

# Data validation imports
try:
    import jsonschema
    JSONSCHEMA_AVAILABLE = True
except ImportError:
    JSONSCHEMA_AVAILABLE = False

# Performance monitoring imports
try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

# Statistics imports
try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

try:
    import scipy.stats as stats
    SCIPY_AVAILABLE = True
except ImportError:
    SCIPY_AVAILABLE = False

# Machine learning imports
try:
    import scikit-learn as sk
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

T = TypeVar('T')

class ValidationError(Exception):
    """Validation error"""
    pass

class PerformanceError(Exception):
    """Performance monitoring error"""
    pass

@dataclass
class TimerResult:
    """Timer result data structure"""
    operation: str
    duration_seconds: float
    start_time: datetime
    end_time: datetime
    memory_usage_mb: Optional[float] = None
    cpu_usage_percent: Optional[float] = None
    metadata: Optional[Dict[str, Any]] = None

@dataclass
class MemorySnapshot:
    """Memory usage snapshot"""
    timestamp: datetime
    rss_mb: float  # Resident Set Size
    vms_mb: float  # Virtual Memory Size
    percent: float  # Memory percentage
    available_mb: Optional[float] = None
    total_mb: Optional[float] = None

class DataValidator:
    """Data validation utilities"""
    
    @staticmethod
    def validate_json_schema(data: Dict[str, Any], schema: Dict[str, Any]) -> bool:
        """Validate data against JSON schema"""
        if not JSONSCHEMA_AVAILABLE:
            warnings.warn("jsonschema not available, skipping validation")
            return True
        
        try:
            jsonschema.validate(data, schema)
            return True
        except jsonschema.ValidationError as e:
            raise ValidationError(f"JSON schema validation failed: {e.message}")
    
    @staticmethod
    def validate_required_fields(data: Dict[str, Any], required_fields: List[str]) -> bool:
        """Validate that all required fields are present"""
        missing_fields = [field for field in required_fields if field not in data]
        if missing_fields:
            raise ValidationError(f"Missing required fields: {missing_fields}")
        return True
    
    @staticmethod
    def validate_data_types(data: Dict[str, Any], type_specs: Dict[str, Type]) -> bool:
        """Validate data types according to specifications"""
        for field_name, expected_type in type_specs.items():
            if field_name in data:
                actual_value = data[field_name]
                if not isinstance(actual_value, expected_type):
                    raise ValidationError(
                        f"Field '{field_name}' should be of type {expected_type.__name__}, "
                        f"got {type(actual_value).__name__}"
                    )
        return True
    
    @staticmethod
    def validate_range(data: Dict[str, Any], range_specs: Dict[str, tuple]) -> bool:
        """Validate numeric data ranges"""
        for field_name, (min_val, max_val) in range_specs.items():
            if field_name in data:
                value = data[field_name]
                if not isinstance(value, (int, float)):
                    raise ValidationError(f"Field '{field_name}' should be numeric")
                if not (min_val <= value <= max_val):
                    raise ValidationError(
                        f"Field '{field_name}' should be between {min_val} and {max_val}, "
                        f"got {value}"
                    )
        return True

class DataProcessor:
    """Data processing utilities"""
    
    @staticmethod
    def flatten_dict(data: Dict[str, Any], separator: str = '.') -> Dict[str, Any]:
        """Flatten nested dictionary"""
        result = {}
        
        def _flatten(obj: Any, parent_key: str = ''):
            if isinstance(obj, dict):
                for key, value in obj.items():
                    new_key = f"{parent_key}{separator}{key}" if parent_key else key
                    _flatten(value, new_key)
            elif isinstance(obj, list):
                for i, item in enumerate(obj):
                    new_key = f"{parent_key}{separator}{i}" if parent_key else str(i)
                    _flatten(item, new_key)
            else:
                result[parent_key] = obj
        
        _flatten(data)
        return result
    
    @staticmethod
    def unflatten_dict(data: Dict[str, Any], separator: str = '.') -> Dict[str, Any]:
        """Unflatten dictionary"""
        result = {}
        
        for key, value in data.items():
            keys = key.split(separator)
            current = result
            
            for k in keys[:-1]:
                if k not in current:
                    current[k] = {}
                current = current[k]
            
            current[keys[-1]] = value
        
        return result
    
    @staticmethod
    def normalize_data(data: List[Union[int, float]], method: str = 'min_max') -> List[float]:
        """Normalize numeric data"""
        if not data:
            return []
        
        if method == 'min_max':
            min_val = min(data)
            max_val = max(data)
            if max_val == min_val:
                return [0.0] * len(data)
            return [(x - min_val) / (max_val - min_val) for x in data]
        
        elif method == 'z_score':
            if not NUMPY_AVAILABLE:
                warnings.warn("NumPy not available, using min_max normalization")
                return DataProcessor.normalize_data(data, 'min_max')
            
            mean = np.mean(data)
            std = np.std(data)
            if std == 0:
                return [0.0] * len(data)
            return [(x - mean) / std for x in data]
        
        else:
            raise ValueError(f"Unknown normalization method: {method}")
    
    @staticmethod
    def detect_outliers(data: List[float], method: str = 'iqr', threshold: float = 1.5) -> List[bool]:
        """Detect outliers in numeric data"""
        if not data:
            return []
        
        if method == 'iqr':
            if not NUMPY_AVAILABLE:
                warnings.warn("NumPy not available, using basic IQR")
                sorted_data = sorted(data)
                n = len(sorted_data)
                q1_idx = n // 4
                q3_idx = 3 * n // 4
                q1 = sorted_data[q1_idx]
                q3 = sorted_data[q3_idx]
                iqr = q3 - q1
                lower_bound = q1 - threshold * iqr
                upper_bound = q3 + threshold * iqr
                return [x < lower_bound or x > upper_bound for x in data]
            
            q1, q3 = np.percentile(data, [25, 75])
            iqr = q3 - q1
            lower_bound = q1 - threshold * iqr
            upper_bound = q3 + threshold * iqr
            return [(x < lower_bound or x > upper_bound) for x in data]
        
        elif method == 'z_score':
            if not NUMPY_AVAILABLE:
                warnings.warn("NumPy not available, using basic z-score")
                mean = sum(data) / len(data)
                std = (sum((x - mean) ** 2 for x in data) / len(data)) ** 0.5
                if std == 0:
                    return [False] * len(data)
                return [abs((x - mean) / std) > threshold for x in data]
            
            mean = np.mean(data)
            std = np.std(data)
            if std == 0:
                return [False] * len(data)
            z_scores = np.abs((data - mean) / std)
            return (z_scores > threshold).tolist()
        
        else:
            raise ValueError(f"Unknown outlier detection method: {method}")

class MathUtils:
    """Mathematical and statistical utilities"""
    
    @staticmethod
    def calculate_correlation(x: List[float], y: List[float]) -> float:
        """Calculate Pearson correlation coefficient"""
        if len(x) != len(y) or len(x) == 0:
            return 0.0
        
        if not NUMPY_AVAILABLE:
            # Manual calculation
            n = len(x)
            sum_x = sum(x)
            sum_y = sum(y)
            sum_xy = sum(xi * yi for xi, yi in zip(x, y))
            sum_x2 = sum(xi * xi for xi in x)
            sum_y2 = sum(yi * yi for yi in y)
            
            numerator = n * sum_xy - sum_x * sum_y
            denominator = ((n * sum_x2 - sum_x ** 2) * (n * sum_y2 - sum_y ** 2)) ** 0.5
            
            return numerator / denominator if denominator != 0 else 0.0
        
        return np.corrcoef(x, y)[0, 1]
    
    @staticmethod
    def moving_average(data: List[float], window_size: int) -> List[float]:
        """Calculate moving average"""
        if window_size <= 0 or len(data) == 0:
            return []
        
        result = []
        for i in range(len(data)):
            start_idx = max(0, i - window_size + 1)
            window_data = data[start_idx:i + 1]
            result.append(sum(window_data) / len(window_data))
        
        return result
    
    @staticmethod
    def exponential_moving_average(data: List[float], alpha: float = 0.3) -> List[float]:
        """Calculate exponential moving average"""
        if not data or not (0 < alpha <= 1):
            return []
        
        ema = [data[0]]
        for i in range(1, len(data)):
            ema.append(alpha * data[i] + (1 - alpha) * ema[i - 1])
        
        return ema
    
    @staticmethod
    def calculate_entropy(data: List[float], bins: int = 10) -> float:
        """Calculate Shannon entropy"""
        if not data:
            return 0.0
        
        # Create histogram
        if not NUMPY_AVAILABLE:
            min_val, max_val = min(data), max(data)
            if max_val == min_val:
                return 0.0
            
            hist = [0] * bins
            bin_width = (max_val - min_val) / bins
            
            for value in data:
                bin_idx = min(int((value - min_val) / bin_width), bins - 1)
                hist[bin_idx] += 1
            
            # Calculate entropy
            total = len(data)
            entropy = 0.0
            for count in hist:
                if count > 0:
                    p = count / total
                    entropy -= p * (p.bit_length() - 1)  # Approximation
        
        else:
            hist, _ = np.histogram(data, bins=bins)
            hist = hist[hist > 0]  # Remove zero bins
            if len(hist) == 0:
                return 0.0
            
            p = hist / hist.sum()
            entropy = -np.sum(p * np.log2(p))
        
        return entropy
    
    @staticmethod
    def polynomial_fit(x: List[float], y: List[float], degree: int = 1) -> List[float]:
        """Fit polynomial of given degree to data"""
        if not NUMPY_AVAILABLE:
            warnings.warn("NumPy not available, using linear approximation")
            if degree == 1:
                # Linear regression
                n = len(x)
                sum_x = sum(x)
                sum_y = sum(y)
                sum_xy = sum(xi * yi for xi, yi in zip(x, y))
                sum_x2 = sum(xi * xi for xi in x)
                
                denominator = n * sum_x2 - sum_x ** 2
                if denominator == 0:
                    return [0.0, sum_y / n] if n > 0 else [0.0]
                
                slope = (n * sum_xy - sum_x * sum_y) / denominator
                intercept = (sum_y - slope * sum_x) / n
                return [intercept, slope]
            else:
                raise ValueError("Higher degree polynomials require NumPy")
        
        # Use NumPy for proper polynomial fitting
        coeffs = np.polyfit(x, y, degree)
        return coeffs.tolist()

class FileUtils:
    """File and directory utilities"""
    
    @staticmethod
    def ensure_directory(path: Union[str, Path]) -> Path:
        """Ensure directory exists"""
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        return path
    
    @staticmethod
    def calculate_file_hash(file_path: Union[str, Path], algorithm: str = 'sha256') -> str:
        """Calculate file hash"""
        hash_func = getattr(hashlib, algorithm.lower())()
        
        with open(file_path, 'rb') as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_func.update(chunk)
        
        return hash_func.hexdigest()
    
    @staticmethod
    def compress_data(data: bytes, method: str = 'gzip') -> bytes:
        """Compress binary data"""
        if method == 'gzip':
            return gzip.compress(data)
        elif method == 'zlib':
            return zlib.compress(data)
        else:
            raise ValueError(f"Unknown compression method: {method}")
    
    @staticmethod
    def decompress_data(compressed_data: bytes, method: str = 'gzip') -> bytes:
        """Decompress binary data"""
        if method == 'gzip':
            return gzip.decompress(compressed_data)
        elif method == 'zlib':
            return zlib.decompress(compressed_data)
        else:
            raise ValueError(f"Unknown decompression method: {method}")
    
    @staticmethod
    def safe_filename(filename: str, replacement: str = '_') -> str:
        """Create safe filename by replacing unsafe characters"""
        unsafe_chars = '<>:"/\\|?*'
        safe_name = filename
        for char in unsafe_chars:
            safe_name = safe_name.replace(char, replacement)
        return safe_name.strip()
    
    @staticmethod
    def get_file_size_mb(file_path: Union[str, Path]) -> float:
        """Get file size in MB"""
        return Path(file_path).stat().st_size / (1024 * 1024)
    
    @staticmethod
    def find_files(directory: Union[str, Path], pattern: str = '*', recursive: bool = True) -> List[Path]:
        """Find files matching pattern"""
        directory = Path(directory)
        if recursive:
            return list(directory.rglob(pattern))
        else:
            return list(directory.glob(pattern))

class TimeUtils:
    """Time and date utilities"""
    
    @staticmethod
    def format_duration(seconds: float) -> str:
        """Format duration in human readable format"""
        if seconds < 60:
            return f"{seconds:.2f}s"
        elif seconds < 3600:
            minutes = seconds // 60
            remaining_seconds = seconds % 60
            return f"{int(minutes)}m {remaining_seconds:.2f}s"
        else:
            hours = seconds // 3600
            remaining_minutes = (seconds % 3600) // 60
            remaining_seconds = seconds % 60
            return f"{int(hours)}h {int(remaining_minutes)}m {remaining_seconds:.2f}s"
    
    @staticmethod
    def get_timezone_aware_now() -> datetime:
        """Get current time with timezone info"""
        return datetime.now(timezone.utc)
    
    @staticmethod
    def parse_datetime(datetime_str: str, format_str: str = None) -> datetime:
        """Parse datetime string"""
        if format_str:
            return datetime.strptime(datetime_str, format_str)
        else:
            # Try common formats
            common_formats = [
                '%Y-%m-%d %H:%M:%S',
                '%Y-%m-%d %H:%M:%S.%f',
                '%Y-%m-%d',
                '%Y-%m-%dT%H:%M:%S',
                '%Y-%m-%dT%H:%M:%S.%fZ'
            ]
            
            for fmt in common_formats:
                try:
                    return datetime.strptime(datetime_str, fmt)
                except ValueError:
                    continue
            
            raise ValueError(f"Unable to parse datetime: {datetime_str}")
    
    @staticmethod
    def calculate_time_difference(start_time: datetime, end_time: datetime = None) -> timedelta:
        """Calculate time difference"""
        if end_time is None:
            end_time = TimeUtils.get_timezone_aware_now()
        return end_time - start_time

class AsyncUtils:
    """Async utilities and helpers"""
    
    @staticmethod
    async def run_in_executor(func: Callable, *args, executor: ThreadPoolExecutor = None) -> Any:
        """Run CPU-bound function in executor"""
        loop = asyncio.get_event_loop()
        if executor:
            return await loop.run_in_executor(executor, func, *args)
        else:
            return await loop.run_in_executor(None, func, *args)
    
    @staticmethod
    async def gather_with_limit(tasks: List[Awaitable], limit: int = 10) -> List[Any]:
        """Run tasks with concurrency limit"""
        results = []
        semaphore = asyncio.Semaphore(limit)
        
        async def bounded_task(task):
            async with semaphore:
                return await task
        
        bounded_tasks = [bounded_task(task) for task in tasks]
        results = await asyncio.gather(*bounded_tasks, return_exceptions=True)
        
        return results
    
    @staticmethod
    async def retry_async(func: Callable, max_retries: int = 3, 
                         delay: float = 1.0, backoff: float = 2.0,
                         exceptions: tuple = (Exception,)) -> Any:
        """Retry async function with exponential backoff"""
        last_exception = None
        
        for attempt in range(max_retries + 1):
            try:
                return await func()
            except exceptions as e:
                last_exception = e
                if attempt == max_retries:
                    break
                
                wait_time = delay * (backoff ** attempt)
                await asyncio.sleep(wait_time)
        
        raise last_exception
    
    @staticmethod
    @contextmanager
    async def timeout_context(timeout_seconds: float):
        """Timeout context for async operations"""
        try:
            yield
        except asyncio.TimeoutError:
            raise PerformanceError(f"Operation timed out after {timeout_seconds} seconds")

class PerformanceMonitor:
    """Performance monitoring utilities"""
    
    _instance = None
    _lock = threading.Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        self.measurements: Dict[str, deque] = defaultdict(lambda: deque(maxlen=100))
        self.memory_snapshots: deque = deque(maxlen=1000)
        self.start_time = time.time()
    
    def record_operation(self, operation_name: str, duration: float, 
                        memory_usage_mb: Optional[float] = None,
                        cpu_usage_percent: Optional[float] = None,
                        metadata: Optional[Dict[str, Any]] = None):
        """Record operation performance"""
        measurement = {
            'timestamp': time.time(),
            'duration': duration,
            'memory_usage_mb': memory_usage_mb,
            'cpu_usage_percent': cpu_usage_percent,
            'metadata': metadata or {}
        }
        
        self.measurements[operation_name].append(measurement)
    
    def get_operation_stats(self, operation_name: str) -> Dict[str, Any]:
        """Get statistics for specific operation"""
        if operation_name not in self.measurements:
            return {}
        
        measurements = list(self.measurements[operation_name])
        if not measurements:
            return {}
        
        durations = [m['duration'] for m in measurements]
        memory_usage = [m['memory_usage_mb'] for m in measurements if m['memory_usage_mb'] is not None]
        
        stats = {
            'count': len(measurements),
            'avg_duration': sum(durations) / len(durations),
            'min_duration': min(durations),
            'max_duration': max(durations),
            'last_duration': durations[-1]
        }
        
        if memory_usage:
            stats.update({
                'avg_memory_mb': sum(memory_usage) / len(memory_usage),
                'max_memory_mb': max(memory_usage),
                'min_memory_mb': min(memory_usage)
            })
        
        return stats
    
    def take_memory_snapshot(self) -> Optional[MemorySnapshot]:
        """Take current memory usage snapshot"""
        if not PSUTIL_AVAILABLE:
            return None
        
        try:
            process = psutil.Process()
            memory_info = process.memory_info()
            
            snapshot = MemorySnapshot(
                timestamp=datetime.now(),
                rss_mb=memory_info.rss / 1024 / 1024,
                vms_mb=memory_info.vms / 1024 / 1024,
                percent=process.memory_percent(),
                available_mb=psutil.virtual_memory().available / 1024 / 1024,
                total_mb=psutil.virtual_memory().total / 1024 / 1024
            )
            
            self.memory_snapshots.append(snapshot)
            return snapshot
            
        except Exception as e:
            logging.error(f"Memory snapshot error: {e}")
            return None
    
    def get_memory_trend(self, duration_minutes: int = 60) -> Dict[str, Any]:
        """Get memory usage trend"""
        if not self.memory_snapshots:
            return {}
        
        cutoff_time = time.time() - (duration_minutes * 60)
        recent_snapshots = [s for s in self.memory_snapshots 
                          if s.timestamp.timestamp() > cutoff_time]
        
        if not recent_snapshots:
            return {}
        
        rss_values = [s.rss_mb for s in recent_snapshots]
        percent_values = [s.percent for s in recent_snapshots]
        
        return {
            'snapshot_count': len(recent_snapshots),
            'avg_rss_mb': sum(rss_values) / len(rss_values),
            'max_rss_mb': max(rss_values),
            'min_rss_mb': min(rss_values),
            'avg_percent': sum(percent_values) / len(percent_values),
            'trend': 'increasing' if rss_values[-1] > rss_values[0] else 'decreasing'
        }

class Timer:
    """High precision timer context manager"""
    
    def __init__(self, operation_name: str, metadata: Optional[Dict[str, Any]] = None):
        self.operation_name = operation_name
        self.metadata = metadata or {}
        self.start_time = None
        self.end_time = None
        self.monitor = PerformanceMonitor()
    
    def __enter__(self):
        self.start_time = time.time()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.end_time = time.time()
        duration = self.end_time - self.start_time
        
        # Get memory usage if available
        memory_usage_mb = None
        cpu_usage_percent = None
        
        if PSUTIL_AVAILABLE:
            try:
                process = psutil.Process()
                memory_usage_mb = process.memory_info().rss / 1024 / 1024
                cpu_usage_percent = process.cpu_percent()
            except Exception:
                pass
        
        # Record the measurement
        self.monitor.record_operation(
            self.operation_name,
            duration,
            memory_usage_mb,
            cpu_usage_percent,
            self.metadata
        )
    
    @property
    def elapsed(self) -> float:
        """Get elapsed time in seconds"""
        if self.start_time is None:
            return 0.0
        end_time = self.end_time or time.time()
        return end_time - self.start_time

@contextmanager
def timer_context(operation_name: str, metadata: Optional[Dict[str, Any]] = None):
    """Timer context manager for timing operations"""
    timer = Timer(operation_name, metadata)
    timer.__enter__()
    try:
        yield timer
    finally:
        timer.__exit__(None, None, None)

class Serializer:
    """Data serialization utilities"""
    
    @staticmethod
    def to_json(data: Any, indent: int = 2, ensure_ascii: bool = False) -> str:
        """Serialize to JSON"""
        return json.dumps(data, indent=indent, ensure_ascii=ensure_ascii, default=str)
    
    @staticmethod
    def from_json(json_str: str) -> Any:
        """Deserialize from JSON"""
        return json.loads(json_str)
    
    @staticmethod
    def to_pickle(data: Any) -> bytes:
        """Serialize to pickle"""
        return pickle.dumps(data)
    
    @staticmethod
    def from_pickle(pickled_data: bytes) -> Any:
        """Deserialize from pickle"""
        return pickle.loads(pickled_data)
    
    @staticmethod
    def to_base64(data: bytes) -> str:
        """Convert bytes to base64 string"""
        return base64.b64encode(data).decode('utf-8')
    
    @staticmethod
    def from_base64(base64_str: str) -> bytes:
        """Convert base64 string to bytes"""
        return base64.b64decode(base64_str.encode('utf-8'))

class Cache:
    """Simple in-memory cache with expiration"""
    
    def __init__(self, max_size: int = 1000, default_ttl: int = 3600):
        self.max_size = max_size
        self.default_ttl = default_ttl
        self._cache: Dict[str, Dict[str, Any]] = {}
        self._access_times: Dict[str, float] = {}
        self._lock = threading.RLock()
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        with self._lock:
            if key not in self._cache:
                return None
            
            entry = self._cache[key]
            
            # Check expiration
            if time.time() > entry['expires_at']:
                del self._cache[key]
                del self._access_times[key]
                return None
            
            # Update access time
            self._access_times[key] = time.time()
            return entry['value']
    
    def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """Set value in cache"""
        with self._lock:
            # Evict oldest entries if cache is full
            if len(self._cache) >= self.max_size:
                self._evict_oldest()
            
            expires_at = time.time() + (ttl or self.default_ttl)
            self._cache[key] = {
                'value': value,
                'expires_at': expires_at
            }
            self._access_times[key] = time.time()
    
    def delete(self, key: str) -> bool:
        """Delete value from cache"""
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                del self._access_times[key]
                return True
            return False
    
    def clear(self) -> None:
        """Clear all cache entries"""
        with self._lock:
            self._cache.clear()
            self._access_times.clear()
    
    def _evict_oldest(self) -> None:
        """Evict least recently used entries"""
        # Sort by access time and remove oldest
        sorted_keys = sorted(self._access_times.keys(), key=lambda k: self._access_times[k])
        keys_to_remove = sorted_keys[:max(1, len(sorted_keys) // 10)]  # Remove 10%
        
        for key in keys_to_remove:
            if key in self._cache:
                del self._cache[key]
            del self._access_times[key]
    
    def size(self) -> int:
        """Get current cache size"""
        return len(self._cache)
    
    def keys(self) -> List[str]:
        """Get all cache keys"""
        return list(self._cache.keys())

class Registry:
    """Generic registry for managing named objects"""
    
    def __init__(self):
        self._items: Dict[str, Any] = {}
        self._lock = threading.RLock()
    
    def register(self, name: str, item: Any) -> None:
        """Register an item"""
        with self._lock:
            self._items[name] = item
    
    def get(self, name: str, default: Any = None) -> Any:
        """Get registered item"""
        with self._lock:
            return self._items.get(name, default)
    
    def unregister(self, name: str) -> bool:
        """Unregister an item"""
        with self._lock:
            if name in self._items:
                del self._items[name]
                return True
            return False
    
    def list(self) -> List[str]:
        """List all registered items"""
        with self._lock:
            return list(self._items.keys())
    
    def clear(self) -> None:
        """Clear all items"""
        with self._lock:
            self._items.clear()

# Global instances
_global_cache = None
_global_registry = None
_global_performance_monitor = None

def get_cache(max_size: int = 1000, default_ttl: int = 3600) -> Cache:
    """Get global cache instance"""
    global _global_cache
    if _global_cache is None:
        _global_cache = Cache(max_size, default_ttl)
    return _global_cache

def get_registry() -> Registry:
    """Get global registry instance"""
    global _global_registry
    if _global_registry is None:
        _global_registry = Registry()
    return _global_registry

def get_performance_monitor() -> PerformanceMonitor:
    """Get global performance monitor instance"""
    global _global_performance_monitor
    if _global_performance_monitor is None:
        _global_performance_monitor = PerformanceMonitor()
    return _global_performance_monitor

# Decorators for common patterns
def memoize(ttl: int = 3600, max_size: int = 1000):
    """Memoization decorator with TTL"""
    cache = get_cache(max_size, ttl)
    
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Create cache key from function name and arguments
            key = f"{func.__name__}:{hash(str(args) + str(sorted(kwargs.items())))}"
            
            # Try to get from cache
            result = cache.get(key)
            if result is not None:
                return result
            
            # Compute and cache result
            result = func(*args, **kwargs)
            cache.set(key, result)
            return result
        
        return wrapper
    return decorator

def singleton(cls):
    """Singleton decorator"""
    instances = {}
    lock = threading.Lock()
    
    @functools.wraps(cls)
    def get_instance(*args, **kwargs):
        if cls not in instances:
            with lock:
                if cls not in instances:
                    instances[cls] = cls(*args, **kwargs)
        return instances[cls]
    
    return get_instance

def rate_limit(calls_per_second: float):
    """Rate limiting decorator"""
    min_interval = 1.0 / calls_per_second
    last_called = [0.0]
    lock = threading.Lock()
    
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with lock:
                elapsed = time.time() - last_called[0]
                left_to_wait = min_interval - elapsed
                if left_to_wait > 0:
                    time.sleep(left_to_wait)
                last_called[0] = time.time()
                return func(*args, **kwargs)
        return wrapper
    return decorator

# Performance monitoring decorator
def monitor_performance(operation_name: str = None, log_result: bool = True):
    """Performance monitoring decorator"""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            name = operation_name or f"{func.__module__}.{func.__name__}"
            
            with timer_context(name) as timer:
                result = func(*args, **kwargs)
                
                if log_result:
                    elapsed_ms = timer.elapsed * 1000
                    logging.debug(f"Performance: {name} took {elapsed_ms:.2f}ms")
                
                return result
        
        return wrapper
    return decorator

# Validation decorator
def validate_input(validator_func: Callable):
    """Input validation decorator"""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if not validator_func(*args, **kwargs):
                raise ValidationError(f"Input validation failed for {func.__name__}")
            return func(*args, **kwargs)
        return wrapper
    return decorator

if __name__ == "__main__":
    # Test the utilities
    import asyncio
    
    async def test_utilities():
        # Test data processing
        data = [1, 2, 3, 4, 5, 100]
        normalized = DataProcessor.normalize_data(data)
        print(f"Normalized data: {normalized}")
        
        outliers = DataProcessor.detect_outliers(data)
        print(f"Outliers: {outliers}")
        
        # Test math utilities
        correlation = MathUtils.calculate_correlation([1, 2, 3, 4], [2, 4, 6, 8])
        print(f"Correlation: {correlation}")
        
        moving_avg = MathUtils.moving_average(data, window_size=3)
        print(f"Moving average: {moving_avg}")
        
        # Test timer
        with timer_context("test_operation") as timer:
            await asyncio.sleep(0.1)
            print(f"Elapsed time: {timer.elapsed:.3f}s")
        
        # Test cache
        cache = get_cache()
        cache.set("test_key", "test_value")
        print(f"Cache get: {cache.get('test_key')}")
        
        # Test memory snapshot
        monitor = get_performance_monitor()
        snapshot = monitor.take_memory_snapshot()
        if snapshot:
            print(f"Memory usage: {snapshot.rss_mb:.2f} MB")
    
    asyncio.run(test_utilities())
