"""
Self-Improving Feedback Loop Demo

Bu dosya Self-Improving Feedback Loop sisteminin kullanımını gösteren
pratik örnekler ve demo senaryoları içerir. Sistem bileşenlerinin nasıl
entegre edileceği ve kullanılacağına dair kapsamlı örnekler sunar.
"""

import asyncio
import logging
import json
from datetime import datetime, timedelta
from typing import Dict, Any, List

# Core imports
from core.orchestrator import SelfImprovingOrchestrator

# Component imports
from pipeline.continuous_learner import ContinuousLearner
from adaptation.automated_adapter import AutomatedSystemAdapter
from optimization.performance_optimizer import PerformanceOptimizer
from monitoring.system_monitor import SystemMonitor

# Integration imports
from integration.system_integrator import BitwisersSystemIntegrator
from integration.api_interface import create_api_interface, start_api_server

# Utils imports
from utils.config_manager import get_config_manager
from utils.logger import get_logger, get_performance_logger
from utils.helpers import timer_context, PerformanceContext

class SelfImprovingLoopDemo:
    """
    Self-Improving Feedback Loop sisteminin ana demo sınıfı
    
    Bu sınıf sistemin tüm bileşenlerini entegre ederek kapsamlı bir demo sunar:
    - Sistem başlatma ve konfigürasyon
    - Pipeline işlemleri (continuous learning)
    - Adaptasyon ve optimizasyon
    - Monitoring ve performans takibi
    - API interface ve real-time iletişim
    - Entegrasyon ve dış sistem bağlantıları
    """
    
    def __init__(self, config_dir: str = "./config", log_level: str = "INFO"):
        """Demo sınıfı başlatıcısı"""
        self.logger = get_logger('demo')
        self.perf_logger = get_performance_logger('demo')
        
        # Konfigürasyon yöneticisi
        self.config_manager = get_config_manager(config_dir)
        
        # Logger seviyesi ayarla
        logging.getLogger().setLevel(getattr(logging, log_level))
        
        # Ana bileşenler
        self.orchestrator = None
        self.continuous_learner = None
        self.automated_adapter = None
        self.performance_optimizer = None
        self.system_monitor = None
        self.system_integrator = None
        self.api_interface = None
        
        # Demo durumu
        self.is_running = False
        self.demo_data = self._generate_demo_data()
        
    def _generate_demo_data(self) -> Dict[str, Any]:
        """Demo için örnek veri üretir"""
        return {
            'training_data': [
                {'feature1': 1.2, 'feature2': 0.8, 'target': 0.7},
                {'feature1': 1.5, 'feature2': 0.9, 'target': 0.8},
                {'feature1': 2.0, 'feature2': 1.1, 'target': 0.9},
                {'feature1': 1.8, 'feature2': 0.95, 'target': 0.85},
                {'feature1': 1.3, 'feature2': 0.85, 'target': 0.75}
            ],
            'performance_metrics': {
                'accuracy': [0.75, 0.78, 0.82, 0.85, 0.87],
                'precision': [0.73, 0.76, 0.80, 0.83, 0.85],
                'recall': [0.77, 0.79, 0.81, 0.84, 0.86],
                'f1_score': [0.75, 0.77, 0.80, 0.83, 0.85]
            },
            'system_parameters': {
                'learning_rate': 0.001,
                'batch_size': 32,
                'max_epochs': 100,
                'early_stopping_patience': 10
            }
        }
    
    async def initialize_system(self):
        """Sistem bileşenlerini başlatır"""
        self.logger.info("Self-Improving Feedback Loop sistemi başlatılıyor...")
        
        with PerformanceContext("system_initialization"):
            try:
                # Ana orchestrator'ı başlat
                orchestrator_config = self.config_manager.get_config('system', {})
                self.orchestrator = SelfImprovingOrchestrator(orchestrator_config)
                
                # Pipeline bileşenlerini başlat
                pipeline_config = self.config_manager.get_config('pipeline', {})
                self.continuous_learner = ContinuousLearner(pipeline_config)
                
                # Adaptation bileşenlerini başlat
                adaptation_config = self.config_manager.get_config('adaptation', {})
                self.automated_adapter = AutomatedSystemAdapter(adaptation_config)
                
                # Optimization bileşenlerini başlat
                optimization_config = self.config_manager.get_config('optimization', {})
                self.performance_optimizer = PerformanceOptimizer(optimization_config)
                
                # Monitoring bileşenlerini başlat
                monitoring_config = self.config_manager.get_config('monitoring', {})
                self.system_monitor = SystemMonitor(monitoring_config)
                
                # Entegrasyon bileşenlerini başlat
                integration_config = self.config_manager.get_config('integration', {})
                self.system_integrator = BitwisersSystemIntegrator(integration_config)
                
                # API interface'ı başlat
                api_config = self.config_manager.get_config('api', {})
                self.api_interface = create_api_interface(self.orchestrator, api_config)
                
                self.logger.info("Tüm sistem bileşenleri başarıyla başlatıldı")
                
            except Exception as e:
                self.logger.error(f"Sistem başlatma hatası: {e}")
                raise
    
    async def demonstrate_continuous_learning(self):
        """Continuous Learning sürecini demo eder"""
        self.logger.info("Continuous Learning demo başlatılıyor...")
        
        try:
            with PerformanceContext("continuous_learning_demo"):
                # Learning stratejisi seç
                learning_strategies = ['online', 'batch', 'incremental']
                
                for strategy in learning_strategies:
                    self.logger.info(f"Testing {strategy} learning strategy...")
                    
                    # Learning verilerini hazırla
                    training_data = self.demo_data['training_data']
                    
                    # Continuous learner ile learning başlat
                    learning_result = await self.continuous_learner.start_learning(
                        data_source='demo_data',
                        learning_type=strategy,
                        training_data=training_data,
                        learning_parameters=self.demo_data['system_parameters']
                    )
                    
                    self.logger.info(f"{strategy} learning completed: {learning_result}")
                    
                    # Learning progress'i izle
                    await self._monitor_learning_progress(learning_result['learning_id'])
                    
                    # Knowledge extraction
                    if learning_result.get('status') == 'completed':
                        knowledge = await self.continuous_learner.extract_knowledge(
                            learning_result['learning_id']
                        )
                        self.logger.info(f"Knowledge extracted: {len(knowledge.get('patterns', []))} patterns")
                
        except Exception as e:
            self.logger.error(f"Continuous learning demo hatası: {e}")
    
    async def demonstrate_adaptation(self):
        """Adaptasyon sürecini demo eder"""
        self.logger.info("Adaptation demo başlatılıyor...")
        
        try:
            with PerformanceContext("adaptation_demo"):
                # Change detection ile veri değişimini tespit et
                change_detection_result = await self.automated_adapter.detect_changes(
                    baseline_data=self.demo_data['training_data'][:3],
                    current_data=self.demo_data['training_data'][3:],
                    detection_config={'sensitivity': 0.1}
                )
                
                self.logger.info(f"Change detection result: {change_detection_result}")
                
                # Regime detection
                if change_detection_result.get('drift_detected', False):
                    regime_result = await self.automated_adapter.detect_regime_change(
                        historical_performance=self.demo_data['performance_metrics']['accuracy'],
                        current_data=self.demo_data['training_data']
                    )
                    
                    self.logger.info(f"Regime change detected: {regime_result}")
                    
                    # Adaptasyon stratejisi uygula
                    adaptation_strategy = self.automated_adapter.select_adaptation_strategy(
                        detected_changes=change_detection_result,
                        regime_info=regime_result,
                        current_performance=self.demo_data['performance_metrics']
                    )
                    
                    # Adaptasyonu gerçekleştir
                    adaptation_result = await self.automated_adapter.execute_adaptation(
                        strategy=adaptation_strategy,
                        adaptation_scope='model_parameters'
                    )
                    
                    self.logger.info(f"Adaptation completed: {adaptation_result}")
                    
                    # Rollback kontrolü
                    rollback_check = await self.automated_adapter.check_rollback_conditions(
                        adaptation_result
                    )
                    
                    if rollback_check.get('rollback_required', False):
                        self.logger.warning("Rollback initiated due to performance degradation")
                        await self.automated_adapter.execute_rollback(
                            snapshot_id=rollback_check.get('rollback_snapshot_id')
                        )
                
        except Exception as e:
            self.logger.error(f"Adaptation demo hatası: {e}")
    
    async def demonstrate_optimization(self):
        """Optimizasyon sürecini demo eder"""
        self.logger.info("Optimization demo başlatılıyor...")
        
        try:
            with PerformanceContext("optimization_demo"):
                # Multi-objective optimization
                optimization_objectives = {
                    'primary': 'maximize_accuracy',
                    'secondary': ['minimize_training_time', 'minimize_model_complexity']
                }
                
                optimization_constraints = {
                    'max_training_time': 300,  # 5 minutes
                    'max_memory_usage': 1024,  # 1GB
                    'model_size_limit': 100  # 100MB
                }
                
                # Performance optimization başlat
                optimization_result = await self.performance_optimizer.optimize_system(
                    objectives=optimization_objectives,
                    constraints=optimization_constraints,
                    current_performance=self.demo_data['performance_metrics']
                )
                
                self.logger.info(f"Optimization completed: {optimization_result}")
                
                # Hyperparameter tuning
                tuning_objectives = [
                    {
                        'parameter': 'learning_rate',
                        'range': [0.0001, 0.01],
                        'distribution': 'log_uniform'
                    },
                    {
                        'parameter': 'batch_size', 
                        'range': [16, 128],
                        'distribution': 'uniform'
                    }
                ]
                
                tuning_result = await self.performance_optimizer.tune_hyperparameters(
                    objectives=tuning_objectives,
                    optimization_metric='f1_score',
                    max_trials=50,
                    timeout_seconds=600
                )
                
                self.logger.info(f"Hyperparameter tuning completed: {tuning_result}")
                
                # Pareto optimization results
                if 'pareto_front' in tuning_result:
                    self.logger.info(f"Pareto optimal solutions: {len(tuning_result['pareto_front'])}")
                    
                    # En iyi çözümü seç
                    best_solution = self.performance_optimizer.select_optimal_solution(
                        tuning_result['pareto_front'],
                        preference_weights={'accuracy': 0.6, 'speed': 0.4}
                    )
                    
                    self.logger.info(f"Selected optimal solution: {best_solution}")
                
        except Exception as e:
            self.logger.error(f"Optimization demo hatası: {e}")
    
    async def demonstrate_monitoring(self):
        """Monitoring sürecini demo eder"""
        self.logger.info("Monitoring demo başlatılıyor...")
        
        try:
            with PerformanceContext("monitoring_demo"):
                # Sistem sağlık kontrolü
                health_check = await self.system_monitor.check_system_health()
                self.logger.info(f"System health: {health_check}")
                
                # Performans metriklerini topla
                performance_metrics = await self.system_monitor.collect_performance_metrics()
                self.logger.info(f"Performance metrics collected: {len(performance_metrics)} metrics")
                
                # Anomali tespiti
                anomaly_result = await self.system_monitor.detect_anomalies(
                    current_metrics=performance_metrics,
                    baseline_metrics=self.demo_data['performance_metrics'],
                    sensitivity=0.95
                )
                
                if anomaly_result.get('anomalies_detected', False):
                    self.logger.warning(f"Anomalies detected: {anomaly_result}")
                    
                    # Alert gönder
                    await self.system_monitor.send_alert(
                        alert_type='performance_anomaly',
                        severity='medium',
                        message=f"Anomalies detected in {len(anomaly_result.get('anomaly_metrics', []))} metrics",
                        context=anomaly_result
                    )
                
                # Statistical Process Control
                spc_result = await self.system_monitor.run_statistical_process_control(
                    metric_history=performance_metrics.get('metric_history', []),
                    control_limits={'upper': 2.0, 'lower': -2.0}
                )
                
                self.logger.info(f"SPC analysis completed: {spc_result}")
                
                # Trend analizi
                trend_analysis = await self.system_monitor.analyze_performance_trends(
                    performance_data=self.demo_data['performance_metrics'],
                    lookback_period_days=7
                )
                
                self.logger.info(f"Trend analysis: {trend_analysis}")
                
        except Exception as e:
            self.logger.error(f"Monitoring demo hatası: {e}")
    
    async def demonstrate_integration(self):
        """Entegrasyon sürecini demo eder"""
        self.logger.info("Integration demo başlatılıyor...")
        
        try:
            with PerformanceContext("integration_demo"):
                # Bileşenlere bağlan
                connection_result = await self.system_integrator.connect_components()
                self.logger.info(f"Component connections: {connection_result}")
                
                # Integration workflows
                workflows = [
                    'optimization_cycle',
                    'learning_adaptation',
                    'strategy_update',
                    'performance_analysis'
                ]
                
                for workflow in workflows:
                    self.logger.info(f"Executing integration workflow: {workflow}")
                    
                    # Workflow için demo data hazırla
                    workflow_data = {
                        'current_params': self.demo_data['system_parameters'],
                        'strategy': 'adaptive',
                        'performance_data': self.demo_data['performance_metrics']['accuracy'],
                        'objective': 'maximize_performance'
                    }
                    
                    # Workflow'u çalıştır
                    workflow_result = await self.system_integrator.execute_integration_workflow(
                        workflow_type=workflow,
                        data=workflow_data
                    )
                    
                    self.logger.info(f"Workflow {workflow} completed: {workflow_result}")
                
                # Sistem durumu raporu
                component_status = self.system_integrator.get_component_status()
                self.logger.info(f"Component status: {component_status}")
                
                # Sağlık kontrolü
                health_report = await self.system_integrator.health_check()
                self.logger.info(f"Integration health: {health_report}")
                
                # Entegrasyon raporu
                integration_report = self.system_integrator.get_integration_report()
                self.logger.info(f"Integration report: {integration_report}")
                
        except Exception as e:
            self.logger.error(f"Integration demo hatası: {e}")
    
    async def demonstrate_api_interface(self):
        """API Interface'i demo eder"""
        self.logger.info("API Interface demo başlatılıyor...")
        
        try:
            # API server'ı background'da başlat
            api_task = asyncio.create_task(
                start_api_server(self.orchestrator, host="127.0.0.1", port=8000)
            )
            
            # API server'ın başlamasını bekle
            await asyncio.sleep(2)
            
            self.logger.info("API server started at http://127.0.0.1:8000")
            self.logger.info("API documentation available at http://127.0.0.1:8000/docs")
            
            # API test istekleri simüle et
            await self._simulate_api_requests()
            
            # Demo süreci boyunca API server'ı çalıştır
            demo_duration = 10  # 10 saniye
            for i in range(demo_duration):
                self.logger.info(f"API demo running... {demo_duration - i} seconds remaining")
                await asyncio.sleep(1)
            
            # API server'ı durdur
            api_task.cancel()
            self.logger.info("API demo completed")
            
        except Exception as e:
            self.logger.error(f"API Interface demo hatası: {e}")
    
    async def _simulate_api_requests(self):
        """API isteklerini simüle eder"""
        import aiohttp
        
        async with aiohttp.ClientSession() as session:
            base_url = "http://127.0.0.1:8000"
            
            try:
                # Health check
                async with session.get(f"{base_url}/health") as response:
                    health_data = await response.json()
                    self.logger.info(f"API Health check: {health_data}")
                
                # Metrics request
                async with session.get(f"{base_url}/metrics") as response:
                    metrics_data = await response.json()
                    self.logger.info(f"API Metrics: {len(metrics_data.get('current_metrics', {}))} metrics")
                
                # System status
                async with session.get(f"{base_url}/status") as response:
                    status_data = await response.json()
                    self.logger.info(f"API Status: {status_data.get('active_processes', 0)} active processes")
                
                # Optimization request
                optimization_request = {
                    "objective": "maximize_accuracy",
                    "parameters": {"learning_rate": 0.001},
                    "priority": "medium"
                }
                
                async with session.post(f"{base_url}/optimize", json=optimization_request) as response:
                    optimization_result = await response.json()
                    self.logger.info(f"API Optimization started: {optimization_result.get('data', {})}")
                
            except aiohttp.ClientError as e:
                self.logger.warning(f"API request failed (server may not be ready): {e}")
    
    async def _monitor_learning_progress(self, learning_id: str):
        """Learning progress'i izler"""
        max_attempts = 10
        attempt = 0
        
        while attempt < max_attempts:
            try:
                # Progress kontrol et
                progress = await self.continuous_learner.get_learning_progress(learning_id)
                
                if progress.get('status') in ['completed', 'failed']:
                    break
                
                self.logger.info(f"Learning progress: {progress.get('progress', 0):.1%}")
                await asyncio.sleep(1)
                attempt += 1
                
            except Exception as e:
                self.logger.error(f"Learning progress monitoring error: {e}")
                break
    
    async def run_full_demo(self):
        """Tam demo sürecini çalıştırır"""
        self.logger.info("=" * 60)
        self.logger.info("Self-Improving Feedback Loop Full Demo")
        self.logger.info("=" * 60)
        
        try:
            # Sistemi başlat
            await self.initialize_system()
            
            # Her demo modülünü sırasıyla çalıştır
            demos = [
                ("Continuous Learning", self.demonstrate_continuous_learning),
                ("Adaptation", self.demonstrate_adaptation),
                ("Optimization", self.demonstrate_optimization),
                ("Monitoring", self.demonstrate_monitoring),
                ("Integration", self.demonstrate_integration),
                ("API Interface", self.demonstrate_api_interface)
            ]
            
            for demo_name, demo_func in demos:
                self.logger.info(f"\n--- {demo_name} Demo ---")
                
                start_time = datetime.now()
                await demo_func()
                end_time = datetime.now()
                
                duration = (end_time - start_time).total_seconds()
                self.logger.info(f"{demo_name} completed in {duration:.2f} seconds")
            
            # Final sistem durumu
            self.logger.info("\n--- Final System Status ---")
            final_health = await self.system_monitor.check_system_health()
            self.logger.info(f"Final system health: {final_health}")
            
            # Performance summary
            performance_summary = await self.orchestrator.get_performance_summary()
            self.logger.info(f"Performance summary: {performance_summary}")
            
            self.logger.info("\n" + "=" * 60)
            self.logger.info("Self-Improving Feedback Loop Demo Completed Successfully!")
            self.logger.info("=" * 60)
            
        except Exception as e:
            self.logger.error(f"Demo hatası: {e}")
            raise
        finally:
            await self.cleanup()
    
    async def cleanup(self):
        """Sistem kaynaklarını temizler"""
        self.logger.info("Sistem temizliği başlatılıyor...")
        
        try:
            if self.system_integrator:
                await self.system_integrator.disconnect()
            
            if self.orchestrator:
                await self.orchestrator.shutdown()
            
            self.logger.info("Sistem temizliği tamamlandı")
            
        except Exception as e:
            self.logger.error(f"Sistem temizliği hatası: {e}")
    
    def get_demo_configuration(self) -> Dict[str, Any]:
        """Demo konfigürasyonunu döndürür"""
        return {
            'system': {
                'debug_mode': True,
                'log_level': 'DEBUG',
                'max_workers': 2
            },
            'pipeline': {
                'continuous_learning': {
                    'enabled': True,
                    'learning_interval_minutes': 1,
                    'batch_size': 10
                }
            },
            'adaptation': {
                'automated_adapter': {
                    'enabled': True,
                    'adaptation_threshold': 0.05
                }
            },
            'optimization': {
                'performance_optimizer': {
                    'enabled': True,
                    'optimization_interval_hours': 1
                }
            },
            'monitoring': {
                'system_monitor': {
                    'enabled': True,
                    'monitoring_interval_seconds': 5
                }
            },
            'integration': {
                'system_integrator': {
                    'enabled': True,
                    'health_check_interval_seconds': 10
                }
            },
            'api': {
                'api_interface': {
                    'enabled': True,
                    'host': '127.0.0.1',
                    'port': 8000
                }
            }
        }

async def main():
    """Ana demo fonksiyonu"""
    # Demo sınıfını oluştur
    demo = SelfImprovingLoopDemo(log_level="INFO")
    
    # Demo konfigürasyonunu ayarla
    demo_config = demo.get_demo_configuration()
    
    # Konfigürasyonu güncelle
    for config_name, config_data in demo_config.items():
        demo.config_manager.update_config(config_name, config_data)
    
    # Full demo'yu çalıştır
    await demo.run_full_demo()

if __name__ == "__main__":
    # Demo'yu çalıştır
    asyncio.run(main())
