"""
Self-Improving Feedback Loop API Interface

Bu modül self-improving feedback loop sistemi için REST API endpoint'leri 
ve WebSocket real-time iletişimi sağlar. Sistem durumu, performans metrikleri,
konfigürasyon yönetimi ve real-time event streaming için API sağlar.
"""

import asyncio
import logging
import json
from typing import Dict, Any, Optional, List, Union
from datetime import datetime
from dataclasses import dataclass, asdict
from enum import Enum
import uuid
import websockets
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
import uvicorn

# API Response modelleri
class APIStatus(BaseModel):
    status: str
    timestamp: datetime
    version: str = "1.0.0"
    uptime: float

class SystemHealthResponse(BaseModel):
    overall_health_score: float
    component_status: Dict[str, Any]
    integration_status: str
    timestamp: datetime

class PerformanceMetricsResponse(BaseModel):
    current_metrics: Dict[str, float]
    historical_data: List[Dict[str, Any]]
    trends: Dict[str, str]
    timestamp: datetime

class OptimizationRequest(BaseModel):
    objective: str = Field(..., description="Optimizasyon hedefi")
    constraints: Optional[Dict[str, Any]] = None
    parameters: Dict[str, Any] = Field(default_factory=dict)
    priority: str = Field(default="medium", description="Öncelik seviyesi")

class LearningRequest(BaseModel):
    data_source: str = Field(..., description="Veri kaynağı")
    learning_type: str = Field(..., description="Öğrenme tipi")
    parameters: Dict[str, Any] = Field(default_factory=dict)
    batch_size: Optional[int] = None

class ConfigurationUpdateRequest(BaseModel):
    component: str = Field(..., description="Güncellenecek bileşen")
    config: Dict[str, Any] = Field(..., description="Yeni konfigürasyon")
    restart_required: bool = Field(default=False)

class WebSocketMessage(BaseModel):
    type: str
    data: Dict[str, Any]
    timestamp: datetime = Field(default_factory=datetime.now)
    message_id: str = Field(default_factory=lambda: str(uuid.uuid4()))

class SelfImprovingAPIInterface:
    """
    Self-Improving Feedback Loop sistemi için API arayüzü
    
    Bu sınıf aşağıdaki API endpoint'lerini sağlar:
    - Sistem durumu ve sağlık kontrolü
    - Performans metrikleri ve analiz
    - Optimizasyon işlemleri
    - Öğrenme ve adaptasyon işlemleri
    - Konfigürasyon yönetimi
    - Real-time WebSocket iletişimi
    """
    
    def __init__(self, orchestrator=None, config: Optional[Dict[str, Any]] = None):
        self.logger = logging.getLogger(__name__)
        self.orchestrator = orchestrator
        self.config = config or {}
        self.app = FastAPI(
            title="Self-Improving Feedback Loop API",
            description="Bitwisers 2.0 Self-Improving Feedback Loop Sistemi API",
            version="1.0.0"
        )
        self.connected_clients: List[WebSocket] = []
        self.event_history: List[Dict[str, Any]] = []
        self.start_time = datetime.now()
        
        # CORS middleware ekle
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
        
        # API route'larını kaydet
        self._setup_routes()
        
    def _setup_routes(self):
        """API route'larını yapılandırır"""
        
        @self.app.get("/", response_model=APIStatus)
        async def root():
            """Ana endpoint - API durumunu döndürür"""
            return APIStatus(
                status="active",
                timestamp=datetime.now(),
                uptime=(datetime.now() - self.start_time).total_seconds()
            )
        
        @self.app.get("/health", response_model=SystemHealthResponse)
        async def health_check():
            """Sistem sağlık kontrolü"""
            try:
                if self.orchestrator:
                    health_data = await self.orchestrator.get_system_health()
                else:
                    health_data = {
                        'overall_health_score': 0.85,
                        'component_status': {'core': 'healthy'},
                        'integration_status': 'active'
                    }
                
                return SystemHealthResponse(
                    overall_health_score=health_data.get('overall_health_score', 0.0),
                    component_status=health_data.get('component_status', {}),
                    integration_status=health_data.get('integration_status', 'unknown'),
                    timestamp=datetime.now()
                )
            except Exception as e:
                self.logger.error(f"Sağlık kontrolü hatası: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.get("/metrics", response_model=PerformanceMetricsResponse)
        async def get_performance_metrics():
            """Performans metriklerini getir"""
            try:
                if self.orchestrator:
                    metrics_data = await self.orchestrator.get_performance_metrics()
                else:
                    # Örnek metrik verisi
                    metrics_data = {
                        'current_metrics': {
                            'accuracy': 0.85,
                            'precision': 0.82,
                            'recall': 0.88,
                            'f1_score': 0.85,
                            'learning_rate': 0.001
                        },
                        'historical_data': [
                            {'timestamp': '2024-01-01', 'accuracy': 0.80},
                            {'timestamp': '2024-01-02', 'accuracy': 0.82}
                        ],
                        'trends': {
                            'accuracy': 'improving',
                            'learning_rate': 'stable'
                        }
                    }
                
                return PerformanceMetricsResponse(
                    current_metrics=metrics_data.get('current_metrics', {}),
                    historical_data=metrics_data.get('historical_data', []),
                    trends=metrics_data.get('trends', {}),
                    timestamp=datetime.now()
                )
            except Exception as e:
                self.logger.error(f"Metrik getirme hatası: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.post("/optimize")
        async def optimize_system(request: OptimizationRequest):
            """Sistem optimizasyonu başlat"""
            try:
                self.logger.info(f"Optimizasyon isteği alındı: {request.objective}")
                
                if self.orchestrator:
                    result = await self.orchestrator.start_optimization(
                        objective=request.objective,
                        constraints=request.constraints,
                        parameters=request.parameters
                    )
                else:
                    # Simüle edilmiş optimizasyon sonucu
                    result = {
                        'optimization_id': str(uuid.uuid4()),
                        'status': 'started',
                        'estimated_completion': '10 minutes',
                        'improvement_potential': 0.15
                    }
                
                # WebSocket ile event gönder
                await self.broadcast_message({
                    'type': 'optimization_started',
                    'data': result,
                    'timestamp': datetime.now()
                })
                
                return {
                    'success': True,
                    'message': 'Optimizasyon başlatıldı',
                    'data': result
                }
                
            except Exception as e:
                self.logger.error(f"Optimizasyon hatası: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.post("/learn")
        async def start_learning(request: LearningRequest):
            """Öğrenme işlemini başlat"""
            try:
                self.logger.info(f"Öğrenme isteği alındı: {request.learning_type}")
                
                if self.orchestrator:
                    result = await self.orchestrator.start_learning(
                        data_source=request.data_source,
                        learning_type=request.learning_type,
                        parameters=request.parameters
                    )
                else:
                    result = {
                        'learning_id': str(uuid.uuid4()),
                        'status': 'started',
                        'data_source': request.data_source,
                        'learning_type': request.learning_type,
                        'progress': 0.0
                    }
                
                # WebSocket ile event gönder
                await self.broadcast_message({
                    'type': 'learning_started',
                    'data': result,
                    'timestamp': datetime.now()
                })
                
                return {
                    'success': True,
                    'message': 'Öğrenme başlatıldı',
                    'data': result
                }
                
            except Exception as e:
                self.logger.error(f"Öğrenme hatası: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.get("/status")
        async def get_system_status():
            """Detaylı sistem durumunu getir"""
            try:
                if self.orchestrator:
                    status_data = await self.orchestrator.get_detailed_status()
                else:
                    status_data = {
                        'phases': {
                            'continuous_learning': {'status': 'active', 'progress': 85},
                            'automated_adaptation': {'status': 'active', 'progress': 92},
                            'performance_optimization': {'status': 'active', 'progress': 78},
                            'parameter_tuning': {'status': 'active', 'progress': 88},
                            'system_monitoring': {'status': 'active', 'progress': 95}
                        },
                        'active_processes': 12,
                        'queued_tasks': 3,
                        'memory_usage': 0.65,
                        'cpu_usage': 0.45
                    }
                
                return {
                    'success': True,
                    'data': status_data,
                    'timestamp': datetime.now().isoformat()
                }
                
            except Exception as e:
                self.logger.error(f"Durum getirme hatası: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.post("/config")
        async def update_configuration(request: ConfigurationUpdateRequest):
            """Konfigürasyonu güncelle"""
            try:
                self.logger.info(f"Konfigürasyon güncelleme: {request.component}")
                
                # Konfigürasyon güncellemesini uygula
                success = await self._update_component_config(
                    request.component, 
                    request.config
                )
                
                if success:
                    # WebSocket ile event gönder
                    await self.broadcast_message({
                        'type': 'config_updated',
                        'data': {
                            'component': request.component,
                            'config': request.config
                        },
                        'timestamp': datetime.now()
                    })
                    
                    return {
                        'success': True,
                        'message': f"{request.component} konfigürasyonu güncellendi",
                        'restart_required': request.restart_required
                    }
                else:
                    raise HTTPException(status_code=400, detail="Konfigürasyon güncelleme başarısız")
                
            except HTTPException:
                raise
            except Exception as e:
                self.logger.error(f"Konfigürasyon güncelleme hatası: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.get("/events")
        async def get_recent_events(limit: int = 100):
            """Son event'leri getir"""
            try:
                events = self.event_history[-limit:] if self.event_history else []
                
                return {
                    'success': True,
                    'data': events,
                    'count': len(events),
                    'timestamp': datetime.now().isoformat()
                }
                
            except Exception as e:
                self.logger.error(f"Event getirme hatası: {e}")
                raise HTTPException(status_code=500, detail=str(e))
        
        @self.app.post("/stop")
        async def stop_system():
            """Sistemi durdur"""
            try:
                if self.orchestrator:
                    await self.orchestrator.shutdown()
                
                # WebSocket ile event gönder
                await self.broadcast_message({
                    'type': 'system_shutdown',
                    'data': {'status': 'shutdown_initiated'},
                    'timestamp': datetime.now()
                })
                
                return {
                    'success': True,
                    'message': 'Sistem kapatma işlemi başlatıldı'
                }
                
            except Exception as e:
                self.logger.error(f"Sistem durdurma hatası: {e}")
                raise HTTPException(status_code=500, detail=str(e))
    
    async def _update_component_config(self, component: str, config: Dict[str, Any]) -> bool:
        """Bileşen konfigürasyonunu günceller"""
        try:
            # Gerçek implementasyonda bileşene özel güncelleme yapılır
            self.logger.info(f"{component} konfigürasyonu güncelleniyor: {config}")
            
            # Simüle edilmiş güncelleme
            return True
            
        except Exception as e:
            self.logger.error(f"Konfigürasyon güncelleme hatası: {e}")
            return False
    
    @self.app.websocket("/ws")
    async def websocket_endpoint(self, websocket: WebSocket):
        """WebSocket endpoint - Real-time iletişim"""
        await self.websocket_handler(websocket)
    
    async def websocket_handler(self, websocket: WebSocket):
        """WebSocket bağlantısını yönetir"""
        try:
            await websocket.accept()
            self.connected_clients.append(websocket)
            
            self.logger.info(f"WebSocket bağlantısı kuruldu. Toplam bağlantı: {len(self.connected_clients)}")
            
            # Karşılama mesajı gönder
            welcome_message = {
                'type': 'welcome',
                'data': {
                    'client_id': str(uuid.uuid4()),
                    'connection_time': datetime.now().isoformat(),
                    'supported_events': [
                        'optimization_started',
                        'optimization_completed', 
                        'learning_started',
                        'learning_progress',
                        'learning_completed',
                        'system_alert',
                        'performance_update',
                        'config_updated',
                        'system_shutdown'
                    ]
                },
                'timestamp': datetime.now()
            }
            
            await websocket.send_json(welcome_message)
            
            # Mesajları dinle
            while True:
                try:
                    data = await websocket.receive_text()
                    message = json.loads(data)
                    
                    # Mesajı işle
                    await self._handle_websocket_message(websocket, message)
                    
                except WebSocketDisconnect:
                    break
                except json.JSONDecodeError:
                    await websocket.send_json({
                        'type': 'error',
                        'data': {'message': 'Geçersiz JSON formatı'},
                        'timestamp': datetime.now()
                    })
                except Exception as e:
                    self.logger.error(f"WebSocket mesaj hatası: {e}")
                    await websocket.send_json({
                        'type': 'error',
                        'data': {'message': 'Mesaj işleme hatası'},
                        'timestamp': datetime.now()
                    })
                    
        except WebSocketDisconnect:
            pass
        except Exception as e:
            self.logger.error(f"WebSocket hatası: {e}")
        finally:
            # Bağlantıyı kaldır
            if websocket in self.connected_clients:
                self.connected_clients.remove(websocket)
            
            self.logger.info(f"WebSocket bağlantısı kapatıldı. Kalan bağlantı: {len(self.connected_clients)}")
    
    async def _handle_websocket_message(self, websocket: WebSocket, message: Dict[str, Any]):
        """WebSocket mesajını işler"""
        try:
            message_type = message.get('type')
            message_data = message.get('data', {})
            
            if message_type == 'ping':
                # Ping-pong işlemi
                await websocket.send_json({
                    'type': 'pong',
                    'data': {'timestamp': datetime.now().isoformat()},
                    'timestamp': datetime.now()
                })
            
            elif message_type == 'subscribe':
                # Event subscription
                events = message_data.get('events', [])
                self.logger.info(f"WebSocket istemci {events} event'lerine abone oldu")
                
                await websocket.send_json({
                    'type': 'subscription_confirmed',
                    'data': {'subscribed_events': events},
                    'timestamp': datetime.now()
                })
            
            elif message_type == 'request_status':
                # Sistem durumu isteği
                if self.orchestrator:
                    status = await self.orchestrator.get_detailed_status()
                else:
                    status = {'status': 'simulation_mode'}
                
                await websocket.send_json({
                    'type': 'status_update',
                    'data': status,
                    'timestamp': datetime.now()
                })
            
            elif message_type == 'request_metrics':
                # Metrik isteği
                if self.orchestrator:
                    metrics = await self.orchestrator.get_performance_metrics()
                else:
                    metrics = {'metrics': 'simulation_mode'}
                
                await websocket.send_json({
                    'type': 'metrics_update',
                    'data': metrics,
                    'timestamp': datetime.now()
                })
            
            else:
                await websocket.send_json({
                    'type': 'error',
                    'data': {'message': f'Bilinmeyen mesaj tipi: {message_type}'},
                    'timestamp': datetime.now()
                })
                
        except Exception as e:
            self.logger.error(f"WebSocket mesaj işleme hatası: {e}")
            await websocket.send_json({
                'type': 'error',
                'data': {'message': 'Mesaj işleme hatası'},
                'timestamp': datetime.now()
            })
    
    async def broadcast_message(self, message: Dict[str, Any]):
        """Tüm bağlı WebSocket istemcilerine mesaj gönderir"""
        if not self.connected_clients:
            return
        
        message['timestamp'] = datetime.now()
        
        # Event history'ye ekle
        self.event_history.append(message.copy())
        if len(self.event_history) > 1000:
            self.event_history = self.event_history[-500:]  # Son 500 event'i tut
        
        # Mesajı tüm istemcilere gönder
        disconnected_clients = []
        
        for websocket in self.connected_clients:
            try:
                await websocket.send_json(message)
            except websockets.exceptions.ConnectionClosed:
                disconnected_clients.append(websocket)
            except Exception as e:
                self.logger.error(f"WebSocket mesaj gönderme hatası: {e}")
                disconnected_clients.append(websocket)
        
        # Kapanmış bağlantıları temizle
        for websocket in disconnected_clients:
            if websocket in self.connected_clients:
                self.connected_clients.remove(websocket)
    
    async def send_system_alert(self, alert_type: str, message: str, severity: str = "info"):
        """Sistem uyarısı gönderir"""
        alert_message = {
            'type': 'system_alert',
            'data': {
                'alert_type': alert_type,
                'message': message,
                'severity': severity
            },
            'timestamp': datetime.now()
        }
        
        await self.broadcast_message(alert_message)
        self.logger.warning(f"Sistem uyarısı: {alert_type} - {message}")
    
    async def send_performance_update(self, metrics: Dict[str, Any]):
        """Performans güncellemesi gönderir"""
        performance_message = {
            'type': 'performance_update',
            'data': metrics,
            'timestamp': datetime.now()
        }
        
        await self.broadcast_message(performance_message)
    
    async def send_optimization_update(self, optimization_id: str, status: str, progress: float, result: Optional[Dict[str, Any]] = None):
        """Optimizasyon güncellemesi gönderir"""
        optimization_message = {
            'type': 'optimization_progress' if status == 'running' else 'optimization_completed',
            'data': {
                'optimization_id': optimization_id,
                'status': status,
                'progress': progress,
                'result': result
            },
            'timestamp': datetime.now()
        }
        
        await self.broadcast_message(optimization_message)
    
    def get_api_stats(self) -> Dict[str, Any]:
        """API istatistiklerini getirir"""
        return {
            'connected_websockets': len(self.connected_clients),
            'total_events': len(self.event_history),
            'uptime_seconds': (datetime.now() - self.start_time).total_seconds(),
            'api_version': '1.0.0',
            'endpoints_count': 8,
            'websocket_endpoint': '/ws'
        }

class MockOrchestrator:
    """Mock orchestrator for testing"""
    
    async def get_system_health(self) -> Dict[str, Any]:
        return {
            'overall_health_score': 0.92,
            'component_status': {'core': 'healthy', 'integration': 'healthy'},
            'integration_status': 'active'
        }
    
    async def get_performance_metrics(self) -> Dict[str, Any]:
        return {
            'current_metrics': {
                'accuracy': 0.87,
                'learning_rate': 0.001,
                'loss': 0.23
            },
            'historical_data': [],
            'trends': {'accuracy': 'improving'}
        }
    
    async def get_detailed_status(self) -> Dict[str, Any]:
        return {
            'phases': {
                'continuous_learning': {'status': 'active', 'progress': 90},
                'automated_adaptation': {'status': 'active', 'progress': 85},
                'performance_optimization': {'status': 'active', 'progress': 75},
                'parameter_tuning': {'status': 'active', 'progress': 88},
                'system_monitoring': {'status': 'active', 'progress': 95}
            },
            'active_processes': 15,
            'memory_usage': 0.68,
            'cpu_usage': 0.42
        }
    
    async def start_optimization(self, objective: str, constraints: Optional[Dict], parameters: Dict) -> Dict[str, Any]:
        return {
            'optimization_id': str(uuid.uuid4()),
            'status': 'started',
            'objective': objective
        }
    
    async def start_learning(self, data_source: str, learning_type: str, parameters: Dict) -> Dict[str, Any]:
        return {
            'learning_id': str(uuid.uuid4()),
            'status': 'started',
            'data_source': data_source,
            'learning_type': learning_type
        }
    
    async def shutdown(self):
        pass

# API başlatma fonksiyonu
def create_api_interface(orchestrator=None, config: Optional[Dict[str, Any]] = None) -> SelfImprovingAPIInterface:
    """API interface oluşturur ve döndürür"""
    if orchestrator is None:
        orchestrator = MockOrchestrator()
    
    return SelfImprovingAPIInterface(orchestrator, config)

async def start_api_server(orchestrator=None, host: str = "0.0.0.0", port: int = 8000):
    """API sunucusunu başlatır"""
    try:
        api_interface = create_api_interface(orchestrator)
        
        config = uvicorn.Config(
            api_interface.app,
            host=host,
            port=port,
            log_level="info"
        )
        
        server = uvicorn.Server(config)
        
        print(f"Self-Improving Feedback Loop API sunucusu başlatılıyor...")
        print(f"API: http://{host}:{port}")
        print(f"WebSocket: ws://{host}:{port}/ws")
        print(f"API Docs: http://{host}:{port}/docs")
        
        await server.serve()
        
    except Exception as e:
        logging.error(f"API sunucu hatası: {e}")

if __name__ == "__main__":
    # Test için standalone çalıştırma
    import asyncio
    
    async def main():
        await start_api_server()
    
    asyncio.run(main())
