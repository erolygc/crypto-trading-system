"""
Learning Strategies Module
Adaptive learning strategies for continuous improvement
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from enum import Enum

class LearningStrategy(Enum):
    """Types of learning strategies"""
    ONLINE_LEARNING = "online_learning"
    BATCH_LEARNING = "batch_learning"
    TRANSFER_LEARNING = "transfer_learning"
    META_LEARNING = "meta_learning"
    REINFORCEMENT_LEARNING = "reinforcement_learning"

@dataclass
class StrategyParameters:
    """Parameters for learning strategy"""
    learning_rate: float = 0.001
    batch_size: int = 100
    regularization: float = 0.01
    momentum: float = 0.9
    dropout_rate: float = 0.2
    epochs: int = 10
    validation_split: float = 0.2

class AdaptiveLearningStrategy:
    """
    Adaptive Learning Strategy system
    Dynamically adjusts learning parameters based on context
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.current_strategy = LearningStrategy.ONLINE_LEARNING
        self.strategy_params = StrategyParameters()
        self.strategy_history = []
        self.performance_history = []
        
    async def initialize(self) -> None:
        """Initialize learning strategy"""
        try:
            # Set initial parameters based on config
            if 'learning' in self.config:
                self.strategy_params.learning_rate = self.config['learning'].get(
                    'learning_rate', 0.001
                )
                self.strategy_params.batch_size = self.config['learning'].get(
                    'batch_size', 100
                )
            
            self.logger.info("Adaptive Learning Strategy initialized")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize learning strategy: {e}")
            raise
    
    async def adapt_parameters(self, context: Dict[str, Any]) -> None:
        """Adapt learning parameters based on current context"""
        try:
            performance_history = context.get('performance_history', [])
            learning_context = context.get('context', {})
            
            # Adapt based on volatility
            volatility = learning_context.get('volatility_level', 0.0)
            if volatility > 0.3:  # High volatility
                self.strategy_params.learning_rate *= 1.2
                self.strategy_params.regularization *= 1.1
            elif volatility < 0.1:  # Low volatility
                self.strategy_params.learning_rate *= 0.8
                self.strategy_params.regularization *= 0.9
            
            # Adapt based on recent performance
            if len(performance_history) > 5:
                recent_performance = sum(
                    p.get('performance', 0) for p in performance_history[-5:]
                ) / min(5, len(performance_history))
                
                if recent_performance < 0.6:  # Poor performance
                    self.strategy_params.learning_rate *= 0.5
                    self.strategy_params.epochs += 5
                elif recent_performance > 0.8:  # Good performance
                    self.strategy_params.learning_rate *= 1.1
                    self.strategy_params.batch_size = min(
                        self.strategy_params.batch_size * 2, 1000
                    )
            
            # Clamp parameters to reasonable bounds
            self.strategy_params.learning_rate = max(0.00001, min(0.1, self.strategy_params.learning_rate))
            self.strategy_params.batch_size = max(10, min(2000, self.strategy_params.batch_size))
            self.strategy_params.regularization = max(0.0, min(1.0, self.strategy_params.regularization))
            
            # Record adaptation
            self.strategy_history.append({
                'timestamp': asyncio.get_event_loop().time(),
                'volatility': volatility,
                'learning_rate': self.strategy_params.learning_rate,
                'batch_size': self.strategy_params.batch_size
            })
            
            self.logger.debug("Learning parameters adapted")
            
        except Exception as e:
            self.logger.error(f"Parameter adaptation failed: {e}")
    
    async def get_training_parameters(self) -> Dict[str, Any]:
        """Get current training parameters"""
        return {
            'strategy': self.current_strategy.value,
            'learning_rate': self.strategy_params.learning_rate,
            'batch_size': self.strategy_params.batch_size,
            'regularization': self.strategy_params.regularization,
            'momentum': self.strategy_params.momentum,
            'dropout_rate': self.strategy_params.dropout_rate,
            'epochs': self.strategy_params.epochs,
            'validation_split': self.strategy_params.validation_split
        }
    
    async def switch_strategy(self, new_strategy: LearningStrategy) -> None:
        """Switch to a different learning strategy"""
        if new_strategy != self.current_strategy:
            self.current_strategy = new_strategy
            self.logger.info(f"Switched to learning strategy: {new_strategy.value}")
    
    def get_strategy_info(self) -> Dict[str, Any]:
        """Get current strategy information"""
        return {
            'current_strategy': self.current_strategy.value,
            'parameters': self.strategy_params.__dict__,
            'adaptations_count': len(self.strategy_history)
        }
