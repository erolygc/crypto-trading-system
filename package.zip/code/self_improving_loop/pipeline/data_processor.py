"""
Real-time Data Processor Module
Processes incoming data for continuous learning
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from collections import deque
import pandas as pd
import numpy as np
import json
import os

@dataclass
class DataConfig:
    """Configuration for data processing"""
    buffer_size: int = 10000
    feature_window: int = 100
    update_frequency: float = 1.0  # seconds
    data_sources: List[str] = field(default_factory=list)
    feature_engineering: bool = True
    validation_enabled: bool = True

@dataclass
class ProcessedData:
    """Container for processed data"""
    raw_data: pd.DataFrame
    features: pd.DataFrame
    metadata: Dict[str, Any]
    timestamp: datetime
    quality_score: float

class RealTimeDataProcessor:
    """
    Real-time Data Processor for continuous learning
    Handles data ingestion, processing, and feature engineering
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Data configuration
        self.data_config = DataConfig()
        if 'learning' in config:
            self.data_config.buffer_size = config['learning'].get('buffer_size', 10000)
            self.data_config.feature_window = config['learning'].get('feature_window', 100)
        
        # Data buffers
        self.data_buffer = deque(maxlen=self.data_config.buffer_size)
        self.feature_buffer = deque(maxlen=self.data_config.buffer_size)
        self.metadata_buffer = deque(maxlen=self.data_config.buffer_size)
        
        # Data quality tracking
        self.data_quality_history = deque(maxlen=1000)
        self.processing_stats = {
            'total_processed': 0,
            'avg_quality_score': 0.0,
            'processing_latency': deque(maxlen=100),
            'error_count': 0,
            'last_update': None
        }
        
        # Feature engineering
        self.feature_engines = {}
        self.feature_cache = {}
        
        # Data source management
        self.active_sources = {}
        self.source_health = {}
        
    async def initialize(self) -> None:
        """Initialize data processor"""
        try:
            # Initialize feature engineering engines
            await self._initialize_feature_engines()
            
            # Initialize data sources
            await self._initialize_data_sources()
            
            # Start background processing
            asyncio.create_task(self._background_processing_loop())
            
            self.logger.info("Real-time Data Processor initialized")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize data processor: {e}")
            raise
    
    async def _initialize_feature_engines(self) -> None:
        """Initialize feature engineering engines"""
        try:
            # Technical indicators
            self.feature_engines['technical'] = TechnicalIndicatorEngine()
            
            # Statistical features
            self.feature_engines['statistical'] = StatisticalFeatureEngine()
            
            # Time-based features
            self.feature_engines['temporal'] = TemporalFeatureEngine()
            
            # Market microstructure features
            self.feature_engines['microstructure'] = MicrostructureFeatureEngine()
            
            self.logger.info("Feature engines initialized")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize feature engines: {e}")
            raise
    
    async def _initialize_data_sources(self) -> None:
        """Initialize data sources"""
        try:
            # Simulated data sources (in practice, these would be real data feeds)
            sources = ['market_data', 'news_data', 'social_sentiment', 'economic_indicators']
            
            for source in sources:
                self.active_sources[source] = DataSource(source, self.config)
                self.source_health[source] = {'status': 'active', 'last_heartbeat': datetime.now()}
            
            self.logger.info(f"Initialized {len(sources)} data sources")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize data sources: {e}")
            raise
    
    async def get_new_data(self, max_wait_time: float = 5.0) -> pd.DataFrame:
        """
        Get new data from sources
        Waits for new data or returns accumulated data
        """
        try:
            start_time = asyncio.get_event_loop().time()
            
            # Try to get fresh data
            new_data = await self._collect_new_data()
            
            if new_data.empty:
                # Wait briefly for new data
                await asyncio.sleep(min(1.0, max_wait_time))
                new_data = await self._collect_new_data()
            
            if not new_data.empty:
                # Process the data
                processed_data = await self._process_data_batch(new_data)
                
                # Update statistics
                processing_time = asyncio.get_event_loop().time() - start_time
                self.processing_stats['processing_latency'].append(processing_time)
                self.processing_stats['total_processed'] += len(processed_data)
                self.processing_stats['last_update'] = datetime.now()
            
            return new_data
            
        except Exception as e:
            self.logger.error(f"Failed to get new data: {e}")
            self.processing_stats['error_count'] += 1
            return pd.DataFrame()
    
    async def _collect_new_data(self) -> pd.DataFrame:
        """Collect new data from all sources"""
        try:
            all_data = []
            
            # Collect from each source
            for source_name, source in self.active_sources.items():
                try:
                    source_data = await source.get_data()
                    if not source_data.empty:
                        source_data['source'] = source_name
                        all_data.append(source_data)
                except Exception as e:
                    self.logger.error(f"Data collection failed for {source_name}: {e}")
                    self.source_health[source_name]['status'] = 'error'
            
            if all_data:
                # Combine all data sources
                combined_data = pd.concat(all_data, ignore_index=True)
                
                # Add timestamp
                combined_data['ingestion_time'] = datetime.now()
                
                # Quality check
                quality_score = self._calculate_data_quality(combined_data)
                
                # Store in buffer
                self.data_buffer.append(combined_data)
                self.metadata_buffer.append({
                    'timestamp': datetime.now(),
                    'quality_score': quality_score,
                    'sources_count': len(all_data)
                })
                
                # Update quality history
                self.data_quality_history.append(quality_score)
                
                return combined_data
            
            return pd.DataFrame()
            
        except Exception as e:
            self.logger.error(f"Data collection failed: {e}")
            return pd.DataFrame()
    
    async def _process_data_batch(self, data: pd.DataFrame) -> pd.DataFrame:
        """Process a batch of data"""
        try:
            # Data validation
            if self.data_config.validation_enabled:
                validated_data = await self._validate_data(data)
            else:
                validated_data = data
            
            # Feature engineering
            if self.data_config.feature_engineering:
                features = await self._engineer_features(validated_data)
                
                # Store features
                self.feature_buffer.append(features)
            else:
                features = validated_data
            
            # Update data quality metrics
            await self._update_data_quality_metrics(validated_data, features)
            
            return features
            
        except Exception as e:
            self.logger.error(f"Data processing failed: {e}")
            return data
    
    async def _validate_data(self, data: pd.DataFrame) -> pd.DataFrame:
        """Validate data quality and integrity"""
        try:
            validated_data = data.copy()
            
            # Remove completely empty rows
            validated_data = validated_data.dropna(how='all')
            
            # Remove rows with excessive missing values
            missing_threshold = 0.5
            validated_data = validated_data.dropna(thresh=int(len(data.columns) * missing_threshold))
            
            # Handle outliers (simple z-score method)
            numeric_columns = validated_data.select_dtypes(include=[np.number]).columns
            for col in numeric_columns:
                if col in validated_data.columns:
                    mean_val = validated_data[col].mean()
                    std_val = validated_data[col].std()
                    if std_val > 0:
                        z_scores = np.abs((validated_data[col] - mean_val) / std_val)
                        validated_data = validated_data[z_scores < 3]  # Remove 3-sigma outliers
            
            # Ensure minimum data size
            if len(validated_data) < 10:
                self.logger.warning("Data size too small after validation")
                return data  # Return original data
            
            self.logger.debug(f"Data validation: {len(data)} -> {len(validated_data)} rows")
            return validated_data
            
        except Exception as e:
            self.logger.error(f"Data validation failed: {e}")
            return data
    
    async def _engineer_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """Engineer features from raw data"""
        try:
            features = data.copy()
            
            # Apply each feature engine
            for engine_name, engine in self.feature_engines.items():
                try:
                    if hasattr(engine, 'extract_features'):
                        engine_features = await engine.extract_features(data)
                        if not engine_features.empty:
                            # Add prefix to avoid column conflicts
                            engine_features.columns = [
                                f"{engine_name}_{col}" for col in engine_features.columns
                            ]
                            features = pd.concat([features, engine_features], axis=1)
                except Exception as e:
                    self.logger.error(f"Feature engineering failed for {engine_name}: {e}")
            
            # Remove any duplicate columns
            features = features.loc[:, ~features.columns.duplicated()]
            
            return features
            
        except Exception as e:
            self.logger.error(f"Feature engineering failed: {e}")
            return data
    
    def _calculate_data_quality(self, data: pd.DataFrame) -> float:
        """Calculate data quality score"""
        try:
            if data.empty:
                return 0.0
            
            quality_score = 1.0
            
            # Completeness (inverse of missing data ratio)
            missing_ratio = data.isnull().sum().sum() / (len(data) * len(data.columns))
            completeness_score = 1.0 - missing_ratio
            quality_score *= completeness_score
            
            # Consistency (data type consistency)
            type_consistency = self._calculate_type_consistency(data)
            quality_score *= type_consistency
            
            # Freshness (data recency)
            freshness_score = self._calculate_data_freshness(data)
            quality_score *= freshness_score
            
            return max(0.0, min(1.0, quality_score))
            
        except Exception as e:
            self.logger.error(f"Quality calculation failed: {e}")
            return 0.0
    
    def _calculate_type_consistency(self, data: pd.DataFrame) -> float:
        """Calculate data type consistency score"""
        try:
            # Check if numeric columns contain mostly numeric values
            numeric_columns = data.select_dtypes(include=[np.number]).columns
            if len(numeric_columns) == 0:
                return 1.0
            
            consistency_scores = []
            for col in numeric_columns:
                total_values = len(data[col].dropna())
                if total_values > 0:
                    numeric_count = pd.to_numeric(data[col], errors='coerce').notna().sum()
                    consistency = numeric_count / total_values
                    consistency_scores.append(consistency)
            
            return np.mean(consistency_scores) if consistency_scores else 1.0
            
        except Exception as e:
            self.logger.error(f"Type consistency calculation failed: {e}")
            return 1.0
    
    def _calculate_data_freshness(self, data: pd.DataFrame) -> float:
        """Calculate data freshness score"""
        try:
            # Check if data contains timestamp columns
            time_columns = ['timestamp', 'ingestion_time', 'time', 'date']
            time_col = None
            
            for col in time_columns:
                if col in data.columns:
                    time_col = col
                    break
            
            if time_col is None:
                return 1.0  # Assume fresh if no timestamp
            
            # Check if timestamps are recent
            if data[time_col].dtype == 'datetime64[ns]':
                most_recent = data[time_col].max()
                if pd.isna(most_recent):
                    return 0.0
                
                time_diff = (datetime.now() - most_recent).total_seconds()
                # Score decreases with age (1.0 for fresh, 0.0 for >1 hour old)
                freshness = max(0.0, 1.0 - (time_diff / 3600))
                return freshness
            else:
                return 0.5  # Unknown timestamp format
            
        except Exception as e:
            self.logger.error(f"Data freshness calculation failed: {e}")
            return 0.5
    
    async def _update_data_quality_metrics(
        self, 
        raw_data: pd.DataFrame, 
        processed_data: pd.DataFrame
    ) -> None:
        """Update data quality metrics"""
        try:
            # Calculate processing quality
            quality_score = self._calculate_data_quality(processed_data)
            
            # Update running average
            history = list(self.data_quality_history)
            if history:
                avg_quality = (sum(history) + quality_score) / (len(history) + 1)
                self.processing_stats['avg_quality_score'] = avg_quality
            else:
                self.processing_stats['avg_quality_score'] = quality_score
            
            self.logger.debug(f"Updated data quality: {quality_score:.3f}")
            
        except Exception as e:
            self.logger.error(f"Quality metrics update failed: {e}")
    
    async def _background_processing_loop(self) -> None:
        """Background loop for ongoing data processing"""
        while True:
            try:
                # Check source health
                await self._check_source_health()
                
                # Clean up old data
                await self._cleanup_old_data()
                
                # Update statistics
                await self._update_processing_stats()
                
                await asyncio.sleep(self.data_config.update_frequency)
                
            except Exception as e:
                self.logger.error(f"Background processing error: {e}")
                await asyncio.sleep(5)
    
    async def _check_source_health(self) -> None:
        """Check health of data sources"""
        try:
            for source_name, source in self.active_sources.items():
                try:
                    health_status = await source.check_health()
                    self.source_health[source_name] = health_status
                except Exception as e:
                    self.logger.error(f"Health check failed for {source_name}: {e}")
                    self.source_health[source_name] = {'status': 'error'}
            
        except Exception as e:
            self.logger.error(f"Source health check failed: {e}")
    
    async def _cleanup_old_data(self) -> None:
        """Clean up old data to manage memory"""
        try:
            # Keep only recent data in buffers
            cutoff_time = datetime.now() - timedelta(hours=1)
            
            # Clean metadata buffer
            while self.metadata_buffer and self.metadata_buffer[0]['timestamp'] < cutoff_time:
                self.metadata_buffer.popleft()
            
            self.logger.debug("Data cleanup completed")
            
        except Exception as e:
            self.logger.error(f"Data cleanup failed: {e}")
    
    async def _update_processing_stats(self) -> None:
        """Update processing statistics"""
        try:
            if self.processing_stats['processing_latency']:
                avg_latency = np.mean(list(self.processing_stats['processing_latency']))
                self.processing_stats['avg_latency'] = avg_latency
            
        except Exception as e:
            self.logger.error(f"Stats update failed: {e}")
    
    def get_processing_stats(self) -> Dict[str, Any]:
        """Get current processing statistics"""
        return {
            'total_processed': self.processing_stats['total_processed'],
            'avg_quality_score': self.processing_stats['avg_quality_score'],
            'error_count': self.processing_stats['error_count'],
            'buffer_sizes': {
                'data_buffer': len(self.data_buffer),
                'feature_buffer': len(self.feature_buffer),
                'metadata_buffer': len(self.metadata_buffer)
            },
            'source_health': self.source_health,
            'active_sources': list(self.active_sources.keys())
        }
    
    async def get_state(self) -> Dict[str, Any]:
        """Get current data processor state"""
        return {
            'stats': self.get_processing_stats(),
            'config': {
                'buffer_size': self.data_config.buffer_size,
                'feature_window': self.data_config.feature_window,
                'feature_engineering': self.data_config.feature_engineering
            },
            'quality_history_length': len(self.data_quality_history)
        }


# Supporting classes for feature engineering

class TechnicalIndicatorEngine:
    """Technical indicator feature engineering"""
    
    async def extract_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """Extract technical indicators"""
        features = pd.DataFrame()
        
        # Simple moving averages
        for window in [5, 10, 20]:
            if 'close' in data.columns:
                sma = data['close'].rolling(window=window).mean()
                features[f'sma_{window}'] = sma
                features[f'price_to_sma_{window}'] = data['close'] / sma
        
        # Volatility
        if 'close' in data.columns:
            returns = data['close'].pct_change()
            features['volatility_20'] = returns.rolling(20).std()
            features['rsi'] = self._calculate_rsi(returns, 14)
        
        return features.dropna()
    
    def _calculate_rsi(self, returns: pd.Series, period: int) -> pd.Series:
        """Calculate RSI indicator"""
        gain = returns.where(returns > 0, 0).rolling(period).mean()
        loss = (-returns.where(returns < 0, 0)).rolling(period).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi


class StatisticalFeatureEngine:
    """Statistical feature engineering"""
    
    async def extract_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """Extract statistical features"""
        features = pd.DataFrame()
        
        # Rolling statistics for numeric columns
        numeric_columns = data.select_dtypes(include=[np.number]).columns
        
        for col in numeric_columns:
            if len(data) >= 10:
                features[f'{col}_rolling_mean'] = data[col].rolling(10).mean()
                features[f'{col}_rolling_std'] = data[col].rolling(10).std()
                features[f'{col}_rolling_skew'] = data[col].rolling(10).skew()
        
        return features.dropna()


class TemporalFeatureEngine:
    """Time-based feature engineering"""
    
    async def extract_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """Extract temporal features"""
        features = pd.DataFrame()
        
        # Time-based features if timestamp exists
        time_columns = ['timestamp', 'ingestion_time']
        
        for time_col in time_columns:
            if time_col in data.columns and data[time_col].dtype == 'datetime64[ns]':
                features[f'{time_col}_hour'] = data[time_col].dt.hour
                features[f'{time_col}_day_of_week'] = data[time_col].dt.dayofweek
                features[f'{time_col}_month'] = data[time_col].dt.month
        
        return features


class MicrostructureFeatureEngine:
    """Market microstructure feature engineering"""
    
    async def extract_features(self, data: pd.DataFrame) -> pd.DataFrame:
        """Extract microstructure features"""
        features = pd.DataFrame()
        
        # Price dynamics
        if all(col in data.columns for col in ['high', 'low', 'close', 'volume']):
            # Price spread
            features['price_spread'] = data['high'] - data['low']
            
            # Volume-weighted price
            features['vwap'] = (data['close'] * data['volume']).rolling(10).sum() / data['volume'].rolling(10).sum()
            
            # Price momentum
            features['momentum'] = data['close'].pct_change(5)
        
        return features.dropna()


class DataSource:
    """Data source wrapper"""
    
    def __init__(self, name: str, config: Dict[str, Any]):
        self.name = name
        self.config = config
        self.logger = logging.getLogger(f"DataSource.{name}")
    
    async def get_data(self) -> pd.DataFrame:
        """Get data from this source"""
        try:
            # Simulated data generation (replace with actual data source)
            data = self._generate_sample_data()
            return data
        except Exception as e:
            self.logger.error(f"Data retrieval failed: {e}")
            return pd.DataFrame()
    
    async def check_health(self) -> Dict[str, Any]:
        """Check source health"""
        return {
            'status': 'active',
            'last_heartbeat': datetime.now(),
            'response_time': 0.1
        }
    
    def _generate_sample_data(self) -> pd.DataFrame:
        """Generate sample data for demonstration"""
        import random
        random.seed(hash(self.name) % 1000)  # Deterministic per source
        
        n_rows = random.randint(50, 200)
        
        data = {
            'close': [random.uniform(100, 200) for _ in range(n_rows)],
            'volume': [random.randint(1000, 10000) for _ in range(n_rows)],
            'high': [random.uniform(105, 210) for _ in range(n_rows)],
            'low': [random.uniform(95, 190) for _ in range(n_rows)],
            'open': [random.uniform(100, 200) for _ in range(n_rows)],
            'timestamp': [datetime.now() - timedelta(minutes=i) for i in range(n_rows)]
        }
        
        return pd.DataFrame(data)
