"""
Continuous Learning Pipeline
Implements Phase 1: Real-time learning and adaptation system
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, field
import numpy as np
import pandas as pd
import pickle
import os
from collections import deque

from .learning_strategies import AdaptiveLearningStrategy
from .knowledge_manager import KnowledgeManager
from .data_processor import RealTimeDataProcessor

@dataclass
class LearningMetrics:
    """Metrics for continuous learning performance"""
    learning_rate: float = 0.001
    convergence_rate: float = 0.0
    knowledge_retention: float = 1.0
    adaptation_speed: float = 0.0
    model_accuracy: float = 0.0
    last_update: Optional[datetime] = None
    
    def update(self, **kwargs) -> None:
        """Update metrics with new values"""
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
        self.last_update = datetime.now()

@dataclass
class LearningContext:
    """Context information for learning process"""
    market_regime: str = "unknown"
    volatility_level: float = 0.0
    liquidity_state: str = "normal"
    correlation_structure: Dict[str, float] = field(default_factory=dict)
    feature_importance: Dict[str, float] = field(default_factory=dict)
    model_performance: Dict[str, float] = field(default_factory=dict)
    environmental_factors: Dict[str, Any] = field(default_factory=dict)

class ContinuousLearningPipeline:
    """
    Continuous Learning Pipeline for Phase 1
    Implements real-time learning, adaptation, and knowledge accumulation
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Initialize components
        self.learning_strategy = AdaptiveLearningStrategy(config)
        self.knowledge_manager = KnowledgeManager(config)
        self.data_processor = RealTimeDataProcessor(config)
        
        # Learning state
        self.metrics = LearningMetrics()
        self.context = LearningContext()
        self.learning_history = deque(maxlen=1000)
        self.model_versions = []
        self.active_models = {}
        
        # Performance tracking
        self.performance_window = deque(maxlen=100)
        self.adaptation_triggers = deque(maxlen=50)
        
        self.logger.info("Continuous Learning Pipeline initialized")
    
    async def initialize(self) -> None:
        """Initialize the learning pipeline"""
        try:
            await self.learning_strategy.initialize()
            await self.knowledge_manager.initialize()
            await self.data_processor.initialize()
            
            # Load existing knowledge
            await self._load_existing_knowledge()
            
            self.logger.info("Continuous Learning Pipeline initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize learning pipeline: {e}")
            raise
    
    async def run_cycle(self) -> Dict[str, Any]:
        """Execute one learning cycle"""
        try:
            self.logger.info("Starting continuous learning cycle")
            
            # Step 1: Process new data
            new_data = await self.data_processor.get_new_data()
            
            # Step 2: Update context
            await self._update_learning_context(new_data)
            
            # Step 3: Adapt learning strategy
            await self._adapt_learning_strategy()
            
            # Step 4: Train models
            training_results = await self._train_models(new_data)
            
            # Step 5: Validate performance
            validation_results = await self._validate_models(new_data)
            
            # Step 6: Update knowledge base
            knowledge_updates = await self._update_knowledge_base(
                training_results, validation_results
            )
            
            # Step 7: Generate adaptations
            adaptations = await self._generate_adaptations(
                training_results, validation_results
            )
            
            # Step 8: Monitor performance
            await self._monitor_learning_performance(training_results)
            
            cycle_results = {
                'status': 'completed',
                'data_points_processed': len(new_data),
                'context_updates': self.context.__dict__,
                'training_results': training_results,
                'validation_results': validation_results,
                'knowledge_updates': knowledge_updates,
                'adaptations': adaptations,
                'metrics': self.metrics.__dict__,
                'timestamp': datetime.now().isoformat()
            }
            
            self.learning_history.append(cycle_results)
            self.logger.info("Continuous learning cycle completed successfully")
            
            return cycle_results
            
        except Exception as e:
            self.logger.error(f"Continuous learning cycle failed: {e}")
            return {
                'status': 'failed',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    async def _update_learning_context(self, new_data: pd.DataFrame) -> None:
        """Update learning context based on new data"""
        try:
            # Detect market regime
            if len(new_data) > 0:
                # Calculate volatility
                if 'close' in new_data.columns:
                    returns = new_data['close'].pct_change().dropna()
                    self.context.volatility_level = returns.std() if len(returns) > 0 else 0.0
                
                # Update correlation structure
                self.context.correlation_structure = await self._calculate_correlations(
                    new_data
                )
                
                # Update feature importance
                self.context.feature_importance = await self._calculate_feature_importance(
                    new_data
                )
            
            self.logger.debug("Learning context updated")
            
        except Exception as e:
            self.logger.error(f"Failed to update learning context: {e}")
    
    async def _adapt_learning_strategy(self) -> None:
        """Adapt learning strategy based on current context"""
        try:
            # Adapt based on volatility
            if self.context.volatility_level > 0.3:
                # High volatility - increase learning rate
                self.metrics.learning_rate = min(
                    self.config['learning']['learning_rate'] * 1.5,
                    0.01
                )
            elif self.context.volatility_level < 0.1:
                # Low volatility - decrease learning rate
                self.metrics.learning_rate = max(
                    self.config['learning']['learning_rate'] * 0.5,
                    0.0001
                )
            
            # Adapt based on knowledge retention
            if self.metrics.knowledge_retention < 0.8:
                # Low retention - reduce learning rate
                self.metrics.learning_rate *= 0.9
            
            # Update learning strategy parameters
            await self.learning_strategy.adapt_parameters({
                'learning_rate': self.metrics.learning_rate,
                'context': self.context,
                'performance_history': list(self.performance_window)
            })
            
            self.logger.debug("Learning strategy adapted")
            
        except Exception as e:
            self.logger.error(f"Failed to adapt learning strategy: {e}")
    
    async def _train_models(self, new_data: pd.DataFrame) -> Dict[str, Any]:
        """Train models on new data"""
        try:
            training_results = {}
            
            # Get training parameters
            training_params = await self.learning_strategy.get_training_parameters()
            
            # Train different model types
            model_types = ['neural_network', 'random_forest', 'gradient_boosting']
            
            for model_type in model_types:
                try:
                    # Train model
                    model_result = await self._train_single_model(
                        model_type, new_data, training_params
                    )
                    training_results[model_type] = model_result
                    
                    # Store model if performance is good
                    if model_result.get('accuracy', 0) > 0.6:
                        self.active_models[model_type] = model_result['model']
                        self.model_versions.append({
                            'model_type': model_type,
                            'version': len(self.model_versions),
                            'accuracy': model_result['accuracy'],
                            'timestamp': datetime.now()
                        })
                
                except Exception as e:
                    self.logger.error(f"Failed to train {model_type}: {e}")
                    training_results[model_type] = {'error': str(e)}
            
            # Update metrics
            best_accuracy = max([
                r.get('accuracy', 0) for r in training_results.values()
                if isinstance(r, dict) and 'accuracy' in r
            ] or [0])
            
            self.metrics.model_accuracy = best_accuracy
            self.metrics.convergence_rate = self._calculate_convergence_rate(
                training_results
            )
            
            return training_results
            
        except Exception as e:
            self.logger.error(f"Model training failed: {e}")
            return {'error': str(e)}
    
    async def _train_single_model(
        self, 
        model_type: str, 
        data: pd.DataFrame, 
        params: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Train a single model"""
        try:
            # Simulate model training (replace with actual ML implementation)
            import random
            random.seed(42)  # For reproducible results
            
            # Simple simulation of model training
            accuracy = random.uniform(0.5, 0.95)
            training_time = random.uniform(1, 10)
            model_size = random.randint(1000, 10000)
            
            return {
                'model_type': model_type,
                'accuracy': accuracy,
                'training_time': training_time,
                'model_size': model_size,
                'parameters': params,
                'timestamp': datetime.now().isoformat(),
                'status': 'trained'
            }
            
        except Exception as e:
            self.logger.error(f"Single model training failed: {e}")
            return {'error': str(e)}
    
    async def _validate_models(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Validate model performance"""
        try:
            validation_results = {}
            
            for model_type, model in self.active_models.items():
                try:
                    # Simulate validation (replace with actual validation)
                    validation_score = self._simulate_validation(model_type, model)
                    
                    validation_results[model_type] = {
                        'validation_score': validation_score,
                        'model_type': model_type,
                        'timestamp': datetime.now().isoformat()
                    }
                    
                except Exception as e:
                    self.logger.error(f"Validation failed for {model_type}: {e}")
                    validation_results[model_type] = {'error': str(e)}
            
            return validation_results
            
        except Exception as e:
            self.logger.error(f"Model validation failed: {e}")
            return {'error': str(e)}
    
    def _simulate_validation(self, model_type: str, model: Any) -> float:
        """Simulate model validation (replace with actual validation)"""
        import random
        random.seed(43)  # Different seed for validation
        
        # Simulate validation score based on model type
        base_scores = {
            'neural_network': 0.85,
            'random_forest': 0.80,
            'gradient_boosting': 0.82
        }
        
        base_score = base_scores.get(model_type, 0.75)
        score_variation = random.uniform(-0.1, 0.1)
        
        return max(0.0, min(1.0, base_score + score_variation))
    
    async def _update_knowledge_base(
        self, 
        training_results: Dict[str, Any], 
        validation_results: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Update knowledge base with new insights"""
        try:
            knowledge_updates = {}
            
            # Extract insights from training
            for model_type, result in training_results.items():
                if isinstance(result, dict) and 'accuracy' in result:
                    insight = {
                        'model_type': model_type,
                        'accuracy': result['accuracy'],
                        'context': self.context.__dict__,
                        'timestamp': datetime.now()
                    }
                    
                    await self.knowledge_manager.add_insight(insight)
                    knowledge_updates[model_type] = insight
            
            # Update performance history
            best_model = max(
                validation_results.items(),
                key=lambda x: x[1].get('validation_score', 0) if isinstance(x[1], dict) else 0,
                default=(None, {})
            )
            
            if best_model[0]:
                self.performance_window.append({
                    'best_model': best_model[0],
                    'performance': best_model[1].get('validation_score', 0),
                    'timestamp': datetime.now()
                })
            
            return knowledge_updates
            
        except Exception as e:
            self.logger.error(f"Knowledge base update failed: {e}")
            return {'error': str(e)}
    
    async def _generate_adaptations(
        self, 
        training_results: Dict[str, Any], 
        validation_results: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Generate system adaptations based on learning results"""
        try:
            adaptations = []
            
            # Check if model performance has degraded
            current_performance = self.metrics.model_accuracy
            historical_avg = np.mean([
                p['performance'] for p in list(self.performance_window)[-10:]
            ]) if self.performance_window else current_performance
            
            if current_performance < historical_avg * 0.9:
                adaptations.append({
                    'type': 'model_replacement',
                    'reason': 'performance_degradation',
                    'current_accuracy': current_performance,
                    'expected_accuracy': historical_avg,
                    'timestamp': datetime.now()
                })
            
            # Check if new model significantly outperforms
            best_validation_score = max([
                r.get('validation_score', 0) for r in validation_results.values()
                if isinstance(r, dict) and 'validation_score' in r
            ] or [0])
            
            if best_validation_score > current_performance * 1.05:
                adaptations.append({
                    'type': 'model_upgrade',
                    'reason': 'significant_improvement',
                    'new_accuracy': best_validation_score,
                    'old_accuracy': current_performance,
                    'timestamp': datetime.now()
                })
            
            # Adaptation speed optimization
            if len(self.adaptation_triggers) > 0:
                recent_adaptations = list(self.adaptation_triggers)[-5:]
                adaptation_frequency = len(recent_adaptations) / 300  # 5 minutes
                
                if adaptation_frequency > 0.1:  # Too frequent
                    adaptations.append({
                        'type': 'adaptation_frequency_reduction',
                        'current_frequency': adaptation_frequency,
                        'target_frequency': 0.05,
                        'timestamp': datetime.now()
                    })
            
            return adaptations
            
        except Exception as e:
            self.logger.error(f"Adaptation generation failed: {e}")
            return []
    
    async def _monitor_learning_performance(self, training_results: Dict[str, Any]) -> None:
        """Monitor learning performance and update metrics"""
        try:
            # Calculate adaptation speed
            if len(self.adaptation_triggers) > 1:
                times = [t['timestamp'] for t in list(self.adaptation_triggers)[-5:]]
                if len(times) > 1:
                    time_diffs = [
                        (times[i] - times[i-1]).total_seconds() 
                        for i in range(1, len(times))
                    ]
                    self.metrics.adaptation_speed = 1.0 / (np.mean(time_diffs) / 60)  # adaptations per minute
            
            # Update knowledge retention
            self.metrics.knowledge_retention = self._calculate_knowledge_retention()
            
            self.logger.debug("Learning performance monitored")
            
        except Exception as e:
            self.logger.error(f"Learning performance monitoring failed: {e}")
    
    def _calculate_convergence_rate(self, training_results: Dict[str, Any]) -> float:
        """Calculate model convergence rate"""
        try:
            # Simple convergence rate calculation
            accuracies = [
                r.get('accuracy', 0) for r in training_results.values()
                if isinstance(r, dict) and 'accuracy' in r
            ]
            
            if len(accuracies) < 2:
                return 0.0
            
            # Calculate improvement rate
            sorted_accuracies = sorted(accuracies, reverse=True)
            improvement = sorted_accuracies[0] - sorted_accuracies[-1]
            
            return min(1.0, improvement)
            
        except Exception as e:
            self.logger.error(f"Convergence rate calculation failed: {e}")
            return 0.0
    
    def _calculate_knowledge_retention(self) -> float:
        """Calculate knowledge retention rate"""
        try:
            if len(self.performance_window) < 5:
                return 1.0
            
            recent_performances = [
                p['performance'] for p in list(self.performance_window)[-10:]
            ]
            
            # Calculate retention as consistency of performance
            performance_std = np.std(recent_performances)
            retention = max(0.0, 1.0 - performance_std)
            
            return retention
            
        except Exception as e:
            self.logger.error(f"Knowledge retention calculation failed: {e}")
            return 1.0
    
    async def _calculate_correlations(self, data: pd.DataFrame) -> Dict[str, float]:
        """Calculate feature correlations"""
        try:
            if data.empty or len(data.columns) < 2:
                return {}
            
            # Calculate correlation matrix
            corr_matrix = data.corr()
            
            # Extract significant correlations
            correlations = {}
            for i in range(len(corr_matrix.columns)):
                for j in range(i+1, len(corr_matrix.columns)):
                    corr_value = corr_matrix.iloc[i, j]
                    if abs(corr_value) > 0.3:  # Threshold for significant correlation
                        feature1 = corr_matrix.columns[i]
                        feature2 = corr_matrix.columns[j]
                        correlations[f"{feature1}_{feature2}"] = float(corr_value)
            
            return correlations
            
        except Exception as e:
            self.logger.error(f"Correlation calculation failed: {e}")
            return {}
    
    async def _calculate_feature_importance(self, data: pd.DataFrame) -> Dict[str, float]:
        """Calculate feature importance scores"""
        try:
            if data.empty:
                return {}
            
            # Simple feature importance calculation
            # In practice, this would use actual feature importance from models
            import random
            random.seed(42)
            
            feature_importance = {}
            for column in data.columns:
                # Simulate feature importance
                importance = random.uniform(0.1, 1.0)
                feature_importance[column] = importance
            
            # Normalize
            total_importance = sum(feature_importance.values())
            if total_importance > 0:
                feature_importance = {
                    k: v/total_importance 
                    for k, v in feature_importance.items()
                }
            
            return feature_importance
            
        except Exception as e:
            self.logger.error(f"Feature importance calculation failed: {e}")
            return {}
    
    async def _load_existing_knowledge(self) -> None:
        """Load existing knowledge from storage"""
        try:
            # Load knowledge from knowledge manager
            insights = await self.knowledge_manager.get_insights()
            
            if insights:
                self.logger.info(f"Loaded {len(insights)} existing insights")
            
        except Exception as e:
            self.logger.error(f"Failed to load existing knowledge: {e}")
    
    async def get_state(self) -> Dict[str, Any]:
        """Get current pipeline state"""
        return {
            'metrics': self.metrics.__dict__,
            'context': self.context.__dict__,
            'active_models': list(self.active_models.keys()),
            'model_versions_count': len(self.model_versions),
            'performance_history_length': len(self.performance_window),
            'learning_cycles_completed': len(self.learning_history)
        }
    
    def add_adaptation_trigger(self, adaptation: Dict[str, Any]) -> None:
        """Add adaptation trigger to history"""
        adaptation['timestamp'] = datetime.now()
        self.adaptation_triggers.append(adaptation)
    
    async def save_knowledge(self, filepath: str) -> None:
        """Save knowledge base to file"""
        try:
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            
            knowledge_data = {
                'insights': await self.knowledge_manager.get_insights(),
                'performance_history': list(self.performance_window),
                'model_versions': self.model_versions,
                'metrics': self.metrics.__dict__,
                'context': self.context.__dict__,
                'timestamp': datetime.now().isoformat()
            }
            
            with open(filepath, 'wb') as f:
                pickle.dump(knowledge_data, f)
            
            self.logger.info(f"Knowledge saved to {filepath}")
            
        except Exception as e:
            self.logger.error(f"Failed to save knowledge: {e}")
