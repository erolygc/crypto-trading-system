"""
Knowledge Manager Module
Manages accumulated knowledge and insights from learning
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from collections import defaultdict, deque
import json
import pickle
import os

@dataclass
class KnowledgeItem:
    """Individual knowledge item"""
    id: str
    type: str  # 'pattern', 'insight', 'model', 'rule'
    content: Dict[str, Any]
    confidence: float
    timestamp: datetime
    context: Dict[str, Any] = field(default_factory=dict)
    usage_count: int = 0
    last_used: Optional[datetime] = None
    expiry_date: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'id': self.id,
            'type': self.type,
            'content': self.content,
            'confidence': self.confidence,
            'timestamp': self.timestamp.isoformat(),
            'context': self.context,
            'usage_count': self.usage_count,
            'last_used': self.last_used.isoformat() if self.last_used else None,
            'expiry_date': self.expiry_date.isoformat() if self.expiry_date else None
        }

class KnowledgeManager:
    """
    Knowledge Manager for storing and retrieving learning insights
    Implements knowledge retention, retrieval, and decay mechanisms
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Knowledge storage
        self.knowledge_base: Dict[str, KnowledgeItem] = {}
        self.insights_by_type: Dict[str, List[str]] = defaultdict(list)
        self.recent_insights = deque(maxlen=100)
        
        # Knowledge retrieval optimization
        self.retrieval_cache: Dict[str, List[KnowledgeItem]] = {}
        self.cache_ttl = 300  # 5 minutes
        
        # Knowledge metrics
        self.knowledge_metrics = {
            'total_items': 0,
            'by_type': defaultdict(int),
            'average_confidence': 0.0,
            'utilization_rate': 0.0,
            'knowledge_growth_rate': 0.0
        }
        
        # Knowledge expiry settings
        self.expiry_policies = {
            'pattern': timedelta(days=30),
            'insight': timedelta(days=7),
            'model': timedelta(days=90),
            'rule': timedelta(days=14)
        }
    
    async def initialize(self) -> None:
        """Initialize knowledge manager"""
        try:
            # Load existing knowledge if available
            await self._load_knowledge_base()
            
            # Start background knowledge maintenance
            asyncio.create_task(self._knowledge_maintenance_loop())
            
            self.logger.info("Knowledge Manager initialized")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize knowledge manager: {e}")
            raise
    
    async def add_insight(self, insight: Dict[str, Any]) -> str:
        """Add a new insight to the knowledge base"""
        try:
            insight_id = f"insight_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
            
            # Create knowledge item
            knowledge_item = KnowledgeItem(
                id=insight_id,
                type='insight',
                content=insight,
                confidence=insight.get('confidence', 0.5),
                timestamp=datetime.now(),
                context=insight.get('context', {}),
                expiry_date=datetime.now() + self.expiry_policies['insight']
            )
            
            # Add to knowledge base
            self.knowledge_base[insight_id] = knowledge_item
            self.insights_by_type['insight'].append(insight_id)
            self.recent_insights.append(knowledge_item)
            
            # Update metrics
            await self._update_knowledge_metrics()
            
            # Clear cache
            self.retrieval_cache.clear()
            
            self.logger.info(f"Added insight: {insight_id}")
            return insight_id
            
        except Exception as e:
            self.logger.error(f"Failed to add insight: {e}")
            raise
    
    async def add_pattern(self, pattern: Dict[str, Any]) -> str:
        """Add a new pattern to the knowledge base"""
        try:
            pattern_id = f"pattern_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
            
            knowledge_item = KnowledgeItem(
                id=pattern_id,
                type='pattern',
                content=pattern,
                confidence=pattern.get('confidence', 0.7),
                timestamp=datetime.now(),
                context=pattern.get('context', {}),
                expiry_date=datetime.now() + self.expiry_policies['pattern']
            )
            
            self.knowledge_base[pattern_id] = knowledge_item
            self.insights_by_type['pattern'].append(pattern_id)
            
            await self._update_knowledge_metrics()
            self.retrieval_cache.clear()
            
            self.logger.info(f"Added pattern: {pattern_id}")
            return pattern_id
            
        except Exception as e:
            self.logger.error(f"Failed to add pattern: {e}")
            raise
    
    async def add_rule(self, rule: Dict[str, Any]) -> str:
        """Add a new rule to the knowledge base"""
        try:
            rule_id = f"rule_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
            
            knowledge_item = KnowledgeItem(
                id=rule_id,
                type='rule',
                content=rule,
                confidence=rule.get('confidence', 0.8),
                timestamp=datetime.now(),
                context=rule.get('context', {}),
                expiry_date=datetime.now() + self.expiry_policies['rule']
            )
            
            self.knowledge_base[rule_id] = knowledge_item
            self.insights_by_type['rule'].append(rule_id)
            
            await self._update_knowledge_metrics()
            self.retrieval_cache.clear()
            
            self.logger.info(f"Added rule: {rule_id}")
            return rule_id
            
        except Exception as e:
            self.logger.error(f"Failed to add rule: {e}")
            raise
    
    async def get_insights(
        self, 
        insight_type: Optional[str] = None,
        min_confidence: float = 0.0,
        context_filter: Optional[Dict[str, Any]] = None
    ) -> List[KnowledgeItem]:
        """Retrieve insights based on criteria"""
        try:
            # Check cache first
            cache_key = f"{insight_type}_{min_confidence}_{hash(str(context_filter))}"
            if cache_key in self.retrieval_cache:
                return self.retrieval_cache[cache_key]
            
            # Filter insights
            filtered_items = []
            
            items_to_check = []
            if insight_type:
                items_to_check = [
                    self.knowledge_base[k] for k in self.insights_by_type.get(insight_type, [])
                ]
            else:
                items_to_check = list(self.knowledge_base.values())
            
            for item in items_to_check:
                # Check expiry
                if item.expiry_date and item.expiry_date < datetime.now():
                    continue
                
                # Check confidence
                if item.confidence < min_confidence:
                    continue
                
                # Check context filter
                if context_filter:
                    if not self._matches_context(item.context, context_filter):
                        continue
                
                filtered_items.append(item)
            
            # Sort by confidence and recency
            filtered_items.sort(
                key=lambda x: (x.confidence, x.timestamp),
                reverse=True
            )
            
            # Cache results
            self.retrieval_cache[cache_key] = filtered_items
            
            # Update usage statistics
            for item in filtered_items:
                item.usage_count += 1
                item.last_used = datetime.now()
            
            self.logger.debug(f"Retrieved {len(filtered_items)} insights")
            return filtered_items
            
        except Exception as e:
            self.logger.error(f"Failed to get insights: {e}")
            return []
    
    async def get_patterns(
        self, 
        min_confidence: float = 0.0,
        pattern_type: Optional[str] = None
    ) -> List[KnowledgeItem]:
        """Retrieve patterns from knowledge base"""
        try:
            patterns = await self.get_insights('pattern', min_confidence)
            
            if pattern_type:
                patterns = [
                    p for p in patterns 
                    if p.content.get('pattern_type') == pattern_type
                ]
            
            return patterns
            
        except Exception as e:
            self.logger.error(f"Failed to get patterns: {e}")
            return []
    
    async def get_relevant_knowledge(
        self, 
        context: Dict[str, Any],
        min_confidence: float = 0.5
    ) -> List[KnowledgeItem]:
        """Get knowledge relevant to specific context"""
        try:
            # Get insights from recent timeframe
            recent_cutoff = datetime.now() - timedelta(days=7)
            recent_items = [
                item for item in self.knowledge_base.values()
                if item.timestamp >= recent_cutoff
            ]
            
            # Score relevance
            scored_items = []
            for item in recent_items:
                relevance_score = self._calculate_relevance_score(item, context)
                if relevance_score > 0.5:
                    scored_items.append((item, relevance_score))
            
            # Sort by relevance
            scored_items.sort(key=lambda x: x[1], reverse=True)
            
            # Filter by confidence
            relevant_items = [
                item for item, score in scored_items 
                if item.confidence >= min_confidence
            ]
            
            return relevant_items[:10]  # Return top 10 most relevant
            
        except Exception as e:
            self.logger.error(f"Failed to get relevant knowledge: {e}")
            return []
    
    def _matches_context(self, item_context: Dict[str, Any], filter_context: Dict[str, Any]) -> bool:
        """Check if item context matches filter criteria"""
        for key, value in filter_context.items():
            if key not in item_context:
                return False
            if isinstance(value, (list, tuple)):
                if item_context[key] not in value:
                    return False
            elif item_context[key] != value:
                return False
        return True
    
    def _calculate_relevance_score(self, item: KnowledgeItem, context: Dict[str, Any]) -> float:
        """Calculate relevance score between item and context"""
        try:
            score = 0.0
            
            # Context similarity
            if 'market_regime' in context and 'market_regime' in item.context:
                if context['market_regime'] == item.context['market_regime']:
                    score += 0.3
            
            if 'volatility_level' in context and 'volatility_level' in item.context:
                vol_diff = abs(context['volatility_level'] - item.context['volatility_level'])
                score += max(0, 0.3 - vol_diff)
            
            # Time proximity
            time_diff = (datetime.now() - item.timestamp).total_seconds()
            if time_diff < 3600:  # Within 1 hour
                score += 0.2
            elif time_diff < 86400:  # Within 1 day
                score += 0.1
            
            # Confidence weight
            score += item.confidence * 0.2
            
            return min(1.0, score)
            
        except Exception as e:
            self.logger.error(f"Relevance score calculation failed: {e}")
            return 0.0
    
    async def _knowledge_maintenance_loop(self) -> None:
        """Background loop for knowledge maintenance"""
        while True:
            try:
                await asyncio.sleep(3600)  # Run every hour
                
                # Remove expired knowledge
                await self._remove_expired_knowledge()
                
                # Update metrics
                await self._update_knowledge_metrics()
                
                # Clean cache
                await self._clean_cache()
                
                self.logger.debug("Knowledge maintenance completed")
                
            except Exception as e:
                self.logger.error(f"Knowledge maintenance error: {e}")
                await asyncio.sleep(60)  # Wait before retry
    
    async def _remove_expired_knowledge(self) -> None:
        """Remove expired knowledge items"""
        try:
            now = datetime.now()
            expired_items = []
            
            for item_id, item in self.knowledge_base.items():
                if item.expiry_date and item.expiry_date < now:
                    expired_items.append(item_id)
            
            for item_id in expired_items:
                item = self.knowledge_base[item_id]
                self.insights_by_type[item.type].remove(item_id)
                del self.knowledge_base[item_id]
            
            if expired_items:
                self.logger.info(f"Removed {len(expired_items)} expired knowledge items")
            
        except Exception as e:
            self.logger.error(f"Failed to remove expired knowledge: {e}")
    
    async def _update_knowledge_metrics(self) -> None:
        """Update knowledge base metrics"""
        try:
            self.knowledge_metrics['total_items'] = len(self.knowledge_base)
            
            # Count by type
            self.knowledge_metrics['by_type'] = defaultdict(int)
            for item in self.knowledge_base.values():
                self.knowledge_metrics['by_type'][item.type] += 1
            
            # Average confidence
            if self.knowledge_base:
                confidences = [item.confidence for item in self.knowledge_base.values()]
                self.knowledge_metrics['average_confidence'] = sum(confidences) / len(confidences)
            
            # Utilization rate
            total_usage = sum(item.usage_count for item in self.knowledge_base.values())
            max_possible_usage = len(self.knowledge_base) * 100  # Assume max 100 uses per item
            self.knowledge_metrics['utilization_rate'] = (
                total_usage / max_possible_usage if max_possible_usage > 0 else 0
            )
            
        except Exception as e:
            self.logger.error(f"Failed to update knowledge metrics: {e}")
    
    async def _clean_cache(self) -> None:
        """Clean expired cache entries"""
        try:
            # Implementation for cache cleaning would go here
            # For now, simple implementation
            if len(self.retrieval_cache) > 100:
                self.retrieval_cache.clear()
            
        except Exception as e:
            self.logger.error(f"Cache cleaning failed: {e}")
    
    async def _load_knowledge_base(self) -> None:
        """Load knowledge base from storage"""
        try:
            # This would load from actual storage
            # For now, just log
            self.logger.info("No existing knowledge base found, starting fresh")
            
        except Exception as e:
            self.logger.error(f"Failed to load knowledge base: {e}")
    
    async def save_knowledge_base(self, filepath: str) -> None:
        """Save knowledge base to file"""
        try:
            os.makedirs(os.path.dirname(filepath), exist_ok=True)
            
            knowledge_data = {
                'knowledge_items': {
                    item_id: item.to_dict() 
                    for item_id, item in self.knowledge_base.items()
                },
                'insights_by_type': dict(self.insights_by_type),
                'metrics': self.knowledge_metrics,
                'timestamp': datetime.now().isoformat()
            }
            
            with open(filepath, 'w') as f:
                json.dump(knowledge_data, f, indent=2, default=str)
            
            self.logger.info(f"Knowledge base saved to {filepath}")
            
        except Exception as e:
            self.logger.error(f"Failed to save knowledge base: {e}")
    
    def get_knowledge_stats(self) -> Dict[str, Any]:
        """Get knowledge base statistics"""
        return {
            'total_items': len(self.knowledge_base),
            'by_type': dict(self.knowledge_metrics['by_type']),
            'average_confidence': self.knowledge_metrics['average_confidence'],
            'utilization_rate': self.knowledge_metrics['utilization_rate'],
            'recent_insights': len(self.recent_insights),
            'cache_size': len(self.retrieval_cache)
        }
    
    async def get_state(self) -> Dict[str, Any]:
        """Get current knowledge manager state"""
        return {
            'stats': self.get_knowledge_stats(),
            'metrics': self.knowledge_metrics,
            'expiry_policies': {
                k: v.total_seconds() for k, v in self.expiry_policies.items()
            }
        }
