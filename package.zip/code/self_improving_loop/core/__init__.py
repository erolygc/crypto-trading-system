"""
Bitwisers 2.0 Self-Improving Feedback Loop System
Comprehensive continuous improvement system for autonomous trading system evolution
"""

__version__ = "2.0.0"
__author__ = "Bitwisers Team"

from .orchestrator import SelfImprovingOrchestrator
from .coordinator import PhaseCoordinator
from .feedback_loop import FeedbackLoopManager

__all__ = [
    'SelfImprovingOrchestrator',
    'PhaseCoordinator',
    'FeedbackLoopManager'
]
