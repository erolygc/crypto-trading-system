# Self-Improving Feedback Loop

Bitwisers 2.0 için kapsamlı Self-Improving Feedback Loop sistemi.

## 🚀 Özellikler

- ✅ **Continuous Learning Pipeline**: Sürekli veri akışı ile model güncelleme
- ✅ **Automated System Adaptation**: Otomatik sistem adaptasyonu ve değişim tespiti  
- ✅ **Performance-Driven Optimization**: Performans odaklı çok amaçlı optimizasyon
- ✅ **Real-time System Monitoring**: Real-time sistem izleme ve performans takibi
- ✅ **API Interface**: REST API + WebSocket real-time iletişim
- ✅ **Integration**: Mevcut Bitwisers bileşenleriyle entegrasyon
- ✅ **Docker Support**: Container tabanlı deployment

## 📦 Kurulum

```bash
# Bağımlılıkları kur
pip install -r requirements.txt

# Sistemi başlat
python main.py standalone

# API server
python main.py api

# Demo çalıştır
python main.py demo
```

## 🏗️ Proje Yapısı

```
code/self_improving_loop/
├── core/               # Ana orchestrator
├── pipeline/           # Continuous learning
├── adaptation/         # Otomatik adaptasyon
├── optimization/       # Performans optimizasyonu
├── monitoring/         # Sistem izleme
├── integration/        # Entegrasyon & API
├── utils/             # Konfigürasyon & utilities
├── tests/             # Test dosyaları
├── demo.py            # Demo senaryoları
├── main.py            # Ana giriş noktası
└── requirements.txt   # Bağımlılıklar
```

## 📊 API Endpoints

- `GET /` - API durumu
- `GET /health` - Sistem sağlığı
- `GET /metrics` - Performans metrikleri
- `POST /optimize` - Optimizasyon başlat
- `POST /learn` - Öğrenme başlat
- `GET /status` - Detaylı sistem durumu
- `WebSocket /ws` - Real-time events

## 🐳 Docker

```bash
# Tüm servisleri başlat
docker-compose up -d

# Sadece ana sistem
docker-compose up self-improving-loop
```

## 📚 Dokümantasyon

Detaylı dokümantasyon: [docs/self_improving_feedback_loop.md](../../docs/self_improving_feedback_loop.md)

## 🧪 Test

```bash
# Tüm testleri çalıştır
python main.py test

# Belirli test
python -m pytest tests/test_integration.py -v
```

## 💡 Hızlı Başlangıç

```python
from self_improving_loop import SelfImprovingLoopApplication

# Uygulama oluştur
app = SelfImprovingLoopApplication()

# Sistemi başlat
await app.initialize_system()

# Demo çalıştır
from demo import SelfImprovingLoopDemo
demo = SelfImprovingLoopDemo()
await demo.run_full_demo()
```

## 📈 İstatistikler

- **Toplam Dosya**: 20+ Python dosyası
- **Toplam Kod**: 15,000+ satır
- **Test Coverage**: Kapsamlı test suite
- **Dokümantasyon**: 1,200+ satır

## 🎯 Sistem Bileşenleri

1. **Core Orchestrator** - Ana koordinatör (473 satır)
2. **Continuous Learner** - Sürekli öğrenme (601 satır)
3. **Knowledge Manager** - Bilgi yönetimi (473 satır)
4. **Data Processor** - Veri işleme (621 satır)
5. **Automated Adapter** - Otomatik adaptasyon (915 satır)
6. **Change Detector** - Değişim tespiti (489 satır)
7. **Performance Optimizer** - Performans optimizasyonu (1,360 satır)
8. **Parameter Tuner** - Hiperparametre ayarı (1,462 satır)
9. **System Monitor** - Sistem izleme (989 satır)
10. **API Interface** - REST API + WebSocket (682 satır)

## 🔧 Konfigürasyon

```yaml
# config/system.yaml
system:
  debug_mode: false
  max_workers: 4
  memory_limit_mb: 1024

pipeline:
  continuous_learning:
    enabled: true
    learning_interval_minutes: 30

optimization:
  performance_optimizer:
    enabled: true
    objectives: ["accuracy", "speed", "memory"]
```

## 🚦 Çalışma Modları

- `standalone` - Bağımsız sistem
- `api` - API server modu
- `demo` - Demo senaryoları
- `test` - Test çalıştırma
- `status` - Sistem durumu

## 📝 Lisans

MIT License

---

**Bitwisers 2.0 Self-Improving Feedback Loop System**  
*Geliştirilme Tarihi: 2024-01-01*  
*Versiyon: 1.0.0*
