"""
Self-Improving Feedback Loop

Bitwisers 2.0 için kapsamlı Self-Improving Feedback Loop sistemi.

Bu sistem, sürekli öğrenme, otomatik adaptasyon, performans odaklı optimizasyon,
feedback-driven parametre ayarı, real-time sistem kalibrasyonu, tahminli sistem iyileştirme,
çok amaçlı optimizasyon, dinamik mimari adaptasyonu, çapraz-sistem öğrenme ve otonom
sistem evrimi özelliklerini sağlar.

Ana Bileşenler:
- Core Orchestrator: Tüm sistem bileşenlerini koordine eder
- Pipeline: Continuous learning ve veri işleme
- Adaptation: Otomatik sistem adaptasyonu
- Optimization: Performans optimizasyonu ve hiperparametre ayarı
- Monitoring: Real-time sistem izleme
- Integration: Mevcut Bitwisers bileşenleriyle entegrasyon
- Utils: Konfigürasyon, logging ve yardımcı fonksiyonlar

Kullanım:
    from self_improving_loop import SelfImprovingOrchestrator
    
    # Ana sistemi başlat
    orchestrator = SelfImprovingOrchestrator(config)
    await orchestrator.initialize()
    
    # Optimizasyon döngüsü başlat
    await orchestrator.start_optimization_cycle()
    
    # API server başlat
    await start_api_server(orchestrator)

Dokümantasyon: docs/self_improving_feedback_loop.md
Demo: demo.py
Testler: tests/
"""

# Version bilgisi
__version__ = "1.0.0"
__author__ = "Bitwisers Development Team"
__email__ = "dev@bitwisers.com"
__description__ = "Self-Improving Feedback Loop System for Bitwisers 2.0"

# Core imports
from .core.orchestrator import SelfImprovingOrchestrator

# Component imports
from .pipeline.continuous_learner import ContinuousLearner
from .adaptation.automated_adapter import AutomatedSystemAdapter
from .optimization.performance_optimizer import PerformanceOptimizer
from .monitoring.system_monitor import SystemMonitor

# Integration imports
from .integration.system_integrator import BitwisersSystemIntegrator
from .integration.api_interface import (
    SelfImprovingAPIInterface,
    create_api_interface,
    start_api_server
)

# Utils imports
from .utils.config_manager import get_config_manager, get_config, update_config
from .utils.logger import get_logger, get_performance_logger, log_system_event
from .utils.helpers import (
    DataValidator, DataProcessor, MathUtils, FileUtils, TimeUtils,
    AsyncUtils, PerformanceMonitor, Timer, timer_context, Serializer,
    Cache, Registry, get_cache, get_registry, get_performance_monitor
)

# Main application
from .main import SelfImprovingLoopApplication

# Demo
from .demo import SelfImprovingLoopDemo

# Package-level exports
__all__ = [
    # Version info
    '__version__',
    '__author__',
    '__email__',
    '__description__',
    
    # Core
    'SelfImprovingOrchestrator',
    
    # Components
    'ContinuousLearner',
    'AutomatedSystemAdapter',
    'PerformanceOptimizer',
    'SystemMonitor',
    
    # Integration
    'BitwisersSystemIntegrator',
    'SelfImprovingAPIInterface',
    'create_api_interface',
    'start_api_server',
    
    # Utils
    'get_config_manager',
    'get_config',
    'update_config',
    'get_logger',
    'get_performance_logger',
    'log_system_event',
    'DataValidator',
    'DataProcessor',
    'MathUtils',
    'FileUtils',
    'TimeUtils',
    'AsyncUtils',
    'PerformanceMonitor',
    'Timer',
    'timer_context',
    'Serializer',
    'Cache',
    'Registry',
    'get_cache',
    'get_registry',
    'get_performance_monitor',
    
    # Application
    'SelfImprovingLoopApplication',
    
    # Demo
    'SelfImprovingLoopDemo'
]

# Package metadata
__package_info__ = {
    'name': 'self_improving_loop',
    'version': __version__,
    'description': __description__,
    'author': __author__,
    'email': __email__,
    'license': 'MIT',
    'python_requires': '>=3.8',
    'keywords': [
        'machine-learning', 'optimization', 'adaptation', 'feedback-loop',
        'self-improving', 'meta-learning', 'automl', 'bitwisers'
    ],
    'classifiers': [
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'Topic :: Software Development :: Libraries :: Python Modules'
    ]
}

def get_version():
    """Package versiyonunu döndürür"""
    return __version__

def get_package_info():
    """Package bilgilerini döndürür"""
    return __package_info__.copy()

def check_dependencies():
    """Gerekli bağımlılıkları kontrol eder"""
    missing_deps = []
    
    required_deps = [
        'numpy', 'pandas', 'scikit-learn', 'asyncio',
        'fastapi', 'pydantic', 'pyyaml', 'psutil'
    ]
    
    for dep in required_deps:
        try:
            __import__(dep)
        except ImportError:
            missing_deps.append(dep)
    
    if missing_deps:
        raise ImportError(
            f"Missing required dependencies: {', '.join(missing_deps)}. "
            f"Please install with: pip install -r requirements.txt"
        )
    
    return True

def validate_installation():
    """Sistem kurulumunu doğrular"""
    try:
        # Bağımlılıkları kontrol et
        check_dependencies()
        
        # Konfigürasyon dizinini kontrol et
        config_dir = Path("./config")
        if not config_dir.exists():
            config_dir.mkdir(exist_ok=True)
            # Varsayılan konfigürasyon oluştur
            config_manager = get_config_manager()
            default_config = {
                'system': {
                    'debug_mode': False,
                    'log_level': 'INFO'
                },
                'api': {
                    'api_interface': {
                        'enabled': True,
                        'host': '0.0.0.0',
                        'port': 8000
                    }
                }
            }
            for config_name, config_data in default_config.items():
                config_manager.update_config(config_name, config_data, validate=False)
        
        # Log dizinini kontrol et
        log_dir = Path("./logs")
        log_dir.mkdir(exist_ok=True)
        
        # Data dizinlerini oluştur
        for subdir in ['data', 'cache', 'temp', 'mlartifacts']:
            (Path("./") / subdir).mkdir(exist_ok=True)
        
        return True
        
    except Exception as e:
        print(f"Installation validation failed: {e}")
        return False

def quick_start():
    """Hızlı başlangıç rehberi"""
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                    Self-Improving Feedback Loop                              ║
║                          Quick Start Guide                                   ║
╠══════════════════════════════════════════════════════════════════════════════╣
║                                                                              ║
║  🚀 Ana Sistem Bileşenleri:                                                  ║
║     • Continuous Learning Pipeline                                           ║
║     • Automated System Adaptation                                            ║
║     • Performance-Driven Optimization                                        ║
║     • Real-time System Monitoring                                            ║
║     • Integration with Bitwisers Components                                  ║
║                                                                              ║
║  📋 Çalışma Modları:                                                         ║
║     python main.py standalone  # Standalone sistem                           ║
║     python main.py api        # API server                                   ║
║     python main.py demo       # Demo senaryoları                             ║
║     python main.py test       # Sistem testleri                              ║
║                                                                              ║
║  🔧 Konfigürasyon:                                                           ║
║     config/                    # Konfigürasyon dosyaları                     ║
║     logs/                      # Log dosyaları                                ║
║     data/, cache/, temp/       # Veri dizinleri                              ║
║                                                                              ║
║  📊 API Endpoints:                                                           ║
║     GET  /                     # API durumu                                  ║
║     GET  /health              # Sistem sağlığı                               ║
║     GET  /metrics             # Performans metrikleri                        ║
║     POST /optimize            # Optimizasyon başlat                          ║
║     POST /learn               # Öğrenme başlat                               ║
║     GET  /status              # Detaylı sistem durumu                        ║
║     POST /config              # Konfigürasyon güncelle                       ║
║                                                                              ║
║  🌐 WebSocket:                                                               ║
║     ws://localhost:8000/ws    # Real-time event streaming                    ║
║                                                                              ║
║  📚 Dokümantasyon:                                                           ║
║     docs/self_improving_feedback_loop.md                                     ║
║                                                                              ║
║  🧪 Test Etmek İçin:                                                         ║
║     python -m pytest tests/ -v                                              ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
    """)

# Package initialization
try:
    # Kurulumu doğrula
    validate_installation()
except Exception as e:
    print(f"Warning: Installation validation failed: {e}")
    print("Run 'pip install -r requirements.txt' to install dependencies")

# Module-level logger
logger = get_logger('self_improving_loop')
logger.info(f"Self-Improving Feedback Loop v{__version__} loaded successfully")

# Performance monitoring
def measure_import_time():
    """Import süresini ölçer"""
    import time
    start_time = time.time()
    # Bu fonksiyon import süresini ölçmek için kullanılır
    return time.time() - start_time

import_time = measure_import_time()
logger.debug(f"Module import completed in {import_time:.3f}s")
