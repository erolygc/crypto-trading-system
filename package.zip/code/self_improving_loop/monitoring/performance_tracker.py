"""
Performance Tracker
Tracks and analyzes performance metrics across all system components
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
import numpy as np
import pandas as pd
from collections import deque
import json
import os

class MetricCategory(Enum):
    """Categories of performance metrics"""
    TRADING = "trading"
    EXECUTION = "execution"
    RISK = "risk"
    SYSTEM = "system"
    ML = "machine_learning"

class PerformanceLevel(Enum):
    """Performance levels"""
    EXCELLENT = "excellent"
    GOOD = "good"
    FAIR = "fair"
    POOR = "poor"
    CRITICAL = "critical"

@dataclass
class PerformanceSnapshot:
    """Performance snapshot at a point in time"""
    timestamp: datetime
    category: MetricCategory
    metrics: Dict[str, float]
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class PerformanceAnalysis:
    """Performance analysis result"""
    category: MetricCategory
    current_performance: Dict[str, float]
    historical_trend: Dict[str, float]
    performance_level: PerformanceLevel
    recommendations: List[str]
    anomalies_detected: List[Dict[str, Any]]
    improvement_potential: float

class PerformanceTracker:
    """
    Performance Tracker for comprehensive performance monitoring
    Tracks performance across all system components and provides insights
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Performance tracking state
        self.performance_snapshots: deque = deque(maxlen=1000)
        self.category_performance: Dict[MetricCategory, deque] = {}
        self.performance_benchmarks: Dict[str, Dict[str, float]] = {}
        self.anomaly_history: List[Dict[str, Any]] = []
        
        # Initialize category performance tracking
        for category in MetricCategory:
            self.category_performance[category] = deque(maxlen=500)
        
        # Performance thresholds and benchmarks
        self.performance_thresholds = {
            MetricCategory.TRADING: {
                'sharpe_ratio': {'excellent': 2.0, 'good': 1.5, 'fair': 1.0, 'poor': 0.5},
                'sortino_ratio': {'excellent': 2.5, 'good': 1.8, 'fair': 1.2, 'poor': 0.8},
                'max_drawdown': {'excellent': 0.05, 'good': 0.10, 'fair': 0.15, 'poor': 0.20},
                'win_rate': {'excellent': 0.65, 'good': 0.60, 'fair': 0.55, 'poor': 0.50},
                'profit_factor': {'excellent': 2.0, 'good': 1.5, 'fair': 1.2, 'poor': 1.0}
            },
            MetricCategory.EXECUTION: {
                'execution_speed': {'excellent': 100, 'good': 200, 'fair': 500, 'poor': 1000},  # ms
                'slippage': {'excellent': 0.001, 'good': 0.005, 'fair': 0.01, 'poor': 0.02},
                'fill_rate': {'excellent': 0.98, 'good': 0.95, 'fair': 0.90, 'poor': 0.85},
                'latency': {'excellent': 50, 'good': 100, 'fair': 200, 'poor': 500}  # ms
            },
            MetricCategory.RISK: {
                'var_95': {'excellent': 0.02, 'good': 0.03, 'fair': 0.05, 'poor': 0.08},
                'cvar_95': {'excellent': 0.03, 'good': 0.04, 'fair': 0.06, 'poor': 0.10},
                'volatility': {'excellent': 0.10, 'good': 0.15, 'fair': 0.20, 'poor': 0.25},
                'beta': {'excellent': 0.8, 'good': 1.0, 'fair': 1.2, 'poor': 1.5}
            },
            MetricCategory.SYSTEM: {
                'uptime': {'excellent': 0.999, 'good': 0.995, 'fair': 0.990, 'poor': 0.985},
                'cpu_usage': {'excellent': 0.5, 'good': 0.7, 'fair': 0.8, 'poor': 0.9},
                'memory_usage': {'excellent': 0.6, 'good': 0.7, 'fair': 0.8, 'poor': 0.9},
                'response_time': {'excellent': 100, 'good': 200, 'fair': 500, 'poor': 1000}  # ms
            },
            MetricCategory.ML: {
                'accuracy': {'excellent': 0.95, 'good': 0.90, 'fair': 0.85, 'poor': 0.80},
                'precision': {'excellent': 0.95, 'good': 0.90, 'fair': 0.85, 'poor': 0.80},
                'recall': {'excellent': 0.95, 'good': 0.90, 'fair': 0.85, 'poor': 0.80},
                'f1_score': {'excellent': 0.95, 'good': 0.90, 'fair': 0.85, 'poor': 0.80},
                'prediction_latency': {'excellent': 10, 'good': 50, 'fair': 100, 'poor': 200}  # ms
            }
        }
        
        # Analysis configuration
        self.analysis_config = {
            'trend_window': 24,  # hours
            'anomaly_threshold': 2.0,  # standard deviations
            'benchmark_lookback': 30,  # days
            'performance_decay': 0.95,  # exponential decay factor
            'correlation_window': 100  # number of data points
        }
        
        # Update from config
        if 'performance_tracking' in config:
            tracking_config = config['performance_tracking']
            if 'thresholds' in tracking_config:
                self.performance_thresholds.update(tracking_config['thresholds'])
            if 'analysis' in tracking_config:
                self.analysis_config.update(tracking_config['analysis'])
        
        # Performance metrics
        self.tracking_metrics = {
            'total_snapshots': 0,
            'categories_tracked': len(MetricCategory),
            'anomalies_detected': 0,
            'recommendations_generated': 0,
            'benchmark_updates': 0,
            'last_update': None
        }
        
        self.logger.info("Performance Tracker initialized")
    
    async def initialize(self) -> None:
        """Initialize the performance tracker"""
        try:
            # Load historical benchmarks
            await self._load_performance_benchmarks()
            
            # Start background tasks
            asyncio.create_task(self._background_performance_collection())
            asyncio.create_task(self._anomaly_detection_loop())
            asyncio.create_task(self._benchmark_update_loop())
            
            self.logger.info("Performance Tracker initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize tracker: {e}")
            raise
    
    async def update_metrics(self, metrics: Dict[str, float]) -> None:
        """Update performance metrics"""
        try:
            # Create performance snapshot
            snapshot = PerformanceSnapshot(
                timestamp=datetime.now(),
                category=self._categorize_metrics(metrics),
                metrics=metrics.copy(),
                metadata={
                    'source': 'system_update',
                    'version': '1.0'
                }
            )
            
            # Store snapshot
            self.performance_snapshots.append(snapshot)
            
            # Update category-specific tracking
            category_queue = self.category_performance[snapshot.category]
            category_queue.append(snapshot)
            
            # Update metrics
            self.tracking_metrics['total_snapshots'] += 1
            self.tracking_metrics['last_update'] = datetime.now()
            
            # Check for immediate anomalies
            await self._check_immediate_anomalies(snapshot)
            
            self.logger.debug(f"Performance metrics updated: {len(metrics)} metrics")
            
        except Exception as e:
            self.logger.error(f"Performance metrics update failed: {e}")
    
    def _categorize_metrics(self, metrics: Dict[str, float]) -> MetricCategory:
        """Categorize metrics based on names"""
        try:
            metric_names = set(metrics.keys())
            
            # Define category keywords
            trading_keywords = {'sharpe', 'sortino', 'drawdown', 'win_rate', 'profit', 'return'}
            execution_keywords = {'execution', 'speed', 'slippage', 'fill', 'latency', 'delay'}
            risk_keywords = {'var', 'cvar', 'volatility', 'beta', 'risk', 'correlation'}
            system_keywords = {'uptime', 'cpu', 'memory', 'response', 'throughput', 'error'}
            ml_keywords = {'accuracy', 'precision', 'recall', 'f1', 'prediction', 'model'}
            
            # Count matches for each category
            category_scores = {
                MetricCategory.TRADING: len(metric_names.intersection(trading_keywords)),
                MetricCategory.EXECUTION: len(metric_names.intersection(execution_keywords)),
                MetricCategory.RISK: len(metric_names.intersection(risk_keywords)),
                MetricCategory.SYSTEM: len(metric_names.intersection(system_keywords)),
                MetricCategory.ML: len(metric_names.intersection(ml_keywords))
            }
            
            # Return category with highest score
            return max(category_scores.items(), key=lambda x: x[1])[0]
            
        except Exception as e:
            self.logger.error(f"Metric categorization failed: {e}")
            return MetricCategory.SYSTEM  # Default category
    
    async def _check_immediate_anomalies(self, snapshot: PerformanceSnapshot) -> None:
        """Check for immediate anomalies in the snapshot"""
        try:
            category = snapshot.category
            current_metrics = snapshot.metrics
            
            if category not in self.performance_thresholds:
                return
            
            thresholds = self.performance_thresholds[category]
            
            anomalies = []
            for metric_name, current_value in current_metrics.items():
                if metric_name in thresholds:
                    metric_thresholds = thresholds[metric_name]
                    
                    # Check for threshold violations
                    for level, threshold_value in metric_thresholds.items():
                        if self._is_threshold_violated(metric_name, current_value, threshold_value, level):
                            anomaly = {
                                'timestamp': snapshot.timestamp,
                                'metric': metric_name,
                                'category': category.value,
                                'current_value': current_value,
                                'threshold': threshold_value,
                                'level': level,
                                'type': 'threshold_violation'
                            }
                            anomalies.append(anomaly)
            
            # Store anomalies
            if anomalies:
                self.anomaly_history.extend(anomalies)
                self.tracking_metrics['anomalies_detected'] += len(anomalies)
                
                self.logger.warning(f"Detected {len(anomalies)} performance anomalies")
            
        except Exception as e:
            self.logger.error(f"Immediate anomaly check failed: {e}")
    
    def _is_threshold_violated(
        self, 
        metric_name: str, 
        current_value: float, 
        threshold_value: float, 
        level: str
    ) -> bool:
        """Check if a metric violates a threshold"""
        try:
            # Define threshold logic based on metric characteristics
            lower_is_better_metrics = ['drawdown', 'slippage', 'var', 'cvar', 'volatility', 'response_time', 'latency', 'prediction_latency', 'cpu_usage', 'memory_usage']
            higher_is_better_metrics = ['sharpe_ratio', 'sortino_ratio', 'win_rate', 'profit_factor', 'fill_rate', 'uptime', 'accuracy', 'precision', 'recall', 'f1_score']
            
            if metric_name in lower_is_better_metrics:
                if level == 'poor':
                    return current_value > threshold_value
                elif level == 'critical':
                    return current_value > threshold_value * 1.5
            elif metric_name in higher_is_better_metrics:
                if level == 'poor':
                    return current_value < threshold_value
                elif level == 'critical':
                    return current_value < threshold_value * 0.5
            
            return False
            
        except Exception as e:
            self.logger.error(f"Threshold violation check failed: {e}")
            return False
    
    async def analyze_performance(self, category: Optional[MetricCategory] = None) -> PerformanceAnalysis:
        """Analyze current performance"""
        try:
            if category is None:
                # Analyze overall performance across all categories
                category = MetricCategory.SYSTEM  # Default
            
            # Get performance data
            category_data = self.category_performance.get(category, deque())
            
            if len(category_data) < 5:
                # Insufficient data for analysis
                return PerformanceAnalysis(
                    category=category,
                    current_performance={},
                    historical_trend={},
                    performance_level=PerformanceLevel.FAIR,
                    recommendations=['Insufficient data for performance analysis'],
                    anomalies_detected=[],
                    improvement_potential=0.0
                )
            
            # Calculate current performance (most recent snapshot)
            current_snapshot = category_data[-1]
            current_performance = current_snapshot.metrics
            
            # Calculate historical trends
            historical_trend = self._calculate_performance_trends(category_data)
            
            # Determine performance level
            performance_level = self._determine_performance_level(category, current_performance)
            
            # Generate recommendations
            recommendations = self._generate_recommendations(category, current_performance, historical_trend)
            
            # Detect anomalies
            anomalies_detected = self._detect_performance_anomalies(category, current_performance)
            
            # Calculate improvement potential
            improvement_potential = self._calculate_improvement_potential(category, current_performance)
            
            analysis = PerformanceAnalysis(
                category=category,
                current_performance=current_performance,
                historical_trend=historical_trend,
                performance_level=performance_level,
                recommendations=recommendations,
                anomalies_detected=anomalies_detected,
                improvement_potential=improvement_potential
            )
            
            self.tracking_metrics['recommendations_generated'] += len(recommendations)
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Performance analysis failed: {e}")
            return PerformanceAnalysis(
                category=category or MetricCategory.SYSTEM,
                current_performance={},
                historical_trend={},
                performance_level=PerformanceLevel.FAIR,
                recommendations=[f'Analysis failed: {str(e)}'],
                anomalies_detected=[],
                improvement_potential=0.0
            )
    
    def _calculate_performance_trends(
        self, 
        category_data: deque
    ) -> Dict[str, float]:
        """Calculate performance trends over time"""
        try:
            if len(category_data) < 2:
                return {}
            
            # Get recent data points (last 24 hours or available data)
            recent_data = list(category_data)[-min(24, len(category_data)):]
            
            # Collect all metric names
            all_metrics = set()
            for snapshot in recent_data:
                all_metrics.update(snapshot.metrics.keys())
            
            trends = {}
            
            for metric_name in all_metrics:
                # Get metric values over time
                metric_values = [
                    snapshot.metrics.get(metric_name, 0) 
                    for snapshot in recent_data 
                    if metric_name in snapshot.metrics
                ]
                
                if len(metric_values) >= 2:
                    # Calculate trend (simple linear regression slope)
                    x = np.arange(len(metric_values))
                    if len(x) > 1:
                        slope = np.polyfit(x, metric_values, 1)[0]
                        trends[metric_name] = slope
                    else:
                        trends[metric_name] = 0.0
            
            return trends
            
        except Exception as e:
            self.logger.error(f"Performance trend calculation failed: {e}")
            return {}
    
    def _determine_performance_level(
        self, 
        category: MetricCategory, 
        current_performance: Dict[str, float]
    ) -> PerformanceLevel:
        """Determine overall performance level"""
        try:
            if category not in self.performance_thresholds:
                return PerformanceLevel.FAIR
            
            thresholds = self.performance_thresholds[category]
            performance_scores = []
            
            for metric_name, current_value in current_performance.items():
                if metric_name in thresholds:
                    metric_thresholds = thresholds[metric_name]
                    
                    # Calculate score based on thresholds
                    score = self._calculate_metric_score(metric_name, current_value, metric_thresholds)
                    performance_scores.append(score)
            
            if not performance_scores:
                return PerformanceLevel.FAIR
            
            # Determine overall level based on average score
            avg_score = np.mean(performance_scores)
            
            if avg_score >= 0.9:
                return PerformanceLevel.EXCELLENT
            elif avg_score >= 0.8:
                return PerformanceLevel.GOOD
            elif avg_score >= 0.6:
                return PerformanceLevel.FAIR
            elif avg_score >= 0.4:
                return PerformanceLevel.POOR
            else:
                return PerformanceLevel.CRITICAL
                
        except Exception as e:
            self.logger.error(f"Performance level determination failed: {e}")
            return PerformanceLevel.FAIR
    
    def _calculate_metric_score(
        self, 
        metric_name: str, 
        current_value: float, 
        thresholds: Dict[str, float]
    ) -> float:
        """Calculate score for a single metric"""
        try:
            # Define metric types
            lower_is_better = ['drawdown', 'slippage', 'var', 'cvar', 'volatility', 'response_time', 'latency', 'cpu_usage', 'memory_usage']
            higher_is_better = ['sharpe_ratio', 'sortino_ratio', 'win_rate', 'profit_factor', 'fill_rate', 'uptime', 'accuracy', 'precision', 'recall', 'f1_score']
            
            if metric_name in lower_is_better:
                # For metrics where lower is better
                excellent_threshold = thresholds.get('excellent', float('inf'))
                good_threshold = thresholds.get('good', float('inf'))
                fair_threshold = thresholds.get('fair', float('inf'))
                
                if current_value <= excellent_threshold:
                    return 1.0
                elif current_value <= good_threshold:
                    return 0.8
                elif current_value <= fair_threshold:
                    return 0.6
                else:
                    return 0.3
                    
            elif metric_name in higher_is_better:
                # For metrics where higher is better
                excellent_threshold = thresholds.get('excellent', 1.0)
                good_threshold = thresholds.get('good', 0.8)
                fair_threshold = thresholds.get('fair', 0.6)
                
                if current_value >= excellent_threshold:
                    return 1.0
                elif current_value >= good_threshold:
                    return 0.8
                elif current_value >= fair_threshold:
                    return 0.6
                else:
                    return 0.3
            else:
                # Default scoring - closer to 1.0 is better
                return 0.7
                
        except Exception as e:
            self.logger.error(f"Metric score calculation failed: {e}")
            return 0.5
    
    def _generate_recommendations(
        self, 
        category: MetricCategory, 
        current_performance: Dict[str, float],
        historical_trend: Dict[str, float]
    ) -> List[str]:
        """Generate performance improvement recommendations"""
        try:
            recommendations = []
            
            # Analyze each metric
            for metric_name, current_value in current_performance.items():
                # Check current performance level
                if category in self.performance_thresholds and metric_name in self.performance_thresholds[category]:
                    thresholds = self.performance_thresholds[category][metric_name]
                    score = self._calculate_metric_score(metric_name, current_value, thresholds)
                    
                    # Generate recommendations based on score and trend
                    if score < 0.6:  # Poor performance
                        trend = historical_trend.get(metric_name, 0)
                        
                        if metric_name in ['sharpe_ratio', 'sortino_ratio']:
                            if trend < 0:
                                recommendations.append(f"Sharpe/Sortino ratio declining. Review risk management and entry/exit criteria.")
                            else:
                                recommendations.append(f"Sharpe/Sortino ratio below target. Consider optimizing position sizing and risk-reward ratios.")
                        
                        elif metric_name == 'max_drawdown':
                            recommendations.append(f"High maximum drawdown detected. Implement stricter risk controls and position sizing adjustments.")
                        
                        elif metric_name in ['accuracy', 'precision', 'recall', 'f1_score']:
                            recommendations.append(f"ML model performance below threshold. Consider retraining models or feature engineering.")
                        
                        elif metric_name in ['response_time', 'latency', 'execution_speed']:
                            recommendations.append(f"System performance degraded. Check resource usage and optimize bottlenecks.")
                        
                        elif metric_name in ['var', 'cvar', 'volatility']:
                            recommendations.append(f"Risk metrics elevated. Review risk management strategies and adjust position sizes.")
            
            # Add general recommendations
            if len(recommendations) == 0:
                if category == MetricCategory.TRADING:
                    recommendations.append("Trading performance is stable. Consider incremental improvements to strategy parameters.")
                elif category == MetricCategory.ML:
                    recommendations.append("ML model performance is adequate. Monitor for concept drift and retrain periodically.")
                elif category == MetricCategory.SYSTEM:
                    recommendations.append("System performance is good. Continue monitoring and regular maintenance.")
            
            return recommendations[:5]  # Limit to top 5 recommendations
            
        except Exception as e:
            self.logger.error(f"Recommendation generation failed: {e}")
            return ["Unable to generate recommendations due to analysis error."]
    
    def _detect_performance_anomalies(
        self, 
        category: MetricCategory, 
        current_performance: Dict[str, float]
    ) -> List[Dict[str, Any]]:
        """Detect performance anomalies"""
        try:
            anomalies = []
            category_data = self.category_performance.get(category, deque())
            
            if len(category_data) < 10:
                return anomalies
            
            # Get historical data for anomaly detection
            historical_data = list(category_data)[-min(50, len(category_data)):]
            
            for metric_name, current_value in current_performance.items():
                # Get historical values for this metric
                historical_values = []
                for snapshot in historical_data:
                    if metric_name in snapshot.metrics:
                        historical_values.append(snapshot.metrics[metric_name])
                
                if len(historical_values) >= 10:
                    # Calculate statistics
                    mean_val = np.mean(historical_values)
                    std_val = np.std(historical_values)
                    
                    if std_val > 0:
                        # Calculate z-score
                        z_score = abs(current_value - mean_val) / std_val
                        
                        # Detect anomaly if z-score exceeds threshold
                        if z_score > self.analysis_config['anomaly_threshold']:
                            anomaly = {
                                'metric': metric_name,
                                'current_value': current_value,
                                'historical_mean': mean_val,
                                'historical_std': std_val,
                                'z_score': z_score,
                                'severity': 'high' if z_score > 3.0 else 'medium',
                                'type': 'statistical_anomaly'
                            }
                            anomalies.append(anomaly)
            
            return anomalies
            
        except Exception as e:
            self.logger.error(f"Anomaly detection failed: {e}")
            return []
    
    def _calculate_improvement_potential(
        self, 
        category: MetricCategory, 
        current_performance: Dict[str, float]
    ) -> float:
        """Calculate potential for performance improvement"""
        try:
            if category not in self.performance_thresholds:
                return 0.0
            
            thresholds = self.performance_thresholds[category]
            improvement_potentials = []
            
            for metric_name, current_value in current_performance.items():
                if metric_name in thresholds:
                    metric_thresholds = thresholds[metric_name]
                    
                    # Define whether higher or lower is better
                    lower_is_better = ['drawdown', 'slippage', 'var', 'cvar', 'volatility', 'response_time', 'latency']
                    higher_is_better = ['sharpe_ratio', 'sortino_ratio', 'win_rate', 'profit_factor', 'fill_rate', 'uptime', 'accuracy']
                    
                    if metric_name in lower_is_better:
                        excellent_threshold = metric_thresholds.get('excellent', current_value)
                        improvement_potential = (current_value - excellent_threshold) / current_value if current_value > 0 else 0
                    elif metric_name in higher_is_better:
                        excellent_threshold = metric_thresholds.get('excellent', current_value)
                        improvement_potential = (excellent_threshold - current_value) / excellent_threshold if excellent_threshold > 0 else 0
                    else:
                        improvement_potential = 0.1  # Default potential
                    
                    improvement_potentials.append(max(0.0, improvement_potential))
            
            return np.mean(improvement_potentials) if improvement_potentials else 0.0
            
        except Exception as e:
            self.logger.error(f"Improvement potential calculation failed: {e}")
            return 0.0
    
    async def _background_performance_collection(self) -> None:
        """Background loop for continuous performance collection"""
        while True:
            try:
                # Simulate performance data collection
                simulated_metrics = await self._simulate_performance_collection()
                
                if simulated_metrics:
                    await self.update_metrics(simulated_metrics)
                
                await asyncio.sleep(60)  # Collect every minute
                
            except Exception as e:
                self.logger.error(f"Background performance collection error: {e}")
                await asyncio.sleep(5)
    
    async def _simulate_performance_collection(self) -> Dict[str, float]:
        """Simulate performance data collection"""
        try:
            import random
            random.seed(int(datetime.now().timestamp()) % 1000)
            
            # Generate realistic performance metrics
            metrics = {}
            
            # Trading metrics
            metrics['sharpe_ratio'] = random.uniform(0.5, 2.5)
            metrics['sortino_ratio'] = random.uniform(0.8, 3.0)
            metrics['max_drawdown'] = random.uniform(0.03, 0.25)
            metrics['win_rate'] = random.uniform(0.45, 0.70)
            metrics['profit_factor'] = random.uniform(1.0, 2.5)
            
            # Execution metrics
            metrics['execution_speed'] = random.uniform(50, 500)  # ms
            metrics['slippage'] = random.uniform(0.001, 0.02)
            metrics['fill_rate'] = random.uniform(0.85, 0.99)
            metrics['latency'] = random.uniform(20, 200)  # ms
            
            # Risk metrics
            metrics['var_95'] = random.uniform(0.01, 0.08)
            metrics['cvar_95'] = random.uniform(0.02, 0.10)
            metrics['volatility'] = random.uniform(0.10, 0.30)
            metrics['beta'] = random.uniform(0.7, 1.5)
            
            # System metrics
            metrics['uptime'] = random.uniform(0.98, 0.999)
            metrics['cpu_usage'] = random.uniform(0.3, 0.8)
            metrics['memory_usage'] = random.uniform(0.4, 0.7)
            metrics['response_time'] = random.uniform(100, 500)  # ms
            
            # ML metrics
            metrics['accuracy'] = random.uniform(0.80, 0.98)
            metrics['precision'] = random.uniform(0.80, 0.98)
            metrics['recall'] = random.uniform(0.80, 0.98)
            metrics['f1_score'] = random.uniform(0.80, 0.98)
            metrics['prediction_latency'] = random.uniform(10, 200)  # ms
            
            return metrics
            
        except Exception as e:
            self.logger.error(f"Performance simulation failed: {e}")
            return {}
    
    async def _anomaly_detection_loop(self) -> None:
        """Background loop for anomaly detection"""
        while True:
            try:
                # Check for anomalies across all categories
                for category in MetricCategory:
                    if category in self.category_performance and len(self.category_performance[category]) > 0:
                        current_snapshot = self.category_performance[category][-1]
                        anomalies = self._detect_performance_anomalies(category, current_snapshot.metrics)
                        
                        if anomalies:
                            self.anomaly_history.extend([
                                {**anomaly, 'detected_at': datetime.now().isoformat()}
                                for anomaly in anomalies
                            ])
                            
                            self.logger.warning(f"Detected {len(anomalies)} anomalies in {category.value}")
                
                # Clean old anomalies
                cutoff_time = datetime.now() - timedelta(hours=24)
                self.anomaly_history = [
                    anomaly for anomaly in self.anomaly_history
                    if datetime.fromisoformat(anomaly.get('detected_at', '1970-01-01')) > cutoff_time
                ]
                
                await asyncio.sleep(300)  # Check every 5 minutes
                
            except Exception as e:
                self.logger.error(f"Anomaly detection loop error: {e}")
                await asyncio.sleep(30)
    
    async def _benchmark_update_loop(self) -> None:
        """Background loop for benchmark updates"""
        while True:
            try:
                # Update benchmarks periodically
                await self._update_performance_benchmarks()
                
                await asyncio.sleep(3600)  # Update every hour
                
            except Exception as e:
                self.logger.error(f"Benchmark update loop error: {e}")
                await asyncio.sleep(60)
    
    async def _update_performance_benchmarks(self) -> None:
        """Update performance benchmarks"""
        try:
            for category in MetricCategory:
                category_data = self.category_performance.get(category, deque())
                
                if len(category_data) >= 20:
                    # Calculate benchmarks from recent data
                    recent_data = list(category_data)[-20:]
                    
                    benchmarks = {}
                    for metric_name in recent_data[-1].metrics:
                        values = [
                            snapshot.metrics.get(metric_name, 0)
                            for snapshot in recent_data
                            if metric_name in snapshot.metrics
                        ]
                        
                        if values:
                            benchmarks[metric_name] = {
                                'mean': np.mean(values),
                                'std': np.std(values),
                                'median': np.median(values),
                                'p25': np.percentile(values, 25),
                                'p75': np.percentile(values, 75)
                            }
                    
                    self.performance_benchmarks[category.value] = benchmarks
            
            self.tracking_metrics['benchmark_updates'] += 1
            
            self.logger.debug("Performance benchmarks updated")
            
        except Exception as e:
            self.logger.error(f"Benchmark update failed: {e}")
    
    async def _load_performance_benchmarks(self) -> None:
        """Load initial performance benchmarks"""
        try:
            # Set default benchmarks
            self.performance_benchmarks = {
                'trading': {
                    'sharpe_ratio': {'mean': 1.2, 'std': 0.3, 'median': 1.15},
                    'max_drawdown': {'mean': 0.12, 'std': 0.05, 'median': 0.10}
                },
                'system': {
                    'uptime': {'mean': 0.995, 'std': 0.003, 'median': 0.996},
                    'response_time': {'mean': 200, 'std': 50, 'median': 180}
                }
            }
            
            self.logger.info("Performance benchmarks loaded")
            
        except Exception as e:
            self.logger.error(f"Benchmark loading failed: {e}")
    
    async def get_state(self) -> Dict[str, Any]:
        """Get current performance tracking state"""
        return {
            'tracking_metrics': self.tracking_metrics,
            'snapshot_count': len(self.performance_snapshots),
            'anomaly_count': len(self.anomaly_history),
            'benchmark_categories': len(self.performance_benchmarks),
            'categories_tracked': {cat.value: len(queue) for cat, queue in self.category_performance.items()}
        }
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get performance summary across all categories"""
        try:
            summary = {}
            
            for category in MetricCategory:
                if category in self.category_performance and len(self.category_performance[category]) > 0:
                    latest_snapshot = self.category_performance[category][-1]
                    
                    summary[category.value] = {
                        'metrics_count': len(latest_snapshot.metrics),
                        'latest_metrics': latest_snapshot.metrics,
                        'data_points': len(self.category_performance[category])
                    }
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Performance summary failed: {e}")
            return {}
    
    def get_recent_anomalies(self, hours: int = 24) -> List[Dict[str, Any]]:
        """Get recent anomalies"""
        try:
            cutoff_time = datetime.now() - timedelta(hours=hours)
            
            return [
                anomaly for anomaly in self.anomaly_history
                if 'detected_at' in anomaly and 
                datetime.fromisoformat(anomaly['detected_at']) > cutoff_time
            ]
            
        except Exception as e:
            self.logger.error(f"Recent anomalies retrieval failed: {e}")
            return []
