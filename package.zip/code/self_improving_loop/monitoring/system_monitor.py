"""
System Monitor
Implements Phase 5: Real-time system monitoring and calibration
"""

import asyncio
import logging
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from enum import Enum
import numpy as np
import pandas as pd
from collections import deque
import json
import os

class MetricType(Enum):
    """Types of system metrics"""
    PERFORMANCE = "performance"
    RESOURCE = "resource"
    QUALITY = "quality"
    BUSINESS = "business"
    TECHNICAL = "technical"

class AlertSeverity(Enum):
    """Alert severity levels"""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"

class CalibrationStatus(Enum):
    """Calibration status"""
    IDLE = "idle"
    CALIBRATING = "calibrating"
    COMPLETED = "completed"
    FAILED = "failed"

@dataclass
class SystemMetric:
    """System metric data point"""
    name: str
    value: float
    timestamp: datetime
    metric_type: MetricType
    unit: str
    tags: Dict[str, str] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class Alert:
    """System alert"""
    id: str
    severity: AlertSeverity
    title: str
    message: str
    metric_name: str
    current_value: float
    threshold_value: float
    triggered_at: datetime
    acknowledged: bool = False
    resolved_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

@dataclass
class CalibrationResult:
    """System calibration result"""
    id: str
    status: CalibrationStatus
    start_time: datetime
    end_time: Optional[datetime] = None
    calibrated_components: List[str] = field(default_factory=list)
    calibration_data: Dict[str, Any] = field(default_factory=dict)
    performance_impact: Dict[str, float] = field(default_factory=dict)
    error_message: Optional[str] = None

class SystemMonitor:
    """
    System Monitor for Phase 5
    Implements real-time monitoring and system calibration
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Monitoring state
        self.active_monitors: Dict[str, Any] = {}
        self.metric_history: Dict[str, deque] = {}
        self.active_alerts: Dict[str, Alert] = {}
        self.calibration_queue: List[CalibrationResult] = []
        self.active_calibrations: Dict[str, CalibrationResult] = {}
        
        # Configuration
        self.monitoring_config = {
            'collection_interval': 10,  # seconds
            'history_retention_hours': 24,
            'alert_thresholds': {},
            'calibration_triggers': {},
            'health_check_enabled': True
        }
        
        # Performance thresholds
        self.thresholds = {
            'performance_drop': 0.15,
            'error_rate': 0.05,
            'response_time': 1000,  # ms
            'cpu_usage': 0.8,
            'memory_usage': 0.8,
            'disk_usage': 0.9,
            'network_latency': 100,  # ms
            'throughput_drop': 0.2
        }
        
        # Update thresholds from config
        if 'monitoring' in config:
            self.monitoring_config.update(config['monitoring'])
            if 'alert_thresholds' in config['monitoring']:
                self.thresholds.update(config['monitoring']['alert_thresholds'])
        
        # Metrics tracking
        self.monitoring_metrics = {
            'metrics_collected': 0,
            'alerts_triggered': 0,
            'calibrations_performed': 0,
            'average_calibration_time': 0.0,
            'system_health_score': 1.0,
            'uptime_percentage': 1.0
        }
        
        # Component monitoring
        self.component_health = {
            'data_processor': {'status': 'healthy', 'last_check': None},
            'model_engine': {'status': 'healthy', 'last_check': None},
            'adaptation_system': {'status': 'healthy', 'last_check': None},
            'optimization_engine': {'status': 'healthy', 'last_check': None},
            'parameter_tuner': {'status': 'healthy', 'last_check': None}
        }
        
        # Self-calibration settings
        self.self_calibration = {
            'enabled': True,
            'calibration_frequency': 3600,  # 1 hour
            'auto_calibration': True,
            'calibration_aggressiveness': 0.5  # 0.0-1.0
        }
        
        self.logger.info("System Monitor initialized")
    
    async def initialize(self) -> None:
        """Initialize the system monitor"""
        try:
            # Initialize metric history buffers
            await self._initialize_metric_history()
            
            # Start monitoring tasks
            asyncio.create_task(self._metric_collection_loop())
            asyncio.create_task(self._alert_processing_loop())
            
            if self.self_calibration['enabled']:
                asyncio.create_task(self._self_calibration_loop())
            
            if self.monitoring_config['health_check_enabled']:
                asyncio.create_task(self._health_check_loop())
            
            self.logger.info("System Monitor initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize monitor: {e}")
            raise
    
    async def run_calibration_cycle(self) -> Dict[str, Any]:
        """Execute one calibration cycle"""
        try:
            self.logger.info("Starting calibration cycle")
            
            cycle_results = {
                'cycle_id': f"calibration_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                'timestamp': datetime.now().isoformat(),
                'status': 'started',
                'calibrations': [],
                'system_health': {},
                'performance_metrics': {}
            }
            
            # Step 1: Collect system metrics
            current_metrics = await self._collect_system_metrics()
            
            # Step 2: Analyze system health
            health_analysis = await self._analyze_system_health(current_metrics)
            
            # Step 3: Identify calibration opportunities
            calibration_opportunities = await self._identify_calibration_opportunities(
                health_analysis
            )
            
            # Step 4: Execute calibrations
            if calibration_opportunities:
                calibration_results = await self._execute_calibrations(
                    calibration_opportunities
                )
                
                cycle_results.update({
                    'status': 'completed',
                    'calibrations_performed': len(calibration_results),
                    'calibrations': calibration_results,
                    'calibrations_count': len(calibration_results),
                    'system_health': health_analysis
                })
            else:
                cycle_results.update({
                    'status': 'completed',
                    'calibrations_performed': 0,
                    'message': 'No calibration opportunities identified',
                    'system_health': health_analysis
                })
            
            # Step 5: Update monitoring metrics
            await self._update_monitoring_metrics(calibration_results)
            
            self.logger.info(f"Calibration cycle completed: {cycle_results['calibrations_performed']} calibrations performed")
            
            return cycle_results
            
        except Exception as e:
            self.logger.error(f"Calibration cycle failed: {e}")
            return {
                'cycle_id': 'failed',
                'status': 'failed',
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    async def _initialize_metric_history(self) -> None:
        """Initialize metric history buffers"""
        try:
            # Define metrics to track
            tracked_metrics = [
                'response_time', 'throughput', 'error_rate', 'cpu_usage',
                'memory_usage', 'disk_usage', 'network_latency', 'accuracy',
                'sharpe_ratio', 'drawdown', 'model_accuracy', 'prediction_latency'
            ]
            
            # Calculate buffer size based on retention period
            buffer_size = int(
                self.monitoring_config['history_retention_hours'] * 3600 / 
                self.monitoring_config['collection_interval']
            )
            
            # Initialize history buffers
            for metric_name in tracked_metrics:
                self.metric_history[metric_name] = deque(maxlen=buffer_size)
            
            self.logger.info(f"Initialized {len(tracked_metrics)} metric history buffers")
            
        except Exception as e:
            self.logger.error(f"Metric history initialization failed: {e}")
            raise
    
    async def _collect_system_metrics(self) -> Dict[str, float]:
        """Collect current system metrics"""
        try:
            metrics = {}
            
            # Simulate metric collection
            import random
            random.seed(int(datetime.now().timestamp()) % 1000)
            
            # Performance metrics
            metrics['response_time'] = random.uniform(50, 200)
            metrics['throughput'] = random.uniform(100, 500)
            metrics['error_rate'] = random.uniform(0, 0.05)
            metrics['accuracy'] = random.uniform(0.85, 0.98)
            
            # Resource metrics
            metrics['cpu_usage'] = random.uniform(0.3, 0.8)
            metrics['memory_usage'] = random.uniform(0.4, 0.7)
            metrics['disk_usage'] = random.uniform(0.3, 0.6)
            metrics['network_latency'] = random.uniform(20, 100)
            
            # Business metrics
            metrics['sharpe_ratio'] = random.uniform(0.8, 2.5)
            metrics['drawdown'] = random.uniform(0.05, 0.25)
            metrics['model_accuracy'] = random.uniform(0.8, 0.95)
            metrics['prediction_latency'] = random.uniform(10, 50)
            
            # Add timestamps and store in history
            timestamp = datetime.now()
            for metric_name, value in metrics.items():
                metric_point = SystemMetric(
                    name=metric_name,
                    value=value,
                    timestamp=timestamp,
                    metric_type=self._get_metric_type(metric_name),
                    unit=self._get_metric_unit(metric_name)
                )
                
                # Add to history
                if metric_name in self.metric_history:
                    self.metric_history[metric_name].append(metric_point)
            
            # Update monitoring metrics
            self.monitoring_metrics['metrics_collected'] += len(metrics)
            
            return metrics
            
        except Exception as e:
            self.logger.error(f"System metrics collection failed: {e}")
            return {}
    
    def _get_metric_type(self, metric_name: str) -> MetricType:
        """Get metric type for a metric name"""
        performance_metrics = ['response_time', 'throughput', 'accuracy', 'sharpe_ratio', 'drawdown']
        resource_metrics = ['cpu_usage', 'memory_usage', 'disk_usage', 'network_latency']
        quality_metrics = ['error_rate', 'model_accuracy', 'prediction_latency']
        
        if metric_name in performance_metrics:
            return MetricType.PERFORMANCE
        elif metric_name in resource_metrics:
            return MetricType.RESOURCE
        elif metric_name in quality_metrics:
            return MetricType.QUALITY
        else:
            return MetricType.TECHNICAL
    
    def _get_metric_unit(self, metric_name: str) -> str:
        """Get unit for a metric"""
        unit_mapping = {
            'response_time': 'ms',
            'throughput': 'requests/sec',
            'error_rate': 'ratio',
            'accuracy': 'ratio',
            'cpu_usage': 'ratio',
            'memory_usage': 'ratio',
            'disk_usage': 'ratio',
            'network_latency': 'ms',
            'sharpe_ratio': 'ratio',
            'drawdown': 'ratio',
            'model_accuracy': 'ratio',
            'prediction_latency': 'ms'
        }
        
        return unit_mapping.get(metric_name, 'unknown')
    
    async def _analyze_system_health(self, current_metrics: Dict[str, float]) -> Dict[str, Any]:
        """Analyze overall system health"""
        try:
            health_analysis = {
                'overall_health_score': 1.0,
                'component_health': {},
                'alert_count': 0,
                'health_trends': {},
                'recommendations': []
            }
            
            # Analyze each metric
            for metric_name, current_value in current_metrics.items():
                # Get historical baseline
                historical_values = [point.value for point in self.metric_history.get(metric_name, [])]
                
                if len(historical_values) >= 10:
                    baseline = np.mean(historical_values[-10:])
                    trend = np.mean(historical_values[-5:]) - np.mean(historical_values[-10:-5])
                    
                    # Calculate health score for this metric
                    health_score = self._calculate_metric_health(metric_name, current_value, baseline)
                    
                    health_analysis['health_trends'][metric_name] = {
                        'current_value': current_value,
                        'baseline': baseline,
                        'trend': trend,
                        'health_score': health_score,
                        'status': self._get_health_status(health_score)
                    }
                    
                    # Check for alerts
                    alert = await self._check_threshold_alert(metric_name, current_value, baseline)
                    if alert:
                        self.active_alerts[alert.id] = alert
                        health_analysis['alert_count'] += 1
                else:
                    # Insufficient history
                    health_analysis['health_trends'][metric_name] = {
                        'current_value': current_value,
                        'status': 'insufficient_data',
                        'health_score': 0.5
                    }
            
            # Calculate overall health score
            health_scores = [
                trend['health_score'] 
                for trend in health_analysis['health_trends'].values()
                if isinstance(trend, dict) and 'health_score' in trend
            ]
            
            if health_scores:
                health_analysis['overall_health_score'] = np.mean(health_scores)
            
            # Update monitoring metrics
            self.monitoring_metrics['system_health_score'] = health_analysis['overall_health_score']
            
            self.logger.debug(f"System health analysis: score={health_analysis['overall_health_score']:.3f}")
            
            return health_analysis
            
        except Exception as e:
            self.logger.error(f"System health analysis failed: {e}")
            return {'overall_health_score': 0.5}
    
    def _calculate_metric_health(
        self, 
        metric_name: str, 
        current_value: float, 
        baseline: float
    ) -> float:
        """Calculate health score for a specific metric"""
        try:
            # Define health calculation logic based on metric type
            if metric_name == 'error_rate':
                # Lower is better
                if baseline > 0:
                    return max(0.0, min(1.0, 1.0 - (current_value - baseline) / baseline))
                else:
                    return 1.0 if current_value == 0 else 0.0
            
            elif metric_name in ['response_time', 'network_latency', 'prediction_latency']:
                # Lower is better
                if baseline > 0:
                    return max(0.0, min(1.0, baseline / current_value))
                else:
                    return 1.0
            
            elif metric_name in ['accuracy', 'model_accuracy', 'sharpe_ratio']:
                # Higher is better
                if baseline > 0:
                    return max(0.0, min(1.0, current_value / baseline))
                else:
                    return 1.0 if current_value > 0.5 else 0.0
            
            elif metric_name in ['drawdown']:
                # Lower is better
                if baseline > 0:
                    return max(0.0, min(1.0, 1.0 - (current_value - baseline) / baseline))
                else:
                    return 1.0 if current_value < 0.1 else 0.0
            
            elif metric_name in ['cpu_usage', 'memory_usage', 'disk_usage']:
                # Balanced - around 70% is optimal
                optimal = 0.7
                distance_from_optimal = abs(current_value - optimal)
                return max(0.0, min(1.0, 1.0 - distance_from_optimal / 0.5))
            
            elif metric_name == 'throughput':
                # Higher is better
                if baseline > 0:
                    return max(0.0, min(1.0, current_value / baseline))
                else:
                    return 1.0 if current_value > 100 else 0.0
            
            else:
                # Default: closer to baseline is better
                if baseline > 0:
                    deviation = abs(current_value - baseline) / baseline
                    return max(0.0, min(1.0, 1.0 - deviation))
                else:
                    return 1.0 if current_value == 0 else 0.5
                    
        except Exception as e:
            self.logger.error(f"Metric health calculation failed for {metric_name}: {e}")
            return 0.5
    
    def _get_health_status(self, health_score: float) -> str:
        """Get health status string from score"""
        if health_score >= 0.9:
            return 'excellent'
        elif health_score >= 0.8:
            return 'good'
        elif health_score >= 0.6:
            return 'fair'
        elif health_score >= 0.4:
            return 'poor'
        else:
            return 'critical'
    
    async def _check_threshold_alert(
        self, 
        metric_name: str, 
        current_value: float, 
        baseline: float
    ) -> Optional[Alert]:
        """Check if metric value triggers an alert"""
        try:
            alert_id = f"alert_{metric_name}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
            
            # Check predefined thresholds
            if metric_name in self.thresholds:
                threshold = self.thresholds[metric_name]
                
                if metric_name == 'error_rate':
                    if current_value > threshold:
                        return Alert(
                            id=alert_id,
                            severity=AlertSeverity.ERROR if current_value > threshold * 2 else AlertSeverity.WARNING,
                            title=f"High {metric_name} detected",
                            message=f"{metric_name} is {current_value:.3f}, above threshold {threshold:.3f}",
                            metric_name=metric_name,
                            current_value=current_value,
                            threshold_value=threshold,
                            triggered_at=datetime.now()
                        )
                
                elif metric_name in ['response_time', 'network_latency', 'prediction_latency']:
                    if current_value > threshold:
                        return Alert(
                            id=alert_id,
                            severity=AlertSeverity.ERROR if current_value > threshold * 2 else AlertSeverity.WARNING,
                            title=f"High {metric_name} detected",
                            message=f"{metric_name} is {current_value:.1f}ms, above threshold {threshold}ms",
                            metric_name=metric_name,
                            current_value=current_value,
                            threshold_value=threshold,
                            triggered_at=datetime.now()
                        )
                
                elif metric_name in ['cpu_usage', 'memory_usage', 'disk_usage']:
                    if current_value > threshold:
                        return Alert(
                            id=alert_id,
                            severity=AlertSeverity.CRITICAL if current_value > 0.95 else AlertSeverity.ERROR,
                            title=f"High {metric_name} detected",
                            message=f"{metric_name} is {current_value:.1%}, above threshold {threshold:.1%}",
                            metric_name=metric_name,
                            current_value=current_value,
                            threshold_value=threshold,
                            triggered_at=datetime.now()
                        )
                
                elif metric_name in ['accuracy', 'model_accuracy']:
                    if current_value < threshold:
                        return Alert(
                            id=alert_id,
                            severity=AlertSeverity.ERROR if current_value < threshold * 0.8 else AlertSeverity.WARNING,
                            title=f"Low {metric_name} detected",
                            message=f"{metric_name} is {current_value:.3f}, below threshold {threshold:.3f}",
                            metric_name=metric_name,
                            current_value=current_value,
                            threshold_value=threshold,
                            triggered_at=datetime.now()
                        )
            
            return None
            
        except Exception as e:
            self.logger.error(f"Threshold alert check failed: {e}")
            return None
    
    async def _identify_calibration_opportunities(
        self, 
        health_analysis: Dict[str, Any]
    ) -> List[CalibrationResult]:
        """Identify components that need calibration"""
        try:
            opportunities = []
            
            health_trends = health_analysis.get('health_trends', {})
            
            for metric_name, trend_data in health_trends.items():
                if not isinstance(trend_data, dict):
                    continue
                
                health_score = trend_data.get('health_score', 1.0)
                
                # Determine if calibration is needed
                if health_score < 0.7:  # Health score below 70%
                    component = self._get_component_for_metric(metric_name)
                    
                    calibration = CalibrationResult(
                        id=f"cal_{component}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                        status=CalibrationStatus.IDLE,
                        start_time=datetime.now(),
                        calibrated_components=[component],
                        calibration_data={
                            'trigger_metric': metric_name,
                            'current_health_score': health_score,
                            'target_health_score': 0.8,
                            'calibration_aggressiveness': self._calculate_calibration_aggressiveness(health_score)
                        }
                    )
                    
                    opportunities.append(calibration)
            
            # Add systematic calibration if system health is low
            overall_health = health_analysis.get('overall_health_score', 1.0)
            if overall_health < 0.6:
                systematic_calibration = CalibrationResult(
                    id=f"systematic_cal_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                    status=CalibrationStatus.IDLE,
                    start_time=datetime.now(),
                    calibrated_components=list(self.component_health.keys()),
                    calibration_data={
                        'trigger': 'systematic_health_check',
                        'overall_health_score': overall_health,
                        'calibration_type': 'systematic_tuning'
                    }
                )
                opportunities.append(systematic_calibration)
            
            self.logger.info(f"Identified {len(opportunities)} calibration opportunities")
            
            return opportunities
            
        except Exception as e:
            self.logger.error(f"Calibration opportunity identification failed: {e}")
            return []
    
    def _get_component_for_metric(self, metric_name: str) -> str:
        """Get component name responsible for a metric"""
        metric_component_mapping = {
            'response_time': 'model_engine',
            'throughput': 'model_engine',
            'accuracy': 'model_engine',
            'model_accuracy': 'model_engine',
            'prediction_latency': 'model_engine',
            'error_rate': 'data_processor',
            'cpu_usage': 'system_architecture',
            'memory_usage': 'system_architecture',
            'disk_usage': 'system_architecture',
            'network_latency': 'network_infrastructure',
            'sharpe_ratio': 'trading_strategy',
            'drawdown': 'risk_management',
        }
        
        return metric_component_mapping.get(metric_name, 'unknown_component')
    
    def _calculate_calibration_aggressiveness(self, health_score: float) -> float:
        """Calculate calibration aggressiveness based on health score"""
        try:
            # Lower health score = more aggressive calibration
            aggressiveness = (1.0 - health_score) * self.self_calibration['calibration_aggressiveness']
            return max(0.1, min(1.0, aggressiveness))
        except Exception as e:
            self.logger.error(f"Calibration aggressiveness calculation failed: {e}")
            return 0.5
    
    async def _execute_calibrations(
        self, 
        opportunities: List[CalibrationResult]
    ) -> List[CalibrationResult]:
        """Execute calibration opportunities"""
        try:
            results = []
            
            for calibration in opportunities[:3]:  # Limit concurrent calibrations
                try:
                    # Execute calibration
                    result = await self._execute_single_calibration(calibration)
                    results.append(result)
                    
                    # Update metrics
                    self.monitoring_metrics['calibrations_performed'] += 1
                    
                except Exception as e:
                    self.logger.error(f"Calibration execution failed for {calibration.id}: {e}")
                    calibration.status = CalibrationStatus.FAILED
                    calibration.error_message = str(e)
                    results.append(calibration)
            
            return results
            
        except Exception as e:
            self.logger.error(f"Calibration execution failed: {e}")
            return []
    
    async def _execute_single_calibration(
        self, 
        calibration: CalibrationResult
    ) -> CalibrationResult:
        """Execute a single calibration"""
        try:
            self.logger.info(f"Executing calibration: {calibration.id}")
            
            calibration.status = CalibrationStatus.CALIBRATING
            
            components = calibration.calibrated_components
            aggressiveness = calibration.calibration_data.get('calibration_aggressiveness', 0.5)
            
            calibration_data = {}
            performance_impact = {}
            
            for component in components:
                # Simulate calibration process
                await asyncio.sleep(1.0)  # Calibration time
                
                # Simulate calibration results
                import random
                random.seed(hash(component) % 1000)
                
                # Calibration effectiveness based on aggressiveness
                effectiveness = aggressiveness * random.uniform(0.7, 1.0)
                
                # Simulate performance improvement
                improvement = {
                    'response_time': random.uniform(-0.1, -0.3) * effectiveness,  # Reduce
                    'accuracy': random.uniform(0.05, 0.15) * effectiveness,     # Improve
                    'resource_usage': random.uniform(-0.1, -0.2) * effectiveness,  # Reduce
                    'stability': random.uniform(0.1, 0.2) * effectiveness      # Improve
                }
                
                calibration_data[component] = {
                    'calibration_method': 'adaptive_tuning',
                    'aggressiveness': aggressiveness,
                    'effectiveness': effectiveness,
                    'parameters_adjusted': random.randint(3, 10)
                }
                
                performance_impact[component] = improvement
                
                # Update component health
                self.component_health[component]['status'] = 'calibrated'
                self.component_health[component]['last_check'] = datetime.now()
            
            # Update calibration result
            calibration.calibration_data = calibration_data
            calibration.performance_impact = performance_impact
            calibration.status = CalibrationStatus.COMPLETED
            calibration.end_time = datetime.now()
            
            self.logger.info(f"Calibration completed: {calibration.id}")
            
            return calibration
            
        except Exception as e:
            self.logger.error(f"Single calibration execution failed: {e}")
            calibration.status = CalibrationStatus.FAILED
            calibration.error_message = str(e)
            calibration.end_time = datetime.now()
            return calibration
    
    async def _update_monitoring_metrics(
        self, 
        calibration_results: List[CalibrationResult]
    ) -> None:
        """Update monitoring metrics with calibration results"""
        try:
            if calibration_results:
                calibration_times = [
                    (result.end_time - result.start_time).total_seconds()
                    for result in calibration_results 
                    if result.end_time
                ]
                
                if calibration_times:
                    avg_cal_time = np.mean(calibration_times)
                    self.monitoring_metrics['average_calibration_time'] = avg_cal_time
            
            # Update alert count
            self.monitoring_metrics['alerts_triggered'] = len(self.active_alerts)
            
            # Calculate success rate
            successful_calibrations = [
                r for r in calibration_results 
                if r.status == CalibrationStatus.COMPLETED
            ]
            
            if calibration_results:
                success_rate = len(successful_calibrations) / len(calibration_results)
                # Update average success rate (exponential moving average)
                current_rate = self.monitoring_metrics.get('calibration_success_rate', 0.8)
                self.monitoring_metrics['calibration_success_rate'] = (
                    0.9 * current_rate + 0.1 * success_rate
                )
            
            self.logger.debug("Monitoring metrics updated")
            
        except Exception as e:
            self.logger.error(f"Monitoring metrics update failed: {e}")
    
    async def _metric_collection_loop(self) -> None:
        """Background loop for continuous metric collection"""
        while True:
            try:
                await self._collect_system_metrics()
                await asyncio.sleep(self.monitoring_config['collection_interval'])
                
            except Exception as e:
                self.logger.error(f"Metric collection loop error: {e}")
                await asyncio.sleep(5)
    
    async def _alert_processing_loop(self) -> None:
        """Background loop for alert processing"""
        while True:
            try:
                # Process active alerts
                current_time = datetime.now()
                
                for alert_id, alert in list(self.active_alerts.items()):
                    # Check if alert should be resolved
                    if not alert.acknowledged:
                        # Check if metric has returned to normal range
                        metric_history = self.metric_history.get(alert.metric_name, [])
                        if metric_history:
                            recent_values = [point.value for point in list(metric_history)[-5:]]
                            avg_recent = np.mean(recent_values)
                            
                            # Simple resolution logic
                            if alert.severity == AlertSeverity.WARNING:
                                if avg_recent < alert.threshold_value * 0.8:
                                    alert.resolved_at = current_time
                            elif alert.severity == AlertSeverity.ERROR:
                                if avg_recent < alert.threshold_value * 0.5:
                                    alert.resolved_at = current_time
                            elif alert.severity == AlertSeverity.CRITICAL:
                                if avg_recent < alert.threshold_value * 0.3:
                                    alert.resolved_at = current_time
                    
                    # Clean up old resolved alerts
                    if alert.resolved_at:
                        alert_age = (current_time - alert.resolved_at).total_seconds()
                        if alert_age > 3600:  # Keep resolved alerts for 1 hour
                            del self.active_alerts[alert_id]
                
                await asyncio.sleep(30)  # Check every 30 seconds
                
            except Exception as e:
                self.logger.error(f"Alert processing loop error: {e}")
                await asyncio.sleep(5)
    
    async def _self_calibration_loop(self) -> None:
        """Background loop for automatic self-calibration"""
        while True:
            try:
                # Check if calibration should be triggered
                current_health = self.monitoring_metrics.get('system_health_score', 1.0)
                
                if current_health < 0.7 or self._should_trigger_periodic_calibration():
                    self.logger.info("Triggering automatic calibration")
                    
                    # Create calibration opportunity
                    calibration = CalibrationResult(
                        id=f"auto_cal_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}",
                        status=CalibrationStatus.IDLE,
                        start_time=datetime.now(),
                        calibrated_components=list(self.component_health.keys()),
                        calibration_data={
                            'trigger': 'automatic_health_check',
                            'system_health_score': current_health,
                            'calibration_type': 'proactive_tuning'
                        }
                    )
                    
                    # Execute calibration
                    result = await self._execute_single_calibration(calibration)
                    
                    self.logger.info(f"Automatic calibration completed: {result.status.value}")
                
                # Wait for next calibration cycle
                await asyncio.sleep(self.self_calibration['calibration_frequency'])
                
            except Exception as e:
                self.logger.error(f"Self-calibration loop error: {e}")
                await asyncio.sleep(300)  # Wait 5 minutes before retry
    
    def _should_trigger_periodic_calibration(self) -> bool:
        """Check if periodic calibration should be triggered"""
        try:
            # Trigger calibration every calibration_frequency seconds
            # For simplicity, use random trigger with low probability
            import random
            return random.random() < 0.1  # 10% chance per check
            
        except Exception as e:
            self.logger.error(f"Periodic calibration check failed: {e}")
            return False
    
    async def _health_check_loop(self) -> None:
        """Background loop for component health checks"""
        while True:
            try:
                # Check each component's health
                for component_name, component_info in self.component_health.items():
                    try:
                        health_status = await self._check_component_health(component_name)
                        component_info['status'] = health_status['status']
                        component_info['last_check'] = datetime.now()
                        component_info.update(health_status)
                    except Exception as e:
                        self.logger.error(f"Health check failed for {component_name}: {e}")
                        component_info['status'] = 'error'
                        component_info['last_check'] = datetime.now()
                
                await asyncio.sleep(60)  # Check every minute
                
            except Exception as e:
                self.logger.error(f"Health check loop error: {e}")
                await asyncio.sleep(10)
    
    async def _check_component_health(self, component_name: str) -> Dict[str, Any]:
        """Check health of a specific component"""
        try:
            # Simulate component health check
            import random
            random.seed(hash(component_name) % 1000)
            
            health_score = random.uniform(0.7, 1.0)
            response_time = random.uniform(50, 200)
            error_rate = random.uniform(0, 0.02)
            
            if health_score > 0.9:
                status = 'healthy'
            elif health_score > 0.8:
                status = 'warning'
            elif health_score > 0.6:
                status = 'degraded'
            else:
                status = 'critical'
            
            return {
                'status': status,
                'health_score': health_score,
                'response_time': response_time,
                'error_rate': error_rate,
                'last_check': datetime.now()
            }
            
        except Exception as e:
            self.logger.error(f"Component health check failed for {component_name}: {e}")
            return {'status': 'error', 'health_score': 0.0}
    
    async def get_state(self) -> Dict[str, Any]:
        """Get current monitoring state"""
        return {
            'monitoring_metrics': self.monitoring_metrics,
            'component_health': self.component_health,
            'active_alerts': len(self.active_alerts),
            'metric_buffers': {name: len(buffer) for name, buffer in self.metric_history.items()},
            'active_calibrations': len(self.active_calibrations),
            'system_health_score': self.monitoring_metrics.get('system_health_score', 1.0)
        }
    
    def get_active_alerts(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get active alerts"""
        alerts = sorted(
            self.active_alerts.values(),
            key=lambda x: x.triggered_at,
            reverse=True
        )
        
        return [
            {
                'id': alert.id,
                'severity': alert.severity.value,
                'title': alert.title,
                'message': alert.message,
                'metric_name': alert.metric_name,
                'current_value': alert.current_value,
                'triggered_at': alert.triggered_at.isoformat(),
                'acknowledged': alert.acknowledged,
                'resolved_at': alert.resolved_at.isoformat() if alert.resolved_at else None
            }
            for alert in alerts[:limit]
        ]
    
    def get_metric_history(self, metric_name: str, hours: int = 1) -> List[Dict[str, Any]]:
        """Get metric history for a specific metric"""
        try:
            if metric_name not in self.metric_history:
                return []
            
            # Filter by time window
            cutoff_time = datetime.now() - timedelta(hours=hours)
            filtered_history = [
                point for point in self.metric_history[metric_name]
                if point.timestamp >= cutoff_time
            ]
            
            return [
                {
                    'timestamp': point.timestamp.isoformat(),
                    'value': point.value,
                    'type': point.metric_type.value,
                    'unit': point.unit
                }
                for point in filtered_history
            ]
            
        except Exception as e:
            self.logger.error(f"Metric history retrieval failed for {metric_name}: {e}")
            return []
