#!/usr/bin/env python3
"""
Bitwisers 2.0 ML Pipeline Test Script
Sistem entegrasyonu ve temel fonksiyonalite testi
"""

import sys
import os
import asyncio
import logging
from pathlib import Path

# Add project root to Python path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from ml_pipeline.utils.logging_utils import get_logger
from ml_pipeline.config.pipeline_config import pipeline_config
from ml_pipeline.data.ingestion import DataIngestionEngine
from ml_pipeline.data.feature_engineering import FeatureEngineeringEngine
from ml_pipeline.models.training import ModelTrainer
from ml_pipeline.api.inference import ModelInferenceEngine
from ml_pipeline.monitoring.drift_detection import MonitoringSystem
from ml_pipeline.testing.ab_testing import ABTestAutomation

logger = get_logger(__name__)

class PipelineTester:
    """Pipeline test coordinator"""
    
    def __init__(self):
        self.test_results = {}
        
    async def run_all_tests(self):
        """Tüm testleri çalıştır"""
        logger.info("🚀 ML Pipeline Test Suite başlatılıyor...")
        
        tests = [
            ("Configuration Test", self.test_configuration),
            ("Database Connection Test", self.test_database_connection),
            ("Data Ingestion Test", self.test_data_ingestion),
            ("Feature Engineering Test", self.test_feature_engineering),
            ("Model Training Test", self.test_model_training),
            ("Inference Engine Test", self.test_inference_engine),
            ("Monitoring System Test", self.test_monitoring),
            ("A/B Testing Test", self.test_ab_testing),
            ("Integration Test", self.test_integration)
        ]
        
        passed = 0
        failed = 0
        
        for test_name, test_func in tests:
            try:
                logger.info(f"🧪 {test_name} başlatılıyor...")
                await test_func()
                self.test_results[test_name] = "PASSED"
                passed += 1
                logger.info(f"✅ {test_name}: PASSED")
                
            except Exception as e:
                self.test_results[test_name] = f"FAILED: {str(e)}"
                failed += 1
                logger.error(f"❌ {test_name}: FAILED - {str(e)}")
        
        # Test summary
        logger.info(f"\n📊 Test Summary:")
        logger.info(f"  ✅ Passed: {passed}")
        logger.info(f"  ❌ Failed: {failed}")
        logger.info(f"  📈 Success Rate: {(passed/(passed+failed))*100:.1f}%")
        
        # Detailed results
        logger.info(f"\n📋 Detailed Results:")
        for test_name, result in self.test_results.items():
            status = "✅ PASSED" if result == "PASSED" else f"❌ {result}"
            logger.info(f"  {test_name}: {status}")
        
        return failed == 0
    
    async def test_configuration(self):
        """Konfigürasyon testi"""
        assert pipeline_config is not None
        assert pipeline_config.model is not None
        assert pipeline_config.features is not None
        assert pipeline_config.training is not None
        
        # Basic configuration checks
        assert pipeline_config.model.sequence_length > 0
        assert pipeline_config.model.prediction_horizon > 0
        assert len(pipeline_config.model.model_types) > 0
        
        logger.debug("Configuration test completed")
    
    async def test_database_connection(self):
        """Veritabanı bağlantı testi"""
        try:
            from sqlalchemy import create_engine
            
            # Test database connection
            database_url = pipeline_config.get_database_url()
            engine = create_engine(database_url)
            
            with engine.connect() as conn:
                result = conn.execute("SELECT 1")
                assert result.fetchone()[0] == 1
            
            logger.debug("Database connection test completed")
            
        except Exception as e:
            logger.warning(f"Database connection test warning: {e}")
            # Database might not be available, but that's okay for basic testing
    
    async def test_data_ingestion(self):
        """Veri ingestion testi"""
        # Test data ingestion engine initialization
        ingestion_engine = DataIngestionEngine()
        
        # Test market data structure (without actual API calls)
        mock_data = {
            'timestamp': [1640995200000, 1640995260000, 1640995320000],
            'open': [45000.0, 45050.0, 45025.0],
            'high': [45080.0, 45100.0, 45050.0],
            'low': [44950.0, 45000.0, 44980.0],
            'close': [45025.0, 45010.0, 45035.0],
            'volume': [100.5, 120.3, 95.8]
        }
        
        import pandas as pd
        df = pd.DataFrame(mock_data)
        
        # Test data validation
        assert not df.empty
        assert len(df.columns) >= 6  # Basic OHLCV columns
        
        logger.debug("Data ingestion test completed")
    
    async def test_feature_engineering(self):
        """Feature engineering testi"""
        # Test feature engineering engine
        feature_engine = FeatureEngineeringEngine()
        
        # Test technical indicators
        from ml_pipeline.data.feature_engineering import TechnicalIndicators
        
        import pandas as pd
        import numpy as np
        
        # Create sample data
        dates = pd.date_range('2024-01-01', periods=100, freq='1H')
        sample_data = pd.DataFrame({
            'timestamp': dates,
            'open': np.random.normal(45000, 100, 100),
            'high': np.random.normal(45100, 100, 100),
            'low': np.random.normal(44900, 100, 100),
            'close': np.random.normal(45000, 100, 100),
            'volume': np.random.normal(1000, 200, 100)
        })
        
        # Test SMA calculation
        sma_14 = TechnicalIndicators.sma(sample_data['close'], 14)
        assert len(sma_14) == len(sample_data)
        assert not sma_14.isna().all()
        
        # Test RSI calculation
        rsi_14 = TechnicalIndicators.rsi(sample_data['close'], 14)
        assert len(rsi_14) == len(sample_data)
        
        logger.debug("Feature engineering test completed")
    
    async def test_model_training(self):
        """Model training testi"""
        # Test model trainer
        trainer = ModelTrainer()
        
        # Create mock training data
        import numpy as np
        
        X = np.random.normal(0, 1, (100, 60, 20))  # sequences, timesteps, features
        y = np.random.normal(0, 1, 100)  # targets
        
        # Test model types
        model_types = ['lstm', 'random_forest']
        
        for model_type in model_types[:1]:  # Test only one to save time
            try:
                # Test data preprocessing
                from ml_pipeline.models.training import DataPreprocessor
                
                preprocessor = DataPreprocessor()
                X_processed, y_processed = preprocessor.prepare_sequences(
                    pd.DataFrame(X.reshape(-1, X.shape[-1])),  # Mock DataFrame
                    target_column='close'
                )
                
                logger.debug(f"Model training test completed for {model_type}")
                
            except Exception as e:
                logger.warning(f"Model training test warning for {model_type}: {e}")
        
        logger.debug("Model training test completed")
    
    async def test_inference_engine(self):
        """Inference engine testi"""
        # Test inference engine initialization
        inference_engine = ModelInferenceEngine()
        
        # Test model status
        try:
            status = inference_engine.get_model_status()
            assert isinstance(status, dict)
            assert 'loaded_models' in status
            
            logger.debug("Inference engine test completed")
            
        except Exception as e:
            logger.warning(f"Inference engine test warning: {e}")
    
    async def test_monitoring(self):
        """Monitoring system testi"""
        # Test monitoring system
        monitoring = MonitoringSystem()
        
        # Test drift detector
        from ml_pipeline.monitoring.drift_detection import DataDriftDetector
        
        detector = DataDriftDetector()
        
        # Create baseline data
        baseline = np.random.normal(50, 15, 1000)
        current = np.random.normal(55, 18, 1000)  # Different distribution
        
        # Test drift detection
        detector.update_baseline('test_feature', baseline)
        drift_result = detector.detect_drift('test_feature', current)
        
        assert 'drift_detected' in drift_result
        assert 'tests' in drift_result
        
        logger.debug("Monitoring test completed")
    
    async def test_ab_testing(self):
        """A/B testing testi"""
        # Test A/B testing framework
        ab_engine = ABTestAutomation()
        
        # Test statistical tests
        from ml_pipeline.testing.ab_testing import StatisticalTests
        
        # Create test data
        group_a = np.random.normal(0, 1, 100)
        group_b = np.random.normal(0.1, 1, 100)
        
        # Test t-test
        t_test_result = StatisticalTests.t_test(group_a, group_b)
        assert 'p_value' in t_test_result
        assert 'significant' in t_test_result
        
        logger.debug("A/B testing test completed")
    
    async def test_integration(self):
        """Entegrasyon testi"""
        # Test that all components can work together
        
        # 1. Configuration integration
        assert pipeline_config is not None
        
        # 2. Module imports
        modules = [
            'ml_pipeline.config.pipeline_config',
            'ml_pipeline.data.ingestion',
            'ml_pipeline.data.feature_engineering',
            'ml_pipeline.models.training',
            'ml_pipeline.api.inference',
            'ml_pipeline.monitoring.drift_detection',
            'ml_pipeline.testing.ab_testing',
            'ml_pipeline.utils.logging_utils',
            'ml_pipeline.utils.orchestrator'
        ]
        
        for module in modules:
            try:
                __import__(module)
            except ImportError as e:
                raise AssertionError(f"Failed to import {module}: {e}")
        
        logger.debug("Integration test completed")

async def main():
    """Ana test fonksiyonu"""
    # Test setup
    logger.info("🧪 Bitwisers 2.0 ML Pipeline Test Suite")
    logger.info("=" * 50)
    
    # Run tests
    tester = PipelineTester()
    success = await tester.run_all_tests()
    
    # Exit
    if success:
        logger.info("🎉 Tüm testler başarıyla tamamlandı!")
        sys.exit(0)
    else:
        logger.error("💥 Bazı testler başarısız oldu!")
        sys.exit(1)

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("⏹️ Test interrupted by user")
        sys.exit(0)
    except Exception as e:
        logger.error(f"💥 Test suite error: {e}")
        sys.exit(1)