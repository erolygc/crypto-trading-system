#!/bin/bash

# Bitwisers 2.0 ML Pipeline Runner Script

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_color() {
    echo -e "${1}${2}${NC}"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to install dependencies
install_dependencies() {
    print_color $BLUE "📦 Installing dependencies..."
    
    if [ -f "requirements.txt" ]; then
        pip install -r requirements.txt
        print_color $GREEN "✅ Dependencies installed successfully"
    else
        print_color $YELLOW "⚠️ requirements.txt not found"
    fi
}

# Function to setup environment
setup_environment() {
    print_color $BLUE "🔧 Setting up environment..."
    
    # Create directories
    mkdir -p logs
    mkdir -p data/{raw,processed,features}
    mkdir -p models/{trained,candidates,archived}
    mkdir -p config
    
    print_color $GREEN "✅ Environment setup completed"
}

# Function to initialize database
init_database() {
    print_color $BLUE "🗃️ Initializing database..."
    
    python -m ml_pipeline.cli init-db
    print_color $GREEN "✅ Database initialized"
}

# Function to check system health
check_health() {
    print_color $BLUE "🔍 Checking system health..."
    
    python -m ml_pipeline.cli health
    print_color $GREEN "✅ Health check completed"
}

# Function to start pipeline
start_pipeline() {
    print_color $BLUE "🚀 Starting ML Pipeline..."
    
    python -m ml_pipeline.cli start
}

# Function to start API server
start_api() {
    print_color $BLUE "🌐 Starting API Server..."
    
    python -m ml_pipeline.cli serve --port ${1:-8000}
}

# Function to train models
train_models() {
    print_color $BLUE "🤖 Training models..."
    
    python -m ml_pipeline.cli train $1
    print_color $GREEN "✅ Training completed"
}

# Function to show status
show_status() {
    print_color $BLUE "📊 Pipeline Status:"
    python -m ml_pipeline.cli status
}

# Main script logic
main() {
    case "$1" in
        "install")
            install_dependencies
            ;;
        "setup")
            install_dependencies
            setup_environment
            ;;
        "init")
            init_database
            ;;
        "health")
            check_health
            ;;
        "start")
            start_pipeline
            ;;
        "api")
            start_api $2
            ;;
        "train")
            train_models $2
            ;;
        "status")
            show_status
            ;;
        "dev")
            # Development mode
            install_dependencies
            setup_environment
            init_database
            check_health
            print_color $GREEN "✅ Development environment ready"
            ;;
        "prod")
            # Production mode
            setup_environment
            check_health
            start_pipeline
            ;;
        *)
            echo "Bitwisers 2.0 ML Pipeline Runner"
            echo ""
            echo "Usage: $0 [COMMAND] [OPTIONS]"
            echo ""
            echo "Commands:"
            echo "  install         Install dependencies"
            echo "  setup           Full setup (install + environment)"
            echo "  init            Initialize database"
            echo "  health          Check system health"
            echo "  start           Start the ML pipeline"
            echo "  api [PORT]      Start API server (default: 8000)"
            echo "  train [MODEL]   Train models (optional: specific model type)"
            echo "  status          Show pipeline status"
            echo "  dev             Setup development environment"
            echo "  prod            Setup and start production"
            echo ""
            echo "Examples:"
            echo "  $0 dev                    # Development setup"
            echo "  $0 prod                   # Production setup"
            echo "  $0 api 8000               # Start API on port 8000"
            echo "  $0 train lstm             # Train LSTM model"
            exit 1
            ;;
    esac
}

# Run main function with all arguments
main "$@"