# Bitwisers 2.0 ML Pipeline

> **Kapsamlı Machine Learning Pipeline for Real-time Trading**

Bitwisers 2.0 ML Pipeline, DVK engine, Genetic engine ve Signal Scoring sistemlerini birleştiren modern bir MLOps platformudur.

## 🚀 Özellikler

### Core Features
- **📊 Real-time Data Ingestion**: Kafka ile market verilerini TimescaleDB'ye aktarım
- **🧠 Automated Feature Engineering**: 20+ technical indicator ile feature oluşturma
- **🤖 Multi-Model Training**: LSTM, Transformer, XGBoost desteği
- **📈 MLflow Integration**: Model versioning ve experiment tracking
- **⚡ Optuna Hyperparameter Tuning**: Otomatik hyperparameter optimizasyonu
- **🌐 FastAPI Inference**: Low-latency prediction API
- **👁️ Model Monitoring**: Drift detection ve performance monitoring
- **🧪 A/B Testing Framework**: Statistical significance testing

### System Architecture
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Data Sources  │    │   ML Pipeline   │    │   Applications  │
│                 │    │                 │    │                 │
│ • Binance API   │───▶│ • Ingestion     │───▶│ • Trading Bot   │
│ • YFinance      │    │ • Feature Eng   │    │ • Dashboard     │
│ • Real-time     │    │ • Training      │    │ • Alert System  │
└─────────────────┘    │ • Monitoring    │    └─────────────────┘
                       │ • A/B Testing   │
                       └─────────────────┘
                              │
                       ┌─────────────────┐
                       │ Infrastructure  │
                       │                 │
                       │ • TimescaleDB   │
                       │ • Kafka         │
                       │ • Redis         │
                       │ • MLflow        │
                       └─────────────────┘
```

## 🛠️ Hızlı Başlangıç

### 1. Otomatik Kurulum
```bash
git clone <repository-url>
cd bitwisers-ml-pipeline
chmod +x setup.sh
./setup.sh quick
```

### 2. Manuel Kurulum
```bash
# Dependencies
pip install -r requirements.txt

# Environment
cp .env.example .env
# Edit .env with your configurations

# Database
python -m ml_pipeline.cli init-db

# Pipeline başlat
python -m ml_pipeline.cli start
```

### 3. Docker ile Kurulum
```bash
# Tüm servisleri başlat
docker-compose up -d

# Pipeline kontrol
docker-compose logs -f ml-pipeline-api
```

## 📖 Kullanım

### CLI Komutları

#### Pipeline Yönetimi
```bash
# Pipeline'ı başlat
python -m ml_pipeline.cli start

# Durum kontrolü
python -m ml_pipeline.cli status

# Pipeline'ı durdur
python -m ml_pipeline.cli stop
```

#### Model Training
```bash
# Tüm modelleri train et
python -m ml_pipeline.cli train

# Specific model
python -m ml_pipeline.cli train --model-type lstm
```

#### A/B Testing
```bash
# A/B test oluştur
python -m ml_pipeline.cli create-ab-test \
    --model-a lstm_v1 \
    --model-b transformer_v1
```

#### API Server
```bash
# API server başlat
python -m ml_pipeline.cli serve --port 8000
```

#### Prediction
```bash
# Single prediction
python -m ml_pipeline.cli predict --symbol BTCUSDT

# Batch prediction
python -m ml_pipeline.cli predict --symbols BTCUSDT,ETHUSDT
```

### Python Integration

```python
from ml_pipeline import ml_pipeline, pipeline_config

# Pipeline başlat
await ml_pipeline.initialize()
await ml_pipeline.start_pipeline()

# Prediction yap
from ml_pipeline.api.inference import inference_engine
result = await inference_engine.make_prediction('BTCUSDT', '1h')
print(f"Prediction: {result['prediction']}")
```

## 🌐 API Dokümantasyonu

### Base URL
```
http://localhost:8000
```

### Endpoints

#### Health Check
```http
GET /health
```
Response:
```json
{
  "status": "ok",
  "timestamp": "2024-01-01T12:00:00Z",
  "models_loaded": 3
}
```

#### Single Prediction
```http
POST /predict
Content-Type: application/json

{
  "symbol": "BTCUSDT",
  "timeframe": "1h",
  "return_raw_prediction": false
}
```

#### Batch Prediction
```http
POST /predict/batch
Content-Type: application/json

{
  "symbols": ["BTCUSDT", "ETHUSDT", "ADAUSDT"],
  "timeframe": "1h"
}
```

#### Model Status
```http
GET /models
```
Response:
```json
{
  "loaded_models": ["lstm_v1", "transformer_v1", "xgboost_v1"],
  "timestamp": "2024-01-01T12:00:00Z"
}
```

### API Test

```bash
# Health check
curl http://localhost:8000/health

# Prediction
curl -X POST http://localhost:8000/predict \
  -H "Content-Type: application/json" \
  -d '{"symbol": "BTCUSDT", "timeframe": "1h"}'
```

## 📊 Monitoring

### Model Performance Metrics
- **MSE**: Mean Squared Error
- **MAE**: Mean Absolute Error
- **RMSE**: Root Mean Squared Error
- **MAPE**: Mean Absolute Percentage Error
- **R²**: R-squared (coefficient of determination)
- **Directional Accuracy**: Doğru yön tahmin oranı

### Monitoring Dashboard

#### MLflow
- Experiment tracking
- Model versioning
- Parameter optimization
- Performance metrics

**URL**: http://localhost:5000

#### Grafana
- Real-time dashboards
- Performance visualization
- Alert management

**URL**: http://localhost:3000 (admin/admin)

#### Prometheus
- Metrics collection
- System monitoring
- Performance alerts

**URL**: http://localhost:9090

### Data Drift Detection

Pipeline otomatik olarak data drift'i izler:

```python
# Drift results
drift_results = await monitoring_system.performance_monitor.monitor_data_drift(
    features_data={'rsi_14': current_rsi, 'macd': current_macd},
    symbol='BTCUSDT',
    timeframe='1h'
)

for feature, result in drift_results.items():
    if result['drift_detected']:
        print(f"Drift detected in {feature}")
```

## 🧪 A/B Testing

### Test Framework

Otomatik A/B testing ile model karşılaştırması:

```python
# A/B test oluştur
test_id = await ml_pipeline.create_ab_test(
    model_a="lstm_v1",
    model_b="transformer_v1",
    test_name="LSTM_vs_Transformer_2024"
)

# Test progress
progress = await ab_testing_engine.monitor_test_progress(test_id)

# Test sonuçları
analysis = ab_testing_engine.analyze_test(test_id)
print(f"Conclusion: {analysis['conclusion']}")
```

### Statistical Analysis

- **T-Test**: Continuous metrics
- **Mann-Whitney U**: Non-parametric test
- **Chi-Square**: Binary metrics
- **Power Analysis**: Sample size calculation

### Traffic Allocation

Otomatik traffic splitting ile model karşılaştırması:

```python
traffic_split = {
    'model_a': 0.5,  # 50% traffic
    'model_b': 0.5   # 50% traffic
}
```

## 📈 Feature Engineering

### Technical Indicators

#### Moving Averages
```python
# Simple Moving Average
sma_7 = sma(data, window=7)
sma_14 = sma(data, window=14)
sma_21 = sma(data, window=21)

# Exponential Moving Average
ema_12 = ema(data, window=12)
ema_26 = ema(data, window=26)
```

#### Momentum Indicators
```python
# RSI
rsi_14 = rsi(data, window=14)
rsi_21 = rsi(data, window=21)

# MACD
macd_data = macd(data, fast=12, slow=26, signal=9)
macd_line = macd_data['macd']
signal_line = macd_data['signal']
histogram = macd_data['histogram']
```

#### Volatility Indicators
```python
# Bollinger Bands
bb_data = bollinger_bands(data, window=20, num_std=2)
upper_band = bb_data['upper']
middle_band = bb_data['middle']
lower_band = bb_data['lower']

# Average True Range
atr_14 = atr(high, low, close, window=14)
```

#### Volume Indicators
```python
# On-Balance Volume
obv_value = obv(close, volume)

# Volume Weighted Average Price
vwap_deviation = (close - vwap) / vwap
```

### Custom Features

```python
class CustomFeatures:
    def fibonacci_retracement(self, high, low):
        # Custom Fibonacci retracement calculation
        return fib_levels
    
    def market_structure(self, ohlc_data):
        # Custom market structure analysis
        return structure_levels
```

## 🔧 Konfigürasyon

### Pipeline Config

`config/pipeline_config.py` dosyasında tüm ayarlar:

```python
# Model Configuration
@dataclass
class ModelConfig:
    model_types: List[str] = field(default_factory=lambda: [
        "lstm", "transformer", "xgboost", "random_forest"
    ])
    default_model: str = "lstm"
    sequence_length: int = 60
    prediction_horizon: int = 24  # hours
    retrain_interval: int = 24    # hours

# Feature Configuration
@dataclass
class FeatureConfig:
    technical_indicators: List[str] = field(default_factory=lambda: [
        "sma", "ema", "rsi", "macd", "bollinger", 
        "stoch", "atr", "obv", "vwap"
    ])
    lookback_periods: List[int] = field(default_factory=lambda: [
        7, 14, 21, 30, 50, 100
    ])
    timeframes: List[str] = field(default_factory=lambda: [
        "1m", "5m", "15m", "1h", "4h", "1d"
    ])

# Training Configuration
@dataclass
class TrainingConfig:
    batch_size: int = 32
    learning_rate: float = 0.001
    epochs: int = 100
    validation_split: float = 0.2
    early_stopping_patience: int = 10
    hyperparameter_tuning_trials: int = 100
    cross_validation_folds: int = 5
```

### Environment Variables

`.env` dosyasında:

```bash
# Database
DB_HOST=localhost
DB_PORT=5432
DB_DATABASE=bitwisers
DB_USER=postgres
DB_PASSWORD=your_password

# Kafka
KAFKA_BOOTSTRAP_SERVERS=localhost:9092
KAFKA_DATA_TOPIC=market-data
KAFKA_PREDICTION_TOPIC=ml-predictions

# MLflow
MLFLOW_TRACKING_URI=http://localhost:5000
MLFLOW_REGISTRY_URI=http://localhost:5000

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0

# Logging
LOG_LEVEL=INFO
LOG_FILE=logs/bitwisers_ml.log

# API
API_HOST=0.0.0.0
API_PORT=8000
API_WORKERS=4
```

## 🔒 Güvenlik

### API Security
```python
# API authentication (future)
from fastapi.security import HTTPBearer

security = HTTPBearer()

@app.middleware("http")
async def authenticate_user(request: Request, call_next):
    # Authentication logic
    pass
```

### Database Security
```sql
-- Database role creation
CREATE ROLE bitwisers_app WITH LOGIN PASSWORD 'secure_password';
GRANT CONNECT ON DATABASE bitwisers TO bitwisers_app;
GRANT USAGE ON SCHEMA public TO bitwisers_app;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA public TO bitwisers_app;
```

## 📦 Deployment

### Docker Production
```bash
# Production deployment
docker-compose -f docker-compose.prod.yml up -d

# With custom environment
docker-compose -f docker-compose.yml up --env-file .env.production -d
```

### Kubernetes (Future)
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: bitwisers-ml-pipeline
spec:
  replicas: 3
  selector:
    matchLabels:
      app: ml-pipeline
  template:
    metadata:
      labels:
        app: ml-pipeline
    spec:
      containers:
      - name: ml-pipeline
        image: bitwisers/ml-pipeline:latest
        ports:
        - containerPort: 8000
        env:
        - name: MLFLOW_TRACKING_URI
          value: "http://mlflow:5000"
```

## 🧪 Testing

### Unit Tests
```bash
# Run all tests
pytest tests/ -v

# Run specific test
pytest tests/test_feature_engineering.py -v

# Run with coverage
pytest tests/ --cov=ml_pipeline --cov-report=html
```

### Integration Tests
```bash
# Full pipeline test
pytest tests/integration/test_full_pipeline.py -v

# API test
pytest tests/api/test_inference.py -v

# Database test
pytest tests/db/test_ingestion.py -v
```

## 🛠️ Development

### Local Development Setup
```bash
# Clone repository
git clone <repository-url>
cd bitwisers-ml-pipeline

# Setup development environment
./setup.sh quick

# Install development dependencies
pip install -r requirements-dev.txt

# Code formatting
black .
isort .

# Linting
flake8 .

# Type checking
mypy ml_pipeline/
```

### Code Structure
```
ml_pipeline/
├── __init__.py              # Main module
├── cli.py                   # CLI interface
├── main.py                  # Entry point
├── config/                  # Configuration
├── data/                    # Data processing
│   ├── ingestion.py         # Data ingestion
│   └── feature_engineering.py # Feature engineering
├── models/                  # Model training
├── api/                     # REST API
├── monitoring/              # Model monitoring
├── testing/                 # A/B testing
└── utils/                   # Utilities
```

### Adding New Features

#### 1. New Model Type
```python
# models/training.py
class CustomModelArchitecture:
    @staticmethod
    def create_custom_model(input_shape):
        # Custom model implementation
        return model
```

#### 2. New Feature
```python
# data/feature_engineering.py
def custom_indicator(self, data):
    # Custom feature calculation
    return result
```

#### 3. New API Endpoint
```python
# api/inference.py
@app.get("/custom_endpoint")
async def custom_endpoint():
    # Custom endpoint implementation
    return result
```

## 🚨 Troubleshooting

### Common Issues

#### 1. Database Connection
```bash
# Check PostgreSQL
sudo systemctl status postgresql

# Test connection
psql -h localhost -U postgres -d bitwisers

# View logs
tail -f /var/log/postgresql/postgresql-*.log
```

#### 2. Kafka Issues
```bash
# Check Kafka
sudo systemctl status kafka

# List topics
kafka-topics --list --bootstrap-server localhost:9092

# View logs
tail -f /var/log/kafka/server.log
```

#### 3. MLflow Issues
```bash
# Check MLflow server
curl http://localhost:5000/api/2.0/preview/mlflow/experiments/list

# Restart MLflow
pkill -f mlflow
mlflow server --host 0.0.0.0 --port 5000
```

#### 4. Model Loading Issues
```bash
# List registered models
curl http://localhost:5000/api/2.0/preview/mlflow/experiments/list

# Check model registry
mlflow models list
```

### Performance Optimization

#### 1. Model Cache
```python
# Monitor cache usage
import redis
r = redis.Redis()
info = r.info('memory')
print(f"Cache usage: {info['used_memory_human']}")
```

#### 2. Database Optimization
```sql
-- Check index usage
SELECT schemaname, tablename, attname, n_distinct, correlation 
FROM pg_stats 
WHERE schemaname = 'public' 
ORDER BY tablename, attname;

-- Create missing indexes
CREATE INDEX CONCURRENTLY idx_market_data_symbol_time 
ON market_data(symbol, time DESC);
```

#### 3. Memory Usage
```python
# Monitor memory usage
import psutil
memory = psutil.virtual_memory()
print(f"Memory usage: {memory.percent}%")
```

### Log Analysis

```bash
# View recent errors
tail -f logs/bitwisers_ml_*.log | grep ERROR

# Performance logs
grep "Training completed" logs/bitwisers_ml_*.log

# Alert logs
grep "Alert" logs/bitwisers_ml_*.log
```

## 📚 Documentation

### Additional Resources
- [Full Documentation](docs/ml_pipeline.md)
- [API Reference](docs/api_reference.md)
- [Architecture Guide](docs/architecture.md)
- [Deployment Guide](docs/deployment.md)

### Community
- [GitHub Issues](https://github.com/bitwisers/ml-pipeline/issues)
- [Discussions](https://github.com/bitwisers/ml-pipeline/discussions)
- [Wiki](https://github.com/bitwisers/ml-pipeline/wiki)

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details.

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 🏆 Features Roadmap

### Q1 2024
- [ ] Real-time streaming inference
- [ ] Model explainability (SHAP, LIME)
- [ ] Advanced alerting system
- [ ] Multi-timeframe support

### Q2 2024
- [ ] Deep reinforcement learning
- [ ] Portfolio optimization
- [ ] Risk management module
- [ ] Mobile app integration

### Q3 2024
- [ ] Federated learning
- [ ] Model interpretability dashboard
- [ ] Advanced A/B testing
- [ ] Cloud deployment

## 📞 Support

- **Email**: support@bitwisers.com
- **Documentation**: [docs.bitwisers.com](https://docs.bitwisers.com)
- **Community**: [Discord](https://discord.gg/bitwisers)

## 🙏 Acknowledgments

- TensorFlow team for deep learning frameworks
- Optuna team for hyperparameter optimization
- MLflow team for experiment tracking
- TimescaleDB team for time-series database
- FastAPI team for modern API framework

---

<div align="center">

**Bitwisers 2.0 ML Pipeline** | Transforming Trading with AI

[Website](https://bitwisers.com) | [Documentation](docs/ml_pipeline.md) | [API](http://localhost:8000) | [MLflow](http://localhost:5000)

Made with ❤️ by Bitwisers Team

</div>