"""
Logging Utility Modülü
Merkezi log yönetimi ve structured logging
"""

import logging
import sys
import os
from datetime import datetime
from typing import Optional
import json
from pathlib import Path

class JSONFormatter(logging.Formatter):
    """JSON formatında log formatting"""
    
    def format(self, record):
        log_entry = {
            'timestamp': datetime.utcnow().isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno
        }
        
        # Extra field'ları ekle
        for key, value in record.__dict__.items():
            if key not in ['name', 'msg', 'args', 'levelname', 'levelno', 
                          'pathname', 'filename', 'module', 'lineno', 
                          'funcName', 'created', 'msecs', 'relativeCreated', 
                          'thread', 'threadName', 'processName', 'process',
                          'getMessage', 'message']:
                log_entry[key] = value
        
        # Exception varsa ekle
        if record.exc_info:
            log_entry['exception'] = self.formatException(record.exc_info)
        
        return json.dumps(log_entry, ensure_ascii=False)

class ColoredFormatter(logging.Formatter):
    """Console için renkli log formatting"""
    
    # ANSI color codes
    COLORS = {
        'DEBUG': '\033[36m',     # Cyan
        'INFO': '\033[32m',      # Green
        'WARNING': '\033[33m',   # Yellow
        'ERROR': '\033[31m',     # Red
        'CRITICAL': '\033[35m',  # Magenta
        'RESET': '\033[0m'       # Reset
    }
    
    def format(self, record):
        color = self.COLORS.get(record.levelname, '')
        reset = self.COLORS['RESET']
        
        # Timestamp ve level
        timestamp = datetime.fromtimestamp(record.created).strftime('%Y-%m-%d %H:%M:%S')
        level = f"{color}{record.levelname:<8}{reset}"
        
        # Message
        message = record.getMessage()
        
        # Full formatted message
        return f"{timestamp} | {level} | {record.name} | {message}"

class LoggerManager:
    """Merkezi log yönetimi"""
    
    _loggers = {}
    _handlers_initialized = False
    
    @classmethod
    def get_logger(cls, name: str, level: int = logging.INFO) -> logging.Logger:
        """Logger instance al"""
        if name not in cls._loggers:
            logger = logging.getLogger(name)
            logger.setLevel(level)
            cls._loggers[name] = logger
            
            # Handler'ları sadece bir kez initialize et
            if not cls._handlers_initialized:
                cls._setup_handlers()
                cls._handlers_initialized = True
                
        return cls._loggers[name]
    
    @classmethod
    def _setup_handlers(cls):
        """Log handler'ları ayarla"""
        
        # Console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_formatter = ColoredFormatter()
        console_handler.setFormatter(console_formatter)
        console_handler.setLevel(logging.INFO)
        
        # File handler
        try:
            log_dir = Path("logs")
            log_dir.mkdir(exist_ok=True)
            
            file_handler = logging.FileHandler(
                log_dir / f"bitwisers_ml_{datetime.now().strftime('%Y%m%d')}.log",
                encoding='utf-8'
            )
            
            # JSON formatında dosyaya yaz
            json_formatter = JSONFormatter()
            file_handler.setFormatter(json_formatter)
            file_handler.setLevel(logging.DEBUG)
            
            # Handler'ları tüm logger'lara ekle
            for logger in cls._loggers.values():
                logger.addHandler(file_handler)
                logger.addHandler(console_handler)
                
        except Exception as e:
            # File handler kurulumu başarısız olursa console'a sadece yaz
            for logger in cls._loggers.values():
                logger.addHandler(console_handler)
            
            print(f"Warning: File logging setup failed: {e}")
    
    @classmethod
    def set_level(cls, level: int):
        """Tüm logger'ların level'ını ayarla"""
        for logger in cls._loggers.values():
            logger.setLevel(level)
    
    @classmethod
    def add_file_handler(cls, log_file: str, level: int = logging.INFO):
        """Ek file handler ekle"""
        try:
            handler = logging.FileHandler(log_file, encoding='utf-8')
            handler.setLevel(level)
            handler.setFormatter(JSONFormatter())
            
            for logger in cls._loggers.values():
                logger.addHandler(handler)
                
        except Exception as e:
            print(f"Warning: Additional file handler setup failed: {e}")

class PerformanceLogger:
    """Performance metriklerini loglayan utility"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        
    def log_training_start(self, model_name: str, dataset_size: int):
        """Training başlangıcını logla"""
        self.logger.info(
            "Training started",
            extra={
                'event_type': 'training_start',
                'model_name': model_name,
                'dataset_size': dataset_size,
                'timestamp': datetime.utcnow().isoformat()
            }
        )
    
    def log_training_complete(self, model_name: str, duration_seconds: float, 
                            final_metrics: dict):
        """Training tamamlanmasını logla"""
        self.logger.info(
            "Training completed",
            extra={
                'event_type': 'training_complete',
                'model_name': model_name,
                'duration_seconds': duration_seconds,
                'final_metrics': final_metrics,
                'timestamp': datetime.utcnow().isoformat()
            }
        )
    
    def log_prediction(self, model_name: str, symbol: str, prediction: float, 
                     actual: float = None):
        """Prediction sonucunu logla"""
        extra = {
            'event_type': 'prediction',
            'model_name': model_name,
            'symbol': symbol,
            'prediction': prediction,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        if actual is not None:
            extra['actual'] = actual
            extra['error'] = abs(prediction - actual)
        
        self.logger.info("Prediction made", extra=extra)
    
    def log_data_drift(self, feature_name: str, drift_detected: bool, 
                      drift_score: float):
        """Data drift detection sonucunu logla"""
        self.logger.warning(
            "Data drift detected" if drift_detected else "Data drift not detected",
            extra={
                'event_type': 'data_drift',
                'feature_name': feature_name,
                'drift_detected': drift_detected,
                'drift_score': drift_score,
                'timestamp': datetime.utcnow().isoformat()
            }
        )
    
    def log_model_performance(self, model_name: str, metric_name: str, 
                            current_value: float, threshold: float):
        """Model performance metriklerini logla"""
        self.logger.warning(
            f"Model performance degradation: {metric_name}",
            extra={
                'event_type': 'performance_degradation',
                'model_name': model_name,
                'metric_name': metric_name,
                'current_value': current_value,
                'threshold': threshold,
                'timestamp': datetime.utcnow().isoformat()
            }
        )

class BusinessLogger:
    """Business logic event'lerini loglayan utility"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        
    def log_trade_signal(self, symbol: str, signal_type: str, confidence: float, 
                        model_version: str):
        """Trade signal oluşturma event'ini logla"""
        self.logger.info(
            "Trade signal generated",
            extra={
                'event_type': 'trade_signal',
                'symbol': symbol,
                'signal_type': signal_type,  # 'buy', 'sell', 'hold'
                'confidence': confidence,
                'model_version': model_version,
                'timestamp': datetime.utcnow().isoformat()
            }
        )
    
    def log_model_selection(self, selected_model: str, alternative_models: list, 
                          selection_criteria: dict):
        """Model seçim event'ini logla"""
        self.logger.info(
            "Model selected for deployment",
            extra={
                'event_type': 'model_selection',
                'selected_model': selected_model,
                'alternative_models': alternative_models,
                'selection_criteria': selection_criteria,
                'timestamp': datetime.utcnow().isoformat()
            }
        )
    
    def log_ab_test_event(self, test_id: str, event_type: str, details: dict):
        """A/B test event'ini logla"""
        self.logger.info(
            f"A/B test {event_type}",
            extra={
                'event_type': f'ab_test_{event_type}',
                'test_id': test_id,
                'details': details,
                'timestamp': datetime.utcnow().isoformat()
            }
        )
    
    def log_system_alert(self, alert_type: str, severity: str, message: str, 
                        details: dict = None):
        """Sistem alert'ini logla"""
        log_level = {
            'info': logging.INFO,
            'warning': logging.WARNING,
            'critical': logging.CRITICAL
        }.get(severity.lower(), logging.INFO)
        
        self.logger.log(
            log_level,
            f"System alert: {message}",
            extra={
                'event_type': 'system_alert',
                'alert_type': alert_type,
                'severity': severity,
                'message': message,
                'details': details or {},
                'timestamp': datetime.utcnow().isoformat()
            }
        )

def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """
    Ana logger instance'ı al
    
    Args:
        name: Logger name (genellikle __name__ kullanılır)
        level: Log level (default: INFO)
    
    Returns:
        Configured logger instance
    """
    return LoggerManager.get_logger(name, level)

def get_performance_logger(name: str) -> PerformanceLogger:
    """
    PerformanceLogger instance'ı al
    
    Args:
        name: Logger name
    
    Returns:
        PerformanceLogger instance
    """
    logger = get_logger(name)
    return PerformanceLogger(logger)

def get_business_logger(name: str) -> BusinessLogger:
    """
    BusinessLogger instance'ı al
    
    Args:
        name: Logger name
    
    Returns:
        BusinessLogger instance
    """
    logger = get_logger(name)
    return BusinessLogger(logger)

def configure_logging(log_level: str = "INFO", log_file: Optional[str] = None):
    """
    Global logging konfigürasyonu
    
    Args:
        log_level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Optional log file path
    """
    # Level ayarla
    level_map = {
        'DEBUG': logging.DEBUG,
        'INFO': logging.INFO,
        'WARNING': logging.WARNING,
        'ERROR': logging.ERROR,
        'CRITICAL': logging.CRITICAL
    }
    
    level = level_map.get(log_level.upper(), logging.INFO)
    LoggerManager.set_level(level)
    
    # Ek file handler ekle
    if log_file:
        LoggerManager.add_file_handler(log_file, level)

# Default logger setup
# Environment variable'dan log level al
LOG_LEVEL = os.getenv('LOG_LEVEL', 'INFO')
configure_logging(LOG_LEVEL)