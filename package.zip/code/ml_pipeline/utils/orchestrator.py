"""
ML Pipeline Orchestrator
Tüm pipeline bileşenlerini koordine eden ana sınıf
"""

import asyncio
import mlflow
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import logging

from .config.pipeline_config import pipeline_config
from .data.ingestion import data_ingestion_engine
from .data.feature_engineering import feature_engineering_engine
from .models.training import model_trainer
from .api.inference import inference_engine
from .monitoring.drift_detection import monitoring_system
from .testing.ab_testing import ab_testing_engine
from .utils.logging_utils import get_logger, get_performance_logger, get_business_logger

logger = get_logger(__name__)
perf_logger = get_performance_logger(__name__)
business_logger = get_business_logger(__name__)

class MLPipelineOrchestrator:
    """Ana ML Pipeline Orchestrator"""
    
    def __init__(self, config=None):
        self.config = config or pipeline_config
        self.is_running = False
        self.tasks = []
        self.active_models = []
        
        # Business metrics
        self.business_metrics = {
            'total_predictions': 0,
            'successful_predictions': 0,
            'average_accuracy': 0.0,
            'drift_detections': 0,
            'alerts_generated': 0
        }
        
    async def initialize(self):
        """Pipeline bileşenlerini başlat"""
        try:
            logger.info("ML Pipeline başlatılıyor...")
            
            # MLflow setup
            mlflow.set_tracking_uri(self.config.get_mlflow_tracking_uri())
            
            # Veritabanı bağlantıları
            data_ingestion_engine._initialize_database()
            feature_engineering_engine._initialize_database()
            
            # Monitoring system
            await monitoring_system.start_monitoring()
            
            # Load active models
            inference_engine.initialize_services()
            
            logger.info("ML Pipeline başarıyla başlatıldı")
            
        except Exception as e:
            logger.error(f"Pipeline başlatma hatası: {e}")
            raise
    
    async def start_pipeline(self):
        """Pipeline'ı başlat"""
        if self.is_running:
            logger.warning("Pipeline zaten çalışıyor")
            return
        
        try:
            self.is_running = True
            logger.info("ML Pipeline başlatıldı")
            
            # Background tasks başlat
            self.tasks = [
                asyncio.create_task(self._data_ingestion_loop()),
                asyncio.create_task(self._feature_engineering_loop()),
                asyncio.create_task(self._model_training_loop()),
                asyncio.create_task(self._monitoring_loop()),
                asyncio.create_task(self._business_metrics_loop())
            ]
            
            # Ana loop
            await self._main_pipeline_loop()
            
        except Exception as e:
            logger.error(f"Pipeline hatası: {e}")
            raise
        finally:
            await self.stop_pipeline()
    
    async def stop_pipeline(self):
        """Pipeline'ı durdur"""
        if not self.is_running:
            return
        
        logger.info("ML Pipeline durduruluyor...")
        
        self.is_running = False
        
        # Background tasks'leri iptal et
        for task in self.tasks:
            if not task.done():
                task.cancel()
        
        # Monitoring'i durdur
        await monitoring_system.stop_monitoring()
        
        # Inference engine cleanup
        inference_engine.cleanup()
        
        logger.info("ML Pipeline durduruldu")
    
    async def _main_pipeline_loop(self):
        """Ana pipeline loop"""
        while self.is_running:
            try:
                # Pipeline health check
                await self._check_pipeline_health()
                
                # Model performance kontrolü
                await self._check_model_performance()
                
                # Drift detection kontrolü
                await self._check_data_drift()
                
                # A/B test monitoring
                await self._monitor_ab_tests()
                
                # 1 dakika bekle
                await asyncio.sleep(60)
                
            except Exception as e:
                logger.error(f"Main loop hatası: {e}")
                await asyncio.sleep(30)  # Hata durumunda kısa bekle
    
    async def _data_ingestion_loop(self):
        """Veri ingestion loop'u"""
        while self.is_running:
            try:
                symbols = ['BTCUSDT', 'ETHUSDT', 'ADAUSDT', 'DOTUSDT']  # Config'den alınmalı
                
                # Market verilerini al
                market_data = await data_ingestion_engine.fetch_market_data(symbols)
                
                if not market_data.empty:
                    # Verileri kaydet
                    await data_ingestion_engine.store_market_data(market_data)
                    
                    perf_logger.log_prediction("data_ingestion", "market_data", len(market_data))
                
                # 5 dakika bekle
                await asyncio.sleep(300)
                
            except Exception as e:
                logger.error(f"Data ingestion loop hatası: {e}")
                await asyncio.sleep(60)
    
    async def _feature_engineering_loop(self):
        """Feature engineering loop'u"""
        while self.is_running:
            try:
                symbols = ['BTCUSDT', 'ETHUSDT', 'ADAUSDT', 'DOTUSDT']
                
                # Feature generation
                features_dict = await feature_engineering_engine.generate_features_for_symbols(symbols)
                
                # Feature'ları kaydet
                for symbol, features in features_dict.items():
                    if not features.empty:
                        feature_engineering_engine.store_features(features, symbol, '1h')
                
                perf_logger.log_prediction("feature_engineering", f"features_{len(features_dict)}", len(features_dict))
                
                # 10 dakika bekle
                await asyncio.sleep(600)
                
            except Exception as e:
                logger.error(f"Feature engineering loop hatası: {e}")
                await asyncio.sleep(120)
    
    async def _model_training_loop(self):
        """Model training loop'u"""
        while self.is_running:
            try:
                # Training schedule kontrolü
                if await self._should_retrain_models():
                    logger.info("Model retraining başlatılıyor...")
                    
                    # Training data hazırla
                    training_data = await self._prepare_training_data()
                    
                    if training_data is not None:
                        # Model training
                        await self._train_models(training_data)
                
                # 6 saatte bir kontrol et
                await asyncio.sleep(21600)  # 6 hours
                
            except Exception as e:
                logger.error(f"Model training loop hatası: {e}")
                await asyncio.sleep(3600)  # 1 saat bekle
    
    async def _monitoring_loop(self):
        """Monitoring loop'u"""
        while self.is_running:
            try:
                # Model performance monitoring
                await self._monitor_model_performance()
                
                # Data drift monitoring
                await self._monitor_data_drift()
                
                # System health monitoring
                await self._monitor_system_health()
                
                # 30 dakika bekle
                await asyncio.sleep(1800)
                
            except Exception as e:
                logger.error(f"Monitoring loop hatası: {e}")
                await asyncio.sleep(300)
    
    async def _business_metrics_loop(self):
        """Business metrics loop'u"""
        while self.is_running:
            try:
                # Metrics hesapla
                await self._update_business_metrics()
                
                # Business alerts kontrolü
                await self._check_business_alerts()
                
                # 15 dakika bekle
                await asyncio.sleep(900)
                
            except Exception as e:
                logger.error(f"Business metrics loop hatası: {e}")
                await asyncio.sleep(300)
    
    async def _check_pipeline_health(self):
        """Pipeline health check"""
        try:
            # Model sayısı kontrolü
            model_count = len(inference_engine.get_model_status()['loaded_models'])
            
            if model_count == 0:
                business_logger.log_system_alert(
                    'model_availability', 'critical', 
                    'No models available for inference', 
                    {'model_count': 0}
                )
            
            # Database bağlantısı kontrolü
            # (Basit ping test)
            # TODO: Implement database health check
            
        except Exception as e:
            logger.error(f"Health check hatası: {e}")
    
    async def _should_retrain_models(self) -> bool:
        """Model retraining gerekip gerekmediğini kontrol et"""
        try:
            # Son training tarihini kontrol et
            # Config'den retrain interval'i al
            retrain_interval = self.config.model.retrain_interval  # hours
            
            # MLflow'dan son run tarihini al
            # TODO: Implement actual MLflow query
            
            # Şimdilik 24 saatte bir retrain yap
            return True  # Basit implementation
            
        except Exception as e:
            logger.error(f"Retrain decision error: {e}")
            return False
    
    async def _prepare_training_data(self):
        """Training data hazırla"""
        try:
            # Son 30 günlük data al
            # TODO: Implement actual data preparation
            
            # Mock training data
            import numpy as np
            training_data = {
                'X': np.random.normal(0, 1, (1000, 60, 20)),  # sequences, timesteps, features
                'y': np.random.normal(0, 1, 1000)  # targets
            }
            
            return training_data
            
        except Exception as e:
            logger.error(f"Training data preparation hatası: {e}")
            return None
    
    async def _train_models(self, training_data: Dict[str, Any]):
        """Models train et"""
        try:
            X_train, y_train = training_data['X'], training_data['y']
            
            # Split data
            split_idx = int(len(X_train) * 0.8)
            X_train_split = X_train[:split_idx]
            X_val_split = X_train[split_idx:]
            y_train_split = y_train[:split_idx]
            y_val_split = y_train[split_idx:]
            
            # Her model tipi için training
            model_types = self.config.model.model_types
            
            for model_type in model_types:
                try:
                    # Hyperparameter tuning
                    best_params, best_score = model_trainer.train_model_with_optuna(
                        model_type, X_train_split, y_train_split, X_val_split, y_val_split
                    )
                    
                    # Final model training
                    final_model = model_trainer.train_final_model(
                        model_type, X_train, y_train, best_params
                    )
                    
                    # Evaluation
                    metrics, _ = model_trainer.evaluate_model(
                        final_model, X_val_split, y_val_split, model_type
                    )
                    
                    # MLflow'a log
                    model_trainer.log_experiment(
                        run_name=f"{model_type}_training_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                        model_type=model_type,
                        best_params=best_params,
                        train_metrics={},  # Training metrics (placeholder)
                        val_metrics=metrics,
                        model=final_model,
                        preprocessor=None  # Preprocessor reference
                    )
                    
                    perf_logger.log_training_complete(
                        model_type, 3600.0, metrics  # Placeholder duration
                    )
                    
                except Exception as e:
                    logger.error(f"{model_type} training hatası: {e}")
                    continue
                    
        except Exception as e:
            logger.error(f"Model training hatası: {e}")
    
    async def _check_model_performance(self):
        """Model performance kontrolü"""
        try:
            # Son performans metriklerini al
            performance_summary = await monitoring_system.performance_monitor.get_performance_summary()
            
            # Performance degradation kontrolü
            for model_name, metrics in performance_summary.items():
                for metric_name, metric_data in metrics.items():
                    # Threshold kontrolü (config'den alınmalı)
                    current_value = metric_data['average']
                    
                    thresholds = {
                        'mse': 0.001,
                        'mae': 0.05,
                        'r2': 0.3
                    }
                    
                    if metric_name in thresholds:
                        threshold = thresholds[metric_name]
                        
                        # Degradation kontrolü
                        is_degraded = False
                        if metric_name in ['mse', 'mae']:
                            is_degraded = current_value > threshold
                        elif metric_name == 'r2':
                            is_degraded = current_value < threshold
                        
                        if is_degraded:
                            perf_logger.log_model_performance(
                                model_name, metric_name, current_value, threshold
                            )
                            
                            # Business alert
                            business_logger.log_system_alert(
                                'performance_degradation', 'warning',
                                f"Model {model_name} performance degraded for {metric_name}",
                                {
                                    'model': model_name,
                                    'metric': metric_name,
                                    'current_value': current_value,
                                    'threshold': threshold
                                }
                            )
                    
        except Exception as e:
            logger.error(f"Model performance check hatası: {e}")
    
    async def _check_data_drift(self):
        """Data drift kontrolü"""
        try:
            # Feature data'sını al (mock)
            import numpy as np
            features_data = {
                'rsi_14': np.random.normal(50, 15, 100),
                'macd': np.random.normal(0, 100, 100),
                'volume': np.random.normal(1000000, 500000, 100)
            }
            
            drift_results = await monitoring_system.performance_monitor.monitor_data_drift(
                features_data, 'BTCUSDT', '1h'
            )
            
            # Drift detection log
            for feature_name, drift_result in drift_results.items():
                if drift_result['drift_detected']:
                    perf_logger.log_data_drift(
                        feature_name, True, drift_result.get('drift_score', 0.0)
                    )
                    
                    self.business_metrics['drift_detections'] += 1
                    
        except Exception as e:
            logger.error(f"Data drift check hatası: {e}")
    
    async def _monitor_ab_tests(self):
        """A/B test monitoring"""
        try:
            active_tests = ab_testing_engine.list_active_tests()
            
            for test in active_tests:
                test_id = test['test_id']
                progress = await ab_testing_engine.monitor_test_progress(test_id)
                
                if 'progress' in progress:
                    progress_data = progress['progress']
                    
                    # Test tamamlanabilir mi kontrol et
                    if progress_data['can_analyze']:
                        # Final analysis yap
                        analysis = ab_testing_engine.analyze_test(test_id)
                        
                        # A/B test sonucunu business logic'e entegre et
                        await self._process_ab_test_result(test_id, analysis)
                        
                        # Test'i tamamla
                        ab_testing_engine.complete_test(test_id)
                    
        except Exception as e:
            logger.error(f"A/B test monitoring hatası: {e}")
    
    async def _process_ab_test_result(self, test_id: str, analysis: Dict[str, Any]):
        """A/B test sonucunu işle"""
        try:
            if 'conclusion' in analysis:
                conclusion = analysis['conclusion']
                
                business_logger.log_ab_test_event(
                    test_id, 'completed', {'conclusion': conclusion}
                )
                
                # Eğer bir model açıkça daha iyi ise, o modeli deploy et
                if 'Model A' in conclusion:
                    better_model = 'model_a'
                elif 'Model B' in conclusion:
                    better_model = 'model_b'
                else:
                    better_model = None
                
                if better_model:
                    await self._promote_winning_model(test_id, better_model)
                    
        except Exception as e:
            logger.error(f"A/B test result processing hatası: {e}")
    
    async def _promote_winning_model(self, test_id: str, winning_model: str):
        """Kazanan model'i promote et"""
        try:
            # Test detaylarını al
            test_config = ab_testing_engine.active_tests.get(test_id)
            if not test_config:
                return
            
            # Model isimlerini belirle
            if winning_model == 'model_a':
                model_name = test_config.model_a
            else:
                model_name = test_config.model_b
            
            # Model'i production'a promote et (MLflow registry)
            # TODO: Implement actual model promotion
            
            business_logger.log_model_selection(
                model_name, [test_config.model_a, test_config.model_b],
                {'test_id': test_id, 'selection_method': 'ab_test'}
            )
            
        except Exception as e:
            logger.error(f"Model promotion hatası: {e}")
    
    async def _monitor_model_performance(self):
        """Model performance monitoring"""
        try:
            # Real-time prediction monitoring
            # Bu fonksiyon gerçek prod ortamında inference API'den metrikler alacak
            
            # Mock performance check
            import random
            
            # Rastgele prediction accuracy simulation
            accuracy = random.uniform(0.6, 0.9)
            
            self.business_metrics['average_accuracy'] = (
                (self.business_metrics['average_accuracy'] * self.business_metrics['total_predictions'] + accuracy) /
                (self.business_metrics['total_predictions'] + 1)
            )
            
            self.business_metrics['total_predictions'] += 1
            self.business_metrics['successful_predictions'] += random.choice([0, 1])
            
        except Exception as e:
            logger.error(f"Model performance monitoring hatası: {e}")
    
    async def _monitor_data_drift(self):
        """Data drift monitoring"""
        # Bu fonksiyon drift detection loop'unda zaten implement edildi
        pass
    
    async def _monitor_system_health(self):
        """System health monitoring"""
        try:
            # Memory, CPU, disk usage monitoring
            # TODO: Implement actual system metrics
            
            health_status = {
                'cpu_usage': random.uniform(20, 80),
                'memory_usage': random.uniform(30, 90),
                'disk_usage': random.uniform(10, 70),
                'timestamp': datetime.now().isoformat()
            }
            
            # Health threshold kontrolü
            if health_status['cpu_usage'] > 90:
                business_logger.log_system_alert(
                    'high_cpu_usage', 'warning',
                    f"High CPU usage: {health_status['cpu_usage']:.1f}%",
                    health_status
                )
            
            if health_status['memory_usage'] > 95:
                business_logger.log_system_alert(
                    'high_memory_usage', 'critical',
                    f"High memory usage: {health_status['memory_usage']:.1f}%",
                    health_status
                )
                
        except Exception as e:
            logger.error(f"System health monitoring hatası: {e}")
    
    async def _update_business_metrics(self):
        """Business metrics güncelle"""
        try:
            # Son 15 dakikalık metrikleri topla
            current_metrics = {
                'pipeline_uptime_hours': (datetime.now() - datetime.now()).total_seconds() / 3600,  # Placeholder
                'active_models': len(inference_engine.get_model_status()['loaded_models']),
                'drift_detections': self.business_metrics['drift_detections'],
                'alerts_generated': self.business_metrics['alerts_generated'],
                'prediction_accuracy': self.business_metrics['average_accuracy'],
                'timestamp': datetime.now().isoformat()
            }
            
            # Business logic ile entegre et
            # TODO: Send metrics to business dashboard
            
        except Exception as e:
            logger.error(f"Business metrics update hatası: {e}")
    
    async def _check_business_alerts(self):
        """Business alert kontrolü"""
        try:
            # Son alert'leri al
            recent_alerts = await monitoring_system.performance_monitor.get_recent_alerts(hours=1)
            
            self.business_metrics['alerts_generated'] = len(recent_alerts)
            
            # Critical alert'leri öne çıkar
            critical_alerts = [alert for alert in recent_alerts if alert['severity'] == 'critical']
            
            if critical_alerts:
                business_logger.log_system_alert(
                    'critical_alerts', 'critical',
                    f"Critical alerts detected: {len(critical_alerts)}",
                    {'alerts': critical_alerts}
                )
                
        except Exception as e:
            logger.error(f"Business alerts check hatası: {e}")
    
    def get_pipeline_status(self) -> Dict[str, Any]:
        """Pipeline durumunu getir"""
        return {
            'is_running': self.is_running,
            'active_tasks': len(self.tasks),
            'business_metrics': self.business_metrics,
            'model_status': inference_engine.get_model_status(),
            'timestamp': datetime.now().isoformat()
        }
    
    async def trigger_manual_training(self, model_type: str = None):
        """Manuel model training tetikle"""
        try:
            logger.info(f"Manuel training tetiklendi: {model_type or 'all'}")
            
            training_data = await self._prepare_training_data()
            if training_data:
                await self._train_models(training_data)
            
            return True
            
        except Exception as e:
            logger.error(f"Manuel training hatası: {e}")
            return False
    
    async def create_ab_test(self, model_a: str, model_b: str, test_name: str = None) -> str:
        """A/B test oluştur"""
        try:
            test_id = await ab_testing_engine.create_comparative_test(model_a, model_b, test_name)
            return test_id
            
        except Exception as e:
            logger.error(f"A/B test oluşturma hatası: {e}")
            return ""

# Global orchestrator instance
ml_pipeline = MLPipelineOrchestrator()