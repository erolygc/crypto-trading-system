"""
A/B Testing Framework
Model karşılaştırma ve statistical significance testing
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Union
from scipy import stats
import mlflow
from sqlalchemy import create_engine, text
import logging
import hashlib
from dataclasses import dataclass
from enum import Enum

from ..config.pipeline_config import pipeline_config
from ..utils.logging_utils import get_logger

logger = get_logger(__name__)

class TestStatus(Enum):
    """A/B Test durumları"""
    PLANNING = "planning"
    RUNNING = "running"
    COMPLETED = "completed"
    PAUSED = "paused"
    CANCELLED = "cancelled"

class AlertLevel(Enum):
    """Alert seviyeleri"""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"

@dataclass
class TestConfiguration:
    """Test konfigürasyonu"""
    test_name: str
    model_a: str
    model_b: str
    traffic_split: Dict[str, float]
    metrics: List[str]
    significance_level: float
    power: float
    min_detectable_effect: float
    duration_days: int
    sample_size: int
    start_date: datetime
    end_date: datetime

class StatisticalTests:
    """Statistical test metodları"""
    
    @staticmethod
    def t_test(group_a: np.ndarray, group_b: np.ndarray, alpha: float = 0.05) -> Dict[str, Any]:
        """Independent t-test"""
        statistic, p_value = stats.ttest_ind(group_a, group_b)
        
        # Effect size (Cohen's d)
        pooled_std = np.sqrt(((len(group_a) - 1) * np.var(group_a, ddof=1) + 
                             (len(group_b) - 1) * np.var(group_b, ddof=1)) / 
                            (len(group_a) + len(group_b) - 2))
        
        cohens_d = (np.mean(group_a) - np.mean(group_b)) / pooled_std
        
        return {
            'test_type': 't_test',
            'statistic': statistic,
            'p_value': p_value,
            'significant': p_value < alpha,
            'effect_size': cohens_d,
            'group_a_mean': np.mean(group_a),
            'group_b_mean': np.mean(group_b),
            'group_a_std': np.std(group_a),
            'group_b_std': np.std(group_b)
        }
    
    @staticmethod
    def mann_whitney_u(group_a: np.ndarray, group_b: np.ndarray, alpha: float = 0.05) -> Dict[str, Any]:
        """Mann-Whitney U test (non-parametric)"""
        statistic, p_value = stats.mannwhitneyu(group_a, group_b, alternative='two-sided')
        
        return {
            'test_type': 'mann_whitney_u',
            'statistic': statistic,
            'p_value': p_value,
            'significant': p_value < alpha,
            'group_a_median': np.median(group_a),
            'group_b_median': np.median(group_b)
        }
    
    @staticmethod
    def chi_square_test(success_a: int, total_a: int, success_b: int, total_b: int) -> Dict[str, Any]:
        """Chi-square test for proportions"""
        # Create contingency table
        contingency_table = np.array([[success_a, total_a - success_a],
                                    [success_b, total_b - success_b]])
        
        chi2, p_value, dof, expected = stats.chi2_contingency(contingency_table)
        
        # Calculate confidence intervals for proportions
        prop_a = success_a / total_a
        prop_b = success_b / total_b
        
        # Wilson score interval
        def wilson_score_interval(successes, trials, confidence=0.95):
            z = stats.norm.ppf((1 + confidence) / 2)
            p = successes / trials
            
            denominator = 1 + z**2 / trials
            centre = (p + z**2 / (2 * trials)) / denominator
            half_width = z * np.sqrt((p * (1 - p) + z**2 / (4 * trials)) / trials) / denominator
            
            return centre - half_width, centre + half_width
        
        ci_a = wilson_score_interval(success_a, total_a)
        ci_b = wilson_score_interval(success_b, total_b)
        
        return {
            'test_type': 'chi_square',
            'statistic': chi2,
            'p_value': p_value,
            'significant': p_value < alpha,
            'prop_a': prop_a,
            'prop_b': prop_b,
            'prop_diff': prop_b - prop_a,
            'ci_a': ci_a,
            'ci_b': ci_b,
            'contingency_table': contingency_table.tolist()
        }
    
    @staticmethod
    def power_analysis(effect_size: float, alpha: float, power: float) -> Dict[str, Any]:
        """Statistical power analysis"""
        from scipy.stats import norm
        
        # Calculate required sample size for given effect size and power
        z_alpha = norm.ppf(1 - alpha / 2)
        z_beta = norm.ppf(power)
        
        required_n = (2 * (z_alpha + z_beta)**2) / (effect_size**2)
        
        return {
            'required_sample_size': int(np.ceil(required_n)),
            'effect_size': effect_size,
            'alpha': alpha,
            'power': power,
            'z_alpha': z_alpha,
            'z_beta': z_beta
        }

class ABTestingEngine:
    """Ana A/B testing engine"""
    
    def __init__(self, config=None):
        self.config = config or pipeline_config
        self.engine = None
        self.active_tests = {}
        self.completed_tests = {}
        
    def initialize_database(self):
        """Veritabanı bağlantısını başlat"""
        try:
            database_url = self.config.get_database_url()
            self.engine = create_engine(database_url)
            
            # A/B test tablolarını oluştur
            self._create_ab_test_tables()
            
        except Exception as e:
            logger.error(f"Veritabanı bağlantısı başarısız: {e}")
            raise
    
    def _create_ab_test_tables(self):
        """A/B test tablolarını oluştur"""
        try:
            # Test konfigürasyonları
            create_tests_table = """
            CREATE TABLE IF NOT EXISTS ab_tests (
                test_id VARCHAR(50) PRIMARY KEY,
                test_name VARCHAR(200) NOT NULL,
                model_a VARCHAR(100) NOT NULL,
                model_b VARCHAR(100) NOT NULL,
                traffic_split JSONB NOT NULL,
                metrics TEXT[] NOT NULL,
                significance_level DECIMAL(5,4) NOT NULL,
                power DECIMAL(5,4) NOT NULL,
                min_detectable_effect DECIMAL(10,6) NOT NULL,
                duration_days INTEGER NOT NULL,
                sample_size INTEGER NOT NULL,
                start_date TIMESTAMPTZ NOT NULL,
                end_date TIMESTAMPTZ NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'planning',
                created_at TIMESTAMPTZ DEFAULT NOW(),
                updated_at TIMESTAMPTZ DEFAULT NOW()
            );
            """
            
            # Test sonuçları
            create_results_table = """
            CREATE TABLE IF NOT EXISTS ab_test_results (
                id SERIAL PRIMARY KEY,
                test_id VARCHAR(50) REFERENCES ab_tests(test_id),
                timestamp TIMESTAMPTZ DEFAULT NOW(),
                symbol VARCHAR(20),
                timeframe VARCHAR(10),
                group_name VARCHAR(10) NOT NULL, -- 'A' or 'B'
                prediction_value DECIMAL(15,8),
                actual_value DECIMAL(15,8),
                error DECIMAL(15,8),
                absolute_error DECIMAL(15,8),
                metadata JSONB
            );
            """
            
            # Statistical analysis sonuçları
            create_analysis_table = """
            CREATE TABLE IF NOT EXISTS ab_test_analysis (
                id SERIAL PRIMARY KEY,
                test_id VARCHAR(50) REFERENCES ab_tests(test_id),
                metric_name VARCHAR(50) NOT NULL,
                analysis_timestamp TIMESTAMPTZ DEFAULT NOW,
                sample_size_a INTEGER,
                sample_size_b INTEGER,
                group_a_mean DECIMAL(15,8),
                group_a_std DECIMAL(15,8),
                group_b_mean DECIMAL(15,8),
                group_b_std DECIMAL(15,8),
                statistic DECIMAL(15,8),
                p_value DECIMAL(15,8),
                significant BOOLEAN,
                effect_size DECIMAL(15,8),
                confidence_interval_a JSONB,
                confidence_interval_b JSONB,
                conclusion TEXT
            );
            """
            
            # Indexes
            create_indexes = [
                "CREATE INDEX IF NOT EXISTS idx_ab_tests_status ON ab_tests (status)",
                "CREATE INDEX IF NOT EXISTS idx_ab_results_test_id ON ab_test_results (test_id, timestamp)",
                "CREATE INDEX IF NOT EXISTS idx_ab_results_symbol ON ab_test_results (symbol, timestamp)",
                "CREATE INDEX IF NOT EXISTS idx_ab_analysis_test_id ON ab_test_analysis (test_id, metric_name)"
            ]
            
            sql_commands = [
                create_tests_table,
                create_results_table,
                create_analysis_table,
                *create_indexes
            ]
            
            for sql in sql_commands:
                self.engine.execute(text(sql))
            
            logger.info("A/B test tabloları oluşturuldu")
            
        except Exception as e:
            logger.error(f"A/B test tablo oluşturma hatası: {e}")
            raise
    
    def create_test(self, test_config: TestConfiguration) -> str:
        """Yeni A/B test oluştur"""
        try:
            # Test ID oluştur
            test_id = self._generate_test_id(test_config.test_name)
            
            # Veritabanına kaydet
            insert_query = """
            INSERT INTO ab_tests 
            (test_id, test_name, model_a, model_b, traffic_split, metrics, 
             significance_level, power, min_detectable_effect, duration_days, 
             sample_size, start_date, end_date, status)
            VALUES (:test_id, :test_name, :model_a, :model_b, :traffic_split,
                   :metrics, :significance_level, :power, :min_detectable_effect,
                   :duration_days, :sample_size, :start_date, :end_date, :status)
            """
            
            with self.engine.connect() as conn:
                conn.execute(text(insert_query), {
                    'test_id': test_id,
                    'test_name': test_config.test_name,
                    'model_a': test_config.model_a,
                    'model_b': test_config.model_b,
                    'traffic_split': test_config.traffic_split,
                    'metrics': test_config.metrics,
                    'significance_level': test_config.significance_level,
                    'power': test_config.power,
                    'min_detectable_effect': test_config.min_detectable_effect,
                    'duration_days': test_config.duration_days,
                    'sample_size': test_config.sample_size,
                    'start_date': test_config.start_date,
                    'end_date': test_config.end_date,
                    'status': TestStatus.PLANNING.value
                })
                
                conn.commit()
            
            # Memory'de sakla
            self.active_tests[test_id] = test_config
            
            logger.info(f"A/B test oluşturuldu: {test_id}")
            return test_id
            
        except Exception as e:
            logger.error(f"A/B test oluşturma hatası: {e}")
            raise
    
    def _generate_test_id(self, test_name: str) -> str:
        """Unique test ID oluştur"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        hash_object = hashlib.md5(test_name.encode())
        hash_hex = hash_object.hexdigest()[:8]
        
        return f"ab_test_{timestamp}_{hash_hex}"
    
    def start_test(self, test_id: str) -> bool:
        """A/B test'i başlat"""
        try:
            if test_id not in self.active_tests:
                raise ValueError(f"Test bulunamadı: {test_id}")
            
            # Status'u güncelle
            update_query = """
            UPDATE ab_tests 
            SET status = :status, updated_at = NOW()
            WHERE test_id = :test_id
            """
            
            with self.engine.connect() as conn:
                conn.execute(text(update_query), {
                    'status': TestStatus.RUNNING.value,
                    'test_id': test_id
                })
                
                conn.commit()
            
            # Test konfigürasyonunu güncelle
            test_config = self.active_tests[test_id]
            test_config.start_date = datetime.now()
            
            logger.info(f"A/B test başlatıldı: {test_id}")
            return True
            
        except Exception as e:
            logger.error(f"A/B test başlatma hatası: {e}")
            return False
    
    def record_result(self, test_id: str, symbol: str, timeframe: str, 
                     prediction: float, actual: float, metadata: Dict = None) -> bool:
        """Test sonucu kaydet"""
        try:
            if test_id not in self.active_tests:
                logger.warning(f"Test bulunamadı: {test_id}")
                return False
            
            # Traffic allocation (hangisi model A, hangisi model B)
            test_config = self.active_tests[test_id]
            group = self._assign_traffic_group(test_id, symbol)
            
            error = abs(prediction - actual)
            
            # Veritabanına kaydet
            insert_query = """
            INSERT INTO ab_test_results 
            (test_id, symbol, timeframe, group_name, prediction_value, 
             actual_value, error, absolute_error, metadata)
            VALUES (:test_id, :symbol, :timeframe, :group_name, :prediction_value,
                   :actual_value, :error, :absolute_error, :metadata)
            """
            
            with self.engine.connect() as conn:
                conn.execute(text(insert_query), {
                    'test_id': test_id,
                    'symbol': symbol,
                    'timeframe': timeframe,
                    'group_name': group,
                    'prediction_value': prediction,
                    'actual_value': actual,
                    'error': prediction - actual,
                    'absolute_error': error,
                    'metadata': metadata or {}
                })
                
                conn.commit()
            
            return True
            
        except Exception as e:
            logger.error(f"Sonuç kaydetme hatası: {e}")
            return False
    
    def _assign_traffic_group(self, test_id: str, symbol: str) -> str:
        """Traffic allocation group ataması (deterministic)"""
        # Hash-based consistent assignment
        hash_input = f"{test_id}_{symbol}"
        hash_object = hashlib.md5(hash_input.encode())
        hash_value = int(hash_object.hexdigest(), 16)
        
        # Convert to group (A or B)
        group_hash = hash_value % 100
        traffic_split = self.active_tests[test_id].traffic_split
        
        if group_hash < traffic_split.get('model_a', 50):
            return 'A'
        else:
            return 'B'
    
    def analyze_test(self, test_id: str) -> Dict[str, Any]:
        """Test sonuçlarını analiz et"""
        try:
            if test_id not in self.active_tests:
                raise ValueError(f"Test bulunamadı: {test_id}")
            
            test_config = self.active_tests[test_id]
            
            # Veri al
            results = self._get_test_results(test_id)
            
            if len(results) == 0:
                return {'error': 'Test sonucu bulunamadı'}
            
            analysis_results = {}
            
            for metric in test_config.metrics:
                # Group A ve B verilerini ayır
                group_a_data = results[results['group_name'] == 'A'][metric].values
                group_b_data = results[results['group_name'] == 'B'][metric].values
                
                if len(group_a_data) == 0 or len(group_b_data) == 0:
                    continue
                
                # Statistical test yap
                if metric in ['error', 'absolute_error']:  # Lower is better
                    test_result = StatisticalTests.t_test(group_a_data, group_b_data, 
                                                        test_config.significance_level)
                else:  # Higher is better (accuracy, r2, etc.)
                    test_result = StatisticalTests.t_test(group_b_data, group_a_data,
                                                        test_config.significance_level)
                
                analysis_results[metric] = test_result
                
                # Sonuçları veritabanına kaydet
                self._save_analysis_result(test_id, metric, test_result, group_a_data, group_b_data)
            
            # Overall conclusion
            conclusion = self._generate_conclusion(analysis_results, test_config)
            
            final_result = {
                'test_id': test_id,
                'sample_sizes': {
                    'group_a': len(results[results['group_name'] == 'A']),
                    'group_b': len(results[results['group_name'] == 'B'])
                },
                'analysis': analysis_results,
                'conclusion': conclusion,
                'timestamp': datetime.now()
            }
            
            return final_result
            
        except Exception as e:
            logger.error(f"Test analiz hatası: {e}")
            return {'error': str(e)}
    
    def _get_test_results(self, test_id: str) -> pd.DataFrame:
        """Test sonuçlarını al"""
        try:
            query = """
            SELECT group_name, prediction_value, actual_value, error, absolute_error,
                   symbol, timeframe, timestamp
            FROM ab_test_results 
            WHERE test_id = :test_id
            ORDER BY timestamp
            """
            
            with self.engine.connect() as conn:
                result = conn.execute(text(query), {'test_id': test_id})
                data = pd.DataFrame(result.fetchall(), columns=result.keys())
            
            return data
            
        except Exception as e:
            logger.error(f"Test sonucu alma hatası: {e}")
            return pd.DataFrame()
    
    def _save_analysis_result(self, test_id: str, metric: str, 
                            test_result: Dict[str, Any], 
                            group_a_data: np.ndarray, group_b_data: np.ndarray):
        """Analysis sonucunu kaydet"""
        try:
            insert_query = """
            INSERT INTO ab_test_analysis 
            (test_id, metric_name, sample_size_a, sample_size_b,
             group_a_mean, group_a_std, group_b_mean, group_b_std,
             statistic, p_value, significant, effect_size)
            VALUES (:test_id, :metric_name, :sample_size_a, :sample_size_b,
                   :group_a_mean, :group_a_std, :group_b_mean, :group_b_std,
                   :statistic, :p_value, :significant, :effect_size)
            """
            
            with self.engine.connect() as conn:
                conn.execute(text(insert_query), {
                    'test_id': test_id,
                    'metric_name': metric,
                    'sample_size_a': len(group_a_data),
                    'sample_size_b': len(group_b_data),
                    'group_a_mean': test_result['group_a_mean'],
                    'group_a_std': test_result['group_a_std'],
                    'group_b_mean': test_result['group_b_mean'],
                    'group_b_std': test_result['group_b_std'],
                    'statistic': test_result['statistic'],
                    'p_value': test_result['p_value'],
                    'significant': test_result['significant'],
                    'effect_size': test_result['effect_size']
                })
                
                conn.commit()
                
        except Exception as e:
            logger.error(f"Analysis sonucu kaydetme hatası: {e}")
    
    def _generate_conclusion(self, analysis_results: Dict[str, Any], 
                           test_config: TestConfiguration) -> str:
        """Test sonuçlarından conclusion oluştur"""
        significant_metrics = []
        better_model = None
        
        for metric, result in analysis_results.items():
            if result['significant']:
                significant_metrics.append(metric)
                
                # Determine which model is better
                if metric in ['error', 'absolute_error']:
                    if result['group_a_mean'] < result['group_b_mean']:
                        better_model = 'model_a'
                    else:
                        better_model = 'model_b'
                else:  # Higher is better
                    if result['group_b_mean'] > result['group_a_mean']:
                        better_model = 'model_b'
                    else:
                        better_model = 'model_a'
        
        if len(significant_metrics) == 0:
            return "Test sonucu statistically significant değil. Daha fazla veri gerekli."
        
        if better_model == 'model_a':
            return f"Model A anlamlı olarak daha iyi performans gösteriyor. Significant metrics: {significant_metrics}"
        else:
            return f"Model B anlamlı olarak daha iyi performans gösteriyor. Significant metrics: {significant_metrics}"
    
    def complete_test(self, test_id: str) -> bool:
        """A/B test'i tamamla"""
        try:
            # Final analysis yap
            analysis = self.analyze_test(test_id)
            
            # Status'u güncelle
            update_query = """
            UPDATE ab_tests 
            SET status = :status, updated_at = NOW()
            WHERE test_id = :test_id
            """
            
            with self.engine.connect() as conn:
                conn.execute(text(update_query), {
                    'status': TestStatus.COMPLETED.value,
                    'test_id': test_id
                })
                
                conn.commit()
            
            # Active tests'ten completed tests'a taşı
            if test_id in self.active_tests:
                self.completed_tests[test_id] = self.active_tests[test_id]
                del self.active_tests[test_id]
            
            logger.info(f"A/B test tamamlandı: {test_id}")
            return True
            
        except Exception as e:
            logger.error(f"Test tamamlama hatası: {e}")
            return False
    
    def get_test_status(self, test_id: str) -> Dict[str, Any]:
        """Test durumunu kontrol et"""
        try:
            query = """
            SELECT * FROM ab_tests WHERE test_id = :test_id
            """
            
            with self.engine.connect() as conn:
                result = conn.execute(text(query), {'test_id': test_id})
                row = result.fetchone()
            
            if not row:
                return {'error': 'Test bulunamadı'}
            
            # Results count
            results_query = """
            SELECT 
                COUNT(*) as total_results,
                SUM(CASE WHEN group_name = 'A' THEN 1 ELSE 0 END) as group_a_results,
                SUM(CASE WHEN group_name = 'B' THEN 1 ELSE 0 END) as group_b_results
            FROM ab_test_results WHERE test_id = :test_id
            """
            
            results_result = conn.execute(text(results_query), {'test_id': test_id})
            results_row = results_result.fetchone()
            
            return {
                'test_info': dict(row._mapping),
                'results_count': dict(results_row._mapping),
                'is_active': test_id in self.active_tests,
                'timestamp': datetime.now()
            }
            
        except Exception as e:
            logger.error(f"Test status alma hatası: {e}")
            return {'error': str(e)}
    
    def list_active_tests(self) -> List[Dict[str, Any]]:
        """Aktif test'leri listele"""
        try:
            query = """
            SELECT test_id, test_name, model_a, model_b, status, created_at
            FROM ab_tests 
            WHERE status IN ('planning', 'running')
            ORDER BY created_at DESC
            """
            
            with self.engine.connect() as conn:
                result = conn.execute(text(query))
                tests = [dict(row._mapping) for row in result.fetchall()]
            
            return tests
            
        except Exception as e:
            logger.error(f"Aktif test listesi alma hatası: {e}")
            return []

# Test automation
class ABTestAutomation:
    """A/B test otomasyonu"""
    
    def __init__(self, config=None):
        self.config = config or pipeline_config
        self.ab_engine = ABTestingEngine()
        self.ab_engine.initialize_database()
        
    async def create_comparative_test(self, model_a: str, model_b: str, 
                                    test_name: str = None) -> str:
        """İki model arasında karşılaştırma testi oluştur"""
        if test_name is None:
            test_name = f"{model_a}_vs_{model_b}_{datetime.now().strftime('%Y%m%d')}"
        
        # Test konfigürasyonu oluştur
        test_config = TestConfiguration(
            test_name=test_name,
            model_a=model_a,
            model_b=model_b,
            traffic_split={'model_a': 50, 'model_b': 50},  # %50-50 split
            metrics=['absolute_error', 'directional_accuracy'],  # Ana metrikler
            significance_level=self.config.testing.significance_level,
            power=self.config.testing.power,
            min_detectable_effect=self.config.testing.min_detectable_effect,
            duration_days=self.config.testing.test_duration,
            sample_size=1000,  # Minimum sample size
            start_date=datetime.now(),
            end_date=datetime.now() + timedelta(days=self.config.testing.test_duration)
        )
        
        # Test'i oluştur ve başlat
        test_id = self.ab_engine.create_test(test_config)
        self.ab_engine.start_test(test_id)
        
        logger.info(f"Karşılaştırma testi oluşturuldu: {test_id}")
        return test_id
    
    async def monitor_test_progress(self, test_id: str) -> Dict[str, Any]:
        """Test ilerlemesini izle"""
        status = self.ab_engine.get_test_status(test_id)
        
        if 'error' in status:
            return status
        
        # Test'in sample size'a ulaşıp ulaşmadığını kontrol et
        test_config = self.ab_engine.active_tests.get(test_id)
        if not test_config:
            return {'error': 'Test bulunamadı veya tamamlandı'}
        
        results_count = status['results_count']['total_results']
        required_samples = test_config.sample_size
        
        progress = {
            'test_id': test_id,
            'required_samples': required_samples,
            'current_samples': results_count,
            'progress_percentage': min(100, (results_count / required_samples) * 100),
            'can_analyze': results_count >= required_samples,
            'days_remaining': (test_config.end_date - datetime.now()).days
        }
        
        return {**status, 'progress': progress}

# Singleton instance
ab_testing_engine = ABTestAutomation()