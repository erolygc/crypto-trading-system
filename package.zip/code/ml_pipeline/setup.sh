#!/bin/bash

# Bitwisers 2.0 ML Pipeline Setup Script
# Comprehensive setup for development and production environments

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Configuration
PROJECT_NAME="bitwisers-ml-pipeline"
PYTHON_VERSION="3.9"
DOCKER_COMPOSE_VERSION="2.20"

# Function to print colored output
print_color() {
    echo -e "${1}${2}${NC}"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to install system dependencies
install_system_dependencies() {
    print_color $BLUE "📦 Installing system dependencies..."
    
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux
        sudo apt-get update
        sudo apt-get install -y \
            python3 \
            python3-pip \
            python3-venv \
            curl \
            wget \
            git \
            build-essential \
            libpq-dev \
            docker.io \
            docker-compose
    elif [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        if ! command_exists brew; then
            print_color $YELLOW "Installing Homebrew..."
            /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
        fi
        
        brew install python@3.9 curl wget git postgresql
        
        # Install Docker Desktop for Mac
        if ! command_exists docker; then
            print_color $YELLOW "Installing Docker Desktop..."
            open "https://www.docker.com/products/docker-desktop"
            read -p "Press Enter after installing Docker Desktop..."
        fi
    else
        print_color $RED "❌ Unsupported operating system: $OSTYPE"
        exit 1
    fi
    
    print_color $GREEN "✅ System dependencies installed"
}

# Function to check Python version
check_python() {
    print_color $BLUE "🐍 Checking Python version..."
    
    if ! command_exists python3; then
        print_color $RED "❌ Python 3 not found. Please install Python 3.9+"
        exit 1
    fi
    
    PYTHON_VER=$(python3 --version | cut -d' ' -f2)
    print_color $GREEN "✅ Python version: $PYTHON_VER"
}

# Function to create virtual environment
create_venv() {
    print_color $BLUE "🔧 Creating virtual environment..."
    
    if [ ! -d "venv" ]; then
        python3 -m venv venv
        print_color $GREEN "✅ Virtual environment created"
    else
        print_color $YELLOW "⚠️ Virtual environment already exists"
    fi
    
    # Activate virtual environment
    source venv/bin/activate
    
    # Upgrade pip
    pip install --upgrade pip
    
    print_color $GREEN "✅ Virtual environment activated"
}

# Function to install Python dependencies
install_python_dependencies() {
    print_color $BLUE "📚 Installing Python dependencies..."
    
    source venv/bin/activate
    pip install -r requirements.txt
    
    print_color $GREEN "✅ Python dependencies installed"
}

# Function to setup database
setup_database() {
    print_color $BLUE "🗃️ Setting up database..."
    
    # Check if PostgreSQL is running
    if ! sudo systemctl is-active --quiet postgresql; then
        print_color $YELLOW "Starting PostgreSQL service..."
        sudo systemctl start postgresql
    fi
    
    # Create database
    sudo -u postgres psql -c "CREATE DATABASE bitwisers;" 2>/dev/null || true
    sudo -u postgres psql -c "CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;" -d bitwisers 2>/dev/null || true
    sudo -u postgres psql -c "CREATE DATABASE mlflow;" 2>/dev/null || true
    
    print_color $GREEN "✅ Database setup completed"
}

# Function to setup environment variables
setup_environment() {
    print_color $BLUE "⚙️ Setting up environment variables..."
    
    if [ ! -f ".env" ]; then
        cat > .env << EOF
# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_DATABASE=bitwisers
DB_USER=postgres
DB_PASSWORD=your_password_here

# MLflow Configuration
MLFLOW_TRACKING_URI=http://localhost:5000
MLFLOW_REGISTRY_URI=http://localhost:5000

# Kafka Configuration
KAFKA_BOOTSTRAP_SERVERS=localhost:9092
KAFKA_DATA_TOPIC=market-data
KAFKA_PREDICTION_TOPIC=ml-predictions
KAFKA_MODEL_UPDATES_TOPIC=model-updates

# Redis Configuration
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_DB=0

# Logging Configuration
LOG_LEVEL=INFO
LOG_FILE=logs/bitwisers_ml.log

# API Configuration
API_HOST=0.0.0.0
API_PORT=8000
API_WORKERS=4
EOF
        print_color $GREEN "✅ Environment file created (.env)"
    else
        print_color $YELLOW "⚠️ Environment file already exists"
    fi
}

# Function to create directory structure
create_directories() {
    print_color $BLUE "📁 Creating directory structure..."
    
    directories=(
        "logs"
        "data/raw"
        "data/processed"
        "data/features"
        "models/trained"
        "models/candidates"
        "models/archived"
        "config"
        "mlruns"
        "mlartifacts"
        "grafana/provisioning/datasources"
        "grafana/provisioning/dashboards"
        "prometheus"
        "scripts"
    )
    
    for dir in "${directories[@]}"; do
        mkdir -p "$dir"
    done
    
    print_color $GREEN "✅ Directory structure created"
}

# Function to setup MLflow
setup_mlflow() {
    print_color $BLUE "🔬 Setting up MLflow..."
    
    # Create MLflow database
    sudo -u postgres psql -c "CREATE DATABASE mlflow;" 2>/dev/null || true
    
    # Download MLflow config example
    if [ ! -f "mlflow_config.py" ]; then
        cat > mlflow_config.py << EOF
import mlflow
import mlflow.sklearn
import mlflow.tensorflow

# Set tracking URI
mlflow.set_tracking_uri("postgresql://postgres:password@localhost:5432/mlflow")

# Set experiment
mlflow.set_experiment("bitwisers_ml_pipeline")

# Model registry
mlflow.set_registry_uri("postgresql://postgres:password@localhost:5432/mlflow")
EOF
    fi
    
    print_color $GREEN "✅ MLflow setup completed"
}

# Function to start services
start_services() {
    print_color $BLUE "🚀 Starting services..."
    
    # Start PostgreSQL
    if ! sudo systemctl is-active --quiet postgresql; then
        sudo systemctl start postgresql
    fi
    
    # Start services with docker-compose if available
    if command_exists docker-compose && [ -f "docker-compose.yml" ]; then
        print_color $BLUE "Starting services with Docker Compose..."
        docker-compose up -d
        print_color $GREEN "✅ Services started with Docker Compose"
    else
        print_color $YELLOW "⚠️ Docker Compose not found, starting services manually..."
        
        # Start MLflow server
        mlflow server \
            --host 0.0.0.0 \
            --port 5000 \
            --backend-store-uri postgresql://postgres:password@localhost:5432/mlflow \
            &
        
        # Start Redis
        if command_exists redis-server; then
            redis-server &
        fi
    fi
    
    print_color $GREEN "✅ Services started"
}

# Function to initialize database tables
init_database_tables() {
    print_color $BLUE "🗃️ Initializing database tables..."
    
    source venv/bin/activate
    python -m ml_pipeline.cli init-db
    
    print_color $GREEN "✅ Database tables initialized"
}

# Function to run health checks
health_check() {
    print_color $BLUE "🔍 Running health checks..."
    
    # Check database
    if pg_isready -h localhost -p 5432 > /dev/null 2>&1; then
        print_color $GREEN "✅ Database: OK"
    else
        print_color $RED "❌ Database: FAILED"
    fi
    
    # Check MLflow
    if curl -s http://localhost:5000/health > /dev/null 2>&1; then
        print_color $GREEN "✅ MLflow: OK"
    else
        print_color $RED "❌ MLflow: FAILED"
    fi
    
    # Check Redis
    if command_exists redis-cli; then
        if redis-cli ping > /dev/null 2>&1; then
            print_color $GREEN "✅ Redis: OK"
        else
            print_color $RED "❌ Redis: FAILED"
        fi
    fi
    
    print_color $BLUE "🏥 Health check completed"
}

# Function to create startup script
create_startup_script() {
    print_color $BLUE "📝 Creating startup script..."
    
    cat > start_pipeline.sh << 'EOF'
#!/bin/bash
# Bitwisers 2.0 ML Pipeline Startup Script

# Activate virtual environment
source venv/bin/activate

# Set environment variables
export DB_PASSWORD=your_password_here
export MLFLOW_TRACKING_URI=http://localhost:5000
export KAFKA_BOOTSTRAP_SERVERS=localhost:9092

# Start the pipeline
python -m ml_pipeline.cli start
EOF
    
    chmod +x start_pipeline.sh
    
    print_color $GREEN "✅ Startup script created (start_pipeline.sh)"
}

# Function to create monitoring scripts
create_monitoring_scripts() {
    print_color $BLUE "📊 Creating monitoring scripts..."
    
    # Status check script
    cat > scripts/check_status.sh << 'EOF'
#!/bin/bash
python -m ml_pipeline.cli status
EOF
    chmod +x scripts/check_status.sh
    
    # Health check script
    cat > scripts/health_check.sh << 'EOF'
#!/bin/bash
python -m ml_pipeline.cli health
EOF
    chmod +x scripts/health_check.sh
    
    # Model training script
    cat > scripts/train_models.sh << 'EOF'
#!/bin/bash
source venv/bin/activate
python -m ml_pipeline.cli train
EOF
    chmod +x scripts/train_models.sh
    
    print_color $GREEN "✅ Monitoring scripts created"
}

# Function to setup Grafana dashboards
setup_grafana() {
    print_color $BLUE "📈 Setting up Grafana..."
    
    # Create Grafana datasource config
    cat > grafana/provisioning/datasources/prometheus.yml << EOF
apiVersion: 1
datasources:
  - name: Prometheus
    type: prometheus
    access: proxy
    url: http://prometheus:9090
    isDefault: true
EOF
    
    print_color $GREEN "✅ Grafana configuration created"
}

# Function to setup Prometheus
setup_prometheus() {
    print_color $BLUE "📊 Setting up Prometheus..."
    
    cat > prometheus/prometheus.yml << EOF
global:
  scrape_interval: 15s

scrape_configs:
  - job_name: 'bitwisers-ml-pipeline'
    static_configs:
      - targets: ['ml-pipeline-api:8000']
  
  - job_name: 'prometheus'
    static_configs:
      - targets: ['localhost:9090']
EOF
    
    print_color $GREEN "✅ Prometheus configuration created"
}

# Function to run tests
run_tests() {
    print_color $BLUE "🧪 Running tests..."
    
    source venv/bin/activate
    python -m pytest tests/ -v || true
    
    print_color $GREEN "✅ Tests completed"
}

# Function to show final summary
show_summary() {
    print_color $GREEN "\n🎉 Bitwisers 2.0 ML Pipeline Setup Completed!\n"
    
    print_color $BLUE "📊 Service URLs:"
    echo "  • API Server: http://localhost:8000"
    echo "  • MLflow: http://localhost:5000"
    echo "  • Grafana: http://localhost:3000 (admin/admin)"
    echo "  • Prometheus: http://localhost:9090"
    echo "  • Redis Commander: http://localhost:8081"
    
    print_color $BLUE "\n🚀 Next Steps:"
    echo "  1. Update .env file with your database password"
    echo "  2. Start the pipeline: ./start_pipeline.sh"
    echo "  3. Access the API: http://localhost:8000"
    echo "  4. Monitor MLflow: http://localhost:5000"
    
    print_color $BLUE "\n📝 Available Commands:"
    echo "  • Check status: ./scripts/check_status.sh"
    echo "  • Health check: ./scripts/health_check.sh"
    echo "  • Train models: ./scripts/train_models.sh"
    echo "  • Manual CLI: python -m ml_pipeline.cli --help"
    
    print_color $YELLOW "\n⚠️ Important Notes:"
    echo "  • Update database password in .env file"
    echo "  • Ensure all services are running before starting the pipeline"
    echo "  • Check logs in the 'logs/' directory for troubleshooting"
    
    print_color $NC
}

# Main installation function
main() {
    print_color $PURPLE "\n🚀 Bitwisers 2.0 ML Pipeline Setup\n"
    
    case "${1:-full}" in
        "system")
            install_system_dependencies
            ;;
        "python")
            check_python
            create_venv
            install_python_dependencies
            ;;
        "database")
            setup_database
            init_database_tables
            ;;
        "services")
            setup_environment
            create_directories
            setup_mlflow
            setup_grafana
            setup_prometheus
            create_startup_script
            create_monitoring_scripts
            start_services
            ;;
        "full")
            install_system_dependencies
            check_python
            create_venv
            install_python_dependencies
            setup_environment
            create_directories
            setup_database
            init_database_tables
            setup_mlflow
            setup_grafana
            setup_prometheus
            create_startup_script
            create_monitoring_scripts
            start_services
            health_check
            show_summary
            ;;
        "quick")
            # Quick setup for development
            check_python
            create_venv
            install_python_dependencies
            setup_environment
            create_directories
            init_database_tables
            show_summary
            ;;
        *)
            echo "Bitwisers 2.0 ML Pipeline Setup Script"
            echo ""
            echo "Usage: $0 [COMMAND]"
            echo ""
            echo "Commands:"
            echo "  system      - Install system dependencies only"
            echo "  python      - Setup Python environment only"
            echo "  database    - Setup database only"
            echo "  services    - Setup services only"
            echo "  quick       - Quick setup for development"
            echo "  full        - Complete setup (default)"
            echo ""
            echo "Examples:"
            echo "  $0 quick              # Development setup"
            echo "  $0 system             # System dependencies only"
            echo "  $0 full               # Complete production setup"
            exit 1
            ;;
    esac
}

# Check for required commands
if [[ "${1:-}" != "system" && "${1:-}" != "--help" && "${1:-}" != "-h" ]]; then
    if ! command_exists python3; then
        print_color $RED "❌ Python 3 not found. Please install Python 3.9+ first."
        exit 1
    fi
fi

# Run main function with all arguments
main "$@"