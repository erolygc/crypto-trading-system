"""
Veri Ingestion Modülü
Real-time market verilerini TimescaleDB'ye aktarır
"""

import asyncio
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from kafka import KafkaConsumer, KafkaProducer
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
import yfinance as yf
import ccxt
import logging

from ..config.pipeline_config import pipeline_config
from ..utils.logging_utils import get_logger

logger = get_logger(__name__)

class DataIngestionEngine:
    """Ana veri ingestion motoru"""
    
    def __init__(self, config=None):
        self.config = config or pipeline_config
        self.engine = None
        self.session = None
        self.kafka_producer = None
        self.kafka_consumer = None
        self.exchanges = self._initialize_exchanges()
        
    def _initialize_exchanges(self) -> Dict:
        """Exchange entegrasyonlarını başlat"""
        exchanges = {}
        
        # CCXT exchange'leri
        try:
            exchanges['binance'] = ccxt.binance({
                'apiKey': 'your_api_key',
                'secret': 'your_secret',
                'sandbox': True,  # Production'da False olmalı
                'enableRateLimit': True,
            })
        except Exception as e:
            logger.warning(f"Binance exchange başlatılamadı: {e}")
            
        return exchanges
    
    def _initialize_database(self):
        """Veritabanı bağlantısını başlat"""
        try:
            database_url = self.config.get_database_url()
            self.engine = create_engine(database_url, pool_size=self.config.database.pool_size)
            Session = sessionmaker(bind=self.engine)
            self.session = Session()
            
            # TimescaleDB hypertable'ları oluştur
            self._create_timescale_tables()
            
        except Exception as e:
            logger.error(f"Veritabanı bağlantısı başarısız: {e}")
            raise
    
    def _initialize_kafka(self):
        """Kafka producer ve consumer'ı başlat"""
        try:
            kafka_config = self.config.get_kafka_config()
            
            self.kafka_producer = KafkaProducer(
                bootstrap_servers=kafka_config['bootstrap_servers'],
                value_serializer=lambda x: x.encode('utf-8') if isinstance(x, str) else x,
                key_serializer=lambda x: x.encode('utf-8') if isinstance(x, str) else x
            )
            
            self.kafka_consumer = KafkaConsumer(
                *kafka_config['bootstrap_servers'],
                group_id=kafka_config['group_id'],
                auto_offset_reset=kafka_config['auto_offset_reset'],
                value_deserializer=lambda x: x.decode('utf-8') if x else None
            )
            
        except Exception as e:
            logger.error(f"Kafka başlatma hatası: {e}")
            raise
    
    def _create_timescale_tables(self):
        """TimescaleDB hypertable'ları oluştur"""
        try:
            # Market data hypertable
            create_market_data_table = """
            CREATE TABLE IF NOT EXISTS market_data (
                time TIMESTAMPTZ NOT NULL,
                symbol VARCHAR(20) NOT NULL,
                timeframe VARCHAR(10) NOT NULL,
                open DECIMAL(20,8) NOT NULL,
                high DECIMAL(20,8) NOT NULL,
                low DECIMAL(20,8) NOT NULL,
                close DECIMAL(20,8) NOT NULL,
                volume DECIMAL(20,8) NOT NULL,
                vwap DECIMAL(20,8),
                primary key (time, symbol, timeframe)
            );
            """
            
            # Hypertable'a çevir
            create_hypertable = """
            SELECT create_hypertable('market_data', 'time', if_not_exists => TRUE);
            """
            
            # Index'ler
            create_indexes = [
                "CREATE INDEX IF NOT EXISTS idx_market_data_symbol ON market_data (symbol)",
                "CREATE INDEX IF NOT EXISTS idx_market_data_timeframe ON market_data (timeframe)",
                "CREATE INDEX IF NOT EXISTS idx_market_data_time ON market_data (time DESC)",
                "CREATE INDEX IF NOT EXISTS idx_market_data_symbol_time ON market_data (symbol, time DESC)"
            ]
            
            # TTL politikası (1 yıl sonra verileri sil)
            create_ttl_policy = """
            SELECT add_retention_policy('market_data', INTERVAL '1 year');
            """
            
            # Continuous aggregate (real-time OHLCV aggregation)
            create_continuous_agg = """
            CREATE MATERIALIZED VIEW IF NOT EXISTS market_data_1h
            WITH (timescaledb.continuous) AS
            SELECT time_bucket('1 hour', time) as time_bucket,
                   symbol,
                   first(open, time) as open,
                   max(high) as high,
                   min(low) as low,
                   last(close, time) as close,
                   sum(volume) as volume,
                   last(vwap, time) as vwap
            FROM market_data
            GROUP BY time_bucket, symbol
            WITH NO DATA;
            """
            
            # Continuous aggregate refresh policy
            create_refresh_policy = """
            SELECT add_continuous_aggregate_policy('market_data_1h',
                start_offset => INTERVAL '2 hours',
                end_offset => INTERVAL '1 hour',
                schedule_interval => INTERVAL '1 hour');
            """
            
            # Tüm SQL'leri çalıştır
            sql_commands = [
                create_market_data_table,
                create_hypertable,
                *create_indexes,
                create_ttl_policy,
                create_continuous_agg,
                create_refresh_policy
            ]
            
            for sql in sql_commands:
                self.session.execute(text(sql))
            
            self.session.commit()
            logger.info("TimescaleDB tabloları başarıyla oluşturuldu")
            
        except Exception as e:
            logger.error(f"TimescaleDB tablo oluşturma hatası: {e}")
            self.session.rollback()
            raise
    
    async def fetch_market_data(self, symbols: List[str], timeframes: List[str] = None, limit: int = 1000) -> pd.DataFrame:
        """Piyasa verilerini al"""
        if timeframes is None:
            timeframes = ['1m', '5m', '15m', '1h', '4h', '1d']
        
        all_data = []
        
        for symbol in symbols:
            for timeframe in timeframes:
                try:
                    # Binance API'den veri al
                    if 'binance' in self.exchanges:
                        ohlcv = await self._fetch_binance_ohlcv(symbol, timeframe, limit)
                        if ohlcv is not None:
                            ohlcv['symbol'] = symbol
                            ohlcv['timeframe'] = timeframe
                            all_data.append(ohlcv)
                    
                    # YFinance'den veri al (backup)
                    yf_data = await self._fetch_yfinance_data(symbol, timeframe, limit)
                    if yf_data is not None and len(yf_data) == 0:
                        yf_data['symbol'] = symbol
                        yf_data['timeframe'] = timeframe
                        all_data.append(yf_data)
                        
                except Exception as e:
                    logger.error(f"{symbol} {timeframe} için veri alınamadı: {e}")
                    continue
        
        if not all_data:
            logger.warning("Hiç veri alınamadı")
            return pd.DataFrame()
        
        combined_data = pd.concat(all_data, ignore_index=True)
        combined_data['timestamp'] = pd.to_datetime(combined_data['timestamp'])
        
        return combined_data
    
    async def _fetch_binance_ohlcv(self, symbol: str, timeframe: str, limit: int) -> Optional[pd.DataFrame]:
        """Binance API'den OHLCV verisi al"""
        try:
            exchange = self.exchanges['binance']
            
            # Binance timeframe formatına çevir
            binance_timeframe = self._convert_to_binance_timeframe(timeframe)
            
            ohlcv = exchange.fetch_ohlcv(symbol, binance_timeframe, limit=limit)
            
            if not ohlcv:
                return None
            
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            
            # VWAP hesapla
            df['typical_price'] = (df['high'] + df['low'] + df['close']) / 3
            df['vwap'] = (df['typical_price'] * df['volume']).cumsum() / df['volume'].cumsum()
            
            return df
            
        except Exception as e:
            logger.error(f"Binance veri alma hatası {symbol}: {e}")
            return None
    
    async def _fetch_yfinance_data(self, symbol: str, timeframe: str, limit: int) -> Optional[pd.DataFrame]:
        """YFinance'den veri al"""
        try:
            ticker = yf.Ticker(symbol.replace('/', ''))
            
            # YFinance period hesapla
            period_map = {
                '1m': '1d', '5m': '5d', '15m': '15d',
                '1h': '1mo', '4h': '6mo', '1d': '2y'
            }
            period = period_map.get(timeframe, '1mo')
            
            hist = ticker.history(period=period, interval=timeframe)
            
            if hist.empty:
                return None
            
            df = hist.reset_index()
            df.columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume', 'dividends', 'stock_splits']
            df = df[['timestamp', 'open', 'high', 'low', 'close', 'volume']]
            
            # VWAP hesapla
            df['typical_price'] = (df['high'] + df['low'] + df['close']) / 3
            df['vwap'] = (df['typical_price'] * df['volume']).cumsum() / df['volume'].cumsum()
            
            return df
            
        except Exception as e:
            logger.error(f"YFinance veri alma hatası {symbol}: {e}")
            return None
    
    def _convert_to_binance_timeframe(self, timeframe: str) -> str:
        """Timeframe formatını Binance API'sine çevir"""
        conversion_map = {
            '1m': '1m', '5m': '5m', '15m': '15m',
            '1h': '1h', '4h': '4h', '1d': '1d'
        }
        return conversion_map.get(timeframe, '1h')
    
    async def store_market_data(self, data: pd.DataFrame) -> bool:
        """Verileri TimescaleDB'ye kaydet"""
        try:
            if data.empty:
                logger.warning("Kaydedilecek veri yok")
                return False
            
            # Veri validasyonu
            data = self._validate_market_data(data)
            
            if data.empty:
                logger.warning("Validasyon sonrası veri kalmadı")
                return False
            
            # Bulk insert
            data.to_sql('market_data', self.engine, if_exists='append', index=False, method='multi')
            
            logger.info(f"{len(data)} kayıt veritabanına kaydedildi")
            
            # Kafka'ya publish et
            self._publish_to_kafka('market_data', data.to_dict('records'))
            
            return True
            
        except Exception as e:
            logger.error(f"Veri kaydetme hatası: {e}")
            return False
    
    def _validate_market_data(self, data: pd.DataFrame) -> pd.DataFrame:
        """Piyasa verilerini validate et"""
        required_columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume', 'symbol', 'timeframe']
        
        # Gerekli sütunları kontrol et
        missing_columns = [col for col in required_columns if col not in data.columns]
        if missing_columns:
            logger.error(f"Eksik sütunlar: {missing_columns}")
            return pd.DataFrame()
        
        # Null değerleri temizle
        data = data.dropna(subset=['timestamp', 'open', 'high', 'low', 'close'])
        
        # OHLC validasyonu
        valid_mask = (
            (data['high'] >= data['low']) &
            (data['high'] >= data['open']) &
            (data['high'] >= data['close']) &
            (data['low'] <= data['open']) &
            (data['low'] <= data['close']) &
            (data['volume'] > 0)
        )
        
        data = data[valid_mask]
        
        # Duplikasyon kontrolü
        data = data.drop_duplicates(subset=['timestamp', 'symbol', 'timeframe'])
        
        return data
    
    def _publish_to_kafka(self, topic: str, data: List[Dict]):
        """Kafka'ya veri gönder"""
        try:
            for record in data:
                self.kafka_producer.send(topic, value=str(record))
            
            self.kafka_producer.flush()
            logger.debug(f"{len(data)} kayıt {topic} topic'ine gönderildi")
            
        except Exception as e:
            logger.error(f"Kafka publish hatası: {e}")
    
    async def start_real_time_ingestion(self, symbols: List[str]):
        """Real-time veri ingestion'ı başlat"""
        try:
            logger.info("Real-time veri ingestion başlatılıyor...")
            
            # DataIngestion ve Kafka'yı başlat
            self._initialize_database()
            self._initialize_kafka()
            
            # Continuous data fetching loop
            while True:
                try:
                    # Market verilerini al
                    data = await self.fetch_market_data(symbols, limit=100)
                    
                    # Verileri kaydet
                    if not data.empty:
                        await self.store_market_data(data)
                    
                    # 1 dakika bekle
                    await asyncio.sleep(60)
                    
                except Exception as e:
                    logger.error(f"Ingestion loop hatası: {e}")
                    await asyncio.sleep(5)  # Hata durumunda kısa bekle
                    
        except KeyboardInterrupt:
            logger.info("Veri ingestion durduruldu")
        except Exception as e:
            logger.error(f"Real-time ingestion hatası: {e}")
            raise
    
    def cleanup(self):
        """Kaynakları temizle"""
        try:
            if self.session:
                self.session.close()
            if self.kafka_producer:
                self.kafka_producer.close()
            if self.kafka_consumer:
                self.kafka_consumer.close()
            logger.info("Veri ingestion temizlik tamamlandı")
        except Exception as e:
            logger.error(f"Temizlik hatası: {e}")

# Singleton instance
data_ingestion_engine = DataIngestionEngine()