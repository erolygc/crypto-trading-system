"""
Feature Engineering Modülü
Real-time technical indicators ve feature generation
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Union
import ta
from sqlalchemy import create_engine, text
import asyncio
import logging

from ..config.pipeline_config import pipeline_config
from ..utils.logging_utils import get_logger

logger = get_logger(__name__)

class TechnicalIndicators:
    """Technical Indicator hesaplama sınıfı"""
    
    @staticmethod
    def sma(data: pd.Series, window: int) -> pd.Series:
        """Simple Moving Average"""
        return data.rolling(window=window).mean()
    
    @staticmethod
    def ema(data: pd.Series, window: int) -> pd.Series:
        """Exponential Moving Average"""
        return data.ewm(span=window).mean()
    
    @staticmethod
    def rsi(data: pd.Series, window: int = 14) -> pd.Series:
        """Relative Strength Index"""
        delta = data.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))
    
    @staticmethod
    def macd(data: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> Dict[str, pd.Series]:
        """MACD Indicator"""
        ema_fast = data.ewm(span=fast).mean()
        ema_slow = data.ewm(span=slow).mean()
        macd_line = ema_fast - ema_slow
        signal_line = macd_line.ewm(span=signal).mean()
        histogram = macd_line - signal_line
        return {
            'macd': macd_line,
            'signal': signal_line,
            'histogram': histogram
        }
    
    @staticmethod
    def bollinger_bands(data: pd.Series, window: int = 20, num_std: float = 2) -> Dict[str, pd.Series]:
        """Bollinger Bands"""
        sma = data.rolling(window=window).mean()
        std = data.rolling(window=window).std()
        upper = sma + (std * num_std)
        lower = sma - (std * num_std)
        return {
            'upper': upper,
            'middle': sma,
            'lower': lower,
            'width': upper - lower,
            'position': (data - lower) / (upper - lower)
        }
    
    @staticmethod
    def stochastic(high: pd.Series, low: pd.Series, close: pd.Series, k_window: int = 14, d_window: int = 3) -> Dict[str, pd.Series]:
        """Stochastic Oscillator"""
        lowest_low = low.rolling(window=k_window).min()
        highest_high = high.rolling(window=k_window).max()
        k_percent = 100 * ((close - lowest_low) / (highest_high - lowest_low))
        d_percent = k_percent.rolling(window=d_window).mean()
        return {
            'k': k_percent,
            'd': d_percent
        }
    
    @staticmethod
    def atr(high: pd.Series, low: pd.Series, close: pd.Series, window: int = 14) -> pd.Series:
        """Average True Range"""
        high_low = high - low
        high_close = np.abs(high - close.shift())
        low_close = np.abs(low - close.shift())
        true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        return true_range.rolling(window=window).mean()
    
    @staticmethod
    def obv(close: pd.Series, volume: pd.Series) -> pd.Series:
        """On-Balance Volume"""
        obv = pd.Series(index=close.index, dtype=float)
        obv.iloc[0] = volume.iloc[0]
        
        for i in range(1, len(close)):
            if close.iloc[i] > close.iloc[i-1]:
                obv.iloc[i] = obv.iloc[i-1] + volume.iloc[i]
            elif close.iloc[i] < close.iloc[i-1]:
                obv.iloc[i] = obv.iloc[i-1] - volume.iloc[i]
            else:
                obv.iloc[i] = obv.iloc[i-1]
        
        return obv

class FeatureEngineeringEngine:
    """Ana feature engineering motoru"""
    
    def __init__(self, config=None):
        self.config = config or pipeline_config
        self.engine = None
        self.technical_indicators = TechnicalIndicators()
        
    def _initialize_database(self):
        """Veritabanı bağlantısını başlat"""
        try:
            database_url = self.config.get_database_url()
            self.engine = create_engine(database_url)
        except Exception as e:
            logger.error(f"Veritabanı bağlantısı başarısız: {e}")
            raise
    
    async def generate_technical_features(self, symbol: str, timeframe: str = '1h', periods: List[int] = None) -> pd.DataFrame:
        """Technical indicators hesapla"""
        if periods is None:
            periods = self.config.features.lookback_periods
        
        try:
            # Verileri al
            data = await self._fetch_market_data(symbol, timeframe, max(periods) + 100)
            
            if data.empty:
                logger.warning(f"{symbol} için veri bulunamadı")
                return pd.DataFrame()
            
            # Technical indicators hesapla
            features = self._calculate_all_indicators(data)
            
            # Lag features oluştur
            features = self._create_lag_features(features)
            
            # Rolling statistics
            features = self._create_rolling_features(features)
            
            # Price action features
            features = self._create_price_action_features(features)
            
            # Volume features
            features = self._create_volume_features(features)
            
            # Market microstructure features
            features = self._create_microstructure_features(features)
            
            return features
            
        except Exception as e:
            logger.error(f"Feature generation hatası {symbol}: {e}")
            return pd.DataFrame()
    
    def _calculate_all_indicators(self, data: pd.DataFrame) -> pd.DataFrame:
        """Tüm technical indicators'ları hesapla"""
        features = data.copy()
        
        # Basic OHLCV features
        features['returns'] = data['close'].pct_change()
        features['log_returns'] = np.log(data['close'] / data['close'].shift(1))
        
        # Moving averages
        for period in [7, 14, 21, 30, 50, 100]:
            features[f'sma_{period}'] = self.technical_indicators.sma(data['close'], period)
            features[f'ema_{period}'] = self.technical_indicators.ema(data['close'], period)
        
        # RSI
        features['rsi_14'] = self.technical_indicators.rsi(data['close'], 14)
        features['rsi_21'] = self.technical_indicators.rsi(data['close'], 21)
        
        # MACD
        macd = self.technical_indicators.macd(data['close'])
        features['macd'] = macd['macd']
        features['macd_signal'] = macd['signal']
        features['macd_histogram'] = macd['histogram']
        
        # Bollinger Bands
        bb = self.technical_indicators.bollinger_bands(data['close'])
        features['bb_upper'] = bb['upper']
        features['bb_middle'] = bb['middle']
        features['bb_lower'] = bb['lower']
        features['bb_width'] = bb['width']
        features['bb_position'] = bb['position']
        
        # Stochastic
        stoch = self.technical_indicators.stochastic(data['high'], data['low'], data['close'])
        features['stoch_k'] = stoch['k']
        features['stoch_d'] = stoch['d']
        
        # ATR
        features['atr_14'] = self.technical_indicators.atr(data['high'], data['low'], data['close'], 14)
        features['atr_21'] = self.technical_indicators.atr(data['high'], data['low'], data['close'], 21)
        
        # OBV
        features['obv'] = self.technical_indicators.obv(data['close'], data['volume'])
        
        # VWAP deviation
        if 'vwap' in data.columns:
            features['vwap_deviation'] = (data['close'] - data['vwap']) / data['vwap']
        
        return features
    
    def _create_lag_features(self, features: pd.DataFrame, lags: List[int] = None) -> pd.DataFrame:
        """Lag features oluştur"""
        if lags is None:
            lags = [1, 2, 3, 5, 10, 20]
        
        base_features = ['close', 'volume', 'returns', 'rsi_14', 'macd', 'atr_14']
        
        for feature_name in base_features:
            if feature_name in features.columns:
                for lag in lags:
                    features[f'{feature_name}_lag_{lag}'] = features[feature_name].shift(lag)
        
        return features
    
    def _create_rolling_features(self, features: pd.DataFrame) -> pd.DataFrame:
        """Rolling statistics oluştur"""
        windows = [5, 10, 20, 50]
        
        for window in windows:
            # Price volatility
            features[f'volatility_{window}'] = features['returns'].rolling(window).std()
            
            # Volume statistics
            if 'volume' in features.columns:
                features[f'volume_mean_{window}'] = features['volume'].rolling(window).mean()
                features[f'volume_std_{window}'] = features['volume'].rolling(window).std()
                features[f'volume_ratio_{window}'] = features['volume'] / features[f'volume_mean_{window}']
            
            # Price range
            features[f'high_low_ratio_{window}'] = features['high'].rolling(window).max() / features['low'].rolling(window).min()
            
            # Returns distribution
            features[f'skewness_{window}'] = features['returns'].rolling(window).skew()
            features[f'kurtosis_{window}'] = features['returns'].rolling(window).kurt()
        
        return features
    
    def _create_price_action_features(self, features: pd.DataFrame) -> pd.DataFrame:
        """Price action based features"""
        # Gap analysis
        features['gap_up'] = (features['open'] > features['close'].shift(1)).astype(int)
        features['gap_down'] = (features['open'] < features['close'].shift(1)).astype(int)
        
        # Body size
        features['body_size'] = np.abs(features['close'] - features['open'])
        features['body_ratio'] = features['body_size'] / features['close']
        
        # Upper and lower shadows
        features['upper_shadow'] = features['high'] - np.maximum(features['open'], features['close'])
        features['lower_shadow'] = np.minimum(features['open'], features['close']) - features['low']
        features['shadow_ratio'] = (features['upper_shadow'] + features['lower_shadow']) / features['body_size']
        
        # Candlestick patterns (simplified)
        features['doji'] = (features['body_size'] / (features['high'] - features['low']) < 0.1).astype(int)
        features['hammer'] = ((features['lower_shadow'] > 2 * features['body_size']) & 
                             (features['upper_shadow'] < features['body_size'])).astype(int)
        
        # Support and resistance levels
        features['support_resistance_ratio'] = features['high'].rolling(20).max() / features['low'].rolling(20).min()
        
        return features
    
    def _create_volume_features(self, features: pd.DataFrame) -> pd.DataFrame:
        """Volume based features"""
        if 'volume' not in features.columns:
            return features
        
        # Volume price trends
        features['volume_weighted_price'] = (features['close'] * features['volume']).rolling(20).sum() / features['volume'].rolling(20).sum()
        features['volume_price_trend'] = ((features['close'] - features['close'].shift(10)) * features['volume']).rolling(10).sum()
        
        # On-Balance Volume features
        features['obv_sma_ratio'] = features['obv'] / features['obv'].rolling(20).mean()
        
        # Volume momentum
        features['volume_momentum'] = features['volume'].pct_change(5)
        
        # Accumulation/Distribution Line (simplified)
        money_flow = ((features['close'] - features['low']) - (features['high'] - features['close'])) / (features['high'] - features['low']) * features['volume']
        features['ad_line'] = money_flow.cumsum()
        features['ad_ratio'] = features['ad_line'] / features['ad_line'].rolling(20).mean()
        
        return features
    
    def _create_microstructure_features(self, features: pd.DataFrame) -> pd.DataFrame:
        """Market microstructure features"""
        # Tick-based features
        features['price_change'] = features['close'].diff()
        features['price_change_ratio'] = features['price_change'] / features['close'].shift(1)
        
        # Volatility measures
        features['intraday_range'] = (features['high'] - features['low']) / features['open']
        features['overnight_return'] = (features['open'] - features['close'].shift(1)) / features['close'].shift(1)
        
        # Market efficiency
        features['close_open_ratio'] = features['close'] / features['open']
        features['high_close_ratio'] = features['high'] / features['close']
        features['low_close_ratio'] = features['low'] / features['close']
        
        # Mean reversion indicators
        features['distance_from_sma_20'] = (features['close'] - features['sma_20']) / features['sma_20']
        features['distance_from_sma_50'] = (features['close'] - features['sma_50']) / features['sma_50']
        
        return features
    
    async def _fetch_market_data(self, symbol: str, timeframe: str, limit: int) -> pd.DataFrame:
        """Market verilerini veritabanından al"""
        try:
            query = """
            SELECT time as timestamp, open, high, low, close, volume, vwap
            FROM market_data 
            WHERE symbol = :symbol AND timeframe = :timeframe
            ORDER BY time DESC
            LIMIT :limit
            """
            
            with self.engine.connect() as conn:
                result = conn.execute(text(query), {
                    'symbol': symbol,
                    'timeframe': timeframe,
                    'limit': limit
                })
                
                data = pd.DataFrame(result.fetchall(), columns=result.keys())
                
                if not data.empty:
                    data['timestamp'] = pd.to_datetime(data['timestamp'])
                    data = data.sort_values('timestamp').reset_index(drop=True)
                
                return data
                
        except Exception as e:
            logger.error(f"Veri alma hatası: {e}")
            return pd.DataFrame()
    
    async def generate_features_for_symbols(self, symbols: List[str]) -> Dict[str, pd.DataFrame]:
        """Birden fazla sembol için feature generation"""
        features_dict = {}
        
        for symbol in symbols:
            logger.info(f"{symbol} için feature generation başlatılıyor...")
            
            try:
                features = await self.generate_technical_features(symbol)
                
                if not features.empty:
                    features_dict[symbol] = features
                    logger.info(f"{symbol} için {len(features.columns)} feature oluşturuldu")
                else:
                    logger.warning(f"{symbol} için feature oluşturulamadı")
                
                # Her sembol arasında kısa bekleme
                await asyncio.sleep(1)
                
            except Exception as e:
                logger.error(f"{symbol} için feature generation hatası: {e}")
                continue
        
        return features_dict
    
    def store_features(self, features: pd.DataFrame, symbol: str, timeframe: str) -> bool:
        """Feature'ları veritabanına kaydet"""
        try:
            if features.empty:
                return False
            
            # Feature metadata ekle
            features['symbol'] = symbol
            features['timeframe'] = timeframe
            features['created_at'] = datetime.now()
            
            # Veritabanına kaydet
            features.to_sql('features', self.engine, if_exists='append', index=False, method='multi')
            
            logger.info(f"{symbol} {timeframe} için {len(features)} feature kaydedildi")
            return True
            
        except Exception as e:
            logger.error(f"Feature kaydetme hatası: {e}")
            return False

# Singleton instance
feature_engineering_engine = FeatureEngineeringEngine()