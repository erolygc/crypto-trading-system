"""
Data Ingestion Module
Real-time market data ingestion
"""

from .ingestion import DataIngestionEngine, data_ingestion_engine

__all__ = [
    'DataIngestionEngine',
    'data_ingestion_engine'
]