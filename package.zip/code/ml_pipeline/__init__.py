"""
Bitwisers 2.0 ML Pipeline
Kapsamlı Machine Learning Pipeline
"""

__version__ = "1.0.0"
__author__ = "Bitwisers Team"
__description__ = "Comprehensive ML Pipeline for Bitwisers Trading System"

# Ana import'lar
from .config.pipeline_config import pipeline_config
from .utils.orchestrator import ml_pipeline
from .utils.logging_utils import get_logger

__all__ = [
    'pipeline_config',
    'ml_pipeline', 
    'get_logger'
]