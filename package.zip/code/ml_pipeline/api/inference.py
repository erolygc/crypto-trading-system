"""
Real-time Model Inference Engine
FastAPI ile model serving ve real-time prediction
"""

import mlflow
import mlflow.sklearn
import mlflow.tensorflow
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any, Union
import tensorflow as tf
import pickle
from sqlalchemy import create_engine, text
import asyncio
import json
from kafka import KafkaConsumer, KafkaProducer
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn
import logging
import redis
import joblib

from ..config.pipeline_config import pipeline_config
from ..utils.logging_utils import get_logger

logger = get_logger(__name__)

# FastAPI app
app = FastAPI(
    title="Bitwisers ML Inference API",
    description="Real-time model inference service",
    version="1.0.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Model cache
model_cache = {}
preprocessor_cache = {}
redis_client = redis.Redis(host='localhost', port=6379, db=0)

class PredictionRequest(BaseModel):
    """Prediction request model"""
    symbol: str
    timeframe: str = "1h"
    features: Optional[List[float]] = None
    return_raw_prediction: bool = False

class PredictionResponse(BaseModel):
    """Prediction response model"""
    symbol: str
    timeframe: str
    prediction: float
    confidence: float
    timestamp: datetime
    model_version: str
    features_used: int

class ModelInferenceEngine:
    """Ana model inference engine"""
    
    def __init__(self, config=None):
        self.config = config or pipeline_config
        self.mlflow_client = None
        self.database_engine = None
        self.kafka_producer = None
        self.feature_engineering_engine = None
        
    def initialize_services(self):
        """Gerekli servisleri başlat"""
        try:
            # MLflow client
            mlflow.set_tracking_uri(self.config.get_mlflow_tracking_uri())
            self.mlflow_client = mlflow.tracking.MlflowClient()
            
            # Database
            database_url = self.config.get_database_url()
            self.database_engine = create_engine(database_url)
            
            # Kafka producer
            kafka_config = self.config.get_kafka_config()
            self.kafka_producer = KafkaProducer(
                bootstrap_servers=kafka_config['bootstrap_servers'],
                value_serializer=lambda x: json.dumps(x).encode('utf-8')
            )
            
            # Load active models
            self._load_active_models()
            
            logger.info("Model inference engine başlatıldı")
            
        except Exception as e:
            logger.error(f"Inference engine başlatma hatası: {e}")
            raise
    
    def _load_active_models(self):
        """Aktif modelleri yükle"""
        try:
            # MLflow'dan production model'leri al
            models = self.mlflow_client.search_registered_models()
            
            for model in models:
                for version in model.latest_versions:
                    if version.current_stage == "Production":
                        model_name = version.name
                        model_version = version.version
                        
                        # Model'i indir
                        model_path = mlflow.artifacts.download_artifacts(
                            artifact_uri=version.source
                        )
                        
                        # Model tipini belirle
                        if 'tensorflow' in str(mlflow.get_run(version.run_id).data.params):
                            # TensorFlow model
                            tf_model = tf.saved_model.load(f"{model_path}/model")
                            model_cache[model_name] = {
                                'model': tf_model,
                                'type': 'tensorflow',
                                'version': model_version
                            }
                        else:
                            # Sklearn model
                            sklearn_model = mlflow.sklearn.load_model(f"{model_path}/model")
                            model_cache[model_name] = {
                                'model': sklearn_model,
                                'type': 'sklearn',
                                'version': model_version
                            }
                        
                        # Preprocessor'ı yükle
                        try:
                            preprocessor_path = f"{model_path}/preprocessor.pkl"
                            with open(preprocessor_path, 'rb') as f:
                                preprocessor = pickle.load(f)
                            preprocessor_cache[model_name] = preprocessor
                        except:
                            logger.warning(f"Preprocessor bulunamadı: {model_name}")
                        
                        logger.info(f"Model yüklendi: {model_name} v{model_version}")
            
        except Exception as e:
            logger.error(f"Model yükleme hatası: {e}")
    
    async def get_latest_features(self, symbol: str, timeframe: str) -> Optional[np.ndarray]:
        """En son feature'ları al"""
        try:
            query = """
            SELECT * FROM features 
            WHERE symbol = :symbol AND timeframe = :timeframe
            ORDER BY timestamp DESC
            LIMIT 1
            """
            
            with self.database_engine.connect() as conn:
                result = conn.execute(text(query), {
                    'symbol': symbol,
                    'timeframe': timeframe
                })
                
                row = result.fetchone()
                if row:
                    # Feature columns
                    feature_cols = [col for col in row.keys() 
                                  if col not in ['timestamp', 'symbol', 'timeframe', 'created_at']]
                    features = [getattr(row, col) for col in feature_cols]
                    return np.array(features)
            
            return None
            
        except Exception as e:
            logger.error(f"Feature alma hatası: {e}")
            return None
    
    async def generate_features(self, symbol: str, timeframe: str) -> Optional[np.ndarray]:
        """Real-time feature generation"""
        try:
            # Feature engineering engine'i import et
            from ..data.feature_engineering import feature_engineering_engine
            
            features_df = await feature_engineering_engine.generate_technical_features(symbol, timeframe)
            
            if features_df.empty:
                return None
            
            # En son row'u al
            latest_features = features_df.iloc[-1]
            
            # Feature columns
            feature_cols = [col for col in latest_features.index 
                          if col not in ['timestamp', 'symbol', 'timeframe', 'created_at']]
            features = latest_features[feature_cols].values
            
            return features
            
        except Exception as e:
            logger.error(f"Feature generation hatası: {e}")
            return None
    
    async def make_prediction(self, symbol: str, timeframe: str, model_name: str = None) -> Dict[str, Any]:
        """Prediction yap"""
        try:
            # Model seçimi
            if model_name is None:
                model_name = self._select_best_model(symbol, timeframe)
            
            if model_name not in model_cache:
                raise HTTPException(status_code=404, detail=f"Model bulunamadı: {model_name}")
            
            # Cache'den feature'ları kontrol et
            cache_key = f"features:{symbol}:{timeframe}"
            features = redis_client.get(cache_key)
            
            if features is None:
                # Yeni feature generation
                features = await self.generate_features(symbol, timeframe)
                if features is None:
                    raise HTTPException(status_code=400, detail="Feature generation başarısız")
                
                # Cache'e kaydet (5 dakika)
                redis_client.setex(cache_key, 300, pickle.dumps(features))
            else:
                features = pickle.loads(features)
            
            # Model ve preprocessor'ı al
            model_info = model_cache[model_name]
            model = model_info['model']
            model_type = model_info['type']
            model_version = model_info['version']
            
            preprocessor = preprocessor_cache.get(model_name)
            
            # Feature preprocessing
            features_reshaped = features.reshape(1, -1)
            
            if preprocessor is not None:
                features_processed = preprocessor.transform(features_reshaped)
            else:
                features_processed = features_reshaped
            
            # Prediction
            if model_type == 'tensorflow':
                # TensorFlow model için sequence format gerekli
                sequence_length = 60  # Model config'den alınmalı
                features_sequence = features_processed.reshape(1, 1, -1)  # Sequence length = 1
                prediction = model(features_sequence).numpy().flatten()[0]
                
                # Confidence score (basit yaklaşım)
                confidence = 0.75  # MLflow'dan model performance metric'i alınabilir
                
            else:  # sklearn
                prediction = model.predict(features_processed)[0]
                confidence = 0.80
            
            # Result hazırla
            result = {
                'symbol': symbol,
                'timeframe': timeframe,
                'prediction': float(prediction),
                'confidence': float(confidence),
                'timestamp': datetime.now(),
                'model_name': model_name,
                'model_version': model_version,
                'features_count': len(features)
            }
            
            # Kafka'ya publish et
            self._publish_prediction(result)
            
            return result
            
        except Exception as e:
            logger.error(f"Prediction hatası: {e}")
            raise HTTPException(status_code=500, detail=str(e))
    
    def _select_best_model(self, symbol: str, timeframe: str) -> str:
        """En uygun model'i seç"""
        # Model performance'a göre seçim yapılabilir
        # Şimdilik default model
        default_models = list(model_cache.keys())
        return default_models[0] if default_models else 'bitwisers_lstm_v1'
    
    def _publish_prediction(self, prediction_result: Dict[str, Any]):
        """Prediction sonucunu Kafka'ya gönder"""
        try:
            topic = self.config.kafka.topic_predictions
            
            message = {
                'type': 'prediction',
                'data': prediction_result,
                'timestamp': datetime.now().isoformat()
            }
            
            self.kafka_producer.send(topic, value=message)
            self.kafka_producer.flush()
            
        except Exception as e:
            logger.error(f"Kafka publish hatası: {e}")
    
    async def batch_prediction(self, symbols: List[str], timeframe: str = "1h") -> List[Dict[str, Any]]:
        """Multiple symbol için batch prediction"""
        results = []
        
        for symbol in symbols:
            try:
                result = await self.make_prediction(symbol, timeframe)
                results.append(result)
                
                # Rate limiting
                await asyncio.sleep(0.1)
                
            except Exception as e:
                logger.error(f"{symbol} prediction hatası: {e}")
                continue
        
        return results
    
    def get_model_status(self) -> Dict[str, Any]:
        """Model durumunu kontrol et"""
        status = {
            'loaded_models': list(model_cache.keys()),
            'timestamp': datetime.now(),
            'cache_size': len(model_cache)
        }
        
        return status

# FastAPI endpoints
inference_engine = ModelInferenceEngine()

@app.on_event("startup")
async def startup_event():
    """Startup event"""
    inference_engine.initialize_services()

@app.get("/")
async def root():
    """Health check"""
    return {
        "service": "Bitwisers ML Inference API",
        "status": "healthy",
        "timestamp": datetime.now(),
        "models": inference_engine.get_model_status()
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "ok",
        "timestamp": datetime.now(),
        "models_loaded": len(model_cache)
    }

@app.get("/models")
async def get_models():
    """Mevcut modelleri listele"""
    return inference_engine.get_model_status()

@app.post("/predict", response_model=PredictionResponse)
async def predict(request: PredictionRequest):
    """Single prediction endpoint"""
    try:
        result = await inference_engine.make_prediction(
            symbol=request.symbol,
            timeframe=request.timeframe,
            model_name=None
        )
        
        return PredictionResponse(
            symbol=result['symbol'],
            timeframe=result['timeframe'],
            prediction=result['prediction'],
            confidence=result['confidence'],
            timestamp=result['timestamp'],
            model_version=result['model_version'],
            features_used=result['features_count']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/predict/batch")
async def batch_predict(request: Dict[str, List[str]]):
    """Batch prediction endpoint"""
    symbols = request.get('symbols', [])
    timeframe = request.get('timeframe', '1h')
    
    if not symbols:
        raise HTTPException(status_code=400, detail="symbols listesi gerekli")
    
    results = await inference_engine.batch_prediction(symbols, timeframe)
    
    return {
        'predictions': results,
        'count': len(results),
        'timestamp': datetime.now()
    }

@app.get("/predict/{symbol}")
async def predict_symbol(symbol: str, timeframe: str = "1h"):
    """Symbol için direct prediction"""
    result = await inference_engine.make_prediction(symbol, timeframe)
    return result

@app.get("/features/{symbol}")
async def get_latest_features(symbol: str, timeframe: str = "1h"):
    """Symbol için en son feature'ları getir"""
    features = await inference_engine.get_latest_features(symbol, timeframe)
    
    if features is None:
        raise HTTPException(status_code=404, detail="Feature bulunamadı")
    
    return {
        'symbol': symbol,
        'timeframe': timeframe,
        'features': features.tolist(),
        'count': len(features),
        'timestamp': datetime.now()
    }

@app.post("/model/refresh")
async def refresh_models(background_tasks: BackgroundTasks):
    """Modelleri yenile"""
    background_tasks.add_task(inference_engine._load_active_models)
    return {"message": "Model refresh başlatıldı"}

if __name__ == "__main__":
    uvicorn.run(
        "inference:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )