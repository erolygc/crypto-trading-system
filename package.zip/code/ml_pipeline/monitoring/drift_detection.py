"""
Model Monitoring ve Drift Detection
Real-time model performance monitoring ve data drift detection
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
import mlflow
from sqlalchemy import create_engine, text
import asyncio
from kafka import KafkaConsumer
import logging
import statistics
from scipy import stats
from sklearn.metrics import mean_squared_error, mean_absolute_error
import warnings
warnings.filterwarnings('ignore')

from ..config.pipeline_config import pipeline_config
from ..utils.logging_utils import get_logger

logger = get_logger(__name__)

class DataDriftDetector:
    """Data drift detection sınıfı"""
    
    def __init__(self, significance_level: float = 0.05):
        self.significance_level = significance_level
        self.baseline_stats = {}
        
    def update_baseline(self, feature_name: str, baseline_data: np.ndarray):
        """Baseline istatistikleri güncelle"""
        self.baseline_stats[feature_name] = {
            'mean': np.mean(baseline_data),
            'std': np.std(baseline_data),
            'min': np.min(baseline_data),
            'max': np.max(baseline_data),
            'q25': np.percentile(baseline_data, 25),
            'q75': np.percentile(baseline_data, 75),
            'skewness': stats.skew(baseline_data),
            'kurtosis': stats.kurtosis(baseline_data)
        }
    
    def detect_drift(self, feature_name: str, current_data: np.ndarray) -> Dict[str, Any]:
        """Data drift detect et"""
        if feature_name not in self.baseline_stats:
            return {'drift_detected': False, 'reason': 'No baseline data'}
        
        baseline = self.baseline_stats[feature_name]
        drift_results = {}
        
        # Kolmogorov-Smirnov test
        ks_statistic, ks_p_value = stats.ks_1samp(current_data, baseline['mean'])
        drift_results['ks_test'] = {
            'statistic': ks_statistic,
            'p_value': ks_p_value,
            'drift': ks_p_value < self.significance_level
        }
        
        # Mean shift test
        current_mean = np.mean(current_data)
        mean_diff = abs(current_mean - baseline['mean'])
        mean_std_diff = mean_diff / baseline['std'] if baseline['std'] > 0 else float('inf')
        
        drift_results['mean_shift'] = {
            'baseline_mean': baseline['mean'],
            'current_mean': current_mean,
            'difference': mean_diff,
            'std_difference': mean_std_diff,
            'drift': mean_std_diff > 2  # 2 sigma threshold
        }
        
        # Variance change test
        current_var = np.var(current_data)
        var_ratio = current_var / baseline['std']**2 if baseline['std']**2 > 0 else float('inf')
        
        drift_results['variance_change'] = {
            'baseline_variance': baseline['std']**2,
            'current_variance': current_var,
            'ratio': var_ratio,
            'drift': var_ratio > 2 or var_ratio < 0.5  # 2x change threshold
        }
        
        # Distribution comparison using histogram
        baseline_hist, _ = np.histogram(baseline_data, bins=50, density=True)
        current_hist, _ = np.histogram(current_data, bins=50, density=True)
        
        # Jensen-Shannon divergence
        js_divergence = self._calculate_js_divergence(baseline_hist, current_hist)
        drift_results['distribution_drift'] = {
            'js_divergence': js_divergence,
            'drift': js_divergence > 0.2  # Threshold for significant drift
        }
        
        # Overall drift detection
        drift_detected = any([
            drift_results['ks_test']['drift'],
            drift_results['mean_shift']['drift'],
            drift_results['variance_change']['drift'],
            drift_results['distribution_drift']['drift']
        ])
        
        return {
            'drift_detected': drift_detected,
            'feature_name': feature_name,
            'tests': drift_results,
            'timestamp': datetime.now(),
            'current_data_stats': {
                'mean': current_mean,
                'std': np.std(current_data),
                'min': np.min(current_data),
                'max': np.max(current_data),
                'skewness': stats.skew(current_data),
                'kurtosis': stats.kurtosis(current_data)
            }
        }
    
    def _calculate_js_divergence(self, p: np.ndarray, q: np.ndarray) -> float:
        """Jensen-Shannon divergence hesapla"""
        # Normalize histograms
        p = p / np.sum(p)
        q = q / np.sum(q)
        
        # Calculate M = (P + Q) / 2
        m = (p + q) / 2
        
        # Calculate KL divergences
        kl_pm = stats.entropy(p, m)
        kl_qm = stats.entropy(q, m)
        
        # JS divergence
        js_div = (kl_pm + kl_qm) / 2
        
        return js_div

class ModelPerformanceMonitor:
    """Model performance monitoring sınıfı"""
    
    def __init__(self, config=None):
        self.config = config or pipeline_config
        self.engine = None
        self.drift_detector = DataDriftDetector()
        self.performance_history = []
        self.alerts = []
        
    def initialize_database(self):
        """Veritabanı bağlantısını başlat"""
        try:
            database_url = self.config.get_database_url()
            self.engine = create_engine(database_url)
            
            # Monitoring tablolarını oluştur
            self._create_monitoring_tables()
            
        except Exception as e:
            logger.error(f"Veritabanı bağlantısı başarısız: {e}")
            raise
    
    def _create_monitoring_tables(self):
        """Monitoring için gerekli tabloları oluştur"""
        try:
            # Model performance history
            create_performance_table = """
            CREATE TABLE IF NOT EXISTS model_performance (
                id SERIAL PRIMARY KEY,
                model_name VARCHAR(100) NOT NULL,
                metric_name VARCHAR(50) NOT NULL,
                metric_value DECIMAL(15,6),
                threshold DECIMAL(15,6),
                timestamp TIMESTAMPTZ DEFAULT NOW(),
                symbol VARCHAR(20),
                timeframe VARCHAR(10),
                metadata JSONB
            );
            """
            
            # Data drift results
            create_drift_table = """
            CREATE TABLE IF NOT EXISTS data_drift (
                id SERIAL PRIMARY KEY,
                feature_name VARCHAR(100) NOT NULL,
                drift_detected BOOLEAN NOT NULL,
                drift_score DECIMAL(15,6),
                tests_results JSONB,
                timestamp TIMESTAMPTZ DEFAULT NOW(),
                symbol VARCHAR(20),
                timeframe VARCHAR(10)
            );
            """
            
            # Alerts
            create_alerts_table = """
            CREATE TABLE IF NOT EXISTS monitoring_alerts (
                id SERIAL PRIMARY KEY,
                alert_type VARCHAR(50) NOT NULL,
                severity VARCHAR(20) NOT NULL,
                message TEXT NOT NULL,
                model_name VARCHAR(100),
                metric_name VARCHAR(50),
                current_value DECIMAL(15,6),
                threshold_value DECIMAL(15,6),
                timestamp TIMESTAMPTZ DEFAULT NOW(),
                resolved BOOLEAN DEFAULT FALSE,
                resolved_at TIMESTAMPTZ
            );
            """
            
            # Indexes
            create_indexes = [
                "CREATE INDEX IF NOT EXISTS idx_performance_model ON model_performance (model_name, timestamp DESC)",
                "CREATE INDEX IF NOT EXISTS idx_drift_feature ON data_drift (feature_name, timestamp DESC)",
                "CREATE INDEX IF NOT EXISTS idx_alerts_type ON monitoring_alerts (alert_type, timestamp DESC)",
                "CREATE INDEX IF NOT EXISTS idx_performance_symbol ON model_performance (symbol, timestamp DESC)"
            ]
            
            sql_commands = [
                create_performance_table,
                create_drift_table,
                create_alerts_table,
                *create_indexes
            ]
            
            for sql in sql_commands:
                self.engine.execute(text(sql))
            
            logger.info("Monitoring tabloları oluşturuldu")
            
        except Exception as e:
            logger.error(f"Monitoring tablo oluşturma hatası: {e}")
            raise
    
    async def evaluate_model_performance(self, model_name: str, symbol: str, 
                                       timeframe: str, actual_prices: np.ndarray, 
                                       predicted_prices: np.ndarray) -> Dict[str, float]:
        """Model performansını değerlendir"""
        try:
            metrics = self._calculate_metrics(actual_prices, predicted_prices)
            
            # Performance history'ye ekle
            for metric_name, metric_value in metrics.items():
                self.performance_history.append({
                    'model_name': model_name,
                    'symbol': symbol,
                    'timeframe': timeframe,
                    'metric_name': metric_name,
                    'metric_value': metric_value,
                    'timestamp': datetime.now()
                })
            
            # Veritabanına kaydet
            self._store_performance_metrics(model_name, symbol, timeframe, metrics)
            
            # Alert kontrolü
            self._check_performance_alerts(model_name, metrics)
            
            return metrics
            
        except Exception as e:
            logger.error(f"Performance evaluation hatası: {e}")
            return {}
    
    def _calculate_metrics(self, actual: np.ndarray, predicted: np.ndarray) -> Dict[str, float]:
        """Performans metriklerini hesapla"""
        metrics = {
            'mse': float(mean_squared_error(actual, predicted)),
            'mae': float(mean_absolute_error(actual, predicted)),
            'rmse': float(np.sqrt(mean_squared_error(actual, predicted))),
            'mape': float(np.mean(np.abs((actual - predicted) / actual)) * 100),
            'directional_accuracy': self._calculate_directional_accuracy(actual, predicted),
            'r2': float(self._calculate_r2(actual, predicted))
        }
        
        return metrics
    
    def _calculate_directional_accuracy(self, actual: np.ndarray, predicted: np.ndarray) -> float:
        """Directional accuracy hesapla"""
        actual_direction = np.diff(actual) > 0
        predicted_direction = np.diff(predicted) > 0
        
        accuracy = np.mean(actual_direction == predicted_direction)
        return float(accuracy)
    
    def _calculate_r2(self, actual: np.ndarray, predicted: np.ndarray) -> float:
        """R-squared hesapla"""
        ss_res = np.sum((actual - predicted) ** 2)
        ss_tot = np.sum((actual - np.mean(actual)) ** 2)
        
        if ss_tot == 0:
            return 0.0
        
        return 1 - (ss_res / ss_tot)
    
    def _store_performance_metrics(self, model_name: str, symbol: str, 
                                 timeframe: str, metrics: Dict[str, float]):
        """Performans metriklerini veritabanına kaydet"""
        try:
            insert_query = """
            INSERT INTO model_performance 
            (model_name, metric_name, metric_value, symbol, timeframe)
            VALUES (:model_name, :metric_name, :metric_value, :symbol, :timeframe)
            """
            
            with self.engine.connect() as conn:
                for metric_name, metric_value in metrics.items():
                    conn.execute(text(insert_query), {
                        'model_name': model_name,
                        'metric_name': metric_name,
                        'metric_value': metric_value,
                        'symbol': symbol,
                        'timeframe': timeframe
                    })
                
                conn.commit()
                
        except Exception as e:
            logger.error(f"Performance metrics kaydetme hatası: {e}")
    
    def _check_performance_alerts(self, model_name: str, metrics: Dict[str, float]):
        """Performance alert'lerini kontrol et"""
        thresholds = {
            'mse': 0.001,
            'mae': 0.05,
            'mape': 10.0,
            'directional_accuracy': 0.6,
            'r2': 0.3
        }
        
        for metric_name, current_value in metrics.items():
            if metric_name in thresholds:
                threshold = thresholds[metric_name]
                
                # Alert koşulları
                is_alert = False
                severity = 'warning'
                
                if metric_name in ['mse', 'mae', 'mape']:
                    is_alert = current_value > threshold
                elif metric_name in ['directional_accuracy', 'r2']:
                    is_alert = current_value < threshold
                
                if is_alert:
                    alert_message = f"{model_name} modeli için {metric_name} threshold'ı aşıldı: {current_value:.4f} > {threshold:.4f}"
                    
                    if current_value > threshold * 2 or (metric_name in ['directional_accuracy', 'r2'] and current_value < threshold * 0.5):
                        severity = 'critical'
                    
                    self._create_alert('performance_degradation', severity, alert_message, 
                                     model_name, metric_name, current_value, threshold)
    
    def _create_alert(self, alert_type: str, severity: str, message: str, 
                     model_name: str = None, metric_name: str = None, 
                     current_value: float = None, threshold_value: float = None):
        """Alert oluştur"""
        try:
            alert = {
                'alert_type': alert_type,
                'severity': severity,
                'message': message,
                'model_name': model_name,
                'metric_name': metric_name,
                'current_value': current_value,
                'threshold_value': threshold_value,
                'timestamp': datetime.now()
            }
            
            self.alerts.append(alert)
            
            # Veritabanına kaydet
            insert_query = """
            INSERT INTO monitoring_alerts 
            (alert_type, severity, message, model_name, metric_name, current_value, threshold_value)
            VALUES (:alert_type, :severity, :message, :model_name, :metric_name, :current_value, :threshold_value)
            """
            
            with self.engine.connect() as conn:
                conn.execute(text(insert_query), alert)
                conn.commit()
            
            # Log alert
            logger.warning(f"Alert oluşturuldu [{severity}]: {message}")
            
        except Exception as e:
            logger.error(f"Alert oluşturma hatası: {e}")
    
    async def monitor_data_drift(self, features_data: Dict[str, np.ndarray], 
                               symbol: str, timeframe: str) -> Dict[str, Any]:
        """Data drift monitoring"""
        drift_results = {}
        
        for feature_name, current_features in features_data.items():
            try:
                # Drift detection
                drift_result = self.drift_detector.detect_drift(feature_name, current_features)
                drift_result['symbol'] = symbol
                drift_result['timeframe'] = timeframe
                
                drift_results[feature_name] = drift_result
                
                # Veritabanına kaydet
                self._store_drift_result(drift_result)
                
                # Drift alert
                if drift_result['drift_detected']:
                    alert_message = f"Data drift detected for feature {feature_name} ({symbol}, {timeframe})"
                    self._create_alert('data_drift', 'warning', alert_message)
                
            except Exception as e:
                logger.error(f"Drift detection hatası {feature_name}: {e}")
                continue
        
        return drift_results
    
    def _store_drift_result(self, drift_result: Dict[str, Any]):
        """Drift sonucunu veritabanına kaydet"""
        try:
            insert_query = """
            INSERT INTO data_drift 
            (feature_name, drift_detected, drift_score, tests_results, symbol, timeframe)
            VALUES (:feature_name, :drift_detected, :drift_score, :tests_results, :symbol, :timeframe)
            """
            
            # Drift score hesapla
            drift_score = max([
                drift_result['tests']['ks_test']['statistic'],
                abs(drift_result['tests']['mean_shift']['std_difference']) / 10,
                abs(np.log(drift_result['tests']['variance_change']['ratio'])) / 5,
                drift_result['tests']['distribution_drift']['js_divergence']
            ])
            
            with self.engine.connect() as conn:
                conn.execute(text(insert_query), {
                    'feature_name': drift_result['feature_name'],
                    'drift_detected': drift_result['drift_detected'],
                    'drift_score': drift_score,
                    'tests_results': drift_result['tests'],
                    'symbol': drift_result.get('symbol'),
                    'timeframe': drift_result.get('timeframe')
                })
                
                conn.commit()
                
        except Exception as e:
            logger.error(f"Drift result kaydetme hatası: {e}")
    
    async def get_performance_summary(self, model_name: str = None, hours: int = 24) -> Dict[str, Any]:
        """Performance özetini al"""
        try:
            query = """
            SELECT model_name, metric_name, AVG(metric_value) as avg_value,
                   STDDEV(metric_value) as std_value, MIN(timestamp) as first_check,
                   MAX(timestamp) as last_check
            FROM model_performance 
            WHERE timestamp >= NOW() - INTERVAL '{hours} hours'
            {where_clause}
            GROUP BY model_name, metric_name
            ORDER BY model_name, metric_name
            """
            
            where_clause = ""
            if model_name:
                where_clause = f"AND model_name = '{model_name}'"
            
            query = query.format(hours=hours, where_clause=where_clause)
            
            with self.engine.connect() as conn:
                result = conn.execute(text(query))
                rows = result.fetchall()
            
            # Group by model
            summary = {}
            for row in rows:
                model = row[0]
                metric = row[1]
                
                if model not in summary:
                    summary[model] = {}
                
                summary[model][metric] = {
                    'average': float(row[2]),
                    'std_dev': float(row[3]),
                    'first_check': row[4],
                    'last_check': row[5]
                }
            
            return summary
            
        except Exception as e:
            logger.error(f"Performance summary alma hatası: {e}")
            return {}
    
    async def get_recent_alerts(self, hours: int = 24, severity: str = None) -> List[Dict[str, Any]]:
        """Son alert'leri al"""
        try:
            where_clause = "WHERE timestamp >= NOW() - INTERVAL '{hours} hours' AND resolved = FALSE"
            if severity:
                where_clause += f" AND severity = '{severity}'"
            
            query = f"""
            SELECT * FROM monitoring_alerts 
            {where_clause}
            ORDER BY timestamp DESC
            LIMIT 100
            """
            
            with self.engine.connect() as conn:
                result = conn.execute(text(query))
                rows = result.fetchall()
                columns = result.keys()
            
            alerts = [dict(zip(columns, row)) for row in rows]
            return alerts
            
        except Exception as e:
            logger.error(f"Alert alma hatası: {e}")
            return []

# Monitoring system orchestration
class MonitoringSystem:
    """Ana monitoring sistemi"""
    
    def __init__(self, config=None):
        self.config = config or pipeline_config
        self.performance_monitor = ModelPerformanceMonitor()
        self.is_running = False
        
    async def start_monitoring(self):
        """Monitoring'i başlat"""
        try:
            self.performance_monitor.initialize_database()
            self.is_running = True
            
            # Background monitoring tasks
            asyncio.create_task(self._periodic_performance_check())
            asyncio.create_task(self._periodic_drift_check())
            
            logger.info("Monitoring sistemi başlatıldı")
            
        except Exception as e:
            logger.error(f"Monitoring başlatma hatası: {e}")
            raise
    
    async def _periodic_performance_check(self):
        """Periyodik performance kontrolü"""
        while self.is_running:
            try:
                # Model performanslarını kontrol et
                await self._check_all_models_performance()
                
                # 30 dakika bekle
                await asyncio.sleep(1800)  # 30 minutes
                
            except Exception as e:
                logger.error(f"Periodic performance check hatası: {e}")
                await asyncio.sleep(300)  # 5 dakika bekle
    
    async def _periodic_drift_check(self):
        """Periyodik drift kontrolü"""
        while self.is_running:
            try:
                # Data drift'leri kontrol et
                await self._check_data_drift()
                
                # 1 saat bekle
                await asyncio.sleep(3600)  # 1 hour
                
            except Exception as e:
                logger.error(f"Periodic drift check hatası: {e}")
                await asyncio.sleep(600)  # 10 dakika bekle
    
    async def _check_all_models_performance(self):
        """Tüm modellerin performansını kontrol et"""
        # Bu fonksiyon gerçek prod ortamında MLflow API'den active model'leri alacak
        # Şimdilik mock implementation
        
        active_models = ['bitwisers_lstm_v1', 'bitwisers_transformer_v1']
        symbols = ['BTCUSDT', 'ETHUSDT']
        
        for model_name in active_models:
            for symbol in symbols:
                try:
                    # Mock data for demonstration
                    actual = np.random.normal(50000, 2000, 50)  # Actual prices
                    predicted = np.random.normal(50000, 2100, 50)  # Predicted prices
                    
                    await self.performance_monitor.evaluate_model_performance(
                        model_name, symbol, '1h', actual, predicted
                    )
                    
                except Exception as e:
                    logger.error(f"Model performance check hatası {model_name}: {e}")
    
    async def _check_data_drift(self):
        """Data drift kontrolü"""
        try:
            # Feature data'sını al (mock implementation)
            features_data = {
                'rsi_14': np.random.normal(50, 15, 1000),
                'macd': np.random.normal(0, 100, 1000),
                'volume': np.random.normal(1000000, 500000, 1000)
            }
            
            await self.performance_monitor.monitor_data_drift(
                features_data, 'BTCUSDT', '1h'
            )
            
        except Exception as e:
            logger.error(f"Data drift check hatası: {e}")
    
    async def stop_monitoring(self):
        """Monitoring'i durdur"""
        self.is_running = False
        logger.info("Monitoring sistemi durduruldu")

# Singleton instance
monitoring_system = MonitoringSystem()