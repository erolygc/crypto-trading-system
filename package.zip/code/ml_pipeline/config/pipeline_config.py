"""
ML Pipeline Ana Konfigürasyon Dosyası
Bitwisers 2.0 MLOps Pipeline Ayarları
"""

import os
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from datetime import timedelta

@dataclass
class DatabaseConfig:
    """TimescaleDB Konfigürasyonu"""
    host: str = "localhost"
    port: int = 5432
    database: str = "bitwisers"
    user: str = "postgres"
    password: str = "password"
    pool_size: int = 20
    max_overflow: int = 10
    pool_timeout: int = 30

@dataclass
class MLflowConfig:
    """MLflow Konfigürasyonu"""
    tracking_uri: str = "postgresql://postgres:password@localhost:5432/mlflow"
    experiment_name: str = "bitwisers_ml_pipeline"
    artifact_location: str = "/mlruns/artifacts"
    registry_uri: str = "postgresql://postgres:password@localhost:5432/mlflow"

@dataclass
class KafkaConfig:
    """Kafka Konfigürasyonu"""
    bootstrap_servers: List[str] = field(default_factory=lambda: ["localhost:9092"])
    topic_data_ingestion: str = "market-data"
    topic_predictions: str = "ml-predictions"
    topic_model_updates: str = "model-updates"
    consumer_group_id: str = "ml-pipeline"
    auto_offset_reset: str = "latest"

@dataclass
class ModelConfig:
    """Model Konfigürasyonu"""
    model_types: List[str] = field(default_factory=lambda: ["lstm", "transformer", "xgboost"])
    default_model: str = "lstm"
    sequence_length: int = 60
    prediction_horizon: int = 24  # hours
    retrain_interval: int = 24  # hours
    model_versions_to_keep: int = 5

@dataclass
class FeatureConfig:
    """Feature Engineering Konfigürasyonu"""
    technical_indicators: List[str] = field(default_factory=lambda: [
        "sma", "ema", "rsi", "macd", "bollinger", "stoch", "atr", "obv"
    ])
    lookback_periods: List[int] = field(default_factory=lambda: [7, 14, 21, 30])
    timeframes: List[str] = field(default_factory=lambda: ["1h", "4h", "1d"])
    features_lookback: int = 200
    normalization_method: str = "robust"

@dataclass
class TrainingConfig:
    """Model Eğitim Konfigürasyonu"""
    batch_size: int = 32
    learning_rate: float = 0.001
    epochs: int = 100
    validation_split: float = 0.2
    early_stopping_patience: int = 10
    hyperparameter_tuning_trials: int = 100
    cross_validation_folds: int = 5

@dataclass
class MonitoringConfig:
    """Model Monitoring Konfigürasyonu"""
    drift_detection_enabled: bool = True
    performance_threshold: float = 0.05  # 5% performance degradation
    prediction_batch_size: int = 1000
    monitoring_interval: int = 60  # minutes
    alert_channels: List[str] = field(default_factory=lambda: ["email", "slack"])

@dataclass
class TestingConfig:
    """A/B Testing Konfigürasyonu"""
    ab_testing_enabled: bool = True
    test_duration: int = 7  # days
    significance_level: float = 0.05
    power: float = 0.8
    min_detectable_effect: float = 0.1
    traffic_split: Dict[str, float] = field(default_factory=lambda: {
        "model_a": 0.5,
        "model_b": 0.5
    })

class PipelineConfig:
    """Ana Pipeline Konfigürasyon Sınıfı"""
    
    def __init__(self, config_file: Optional[str] = None):
        self.config_file = config_file or "config/pipeline_config.yaml"
        self.base_dir = Path(__file__).parent
        
        # Temel dizinler
        self.data_dir = self.base_dir / "data"
        self.models_dir = self.base_dir / "models"
        self.logs_dir = self.base_dir / "logs"
        self.config_dir = self.base_dir / "config"
        
        # Konfigürasyonlar
        self.database = DatabaseConfig()
        self.mlflow = MLflowConfig()
        self.kafka = KafkaConfig()
        self.model = ModelConfig()
        self.features = FeatureConfig()
        self.training = TrainingConfig()
        self.monitoring = MonitoringConfig()
        self.testing = TestingConfig()
        
        # Dizinleri oluştur
        self._create_directories()
    
    def _create_directories(self):
        """Gerekli dizinleri oluştur"""
        directories = [
            self.data_dir,
            self.models_dir, 
            self.logs_dir,
            self.config_dir,
            self.data_dir / "raw",
            self.data_dir / "processed",
            self.data_dir / "features",
            self.models_dir / "trained",
            self.models_dir / "candidates",
            self.models_dir / "archived"
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
    
    def get_database_url(self) -> str:
        """PostgreSQL/TimescaleDB bağlantı URL'si"""
        return f"postgresql://{self.database.user}:{self.database.password}@{self.database.host}:{self.database.port}/{self.database.database}"
    
    def get_mlflow_tracking_uri(self) -> str:
        """MLflow tracking URI"""
        return self.mlflow.tracking_uri
    
    def get_kafka_config(self) -> Dict:
        """Kafka konfigürasyonu sözlüğü"""
        return {
            "bootstrap_servers": self.kafka.bootstrap_servers,
            "group_id": self.kafka.consumer_group_id,
            "auto_offset_reset": self.kafka.auto_offset_reset
        }
    
    @classmethod
    def from_env(cls) -> 'PipelineConfig':
        """Çevre değişkenlerinden konfigürasyon yükle"""
        config = cls()
        
        # Database konfigürasyonu
        if os.getenv("DB_HOST"):
            config.database.host = os.getenv("DB_HOST")
        if os.getenv("DB_PASSWORD"):
            config.database.password = os.getenv("DB_PASSWORD")
            
        # MLflow konfigürasyonu
        if os.getenv("MLFLOW_TRACKING_URI"):
            config.mlflow.tracking_uri = os.getenv("MLFLOW_TRACKING_URI")
            
        # Kafka konfigürasyonu
        if os.getenv("KAFKA_BOOTSTRAP_SERVERS"):
            config.kafka.bootstrap_servers = os.getenv("KAFKA_BOOTSTRAP_SERVERS").split(",")
            
        return config

# Global config instance
pipeline_config = PipelineConfig()