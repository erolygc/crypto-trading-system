"""
Model Training Modülü
MLflow ile model versioning ve experiment tracking
"""

import mlflow
import mlflow.sklearn
import mlflow.tensorflow
import mlflow.pytorch
import optuna
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple, Any
import tensorflow as tf
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.model_selection import TimeSeriesSplit, cross_val_score
from sklearn.preprocessing import StandardScaler, RobustScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import logging
import pickle
import warnings

from ..config.pipeline_config import pipeline_config
from ..utils.logging_utils import get_logger

logger = get_logger(__name__)

class ModelArchitecture:
    """Model mimarilerini tanımlayan sınıf"""
    
    @staticmethod
    def create_lstm_model(input_shape: Tuple[int, int], units: int = 128, dropout: float = 0.2) -> tf.keras.Model:
        """LSTM model mimarisi"""
        model = tf.keras.Sequential([
            tf.keras.layers.LSTM(units, return_sequences=True, input_shape=input_shape),
            tf.keras.layers.Dropout(dropout),
            tf.keras.layers.LSTM(units // 2, return_sequences=True),
            tf.keras.layers.Dropout(dropout),
            tf.keras.layers.LSTM(units // 4, return_sequences=False),
            tf.keras.layers.Dropout(dropout),
            tf.keras.layers.Dense(64, activation='relu'),
            tf.keras.layers.Dense(32, activation='relu'),
            tf.keras.layers.Dense(1, activation='linear')
        ])
        
        model.compile(
            optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
            loss='mse',
            metrics=['mae']
        )
        
        return model
    
    @staticmethod
    def create_transformer_model(input_shape: Tuple[int, int], d_model: int = 64, num_heads: int = 8) -> tf.keras.Model:
        """Transformer model mimarisi"""
        inputs = tf.keras.Input(shape=input_shape)
        
        # Positional encoding
        x = tf.keras.layers.Lambda(lambda x: tf.math.sin(tf.range(tf.shape(x)[-1]) / 10000 ** (2 * np.arange(0, 5, 2) / 5)))(inputs)
        x = tf.keras.layers.Add()([inputs, x])
        
        # Multi-head attention
        attention_output = tf.keras.layers.MultiHeadAttention(
            num_heads=num_heads, key_dim=d_model // num_heads
        )(x, x)
        
        # Add & Norm
        x = tf.keras.layers.Add()([x, attention_output])
        x = tf.keras.layers.LayerNormalization()(x)
        
        # Feed forward network
        ffn_output = tf.keras.layers.Dense(d_model * 4, activation='relu')(x)
        ffn_output = tf.keras.layers.Dense(d_model)(ffn_output)
        
        # Add & Norm
        x = tf.keras.layers.Add()([x, ffn_output])
        x = tf.keras.layers.LayerNormalization()(x)
        
        # Global average pooling
        x = tf.keras.layers.GlobalAveragePooling1D()(x)
        
        # Dense layers
        x = tf.keras.layers.Dense(128, activation='relu')(x)
        x = tf.keras.layers.Dropout(0.3)(x)
        x = tf.keras.layers.Dense(64, activation='relu')(x)
        x = tf.keras.layers.Dropout(0.2)(x)
        outputs = tf.keras.layers.Dense(1, activation='linear')(x)
        
        model = tf.keras.Model(inputs=inputs, outputs=outputs)
        model.compile(optimizer='adam', loss='mse', metrics=['mae'])
        
        return model
    
    @staticmethod
    def create_pytorch_lstm(input_size: int, hidden_size: int = 128, num_layers: int = 3, dropout: float = 0.2) -> nn.Module:
        """PyTorch LSTM modeli"""
        class LSTMPredictor(nn.Module):
            def __init__(self, input_size, hidden_size, num_layers, dropout):
                super(LSTMPredictor, self).__init__()
                self.hidden_size = hidden_size
                self.num_layers = num_layers
                
                self.lstm = nn.LSTM(input_size, hidden_size, num_layers, 
                                  batch_first=True, dropout=dropout)
                self.dropout = nn.Dropout(dropout)
                self.fc1 = nn.Linear(hidden_size, 64)
                self.fc2 = nn.Linear(64, 32)
                self.fc3 = nn.Linear(32, 1)
                self.relu = nn.ReLU()
                
            def forward(self, x):
                h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size)
                c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size)
                
                out, _ = self.lstm(x, (h0, c0))
                out = self.dropout(out[:, -1, :])  # Son sequence elementi
                out = self.relu(self.fc1(out))
                out = self.dropout(out)
                out = self.relu(self.fc2(out))
                out = self.fc3(out)
                return out
        
        return LSTMPredictor(input_size, hidden_size, num_layers, dropout)

class DataPreprocessor:
    """Veri ön işleme sınıfı"""
    
    def __init__(self, config=None):
        self.config = config or pipeline_config
        self.scaler = None
        self.feature_columns = None
        
    def prepare_sequences(self, data: pd.DataFrame, target_column: str = 'close', 
                         sequence_length: int = None, prediction_horizon: int = None) -> Tuple[np.ndarray, np.ndarray]:
        """Time series data'yı sequence'lara çevir"""
        if sequence_length is None:
            sequence_length = self.config.model.sequence_length
        if prediction_horizon is None:
            prediction_horizon = self.config.model.prediction_horizon
            
        # Feature ve target ayrımı
        feature_cols = [col for col in data.columns if col not in [target_column, 'timestamp', 'symbol', 'timeframe', 'created_at']]
        self.feature_columns = feature_cols
        
        features = data[feature_cols].values
        target = data[target_column].values
        
        # Scaler ile normalization
        if self.scaler is None:
            self.scaler = RobustScaler()
            features_scaled = self.scaler.fit_transform(features)
        else:
            features_scaled = self.scaler.transform(features)
        
        # Sequence oluşturma
        X, y = [], []
        for i in range(sequence_length, len(features_scaled) - prediction_horizon):
            X.append(features_scaled[i-sequence_length:i])
            # Target'ı future price olarak al
            y.append(target[i + prediction_horizon])
        
        return np.array(X), np.array(y)
    
    def split_data(self, X: np.ndarray, y: np.ndarray, test_size: float = 0.2) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Time series split"""
        split_index = int(len(X) * (1 - test_size))
        
        X_train, X_test = X[:split_index], X[split_index:]
        y_train, y_test = y[:split_index], y[split_index:]
        
        return X_train, X_test, y_train, y_test
    
    def save_scaler(self, filepath: str):
        """Scaler'ı kaydet"""
        if self.scaler is not None:
            with open(filepath, 'wb') as f:
                pickle.dump(self.scaler, f)
    
    def load_scaler(self, filepath: str):
        """Scaler'ı yükle"""
        with open(filepath, 'rb') as f:
            self.scaler = pickle.load(f)

class ModelTrainer:
    """Ana model training sınıfı"""
    
    def __init__(self, config=None):
        self.config = config or pipeline_config
        self.mlflow_client = None
        
        # MLflow setup
        mlflow.set_tracking_uri(self.config.get_mlflow_tracking_uri())
        
    def train_model_with_optuna(self, model_type: str, X_train: np.ndarray, y_train: np.ndarray, 
                               X_val: np.ndarray, y_val: np.ndarray) -> Dict[str, Any]:
        """Optuna ile hyperparameter tuning"""
        
        def objective(trial):
            # Hyperparameter space tanımla
            if model_type == 'lstm':
                return self._lstm_objective(trial, X_train, y_train, X_val, y_val)
            elif model_type == 'transformer':
                return self._transformer_objective(trial, X_train, y_train, X_val, y_val)
            elif model_type == 'random_forest':
                return self._rf_objective(trial, X_train, y_train, X_val, y_val)
            elif model_type == 'gradient_boosting':
                return self._gb_objective(trial, X_train, y_train, X_val, y_val)
            else:
                raise ValueError(f"Bilinmeyen model tipi: {model_type}")
        
        # Optuna study oluştur
        study = optuna.create_study(
            direction='minimize',
            sampler=optuna.samplers.TPESampler(seed=42)
        )
        
        # Hyperparameter tuning
        study.optimize(objective, n_trials=self.config.training.hyperparameter_tuning_trials)
        
        return study.best_params, study.best_value
    
    def _lstm_objective(self, trial, X_train, y_train, X_val, y_val) -> float:
        """LSTM hyperparameter tuning objective"""
        # Hyperparameters
        units = trial.suggest_int('units', 64, 256, step=32)
        dropout = trial.suggest_float('dropout', 0.1, 0.5)
        learning_rate = trial.suggest_float('learning_rate', 1e-4, 1e-2, log=True)
        batch_size = trial.suggest_categorical('batch_size', [16, 32, 64])
        
        # Model oluştur
        model = ModelArchitecture.create_lstm_model(
            input_shape=(X_train.shape[1], X_train.shape[2]),
            units=units,
            dropout=dropout
        )
        
        # Early stopping callback
        early_stopping = tf.keras.callbacks.EarlyStopping(
            patience=self.config.training.early_stopping_patience,
            restore_best_weights=True
        )
        
        # Model training
        history = model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=self.config.training.epochs,
            batch_size=batch_size,
            callbacks=[early_stopping],
            verbose=0
        )
        
        # Validation loss
        val_loss = min(history.history['val_loss'])
        
        return val_loss
    
    def _transformer_objective(self, trial, X_train, y_train, X_val, y_val) -> float:
        """Transformer hyperparameter tuning objective"""
        d_model = trial.suggest_int('d_model', 32, 128, step=16)
        num_heads = trial.suggest_categorical('num_heads', [4, 8, 16])
        learning_rate = trial.suggest_float('learning_rate', 1e-4, 1e-2, log=True)
        batch_size = trial.suggest_categorical('batch_size', [16, 32, 64])
        
        model = ModelArchitecture.create_transformer_model(
            input_shape=(X_train.shape[1], X_train.shape[2]),
            d_model=d_model,
            num_heads=num_heads
        )
        
        model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate), loss='mse', metrics=['mae'])
        
        early_stopping = tf.keras.callbacks.EarlyStopping(
            patience=self.config.training.early_stopping_patience,
            restore_best_weights=True
        )
        
        history = model.fit(
            X_train, y_train,
            validation_data=(X_val, y_val),
            epochs=self.config.training.epochs,
            batch_size=batch_size,
            callbacks=[early_stopping],
            verbose=0
        )
        
        return min(history.history['val_loss'])
    
    def _rf_objective(self, trial, X_train, y_train, X_val, y_val) -> float:
        """Random Forest hyperparameter tuning objective"""
        n_estimators = trial.suggest_int('n_estimators', 100, 500, step=50)
        max_depth = trial.suggest_int('max_depth', 10, 50)
        min_samples_split = trial.suggest_int('min_samples_split', 2, 20)
        min_samples_leaf = trial.suggest_int('min_samples_leaf', 1, 10)
        
        # Reshape for sklearn (2D)
        X_train_2d = X_train.reshape(X_train.shape[0], -1)
        X_val_2d = X_val.reshape(X_val.shape[0], -1)
        
        model = RandomForestRegressor(
            n_estimators=n_estimators,
            max_depth=max_depth,
            min_samples_split=min_samples_split,
            min_samples_leaf=min_samples_leaf,
            random_state=42
        )
        
        model.fit(X_train_2d, y_train)
        y_pred = model.predict(X_val_2d)
        
        return mean_squared_error(y_val, y_pred)
    
    def _gb_objective(self, trial, X_train, y_train, X_val, y_val) -> float:
        """Gradient Boosting hyperparameter tuning objective"""
        n_estimators = trial.suggest_int('n_estimators', 100, 500, step=50)
        learning_rate = trial.suggest_float('learning_rate', 0.01, 0.3)
        max_depth = trial.suggest_int('max_depth', 3, 10)
        subsample = trial.suggest_float('subsample', 0.8, 1.0)
        
        X_train_2d = X_train.reshape(X_train.shape[0], -1)
        X_val_2d = X_val.reshape(X_val.shape[0], -1)
        
        model = GradientBoostingRegressor(
            n_estimators=n_estimators,
            learning_rate=learning_rate,
            max_depth=max_depth,
            subsample=subsample,
            random_state=42
        )
        
        model.fit(X_train_2d, y_train)
        y_pred = model.predict(X_val_2d)
        
        return mean_squared_error(y_val, y_pred)
    
    def train_final_model(self, model_type: str, X_train: np.ndarray, y_train: np.ndarray, 
                         best_params: Dict[str, Any]) -> Any:
        """Best parameters ile final model eğit"""
        if model_type == 'lstm':
            model = ModelArchitecture.create_lstm_model(
                input_shape=(X_train.shape[1], X_train.shape[2]),
                units=best_params['units'],
                dropout=best_params['dropout']
            )
            
            # Final training with best params
            model.fit(
                X_train, y_train,
                epochs=self.config.training.epochs,
                batch_size=best_params['batch_size'],
                verbose=0
            )
            
        elif model_type == 'transformer':
            model = ModelArchitecture.create_transformer_model(
                input_shape=(X_train.shape[1], X_train.shape[2]),
                d_model=best_params['d_model'],
                num_heads=best_params['num_heads']
            )
            
            model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=best_params['learning_rate']), loss='mse', metrics=['mae'])
            
            model.fit(
                X_train, y_train,
                epochs=self.config.training.epochs,
                batch_size=best_params['batch_size'],
                verbose=0
            )
            
        elif model_type in ['random_forest', 'gradient_boosting']:
            X_train_2d = X_train.reshape(X_train.shape[0], -1)
            
            if model_type == 'random_forest':
                model = RandomForestRegressor(
                    n_estimators=best_params['n_estimators'],
                    max_depth=best_params['max_depth'],
                    min_samples_split=best_params['min_samples_split'],
                    min_samples_leaf=best_params['min_samples_leaf'],
                    random_state=42
                )
            else:  # gradient_boosting
                model = GradientBoostingRegressor(
                    n_estimators=best_params['n_estimators'],
                    learning_rate=best_params['learning_rate'],
                    max_depth=best_params['max_depth'],
                    subsample=best_params['subsample'],
                    random_state=42
                )
            
            model.fit(X_train_2d, y_train)
            
        return model
    
    def log_experiment(self, run_name: str, model_type: str, best_params: Dict[str, Any], 
                      train_metrics: Dict[str, float], val_metrics: Dict[str, float], 
                      model: Any, preprocessor: DataPreprocessor):
        """MLflow'a experiment sonuçlarını kaydet"""
        with mlflow.start_run(run_name=run_name):
            # Hyperparameters
            for key, value in best_params.items():
                mlflow.log_param(key, value)
            
            mlflow.log_param("model_type", model_type)
            mlflow.log_param("training_samples", len(X_train))
            mlflow.log_param("validation_samples", len(X_val))
            
            # Metrics
            for key, value in train_metrics.items():
                mlflow.log_metric(f"train_{key}", value)
            
            for key, value in val_metrics.items():
                mlflow.log_metric(f"val_{key}", value)
            
            # Model artifacts
            model_path = "model"
            
            if model_type in ['lstm', 'transformer']:
                # TensorFlow model
                tf.saved_model.save(model, model_path)
                mlflow.tensorflow.log_model(
                    tf_saved_model_dir=model_path,
                    tf_meta_graph_tags=None,
                    tf_signature_def_key='serving_default',
                    artifact_path="model"
                )
                
                # Preprocessor
                preprocessor.save_scaler("preprocessor.pkl")
                mlflow.log_artifact("preprocessor.pkl")
                
            else:  # sklearn models
                mlflow.sklearn.log_model(model, "model")
                preprocessor.save_scaler("preprocessor.pkl")
                mlflow.log_artifact("preprocessor.pkl")
    
    def evaluate_model(self, model: Any, X_test: np.ndarray, y_test: np.ndarray, model_type: str) -> Dict[str, float]:
        """Model performansını değerlendir"""
        # Predictions
        if model_type in ['lstm', 'transformer']:
            y_pred = model.predict(X_test, verbose=0).flatten()
        else:  # sklearn models
            X_test_2d = X_test.reshape(X_test.shape[0], -1)
            y_pred = model.predict(X_test_2d)
        
        # Metrics
        metrics = {
            'mse': mean_squared_error(y_test, y_pred),
            'rmse': np.sqrt(mean_squared_error(y_test, y_pred)),
            'mae': mean_absolute_error(y_test, y_pred),
            'r2': r2_score(y_test, y_pred),
            'mape': np.mean(np.abs((y_test - y_pred) / y_test)) * 100
        }
        
        return metrics, y_pred

# Model registry fonksiyonu
def register_model(run_id: str, model_name: str, stage: str = "Production"):
    """Model'i MLflow Registry'e register et"""
    result = mlflow.register_model(
        f"runs:/{run_id}/model",
        model_name,
        tags={"stage": stage}
    )
    
    # Model'i staging'e promote et
    client = mlflow.tracking.MlflowClient()
    client.transition_model_version_stage(
        name=model_name,
        version=result.version,
        stage=stage
    )
    
    return result

# Singleton instance
model_trainer = ModelTrainer()