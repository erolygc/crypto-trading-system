#!/usr/bin/env python3
"""
Bitwisers 2.0 ML Pipeline - Ana Entry Point
Comprehensive Machine Learning Pipeline for Bitwisers Trading System
"""

import sys
import os
import asyncio
import logging
from pathlib import Path

# Add project root to Python path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from ml_pipeline.cli import cli
from ml_pipeline.utils.logging_utils import get_logger

logger = get_logger(__name__)

def main():
    """Ana entry point"""
    try:
        # CLI'yi çalıştır
        cli()
        
    except KeyboardInterrupt:
        logger.info("Program interrupted by user")
        sys.exit(0)
        
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()