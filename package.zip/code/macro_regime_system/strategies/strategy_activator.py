"""
Strategy Activator - Strateji Aktivasyon Yöneticisi
===================================================

Makro rejime göre stratejileri aktifleştiren ve tahsisleri
yöneten ana sınıf.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum
from datetime import datetime, timedelta
import logging
import asyncio
from concurrent.futures import ThreadPoolExecutor


class StrategyType(Enum):
    """Strateji tipleri"""
    MOMENTUM_LONG = "momentum_long"
    MOMENTUM_SHORT = "momentum_short"
    MEAN_REVERSION = "mean_reversion"
    VOLATILITY_TRADING = "volatility_trading"
    MARKET_NEUTRAL = "market_neutral"
    EVENT_DRIVEN = "event_driven"
    STATISTICAL_ARBITRAGE = "statistical_arbitrage"
    RISK_PARITY = "risk_parity"
    CAPITAL_PRESERVATION = "capital_preservation"
    SAFE_HAVENS = "safe_havens"


class MarketRegime:
    """Market rejimleri (regime_classifier'dan import edilecek)"""
    TRENDING_UP = "trending_up"
    TRENDING_DOWN = "trending_down"
    RANGING = "ranging"
    VOLATILE = "volatile"
    CRISIS = "crisis"
    UNKNOWN = "unknown"


@dataclass
class StrategyConfig:
    """Strateji konfigürasyonu"""
    name: str
    strategy_type: StrategyType
    base_allocation: float
    max_allocation: float
    min_allocation: float
    risk_level: float
    expected_return: float
    volatility: float
    correlation_benchmark: float
    active: bool = True


@dataclass
class ActiveStrategy:
    """Aktif strateji"""
    config: StrategyConfig
    current_allocation: float
    target_allocation: float
    pnl: float
    max_drawdown: float
    win_rate: float
    start_date: datetime
    last_rebalance: datetime


class StrategyActivator:
    """
    Strateji Aktivasyon Yöneticisi
    
    Makro rejime göre stratejileri aktifleştiren ve portföy
    tahsislerini yöneten ana sınıf.
    """
    
    def __init__(self):
        """Initialize strategy activator"""
        self.logger = logging.getLogger(__name__)
        
        # Strateji konfigürasyonları
        self.strategy_configs = self._initialize_strategy_configs()
        self.active_strategies: Dict[str, ActiveStrategy] = {}
        
        # Rejim-strateji mapping
        self.regime_strategy_mapping = {
            MarketRegime.TRENDING_UP: {
                StrategyType.MOMENTUM_LONG: 0.4,
                StrategyType.RISK_PARITY: 0.2,
                StrategyType.MARKET_NEUTRAL: 0.2,
                StrategyType.EVENT_DRIVEN: 0.2
            },
            MarketRegime.TRENDING_DOWN: {
                StrategyType.MOMENTUM_SHORT: 0.3,
                StrategyType.STATISTICAL_ARBITRAGE: 0.3,
                StrategyType.MEAN_REVERSION: 0.2,
                StrategyType.CAPITAL_PRESERVATION: 0.2
            },
            MarketRegime.RANGING: {
                StrategyType.MEAN_REVERSION: 0.3,
                StrategyType.STATISTICAL_ARBITRAGE: 0.3,
                StrategyType.VOLATILITY_TRADING: 0.2,
                StrategyType.MARKET_NEUTRAL: 0.2
            },
            MarketRegime.VOLATILE: {
                StrategyType.VOLATILITY_TRADING: 0.4,
                StrategyType.MARKET_NEUTRAL: 0.3,
                StrategyType.RISK_PARITY: 0.3
            },
            MarketRegime.CRISIS: {
                StrategyType.CAPITAL_PRESERVATION: 0.5,
                StrategyType.SAFE_HAVENS: 0.3,
                StrategyType.VOLATILITY_TRADING: 0.2
            }
        }
        
        # Global parametreler
        self.rebalance_threshold = 0.05  # %5 değişiklikte rebalance
        self.max_strategies = 6
        self.min_strategy_allocation = 0.05  # Minimum %5 tahsis
        
        # Performans takibi
        self.portfolio_performance = {
            'total_return': 0.0,
            'annualized_return': 0.0,
            'volatility': 0.0,
            'sharpe_ratio': 0.0,
            'max_drawdown': 0.0,
            'win_rate': 0.0
        }
        
        # Son güncelleme
        self.last_regime = MarketRegime.UNKNOWN
        self.last_rebalance_date = None
        
        # Executor
        self.executor = ThreadPoolExecutor(max_workers=2)
    
    def _initialize_strategy_configs(self) -> Dict[str, StrategyConfig]:
        """Strateji konfigürasyonlarını başlat"""
        configs = {
            "momentum_long": StrategyConfig(
                name="Momentum Long",
                strategy_type=StrategyType.MOMENTUM_LONG,
                base_allocation=0.15,
                max_allocation=0.30,
                min_allocation=0.05,
                risk_level=0.8,
                expected_return=0.12,
                volatility=0.18,
                correlation_benchmark=0.7
            ),
            "momentum_short": StrategyConfig(
                name="Momentum Short",
                strategy_type=StrategyType.MOMENTUM_SHORT,
                base_allocation=0.12,
                max_allocation=0.25,
                min_allocation=0.03,
                risk_level=0.9,
                expected_return=0.10,
                volatility=0.20,
                correlation_benchmark=0.6
            ),
            "mean_reversion": StrategyConfig(
                name="Mean Reversion",
                strategy_type=StrategyType.MEAN_REVERSION,
                base_allocation=0.15,
                max_allocation=0.25,
                min_allocation=0.08,
                risk_level=0.6,
                expected_return=0.08,
                volatility=0.12,
                correlation_benchmark=0.3
            ),
            "volatility_trading": StrategyConfig(
                name="Volatility Trading",
                strategy_type=StrategyType.VOLATILITY_TRADING,
                base_allocation=0.10,
                max_allocation=0.35,
                min_allocation=0.02,
                risk_level=1.0,
                expected_return=0.15,
                volatility=0.25,
                correlation_benchmark=0.1
            ),
            "market_neutral": StrategyConfig(
                name="Market Neutral",
                strategy_type=StrategyType.MARKET_NEUTRAL,
                base_allocation=0.18,
                max_allocation=0.30,
                min_allocation=0.10,
                risk_level=0.4,
                expected_return=0.07,
                volatility=0.08,
                correlation_benchmark=0.0
            ),
            "statistical_arbitrage": StrategyConfig(
                name="Statistical Arbitrage",
                strategy_type=StrategyType.STATISTICAL_ARBITRAGE,
                base_allocation=0.12,
                max_allocation=0.25,
                min_allocation=0.06,
                risk_level=0.5,
                expected_return=0.09,
                volatility=0.10,
                correlation_benchmark=0.2
            ),
            "risk_parity": StrategyConfig(
                name="Risk Parity",
                strategy_type=StrategyType.RISK_PARITY,
                base_allocation=0.08,
                max_allocation=0.20,
                min_allocation=0.04,
                risk_level=0.3,
                expected_return=0.06,
                volatility=0.06,
                correlation_benchmark=0.4
            ),
            "capital_preservation": StrategyConfig(
                name="Capital Preservation",
                strategy_type=StrategyType.CAPITAL_PRESERVATION,
                base_allocation=0.05,
                max_allocation=0.40,
                min_allocation=0.02,
                risk_level=0.1,
                expected_return=0.03,
                volatility=0.02,
                correlation_benchmark=-0.1
            ),
            "safe_havens": StrategyConfig(
                name="Safe Havens",
                strategy_type=StrategyType.SAFE_HAVENS,
                base_allocation=0.03,
                max_allocation=0.30,
                min_allocation=0.01,
                risk_level=0.2,
                expected_return=0.04,
                volatility=0.04,
                correlation_benchmark=-0.3
            ),
            "event_driven": StrategyConfig(
                name="Event Driven",
                strategy_type=StrategyType.EVENT_DRIVEN,
                base_allocation=0.07,
                max_allocation=0.20,
                min_allocation=0.02,
                risk_level=0.7,
                expected_return=0.11,
                volatility=0.15,
                correlation_benchmark=0.5
            )
        }
        
        return configs
    
    async def update_allocations(self, regime_signal: Any) -> Dict[str, float]:
        """
        Rejim sinyaline göre strateji tahsislerini güncelle
        
        Args:
            regime_signal: Rejim sinyali
            
        Returns:
            Güncellenmiş strateji tahsisleri
        """
        try:
            # Mevcut rejimi belirle
            current_regime = regime_signal.regime if hasattr(regime_signal, 'regime') else MarketRegime.UNKNOWN
            confidence = regime_signal.confidence if hasattr(regime_signal, 'confidence') else 0.5
            
            # Rejim değişikliği kontrolü
            regime_changed = current_regime != self.last_regime
            
            # Tahsisleri hesapla
            if regime_changed or self.last_rebalance_date is None:
                # Büyük rejim değişikliği
                new_allocations = await self._calculate_regime_allocations(current_regime, confidence)
            else:
                # Kademeli ayarlama
                new_allocations = await self._calculate_incremental_adjustments(current_regime, confidence)
            
            # Stratejileri güncelle
            await self._update_active_strategies(new_allocations, regime_signal)
            
            # Son durumu güncelle
            self.last_regime = current_regime
            self.last_rebalance_date = datetime.now()
            
            self.logger.info(
                f"Strateji tahsisleri güncellendi - Rejim: {current_regime.value}, "
                f"Güven: {confidence:.2f}, Strateji sayısı: {len(new_allocations)}"
            )
            
            return new_allocations
            
        except Exception as e:
            self.logger.error(f"Tahsis güncelleme hatası: {e}")
            return self._get_default_allocations()
    
    async def _calculate_regime_allocations(self, regime: str, confidence: float) -> Dict[str, float]:
        """Rejim bazlı tahsis hesaplama"""
        # Temel rejim-strateji mapping'i al
        base_mapping = self.regime_strategy_mapping.get(regime, self._get_default_mapping())
        
        # Güven seviyesi faktörü
        confidence_factor = min(confidence / 0.8, 1.0)  # Max güven 0.8'e kadar
        
        # Tahsisleri hesapla
        allocations = {}
        
        for strategy_type, base_weight in base_mapping.items():
            strategy_config = self._find_strategy_config(strategy_type)
            if strategy_config and strategy_config.active:
                # Güven faktörü uygula
                adjusted_weight = base_weight * confidence_factor
                
                # Strateji sınırlarını uygula
                final_weight = np.clip(
                    adjusted_weight,
                    strategy_config.min_allocation,
                    strategy_config.max_allocation
                )
                
                if final_weight > 0.01:  # Minimum %1
                    allocations[strategy_config.name] = final_weight
        
        # Tahsisleri normalize et
        total_allocation = sum(allocations.values())
        if total_allocation > 0:
            allocations = {k: v / total_allocation for k, v in allocations.items()}
        
        # Strateji sayısını sınırla
        if len(allocations) > self.max_strategies:
            sorted_strategies = sorted(allocations.items(), key=lambda x: x[1], reverse=True)
            allocations = dict(sorted_strategies[:self.max_strategies])
            
            # Tekrar normalize et
            total = sum(allocations.values())
            allocations = {k: v / total for k, v in allocations.items()}
        
        return allocations
    
    async def _calculate_incremental_adjustments(self, regime: str, confidence: float) -> Dict[str, float]:
        """Kademeli tahsis ayarlaması"""
        # Mevcut tahsisleri al
        current_allocations = {
            strategy.name: strategy.current_allocation 
            for strategy in self.active_strategies.values()
        }
        
        # Hedef tahsisleri hesapla
        target_allocations = await self._calculate_regime_allocations(regime, confidence)
        
        # Kademeli geçiş hesapla
        new_allocations = {}
        adjustment_speed = 0.2  # %20 kademeli geçiş
        
        all_strategy_names = set(current_allocations.keys()) | set(target_allocations.keys())
        
        for strategy_name in all_strategy_names:
            current = current_allocations.get(strategy_name, 0.0)
            target = target_allocations.get(strategy_name, 0.0)
            
            # Kademeli ayarlama
            adjustment = (target - current) * adjustment_speed
            new_allocation = current + adjustment
            
            new_allocations[strategy_name] = max(new_allocation, 0.0)
        
        # Negatif tahsisleri temizle
        new_allocations = {k: v for k, v in new_allocations.items() if v > 0.01}
        
        # Tekrar normalize et
        total = sum(new_allocations.values())
        if total > 0:
            new_allocations = {k: v / total for k, v in new_allocations.items()}
        
        return new_allocations
    
    def _get_default_mapping(self) -> Dict[StrategyType, float]:
        """Varsayılan rejim-strateji mapping"""
        return {
            StrategyType.MARKET_NEUTRAL: 0.25,
            StrategyType.RISK_PARITY: 0.20,
            StrategyType.MEAN_REVERSION: 0.20,
            StrategyType.STATISTICAL_ARBITRAGE: 0.20,
            StrategyType.VOLATILITY_TRADING: 0.15
        }
    
    def _find_strategy_config(self, strategy_type: StrategyType) -> Optional[StrategyConfig]:
        """Strateji tipine göre konfigürasyon bul"""
        for config in self.strategy_configs.values():
            if config.strategy_type == strategy_type:
                return config
        return None
    
    async def _update_active_strategies(self, allocations: Dict[str, float], regime_signal: Any) -> None:
        """Aktif stratejileri güncelle"""
        current_time = datetime.now()
        
        # Yeni stratejiler ekle
        for strategy_name, allocation in allocations.items():
            if strategy_name not in self.active_strategies:
                config = self.strategy_configs.get(strategy_name)
                if config:
                    new_strategy = ActiveStrategy(
                        config=config,
                        current_allocation=0.0,
                        target_allocation=allocation,
                        pnl=0.0,
                        max_drawdown=0.0,
                        win_rate=0.0,
                        start_date=current_time,
                        last_rebalance=current_time
                    )
                    self.active_strategies[strategy_name] = new_strategy
                    
                    self.logger.info(f"Yeni strateji eklendi: {strategy_name} ({allocation:.2%})")
            
            # Mevcut stratejileri güncelle
            if strategy_name in self.active_strategies:
                strategy = self.active_strategies[strategy_name]
                
                # Tahsis güncelle
                old_allocation = strategy.current_allocation
                strategy.target_allocation = allocation
                
                # Rebalance gerekli mi kontrol et
                if abs(allocation - old_allocation) > self.rebalance_threshold:
                    await self._execute_rebalance(strategy, allocation)
        
        # Eski stratejileri kaldır
        strategies_to_remove = []
        for strategy_name, strategy in self.active_strategies.items():
            if strategy_name not in allocations:
                strategies_to_remove.append(strategy_name)
        
        for strategy_name in strategies_to_remove:
            self.logger.info(f"Strateji kaldırılıyor: {strategy_name}")
            del self.active_strategies[strategy_name]
    
    async def _execute_rebalance(self, strategy: ActiveStrategy, target_allocation: float) -> None:
        """Rebalance işlemi uygula"""
        try:
            # Strateji performansını değerlendir
            performance_ok = self._evaluate_strategy_performance(strategy)
            
            if performance_ok:
                # Rebalance uygula
                old_allocation = strategy.current_allocation
                strategy.current_allocation = target_allocation
                strategy.last_rebalance = datetime.now()
                
                self.logger.debug(
                    f"Rebalance uygulandı: {strategy.config.name} "
                    f"({old_allocation:.2%} -> {target_allocation:.2%})"
                )
            else:
                # Performans zayıf, gecikme uygula
                self.logger.warning(
                    f"Rebalance gecikmesi: {strategy.config.name} "
                    f"(Performans: {strategy.pnl:.2%})"
                )
        
        except Exception as e:
            self.logger.error(f"Rebalance hatası ({strategy.config.name}): {e}")
    
    def _evaluate_strategy_performance(self, strategy: ActiveStrategy) -> bool:
        """Strateji performansını değerlendir"""
        # Basit performans kriterleri
        days_active = (datetime.now() - strategy.start_date).days
        
        if days_active < 7:  # 7 günden az aktif
            return True
        
        # PnL kontrolü
        if strategy.pnl < -0.05:  # %5'ten fazla kayıp
            return False
        
        # Max drawdown kontrolü
        if strategy.max_drawdown > 0.15:  # %15'ten fazla drawdown
            return False
        
        return True
    
    def _get_default_allocations(self) -> Dict[str, float]:
        """Varsayılan tahsisler"""
        return {
            "Market Neutral": 0.25,
            "Risk Parity": 0.20,
            "Mean Reversion": 0.20,
            "Statistical Arbitrage": 0.20,
            "Volatility Trading": 0.15
        }
    
    async def rotate_strategies(self, current_strategies: List[str], 
                              suitable_strategies: List[str],
                              regime_signal: Any) -> Dict[str, float]:
        """Strateji rotasyonu uygula"""
        try:
            self.logger.info(f"Strateji rotasyonu başlıyor: {len(current_strategies)} -> {len(suitable_strategies)}")
            
            # Rotasyon stratejisi belirle
            rotation_plan = self._create_rotation_plan(current_strategies, suitable_strategies, regime_signal)
            
            # Rotasyonu uygula
            new_allocations = await self._execute_rotation_plan(rotation_plan, regime_signal)
            
            return new_allocations
            
        except Exception as e:
            self.logger.error(f"Strateji rotasyon hatası: {e}")
            return self._get_default_allocations()
    
    def _create_rotation_plan(self, current_strategies: List[str],
                            suitable_strategies: List[str],
                            regime_signal: Any) -> Dict[str, Any]:
        """Rotasyon planı oluştur"""
        # Çıkarılacak stratejiler
        strategies_to_exit = [s for s in current_strategies if s not in suitable_strategies]
        
        # Eklenen stratejiler
        strategies_to_enter = [s for s in suitable_strategies if s not in current_strategies]
        
        # Mevcut stratejiler
        strategies_to_keep = [s for s in current_strategies if s in suitable_strategies]
        
        rotation_plan = {
            'exit': strategies_to_exit,
            'enter': strategies_to_enter,
            'keep': strategies_to_keep,
            'exit_allocation': 0.0,
            'enter_allocation': 0.0
        }
        
        # Çıkış ve giriş tahsislerini hesapla
        if strategies_to_exit:
            exit_allocations = [self.active_strategies[s].current_allocation for s in strategies_to_exit if s in self.active_strategies]
            rotation_plan['exit_allocation'] = sum(exit_allocations)
        
        if strategies_to_enter:
            rotation_plan['enter_allocation'] = rotation_plan['exit_allocation'] / len(strategies_to_enter)
        
        return rotation_plan
    
    async def _execute_rotation_plan(self, rotation_plan: Dict[str, Any], 
                                   regime_signal: Any) -> Dict[str, float]:
        """Rotasyon planını uygula"""
        new_allocations = {}
        
        # Mevcut stratejileri koru (adjust edilecek)
        for strategy_name in rotation_plan['keep']:
            if strategy_name in self.active_strategies:
                strategy = self.active_strategies[strategy_name]
                new_allocations[strategy_name] = strategy.current_allocation * 0.8  # %80'ine düşür
        
        # Yeni stratejileri ekle
        for strategy_name in rotation_plan['enter']:
            if strategy_name in self.strategy_configs:
                config = self.strategy_configs[strategy_name]
                if config.active:
                    allocation = rotation_plan['enter_allocation']
                    new_allocations[strategy_name] = allocation
        
        # Tahsisleri normalize et
        total_allocation = sum(new_allocations.values())
        if total_allocation > 0:
            new_allocations = {k: v / total_allocation for k, v in new_allocations.items()}
        
        # Minimum tahsis kontrolü
        new_allocations = {
            k: max(v, self.min_strategy_allocation) 
            for k, v in new_allocations.items()
        }
        
        # Tekrar normalize et
        total = sum(new_allocations.values())
        if total > 0:
            new_allocations = {k: v / total for k, v in new_allocations.items()}
        
        return new_allocations
    
    def update_strategy_performance(self, strategy_name: str, pnl: float, 
                                  max_drawdown: float, win_rate: float) -> None:
        """Strateji performansını güncelle"""
        if strategy_name in self.active_strategies:
            strategy = self.active_strategies[strategy_name]
            strategy.pnl = pnl
            strategy.max_drawdown = max_drawdown
            strategy.win_rate = win_rate
    
    def get_portfolio_summary(self) -> Dict:
        """Portföy özeti"""
        if not self.active_strategies:
            return {
                'total_allocation': 0.0,
                'strategies': [],
                'risk_level': 0.0,
                'expected_return': 0.0
            }
        
        total_allocation = sum(s.current_allocation for s in self.active_strategies.values())
        
        # Risk seviyesi hesapla
        weighted_risk = sum(
            s.config.risk_level * s.current_allocation 
            for s in self.active_strategies.values()
        )
        
        # Beklenen getiri hesapla
        weighted_return = sum(
            s.config.expected_return * s.current_allocation 
            for s in self.active_strategies.values()
        )
        
        # Volatilite hesapla (basitleştirilmiş)
        portfolio_volatility = np.sqrt(sum(
            (s.config.volatility ** 2) * (s.current_allocation ** 2)
            for s in self.active_strategies.values()
        ))
        
        strategies_info = []
        for strategy in self.active_strategies.values():
            strategies_info.append({
                'name': strategy.config.name,
                'type': strategy.config.strategy_type.value,
                'allocation': strategy.current_allocation,
                'pnl': strategy.pnl,
                'max_drawdown': strategy.max_drawdown,
                'win_rate': strategy.win_rate,
                'days_active': (datetime.now() - strategy.start_date).days
            })
        
        return {
            'total_allocation': total_allocation,
            'strategies': strategies_info,
            'strategy_count': len(self.active_strategies),
            'current_regime': self.last_regime.value,
            'risk_level': weighted_risk,
            'expected_return': weighted_return,
            'portfolio_volatility': portfolio_volatility,
            'last_rebalance': self.last_rebalance_date.isoformat() if self.last_rebalance_date else None,
            'rebalance_threshold': self.rebalance_threshold
        }