#!/usr/bin/env python3
"""
Makro Rejim Filtreleme Sistemi - Basit Test
============================================

Sistemin temel bileşenlerini test eden basit script.
"""

import sys
import os
import numpy as np
sys.path.insert(0, '/workspace/code')

def test_regime_classifier():
    """Regime Classifier testi"""
    print("\n🔍 1. Regime Classifier Testi")
    print("-" * 30)
    
    try:
        from core.regime_classifier import RegimeClassifier
        import pandas as pd
        import numpy as np
        
        # Classifier oluştur
        classifier = RegimeClassifier()
        print("   ✅ Classifier oluşturuldu")
        
        # Test verisi
        test_data = pd.DataFrame({
            'timestamp': pd.date_range('2023-01-01', periods=50, freq='1h'),
            'open': np.random.randn(50).cumsum() + 100,
            'high': np.random.randn(50).cumsum() + 105,
            'low': np.random.randn(50).cumsum() + 95,
            'close': np.random.randn(50).cumsum() + 100,
            'volume': np.random.randint(1000, 10000, 50)
        })
        
        # Rejim tespiti
        signal = classifier.classify_regime(test_data)
        print(f"   ✅ Tespit edilen rejim: {signal.regime.value}")
        print(f"   ✅ Güven seviyesi: {signal.confidence:.2%}")
        print(f"   ✅ Rejim gücü: {signal.strength:.2f}")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Hata: {e}")
        return False

def test_volatility_detector():
    """Volatility Detector testi"""
    print("\n📊 2. Volatility Detector Testi")
    print("-" * 30)
    
    try:
        from detectors.volatility_detector import VolatilityDetector
        import numpy as np
        
        # Detector oluştur
        detector = VolatilityDetector()
        print("   ✅ Detector oluşturuldu")
        
        # Test verisi
        prices = np.random.randn(100).cumsum() + 100
        returns = np.diff(prices) / prices[:-1]
        
        detector.update_data(returns.tolist(), prices.tolist())
        print("   ✅ Veri güncellendi")
        
        # Analiz
        analysis = detector.analyze_volatility()
        print(f"   ✅ Volatilite rejimi: {analysis['regime']}")
        print(f"   ✅ Volatilite seviyesi: {analysis['volatility_level']:.4f}")
        print(f"   ✅ Risk seviyesi: {analysis['risk_level']:.2%}")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Hata: {e}")
        return False

def test_liquidity_detector():
    """Liquidity Detector testi"""
    print("\n💧 3. Liquidity Detector Testi")
    print("-" * 30)
    
    try:
        from detectors.liquidity_detector import LiquidityDetector
        
        # Detector oluştur
        detector = LiquidityDetector()
        print("   ✅ Detector oluşturuldu")
        
        # Market verisi güncelle
        for i in range(10):
            bid = 100 + np.random.normal(0, 0.5)
            ask = bid + 0.01 + np.random.exponential(0.005)
            depth = 1000000 + np.random.normal(0, 200000)
            volume = np.random.randint(5000, 15000)
            
            detector.update_market_data(bid, ask, depth, volume)
        
        print("   ✅ Market verisi güncellendi")
        
        # Analiz
        analysis = detector.analyze_liquidity()
        print(f"   ✅ Likidite rejimi: {analysis['regime']}")
        print(f"   ✅ Stress seviyesi: {analysis['stress_level']:.2%}")
        print(f"   ✅ Bid-ask spread: {analysis['bid_ask_spread']:.4f}")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Hata: {e}")
        return False

def test_macro_indicators():
    """Macro Indicators testi"""
    print("\n🌍 4. Macro Indicators Testi")
    print("-" * 30)
    
    try:
        from indicators.macro_indicators import MacroIndicators
        
        # Indicators oluştur
        macro = MacroIndicators()
        print("   ✅ Macro Indicators oluşturuldu")
        
        # Dummy veri al (test için)
        data = macro._get_dummy_data()
        print(f"   ✅ Dummy veri alındı")
        print(f"   ✅ VIX: {data['vix']:.2f}")
        print(f"   ✅ S&P 500: {data['sp500']:.0f}")
        print(f"   ✅ Treasury 10Y: {data['treasury_10y']:.2f}%")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Hata: {e}")
        return False

def test_strategy_activator():
    """Strategy Activator testi"""
    print("\n🎯 5. Strategy Activator Testi")
    print("-" * 30)
    
    try:
        from strategies.strategy_activator import StrategyActivator
        from core.regime_classifier import MarketRegime, RegimeSignal
        from datetime import datetime
        
        # Activator oluştur
        activator = StrategyActivator()
        print("   ✅ Strategy Activator oluşturuldu")
        
        # Mock rejim sinyali
        signal = RegimeSignal(
            regime=MarketRegime.TRENDING_UP,
            confidence=0.8,
            strength=0.7,
            duration_estimate=24,
            indicators={'volatility': 0.02},
            timestamp=datetime.now()
        )
        
        print("   ✅ Rejim sinyali oluşturuldu")
        print(f"   ✅ Sinyal rejimi: {signal.regime.value}")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Hata: {e}")
        return False

def test_system_integration():
    """Sistem entegrasyonu testi"""
    print("\n🔗 6. Sistem Entegrasyon Testi")
    print("-" * 30)
    
    try:
        # Tüm bileşenleri import et
        from core.regime_classifier import RegimeClassifier
        from detectors.volatility_detector import VolatilityDetector
        from detectors.liquidity_detector import LiquidityDetector
        from indicators.macro_indicators import MacroIndicators
        from strategies.strategy_activator import StrategyActivator
        
        print("   ✅ Tüm bileşenler import edildi")
        
        # Basit pipeline oluştur
        classifier = RegimeClassifier()
        vol_detector = VolatilityDetector()
        liq_detector = LiquidityDetector()
        macro = MacroIndicators()
        activator = StrategyActivator()
        
        print("   ✅ Pipeline bileşenleri oluşturuldu")
        print("   ✅ Sistem entegrasyonu başarılı")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Hata: {e}")
        return False

def main():
    """Ana test fonksiyonu"""
    print("🚀 MAKRO REJİM FİLTRELEME SİSTEMİ TEST")
    print("=" * 50)
    print("Sistem bileşenlerinin temel fonksiyonalitesi test ediliyor...")
    
    tests = [
        ("Regime Classifier", test_regime_classifier),
        ("Volatility Detector", test_volatility_detector),
        ("Liquidity Detector", test_liquidity_detector),
        ("Macro Indicators", test_macro_indicators),
        ("Strategy Activator", test_strategy_activator),
        ("System Integration", test_system_integration)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"\n❌ {test_name} test hatası: {e}")
            results.append((test_name, False))
    
    # Sonuçlar
    print("\n" + "=" * 50)
    print("📋 TEST SONUÇLARI")
    print("=" * 50)
    
    passed = 0
    total = len(results)
    
    for test_name, result in results:
        status = "✅ BAŞARILI" if result else "❌ BAŞARISIZ"
        print(f"{test_name:.<30} {status}")
        if result:
            passed += 1
    
    print("-" * 50)
    print(f"Toplam: {passed}/{total} test başarılı")
    
    if passed == total:
        print("\n🎉 TÜM TESTLER BAŞARILI!")
        print("✨ Makro Rejim Filtreleme Sistemi kullanıma hazır!")
    else:
        print(f"\n⚠️ {total - passed} test başarısız")
        print("🔧 Sistemde iyileştirme gerekebilir")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)