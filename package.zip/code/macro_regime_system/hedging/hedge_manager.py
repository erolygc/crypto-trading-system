"""
Hedge Manager - Otomatik Hedge Yönetimi
======================================

Otomatik hedge pozisyonlarını yöneten ve hedge stratejilerini
uygulayan ana sınıf.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timedelta
import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor


class HedgeStrategy(Enum):
    """Hedge stratejileri"""
    STATIC_HEDGE = "static_hedge"
    DYNAMIC_HEDGE = "dynamic_hedge"
    VOLATILITY_HEDGE = "volatility_hedge"
    PROTECTIVE_PUT = "protective_put"
    COLLAR = "collar"
    TAIL_RISK_HEDGE = "tail_risk_hedge"


@dataclass
class HedgePosition:
    """Hedge pozisyonu"""
    instrument: str
    position_size: float
    entry_price: float
    current_price: float
    pnl: float
    hedge_ratio: float
    strategy: HedgeStrategy
    entry_time: datetime
    last_update: datetime = field(default_factory=datetime.now)


@dataclass
class HedgeParameters:
    """Hedge parametreleri"""
    max_hedge_ratio: float = 1.0
    hedge_sensitivity: float = 0.8
    rebalance_threshold: float = 0.05
    max_positions: int = 10
    stop_loss_level: float = 0.1
    take_profit_level: float = 0.05
    strategy_mix: Dict[HedgeStrategy, float] = field(default_factory=dict)


class HedgeManager:
    """
    Hedge Manager
    
    Otomatik hedge pozisyonlarını yöneten ve hedge stratejilerini
    uygulayan ana sınıf. Risk yönetimi ve pozisyon optimizasyonu yapar.
    """
    
    def __init__(self, sensitivity: float = 0.8):
        """
        Args:
            sensitivity: Hedge duyarlılığı
        """
        self.sensitivity = sensitivity
        
        # Hedge parametreleri
        self.default_params = HedgeParameters(
            hedge_sensitivity=sensitivity
        )
        self.current_params = self.default_params
        
        # Pozisyonlar
        self.positions: List[HedgePosition] = []
        self.hedge_history = []
        
        # Risk yönetimi
        self.total_portfolio_value = 1000000  # Default
        self.max_hedge_capacity = self.total_portfolio_value * 0.3  # %30 max hedge
        self.current_hedge_exposure = 0.0
        
        # Performans takibi
        self.hedge_performance = {
            'total_pnl': 0.0,
            'win_rate': 0.0,
            'max_drawdown': 0.0,
            'sharpe_ratio': 0.0
        }
        
        # Logging
        self.logger = logging.getLogger(__name__)
        
        # Async executor
        self.executor = ThreadPoolExecutor(max_workers=2)
        
        # Strateji ağırlıkları
        self.strategy_weights = {
            HedgeStrategy.STATIC_HEDGE: 0.3,
            HedgeStrategy.DYNAMIC_HEDGE: 0.4,
            HedgeStrategy.VOLATILITY_HEDGE: 0.2,
            HedgeStrategy.PROTECTIVE_PUT: 0.1
        }
        
        # Market data (dummy)
        self.market_prices = {}
        self.last_price_update = None
    
    async def get_current_hedge(self) -> float:
        """Mevcut hedge oranını getir"""
        total_exposure = sum(abs(pos.position_size) for pos in self.positions)
        return min(total_exposure / self.total_portfolio_value, 1.0)
    
    async def execute_hedge_signal(self, signal: Any) -> Dict:
        """Hedge sinyalini uygula"""
        try:
            # Signal analizi
            if not hasattr(signal, 'action'):
                return {'success': False, 'error': 'Geçersiz sinyal formatı'}
            
            # Hedge oranı hesaplama
            current_hedge = await self.get_current_hedge()
            target_hedge = self._calculate_target_hedge(signal)
            
            # Hedge pozisyonu ayarlama
            hedge_delta = target_hedge - current_hedge
            
            if abs(hedge_delta) < self.current_params.rebalance_threshold:
                return {'success': True, 'message': 'Hedge adjustment not needed'}
            
            # Hedge uygula
            result = await self._apply_hedge_adjustment(hedge_delta, signal)
            
            if result['success']:
                self.logger.info(
                    f"Hedge uygulandı: {signal.action} "
                    f"(Delta: {hedge_delta:.3f}, Hedef: {target_hedge:.3f})"
                )
            
            return result
            
        except Exception as e:
            self.logger.error(f"Hedge uygulama hatası: {e}")
            return {'success': False, 'error': str(e)}
    
    def _calculate_target_hedge(self, signal: Any) -> float:
        """Hedef hedge oranını hesapla"""
        # Base hedge ratio from signal
        if hasattr(signal, 'position_size'):
            base_ratio = signal.position_size
        else:
            base_ratio = 0.5
        
        # Market regime adjustment
        regime_multiplier = self._get_regime_multiplier(signal)
        
        # Volatility adjustment
        volatility_adjustment = self._get_volatility_adjustment()
        
        # Risk appetite adjustment
        risk_adjustment = self._get_risk_adjustment()
        
        # Final target
        target_ratio = base_ratio * regime_multiplier * volatility_adjustment * risk_adjustment
        
        return min(target_ratio, self.current_params.max_hedge_ratio)
    
    def _get_regime_multiplier(self, signal: Any) -> float:
        """Rejim bazlı hedge çarpanı"""
        # Rejim bilgisini sinyal'den al (dummy implementation)
        if hasattr(signal, 'reason'):
            reason = signal.reason.lower()
        else:
            reason = "neutral"
        
        if 'crisis' in reason:
            return 1.5
        elif 'volatile' in reason:
            return 1.3
        elif 'trending_down' in reason:
            return 1.2
        elif 'trending_up' in reason:
            return 0.8
        else:
            return 1.0
    
    def _get_volatility_adjustment(self) -> float:
        """Volatilite bazlı hedge ayarlaması"""
        # Dummy volatility calculation
        # Gerçek sistemde VIX veya realized volatility kullanılır
        market_vol = 0.25  # %25 volatilite
        
        if market_vol > 0.4:  # Yüksek volatilite
            return 1.4
        elif market_vol > 0.3:
            return 1.2
        elif market_vol < 0.15:  # Düşük volatilite
            return 0.7
        else:
            return 1.0
    
    def _get_risk_adjustment(self) -> float:
        """Risk iştahı bazlı hedge ayarlaması"""
        # Dummy risk appetite
        # Gerçek sistemde makro göstergelerden alınır
        risk_appetite = 0.6  # Orta risk iştahı
        
        if risk_appetite < 0.3:  # Düşük risk iştahı
            return 1.3
        elif risk_appetite > 0.8:  # Yüksek risk iştahı
            return 0.8
        else:
            return 1.0
    
    async def _apply_hedge_adjustment(self, hedge_delta: float, signal: Any) -> Dict:
        """Hedge ayarlamasını uygula"""
        try:
            # Hedge enstrümanı seçimi
            instruments = self._select_hedge_instruments(hedge_delta, signal)
            
            positions_added = 0
            total_cost = 0
            
            for instrument, allocation in instruments.items():
                position_size = self.total_portfolio_value * allocation * np.sign(hedge_delta)
                
                # Pozisyon oluştur
                position = await self._create_hedge_position(
                    instrument, position_size, signal
                )
                
                if position:
                    self.positions.append(position)
                    total_cost += abs(position.position_size * position.entry_price)
                    positions_added += 1
            
            # Hedge history'ye ekle
            self.hedge_history.append({
                'timestamp': datetime.now(),
                'signal': signal.action,
                'delta': hedge_delta,
                'positions_added': positions_added,
                'total_cost': total_cost,
                'new_hedge_ratio': await self.get_current_hedge()
            })
            
            # Geçmiş veriyi sınırla
            if len(self.hedge_history) > 200:
                self.hedge_history = self.hedge_history[-200:]
            
            return {
                'success': True,
                'positions_added': positions_added,
                'total_cost': total_cost,
                'new_hedge_ratio': await self.get_current_hedge()
            }
            
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _select_hedge_instruments(self, hedge_delta: float, signal: Any) -> Dict[str, float]:
        """Hedge enstrümanlarını seç"""
        instruments = {}
        
        # Rejim bazlı enstrüman seçimi
        if hasattr(signal, 'reason'):
            reason = signal.reason.lower()
        else:
            reason = "neutral"
        
        if 'crisis' in reason:
            # Kriz döneminde: Treasury, Altın, Nakit
            instruments = {
                'treasury_bonds': 0.4,
                'gold_etf': 0.3,
                'cash': 0.3
            }
        elif 'volatile' in reason:
            # Volatil dönemde: Volatility instruments, Put options
            instruments = {
                'vix_futures': 0.4,
                'put_options': 0.4,
                'short_vol_etf': 0.2
            }
        elif 'trending_down' in reason:
            # Düşüş trendinde: Puts, Short positions
            instruments = {
                'put_options': 0.5,
                'short_etf': 0.3,
                'inverse_etf': 0.2
            }
        else:
            # Normal dönem: Balanced approach
            instruments = {
                'put_options': 0.3,
                'volatility_etf': 0.3,
                'treasury_bonds': 0.2,
                'managed_futures': 0.2
            }
        
        # Hedge delta büyüklüğüne göre ölçekle
        scale_factor = min(abs(hedge_delta) / 0.3, 1.0)  # Max 30% hedge
        instruments = {k: v * scale_factor for k, v in instruments.items()}
        
        return instruments
    
    async def _create_hedge_position(self, instrument: str, position_size: float, signal: Any) -> Optional[HedgePosition]:
        """Hedge pozisyonu oluştur"""
        try:
            # Dummy fiyat (gerçek sistemde market data'dan alınır)
            current_price = self._get_market_price(instrument)
            
            # Pozisyon oluştur
            position = HedgePosition(
                instrument=instrument,
                position_size=position_size,
                entry_price=current_price,
                current_price=current_price,
                pnl=0.0,
                hedge_ratio=abs(position_size) / self.total_portfolio_value,
                strategy=self._determine_strategy(instrument, signal),
                entry_time=datetime.now()
            )
            
            self.current_hedge_exposure += abs(position_size)
            
            return position
            
        except Exception as e:
            self.logger.error(f"Pozisyon oluşturma hatası: {e}")
            return None
    
    def _get_market_price(self, instrument: str) -> float:
        """Market fiyatı al (dummy)"""
        # Dummy price generation
        base_prices = {
            'treasury_bonds': 100.0,
            'gold_etf': 180.0,
            'cash': 1.0,
            'vix_futures': 25.0,
            'put_options': 5.0,
            'short_vol_etf': 30.0,
            'short_etf': 50.0,
            'inverse_etf': 45.0,
            'volatility_etf': 20.0,
            'managed_futures': 100.0
        }
        
        base_price = base_prices.get(instrument, 50.0)
        # Add some noise
        return base_price * (1 + np.random.normal(0, 0.02))
    
    def _determine_strategy(self, instrument: str, signal: Any) -> HedgeStrategy:
        """Strateji belirleme"""
        strategy_mapping = {
            'treasury_bonds': HedgeStrategy.STATIC_HEDGE,
            'gold_etf': HedgeStrategy.STATIC_HEDGE,
            'cash': HedgeStrategy.STATIC_HEDGE,
            'vix_futures': HedgeStrategy.VOLATILITY_HEDGE,
            'put_options': HedgeStrategy.PROTECTIVE_PUT,
            'short_vol_etf': HedgeStrategy.TAIL_RISK_HEDGE,
            'short_etf': HedgeStrategy.DYNAMIC_HEDGE,
            'inverse_etf': HedgeStrategy.DYNAMIC_HEDGE,
            'volatility_etf': HedgeStrategy.VOLATILITY_HEDGE,
            'managed_futures': HedgeStrategy.DYNAMIC_HEDGE
        }
        
        return strategy_mapping.get(instrument, HedgeStrategy.STATIC_HEDGE)
    
    async def update_positions(self) -> None:
        """Pozisyonları güncelle"""
        for position in self.positions:
            try:
                # Piyasa fiyatını güncelle
                new_price = self._get_market_price(position.instrument)
                old_price = position.current_price
                
                # PnL güncelle
                price_change = (new_price - old_price) / old_price if old_price > 0 else 0
                position.pnl += position.position_size * price_change
                position.current_price = new_price
                position.last_update = datetime.now()
                
            except Exception as e:
                self.logger.error(f"Pozisyon güncelleme hatası ({position.instrument}): {e}")
        
        # Performans metriklerini güncelle
        self._update_performance_metrics()
    
    def _update_performance_metrics(self) -> None:
        """Performans metriklerini güncelle"""
        if not self.positions:
            return
        
        # Toplam PnL
        total_pnl = sum(pos.pnl for pos in self.positions)
        self.hedge_performance['total_pnl'] = total_pnl
        
        # Win rate
        winning_positions = sum(1 for pos in self.positions if pos.pnl > 0)
        self.hedge_performance['win_rate'] = winning_positions / len(self.positions) if self.positions else 0
        
        # Max drawdown (basitleştirilmiş)
        # Gerçek sistemde zaman serisi analizi gerekli
        cumulative_pnl = []
        running_pnl = 0
        for pos in self.positions:
            running_pnl += pos.pnl
            cumulative_pnl.append(running_pnl)
        
        if cumulative_pnl:
            peak = np.maximum.accumulate(cumulative_pnl)
            drawdown = (peak - cumulative_pnl) / (peak + 1e-8)
            self.hedge_performance['max_drawdown'] = np.max(drawdown)
        
        # Sharpe ratio (basitleştirilmiş)
        if len(self.positions) > 5:
            pnl_returns = [pos.pnl / abs(pos.position_size) for pos in self.positions[-20:]]
            if np.std(pnl_returns) > 0:
                self.hedge_performance['sharpe_ratio'] = np.mean(pnl_returns) / np.std(pnl_returns)
    
    async def rebalance_positions(self) -> Dict:
        """Pozisyonları yeniden dengele"""
        try:
            rebalance_needed = False
            actions_taken = []
            
            for position in self.positions:
                # Stop loss kontrolü
                if position.pnl < -self.current_params.stop_loss_level * abs(position.position_size):
                    await self._close_position(position, 'stop_loss')
                    actions_taken.append(f"Stop-loss executed: {position.instrument}")
                    rebalance_needed = True
                    continue
                
                # Take profit kontrolü
                if position.pnl > self.current_params.take_profit_level * abs(position.position_size):
                    await self._close_position(position, 'take_profit')
                    actions_taken.append(f"Take-profit executed: {position.instrument}")
                    rebalance_needed = True
                    continue
                
                # Hedef hedge ratio kontrolü
                current_ratio = abs(position.hedge_ratio)
                target_ratio = self._get_target_ratio_for_instrument(position.instrument)
                
                if abs(current_ratio - target_ratio) > self.current_params.rebalance_threshold:
                    await self._adjust_position(position, target_ratio)
                    actions_taken.append(f"Position adjusted: {position.instrument}")
                    rebalance_needed = True
            
            return {
                'success': True,
                'rebalance_needed': rebalance_needed,
                'actions_taken': actions_taken
            }
            
        except Exception as e:
            self.logger.error(f"Yeniden dengeleme hatası: {e}")
            return {'success': False, 'error': str(e)}
    
    async def _close_position(self, position: HedgePosition, reason: str) -> None:
        """Pozisyonu kapat"""
        try:
            # PnL finalizasyonu
            final_pnl = position.pnl
            
            # Pozisyonu listeden çıkar
            if position in self.positions:
                self.positions.remove(position)
            
            self.current_hedge_exposure -= abs(position.position_size)
            
            self.logger.info(
                f"Pozisyon kapatıldı: {position.instrument} "
                f"(Sebep: {reason}, PnL: {final_pnl:.2f})"
            )
            
        except Exception as e:
            self.logger.error(f"Pozisyon kapatma hatası: {e}")
    
    def _get_target_ratio_for_instrument(self, instrument: str) -> float:
        """Enstrüman için hedef oran"""
        # Strateji bazlı hedef oranlar
        strategy_ratios = {
            HedgeStrategy.STATIC_HEDGE: 0.1,
            HedgeStrategy.DYNAMIC_HEDGE: 0.15,
            HedgeStrategy.VOLATILITY_HEDGE: 0.1,
            HedgeStrategy.PROTECTIVE_PUT: 0.12,
            HedgeStrategy.TAIL_RISK_HEDGE: 0.08
        }
        
        # Enstrüman için stratejiyi bul
        for position in self.positions:
            if position.instrument == instrument:
                strategy = position.strategy
                return strategy_ratios.get(strategy, 0.1)
        
        return 0.1  # Default
    
    async def _adjust_position(self, position: HedgePosition, target_ratio: float) -> None:
        """Pozisyonu ayarla"""
        try:
            current_ratio = abs(position.hedge_ratio)
            adjustment_needed = target_ratio - current_ratio
            
            # Adjustment uygula
            new_size = position.position_size * (1 + adjustment_needed)
            position.position_size = new_size
            position.hedge_ratio = abs(new_size) / self.total_portfolio_value
            
        except Exception as e:
            self.logger.error(f"Pozisyon ayarlama hatası: {e}")
    
    async def update_parameters(self, new_params: Dict) -> None:
        """Hedge parametrelerini güncelle"""
        try:
            for key, value in new_params.items():
                if hasattr(self.current_params, key):
                    setattr(self.current_params, key, value)
            
            self.logger.info(f"Hedge parametreleri güncellendi: {new_params}")
            
        except Exception as e:
            self.logger.error(f"Parametre güncelleme hatası: {e}")
    
    def get_hedge_summary(self) -> Dict:
        """Hedge özeti"""
        current_hedge_ratio = sum(abs(pos.hedge_ratio) for pos in self.positions)
        
        return {
            'current_hedge_ratio': current_hedge_ratio,
            'total_positions': len(self.positions),
            'total_exposure': sum(abs(pos.position_size) for pos in self.positions),
            'total_pnl': self.hedge_performance['total_pnl'],
            'win_rate': self.hedge_performance['win_rate'],
            'max_drawdown': self.hedge_performance['max_drawdown'],
            'sharpe_ratio': self.hedge_performance['sharpe_ratio'],
            'positions_by_strategy': self._get_positions_by_strategy(),
            'portfolio_allocation': self._get_portfolio_allocation()
        }
    
    def _get_positions_by_strategy(self) -> Dict[str, int]:
        """Stratejiye göre pozisyon sayısı"""
        strategy_counts = {}
        for position in self.positions:
            strategy_name = position.strategy.value
            strategy_counts[strategy_name] = strategy_counts.get(strategy_name, 0) + 1
        return strategy_counts
    
    def _get_portfolio_allocation(self) -> Dict[str, float]:
        """Portföy tahsisleri"""
        allocations = {}
        total_value = sum(abs(pos.position_size) for pos in self.positions)
        
        if total_value == 0:
            return {}
        
        for position in self.positions:
            instrument = position.instrument
            allocation = abs(position.position_size) / total_value
            allocations[instrument] = allocation
        
        return allocations
    
    def get_risk_metrics(self) -> Dict:
        """Risk metrikleri"""
        hedge_ratio = sum(abs(pos.hedge_ratio) for pos in self.positions)
        
        # Concentration risk
        max_allocation = max(
            (abs(pos.position_size) / sum(abs(p.position_size) for p in self.positions))
            for pos in self.positions
        ) if self.positions else 0
        
        # Correlation risk (dummy)
        correlation_risk = 0.3  # Placeholder
        
        return {
            'hedge_ratio': hedge_ratio,
            'concentration_risk': max_allocation,
            'correlation_risk': correlation_risk,
            'tail_risk_exposure': sum(
                pos.hedge_ratio for pos in self.positions
                if pos.strategy == HedgeStrategy.TAIL_RISK_HEDGE
            ),
            'volatility_exposure': sum(
                pos.hedge_ratio for pos in self.positions
                if pos.strategy == HedgeStrategy.VOLATILITY_HEDGE
            )
        }