"""
Makro Rejim Filtreleme Sistemi - Ana Başlatıcı
===============================================

Sistemin ana başlatıcı ve koordinatörü.
"""

import asyncio
import logging
from datetime import datetime
from typing import Optional, Dict, Any
import signal
import sys
import os

# Add the package to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from .core.regime_engine import RegimeEngine, RegimeConfig
from .core.regime_classifier import MarketRegime
from .monitoring.real_time_monitor import RealTimeMonitor
from .utils.helpers import Logger, ConfigManager, ValidationUtils


class MacroRegimeSystem:
    """
    Makro Rejim Filtreleme Sistemi Ana Sınıf
    
    Tüm sistem bileşenlerini koordine eden ve yöneten ana controller.
    """
    
    def __init__(self, config_path: Optional[str] = None):
        """
        Args:
            config_path: Konfigürasyon dosyası yolu
        """
        # Logger kurulumu
        self.logger = Logger.setup_logger(
            'macro_regime_system',
            log_level='INFO',
            log_file='logs/macro_regime_system.log'
        )
        
        # Konfigürasyon
        self.config = self._load_configuration(config_path)
        
        # Sistem bileşenleri
        self.regime_engine: Optional[RegimeEngine] = None
        self.real_time_monitor: Optional[RealTimeMonitor] = None
        
        # Durum
        self.is_running = False
        self.start_time = None
        
        # Callback'ler
        self.system_callbacks = {
            'regime_change': [],
            'alert': [],
            'hedge_signal': [],
            'risk_warning': []
        }
        
        self.logger.info("Makro Rejim Filtreleme Sistemi başlatılıyor...")
    
    def _load_configuration(self, config_path: Optional[str]) -> Dict[str, Any]:
        """Konfigürasyon yükle"""
        if config_path and os.path.exists(config_path):
            try:
                config = ConfigManager.load_config(config_path)
                self.logger.info(f"Konfigürasyon yüklendi: {config_path}")
                return config
            except Exception as e:
                self.logger.error(f"Konfigürasyon yükleme hatası: {e}")
        
        # Varsayılan konfigürasyon
        default_config = {
            'system': {
                'name': 'Makro Rejim Filtreleme Sistemi',
                'version': '1.0.0',
                'environment': 'development',
                'update_interval': 60,
                'data_retention_days': 30
            },
            'regime_engine': {
                'volatility_threshold': 2.0,
                'trend_threshold': 0.7,
                'crisis_threshold': 3.0,
                'hedge_sensitivity': 0.8,
                'regime_persistence_min': 3,
                'auto_hedge_enabled': True,
                'strategy_rotation_enabled': True,
                'risk_limit_percent': 10.0
            },
            'monitoring': {
                'update_interval': 30,
                'alert_thresholds': {
                    'regime_change_confidence': 0.8,
                    'volatility_spike': 2.0,
                    'liquidity_stress': 0.7,
                    'risk_level_high': 0.8
                }
            },
            'logging': {
                'level': 'INFO',
                'file': 'logs/macro_regime_system.log'
            }
        }
        
        self.logger.info("Varsayılan konfigürasyon kullanılıyor")
        return default_config
    
    async def initialize(self) -> bool:
        """Sistemi başlat"""
        try:
            self.logger.info("Sistem bileşenleri başlatılıyor...")
            
            # Regime engine konfigürasyonu
            regime_config = RegimeConfig(
                volatility_threshold=self.config['regime_engine']['volatility_threshold'],
                trend_threshold=self.config['regime_engine']['trend_threshold'],
                crisis_threshold=self.config['regime_engine']['crisis_threshold'],
                hedge_sensitivity=self.config['regime_engine']['hedge_sensitivity'],
                regime_persistence_min=self.config['regime_engine']['regime_persistence_min'],
                auto_hedge_enabled=self.config['regime_engine']['auto_hedge_enabled'],
                strategy_rotation_enabled=self.config['regime_engine']['strategy_rotation_enabled'],
                risk_limit_percent=self.config['regime_engine']['risk_limit_percent']
            )
            
            # Regime engine oluştur
            self.regime_engine = RegimeEngine(regime_config)
            
            # Real-time monitor oluştur
            monitor_config = self.config.get('monitoring', {})
            self.real_time_monitor = RealTimeMonitor(
                update_interval=monitor_config.get('update_interval', 30),
                alert_thresholds=monitor_config.get('alert_thresholds', {})
            )
            
            # Callback'leri kaydet
            self._register_callbacks()
            
            # Validasyon kontrolü
            if not await self._validate_system():
                self.logger.error("Sistem validasyonu başarısız")
                return False
            
            self.logger.info("Sistem bileşenleri başarıyla başlatıldı")
            return True
            
        except Exception as e:
            self.logger.error(f"Sistem başlatma hatası: {e}")
            return False
    
    def _register_callbacks(self) -> None:
        """Callback'leri kaydet"""
        
        # Rejim değişikliği callback'i
        async def on_regime_change(old_regime: MarketRegime, new_regime_signal):
            self.logger.info(f"Rejim değişikliği: {old_regime.value} -> {new_regime_signal.regime.value}")
            
            # Alert callback'leri çağır
            for callback in self.system_callbacks['regime_change']:
                try:
                    await callback(old_regime, new_regime_signal)
                except Exception as e:
                    self.logger.error(f"Regime change callback hatası: {e}")
        
        # Hedge signal callback'i
        async def on_hedge_signal(hedge_signal, result):
            self.logger.info(f"Hedge sinyali: {hedge_signal.action} - {hedge_signal.reason}")
            
            for callback in self.system_callbacks['hedge_signal']:
                try:
                    await callback(hedge_signal, result)
                except Exception as e:
                    self.logger.error(f"Hedge signal callback hatası: {e}")
        
        # Risk warning callback'i
        async def on_risk_warning(risk_level, risk_data):
            self.logger.warning(f"Risk uyarısı: {risk_level:.2%} - {risk_data}")
            
            for callback in self.system_callbacks['risk_warning']:
                try:
                    await callback(risk_level, risk_data)
                except Exception as e:
                    self.logger.error(f"Risk warning callback hatası: {e}")
        
        # Alert callback'i
        async def on_alert(alert):
            self.logger.warning(f"Sistem uyarısı: {alert.alert_type} - {alert.message}")
            
            for callback in self.system_callbacks['alert']:
                try:
                    await callback(alert)
                except Exception as e:
                    self.logger.error(f"Alert callback hatası: {e}")
        
        # Engine callback'lerini kaydet
        if self.regime_engine:
            self.regime_engine.add_regime_change_callback(on_regime_change)
            self.regime_engine.add_hedge_callback(on_hedge_signal)
            self.regime_engine.add_risk_callback(on_risk_warning)
        
        # Monitor callback'lerini kaydet
        if self.real_time_monitor:
            self.real_time_monitor.add_alert_callback(on_alert)
    
    async def _validate_system(self) -> bool:
        """Sistem validasyonu"""
        try:
            self.logger.info("Sistem validasyonu yapılıyor...")
            
            # Regime engine test
            if self.regime_engine:
                test_regime = self.regime_engine.get_current_regime()
                self.logger.info(f"Regime engine test - Mevcut rejim: {test_regime.value}")
            
            # Monitor test
            if self.real_time_monitor:
                monitor_status = self.real_time_monitor.get_current_status()
                self.logger.info(f"Monitor test - Çalışıyor: {monitor_status['is_running']}")
            
            self.logger.info("Sistem validasyonu tamamlandı")
            return True
            
        except Exception as e:
            self.logger.error(f"Sistem validasyon hatası: {e}")
            return False
    
    async def start(self) -> bool:
        """Sistemi başlat"""
        try:
            if self.is_running:
                self.logger.warning("Sistem zaten çalışıyor")
                return True
            
            # Sistem başlatma
            if not await self.initialize():
                return False
            
            # Real-time monitor başlat
            if self.real_time_monitor:
                await self.real_time_monitor.start()
            
            # Regime engine başlat
            if self.regime_engine:
                await self.regime_engine.start_monitoring()
            
            self.is_running = True
            self.start_time = datetime.now()
            
            self.logger.info("Makro Rejim Filtreleme Sistemi başarıyla başlatıldı")
            return True
            
        except Exception as e:
            self.logger.error(f"Sistem başlatma hatası: {e}")
            return False
    
    async def stop(self) -> None:
        """Sistemi durdur"""
        try:
            self.logger.info("Sistem durduruluyor...")
            
            self.is_running = False
            
            # Regime engine durdur
            if self.regime_engine:
                self.regime_engine.stop_monitoring()
            
            # Monitor durdur
            if self.real_time_monitor:
                self.real_time_monitor.stop()
            
            self.logger.info("Sistem başarıyla durduruldu")
            
        except Exception as e:
            self.logger.error(f"Sistem durdurma hatası: {e}")
    
    async def restart(self) -> bool:
        """Sistemi yeniden başlat"""
        await self.stop()
        await asyncio.sleep(5)  # 5 saniye bekle
        return await self.start()
    
    def add_callback(self, callback_type: str, callback) -> None:
        """Callback ekle"""
        if callback_type in self.system_callbacks:
            self.system_callbacks[callback_type].append(callback)
            self.logger.info(f"Callback eklendi: {callback_type}")
        else:
            self.logger.warning(f"Bilinmeyen callback tipi: {callback_type}")
    
    def get_system_status(self) -> Dict[str, Any]:
        """Sistem durumu"""
        uptime = (
            datetime.now() - self.start_time
            if self.start_time
            else None
        )
        
        status = {
            'system': {
                'name': 'Makro Rejim Filtreleme Sistemi',
                'version': self.config.get('system', {}).get('version', '1.0.0'),
                'is_running': self.is_running,
                'start_time': self.start_time.isoformat() if self.start_time else None,
                'uptime_seconds': uptime.total_seconds() if uptime else 0
            },
            'components': {
                'regime_engine': {
                    'initialized': self.regime_engine is not None,
                    'current_regime': self.regime_engine.get_current_regime().value if self.regime_engine else 'unknown',
                    'risk_metrics': self.regime_engine.get_risk_metrics() if self.regime_engine else {}
                },
                'real_time_monitor': {
                    'initialized': self.real_time_monitor is not None,
                    'status': self.real_time_monitor.get_current_status() if self.real_time_monitor else {}
                }
            },
            'configuration': {
                'environment': self.config.get('system', {}).get('environment', 'development'),
                'update_interval': self.config.get('system', {}).get('update_interval', 60),
                'auto_hedge': self.config.get('regime_engine', {}).get('auto_hedge_enabled', True)
            }
        }
        
        return status
    
    def get_regime_summary(self) -> Dict[str, Any]:
        """Rejim özeti"""
        if not self.regime_engine:
            return {'error': 'Regime engine not initialized'}
        
        try:
            # Mevcut rejim
            current_regime = self.regime_engine.get_current_regime()
            
            # Risk metrikleri
            risk_metrics = self.regime_engine.get_risk_metrics()
            
            # Rejim geçmişi
            regime_history = self.regime_engine.get_regime_history(24)  # Son 24 saat
            
            # Makro özet
            macro_summary = self.regime_engine.macro_indicators.get_macro_summary()
            
            return {
                'current_regime': current_regime.value,
                'confidence': risk_metrics.get('confidence', 0.0),
                'risk_level': risk_metrics.get('current_risk_level', 0.0),
                'hedge_ratio': risk_metrics.get('hedge_ratio', 0.0),
                'regime_history': [
                    {
                        'regime': signal.regime.value,
                        'confidence': signal.confidence,
                        'timestamp': signal.timestamp.isoformat()
                    }
                    for signal in regime_history[-10:]  # Son 10 kayıt
                ],
                'macro_summary': macro_summary,
                'last_update': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Rejim özeti alma hatası: {e}")
            return {'error': str(e)}
    
    def get_hedge_status(self) -> Dict[str, Any]:
        """Hedge durumu"""
        if not self.regime_engine:
            return {'error': 'Regime engine not initialized'}
        
        try:
            hedge_summary = self.regime_engine.hedge_manager.get_hedge_summary()
            risk_metrics = self.regime_engine.hedge_manager.get_risk_metrics()
            
            return {
                'hedge_summary': hedge_summary,
                'risk_metrics': risk_metrics,
                'last_update': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Hedge durumu alma hatası: {e}")
            return {'error': str(e)}
    
    def get_strategy_allocation(self) -> Dict[str, Any]:
        """Strateji tahsisi"""
        if not self.regime_engine:
            return {'error': 'Regime engine not initialized'}
        
        try:
            portfolio_summary = self.regime_engine.strategy_activator.get_portfolio_summary()
            
            return {
                'portfolio_summary': portfolio_summary,
                'last_update': datetime.now().isoformat()
            }
            
        except Exception as e:
            self.logger.error(f"Strateji tahsisi alma hatası: {e}")
            return {'error': str(e)}


async def main():
    """Ana fonksiyon"""
    # Graceful shutdown için signal handler
    system = None
    
    def signal_handler(signum, frame):
        nonlocal system
        if system and system.is_running:
            print("\nSistem kapatılıyor...")
            asyncio.create_task(system.stop())
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    try:
        # Sistem oluştur
        system = MacroRegimeSystem()
        
        # Callback örnekleri
        async def example_regime_change_callback(old_regime, new_signal):
            print(f"REJIM DEĞİŞİKLİĞİ: {old_regime.value} -> {new_signal.regime.value}")
        
        async def example_alert_callback(alert):
            print(f"UYARI: {alert.alert_type} - {alert.message}")
        
        async def example_hedge_callback(hedge_signal, result):
            print(f"HEDGE: {hedge_signal.action} - {hedge_signal.reason}")
        
        # Callback'leri ekle
        system.add_callback('regime_change', example_regime_change_callback)
        system.add_callback('alert', example_alert_callback)
        system.add_callback('hedge_signal', example_hedge_callback)
        
        # Sistemi başlat
        print("Makro Rejim Filtreleme Sistemi başlatılıyor...")
        if await system.start():
            print("Sistem başarıyla başlatıldı!")
            print("Durdurmak için Ctrl+C tuşlayın...")
            
            # Ana döngü
            while system.is_running:
                try:
                    # Durum raporu her 60 saniyede bir
                    await asyncio.sleep(60)
                    
                    if system.is_running:
                        status = system.get_system_status()
                        print(f"\n=== SİSTEM DURUMU ===")
                        print(f"Çalışıyor: {status['system']['is_running']}")
                        print(f"Çalışma süresi: {status['system']['uptime_seconds']:.0f} saniye")
                        print(f"Mevcut rejim: {status['components']['regime_engine']['current_regime']}")
                        print(f"Risk seviyesi: {status['components']['regime_engine']['risk_metrics'].get('current_risk_level', 0):.2%}")
                        print(f"Hedge oranı: {status['components']['regime_engine']['risk_metrics'].get('hedge_ratio', 0):.2%}")
                        print("===================\n")
                
                except Exception as e:
                    print(f"Döngü hatası: {e}")
                    await asyncio.sleep(10)
        else:
            print("Sistem başlatılamadı!")
    
    except KeyboardInterrupt:
        print("\nKullanıcı tarafından durduruldu")
    
    except Exception as e:
        print(f"Sistem hatası: {e}")
    
    finally:
        if system:
            await system.stop()
            print("Sistem temizlendi")


if __name__ == "__main__":
    # Logging dizinini oluştur
    os.makedirs('logs', exist_ok=True)
    
    # Ana programı çalıştır
    asyncio.run(main())