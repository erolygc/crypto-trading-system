"""
Makro Rejim Filtreleme Sistemi - Örnek Kullanım ve Testler
========================================================

Sistemin kullanımı ve test edilmesi için örnek kodlar.
"""

import asyncio
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import json
import logging
import sys
import os

# Add the parent directory to the path
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))

from core.regime_classifier import RegimeClassifier
from core.regime_engine import RegimeEngine, RegimeConfig, HedgeSignal
from indicators.macro_indicators import MacroIndicators
from detectors.volatility_detector import VolatilityDetector
from detectors.liquidity_detector import LiquidityDetector
from hedging.hedge_manager import HedgeManager
from strategies.strategy_activator import StrategyActivator
from monitoring.real_time_monitor import RealTimeMonitor, MonitoringAlert


class SystemDemo:
    """Sistem demo ve test sınıfı"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.INFO)
        
        # Demo verileri
        self.demo_market_data = self._generate_demo_data()
        self.demo_macro_data = self._generate_demo_macro_data()
    
    def _generate_demo_data(self, days: int = 100) -> pd.DataFrame:
        """Demo market verisi oluştur"""
        dates = pd.date_range(start=datetime.now() - timedelta(days=days), 
                             end=datetime.now(), freq='1H')
        
        # Simulate different market regimes
        base_price = 100
        prices = [base_price]
        
        for i in range(1, len(dates)):
            # Regime-based price movement
            if i < days * 0.2:  # First 20% - trending up
                daily_return = np.random.normal(0.002, 0.01)
            elif i < days * 0.4:  # Next 20% - ranging
                daily_return = np.random.normal(0, 0.008)
            elif i < days * 0.6:  # Next 20% - volatile
                daily_return = np.random.normal(0, 0.025)
            elif i < days * 0.8:  # Next 20% - trending down
                daily_return = np.random.normal(-0.001, 0.015)
            else:  # Last 20% - crisis
                daily_return = np.random.normal(-0.005, 0.04)
            
            new_price = prices[-1] * (1 + daily_return)
            prices.append(new_price)
        
        # Generate OHLCV data
        data = []
        for i, (date, close) in enumerate(zip(dates, prices)):
            volatility = 0.005 + 0.02 * np.random.random()
            
            high = close * (1 + abs(np.random.normal(0, volatility)))
            low = close * (1 - abs(np.random.normal(0, volatility)))
            open_price = low + np.random.random() * (high - low)
            volume = np.random.randint(1000, 10000)
            
            data.append({
                'timestamp': date,
                'open': open_price,
                'high': high,
                'low': low,
                'close': close,
                'volume': volume
            })
        
        return pd.DataFrame(data)
    
    def _generate_demo_macro_data(self, days: int = 30) -> dict:
        """Demo makro veri oluştur"""
        macro_data = []
        
        for i in range(days):
            # VIX - higher during volatile periods
            if i < 10:
                vix = 15 + np.random.normal(0, 2)  # Low volatility
            elif i < 20:
                vix = 25 + np.random.normal(0, 5)  # Medium volatility
            else:
                vix = 35 + np.random.normal(0, 8)  # High volatility
            
            # Treasury 10Y yield
            treasury_10y = 3.5 + np.random.normal(0, 0.5)
            
            # S&P 500
            sp500 = 4000 + np.random.normal(0, 100)
            
            # Other indicators
            dxy = 100 + np.random.normal(0, 5)
            gold = 2000 + np.random.normal(0, 50)
            oil = 80 + np.random.normal(0, 10)
            
            macro_data.append({
                'timestamp': datetime.now() - timedelta(days=days-i),
                'vix': max(vix, 5),
                'sp500': sp500,
                'treasury_10y': max(treasury_10y, 0.5),
                'dxy': max(dxy, 80),
                'gold': max(gold, 1500),
                'oil': max(oil, 40),
                'interest_rate_fed': 5.25,
                'liquidity_index': 100 + np.random.normal(0, 10),
                'risk_appetite': 0.5 + np.random.normal(0, 0.2)
            })
        
        return {
            'current': macro_data[-1],
            'history': macro_data
        }
    
    async def demo_regime_classifier(self) -> None:
        """Regime classifier demo"""
        print("\n=== REGIME CLASSIFIER DEMO ===")
        
        classifier = RegimeClassifier()
        
        # Test different market conditions
        test_data = self.demo_market_data.tail(100)  # Last 100 data points
        
        # Classify regime
        signal = classifier.classify_regime(test_data)
        
        print(f"Tespit edilen rejim: {signal.regime.value}")
        print(f"Güven seviyesi: {signal.confidence:.2%}")
        print(f"Güç: {signal.strength:.2f}")
        print(f"Tahmini süre: {signal.duration_estimate} saat")
        
        # Show indicators
        print("\nGöstergeler:")
        for key, value in signal.indicators.items():
            print(f"  {key}: {value:.4f}")
        
        # Regime prediction
        prediction = classifier.predict_regime_change()
        print(f"\nRejim değişikliği tahmini:")
        print(f"  Değişiklik olasılığı: {prediction['change_probability']:.2%}")
        print(f"  Sonraki rejim: {prediction['next_regime']}")
    
    async def demo_volatility_detector(self) -> None:
        """Volatility detector demo"""
        print("\n=== VOLATILITY DETECTOR DEMO ===")
        
        detector = VolatilityDetector()
        
        # Generate volatility data
        prices = self.demo_market_data['close'].values
        returns = np.diff(prices) / prices[:-1]
        
        # Update detector with data
        detector.update_data(returns.tolist(), prices.tolist())
        
        # Analyze volatility
        analysis = detector.analyze_volatility()
        
        print(f"Volatilite rejimi: {analysis['regime']}")
        print(f"Volatilite seviyesi: {analysis['volatility_level']:.4f}")
        print(f"Risk seviyesi: {analysis['risk_level']:.2%}")
        print(f"Cluster olasılığı: {analysis['cluster_probability']:.2%}")
        
        # Volatility forecast
        forecast = analysis['volatility_forecast']
        print(f"\nVolatilite tahmini:")
        print(f"  Kısa vadeli: {forecast['short_term']:.4f}")
        print(f"  Orta vadeli: {forecast['medium_term']:.4f}")
        
        # Regime statistics
        stats = detector.get_regime_statistics()
        if stats:
            print(f"\nRejim istatistikleri:")
            print(f"  Toplam dönemler: {stats['total_periods']}")
            print(f"  En yaygın rejim: {stats['most_common_regime']}")
    
    async def demo_liquidity_detector(self) -> None:
        """Liquidity detector demo"""
        print("\n=== LIQUIDITY DETECTOR DEMO ===")
        
        detector = LiquidityDetector()
        
        # Simulate market data updates
        for i in range(20):
            bid = 100 + np.random.normal(0, 0.5)
            ask = bid + 0.01 + np.random.exponential(0.005)
            depth = 1000000 + np.random.normal(0, 200000)
            volume = np.random.randint(5000, 15000)
            
            detector.update_market_data(bid, ask, depth, volume)
        
        # Analyze liquidity
        analysis = detector.analyze_liquidity()
        
        print(f"Likidite rejimi: {analysis['regime']}")
        print(f"Stress seviyesi: {analysis['stress_level']:.2%}")
        print(f"Bid-ask spread: {analysis['bid_ask_spread']:.4f}")
        print(f"Piyasa derinliği: {analysis['market_depth']:,.0f}")
        
        # Liquidity forecast
        forecast = analysis['liquidity_forecast']
        print(f"\nLikidite tahmini:")
        print(f"  Kısa vadeli: {forecast['short_term']:.2f}")
        print(f"  Orta vadeli: {forecast['medium_term']:.2f}")
        
        # Summary
        summary = detector.get_liquidity_summary()
        print(f"\nLikidite özeti:")
        print(f"  Toplam rejim değişikliği: {summary['regime_history']['total_changes']}")
        print(f"  Stress event sayısı: {summary['regime_history']['stress_events']}")
    
    async def demo_hedge_manager(self) -> None:
        """Hedge manager demo"""
        print("\n=== HEDGE MANAGER DEMO ===")
        
        hedge_manager = HedgeManager(sensitivity=0.8)
        
        # Simulate hedge signals
        from core.regime_engine import HedgeSignal
        
        signals = [
            HedgeSignal("increase", 0.2, 0.8, "Volatility increase"),
            HedgeSignal("increase", 0.15, 0.9, "Risk-off regime"),
            HedgeSignal("decrease", 0.1, 0.7, "Volatility decrease")
        ]
        
        # Execute hedge signals
        for signal in signals:
            result = await hedge_manager.execute_hedge_signal(signal)
            print(f"Signal: {signal.action} - Başarılı: {result['success']}")
            
            if result['success']:
                print(f"  Eklenen pozisyon: {result['positions_added']}")
                print(f"  Toplam maliyet: {result['total_cost']:,.2f}")
                print(f"  Yeni hedge oranı: {result['new_hedge_ratio']:.2%}")
        
        # Update positions (simulate price movements)
        await hedge_manager.update_positions()
        
        # Rebalance
        rebalance_result = await hedge_manager.rebalance_positions()
        print(f"\nRebalance sonucu: {rebalance_result['rebalance_needed']}")
        if rebalance_result['actions_taken']:
            for action in rebalance_result['actions_taken']:
                print(f"  {action}")
        
        # Summary
        summary = hedge_manager.get_hedge_summary()
        print(f"\nHedge özeti:")
        print(f"  Mevcut hedge oranı: {summary['current_hedge_ratio']:.2%}")
        print(f"  Toplam pozisyon: {summary['total_positions']}")
        print(f"  Toplam PnL: {summary['total_pnl']:,.2f}")
        print(f"  Win rate: {summary['win_rate']:.2%}")
    
    async def demo_strategy_activator(self) -> None:
        """Strategy activator demo"""
        print("\n=== STRATEGY ACTIVATOR DEMO ===")
        
        activator = StrategyActivator()
        
        # Simulate regime signals
        from core.regime_classifier import RegimeSignal, MarketRegime
        
        regimes = [
            MarketRegime.TRENDING_UP,
            MarketRegime.VOLATILE,
            MarketRegime.CRISIS
        ]
        
        for regime in regimes:
            signal = RegimeSignal(
                regime=regime,
                confidence=0.8,
                strength=0.7,
                duration_estimate=24,
                indicators={'volatility': 0.02, 'trend_strength': 0.6},
                timestamp=datetime.now()
            )
            
            # Update allocations
            allocations = await activator.update_allocations(signal)
            print(f"\nRejim: {regime.value}")
            print("Strateji tahsisleri:")
            for strategy, allocation in allocations.items():
                print(f"  {strategy}: {allocation:.2%}")
        
        # Portfolio summary
        summary = activator.get_portfolio_summary()
        print(f"\nPortföy özeti:")
        print(f"  Toplam tahsis: {summary['total_allocation']:.2%}")
        print(f"  Strateji sayısı: {summary['strategy_count']}")
        print(f"  Risk seviyesi: {summary['risk_level']:.2f}")
        print(f"  Beklenen getiri: {summary['expected_return']:.2%}")
    
    async def demo_macro_indicators(self) -> None:
        """Macro indicators demo"""
        print("\n=== MACRO INDICATORS DEMO ===")
        
        macro_indicators = MacroIndicators()
        
        # Get latest macro data
        latest_data = await macro_indicators.get_latest_data()
        
        print("Güncel makro veriler:")
        for key, value in latest_data.items():
            if key != 'timestamp':
                print(f"  {key}: {value:.4f}")
        
        # Macro summary
        summary = macro_indicators.get_macro_summary()
        print(f"\nMakro özeti:")
        print(f"  Makro rejim: {summary['macro_regime']}")
        print(f"  Risk seviyesi: {summary['risk_level']:.2%}")
        print(f"  Likidite durumu: {summary['liquidity_status']}")
        
        # Indicator trends
        indicators = ['vix', 'sp500', 'treasury_10y']
        for indicator in indicators:
            trend = macro_indicators.get_indicator_trend(indicator)
            print(f"\n{indicator.upper()} trendi:")
            print(f"  Trend: {trend['trend']}")
            print(f"  Güç: {trend['strength']:.2f}")
            print(f"  R²: {trend['r_squared']:.3f}")
    
    async def demo_regime_engine(self) -> None:
        """Regime engine demo"""
        print("\n=== REGIME ENGINE DEMO ===")
        
        # Create regime engine
        from core.regime_engine import RegimeEngine, RegimeConfig
        
        config = RegimeConfig(
            auto_hedge_enabled=True,
            strategy_rotation_enabled=True,
            risk_limit_percent=15.0
        )
        
        engine = RegimeEngine(config)
        
        # Add callbacks
        async def on_regime_change(old_regime, new_signal):
            print(f"🔄 REJIM DEĞİŞİKLİĞİ: {old_regime.value} -> {new_signal.regime.value}")
        
        async def on_hedge_signal(hedge_signal, result):
            print(f"🛡️ HEDGE: {hedge_signal.action} - {hedge_signal.reason}")
        
        async def on_risk_warning(risk_level, risk_data):
            print(f"⚠️ RİSK UYARISI: {risk_level:.2%} - {risk_data}")
        
        engine.add_regime_change_callback(on_regime_change)
        engine.add_hedge_callback(on_hedge_signal)
        engine.add_risk_callback(on_risk_warning)
        
        # Start monitoring (simulated)
        print("Rejim izleme başlatılıyor...")
        
        # Simulate monitoring cycle
        for i in range(3):
            print(f"\n--- Döngü {i+1} ---")
            
            # Simulate regime detection and processing
            await asyncio.sleep(1)  # Simulate processing time
            
            # Get current status
            status = engine.get_risk_metrics()
            print(f"Mevcut rejim: {engine.current_regime.value}")
            print(f"Risk seviyesi: {status['current_risk_level']:.2%}")
            print(f"Hedge oranı: {status['hedge_ratio']:.2%}")
        
        print("\nRejim motoru demo tamamlandı")
    
    async def demo_real_time_monitor(self) -> None:
        """Real-time monitor demo"""
        print("\n=== REAL-TIME MONITOR DEMO ===")
        
        monitor = RealTimeMonitor(update_interval=2)  # 2 second updates
        
        # Add alert callback
        async def on_alert(alert):
            print(f"🚨 ALERT: {alert.alert_type} - {alert.message}")
        
        monitor.add_alert_callback(on_alert)
        
        # Start monitoring
        await monitor.start()
        
        # Simulate monitoring for 10 seconds
        print("Real-time izleme başlatılıyor (10 saniye)...")
        
        for i in range(5):
            await asyncio.sleep(2)
            
            # Get current status
            status = monitor.get_current_status()
            print(f"\nDurum güncellemesi {i+1}:")
            print(f"  Veri noktası sayısı: {status['data_points']}")
            print(f"  Aktif alert: {status['active_alerts']}")
            print(f"  Güncel risk seviyesi: {status['current_risk_level']:.2%}")
        
        # Stop monitoring
        monitor.stop()
        print("Real-time monitor demo tamamlandı")
    
    async def run_full_demo(self) -> None:
        """Tüm sistem demo'su"""
        print("🚀 MAKRO REJİM FİLTRELEME SİSTEMİ DEMO")
        print("=" * 50)
        
        try:
            # Individual component demos
            await self.demo_regime_classifier()
            await asyncio.sleep(1)
            
            await self.demo_volatility_detector()
            await asyncio.sleep(1)
            
            await self.demo_liquidity_detector()
            await asyncio.sleep(1)
            
            await self.demo_macro_indicators()
            await asyncio.sleep(1)
            
            await self.demo_hedge_manager()
            await asyncio.sleep(1)
            
            await self.demo_strategy_activator()
            await asyncio.sleep(1)
            
            await self.demo_regime_engine()
            await asyncio.sleep(1)
            
            await self.demo_real_time_monitor()
            
            print("\n✅ Demo tamamlandı!")
            
        except Exception as e:
            print(f"\n❌ Demo hatası: {e}")


def run_tests() -> None:
    """Sistem testlerini çalıştır"""
    print("🧪 MAKRO REJİM FİLTRELEME SİSTEMİ TESTLERİ")
    print("=" * 50)
    
    # Test 1: Regime Classifier
    print("\n1. Regime Classifier Testi...")
    try:
        classifier = RegimeClassifier()
        test_data = pd.DataFrame({
            'timestamp': pd.date_range('2023-01-01', periods=100, freq='1H'),
            'open': np.random.randn(100).cumsum() + 100,
            'high': np.random.randn(100).cumsum() + 105,
            'low': np.random.randn(100).cumsum() + 95,
            'close': np.random.randn(100).cumsum() + 100,
            'volume': np.random.randint(1000, 10000, 100)
        })
        
        signal = classifier.classify_regime(test_data)
        assert signal.regime is not None
        assert 0 <= signal.confidence <= 1
        print("   ✅ Başarılı")
        
    except Exception as e:
        print(f"   ❌ Hata: {e}")
    
    # Test 2: Volatility Detector
    print("\n2. Volatility Detector Testi...")
    try:
        detector = VolatilityDetector()
        prices = np.random.randn(100).cumsum() + 100
        returns = np.diff(prices) / prices[:-1]
        
        detector.update_data(returns.tolist(), prices.tolist())
        analysis = detector.analyze_volatility()
        assert 'regime' in analysis
        assert 'volatility_level' in analysis
        print("   ✅ Başarılı")
        
    except Exception as e:
        print(f"   ❌ Hata: {e}")
    
    # Test 3: Liquidity Detector
    print("\n3. Liquidity Detector Testi...")
    try:
        detector = LiquidityDetector()
        detector.update_market_data(100, 100.01, 1000000, 5000)
        detector.update_market_data(101, 101.02, 1100000, 6000)
        
        analysis = detector.analyze_liquidity()
        assert 'regime' in analysis
        assert 'stress_level' in analysis
        print("   ✅ Başarılı")
        
    except Exception as e:
        print(f"   ❌ Hata: {e}")
    
    # Test 4: Macro Indicators
    print("\n4. Macro Indicators Testi...")
    try:
        macro = MacroIndicators()
        # Async test
        async def test_macro():
            data = await macro.get_latest_data()
            assert 'vix' in data
            assert 'sp500' in data
            return True
        
        result = asyncio.run(test_macro())
        if result:
            print("   ✅ Başarılı")
        
    except Exception as e:
        print(f"   ❌ Hata: {e}")
    
    print("\n🎯 Testler tamamlandı!")


if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        # Run tests
        run_tests()
    else:
        # Run demo
        demo = SystemDemo()
        asyncio.run(demo.run_full_demo())