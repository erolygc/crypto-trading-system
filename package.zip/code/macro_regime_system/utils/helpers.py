"""
Makro Rejim Filtreleme Sistemi - Utility Fonksiyonları
====================================================

Sistem genelinde kullanılan yardımcı fonksiyonlar ve sınıflar.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple, Any, Union
from datetime import datetime, timedelta
from dataclasses import dataclass
import json
import logging
from scipy import stats
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import warnings

warnings.filterwarnings('ignore')


@dataclass
class SystemConfig:
    """Sistem konfigürasyonu"""
    name: str
    version: str
    environment: str  # 'development', 'testing', 'production'
    debug_mode: bool = False
    log_level: str = 'INFO'
    update_interval: int = 60
    data_retention_days: int = 30
    max_memory_usage_mb: int = 1024
    alert_cooldown_minutes: int = 15


class DataProcessor:
    """Veri işleme yardımcı sınıfı"""
    
    @staticmethod
    def clean_price_data(data: pd.DataFrame, 
                        max_gap_percent: float = 10.0) -> pd.DataFrame:
        """
        Fiyat verilerini temizle
        
        Args:
            data: OHLCV verisi
            max_gap_percent: Maksimum boşluk yüzdesi
            
        Returns:
            Temizlenmiş veri
        """
        cleaned_data = data.copy()
        
        # Null değerleri temizle
        cleaned_data = cleaned_data.dropna()
        
        # Aşırı fiyat boşluklarını tespit et
        if 'close' in cleaned_data.columns:
            close = cleaned_data['close']
            returns = close.pct_change()
            
            # Aşırı değişimleri tespit et
            extreme_changes = returns.abs() > (max_gap_percent / 100)
            
            # Aşırı değişimleri interpolasyon ile düzelt
            if extreme_changes.any():
                cleaned_data.loc[extreme_changes, 'close'] = np.nan
                cleaned_data['close'] = cleaned_data['close'].interpolate(method='linear')
                
                # Diğer kolonları da güncelle
                for col in ['open', 'high', 'low']:
                    if col in cleaned_data.columns:
                        ratio = cleaned_data[col] / cleaned_data['close'].shift(1)
                        cleaned_data[col] = cleaned_data['close'] * ratio
        
        return cleaned_data
    
    @staticmethod
    def calculate_returns(prices: pd.Series, 
                         method: str = 'log') -> pd.Series:
        """
        Getiri hesapla
        
        Args:
            prices: Fiyat serisi
            method: 'log' veya 'simple'
            
        Returns:
            Getiri serisi
        """
        if method == 'log':
            return np.log(prices / prices.shift(1))
        elif method == 'simple':
            return prices.pct_change()
        else:
            raise ValueError("Method must be 'log' or 'simple'")


class StatUtils:
    """İstatistiksel yardımcı fonksiyonlar"""
    
    @staticmethod
    def calculate_percentile(series: pd.Series, 
                           percentile: float) -> float:
        """Yüzdelik hesapla"""
        return np.percentile(series.dropna(), percentile)
    
    @staticmethod
    def calculate_zscore(series: pd.Series) -> pd.Series:
        """Z-score hesapla"""
        return (series - series.mean()) / series.std()
    
    @staticmethod
    def calculate_rolling_correlation(x: pd.Series, 
                                     y: pd.Series, 
                                     window: int = 20) -> pd.Series:
        """Kayan pencereli korelasyon"""
        return x.rolling(window).corr(y)
    
    @staticmethod
    def detect_outliers(series: pd.Series, 
                       method: str = 'iqr',
                       threshold: float = 1.5) -> pd.Series:
        """
        Aykırı değer tespiti
        
        Args:
            series: Veri serisi
            method: 'iqr', 'zscore', 'modified_zscore'
            threshold: Eşik değeri
            
        Returns:
            Aykırı değer maskesi
        """
        if method == 'iqr':
            Q1 = series.quantile(0.25)
            Q3 = series.quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - threshold * IQR
            upper_bound = Q3 + threshold * IQR
            return (series < lower_bound) | (series > upper_bound)
        
        elif method == 'zscore':
            z_scores = np.abs(StatUtils.calculate_zscore(series))
            return z_scores > threshold
        
        elif method == 'modified_zscore':
            median = series.median()
            mad = np.median(np.abs(series - median))
            modified_z_scores = 0.6745 * (series - median) / mad
            return np.abs(modified_z_scores) > threshold
        
        else:
            raise ValueError("Method must be 'iqr', 'zscore', or 'modified_zscore'")
    
    @staticmethod
    def calculate_regime_stability(regimes: List[str], 
                                 window: int = 10) -> float:
        """Rejim stabilitesi hesapla"""
        if len(regimes) < window:
            return 0.0
        
        recent_regimes = regimes[-window:]
        unique_regimes = len(set(recent_regimes))
        
        # Stabilite = 1 - (farklı rejim sayısı / toplam rejim)
        stability = 1 - (unique_regimes / len(recent_regimes))
        return stability


class TechnicalIndicators:
    """Teknik analiz göstergeleri"""
    
    @staticmethod
    def calculate_sma(prices: pd.Series, 
                     window: int) -> pd.Series:
        """Basit hareketli ortalama"""
        return prices.rolling(window).mean()
    
    @staticmethod
    def calculate_ema(prices: pd.Series, 
                     window: int) -> pd.Series:
        """Üssel hareketli ortalama"""
        return prices.ewm(span=window).mean()
    
    @staticmethod
    def calculate_rsi(prices: pd.Series, 
                     window: int = 14) -> pd.Series:
        """Relative Strength Index"""
        delta = prices.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    @staticmethod
    def calculate_bollinger_bands(prices: pd.Series, 
                                 window: int = 20, 
                                 num_std: float = 2) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """Bollinger Bands"""
        sma = prices.rolling(window).mean()
        std = prices.rolling(window).std()
        
        upper_band = sma + (std * num_std)
        lower_band = sma - (std * num_std)
        
        return upper_band, sma, lower_band
    
    @staticmethod
    def calculate_macd(prices: pd.Series, 
                      fast: int = 12, 
                      slow: int = 26, 
                      signal: int = 9) -> Tuple[pd.Series, pd.Series, pd.Series]:
        """MACD"""
        ema_fast = TechnicalIndicators.calculate_ema(prices, fast)
        ema_slow = TechnicalIndicators.calculate_ema(prices, slow)
        
        macd_line = ema_fast - ema_slow
        signal_line = TechnicalIndicators.calculate_ema(macd_line, signal)
        histogram = macd_line - signal_line
        
        return macd_line, signal_line, histogram
    
    @staticmethod
    def calculate_atr(high: pd.Series, 
                     low: pd.Series, 
                     close: pd.Series, 
                     window: int = 14) -> pd.Series:
        """Average True Range"""
        high_low = high - low
        high_close = np.abs(high - close.shift())
        low_close = np.abs(low - close.shift())
        
        true_range = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        return true_range.rolling(window).mean()


class MacroUtils:
    """Makro analiz yardımcı fonksiyonları"""
    
    @staticmethod
    def normalize_macro_indicator(values: pd.Series, 
                                method: str = 'zscore') -> pd.Series:
        """Makro gösterge normalizasyonu"""
        if method == 'zscore':
            return (values - values.mean()) / values.std()
        elif method == 'minmax':
            scaler = MinMaxScaler()
            return pd.Series(scaler.fit_transform(values.values.reshape(-1, 1)).flatten(), index=values.index)
        elif method == 'percentile':
            return values.rank(pct=True)
        else:
            raise ValueError("Method must be 'zscore', 'minmax', or 'percentile'")
    
    @staticmethod
    def calculate_regime_probability(indicators: Dict[str, float],
                                   weights: Dict[str, float]) -> Dict[str, float]:
        """Rejim olasılığı hesapla"""
        probabilities = {}
        total_weight = sum(weights.values())
        
        for regime in ['trending_up', 'trending_down', 'ranging', 'volatile', 'crisis']:
            prob = 0
            
            for indicator, weight in weights.items():
                if indicator in indicators:
                    # Indicator değerini rejim olasılığına çevir
                    indicator_value = indicators[indicator]
                    regime_weight = MacroUtils._indicator_to_regime_weight(indicator, indicator_value, regime)
                    prob += regime_weight * weight
            
            probabilities[regime] = prob / total_weight if total_weight > 0 else 0
        
        return probabilities
    
    @staticmethod
    def _indicator_to_regime_weight(indicator: str, 
                                  value: float, 
                                  regime: str) -> float:
        """Gösterge değerini rejim ağırlığına çevir (dummy implementation)"""
        # Basit kurallar - gerçek sistemde daha karmaşık olabilir
        if indicator == 'vix':
            if regime == 'volatile' or regime == 'crisis':
                return min(value / 30, 1.0)  # Yüksek VIX = volatil/kriz
            else:
                return max(0, 1 - value / 20)
        
        elif indicator == 'treasury_yield':
            if regime == 'trending_up':
                return max(0, (value - 2) / 3)  # Yüksek getiri = trend
            else:
                return 1 - abs(value - 3) / 3
        
        elif indicator == 'sp500_momentum':
            if regime == 'trending_up':
                return max(0, value)
            elif regime == 'trending_down':
                return max(0, -value)
            else:
                return 1 - abs(value)
        
        return 0.5  # Default


class PerformanceMetrics:
    """Performans metrikleri"""
    
    @staticmethod
    def calculate_sharpe_ratio(returns: pd.Series, 
                              risk_free_rate: float = 0.02,
                              periods_per_year: int = 252) -> float:
        """Sharpe ratio hesapla"""
        excess_returns = returns - (risk_free_rate / periods_per_year)
        return excess_returns.mean() / excess_returns.std() * np.sqrt(periods_per_year) if excess_returns.std() > 0 else 0
    
    @staticmethod
    def calculate_max_drawdown(prices: pd.Series) -> Tuple[float, float, float]:
        """Maximum drawdown hesapla"""
        peak = prices.expanding().max()
        drawdown = (prices - peak) / peak
        
        max_drawdown = drawdown.min()
        max_dd_start = drawdown.idxmin()
        max_dd_end = prices.loc[max_dd_start:].idxmax() if max_dd_start < prices.index[-1] else max_dd_start
        
        return max_drawdown, max_dd_start, max_dd_end
    
    @staticmethod
    def calculate_calmar_ratio(returns: pd.Series, 
                              periods_per_year: int = 252) -> float:
        """Calmar ratio hesapla"""
        annual_return = returns.mean() * periods_per_year
        max_dd, _, _ = PerformanceMetrics.calculate_max_drawdown((1 + returns).cumprod())
        return annual_return / abs(max_dd) if max_dd != 0 else 0
    
    @staticmethod
    def calculate_win_rate(returns: pd.Series) -> float:
        """Kazanma oranı hesapla"""
        return (returns > 0).sum() / len(returns) if len(returns) > 0 else 0
    
    @staticmethod
    def calculate_profit_factor(returns: pd.Series) -> float:
        """Profit factor hesapla"""
        profits = returns[returns > 0].sum()
        losses = abs(returns[returns < 0].sum())
        return profits / losses if losses != 0 else float('inf')


class ConfigManager:
    """Konfigürasyon yönetimi"""
    
    @staticmethod
    def load_config(config_path: str) -> Dict:
        """Konfigürasyon dosyası yükle"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logging.error(f"Konfigürasyon yükleme hatası: {e}")
            return {}
    
    @staticmethod
    def save_config(config: Dict, config_path: str) -> None:
        """Konfigürasyon dosyası kaydet"""
        try:
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logging.error(f"Konfigürasyon kaydetme hatası: {e}")
    
    @staticmethod
    def validate_config(config: Dict, required_keys: List[str]) -> Tuple[bool, List[str]]:
        """Konfigürasyon doğrulama"""
        errors = []
        
        for key in required_keys:
            if key not in config:
                errors.append(f"Eksit anahtar: {key}")
        
        return len(errors) == 0, errors


class Logger:
    """Sistem logger yardımcı sınıfı"""
    
    @staticmethod
    def setup_logger(name: str, 
                    log_level: str = 'INFO',
                    log_file: Optional[str] = None,
                    console_output: bool = True) -> logging.Logger:
        """Logger kurulumu"""
        logger = logging.getLogger(name)
        logger.setLevel(getattr(logging, log_level.upper()))
        
        # Format
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
        # File handler
        if log_file:
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)
        
        # Console handler
        if console_output:
            console_handler = logging.StreamHandler()
            console_handler.setFormatter(formatter)
            logger.addHandler(console_handler)
        
        return logger
    
    @staticmethod
    def log_system_event(logger: logging.Logger, 
                        event_type: str, 
                        message: str, 
                        data: Optional[Dict] = None) -> None:
        """Sistem olayı logla"""
        log_data = {
            'event_type': event_type,
            'timestamp': datetime.now().isoformat(),
            'message': message,
            'data': data or {}
        }
        
        logger.info(f"SYSTEM_EVENT: {json.dumps(log_data, ensure_ascii=False)}")


class TimeUtils:
    """Zaman yardımcı fonksiyonları"""
    
    @staticmethod
    def get_market_hours(dt: datetime, 
                        timezone: str = 'UTC',
                        market_hours: Tuple[int, int] = (9, 16)) -> bool:
        """Piyasa saatleri kontrolü"""
        local_dt = TimeUtils._convert_timezone(dt, timezone)
        current_hour = local_dt.hour
        
        market_open, market_close = market_hours
        return market_open <= current_hour < market_close
    
    @staticmethod
    def _convert_timezone(dt: datetime, timezone: str) -> datetime:
        """Zaman dilimi dönüştürme (basitleştirilmiş)"""
        # Gerçek sistemde pytz kullanılır
        return dt
    
    @staticmethod
    def get_next_market_open(dt: datetime) -> datetime:
        """Sonraki piyasa açılış zamanı"""
        next_day = dt + timedelta(days=1)
        return next_day.replace(hour=9, minute=0, second=0, microsecond=0)
    
    @staticmethod
    def get_business_days_between(start_date: datetime, 
                                end_date: datetime) -> int:
        """İş günleri arasındaki fark"""
        business_days = 0
        current_date = start_date
        
        while current_date <= end_date:
            if current_date.weekday() < 5:  # Pazartesi=0, Cuma=4
                business_days += 1
            current_date += timedelta(days=1)
        
        return business_days


class ValidationUtils:
    """Doğrulama yardımcı fonksiyonları"""
    
    @staticmethod
    def validate_price_data(data: pd.DataFrame) -> Tuple[bool, List[str]]:
        """Fiyat verisi doğrulama"""
        errors = []
        
        required_columns = ['open', 'high', 'low', 'close']
        for col in required_columns:
            if col not in data.columns:
                errors.append(f"Eksik kolon: {col}")
        
        # OHLC tutarlılığı
        if all(col in data.columns for col in required_columns):
            invalid_ohlc = (
                (data['high'] < data['low']) |
                (data['high'] < data['open']) |
                (data['high'] < data['close']) |
                (data['low'] > data['open']) |
                (data['low'] > data['close'])
            )
            
            if invalid_ohlc.any():
                errors.append("Geçersiz OHLC değerleri tespit edildi")
        
        # Negatif değerler
        for col in required_columns:
            if col in data.columns and (data[col] <= 0).any():
                errors.append(f"Negatif değerler bulundu: {col}")
        
        # Duplicate timestamps
        if 'timestamp' in data.columns and data['timestamp'].duplicated().any():
            errors.append("Duplicate timestamps bulundu")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def validate_macro_data(data: Dict) -> Tuple[bool, List[str]]:
        """Makro veri doğrulama"""
        errors = []
        
        required_fields = ['timestamp', 'vix', 'sp500', 'treasury_10y']
        for field in required_fields:
            if field not in data:
                errors.append(f"Eksit alan: {field}")
        
        # Değer aralıkları
        if 'vix' in data and not 0 <= data['vix'] <= 100:
            errors.append("VIX değeri geçersiz aralıkta")
        
        if 'treasury_10y' in data and not 0 <= data['treasury_10y'] <= 15:
            errors.append("Treasury 10Y değeri geçersiz aralıkta")
        
        return len(errors) == 0, errors