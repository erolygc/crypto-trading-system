"""
Makro Rejim Filtreleme Sistemi
===============================

Bu sistem otomatik hedge mode, market rejim sınıflandırması ve makro
göstergelerin entegrasyonunu sağlar.

Ana Bileşenler:
- Regime Classification Engine
- Macro Indicators Integration  
- Strategy Activator
- Automatic Hedging Mechanisms
- Risk-on/Risk-off Detection
- Volatility Regime Detection
- Liquidity Stress Detection
- Real-time Regime Monitoring
- Regime Persistence Analysis
- Strategy Adaptation based on Regime
"""

from .core.regime_classifier import RegimeClassifier
from .core.regime_engine import RegimeEngine
from .indicators.macro_indicators import MacroIndicators
from .detectors.volatility_detector import VolatilityDetector
from .detectors.liquidity_detector import LiquidityDetector
from .hedging.hedge_manager import HedgeManager
from .strategies.strategy_activator import StrategyActivator
from .monitoring.real_time_monitor import RealTimeMonitor

__version__ = "1.0.0"
__author__ = "Makro Rejim Filtreleme Sistemi"

__all__ = [
    "RegimeClassifier",
    "RegimeEngine", 
    "MacroIndicators",
    "VolatilityDetector",
    "LiquidityDetector",
    "HedgeManager",
    "StrategyActivator",
    "RealTimeMonitor"
]