"""
Regime Engine - Makro Rejim Motoru
==================================

Makro rejim filtreleme sisteminin ana motoru. Tüm bileşenleri 
koordine eder ve otomatik hedge modunu yönetir.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor

from .regime_classifier import RegimeClassifier, MarketRegime, RegimeSignal
from ..indicators.macro_indicators import MacroIndicators
from ..detectors.volatility_detector import VolatilityDetector
from ..detectors.liquidity_detector import LiquidityDetector
from ..hedging.hedge_manager import HedgeManager
from ..strategies.strategy_activator import StrategyActivator
from ..monitoring.real_time_monitor import RealTimeMonitor


@dataclass
class RegimeConfig:
    """Rejim konfigürasyonu"""
    volatility_threshold: float = 2.0
    trend_threshold: float = 0.7
    crisis_threshold: float = 3.0
    hedge_sensitivity: float = 0.8
    regime_persistence_min: int = 3
    auto_hedge_enabled: bool = True
    strategy_rotation_enabled: bool = True
    risk_limit_percent: float = 10.0


@dataclass
class HedgeSignal:
    """Hedge sinyali"""
    action: str  # 'hedge', 'unhedge', 'increase', 'decrease'
    position_size: float
    confidence: float
    reason: str
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class StrategyAllocation:
    """Strateji tahsisi"""
    strategy_name: str
    allocation_percent: float
    risk_level: float
    expected_return: float
    regime_suitability: float


class RegimeEngine:
    """
    Makro Rejim Motoru
    
    Ana koordinatör. Market rejimlerini tespit eder, hedge pozisyonlarını
    yönetir ve strateji tahsislerini günceller.
    """
    
    def __init__(self, config: Optional[RegimeConfig] = None):
        """
        Args:
            config: Rejim konfigürasyonu
        """
        self.config = config or RegimeConfig()
        
        # Bileşenler
        self.classifier = RegimeClassifier(
            volatility_threshold=self.config.volatility_threshold,
            trend_threshold=self.config.trend_threshold,
            crisis_threshold=self.config.crisis_threshold
        )
        self.macro_indicators = MacroIndicators()
        self.volatility_detector = VolatilityDetector()
        self.liquidity_detector = LiquidityDetector()
        self.hedge_manager = HedgeManager(
            sensitivity=self.config.hedge_sensitivity
        )
        self.strategy_activator = StrategyActivator()
        self.real_time_monitor = RealTimeMonitor()
        
        # Durum
        self.current_regime = MarketRegime.UNKNOWN
        self.regime_signals = []
        self.hedge_signals = []
        self.strategy_allocations = {}
        self.is_running = False
        
        # Callback'ler
        self.regime_change_callbacks: List[Callable] = []
        self.hedge_callbacks: List[Callable] = []
        self.risk_callbacks: List[Callable] = []
        
        # Executor for async operations
        self.executor = ThreadPoolExecutor(max_workers=4)
        
        # Logging
        self.logger = logging.getLogger(__name__)
        
        # Rejim kalıcılığı takibi
        self.regime_persistence = {}
        self.regime_confidence_history = []
        
        # Risk yönetimi
        self.current_risk_level = 0.0
        self.max_risk_limit = self.config.risk_limit_percent / 100.0
        
    async def start_monitoring(self) -> None:
        """Rejim izleme başlat"""
        self.is_running = True
        self.logger.info("Makro rejim motoru başlatıldı")
        
        # Real-time monitor başlat
        await self.real_time_monitor.start()
        
        # Ana loop
        while self.is_running:
            try:
                await self._regime_update_cycle()
                await asyncio.sleep(60)  # 1 dakika güncelleme
            except Exception as e:
                self.logger.error(f"Rejim güncelleme hatası: {e}")
                await asyncio.sleep(10)
    
    def stop_monitoring(self) -> None:
        """Rejim izleme durdur"""
        self.is_running = False
        self.real_time_monitor.stop()
        self.logger.info("Makro rejim motoru durduruldu")
    
    async def _regime_update_cycle(self) -> None:
        """Ana rejim güncelleme döngüsü"""
        # Makro göstergeleri güncelle
        macro_data = await self.macro_indicators.get_latest_data()
        
        # Volatilite analizi
        volatility_analysis = self.volatility_detector.analyze_volatility()
        
        # Likidite analizi
        liquidity_analysis = self.liquidity_detector.analyze_liquidity()
        
        # Market rejimini tespit et
        regime_signal = await self._detect_current_regime(
            macro_data, volatility_analysis, liquidity_analysis
        )
        
        # Rejim kalıcılığını değerlendir
        persistence_score = self._evaluate_regime_persistence(regime_signal)
        
        # Rejim değişikliği kontrolü
        if self._should_change_regime(regime_signal, persistence_score):
            await self._handle_regime_change(regime_signal)
        
        # Hedge stratejisi güncelle
        hedge_signal = await self._update_hedge_strategy(regime_signal)
        if hedge_signal:
            await self._execute_hedge_signal(hedge_signal)
        
        # Strateji tahsislerini güncelle
        await self._update_strategy_allocations(regime_signal)
        
        # Risk seviyesini değerlendir
        await self._assess_risk_level(regime_signal, volatility_analysis, liquidity_analysis)
    
    async def _detect_current_regime(self, macro_data: Dict, 
                                   volatility_analysis: Dict,
                                   liquidity_analysis: Dict) -> RegimeSignal:
        """Mevcut market rejimini tespit et"""
        # Dummy market data (gerçek sistemde market data feed'den gelecek)
        market_data = pd.DataFrame({
            'timestamp': pd.date_range('2023-01-01', periods=100, freq='1H'),
            'open': np.random.randn(100).cumsum() + 100,
            'high': np.random.randn(100).cumsum() + 105,
            'low': np.random.randn(100).cumsum() + 95,
            'close': np.random.randn(100).cumsum() + 100,
            'volume': np.random.randint(1000, 10000, 100)
        })
        
        # Temel rejim sınıflandırması
        base_signal = self.classifier.classify_regime(market_data)
        
        # Makro göstergelerle refine et
        refined_regime = self._refine_regime_with_macro_indicators(
            base_signal, macro_data, volatility_analysis, liquidity_analysis
        )
        
        return refined_regime
    
    def _refine_regime_with_macro_indicators(self, base_signal: RegimeSignal,
                                           macro_data: Dict,
                                           volatility_analysis: Dict,
                                           liquidity_analysis: Dict) -> RegimeSignal:
        """Makro göstergelerle rejimi rafine et"""
        regime = base_signal.regime
        confidence = base_signal.confidence
        indicators = base_signal.indicators.copy()
        
        # VIX seviyesi kontrolü
        if 'vix' in macro_data and macro_data['vix'] > 30:
            # Yüksek VIX - kriz veya volatil rejim
            if regime in [MarketRegime.TRENDING_UP, MarketRegime.RANGING]:
                regime = MarketRegime.VOLATILE
                confidence *= 0.8
        
        # Faiz oranı değişimi
        if 'interest_rate_change' in macro_data:
            rate_change = abs(macro_data['interest_rate_change'])
            if rate_change > 0.5:  # 50bp+ değişim
                regime = MarketRegime.VOLATILE
                confidence *= 0.9
        
        # Likidite stresi
        if liquidity_analysis.get('stress_level', 0) > 0.7:
            regime = MarketRegime.CRISIS
            confidence *= 0.7
        
        # Güncellenmiş göstergeler
        indicators.update({
            'macro_vix': macro_data.get('vix', 15.0),
            'rate_change': macro_data.get('interest_rate_change', 0.0),
            'liquidity_stress': liquidity_analysis.get('stress_level', 0.0),
            'vol_regime': volatility_analysis.get('regime', 'normal'),
            'macro_confidence': confidence
        })
        
        return RegimeSignal(
            regime=regime,
            confidence=confidence,
            strength=base_signal.strength,
            duration_estimate=base_signal.duration_estimate,
            indicators=indicators,
            timestamp=pd.Timestamp.now()
        )
    
    def _evaluate_regime_persistence(self, signal: RegimeSignal) -> float:
        """Rejim kalıcılığını değerlendir (0-1)"""
        if len(self.regime_signals) < 3:
            return 0.5
        
        # Son 10 sinyal
        recent_signals = self.regime_signals[-10:]
        
        # Aynı rejim sayısı
        same_regime_count = sum(1 for s in recent_signals if s.regime == signal.regime)
        persistence_ratio = same_regime_count / len(recent_signals)
        
        # Güven seviyesi stabilitesi
        conf_variance = np.var([s.confidence for s in recent_signals[-5:]])
        confidence_stability = 1.0 / (1.0 + conf_variance)
        
        # Rejim gücü
        strength_component = signal.strength
        
        # Ağırlıklı ortalama
        persistence_score = (
            0.5 * persistence_ratio +
            0.3 * confidence_stability +
            0.2 * strength_component
        )
        
        return min(persistence_score, 1.0)
    
    def _should_change_regime(self, signal: RegimeSignal, persistence_score: float) -> bool:
        """Rejim değişikliği gerekli mi?"""
        # Kalıcılık eşiği
        if persistence_score < 0.6:
            return True
        
        # Güven eşiği
        if signal.confidence < 0.5:
            return True
        
        # Rejim süresi kontrolü
        current_regime_count = 0
        for recent_signal in reversed(self.regime_signals):
            if recent_signal.regime == signal.regime:
                current_regime_count += 1
            else:
                break
        
        # Minimum rejim süresi
        if current_regime_count < self.config.regime_persistence_min:
            return False
        
        # Aşırı volatil rejim değişikliği
        if signal.regime == MarketRegime.VOLATILE and current_regime_count > 10:
            return True
        
        return False
    
    async def _handle_regime_change(self, new_signal: RegimeSignal) -> None:
        """Rejim değişikliğini yönet"""
        old_regime = self.current_regime
        self.current_regime = new_signal.regime
        
        self.logger.info(
            f"Rejim değişikliği: {old_regime.value} -> {new_signal.regime.value} "
            f"(Güven: {new_signal.confidence:.2f})"
        )
        
        # Callback'leri çağır
        for callback in self.regime_change_callbacks:
            try:
                await callback(old_regime, new_signal)
            except Exception as e:
                self.logger.error(f"Regime change callback hatası: {e}")
        
        # Hedge stratejisini güncelle
        await self._adapt_hedge_to_regime(new_signal)
        
        # Strateji tahsislerini rotasyona tabi tut
        if self.config.strategy_rotation_enabled:
            await self._rotate_strategies(new_signal)
    
    async def _update_hedge_strategy(self, regime_signal: RegimeSignal) -> Optional[HedgeSignal]:
        """Hedge stratejisini güncelle"""
        if not self.config.auto_hedge_enabled:
            return None
        
        # Mevcut hedge pozisyonu
        current_hedge = await self.hedge_manager.get_current_hedge()
        
        # Rejime göre hedge ihtiyacı
        required_hedge = self._calculate_required_hedge(regime_signal)
        
        # Hedge farkı
        hedge_delta = required_hedge - current_hedge
        
        # Önemli değişiklik kontrolü
        if abs(hedge_delta) < 0.05:  # %5'ten az değişim
            return None
        
        # Hedge sinyali oluştur
        action = 'increase' if hedge_delta > 0 else 'decrease'
        
        return HedgeSignal(
            action=action,
            position_size=abs(hedge_delta),
            confidence=regime_signal.confidence,
            reason=f"Rejim: {regime_signal.regime.value}"
        )
    
    def _calculate_required_hedge(self, regime_signal: RegimeSignal) -> float:
        """Rejime göre gerekli hedge oranı"""
        base_hedge_ratios = {
            MarketRegime.TRENDING_UP: 0.2,
            MarketRegime.TRENDING_DOWN: 0.6,
            MarketRegime.RANGING: 0.3,
            MarketRegime.VOLATILE: 0.8,
            MarketRegime.CRISIS: 1.0,
            MarketRegime.UNKNOWN: 0.5
        }
        
        base_ratio = base_hedge_ratios.get(regime_signal.regime, 0.5)
        
        # Güven seviyesi faktörü
        confidence_factor = regime_signal.confidence
        
        # Volatilite faktörü
        volatility_factor = regime_signal.indicators.get('volatility', 0.0)
        volatility_multiplier = 1.0 + (volatility_factor * 0.5)
        
        # Final hedge oranı
        required_hedge = base_ratio * confidence_factor * volatility_multiplier
        
        return min(required_hedge, 1.0)
    
    async def _execute_hedge_signal(self, hedge_signal: HedgeSignal) -> None:
        """Hedge sinyalini uygula"""
        # Hedge manager'a gönder
        result = await self.hedge_manager.execute_hedge_signal(hedge_signal)
        
        if result['success']:
            self.logger.info(
                f"Hedge uygulandı: {hedge_signal.action} "
                f"(Boyut: {hedge_signal.position_size:.2f})"
            )
            
            # Callback'leri çağır
            for callback in self.hedge_callbacks:
                try:
                    await callback(hedge_signal, result)
                except Exception as e:
                    self.logger.error(f"Hedge callback hatası: {e}")
    
    async def _update_strategy_allocations(self, regime_signal: RegimeSignal) -> None:
        """Strateji tahsislerini güncelle"""
        # Strateji aktivatör'e rejim bilgisi gönder
        allocations = await self.strategy_activator.update_allocations(regime_signal)
        
        self.strategy_allocations = allocations
        
        self.logger.debug(
            f"Strateji tahsisleri güncellendi - {len(allocations)} strateji"
        )
    
    async def _assess_risk_level(self, regime_signal: RegimeSignal,
                               volatility_analysis: Dict,
                               liquidity_analysis: Dict) -> None:
        """Risk seviyesini değerlendir"""
        risk_components = []
        
        # Rejim riski
        regime_risks = {
            MarketRegime.TRENDING_UP: 0.2,
            MarketRegime.TRENDING_DOWN: 0.6,
            MarketRegime.RANGING: 0.3,
            MarketRegime.VOLATILE: 0.8,
            MarketRegime.CRISIS: 1.0,
            MarketRegime.UNKNOWN: 0.5
        }
        regime_risk = regime_risks.get(regime_signal.regime, 0.5)
        risk_components.append(regime_risk)
        
        # Volatilite riski
        vol_risk = volatility_analysis.get('risk_level', 0.0)
        risk_components.append(vol_risk)
        
        # Likidite riski
        liq_risk = liquidity_analysis.get('stress_level', 0.0)
        risk_components.append(liq_risk)
        
        # Genel risk seviyesi
        self.current_risk_level = np.mean(risk_components)
        
        # Risk limiti kontrolü
        if self.current_risk_level > self.max_risk_limit:
            await self._handle_high_risk(regime_signal)
        
        # Risk callback'leri
        for callback in self.risk_callbacks:
            try:
                await callback(self.current_risk_level, {
                    'regime': regime_signal.regime.value,
                    'volatility': vol_risk,
                    'liquidity': liq_risk
                })
            except Exception as e:
                self.logger.error(f"Risk callback hatası: {e}")
    
    async def _handle_high_risk(self, regime_signal: RegimeSignal) -> None:
        """Yüksek risk durumunu yönet"""
        self.logger.warning(
            f"Yüksek risk seviyesi: {self.current_risk_level:.2f} "
            f"(Limit: {self.max_risk_limit:.2f})"
        )
        
        # Acil hedge artırımı
        hedge_signal = HedgeSignal(
            action='increase',
            position_size=min(self.current_risk_level - self.max_risk_limit, 0.3),
            confidence=1.0,
            reason="Yüksek risk seviyesi"
        )
        
        await self._execute_hedge_signal(hedge_signal)
    
    async def _adapt_hedge_to_regime(self, regime_signal: RegimeSignal) -> None:
        """Rejime göre hedge adaptasyonu"""
        # Rejim spesifik hedge parametreleri
        hedge_params = self._get_regime_hedge_params(regime_signal.regime)
        
        # Hedge manager parametrelerini güncelle
        await self.hedge_manager.update_parameters(hedge_params)
    
    def _get_regime_hedge_params(self, regime: MarketRegime) -> Dict:
        """Rejim spesifik hedge parametreleri"""
        base_params = {
            'max_hedge_ratio': 1.0,
            'hedge_sensitivity': self.config.hedge_sensitivity,
            'rebalance_frequency': 'daily'
        }
        
        regime_specific = {
            MarketRegime.TRENDING_UP: {
                'max_hedge_ratio': 0.3,
                'hedge_sensitivity': 0.6,
                'preferred_instruments': ['call_options', 'long_equity']
            },
            MarketRegime.TRENDING_DOWN: {
                'max_hedge_ratio': 0.8,
                'hedge_sensitivity': 0.9,
                'preferred_instruments': ['put_options', 'short_equity', 'bonds']
            },
            MarketRegime.RANGING: {
                'max_hedge_ratio': 0.4,
                'hedge_sensitivity': 0.7,
                'preferred_instruments': ['straddles', 'volatility_trading']
            },
            MarketRegime.VOLATILE: {
                'max_hedge_ratio': 1.0,
                'hedge_sensitivity': 1.0,
                'preferred_instruments': ['puts', 'vix_futures', 'safe_havens']
            },
            MarketRegime.CRISIS: {
                'max_hedge_ratio': 1.0,
                'hedge_sensitivity': 1.0,
                'preferred_instruments': ['treasuries', 'gold', 'cash']
            }
        }
        
        params = base_params.copy()
        params.update(regime_specific.get(regime, {}))
        
        return params
    
    async def _rotate_strategies(self, regime_signal: RegimeSignal) -> None:
        """Rejime göre strateji rotasyonu"""
        # Mevcut stratejiler
        current_strategies = list(self.strategy_allocations.keys())
        
        # Rejim için uygun stratejiler
        suitable_strategies = self._get_regime_strategies(regime_signal.regime)
        
        # Strateji rotasyonu (basitleştirilmiş)
        new_allocations = await self.strategy_activator.rotate_strategies(
            current_strategies, suitable_strategies, regime_signal
        )
        
        self.logger.info(
            f"Strateji rotasyonu: {len(current_strategies)} -> {len(new_allocations)} strateji"
        )
    
    def _get_regime_strategies(self, regime: MarketRegime) -> List[str]:
        """Rejim için uygun stratejiler"""
        strategy_mapping = {
            MarketRegime.TRENDING_UP: [
                'momentum_long', 'growth_stocks', 'sector_rotation'
            ],
            MarketRegime.TRENDING_DOWN: [
                'value_hunting', 'short_strategy', 'defensive_sectors'
            ],
            MarketRegime.RANGING: [
                'mean_reversion', 'pairs_trading', 'market_neutral'
            ],
            MarketRegime.VOLATILE: [
                'volatility_trading', 'short_volatility', 'hedge_heavy'
            ],
            MarketRegime.CRISIS: [
                'capital_preservation', 'safe_havens', 'cash_position'
            ]
        }
        
        return strategy_mapping.get(regime, ['balanced_portfolio'])
    
    # Public API methods
    
    def add_regime_change_callback(self, callback: Callable) -> None:
        """Rejim değişikliği callback'i ekle"""
        self.regime_change_callbacks.append(callback)
    
    def add_hedge_callback(self, callback: Callable) -> None:
        """Hedge callback'i ekle"""
        self.hedge_callbacks.append(callback)
    
    def add_risk_callback(self, callback: Callable) -> None:
        """Risk callback'i ekle"""
        self.risk_callbacks.append(callback)
    
    def get_current_regime(self) -> MarketRegime:
        """Mevcut rejimi getir"""
        return self.current_regime
    
    def get_regime_history(self, hours: int = 24) -> List[RegimeSignal]:
        """Rejim geçmişini getir"""
        cutoff = pd.Timestamp.now() - pd.Timedelta(hours=hours)
        return [signal for signal in self.regime_signals if signal.timestamp >= cutoff]
    
    def get_risk_metrics(self) -> Dict:
        """Risk metriklerini getir"""
        return {
            'current_risk_level': self.current_risk_level,
            'max_risk_limit': self.max_risk_limit,
            'regime': self.current_regime.value,
            'hedge_ratio': self.hedge_manager.get_current_hedge(),
            'confidence': self.classifier.regime_history[-1].confidence if self.classifier.regime_history else 0.0
        }