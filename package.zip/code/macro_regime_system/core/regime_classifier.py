"""
Regime Classifier - Market Rejim Sınıflandırma Motoru
====================================================

Market rejimlerini (trending, ranging, volatile, crisis) tespit eden
temel sınıflandırma motoru.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum

# Optional TensorFlow import
try:
    import tensorflow as tf
    TENSORFLOW_AVAILABLE = True
except ImportError:
    tf = None
    TENSORFLOW_AVAILABLE = False

from scipy import stats
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier


class MarketRegime(Enum):
    """Market rejimleri"""
    TRENDING_UP = "trending_up"
    TRENDING_DOWN = "trending_down" 
    RANGING = "ranging"
    VOLATILE = "volatile"
    CRISIS = "crisis"
    UNKNOWN = "unknown"


@dataclass
class RegimeSignal:
    """Rejim sinyali yapısı"""
    regime: MarketRegime
    confidence: float
    strength: float
    duration_estimate: int
    indicators: Dict[str, float]
    timestamp: pd.Timestamp


class RegimeClassifier:
    """
    Makro rejim sınıflandırıcısı
    
    Market rejimlerini tespit eden ana motor. Trend, range, volatilite
    ve kriz rejimlerini ayırt eder.
    """
    
    def __init__(self, 
                 volatility_threshold: float = 2.0,
                 trend_threshold: float = 0.7,
                 crisis_threshold: float = 3.0):
        """
        Args:
            volatility_threshold: Volatilite eşiği
            trend_threshold: Trend güç eşiği
            crisis_threshold: Kriz eşiği
        """
        self.volatility_threshold = volatility_threshold
        self.trend_threshold = trend_threshold
        self.crisis_threshold = crisis_threshold
        
        # Model bileşenleri
        self.scaler = StandardScaler()
        self.rf_classifier = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42
        )
        self.ml_model = None
        self.is_trained = False
        
        # Rejim geçmişi
        self.regime_history = []
        self.last_regime = MarketRegime.UNKNOWN
        
        self._initialize_ml_model()
    
    def _initialize_ml_model(self):
        """TensorFlow ML modeli başlat"""
        if not TENSORFLOW_AVAILABLE:
            self.ml_model = None
            return
            
        self.ml_model = tf.keras.Sequential([
            tf.keras.layers.Dense(128, activation='relu', input_shape=(20,)),
            tf.keras.layers.Dropout(0.3),
            tf.keras.layers.Dense(64, activation='relu'),
            tf.keras.layers.Dropout(0.3),
            tf.keras.layers.Dense(32, activation='relu'),
            tf.keras.layers.Dense(5, activation='softmax')  # 5 rejim tipi
        ])
        
        self.ml_model.compile(
            optimizer='adam',
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy']
        )
    
    def extract_features(self, data: pd.DataFrame) -> np.ndarray:
        """
        Rejim tespiti için özellik çıkarımı
        
        Args:
            data: OHLCV verisi
            
        Returns:
            Özellik vektörü
        """
        features = []
        
        # Teknik özellikler
        if len(data) >= 20:
            close = data['close'].values
            high = data['high'].values
            low = data['low'].values
            volume = data['volume'].values if 'volume' in data.columns else np.ones(len(data))
            
            # Volatilite özellikleri
            returns = np.diff(close) / close[:-1]
            features.extend([
                np.std(returns),  # Volatilite
                np.mean(returns),  # Ortalama getiri
                stats.skew(returns),  # Çarpıklık
                stats.kurtosis(returns),  # Basıklık
            ])
            
            # Trend özellikleri
            trend_strength = self._calculate_trend_strength(close)
            features.extend([
                trend_strength,
                self._calculate_adx(close, high, low),  # ADX
                self._calculate_rsi(close),  # RSI
            ])
            
            # Range özellikleri
            range_ratio = self._calculate_range_ratio(high, low, close)
            features.extend([
                range_ratio,
                self._calculate_support_resistance_strength(high, low),
            ])
            
            # Hacim özellikleri
            if len(volume) > 0:
                features.extend([
                    np.mean(volume[-10:]) / np.mean(volume[-20:]) if len(volume) >= 20 else 1.0,  # Hacim oranı
                    np.std(volume[-10:]) / np.mean(volume[-10:]) if len(volume) >= 10 else 0.0,  # Hacim volatilitesi
                ])
            else:
                features.extend([1.0, 0.0])
            
            # Momentum özellikleri
            momentum = self._calculate_momentum(close)
            features.extend([
                momentum,
                self._calculate_momentum_divergence(close),
            ])
            
            # Makro göstergeler (dummy değerler - gerçek sistemde API'den gelecek)
            features.extend([
                15.0 + np.random.normal(0, 2),  # VIX (dummy)
                2.5 + np.random.normal(0, 0.5),  # Faiz oranı (dummy)
                100.0 + np.random.normal(0, 10),  # Likidite endeksi (dummy)
                0.5 + np.random.normal(0, 0.1),  # Risk iştahı (dummy)
            ])
            
        # 20 özelliğe tamamla
        while len(features) < 20:
            features.append(0.0)
            
        return np.array(features[:20])
    
    def _calculate_trend_strength(self, prices: np.ndarray) -> float:
        """Trend gücü hesapla"""
        if len(prices) < 10:
            return 0.0
        
        # Linear regression slope
        x = np.arange(len(prices))
        slope, _, r_value, _, _ = stats.linregress(x, prices)
        
        return abs(r_value) * np.sign(slope)
    
    def _calculate_adx(self, close: np.ndarray, high: np.ndarray, low: np.ndarray) -> float:
        """ADX hesapla"""
        if len(close) < 14:
            return 0.0
        
        # Basit ADX approximation
        high_low = high - low
        high_close = np.abs(high - np.roll(close, 1))
        low_close = np.abs(low - np.roll(close, 1))
        
        true_range = np.maximum(high_low, np.maximum(high_close, low_close))
        dm_plus = np.where((high - np.roll(high, 1)) > (np.roll(low, 1) - low),
                          np.maximum(high - np.roll(high, 1), 0), 0)
        dm_minus = np.where((np.roll(low, 1) - low) > (high - np.roll(high, 1)),
                           np.maximum(np.roll(low, 1) - low, 0), 0)
        
        atr = np.mean(true_range[-14:])
        di_plus = 100 * (np.mean(dm_plus[-14:]) / atr) if atr > 0 else 0
        di_minus = 100 * (np.mean(dm_minus[-14:]) / atr) if atr > 0 else 0
        
        dx = 100 * np.abs(di_plus - di_minus) / (di_plus + di_minus) if (di_plus + di_minus) > 0 else 0
        return dx / 100.0  # Normalize to 0-1
    
    def _calculate_rsi(self, prices: np.ndarray) -> float:
        """RSI hesapla"""
        if len(prices) < 14:
            return 0.5
        
        delta = np.diff(prices)
        gain = np.where(delta > 0, delta, 0)
        loss = np.where(delta < 0, -delta, 0)
        
        avg_gain = np.mean(gain[-14:])
        avg_loss = np.mean(loss[-14:])
        
        if avg_loss == 0:
            return 1.0
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        return rsi / 100.0  # Normalize to 0-1
    
    def _calculate_range_ratio(self, high: np.ndarray, low: np.ndarray, close: np.ndarray) -> float:
        """Range oranı hesapla"""
        if len(high) < 10:
            return 0.0
        
        recent_range = np.mean(high[-10:] - low[-10:])
        historical_range = np.mean(high[-20:] - low[-20:]) if len(high) >= 20 else recent_range
        
        return recent_range / historical_range if historical_range > 0 else 1.0
    
    def _calculate_support_resistance_strength(self, high: np.ndarray, low: np.ndarray) -> float:
        """Destek-direnç gücü hesapla"""
        if len(high) < 20:
            return 0.0
        
        # Basit support/resistance detection
        price_center = (np.mean(high[-20:]) + np.mean(low[-20:])) / 2
        recent_price = np.mean(high[-5:] + low[-5:]) / 2
        
        return abs(recent_price - price_center) / price_center if price_center > 0 else 0.0
    
    def _calculate_momentum(self, prices: np.ndarray) -> float:
        """Momentum hesapla"""
        if len(prices) < 10:
            return 0.0
        
        momentum = (prices[-1] - prices[-10]) / prices[-10] if prices[-10] > 0 else 0.0
        return momentum
    
    def _calculate_momentum_divergence(self, prices: np.ndarray) -> float:
        """Momentum diverjansı hesapla"""
        if len(prices) < 20:
            return 0.0
        
        # Price vs momentum divergence
        price_change = (prices[-1] - prices[-10]) / prices[-10]
        momentum_change = (prices[-10] - prices[-20]) / prices[-20] if len(prices) >= 20 else 0
        
        return price_change - momentum_change
    
    def classify_regime(self, data: pd.DataFrame) -> RegimeSignal:
        """
        Market rejimini sınıflandır
        
        Args:
            data: OHLCV verisi
            
        Returns:
            Rejim sinyali
        """
        if len(data) < 20:
            return RegimeSignal(
                regime=MarketRegime.UNKNOWN,
                confidence=0.0,
                strength=0.0,
                duration_estimate=0,
                indicators={},
                timestamp=pd.Timestamp.now()
            )
        
        # Özellik çıkarımı
        features = self.extract_features(data)
        
        # Rejim tespiti
        regime, confidence, strength = self._classify_regime_ml(features)
        
        # Süre tahmini
        duration_estimate = self._estimate_regime_duration(regime, features)
        
        # Göstergeler
        indicators = self._calculate_regime_indicators(data)
        
        # Rejim sinyali oluştur
        signal = RegimeSignal(
            regime=regime,
            confidence=confidence,
            strength=strength,
            duration_estimate=duration_estimate,
            indicators=indicators,
            timestamp=pd.Timestamp.now()
        )
        
        # Geçmişe ekle
        self.regime_history.append(signal)
        self.last_regime = regime
        
        return signal
    
    def _classify_regime_ml(self, features: np.ndarray) -> Tuple[MarketRegime, float, float]:
        """ML modeli ile rejim sınıflandırması"""
        if not self.is_trained:
            return self._classify_regime_rule_based(features)
        
        # ML model prediction (dummy implementation)
        # Gerçek sistemde eğitilmiş model kullanılacak
        return self._classify_regime_rule_based(features)
    
    def _classify_regime_rule_based(self, features: np.ndarray) -> Tuple[MarketRegime, float, float]:
        """Kural tabanlı rejim sınıflandırması"""
        if len(features) < 15:
            return MarketRegime.UNKNOWN, 0.0, 0.0
        
        volatility = features[0] if len(features) > 0 else 0.0
        trend_strength = features[4] if len(features) > 4 else 0.0
        range_ratio = features[8] if len(features) > 8 else 1.0
        
        # Crisis detection
        if volatility > self.crisis_threshold:
            return MarketRegime.CRISIS, min(volatility / self.crisis_threshold, 1.0), volatility
        
        # Volatile detection
        if volatility > self.volatility_threshold:
            return MarketRegime.VOLATILE, min(volatility / self.volatility_threshold, 1.0), volatility
        
        # Trend detection
        if abs(trend_strength) > self.trend_threshold:
            regime = MarketRegime.TRENDING_UP if trend_strength > 0 else MarketRegime.TRENDING_DOWN
            confidence = abs(trend_strength)
            return regime, confidence, abs(trend_strength)
        
        # Ranging detection
        return MarketRegime.RANGING, 1.0 - volatility, 1.0 - volatility
    
    def _estimate_regime_duration(self, regime: MarketRegime, features: np.ndarray) -> int:
        """Rejim süresi tahmini"""
        # Basit süre tahmini (gün cinsinden)
        base_duration = {
            MarketRegime.TRENDING_UP: 30,
            MarketRegime.TRENDING_DOWN: 20,
            MarketRegime.RANGING: 14,
            MarketRegime.VOLATILE: 7,
            MarketRegime.CRISIS: 5,
            MarketRegime.UNKNOWN: 1
        }
        
        # Volatilite faktörü
        volatility_factor = 1.0 / (1.0 + features[0]) if len(features) > 0 else 1.0
        
        return int(base_duration.get(regime, 1) * volatility_factor)
    
    def _calculate_regime_indicators(self, data: pd.DataFrame) -> Dict[str, float]:
        """Rejim göstergelerini hesapla"""
        indicators = {}
        
        if len(data) >= 20:
            close = data['close'].values
            
            # Teknik göstergeler
            indicators['volatility'] = np.std(np.diff(close) / close[:-1])
            indicators['trend_strength'] = self._calculate_trend_strength(close)
            indicators['momentum'] = self._calculate_momentum(close)
            
            # Makro göstergeler (dummy)
            indicators['vix_level'] = 15.0 + np.random.normal(0, 2)
            indicators['interest_rate'] = 2.5 + np.random.normal(0, 0.5)
            indicators['liquidity_index'] = 100.0 + np.random.normal(0, 10)
            indicators['risk_appetite'] = 0.5 + np.random.normal(0, 0.1)
        
        return indicators
    
    def train_model(self, training_data: List[Dict]) -> None:
        """ML modelini eğit"""
        if not training_data:
            return
        
        # Eğitim verilerini hazırla
        X = []
        y = []
        
        for data_point in training_data:
            features = self.extract_features(data_point['data'])
            regime_map = {
                'trending_up': 0,
                'trending_down': 1,
                'ranging': 2,
                'volatile': 3,
                'crisis': 4
            }
            label = regime_map.get(data_point['regime'], 4)
            
            X.append(features)
            y.append(label)
        
        X = np.array(X)
        y = np.array(y)
        
        # Özellikleri normalize et
        X_scaled = self.scaler.fit_transform(X)
        
        # Random Forest eğit
        self.rf_classifier.fit(X_scaled, y)
        
        # TensorFlow modelini eğit
        self.ml_model.fit(X_scaled, y, epochs=50, batch_size=32, validation_split=0.2, verbose=0)
        
        self.is_trained = True
    
    def get_regime_history(self, days: int = 30) -> List[RegimeSignal]:
        """Geçmiş rejimleri getir"""
        cutoff_date = pd.Timestamp.now() - pd.Timedelta(days=days)
        return [signal for signal in self.regime_history if signal.timestamp >= cutoff_date]
    
    def predict_regime_change(self) -> Dict[str, float]:
        """Rejim değişikliği tahmini"""
        if len(self.regime_history) < 5:
            return {'change_probability': 0.0, 'next_regime': 'unknown'}
        
        recent_regimes = [signal.regime for signal in self.regime_history[-5:]]
        
        # Basit geçiş olasılığı
        change_indicators = []
        
        # Volatilite artışı
        recent_vol = np.mean([signal.strength for signal in self.regime_history[-3:]])
        older_vol = np.mean([signal.strength for signal in self.regime_history[-10:-3]]) if len(self.regime_history) >= 10 else recent_vol
        
        change_indicators.append(max(0, (recent_vol - older_vol) / older_vol) if older_vol > 0 else 0)
        
        # Güven seviyesi düşüşü
        recent_conf = np.mean([signal.confidence for signal in self.regime_history[-3:]])
        older_conf = np.mean([signal.confidence for signal in self.regime_history[-10:-3]]) if len(self.regime_history) >= 10 else recent_conf
        
        change_indicators.append(max(0, (1 - recent_conf)))
        
        # Ortalama değişiklik olasılığı
        change_probability = np.mean(change_indicators)
        
        # En muhtemel sonraki rejim
        regime_counts = {}
        for regime in recent_regimes:
            regime_counts[regime] = regime_counts.get(regime, 0) + 1
        
        next_regime = max(regime_counts, key=regime_counts.get) if regime_counts else MarketRegime.UNKNOWN
        
        return {
            'change_probability': min(change_probability, 1.0),
            'next_regime': next_regime.value,
            'confidence': np.mean([signal.confidence for signal in self.regime_history[-3:]])
        }