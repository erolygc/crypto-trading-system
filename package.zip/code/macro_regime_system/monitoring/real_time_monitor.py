"""
Real-time Monitor - Canlı Rejim İzleme
======================================

Real-time market rejim izleme ve analiz sistemi.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Callable, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
import asyncio
import logging
import json
from concurrent.futures import ThreadPoolExecutor
import websockets
import aiohttp
from threading import Lock


@dataclass
class MonitoringAlert:
    """İzleme uyarısı"""
    alert_type: str  # 'regime_change', 'risk_level', 'volatility_spike', 'liquidity_stress'
    severity: str    # 'low', 'medium', 'high', 'critical'
    message: str
    data: Dict[str, Any]
    timestamp: datetime = field(default_factory=datetime.now)
    acknowledged: bool = False


@dataclass
class MarketDataPoint:
    """Market veri noktası"""
    timestamp: datetime
    price: float
    volume: float
    bid: float
    ask: float
    indicators: Dict[str, float] = field(default_factory=dict)


class RealTimeMonitor:
    """
    Real-time Monitor
    
    Canlı market rejim izleme, uyarı sistemi ve veri akışı yönetimi.
    """
    
    def __init__(self, 
                 update_interval: int = 60,
                 alert_thresholds: Optional[Dict] = None):
        """
        Args:
            update_interval: Güncelleme aralığı (saniye)
            alert_thresholds: Uyarı eşikleri
        """
        self.update_interval = update_interval
        self.alert_thresholds = alert_thresholds or self._default_alert_thresholds()
        
        # Durum
        self.is_running = False
        self.last_update = None
        
        # Veri saklama
        self.market_data: List[MarketDataPoint] = []
        self.max_data_points = 1000
        
        # Alert sistemi
        self.alerts: List[MonitoringAlert] = []
        self.active_alerts: Dict[str, MonitoringAlert] = {}
        self.alert_callbacks: List[Callable] = []
        
        # İstatistikler
        self.monitoring_stats = {
            'total_updates': 0,
            'alerts_generated': 0,
            'regime_changes_detected': 0,
            'data_points_processed': 0,
            'uptime_start': None
        }
        
        # Threading
        self.data_lock = Lock()
        self.executor = ThreadPoolExecutor(max_workers=3)
        
        # WebSocket connections (dummy)
        self.websocket_connections = []
        self.http_clients = []
        
        # Logging
        self.logger = logging.getLogger(__name__)
        
        # Son rejim durumu
        self.last_regime = None
        self.regime_stability_counter = 0
        
        # Risk metrikleri
        self.current_risk_level = 0.0
        self.volatility_baseline = 0.02
        
    def _default_alert_thresholds(self) -> Dict:
        """Varsayılan uyarı eşikleri"""
        return {
            'regime_change_confidence': 0.8,
            'volatility_spike': 2.0,  # 2x normal volatilite
            'liquidity_stress': 0.7,
            'risk_level_high': 0.8,
            'risk_level_critical': 0.95,
            'price_change_pct': 0.05,  # %5 fiyat değişimi
            'volume_spike': 3.0,  # 3x normal hacim
            'spread_widening': 2.0  # 2x normal spread
        }
    
    async def start(self) -> None:
        """İzleme sistemini başlat"""
        if self.is_running:
            return
        
        self.is_running = True
        self.monitoring_stats['uptime_start'] = datetime.now()
        
        self.logger.info("Real-time monitor başlatıldı")
        
        # WebSocket bağlantılarını başlat
        await self._initialize_connections()
        
        # Ana izleme döngüsü
        asyncio.create_task(self._monitoring_loop())
        
        # Alert temizleme döngüsü
        asyncio.create_task(self._alert_cleanup_loop())
    
    def stop(self) -> None:
        """İzleme sistemini durdur"""
        self.is_running = False
        self.logger.info("Real-time monitor durduruldu")
    
    async def _initialize_connections(self) -> None:
        """Bağlantıları başlat"""
        try:
            # Dummy WebSocket bağlantıları
            # Gerçek sistemde market data provider'larına bağlanılır
            self.websocket_connections = [
                "wss://example.com/market-data",
                "wss://example.com/liquidity-data"
            ]
            
            self.logger.info("Bağlantılar başlatıldı")
            
        except Exception as e:
            self.logger.error(f"Bağlantı başlatma hatası: {e}")
    
    async def _monitoring_loop(self) -> None:
        """Ana izleme döngüsü"""
        while self.is_running:
            try:
                # Market verisi çek
                await self._fetch_market_data()
                
                # Veriyi işle
                await self._process_market_data()
                
                # Rejim değişikliklerini tespit et
                await self._detect_regime_changes()
                
                # Risk seviyesini değerlendir
                await self._assess_risk_levels()
                
                # Alert'leri kontrol et
                await self._check_alert_conditions()
                
                # İstatistikleri güncelle
                self.monitoring_stats['total_updates'] += 1
                self.last_update = datetime.now()
                
                # Bekle
                await asyncio.sleep(self.update_interval)
                
            except Exception as e:
                self.logger.error(f"Monitoring loop hatası: {e}")
                await asyncio.sleep(5)
    
    async def _fetch_market_data(self) -> None:
        """Market verisi çek"""
        try:
            # Dummy market data
            # Gerçek sistemde WebSocket veya HTTP API'den çekilir
            current_time = datetime.now()
            
            # Mock market data
            price = 100.0 + np.random.normal(0, 2)
            volume = np.random.randint(1000, 10000)
            spread = 0.01 + np.random.exponential(0.005)
            
            market_point = MarketDataPoint(
                timestamp=current_time,
                price=price,
                volume=volume,
                bid=price - spread/2,
                ask=price + spread/2,
                indicators={
                    'rsi': np.random.uniform(20, 80),
                    'macd': np.random.normal(0, 0.5),
                    'bollinger_position': np.random.uniform(0, 1)
                }
            )
            
            with self.data_lock:
                self.market_data.append(market_point)
                
                # Maksimum veri noktası kontrolü
                if len(self.market_data) > self.max_data_points:
                    self.market_data = self.market_data[-self.max_data_points:]
                
                self.monitoring_stats['data_points_processed'] += 1
            
        except Exception as e:
            self.logger.error(f"Market veri çekme hatası: {e}")
    
    async def _process_market_data(self) -> None:
        """Market verisini işle"""
        try:
            with self.data_lock:
                if len(self.market_data) < 2:
                    return
                
                latest_data = self.market_data[-1]
                previous_data = self.market_data[-2]
            
            # Fiyat değişimi analizi
            price_change_pct = (latest_data.price - previous_data.price) / previous_data.price
            latest_data.indicators['price_change_pct'] = price_change_pct
            
            # Volatilite hesaplama
            if len(self.market_data) >= 20:
                prices = [dp.price for dp in self.market_data[-20:]]
                returns = np.diff(prices) / prices[:-1]
                current_volatility = np.std(returns)
                latest_data.indicators['volatility'] = current_volatility
                
                # Volatilite baseline güncelle
                self.volatility_baseline = 0.9 * self.volatility_baseline + 0.1 * current_volatility
            
            # Hacim analizi
            if len(self.market_data) >= 20:
                recent_volumes = [dp.volume for dp in self.market_data[-20:]]
                avg_volume = np.mean(recent_volumes)
                volume_ratio = latest_data.volume / avg_volume if avg_volume > 0 else 1.0
                latest_data.indicators['volume_ratio'] = volume_ratio
            
            # Spread analizi
            spread = latest_data.ask - latest_data.bid
            latest_data.indicators['spread'] = spread
            latest_data.indicators['spread_pct'] = spread / latest_data.price
            
            # Teknik göstergeler
            if len(self.market_data) >= 50:
                prices_50 = [dp.price for dp in self.market_data[-50:]]
                
                # RSI hesaplama
                latest_data.indicators['rsi'] = self._calculate_rsi(prices_50)
                
                # MACD hesaplama
                latest_data.indicators['macd'] = self._calculate_macd(prices_50)
                
                # Bollinger Bands pozisyonu
                latest_data.indicators['bollinger_position'] = self._calculate_bollinger_position(prices_50)
        
        except Exception as e:
            self.logger.error(f"Market veri işleme hatası: {e}")
    
    def _calculate_rsi(self, prices: List[float], period: int = 14) -> float:
        """RSI hesapla"""
        if len(prices) < period + 1:
            return 50.0
        
        returns = np.diff(prices)
        gains = np.where(returns > 0, returns, 0)
        losses = np.where(returns < 0, -returns, 0)
        
        avg_gain = np.mean(gains[-period:])
        avg_loss = np.mean(losses[-period:])
        
        if avg_loss == 0:
            return 100.0
        
        rs = avg_gain / avg_loss
        rsi = 100 - (100 / (1 + rs))
        return rsi
    
    def _calculate_macd(self, prices: List[float]) -> float:
        """MACD hesapla"""
        if len(prices) < 26:
            return 0.0
        
        # EMA hesapla
        ema_12 = self._calculate_ema(prices, 12)
        ema_26 = self._calculate_ema(prices, 26)
        
        return ema_12 - ema_26
    
    def _calculate_ema(self, prices: List[float], period: int) -> float:
        """EMA hesapla"""
        if len(prices) < period:
            return prices[-1]
        
        multiplier = 2 / (period + 1)
        ema = prices[0]
        
        for price in prices[1:]:
            ema = (price * multiplier) + (ema * (1 - multiplier))
        
        return ema
    
    def _calculate_bollinger_position(self, prices: List[float], period: int = 20, std_dev: float = 2) -> float:
        """Bollinger Bands pozisyonu hesapla"""
        if len(prices) < period:
            return 0.5
        
        recent_prices = prices[-period:]
        mean_price = np.mean(recent_prices)
        std_price = np.std(recent_prices)
        
        upper_band = mean_price + (std_price * std_dev)
        lower_band = mean_price - (std_price * std_dev)
        
        current_price = prices[-1]
        
        if upper_band == lower_band:
            return 0.5
        
        position = (current_price - lower_band) / (upper_band - lower_band)
        return np.clip(position, 0, 1)
    
    async def _detect_regime_changes(self) -> None:
        """Rejim değişikliklerini tespit et"""
        try:
            with self.data_lock:
                if len(self.market_data) < 50:
                    return
                
                latest_data = self.market_data[-1]
            
            # Rejim belirleme algoritması
            new_regime = self._determine_market_regime(latest_data)
            
            # Rejim değişikliği kontrolü
            if self.last_regime != new_regime:
                self.regime_stability_counter += 1
                
                # Stabilite eşiği (3 ardışık veri noktası)
                if self.regime_stability_counter >= 3:
                    await self._handle_regime_change(self.last_regime, new_regime)
                    self.last_regime = new_regime
                    self.regime_stability_counter = 0
                    self.monitoring_stats['regime_changes_detected'] += 1
            else:
                self.regime_stability_counter = 0
                self.last_regime = new_regime
            
        except Exception as e:
            self.logger.error(f"Rejim tespit hatası: {e}")
    
    def _determine_market_regime(self, data: MarketDataPoint) -> str:
        """Market rejimi belirle"""
        try:
            indicators = data.indicators
            
            # Volatilite bazlı rejim
            volatility = indicators.get('volatility', 0.02)
            vol_ratio = volatility / self.volatility_baseline if self.volatility_baseline > 0 else 1.0
            
            if vol_ratio > 3.0:
                return "crisis"
            elif vol_ratio > 2.0:
                return "volatile"
            
            # Trend analizi
            if len(self.market_data) >= 20:
                prices = [dp.price for dp in self.market_data[-20:]]
                trend_strength = np.abs(np.polyfit(range(20), prices, 1)[0])
                
                if trend_strength > 2.0:
                    # Trend yönü
                    if prices[-1] > prices[0]:
                        return "trending_up"
                    else:
                        return "trending_down"
            
            # RSI bazlı rejim
            rsi = indicators.get('rsi', 50)
            if rsi > 70:
                return "trending_up"
            elif rsi < 30:
                return "trending_down"
            
            return "ranging"
            
        except Exception as e:
            self.logger.error(f"Rejim belirleme hatası: {e}")
            return "unknown"
    
    async def _handle_regime_change(self, old_regime: str, new_regime: str) -> None:
        """Rejim değişikliğini işle"""
        self.logger.info(f"Rejim değişikliği tespit edildi: {old_regime} -> {new_regime}")
        
        # Alert oluştur
        alert = MonitoringAlert(
            alert_type='regime_change',
            severity='medium',
            message=f"Market rejimi değişti: {old_regime} -> {new_regime}",
            data={
                'old_regime': old_regime,
                'new_regime': new_regime,
                'timestamp': datetime.now().isoformat()
            }
        )
        
        await self._trigger_alert(alert)
    
    async def _assess_risk_levels(self) -> None:
        """Risk seviyelerini değerlendir"""
        try:
            with self.data_lock:
                if len(self.market_data) < 10:
                    return
                
                latest_data = self.market_data[-1]
            
            risk_components = []
            
            # Volatilite riski
            volatility = latest_data.indicators.get('volatility', 0.02)
            vol_risk = min(volatility / 0.05, 1.0)  # %5 volatilite eşiği
            risk_components.append(vol_risk)
            
            # Hacim riski
            volume_ratio = latest_data.indicators.get('volume_ratio', 1.0)
            if volume_ratio < 0.5:  # Düşük hacim
                volume_risk = (0.5 - volume_ratio) * 2
            else:
                volume_risk = 0.0
            risk_components.append(volume_risk)
            
            # Spread riski
            spread_pct = latest_data.indicators.get('spread_pct', 0.01)
            spread_risk = min(spread_pct / 0.02, 1.0)  # %2 spread eşiği
            risk_components.append(spread_risk)
            
            # Fiyat değişim riski
            price_change = abs(latest_data.indicators.get('price_change_pct', 0))
            price_risk = min(price_change / 0.05, 1.0)  # %5 değişim eşiği
            risk_components.append(price_risk)
            
            # Toplam risk seviyesi
            self.current_risk_level = np.mean(risk_components)
            
            # Risk seviyesi alertleri
            if self.current_risk_level > self.alert_thresholds['risk_level_critical']:
                await self._trigger_critical_risk_alert()
            elif self.current_risk_level > self.alert_thresholds['risk_level_high']:
                await self._trigger_high_risk_alert()
        
        except Exception as e:
            self.logger.error(f"Risk değerlendirme hatası: {e}")
    
    async def _check_alert_conditions(self) -> None:
        """Alert koşullarını kontrol et"""
        try:
            with self.data_lock:
                if len(self.market_data) < 2:
                    return
                
                latest_data = self.market_data[-1]
                previous_data = self.market_data[-2]
            
            # Volatilite spike
            volatility = latest_data.indicators.get('volatility', 0.02)
            vol_spike = volatility / self.volatility_baseline if self.volatility_baseline > 0 else 1.0
            
            if vol_spike > self.alert_thresholds['volatility_spike']:
                alert = MonitoringAlert(
                    alert_type='volatility_spike',
                    severity='high',
                    message=f"Volatilite spike tespit edildi: {vol_spike:.2f}x",
                    data={
                        'volatility': volatility,
                        'baseline': self.volatility_baseline,
                        'spike_ratio': vol_spike
                    }
                )
                await self._trigger_alert(alert)
            
            # Hacim spike
            volume_ratio = latest_data.indicators.get('volume_ratio', 1.0)
            if volume_ratio > self.alert_thresholds['volume_spike']:
                alert = MonitoringAlert(
                    alert_type='volume_spike',
                    severity='medium',
                    message=f"Hacim spike tespit edildi: {volume_ratio:.2f}x",
                    data={
                        'current_volume': latest_data.volume,
                        'avg_volume': latest_data.volume / volume_ratio,
                        'volume_ratio': volume_ratio
                    }
                )
                await self._trigger_alert(alert)
            
            # Spread widening
            current_spread = latest_data.indicators.get('spread_pct', 0.01)
            if len(self.market_data) >= 20:
                historical_spreads = [
                    dp.indicators.get('spread_pct', 0.01) 
                    for dp in self.market_data[-20:]
                ]
                avg_spread = np.mean(historical_spreads)
                
                if current_spread > avg_spread * self.alert_thresholds['spread_widening']:
                    alert = MonitoringAlert(
                        alert_type='liquidity_stress',
                        severity='medium',
                        message=f"Spread genişlemesi tespit edildi: {current_spread/avg_spread:.2f}x",
                        data={
                            'current_spread': current_spread,
                            'avg_spread': avg_spread,
                            'widening_ratio': current_spread / avg_spread
                        }
                    )
                    await self._trigger_alert(alert)
        
        except Exception as e:
            self.logger.error(f"Alert kontrol hatası: {e}")
    
    async def _trigger_alert(self, alert: MonitoringAlert) -> None:
        """Alert tetikle"""
        try:
            # Alert'i kaydet
            self.alerts.append(alert)
            self.active_alerts[alert.alert_type] = alert
            self.monitoring_stats['alerts_generated'] += 1
            
            # Callback'leri çağır
            for callback in self.alert_callbacks:
                try:
                    if asyncio.iscoroutinefunction(callback):
                        await callback(alert)
                    else:
                        callback(alert)
                except Exception as e:
                    self.logger.error(f"Alert callback hatası: {e}")
            
            self.logger.info(f"Alert tetiklendi: {alert.alert_type} - {alert.message}")
            
        except Exception as e:
            self.logger.error(f"Alert tetikleme hatası: {e}")
    
    async def _trigger_critical_risk_alert(self) -> None:
        """Kritik risk uyarısı"""
        alert = MonitoringAlert(
            alert_type='risk_level',
            severity='critical',
            message=f"Kritik risk seviyesi: {self.current_risk_level:.2%}",
            data={
                'risk_level': self.current_risk_level,
                'threshold': self.alert_thresholds['risk_level_critical']
            }
        )
        await self._trigger_alert(alert)
    
    async def _trigger_high_risk_alert(self) -> None:
        """Yüksek risk uyarısı"""
        alert = MonitoringAlert(
            alert_type='risk_level',
            severity='high',
            message=f"Yüksek risk seviyesi: {self.current_risk_level:.2%}",
            data={
                'risk_level': self.current_risk_level,
                'threshold': self.alert_thresholds['risk_level_high']
            }
        )
        await self._trigger_alert(alert)
    
    async def _alert_cleanup_loop(self) -> None:
        """Alert temizleme döngüsü"""
        while self.is_running:
            try:
                # 5 dakika öncesi alert'leri temizle
                cutoff_time = datetime.now() - timedelta(minutes=5)
                
                expired_alerts = []
                for alert_type, alert in self.active_alerts.items():
                    if alert.timestamp < cutoff_time:
                        expired_alerts.append(alert_type)
                
                for alert_type in expired_alerts:
                    del self.active_alerts[alert_type]
                
                if expired_alerts:
                    self.logger.debug(f"Temizlenen alert sayısı: {len(expired_alerts)}")
                
                await asyncio.sleep(300)  # 5 dakika bekle
                
            except Exception as e:
                self.logger.error(f"Alert temizleme hatası: {e}")
                await asyncio.sleep(60)
    
    def add_alert_callback(self, callback: Callable) -> None:
        """Alert callback'i ekle"""
        self.alert_callbacks.append(callback)
    
    def get_current_status(self) -> Dict:
        """Mevcut durum bilgisi"""
        uptime = (
            datetime.now() - self.monitoring_stats['uptime_start']
            if self.monitoring_stats['uptime_start']
            else timedelta(0)
        )
        
        with self.data_lock:
            latest_data = self.market_data[-1] if self.market_data else None
        
        return {
            'is_running': self.is_running,
            'uptime_seconds': uptime.total_seconds(),
            'last_update': self.last_update.isoformat() if self.last_update else None,
            'data_points': len(self.market_data),
            'current_risk_level': self.current_risk_level,
            'active_alerts': len(self.active_alerts),
            'total_alerts': len(self.alerts),
            'monitoring_stats': self.monitoring_stats,
            'latest_market_data': {
                'timestamp': latest_data.timestamp.isoformat() if latest_data else None,
                'price': latest_data.price if latest_data else None,
                'volume': latest_data.volume if latest_data else None,
                'volatility': latest_data.indicators.get('volatility') if latest_data else None
            } if latest_data else None
        }
    
    def get_recent_alerts(self, hours: int = 24) -> List[Dict]:
        """Son alert'leri getir"""
        cutoff_time = datetime.now() - timedelta(hours=hours)
        
        recent_alerts = [
            {
                'timestamp': alert.timestamp.isoformat(),
                'type': alert.alert_type,
                'severity': alert.severity,
                'message': alert.message,
                'data': alert.data,
                'acknowledged': alert.acknowledged
            }
            for alert in self.alerts
            if alert.timestamp >= cutoff_time
        ]
        
        return sorted(recent_alerts, key=lambda x: x['timestamp'], reverse=True)
    
    def acknowledge_alert(self, alert_index: int) -> bool:
        """Alert'i onayla"""
        try:
            if 0 <= alert_index < len(self.alerts):
                self.alerts[alert_index].acknowledged = True
                return True
            return False
        except Exception as e:
            self.logger.error(f"Alert onaylama hatası: {e}")
            return False