"""
Makro Rejim Filtreleme Sistemi - Tests
======================================

Test paketi başlatıcısı.
"""

# Test configuration ve fixtures burada tanımlanabilir
import sys
import os

# Test veri dizinini path'e ekle
test_data_dir = os.path.join(os.path.dirname(__file__), 'data')
if test_data_dir not in sys.path:
    sys.path.append(test_data_dir)