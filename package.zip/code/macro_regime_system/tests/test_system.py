"""
Makro Rejim Filtreleme Sistemi - Unit Testler
=============================================

Sistemin tüm bileşenlerini test eden kapsamlı test suite'i.
"""

import pytest
import asyncio
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from unittest.mock import Mock, patch, AsyncMock
import logging

# Import system components
from macro_regime_system.core.regime_classifier import RegimeClassifier, MarketRegime, RegimeSignal
from macro_regime_system.core.regime_engine import RegimeEngine, RegimeConfig, HedgeSignal
from macro_regime_system.indicators.macro_indicators import MacroIndicators, MacroData
from macro_regime_system.detectors.volatility_detector import VolatilityDetector, VolatilityRegime
from macro_regime_system.detectors.liquidity_detector import LiquidityDetector, LiquidityRegime
from macro_regime_system.hedging.hedge_manager import HedgeManager, HedgePosition
from macro_regime_system.strategies.strategy_activator import StrategyActivator
from macro_regime_system.monitoring.real_time_monitor import RealTimeMonitor, MonitoringAlert


class TestRegimeClassifier:
    """Regime Classifier testleri"""
    
    @pytest.fixture
    def classifier(self):
        return RegimeClassifier()
    
    @pytest.fixture
    def sample_data(self):
        """Örnek market verisi"""
        dates = pd.date_range('2023-01-01', periods=100, freq='1H')
        np.random.seed(42)  # Reproducible tests
        
        data = pd.DataFrame({
            'timestamp': dates,
            'open': 100 + np.random.randn(100).cumsum() * 0.5,
            'high': 100 + np.random.randn(100).cumsum() * 0.5 + 1,
            'low': 100 + np.random.randn(100).cumsum() * 0.5 - 1,
            'close': 100 + np.random.randn(100).cumsum() * 0.5,
            'volume': np.random.randint(1000, 10000, 100)
        })
        return data
    
    def test_init(self, classifier):
        """Başlatma testi"""
        assert classifier.volatility_threshold == 2.0
        assert classifier.trend_threshold == 0.7
        assert classifier.crisis_threshold == 3.0
        assert classifier.scaler is not None
        assert classifier.rf_classifier is not None
        assert classifier.ml_model is not None
    
    def test_extract_features(self, classifier, sample_data):
        """Özellik çıkarım testi"""
        features = classifier.extract_features(sample_data)
        
        assert isinstance(features, np.ndarray)
        assert len(features) == 20
        assert not np.isnan(features).any()
        assert all(isinstance(f, (int, float)) for f in features)
    
    def test_calculate_trend_strength(self, classifier):
        """Trend gücü hesaplama testi"""
        prices = np.array([100, 101, 102, 103, 104, 105, 106, 107, 108, 109])
        strength = classifier._calculate_trend_strength(prices)
        
        assert isinstance(strength, float)
        assert 0 <= abs(strength) <= 1
        assert strength > 0  # Yükseliş trendi
    
    def test_classify_regime(self, classifier, sample_data):
        """Rejim sınıflandırma testi"""
        signal = classifier.classify_regime(sample_data)
        
        assert isinstance(signal, RegimeSignal)
        assert isinstance(signal.regime, MarketRegime)
        assert 0 <= signal.confidence <= 1
        assert 0 <= signal.strength <= 1
        assert signal.duration_estimate > 0
        assert isinstance(signal.indicators, dict)
    
    def test_regime_detection_different_markets(self, classifier):
        """Farklı market koşullarında rejim tespiti"""
        # Yükseliş trendi
        trending_up = pd.DataFrame({
            'timestamp': pd.date_range('2023-01-01', periods=100, freq='1H'),
            'open': np.linspace(100, 150, 100),
            'high': np.linspace(101, 151, 100),
            'low': np.linspace(99, 149, 100),
            'close': np.linspace(100, 150, 100),
            'volume': [1000] * 100
        })
        
        signal = classifier.classify_regime(trending_up)
        assert signal.regime in [MarketRegime.TRENDING_UP, MarketRegime.TRENDING_DOWN]
        
        # Yüksek volatilite
        volatile_data = pd.DataFrame({
            'timestamp': pd.date_range('2023-01-01', periods=100, freq='1H'),
            'open': np.random.randn(100).cumsum() + 100,
            'high': np.random.randn(100).cumsum() + 105,
            'low': np.random.randn(100).cumsum() + 95,
            'close': np.random.randn(100).cumsum() + 100,
            'volume': [1000] * 100
        })
        
        signal = classifier.classify_regime(volatile_data)
        # Yüksek volatilite değişkenliği nedeniyle farklı rejimler olabilir
        assert isinstance(signal.regime, MarketRegime)
    
    def test_predict_regime_change(self, classifier, sample_data):
        """Rejim değişikliği tahmini testi"""
        # Önce birkaç rejim sinyali ekle
        for i in range(5):
            signal = RegimeSignal(
                regime=MarketRegime.RANGING,
                confidence=0.7,
                strength=0.6,
                duration_estimate=20,
                indicators={'volatility': 0.02},
                timestamp=datetime.now()
            )
            classifier.regime_history.append(signal)
        
        prediction = classifier.predict_regime_change()
        
        assert isinstance(prediction, dict)
        assert 'change_probability' in prediction
        assert 'next_regime' in prediction
        assert 'confidence' in prediction
        assert 0 <= prediction['change_probability'] <= 1


class TestRegimeEngine:
    """Regime Engine testleri"""
    
    @pytest.fixture
    def config(self):
        return RegimeConfig(
            volatility_threshold=2.0,
            trend_threshold=0.7,
            auto_hedge_enabled=True,
            strategy_rotation_enabled=True
        )
    
    @pytest.fixture
    def engine(self, config):
        return RegimeEngine(config)
    
    def test_init(self, engine, config):
        """Başlatma testi"""
        assert engine.config == config
        assert engine.classifier is not None
        assert engine.macro_indicators is not None
        assert engine.volatility_detector is not None
        assert engine.liquidity_detector is not None
        assert engine.hedge_manager is not None
        assert engine.strategy_activator is not None
        assert engine.real_time_monitor is not None
        assert not engine.is_running
    
    @pytest.mark.asyncio
    async def test_calculate_required_hedge(self, engine):
        """Gerekli hedge hesaplama testi"""
        # Trending up signal
        up_signal = RegimeSignal(
            regime=MarketRegime.TRENDING_UP,
            confidence=0.8,
            strength=0.7,
            duration_estimate=24,
            indicators={'volatility': 0.02},
            timestamp=datetime.now()
        )
        
        hedge_ratio = engine._calculate_required_hedge(up_signal)
        assert 0 <= hedge_ratio <= 1
        assert hedge_ratio < 0.4  # Düşük hedge trending up için
        
        # Crisis signal
        crisis_signal = RegimeSignal(
            regime=MarketRegime.CRISIS,
            confidence=0.9,
            strength=0.8,
            duration_estimate=12,
            indicators={'volatility': 0.05},
            timestamp=datetime.now()
        )
        
        hedge_ratio = engine._calculate_required_hedge(crisis_signal)
        assert hedge_ratio >= 0.8  # Yüksek hedge kriz için
    
    @pytest.mark.asyncio
    async def test_update_hedge_strategy(self, engine):
        """Hedge stratejisi güncelleme testi"""
        signal = RegimeSignal(
            regime=MarketRegime.VOLATILE,
            confidence=0.8,
            strength=0.7,
            duration_estimate=18,
            indicators={'volatility': 0.04},
            timestamp=datetime.now()
        )
        
        # Mock hedge manager
        engine.hedge_manager.get_current_hedge = AsyncMock(return_value=0.3)
        
        hedge_signal = await engine._update_hedge_strategy(signal)
        
        assert hedge_signal is not None
        assert isinstance(hedge_signal, HedgeSignal)
        assert hedge_signal.action in ['increase', 'decrease']
        assert 0 <= hedge_signal.position_size <= 1
    
    def test_get_regime_hedge_params(self, engine):
        """Rejim hedge parametreleri testi"""
        params = engine._get_regime_hedge_params(MarketRegime.TRENDING_UP)
        
        assert isinstance(params, dict)
        assert 'max_hedge_ratio' in params
        assert 'hedge_sensitivity' in params
        assert 'preferred_instruments' in params
        assert params['max_hedge_ratio'] == 0.3
        
        params = engine._get_regime_hedge_params(MarketRegime.CRISIS)
        assert params['max_hedge_ratio'] == 1.0


class TestMacroIndicators:
    """Macro Indicators testleri"""
    
    @pytest.fixture
    def macro(self):
        return MacroIndicators()
    
    @pytest.mark.asyncio
    async def test_get_latest_data(self, macro):
        """Güncel makro veri alma testi"""
        # Mock network calls
        with patch('yfinance.Tickers') as mock_tickers:
            mock_ticker = Mock()
            mock_ticker.history.return_value = pd.DataFrame({
                'Close': [20.0, 25.0]
            })
            mock_tickers.return_value.tickers = {'^VIX': mock_ticker}
            
            data = await macro.get_latest_data()
            
            assert isinstance(data, dict)
            assert 'vix' in data
            assert 'sp500' in data
            assert 'treasury_10y' in data
    
    def test_calculate_liquidity_index(self, macro):
        """Likidite endeksi hesaplama testi"""
        data_dict = {
            'vix': 15.0,
            'treasury_10y': 3.0,
            'dxy': 95.0
        }
        
        liquidity_index = macro._calculate_liquidity_index(data_dict)
        
        assert isinstance(liquidity_index, float)
        assert 0 <= liquidity_index <= 100
    
    def test_calculate_risk_appetite(self, macro):
        """Risk iştahı hesaplama testi"""
        data_dict = {
            'vix': 15.0,
            'sp500': 4000.0,
            'gold': 1900.0
        }
        
        risk_appetite = macro._calculate_risk_appetite(data_dict)
        
        assert isinstance(risk_appetite, float)
        assert 0 <= risk_appetite <= 1
    
    def test_get_macro_summary(self, macro):
        """Makro özet testi"""
        # Mock current data
        macro.current_data = MacroData(
            timestamp=datetime.now(),
            vix=20.0,
            sp500=4000.0,
            treasury_10y=3.5,
            dxy=100.0,
            gold=2000.0,
            oil=80.0,
            interest_rate_fed=5.25,
            interest_rate_10y=3.5,
            liquidity_index=80.0,
            risk_appetite=0.6,
            credit_spread=1.5,
            dollar_index=100.0
        )
        
        summary = macro.get_macro_summary()
        
        assert isinstance(summary, dict)
        assert 'macro_regime' in summary
        assert 'risk_level' in summary
        assert 'liquidity_status' in summary
        assert 'key_indicators' in summary


class TestVolatilityDetector:
    """Volatility Detector testleri"""
    
    @pytest.fixture
    def detector(self):
        return VolatilityDetector()
    
    def test_init(self, detector):
        """Başlatma testi"""
        assert detector.window_size == 100
        assert detector.cluster_threshold == 0.3
        assert detector.extreme_vol_threshold == 3.0
        assert detector.current_regime == VolatilityRegime.NORMAL_VOL
    
    def test_update_data(self, detector):
        """Veri güncelleme testi"""
        prices = np.random.randn(100).cumsum() + 100
        returns = np.diff(prices) / prices[:-1]
        
        detector.update_data(returns.tolist(), prices.tolist())
        
        assert len(detector.volatility_history) > 0
        assert len(detector.returns_history) > 0
        assert detector.volatility_history[-1] >= 0
    
    def test_analyze_volatility(self, detector):
        """Volatilite analizi testi"""
        # Önce veri ekle
        prices = np.random.randn(50).cumsum() + 100
        returns = np.diff(prices) / prices[:-1]
        detector.update_data(returns.tolist(), prices.tolist())
        
        analysis = detector.analyze_volatility()
        
        assert isinstance(analysis, dict)
        assert 'regime' in analysis
        assert 'volatility_level' in analysis
        assert 'risk_level' in analysis
        assert 'expected_duration' in analysis
    
    def test_calculate_clustering_strength(self, detector):
        """Clustering gücü hesaplama testi"""
        # Yüksek volatilite dönemleri oluştur
        detector.volatility_history = [0.02] * 10 + [0.08] * 5 + [0.02] * 5
        
        strength = detector._calculate_clustering_strength()
        
        assert isinstance(strength, float)
        assert 0 <= strength <= 1


class TestLiquidityDetector:
    """Liquidity Detector testleri"""
    
    @pytest.fixture
    def detector(self):
        return LiquidityDetector()
    
    def test_update_market_data(self, detector):
        """Market veri güncelleme testi"""
        detector.update_market_data(100.0, 100.01, 1000000, 5000)
        detector.update_market_data(101.0, 101.02, 1100000, 6000)
        
        assert len(detector.spread_history) == 2
        assert len(detector.depth_history) == 2
        assert len(detector.volume_history) == 2
    
    def test_analyze_liquidity(self, detector):
        """Likidite analizi testi"""
        # Önce veri ekle
        for i in range(20):
            detector.update_market_data(
                100 + i * 0.1,
                100 + i * 0.1 + 0.01,
                1000000 + i * 10000,
                5000 + i * 100
            )
        
        analysis = detector.analyze_liquidity()
        
        assert isinstance(analysis, dict)
        assert 'regime' in analysis
        assert 'stress_level' in analysis
        assert 'bid_ask_spread' in analysis
        assert 'market_depth' in analysis
    
    def test_calculate_stress_level(self, detector):
        """Stress seviyesi hesaplama testi"""
        # Mock metrics
        metrics = {
            'current_spread': 0.02,
            'current_depth': 500000,
            'composite_liquidity_score': 0.4
        }
        
        spread_analysis = {'anomaly_detected': False}
        depth_analysis = {}
        
        stress = detector._calculate_stress_level(metrics, spread_analysis, depth_analysis)
        
        assert isinstance(stress, float)
        assert 0 <= stress <= 1


class TestHedgeManager:
    """Hedge Manager testleri"""
    
    @pytest.fixture
    def manager(self):
        return HedgeManager(sensitivity=0.8)
    
    @pytest.mark.asyncio
    async def test_get_current_hedge(self, manager):
        """Mevcut hedge oranı testi"""
        # Mock positions
        manager.positions = [
            HedgePosition(
                instrument="put_options",
                position_size=10000,
                entry_price=5.0,
                current_price=5.2,
                pnl=200,
                hedge_ratio=0.1,
                strategy=Mock(),
                entry_time=datetime.now()
            )
        ]
        manager.total_portfolio_value = 100000
        
        hedge_ratio = await manager.get_current_hedge()
        
        assert hedge_ratio == 0.1
    
    @pytest.mark.asyncio
    async def test_execute_hedge_signal(self, manager):
        """Hedge sinyali uygulama testi"""
        signal = HedgeSignal(
            action="increase",
            position_size=0.2,
            confidence=0.8,
            reason="Volatility increase"
        )
        
        result = await manager.execute_hedge_signal(signal)
        
        assert isinstance(result, dict)
        assert 'success' in result
        assert 'positions_added' in result
        assert 'new_hedge_ratio' in result
    
    def test_get_hedge_summary(self, manager):
        """Hedge özeti testi"""
        # Mock positions
        manager.positions = [
            Mock(
                position_size=10000,
                pnl=500,
                hedge_ratio=0.1
            )
        ]
        
        summary = manager.get_hedge_summary()
        
        assert isinstance(summary, dict)
        assert 'current_hedge_ratio' in summary
        assert 'total_positions' in summary
        assert 'total_pnl' in summary


class TestStrategyActivator:
    """Strategy Activator testleri"""
    
    @pytest.fixture
    def activator(self):
        return StrategyActivator()
    
    @pytest.mark.asyncio
    async def test_update_allocations(self, activator):
        """Tahsis güncelleme testi"""
        signal = RegimeSignal(
            regime=MarketRegime.TRENDING_UP,
            confidence=0.8,
            strength=0.7,
            duration_estimate=24,
            indicators={'volatility': 0.02},
            timestamp=datetime.now()
        )
        
        allocations = await activator.update_allocations(signal)
        
        assert isinstance(allocations, dict)
        assert len(allocations) > 0
        assert sum(allocations.values()) == pytest.approx(1.0, abs=0.01)
    
    def test_get_portfolio_summary(self, activator):
        """Portföy özeti testi"""
        # Mock active strategies
        from macro_regime_system.strategies.strategy_activator import ActiveStrategy, StrategyConfig, StrategyType
        
        config = StrategyConfig(
            name="Test Strategy",
            strategy_type=StrategyType.MOMENTUM_LONG,
            base_allocation=0.2,
            max_allocation=0.3,
            min_allocation=0.1,
            risk_level=0.8,
            expected_return=0.12,
            volatility=0.18,
            correlation_benchmark=0.7
        )
        
        strategy = ActiveStrategy(
            config=config,
            current_allocation=0.2,
            target_allocation=0.2,
            pnl=100,
            max_drawdown=0.05,
            win_rate=0.6,
            start_date=datetime.now(),
            last_rebalance=datetime.now()
        )
        
        activator.active_strategies["Test Strategy"] = strategy
        
        summary = activator.get_portfolio_summary()
        
        assert isinstance(summary, dict)
        assert 'total_allocation' in summary
        assert 'strategies' in summary
        assert 'current_regime' in summary


class TestRealTimeMonitor:
    """Real-time Monitor testleri"""
    
    @pytest.fixture
    def monitor(self):
        return RealTimeMonitor(update_interval=1)
    
    def test_init(self, monitor):
        """Başlatma testi"""
        assert monitor.update_interval == 1
        assert not monitor.is_running
        assert monitor.market_data == []
        assert monitor.alerts == []
    
    @pytest.mark.asyncio
    async def test_start_stop(self, monitor):
        """Başlatma/durdurma testi"""
        await monitor.start()
        assert monitor.is_running
        
        monitor.stop()
        assert not monitor.is_running
    
    def test_get_current_status(self, monitor):
        """Mevcut durum testi"""
        status = monitor.get_current_status()
        
        assert isinstance(status, dict)
        assert 'is_running' in status
        assert 'uptime_seconds' in status
        assert 'data_points' in status
        assert 'monitoring_stats' in status
    
    def test_add_alert_callback(self, monitor):
        """Alert callback ekleme testi"""
        def test_callback(alert):
            assert isinstance(alert, MonitoringAlert)
        
        monitor.add_alert_callback(test_callback)
        assert len(monitor.alert_callbacks) == 1


class TestIntegration:
    """Entegrasyon testleri"""
    
    @pytest.mark.asyncio
    async def test_full_system_workflow(self):
        """Tam sistem workflow testi"""
        # Sistem oluştur
        from macro_regime_system.main import MacroRegimeSystem
        
        system = MacroRegimeSystem()
        
        # Callback'ler ekle
        regime_changes = []
        alerts = []
        
        async def on_regime_change(old_regime, new_signal):
            regime_changes.append((old_regime, new_signal))
        
        async def on_alert(alert):
            alerts.append(alert)
        
        system.add_callback('regime_change', on_regime_change)
        system.add_callback('alert', on_alert)
        
        # Sistem başlat
        initialized = await system.initialize()
        assert initialized
        
        # Başlat
        started = await system.start()
        assert started
        
        # Bir süre bekle
        await asyncio.sleep(2)
        
        # Durum kontrol et
        status = system.get_system_status()
        assert status['system']['is_running']
        
        # Durdur
        await system.stop()
        
        # Temizlik
        assert len(regime_changes) >= 0  # Rejim değişikliği olabilir veya olmayabilir
        assert len(alerts) >= 0  # Alert olabilir veya olmayabilir
    
    @pytest.mark.asyncio
    async def test_regime_detection_to_hedge_execution(self):
        """Rejim tespitinden hedge uygulamasına kadar akış"""
        # Adım 1: Classifier ile rejim tespit et
        classifier = RegimeClassifier()
        data = pd.DataFrame({
            'timestamp': pd.date_range('2023-01-01', periods=100, freq='1H'),
            'open': np.random.randn(100).cumsum() + 100,
            'high': np.random.randn(100).cumsum() + 105,
            'low': np.random.randn(100).cumsum() + 95,
            'close': np.random.randn(100).cumsum() + 100,
            'volume': np.random.randint(1000, 10000, 100)
        })
        
        signal = classifier.classify_regime(data)
        assert isinstance(signal.regime, MarketRegime)
        
        # Adım 2: Hedge manager ile hedge hesapla
        manager = HedgeManager()
        target_hedge = 0.5 if signal.regime == MarketRegime.VOLATILE else 0.2
        
        hedge_signal = HedgeSignal(
            action="increase" if target_hedge > 0.3 else "decrease",
            position_size=target_hedge,
            confidence=signal.confidence,
            reason=f"Regime: {signal.regime.value}"
        )
        
        result = await manager.execute_hedge_signal(hedge_signal)
        assert result['success'] or result.get('message') is not None
        
        # Adım 3: Strateji tahsisi güncelle
        activator = StrategyActivator()
        allocations = await activator.update_allocations(signal)
        
        assert len(allocations) > 0
        assert sum(allocations.values()) == pytest.approx(1.0, abs=0.01)


# Pytest configuration
def pytest_configure(config):
    """Pytest konfigürasyonu"""
    config.addinivalue_line(
        "markers", "asyncio: mark test as async"
    )


if __name__ == "__main__":
    # Test'leri çalıştır
    pytest.main([__file__, "-v", "--tb=short"])