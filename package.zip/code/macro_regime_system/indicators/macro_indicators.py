"""
Macro Indicators - Makro Ekonomik Göstergeler
=============================================

VIX, faiz oranları, likidite ve risk iştahı gibi makro göstergelerin
entegrasyonu ve analizi.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
import asyncio
import aiohttp
import yfinance as yf
from scipy import stats
import logging


@dataclass
class MacroData:
    """Makro veri yapısı"""
    timestamp: datetime
    vix: float
    sp500: float
    treasury_10y: float
    dxy: float
    gold: float
    oil: float
    interest_rate_fed: float
    interest_rate_10y: float
    liquidity_index: float
    risk_appetite: float
    credit_spread: float
    dollar_index: float


@dataclass
class MacroSignal:
    """Makro sinyal yapısı"""
    signal_type: str  # 'risk_on', 'risk_off', 'flight_to_quality', 'liquidity_crisis'
    strength: float  # 0-1
    confidence: float  # 0-1
    components: Dict[str, float]
    timestamp: datetime


class MacroIndicators:
    """
    Makro Ekonomik Göstergeler
    
    VIX, faiz oranları, likidite göstergeleri ve risk iştahını
    takip eden ana sınıf.
    """
    
    def __init__(self):
        """Initialize macro indicators"""
        self.logger = logging.getLogger(__name__)
        
        # Veri saklama
        self.historical_data = []
        self.current_data = None
        self.last_update = None
        
        # API endpoints (gerçek sistemde)
        self.data_sources = {
            'vix': '^VIX',
            'sp500': '^GSPC', 
            'treasury_10y': '^TNX',
            'dxy': 'DX-Y.NYB',
            'gold': 'GC=F',
            'oil': 'CL=F',
            'fed_funds': 'DFF',  # Dummy - gerçek API gerekli
            'vix_futures': 'VX1.N'
        }
        
        # Eşik değerleri
        self.thresholds = {
            'vix_critical': 30.0,
            'vix_high': 20.0,
            'vix_low': 12.0,
            'treasury_high': 5.0,
            'treasury_low': 1.0,
            'liquidity_stress': 0.3,
            'risk_appetite_extreme': 0.1,
            'credit_spread_wide': 2.0
        }
        
        # Sinyal geçmişi
        self.signal_history = []
        self.active_signals = []
        
    async def get_latest_data(self) -> Dict:
        """Son makro verileri getir"""
        try:
            # Async veri çekimi
            data = await self._fetch_macro_data()
            
            if data:
                self.current_data = data
                self.historical_data.append(data)
                self.last_update = datetime.now()
                
                # Geçmiş veriyi sınırla (son 1000 kayıt)
                if len(self.historical_data) > 1000:
                    self.historical_data = self.historical_data[-1000:]
                
                return self._process_macro_data(data)
            else:
                return self._get_dummy_data()
                
        except Exception as e:
            self.logger.error(f"Makro veri çekme hatası: {e}")
            return self._get_dummy_data()
    
    async def _fetch_macro_data(self) -> Optional[MacroData]:
        """Gerçek makro veri çekimi"""
        try:
            # YFinance ile veri çekimi
            symbols = list(self.data_sources.values())
            tickers = yf.Tickers(' '.join(symbols))
            
            # Son fiyatları al
            data_dict = {}
            for name, symbol in self.data_sources.items():
                try:
                    ticker = tickers.tickers.get(symbol)
                    if ticker:
                        hist = ticker.history(period="2d")
                        if not hist.empty:
                            data_dict[name] = hist['Close'].iloc[-1]
                        else:
                            data_dict[name] = np.nan
                    else:
                        data_dict[name] = np.nan
                except Exception as e:
                    self.logger.warning(f"{name} verisi alınamadı: {e}")
                    data_dict[name] = np.nan
            
            # Makro veri yapısı oluştur
            macro_data = MacroData(
                timestamp=datetime.now(),
                vix=data_dict.get('vix', 20.0),
                sp500=data_dict.get('sp500', 4000.0),
                treasury_10y=data_dict.get('treasury_10y', 3.5),
                dxy=data_dict.get('dxy', 100.0),
                gold=data_dict.get('gold', 2000.0),
                oil=data_dict.get('oil', 80.0),
                interest_rate_fed=5.25,  # Dummy - gerçek API gerekli
                interest_rate_10y=data_dict.get('treasury_10y', 3.5),
                liquidity_index=self._calculate_liquidity_index(data_dict),
                risk_appetite=self._calculate_risk_appetite(data_dict),
                credit_spread=1.5,  # Dummy - gerçek API gerekli
                dollar_index=data_dict.get('dxy', 100.0)
            )
            
            return macro_data
            
        except Exception as e:
            self.logger.error(f"Makro veri çekimi hatası: {e}")
            return None
    
    def _get_dummy_data(self) -> Dict:
        """Dummy makro veri (test amaçlı)"""
        return {
            'vix': 18.0 + np.random.normal(0, 5),
            'sp500': 4000.0 + np.random.normal(0, 100),
            'treasury_10y': 3.5 + np.random.normal(0, 0.5),
            'dxy': 100.0 + np.random.normal(0, 5),
            'gold': 2000.0 + np.random.normal(0, 50),
            'oil': 80.0 + np.random.normal(0, 10),
            'interest_rate_fed': 5.25,
            'interest_rate_10y': 3.5 + np.random.normal(0, 0.3),
            'liquidity_index': 100.0 + np.random.normal(0, 10),
            'risk_appetite': 0.5 + np.random.normal(0, 0.2),
            'credit_spread': 1.5 + np.random.normal(0, 0.5),
            'dollar_index': 100.0 + np.random.normal(0, 3),
            'timestamp': datetime.now()
        }
    
    def _calculate_liquidity_index(self, data_dict: Dict) -> float:
        """Likidite endeksi hesapla"""
        # Basit likidite hesaplaması
        # Gerçek sistemde daha sofistike hesaplama kullanılır
        
        components = []
        
        # VIX ters oranı (yüksek VIX = düşük likidite)
        if 'vix' in data_dict and not np.isnan(data_dict['vix']):
            vix_component = max(0, 1 - (data_dict['vix'] / 50.0))
            components.append(vix_component)
        
        # Treasury getiri (yüksek getiri = daha az likidite)
        if 'treasury_10y' in data_dict and not np.isnan(data_dict['treasury_10y']):
            treasury_component = max(0, 1 - (data_dict['treasury_10y'] / 10.0))
            components.append(treasury_component)
        
        # Dolar gücü (güçlü dolar = global likidite sıkıntısı)
        if 'dxy' in data_dict and not np.isnan(data_dict['dxy']):
            dxy_component = max(0, 1 - ((data_dict['dxy'] - 90.0) / 20.0))
            components.append(dxy_component)
        
        if components:
            return np.mean(components) * 100
        else:
            return 75.0  # Default değer
    
    def _calculate_risk_appetite(self, data_dict: Dict) -> float:
        """Risk iştahı hesapla"""
        components = []
        
        # VIX ters oranı (düşük VIX = yüksek risk iştahı)
        if 'vix' in data_dict and not np.isnan(data_dict['vix']):
            vix_component = max(0, 1 - (data_dict['vix'] / 40.0))
            components.append(vix_component)
        
        # S&P 500 momentum
        if 'sp500' in data_dict and not np.isnan(data_dict['sp500']):
            sp500_component = 0.5  # Dummy - momentum hesaplaması gerekli
            components.append(sp500_component)
        
        # Altın ters oranı (düşük altın = risk iştahı yüksek)
        if 'gold' in data_dict and not np.isnan(data_dict['gold']):
            gold_component = max(0, 1 - ((data_dict['gold'] - 1800.0) / 600.0))
            components.append(gold_component)
        
        if components:
            return np.mean(components)
        else:
            return 0.5  # Default değer
    
    def _process_macro_data(self, macro_data: MacroData) -> Dict:
        """Makro veriyi işle ve sinyaller üret"""
        processed_data = {
            'vix': macro_data.vix,
            'sp500': macro_data.sp500,
            'treasury_10y': macro_data.treasury_10y,
            'dxy': macro_data.dxy,
            'gold': macro_data.gold,
            'oil': macro_data.oil,
            'interest_rate_fed': macro_data.interest_rate_fed,
            'interest_rate_10y': macro_data.interest_rate_10y,
            'liquidity_index': macro_data.liquidity_index,
            'risk_appetite': macro_data.risk_appetite,
            'credit_spread': macro_data.credit_spread,
            'dollar_index': macro_data.dollar_index,
            'timestamp': macro_data.timestamp
        }
        
        # Derivative göstergeler
        processed_data.update(self._calculate_derivative_indicators(processed_data))
        
        # Makro sinyaller üret
        signals = self._generate_macro_signals(processed_data)
        self.active_signals.extend(signals)
        
        # Sinyal geçmişini güncelle
        self.signal_history.extend(signals)
        if len(self.signal_history) > 100:
            self.signal_history = self.signal_history[-100:]
        
        return processed_data
    
    def _calculate_derivative_indicators(self, data: Dict) -> Dict:
        """Türev makro göstergeleri hesapla"""
        derivatives = {}
        
        # Geçmiş veri varsa hesapla
        if len(self.historical_data) >= 2:
            prev_data = self.historical_data[-2]
            
            # Değişim oranları
            derivatives['vix_change'] = (data['vix'] - prev_data.vix) / prev_data.vix if prev_data.vix != 0 else 0
            derivatives['sp500_change'] = (data['sp500'] - prev_data.sp500) / prev_data.sp500 if prev_data.sp500 != 0 else 0
            derivatives['treasury_change'] = data['treasury_10y'] - prev_data.treasury_10y
            derivatives['dxy_change'] = (data['dxy'] - prev_data.dxy) / prev_data.dxy if prev_data.dxy != 0 else 0
            
            # Fed vs 10Y spread
            derivatives['fed_10y_spread'] = data['interest_rate_10y'] - data['interest_rate_fed']
            
            # Risk oranları
            derivatives['vix_percentile'] = self._calculate_percentile('vix', data['vix'])
            derivatives['treasury_percentile'] = self._calculate_percentile('treasury_10y', data['treasury_10y'])
            derivatives['liquidity_stress'] = max(0, 1 - data['liquidity_index'] / 100.0)
            derivatives['risk_off_factor'] = self._calculate_risk_off_factor(data)
        
        return derivatives
    
    def _calculate_percentile(self, indicator: str, value: float) -> float:
        """Belirli bir gösterge için percentile hesapla"""
        historical_values = []
        
        for data in self.historical_data[-100:]:  # Son 100 kayıt
            if hasattr(data, indicator):
                historical_values.append(getattr(data, indicator))
        
        if historical_values and len(historical_values) > 10:
            return stats.percentileofscore(historical_values, value) / 100.0
        else:
            return 0.5  # Default 50th percentile
    
    def _calculate_risk_off_factor(self, data: Dict) -> float:
        """Risk-off faktörü hesapla (0-1, 1 = maksimum risk-off)"""
        risk_components = []
        
        # VIX risk-off
        vix_risk = max(0, min(1, (data['vix'] - 15) / 20))  # 15-35 arası normalize
        risk_components.append(vix_risk)
        
        # Treasury yükselişi risk-off
        treasury_risk = max(0, min(1, (data['treasury_10y'] - 2) / 4))  # 2-6% arası normalize
        risk_components.append(treasury_risk)
        
        # Likidite stresi
        liquidity_risk = max(0, 1 - data['liquidity_index'] / 100)
        risk_components.append(liquidity_risk)
        
        # Dolar gücü risk-off
        dxy_risk = max(0, min(1, (data['dxy'] - 95) / 10))  # 95-105 arası normalize
        risk_components.append(dxy_risk)
        
        return np.mean(risk_components)
    
    def _generate_macro_signals(self, data: Dict) -> List[MacroSignal]:
        """Makro sinyaller üret"""
        signals = []
        
        # VIX sinyalleri
        if data['vix'] > self.thresholds['vix_critical']:
            signals.append(MacroSignal(
                signal_type='volatility_crisis',
                strength=min(1.0, (data['vix'] - self.thresholds['vix_critical']) / 10),
                confidence=0.8,
                components={'vix': data['vix']},
                timestamp=datetime.now()
            ))
        elif data['vix'] > self.thresholds['vix_high']:
            signals.append(MacroSignal(
                signal_type='elevated_volatility',
                strength=(data['vix'] - self.thresholds['vix_high']) / 10,
                confidence=0.6,
                components={'vix': data['vix']},
                timestamp=datetime.now()
            ))
        
        # Risk-on/Risk-off sinyalleri
        if data['risk_appetite'] > 0.7 and data['vix'] < self.thresholds['vix_low']:
            signals.append(MacroSignal(
                signal_type='risk_on',
                strength=data['risk_appetite'] - 0.7,
                confidence=0.7,
                components={'risk_appetite': data['risk_appetite'], 'vix': data['vix']},
                timestamp=datetime.now()
            ))
        elif data['risk_appetite'] < self.thresholds['risk_appetite_extreme'] or data['vix'] > 25:
            signals.append(MacroSignal(
                signal_type='risk_off',
                strength=0.9 - data['risk_appetite'],
                confidence=0.8,
                components={'risk_appetite': data['risk_appetite'], 'vix': data['vix']},
                timestamp=datetime.now()
            ))
        
        # Likidite krizi sinyali
        if data.get('liquidity_stress', 0) > self.thresholds['liquidity_stress']:
            signals.append(MacroSignal(
                signal_type='liquidity_crisis',
                strength=data['liquidity_stress'],
                confidence=0.7,
                components={'liquidity_stress': data['liquidity_stress']},
                timestamp=datetime.now()
            ))
        
        # Flight-to-quality sinyali
        if (data['treasury_10y'] < self.thresholds['treasury_low'] and 
            data['gold'] > 1900):
            signals.append(MacroSignal(
                signal_type='flight_to_quality',
                strength=min(1.0, (2000 - data['treasury_10y']) / 2),
                confidence=0.6,
                components={'treasury_10y': data['treasury_10y'], 'gold': data['gold']},
                timestamp=datetime.now()
            ))
        
        return signals
    
    def get_macro_summary(self) -> Dict:
        """Makro durum özeti"""
        if not self.current_data:
            return {'status': 'no_data'}
        
        data = self.current_data
        
        # Rejim belirleme
        regime = self._determine_macro_regime(data)
        
        # Risk seviyesi
        risk_level = self._calculate_risk_level(data)
        
        # Likidite durumu
        liquidity_status = self._determine_liquidity_status(data)
        
        return {
            'timestamp': data.timestamp,
            'macro_regime': regime,
            'risk_level': risk_level,
            'liquidity_status': liquidity_status,
            'key_indicators': {
                'vix': data.vix,
                'treasury_10y': data.treasury_10y,
                'sp500': data.sp500,
                'dxy': data.dxy,
                'risk_appetite': data.risk_appetite,
                'liquidity_index': data.liquidity_index
            },
            'active_signals': [s.signal_type for s in self.active_signals],
            'signal_strength': np.mean([s.strength for s in self.active_signals]) if self.active_signals else 0.0
        }
    
    def _determine_macro_regime(self, data) -> str:
        """Makro rejim belirle"""
        # Risk-off rejim
        if (data.vix > 25 or data.risk_appetite < 0.3 or 
            data.treasury_10y < 2.5):
            return 'risk_off'
        
        # Risk-on rejim
        if (data.vix < 15 and data.risk_appetite > 0.7 and 
            data.treasury_10y > 3.0):
            return 'risk_on'
        
        # Transition rejim
        if data.vix > 20 or data.risk_appetite < 0.5:
            return 'transition_risk_off'
        elif data.vix > 15 or data.risk_appetite < 0.6:
            return 'transition_neutral'
        else:
            return 'neutral'
    
    def _calculate_risk_level(self, data) -> float:
        """Risk seviyesi hesapla (0-1)"""
        risk_factors = []
        
        # VIX riski
        vix_risk = max(0, min(1, (data.vix - 10) / 30))
        risk_factors.append(vix_risk)
        
        # Getiri riski
        yield_risk = max(0, min(1, (5.0 - data.treasury_10y) / 3))
        risk_factors.append(yield_risk)
        
        # Likidite riski
        liquidity_risk = max(0, 1 - data.liquidity_index / 100)
        risk_factors.append(liquidity_risk)
        
        # Risk iştahı ters riski
        appetite_risk = 1 - data.risk_appetite
        risk_factors.append(appetite_risk)
        
        return np.mean(risk_factors)
    
    def _determine_liquidity_status(self, data) -> str:
        """Likidite durumu belirle"""
        if data.liquidity_index > 80:
            return 'ample'
        elif data.liquidity_index > 60:
            return 'adequate'
        elif data.liquidity_index > 40:
            return 'tight'
        else:
            return 'stressed'
    
    def get_indicator_trend(self, indicator: str, periods: int = 20) -> Dict:
        """Belirli bir gösterge için trend analizi"""
        if len(self.historical_data) < periods:
            return {'trend': 'insufficient_data'}
        
        # Son N dönem verisi
        recent_data = self.historical_data[-periods:]
        values = [getattr(d, indicator, None) for d in recent_data]
        
        # None değerleri temizle
        clean_values = [v for v in values if v is not None and not np.isnan(v)]
        
        if len(clean_values) < 5:
            return {'trend': 'insufficient_clean_data'}
        
        # Trend hesaplama
        x = np.arange(len(clean_values))
        slope, intercept, r_value, p_value, std_err = stats.linregress(x, clean_values)
        
        trend_strength = abs(r_value)
        trend_direction = 'up' if slope > 0 else 'down'
        
        # Trend kategorisi
        if trend_strength > 0.7:
            trend_category = f'strong_{trend_direction}'
        elif trend_strength > 0.5:
            trend_category = f'moderate_{trend_direction}'
        else:
            trend_category = 'sideways'
        
        return {
            'trend': trend_category,
            'strength': trend_strength,
            'slope': slope,
            'r_squared': r_value ** 2,
            'p_value': p_value,
            'current_value': clean_values[-1],
            'change_from_periods_ago': (clean_values[-1] - clean_values[0]) / clean_values[0] if clean_values[0] != 0 else 0
        }
    
    def clear_expired_signals(self, max_age_hours: int = 24) -> None:
        """Süresi dolmuş sinyalleri temizle"""
        cutoff_time = datetime.now() - timedelta(hours=max_age_hours)
        self.active_signals = [
            signal for signal in self.active_signals 
            if signal.timestamp > cutoff_time
        ]