"""
Volatility Detector - Volatilite Rejim Tespiti
==============================================

Volatilite rejimlerini tespit eden ve analiz eden sınıf.
GARCH, realized volatility ve volatilite clustering analizleri.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
from datetime import datetime, timedelta
from scipy import stats, optimize
from sklearn.mixture import GaussianMixture
import warnings

warnings.filterwarnings('ignore')


class VolatilityRegime(Enum):
    """Volatilite rejimleri"""
    LOW_VOL = "low_volatility"
    NORMAL_VOL = "normal_volatility"
    HIGH_VOL = "high_volatility"
    EXTREME_VOL = "extreme_volatility"
    VOLATILITY_CLUSTER = "volatility_cluster"
    REGIME_SHIFT = "regime_shift"


@dataclass
class VolatilitySignal:
    """Volatilite sinyali"""
    regime: VolatilityRegime
    confidence: float
    volatility_level: float
    expected_duration: int  # hours
    cluster_probability: float
    regime_shift_probability: float
    timestamp: datetime


class VolatilityDetector:
    """
    Volatilite Detektörü
    
    Volatilite rejimlerini tespit eden ve analiz eden ana sınıf.
    Realized volatility, GARCH modelleri ve volatilite clustering analizi yapar.
    """
    
    def __init__(self, 
                 window_size: int = 100,
                 cluster_threshold: float = 0.3,
                 extreme_vol_threshold: float = 3.0):
        """
        Args:
            window_size: Analiz penceresi boyutu
            cluster_threshold: Volatilite clustering eşiği
            extreme_vol_threshold: Aşırı volatilite eşiği
        """
        self.window_size = window_size
        self.cluster_threshold = cluster_threshold
        self.extreme_vol_threshold = extreme_vol_threshold
        
        # Volatilite verisi
        self.volatility_history = []
        self.returns_history = []
        self.current_regime = VolatilityRegime.NORMAL_VOL
        
        # GARCH model parametreleri
        self.garch_params = None
        self.garch_fitted = False
        
        # Clustering model
        self.cluster_model = GaussianMixture(n_components=3, random_state=42)
        self.cluster_fitted = False
        
        # Rejim geçmişi
        self.regime_history = []
        self.regime_transitions = []
        
    def analyze_volatility(self) -> Dict:
        """
        Volatilite analizi yap
        
        Returns:
            Volatilite analiz sonuçları
        """
        if len(self.volatility_history) < 20:
            return self._get_default_analysis()
        
        try:
            # Temel volatilite metrikleri
            volatility_metrics = self._calculate_volatility_metrics()
            
            # GARCH analizi
            garch_analysis = self._analyze_garch()
            
            # Volatilite clustering
            clustering_analysis = self._analyze_clustering()
            
            # Rejim tespiti
            current_regime = self._detect_current_regime(volatility_metrics)
            
            # Rejim geçiş olasılığı
            regime_transition_prob = self._calculate_regime_transition_prob()
            
            # Volatilite tahmini
            volatility_forecast = self._forecast_volatility()
            
            # Risk seviyesi
            risk_level = self._calculate_volatility_risk(volatility_metrics)
            
            analysis = {
                'regime': current_regime.value,
                'volatility_level': volatility_metrics['current_vol'],
                'risk_level': risk_level,
                'cluster_probability': clustering_analysis['cluster_prob'],
                'regime_shift_probability': regime_transition_prob,
                'volatility_forecast': volatility_forecast,
                'metrics': volatility_metrics,
                'garch': garch_analysis,
                'clustering': clustering_analysis,
                'expected_duration': self._estimate_regime_duration(current_regime),
                'confidence': self._calculate_confidence(volatility_metrics)
            }
            
            return analysis
            
        except Exception as e:
            print(f"Volatilite analizi hatası: {e}")
            return self._get_default_analysis()
    
    def _get_default_analysis(self) -> Dict:
        """Varsayılan analiz sonucu"""
        return {
            'regime': 'normal_volatility',
            'volatility_level': 0.02,
            'risk_level': 0.5,
            'cluster_probability': 0.0,
            'regime_shift_probability': 0.0,
            'volatility_forecast': {'short_term': 0.02, 'medium_term': 0.025},
            'expected_duration': 24,
            'confidence': 0.5
        }
    
    def _calculate_volatility_metrics(self) -> Dict:
        """Volatilite metriklerini hesapla"""
        if len(self.volatility_history) < 20:
            return {'current_vol': 0.02, 'avg_vol': 0.02}
        
        vol_series = np.array(self.volatility_history)
        returns_series = np.array(self.returns_history)
        
        # Mevcut volatilite
        current_vol = vol_series[-1] if len(vol_series) > 0 else 0.02
        
        # Ortalama volatilite
        avg_vol = np.mean(vol_series[-self.window_size:])
        
        # Volatilite yüzdelik
        vol_percentile = stats.percentileofscore(vol_series, current_vol) / 100.0
        
        # Volatilite trend
        if len(vol_series) >= 10:
            vol_trend = np.polyfit(range(10), vol_series[-10:], 1)[0]
        else:
            vol_trend = 0
        
        # Volatilite volatilitesi
        vol_of_vol = np.std(vol_series[-20:]) if len(vol_series) >= 20 else 0
        
        # Jarque-Bera test (normallik testi)
        jb_stat, jb_pvalue = stats.jarque_bera(returns_series[-100:]) if len(returns_series) >= 100 else (0, 1)
        
        return {
            'current_vol': current_vol,
            'avg_vol': avg_vol,
            'vol_percentile': vol_percentile,
            'vol_trend': vol_trend,
            'vol_of_vol': vol_of_vol,
            'skewness': stats.skew(returns_series[-50:]) if len(returns_series) >= 50 else 0,
            'kurtosis': stats.kurtosis(returns_series[-50:]) if len(returns_series) >= 50 else 0,
            'jarque_bera_pvalue': jb_pvalue
        }
    
    def _analyze_garch(self) -> Dict:
        """GARCH model analizi"""
        if len(self.returns_history) < 50:
            return {'fitted': False, 'params': None}
        
        try:
            # Basit GARCH(1,1) simülasyonu
            returns = np.array(self.returns_history)
            returns_squared = returns ** 2
            
            # Maksimum likelihood estimation (basitleştirilmiş)
            n = len(returns_squared)
            
            # GARCH parametreleri tahmini (daha karmaşık optimizasyon gerekli)
            omega = np.var(returns) * 0.1  # Sabit terim
            alpha = 0.1  # AR terimi
            beta = 0.8   # MA terimi
            
            # Conditional volatility
            conditional_vol = np.zeros(n)
            conditional_vol[0] = np.std(returns)
            
            for i in range(1, n):
                conditional_vol[i] = np.sqrt(
                    omega + alpha * returns_squared[i-1] + beta * conditional_vol[i-1]**2
                )
            
            # Model uyumu
            residuals = returns / conditional_vol
            self.garch_fitted = True
            self.garch_params = {'omega': omega, 'alpha': alpha, 'beta': beta}
            
            return {
                'fitted': True,
                'params': self.garch_params,
                'conditional_volatility': conditional_vol[-10:].tolist(),
                'volatility_persistence': alpha + beta,
                'asymmetry': False  # GJR-GARCH gerekir
            }
            
        except Exception as e:
            print(f"GARCH analizi hatası: {e}")
            return {'fitted': False, 'params': None}
    
    def _analyze_clustering(self) -> Dict:
        """Volatilite clustering analizi"""
        if len(self.volatility_history) < 30:
            return {'cluster_prob': 0.0, 'clusters': []}
        
        try:
            vol_data = np.array(self.volatility_history).reshape(-1, 1)
            
            if not self.cluster_fitted:
                # Gaussian Mixture Model ile clustering
                self.cluster_model.fit(vol_data)
                self.cluster_fitted = True
            
            # Mevcut volatilite için cluster olasılığı
            current_vol = np.array([[self.volatility_history[-1]]])
            cluster_probs = self.cluster_model.predict_proba(current_vol)[0]
            
            # En yüksek olasılıklı cluster
            max_cluster = np.argmax(cluster_probs)
            cluster_prob = cluster_probs[max_cluster]
            
            # Cluster merkezleri
            cluster_centers = self.cluster_model.means_.flatten()
            
            # Clustering gücü (volatilite artışlarının grup halinde olma eğilimi)
            clustering_strength = self._calculate_clustering_strength()
            
            return {
                'cluster_prob': cluster_prob,
                'cluster_center': cluster_centers[max_cluster],
                'all_centers': cluster_centers.tolist(),
                'clustering_strength': clustering_strength,
                'current_cluster': int(max_cluster)
            }
            
        except Exception as e:
            print(f"Clustering analizi hatası: {e}")
            return {'cluster_prob': 0.0, 'clusters': []}
    
    def _calculate_clustering_strength(self) -> float:
        """Volatilite clustering gücü hesapla"""
        if len(self.volatility_history) < 20:
            return 0.0
        
        vol_series = np.array(self.volatility_history)
        
        # Yüksek volatilite dönemlerini tespit et
        vol_threshold = np.percentile(vol_series, 75)
        high_vol_mask = vol_series > vol_threshold
        
        if np.sum(high_vol_mask) < 3:
            return 0.0
        
        # Clustering metriği: yüksek volatilite günlerinin ardışıklığı
        clusters = []
        current_cluster_length = 0
        
        for is_high in high_vol_mask:
            if is_high:
                current_cluster_length += 1
            else:
                if current_cluster_length > 0:
                    clusters.append(current_cluster_length)
                current_cluster_length = 0
        
        if current_cluster_length > 0:
            clusters.append(current_cluster_length)
        
        if not clusters:
            return 0.0
        
        # Ortalama cluster uzunluğu
        avg_cluster_length = np.mean(clusters)
        
        # Clustering gücü (1 = mükemmel clustering)
        total_high_vol_days = np.sum(high_vol_mask)
        clustering_strength = avg_cluster_length * len(clusters) / total_high_vol_days if total_high_vol_days > 0 else 0
        
        return min(clustering_strength, 1.0)
    
    def _detect_current_regime(self, metrics: Dict) -> VolatilityRegime:
        """Mevcut volatilite rejimini tespit et"""
        current_vol = metrics['current_vol']
        avg_vol = metrics['avg_vol']
        vol_percentile = metrics['vol_percentile']
        
        # Aşırı volatilite
        if current_vol > self.extreme_vol_threshold * avg_vol or vol_percentile > 0.95:
            return VolatilityRegime.EXTREME_VOL
        
        # Yüksek volatilite
        if current_vol > 2.0 * avg_vol or vol_percentile > 0.8:
            return VolatilityRegime.HIGH_VOL
        
        # Düşük volatilite
        if current_vol < 0.5 * avg_vol or vol_percentile < 0.2:
            return VolatilityRegime.LOW_VOL
        
        # Normal volatilite
        return VolatilityRegime.NORMAL_VOL
    
    def _calculate_regime_transition_prob(self) -> float:
        """Rejim geçiş olasılığı hesapla"""
        if len(self.regime_history) < 5:
            return 0.0
        
        # Son rejim değişiklikleri
        recent_regimes = [r['regime'] for r in self.regime_history[-10:]]
        
        # Rejim değişiklik sayısı
        transitions = 0
        for i in range(1, len(recent_regimes)):
            if recent_regimes[i] != recent_regimes[i-1]:
                transitions += 1
        
        # Geçiş olasılığı
        transition_rate = transitions / len(recent_regimes)
        
        # Volatilite trend faktörü
        if len(self.volatility_history) >= 10:
            recent_vol = np.mean(self.volatility_history[-5:])
            older_vol = np.mean(self.volatility_history[-10:-5])
            vol_change_factor = abs(recent_vol - older_vol) / older_vol if older_vol > 0 else 0
        else:
            vol_change_factor = 0
        
        # Final olasılık
        transition_prob = min(0.5 * transition_rate + 0.3 * vol_change_factor, 1.0)
        
        return transition_prob
    
    def _forecast_volatility(self) -> Dict:
        """Volatilite tahmini"""
        if len(self.volatility_history) < 10:
            return {'short_term': 0.02, 'medium_term': 0.025}
        
        vol_series = np.array(self.volatility_history)
        
        # Basit exponential smoothing
        alpha = 0.3
        short_term_forecast = alpha * vol_series[-1] + (1 - alpha) * np.mean(vol_series[-5:])
        
        # Trend adjustment
        if len(vol_series) >= 20:
            trend = np.polyfit(range(20), vol_series[-20:], 1)[0]
            medium_term_forecast = short_term_forecast + trend * 5  # 5 gün ileri
        else:
            medium_term_forecast = short_term_forecast
        
        return {
            'short_term': max(short_term_forecast, 0.001),
            'medium_term': max(medium_term_forecast, 0.001)
        }
    
    def _calculate_volatility_risk(self, metrics: Dict) -> float:
        """Volatilite riski hesapla (0-1)"""
        risk_components = []
        
        # Volatilite seviyesi riski
        vol_risk = min(metrics['vol_percentile'], 1.0)
        risk_components.append(vol_risk)
        
        # Volatilite volatilitesi riski
        vol_of_vol_risk = min(metrics['vol_of_vol'] * 10, 1.0)
        risk_components.append(vol_of_vol_risk)
        
        # Aşırılık riski (skewness ve kurtosis)
        excess_risk = 0
        if abs(metrics['skewness']) > 1:
            excess_risk += 0.3
        if metrics['kurtosis'] > 5:
            excess_risk += 0.3
        
        risk_components.append(excess_risk)
        
        return min(np.mean(risk_components), 1.0)
    
    def _estimate_regime_duration(self, regime: VolatilityRegime) -> int:
        """Rejim süresi tahmini (saat)"""
        duration_mapping = {
            VolatilityRegime.LOW_VOL: 48,
            VolatilityRegime.NORMAL_VOL: 24,
            VolatilityRegime.HIGH_VOL: 12,
            VolatilityRegime.EXTREME_VOL: 6,
            VolatilityRegime.VOLATILITY_CLUSTER: 18,
            VolatilityRegime.REGIME_SHIFT: 8
        }
        
        return duration_mapping.get(regime, 24)
    
    def _calculate_confidence(self, metrics: Dict) -> float:
        """Analiz güveni hesapla"""
        confidence_components = []
        
        # Veri yeterliliği
        data_sufficiency = min(len(self.volatility_history) / 100, 1.0)
        confidence_components.append(data_sufficiency)
        
        # Model uyumu
        if self.garch_fitted:
            model_confidence = 0.8
        else:
            model_confidence = 0.4
        confidence_components.append(model_confidence)
        
        # Clustering güveni
        if self.cluster_fitted:
            clustering_confidence = 0.7
        else:
            clustering_confidence = 0.3
        confidence_components.append(clustering_confidence)
        
        return np.mean(confidence_components)
    
    def update_data(self, returns: List[float], prices: List[float]) -> None:
        """Veri güncelleme"""
        if len(returns) < 1 or len(prices) < 2:
            return
        
        # Getiri serisi güncelle
        self.returns_history.extend(returns)
        if len(self.returns_history) > 1000:
            self.returns_history = self.returns_history[-1000:]
        
        # Realized volatility hesapla
        if len(prices) >= 2:
            for i in range(1, len(prices)):
                daily_return = (prices[i] - prices[i-1]) / prices[i-1]
                self.returns_history.append(daily_return)
            
            # Realized volatility (rolling window)
            window_returns = self.returns_history[-self.window_size:]
            realized_vol = np.std(window_returns) if len(window_returns) > 1 else 0.02
            
            self.volatility_history.append(realized_vol)
            if len(self.volatility_history) > 1000:
                self.volatility_history = self.volatility_history[-1000:]
        
        # Rejim geçmişini güncelle
        if len(self.volatility_history) >= 20:
            current_metrics = self._calculate_volatility_metrics()
            current_regime = self._detect_current_regime(current_metrics)
            
            # Yeni rejim kontrolü
            if (not self.regime_history or 
                self.regime_history[-1]['regime'] != current_regime):
                self.regime_history.append({
                    'regime': current_regime,
                    'timestamp': datetime.now(),
                    'volatility': current_metrics['current_vol']
                })
                
                if len(self.regime_history) > 100:
                    self.regime_history = self.regime_history[-100:]
    
    def get_regime_statistics(self) -> Dict:
        """Rejim istatistikleri"""
        if not self.regime_history:
            return {}
        
        regime_counts = {}
        total_periods = len(self.regime_history)
        
        for regime_data in self.regime_history:
            regime = regime_data['regime']
            regime_counts[regime.value] = regime_counts.get(regime.value, 0) + 1
        
        # Yüzdelik hesaplama
        regime_percentages = {
            regime: count / total_periods * 100 
            for regime, count in regime_counts.items()
        }
        
        return {
            'total_periods': total_periods,
            'regime_distribution': regime_percentages,
            'current_regime': self.current_regime.value,
            'most_common_regime': max(regime_counts, key=regime_counts.get),
            'regime_stability': 1 - (len(set(r['regime'] for r in self.regime_history[-20:])) / 20)
        }
    
    def simulate_volatility_shock(self, shock_magnitude: float = 2.0) -> Dict:
        """Volatilite şoku simülasyonu"""
        if len(self.volatility_history) < 10:
            return {'impact': 0.0, 'duration': 0}
        
        base_vol = np.mean(self.volatility_history[-20:])
        shock_vol = base_vol * shock_magnitude
        
        # Rejim geçişi simülasyonu
        if shock_vol > self.extreme_vol_threshold * base_vol:
            predicted_regime = VolatilityRegime.EXTREME_VOL
            duration_estimate = 6
        elif shock_vol > 2.0 * base_vol:
            predicted_regime = VolatilityRegime.HIGH_VOL
            duration_estimate = 12
        else:
            predicted_regime = VolatilityRegime.HIGH_VOL
            duration_estimate = 18
        
        return {
            'shock_volatility': shock_vol,
            'predicted_regime': predicted_regime.value,
            'duration_estimate': duration_estimate,
            'impact': min(shock_magnitude - 1.0, 2.0),
            'recovery_estimate': duration_estimate * 2
        }