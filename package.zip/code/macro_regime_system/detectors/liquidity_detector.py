"""
Liquidity Detector - Likidite Stres Tespiti
===========================================

Likidite stresini tespit eden ve likidite rejimlerini analiz eden sınıf.
Piyasa derinliği, bid-ask spreadleri ve likidite oranları analizi.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
from datetime import datetime, timedelta
from scipy import stats, optimize
import warnings

warnings.filterwarnings('ignore')


class LiquidityRegime(Enum):
    """Likidite rejimleri"""
    AMPLE_LIQUIDITY = "ample_liquidity"
    ADEQUATE_LIQUIDITY = "adequate_liquidity"
    TIGHT_LIQUIDITY = "tight_liquidity"
    STRESSED_LIQUIDITY = "stressed_liquidity"
    LIQUIDITY_CRISIS = "liquidity_crisis"


@dataclass
class LiquiditySignal:
    """Likidite sinyali"""
    regime: LiquidityRegime
    stress_level: float  # 0-1
    confidence: float
    bid_ask_spread: float
    market_depth: float
    expected_duration: int
    timestamp: datetime


class LiquidityDetector:
    """
    Likidite Detektörü
    
    Piyasa likidite durumunu analiz eden ve likidite stresini tespit eden ana sınıf.
    Bid-ask spreadleri, piyasa derinliği ve likidite metriklerini takip eder.
    """
    
    def __init__(self,
                 spread_threshold: float = 0.05,
                 depth_threshold: float = 1000000,
                 stress_threshold: float = 0.7):
        """
        Args:
            spread_threshold: Bid-ask spread eşiği (%)
            depth_threshold: Piyasa derinliği eşiği
            stress_threshold: Likidite stresi eşiği
        """
        self.spread_threshold = spread_threshold
        self.depth_threshold = depth_threshold
        self.stress_threshold = stress_threshold
        
        # Likidite verileri
        self.spread_history = []
        self.depth_history = []
        self.volume_history = []
        self.turnover_history = []
        
        # Mevcut durum
        self.current_regime = LiquidityRegime.ADEQUATE_LIQUIDITY
        self.current_stress_level = 0.0
        
        # Rejim geçmişi
        self.regime_history = []
        self.stress_events = []
        
        # Likidite metrikleri
        self.liquidity_scores = []
        self.market_efficiency_scores = []
        
    def analyze_liquidity(self) -> Dict:
        """
        Likidite analizi yap
        
        Returns:
            Likidite analiz sonuçları
        """
        if (len(self.spread_history) < 10 and 
            len(self.volume_history) < 10):
            return self._get_default_analysis()
        
        try:
            # Temel likidite metrikleri
            liquidity_metrics = self._calculate_liquidity_metrics()
            
            # Bid-ask spread analizi
            spread_analysis = self._analyze_bid_ask_spread()
            
            # Piyasa derinliği analizi
            depth_analysis = self._analyze_market_depth()
            
            # Hacim analizi
            volume_analysis = self._analyze_volume_patterns()
            
            # Mevcut rejim tespiti
            current_regime = self._detect_current_regime(
                liquidity_metrics, spread_analysis, depth_analysis
            )
            
            # Likidite stress seviyesi
            stress_level = self._calculate_stress_level(
                liquidity_metrics, spread_analysis, depth_analysis
            )
            
            # Likidite tahmini
            liquidity_forecast = self._forecast_liquidity()
            
            # Piyasa verimliliği
            efficiency_score = self._calculate_market_efficiency()
            
            analysis = {
                'regime': current_regime.value,
                'stress_level': stress_level,
                'confidence': self._calculate_confidence(liquidity_metrics),
                'bid_ask_spread': spread_analysis['current_spread'],
                'market_depth': depth_analysis['current_depth'],
                'liquidity_forecast': liquidity_forecast,
                'expected_duration': self._estimate_regime_duration(current_regime),
                'efficiency_score': efficiency_score,
                'metrics': liquidity_metrics,
                'spread_analysis': spread_analysis,
                'depth_analysis': depth_analysis,
                'volume_analysis': volume_analysis
            }
            
            return analysis
            
        except Exception as e:
            print(f"Likidite analizi hatası: {e}")
            return self._get_default_analysis()
    
    def _get_default_analysis(self) -> Dict:
        """Varsayılan analiz sonucu"""
        return {
            'regime': 'adequate_liquidity',
            'stress_level': 0.3,
            'confidence': 0.5,
            'bid_ask_spread': 0.02,
            'market_depth': 1000000,
            'liquidity_forecast': {'short_term': 0.7, 'medium_term': 0.6},
            'expected_duration': 24,
            'efficiency_score': 0.7
        }
    
    def _calculate_liquidity_metrics(self) -> Dict:
        """Likidite metriklerini hesapla"""
        metrics = {}
        
        # Spread metrikleri
        if len(self.spread_history) > 0:
            current_spread = self.spread_history[-1]
            avg_spread = np.mean(self.spread_history[-20:]) if len(self.spread_history) >= 20 else current_spread
            
            metrics.update({
                'current_spread': current_spread,
                'avg_spread': avg_spread,
                'spread_volatility': np.std(self.spread_history[-20:]) if len(self.spread_history) >= 20 else 0,
                'spread_percentile': stats.percentileofscore(self.spread_history, current_spread) / 100.0
            })
        
        # Derinlik metrikleri
        if len(self.depth_history) > 0:
            current_depth = self.depth_history[-1]
            avg_depth = np.mean(self.depth_history[-20:]) if len(self.depth_history) >= 20 else current_depth
            
            metrics.update({
                'current_depth': current_depth,
                'avg_depth': avg_depth,
                'depth_percentile': stats.percentileofscore(self.depth_history, current_depth) / 100.0,
                'depth_trend': np.polyfit(range(min(20, len(self.depth_history))), 
                                        self.depth_history[-20:], 1)[0] if len(self.depth_history) >= 2 else 0
            })
        
        # Hacim metrikleri
        if len(self.volume_history) > 0:
            current_volume = self.volume_history[-1]
            avg_volume = np.mean(self.volume_history[-20:]) if len(self.volume_history) >= 20 else current_volume
            
            metrics.update({
                'current_volume': current_volume,
                'avg_volume': avg_volume,
                'volume_ratio': current_volume / avg_volume if avg_volume > 0 else 1.0,
                'volume_percentile': stats.percentileofscore(self.volume_history, current_volume) / 100.0
            })
        
        # Kompozit likidite skoru
        liquidity_score = self._calculate_composite_liquidity_score(metrics)
        metrics['composite_liquidity_score'] = liquidity_score
        
        return metrics
    
    def _calculate_composite_liquidity_score(self, metrics: Dict) -> float:
        """Kompozit likidite skoru hesapla (0-1)"""
        components = []
        
        # Spread skoru (düşük spread = yüksek likidite)
        if 'spread_percentile' in metrics:
            spread_score = 1 - metrics['spread_percentile']
            components.append(spread_score)
        
        # Derinlik skoru (yüksek derinlik = yüksek likidite)
        if 'depth_percentile' in metrics:
            depth_score = metrics['depth_percentile']
            components.append(depth_score)
        
        # Hacim skoru
        if 'volume_percentile' in metrics:
            volume_score = metrics['volume_percentile']
            components.append(volume_score)
        
        return np.mean(components) if components else 0.5
    
    def _analyze_bid_ask_spread(self) -> Dict:
        """Bid-ask spread analizi"""
        if len(self.spread_history) < 10:
            return {'trend': 'insufficient_data', 'volatility': 0}
        
        spreads = np.array(self.spread_history)
        
        # Trend analizi
        trend_slope, _, r_value, _, _ = stats.linregress(
            range(len(spreads[-20:])), spreads[-20:]
        )
        
        trend_strength = abs(r_value)
        trend_direction = 'widening' if trend_slope > 0 else 'narrowing'
        
        if trend_strength > 0.7:
            trend_category = f'strong_{trend_direction}'
        elif trend_strength > 0.5:
            trend_category = f'moderate_{trend_direction}'
        else:
            trend_category = 'stable'
        
        # Spread volatilitesi
        spread_volatility = np.std(spreads[-20:]) if len(spreads) >= 20 else 0
        
        # Anomali tespiti
        current_spread = spreads[-1]
        spread_zscore = (current_spread - np.mean(spreads[-50:])) / np.std(spreads[-50:]) if len(spreads) >= 50 else 0
        
        anomaly_detected = abs(spread_zscore) > 2
        
        return {
            'trend': trend_category,
            'trend_strength': trend_strength,
            'volatility': spread_volatility,
            'current_spread': current_spread,
            'z_score': spread_zscore,
            'anomaly_detected': anomaly_detected,
            'stability_index': 1 - (spread_volatility / np.mean(spreads[-20:])) if len(spreads) >= 20 else 0.5
        }
    
    def _analyze_market_depth(self) -> Dict:
        """Piyasa derinliği analizi"""
        if len(self.depth_history) < 10:
            return {'trend': 'insufficient_data', 'adequacy': 0.5}
        
        depths = np.array(self.depth_history)
        
        # Trend analizi
        trend_slope, _, r_value, _, _ = stats.linregress(
            range(len(depths[-20:])), depths[-20:]
        )
        
        trend_strength = abs(r_value)
        trend_direction = 'increasing' if trend_slope > 0 else 'decreasing'
        
        if trend_strength > 0.7:
            trend_category = f'strong_{trend_direction}'
        elif trend_strength > 0.5:
            trend_category = f'moderate_{trend_direction}'
        else:
            trend_category = 'stable'
        
        # Derinlik yeterliliği
        current_depth = depths[-1]
        adequacy_score = min(current_depth / self.depth_threshold, 2.0)  # 2x threshold'a kadar
        
        # Derinlik kalitesi
        depth_quality = self._assess_depth_quality(depths)
        
        return {
            'trend': trend_category,
            'trend_strength': trend_strength,
            'current_depth': current_depth,
            'adequacy_score': adequacy_score,
            'depth_quality': depth_quality,
            'depth_consistency': 1 - (np.std(depths[-20:]) / np.mean(depths[-20:])) if len(depths) >= 20 else 0.5
        }
    
    def _assess_depth_quality(self, depths: np.ndarray) -> float:
        """Derinlik kalitesi değerlendirmesi"""
        if len(depths) < 20:
            return 0.5
        
        # Derinlik değişkenliği
        depth_cv = np.std(depths[-20:]) / np.mean(depths[-20:])
        stability_score = 1 / (1 + depth_cv)
        
        # Trend kalitesi
        if len(depths) >= 20:
            trend_slope = np.polyfit(range(20), depths[-20:], 1)[0]
            trend_quality = 1 if trend_slope > 0 else 0.7
        else:
            trend_quality = 0.5
        
        return (stability_score + trend_quality) / 2
    
    def _analyze_volume_patterns(self) -> Dict:
        """Hacim paternleri analizi"""
        if len(self.volume_history) < 10:
            return {'pattern': 'insufficient_data'}
        
        volumes = np.array(self.volume_history)
        
        # Hacim trend analizi
        if len(volumes) >= 20:
            trend_slope, _, r_value, _, _ = stats.linregress(
                range(20), volumes[-20:]
            )
            trend_strength = abs(r_value)
        else:
            trend_slope = 0
            trend_strength = 0
        
        # Hacim patern tespiti
        recent_volumes = volumes[-10:]
        
        # Artan hacim patern
        increasing_pattern = all(recent_volumes[i] >= recent_volumes[i-1] * 0.9 
                               for i in range(1, len(recent_volumes)))
        
        # Azalan hacim patern  
        decreasing_pattern = all(recent_volumes[i] <= recent_volumes[i-1] * 1.1
                               for i in range(1, len(recent_volumes)))
        
        # Dalgalı patern
        volatile_pattern = np.std(recent_volumes) / np.mean(recent_volumes) > 0.5
        
        if increasing_pattern:
            pattern = 'increasing_volume'
        elif decreasing_pattern:
            pattern = 'decreasing_volume'
        elif volatile_pattern:
            pattern = 'volatile_volume'
        else:
            pattern = 'stable_volume'
        
        # Hacim kalitesi
        volume_quality = self._calculate_volume_quality(volumes)
        
        return {
            'pattern': pattern,
            'trend_strength': trend_strength,
            'current_volume': volumes[-1],
            'volume_quality': volume_quality,
            'volume_consistency': 1 - (np.std(recent_volumes) / np.mean(recent_volumes))
        }
    
    def _calculate_volume_quality(self, volumes: np.ndarray) -> float:
        """Hacim kalitesi hesapla"""
        if len(volumes) < 20:
            return 0.5
        
        # Hacim stabilitesi
        recent_volumes = volumes[-20:]
        volume_cv = np.std(recent_volumes) / np.mean(recent_volumes)
        stability_score = max(0, 1 - volume_cv)
        
        # Trend kalitesi
        trend_slope = np.polyfit(range(20), recent_volumes, 1)[0]
        trend_score = 0.8 if trend_slope > 0 else 0.4
        
        # Aşırı hacim kontrolü
        volume_zscore = abs((recent_volumes[-1] - np.mean(recent_volumes)) / np.std(recent_volumes))
        outlier_penalty = min(volume_zscore / 3, 0.3)
        
        return max(0, (stability_score + trend_score) / 2 - outlier_penalty)
    
    def _detect_current_regime(self, metrics: Dict, spread_analysis: Dict, depth_analysis: Dict) -> LiquidityRegime:
        """Mevcut likidite rejimini tespit et"""
        # Kompozit likidite skoru
        liquidity_score = metrics.get('composite_liquidity_score', 0.5)
        
        # Spread bazlı değerlendirme
        spread_percentile = metrics.get('spread_percentile', 0.5)
        current_spread = metrics.get('current_spread', 0.02)
        
        # Derinlik bazlı değerlendirme
        depth_percentile = metrics.get('depth_percentile', 0.5)
        current_depth = metrics.get('current_depth', 1000000)
        
        # Rejim belirleme
        if (liquidity_score > 0.8 and 
            spread_percentile < 0.3 and 
            depth_percentile > 0.7):
            return LiquidityRegime.AMPLE_LIQUIDITY
        
        elif (liquidity_score > 0.6 and 
              spread_percentile < 0.5 and 
              depth_percentile > 0.5):
            return LiquidityRegime.ADEQUATE_LIQUIDITY
        
        elif (liquidity_score > 0.3 and 
              spread_percentile < 0.7 and 
              depth_percentile > 0.3):
            return LiquidityRegime.TIGHT_LIQUIDITY
        
        elif (liquidity_score > 0.1 and 
              current_spread > self.spread_threshold * 1.5):
            return LiquidityRegime.STRESSED_LIQUIDITY
        
        else:
            return LiquidityRegime.LIQUIDITY_CRISIS
    
    def _calculate_stress_level(self, metrics: Dict, spread_analysis: Dict, depth_analysis: Dict) -> float:
        """Likidite stress seviyesi hesapla (0-1)"""
        stress_components = []
        
        # Spread stress
        current_spread = metrics.get('current_spread', 0.02)
        spread_stress = min(current_spread / (self.spread_threshold * 2), 1.0)
        stress_components.append(spread_stress)
        
        # Derinlik stress
        current_depth = metrics.get('current_depth', 1000000)
        depth_stress = max(0, 1 - current_depth / self.depth_threshold)
        stress_components.append(depth_stress)
        
        # Kompozit likidite stress
        liquidity_score = metrics.get('composite_liquidity_score', 0.5)
        liquidity_stress = 1 - liquidity_score
        stress_components.append(liquidity_stress)
        
        # Anomali stress
        if spread_analysis.get('anomaly_detected', False):
            anomaly_stress = 0.8
        else:
            anomaly_stress = 0.0
        stress_components.append(anomaly_stress)
        
        # Volume stress
        volume_ratio = metrics.get('volume_ratio', 1.0)
        if volume_ratio < 0.5:  # Hacim düşüşü
            volume_stress = (0.5 - volume_ratio) * 2
        else:
            volume_stress = 0.0
        stress_components.append(volume_stress)
        
        return min(np.mean(stress_components), 1.0)
    
    def _forecast_liquidity(self) -> Dict:
        """Likidite tahmini"""
        if len(self.liquidity_scores) < 10:
            return {'short_term': 0.7, 'medium_term': 0.6}
        
        scores = np.array(self.liquidity_scores)
        
        # Basit exponential smoothing
        alpha = 0.3
        
        # Kısa vadeli tahmin (1 gün)
        short_term = alpha * scores[-1] + (1 - alpha) * np.mean(scores[-5:])
        
        # Orta vadeli tahmin (5 gün)
        if len(scores) >= 20:
            trend = np.polyfit(range(20), scores[-20:], 1)[0]
            medium_term = short_term + trend * 5
        else:
            medium_term = short_term
        
        return {
            'short_term': max(min(short_term, 1.0), 0.0),
            'medium_term': max(min(medium_term, 1.0), 0.0)
        }
    
    def _calculate_market_efficiency(self) -> float:
        """Piyasa verimliliği hesapla"""
        if len(self.market_efficiency_scores) < 5:
            return 0.7
        
        # Son 10 verimlilik skorunun ortalaması
        recent_scores = self.market_efficiency_scores[-10:]
        return np.mean(recent_scores)
    
    def _calculate_confidence(self, metrics: Dict) -> float:
        """Analiz güveni hesapla"""
        confidence_components = []
        
        # Veri yeterliliği
        data_availability = min(
            (len(self.spread_history) + len(self.depth_history) + len(self.volume_history)) / 60,
            1.0
        )
        confidence_components.append(data_availability)
        
        # Metrik tutarlılığı
        if 'composite_liquidity_score' in metrics:
            metric_consistency = 0.8 if 0.1 <= metrics['composite_liquidity_score'] <= 0.9 else 0.4
            confidence_components.append(metric_consistency)
        
        return np.mean(confidence_components) if confidence_components else 0.5
    
    def _estimate_regime_duration(self, regime: LiquidityRegime) -> int:
        """Rejim süresi tahmini (saat)"""
        duration_mapping = {
            LiquidityRegime.AMPLE_LIQUIDITY: 72,
            LiquidityRegime.ADEQUATE_LIQUIDITY: 48,
            LiquidityRegime.TIGHT_LIQUIDITY: 24,
            LiquidityRegime.STRESSED_LIQUIDITY: 12,
            LiquidityRegime.LIQUIDITY_CRISIS: 6
        }
        
        return duration_mapping.get(regime, 24)
    
    def update_market_data(self, bid: float, ask: float, depth: float, volume: float) -> None:
        """Piyasa verisi güncelle"""
        # Bid-ask spread hesapla
        spread = (ask - bid) / bid if bid > 0 else 0.02
        
        # Verileri güncelle
        self.spread_history.append(spread)
        self.depth_history.append(depth)
        self.volume_history.append(volume)
        
        # Geçmiş veriyi sınırla
        if len(self.spread_history) > 500:
            self.spread_history = self.spread_history[-500:]
            self.depth_history = self.depth_history[-500:]
            self.volume_history = self.volume_history[-500:]
        
        # Kompozit likidite skoru hesapla
        liquidity_score = self._calculate_current_liquidity_score()
        self.liquidity_scores.append(liquidity_score)
        
        if len(self.liquidity_scores) > 100:
            self.liquidity_scores = self.liquidity_scores[-100:]
        
        # Piyasa verimliliği güncelle
        efficiency_score = self._calculate_current_efficiency_score()
        self.market_efficiency_scores.append(efficiency_score)
        
        if len(self.market_efficiency_scores) > 100:
            self.market_efficiency_scores = self.market_efficiency_scores[-100:]
        
        # Rejim geçişini tespit et
        if len(self.spread_history) >= 20:
            current_metrics = self._calculate_liquidity_metrics()
            spread_analysis = self._analyze_bid_ask_spread()
            depth_analysis = self._analyze_market_depth()
            
            new_regime = self._detect_current_regime(current_metrics, spread_analysis, depth_analysis)
            
            if new_regime != self.current_regime:
                self._handle_regime_change(new_regime, current_metrics)
    
    def _calculate_current_liquidity_score(self) -> float:
        """Mevcut likidite skoru hesapla"""
        if not self.spread_history or not self.depth_history:
            return 0.5
        
        current_spread = self.spread_history[-1]
        current_depth = self.depth_history[-1] if self.depth_history else 1000000
        
        # Normalize edilmiş skorlar
        spread_score = max(0, 1 - (current_spread / (self.spread_threshold * 2)))
        depth_score = min(current_depth / self.depth_threshold, 1.0)
        
        return (spread_score + depth_score) / 2
    
    def _calculate_current_efficiency_score(self) -> float:
        """Mevcut verimlilik skoru hesapla"""
        if len(self.spread_history) < 10 or len(self.volume_history) < 10:
            return 0.7
        
        # Spread stabilitesi
        recent_spreads = self.spread_history[-20:]
        spread_stability = 1 - (np.std(recent_spreads) / np.mean(recent_spreads))
        
        # Hacim kalitesi
        recent_volumes = self.volume_history[-20:]
        volume_consistency = 1 - (np.std(recent_volumes) / np.mean(recent_volumes))
        
        return (spread_stability + volume_consistency) / 2
    
    def _handle_regime_change(self, new_regime: LiquidityRegime, metrics: Dict) -> None:
        """Rejim değişikliğini yönet"""
        old_regime = self.current_regime
        self.current_regime = new_regime
        
        # Stress seviyesi güncelle
        self.current_stress_level = self._calculate_stress_level(
            metrics, self._analyze_bid_ask_spread(), self._analyze_market_depth()
        )
        
        # Rejim geçmişini kaydet
        self.regime_history.append({
            'regime': new_regime,
            'timestamp': datetime.now(),
            'stress_level': self.current_stress_level
        })
        
        if len(self.regime_history) > 100:
            self.regime_history = self.regime_history[-100:]
        
        # Stress event kaydet
        if self.current_stress_level > self.stress_threshold:
            self.stress_events.append({
                'timestamp': datetime.now(),
                'stress_level': self.current_stress_level,
                'regime': new_regime,
                'duration_estimate': self._estimate_regime_duration(new_regime)
            })
    
    def get_liquidity_summary(self) -> Dict:
        """Likidite durumu özeti"""
        if not self.spread_history:
            return {'status': 'no_data'}
        
        # Temel metrikler
        current_spread = self.spread_history[-1]
        current_depth = self.depth_history[-1] if self.depth_history else 0
        current_volume = self.volume_history[-1] if self.volume_history else 0
        
        # Trend analizi
        spread_trend = 'stable'
        if len(self.spread_history) >= 20:
            recent_spreads = self.spread_history[-20:]
            trend_slope = np.polyfit(range(20), recent_spreads, 1)[0]
            if trend_slope > 0.001:
                spread_trend = 'widening'
            elif trend_slope < -0.001:
                spread_trend = 'narrowing'
        
        return {
            'current_regime': self.current_regime.value,
            'stress_level': self.current_stress_level,
            'current_metrics': {
                'bid_ask_spread': current_spread,
                'market_depth': current_depth,
                'volume': current_volume
            },
            'trends': {
                'spread_trend': spread_trend,
                'liquidity_score': self.liquidity_scores[-1] if self.liquidity_scores else 0.5
            },
            'regime_history': {
                'total_changes': len(self.regime_history),
                'recent_regime': self.regime_history[-1]['regime'].value if self.regime_history else 'unknown',
                'stress_events': len(self.stress_events)
            }
        }
    
    def simulate_liquidity_shock(self, shock_intensity: float = 0.8) -> Dict:
        """Likidite şoku simülasyonu"""
        base_spread = np.mean(self.spread_history[-20:]) if len(self.spread_history) >= 20 else 0.02
        base_depth = np.mean(self.depth_history[-20:]) if len(self.depth_history) >= 20 else 1000000
        
        # Şok sonrası değerler
        shocked_spread = base_spread * (1 + shock_intensity)
        shocked_depth = base_depth * (1 - shock_intensity)
        
        # Tahmini rejim
        if shocked_spread > self.spread_threshold * 2:
            predicted_regime = LiquidityRegime.LIQUIDITY_CRISIS
        elif shocked_spread > self.spread_threshold * 1.5:
            predicted_regime = LiquidityRegime.STRESSED_LIQUIDITY
        elif shocked_depth < self.depth_threshold * 0.5:
            predicted_regime = LiquidityRegime.TIGHT_LIQUIDITY
        else:
            predicted_regime = LiquidityRegime.ADEQUATE_LIQUIDITY
        
        return {
            'shock_intensity': shock_intensity,
            'predicted_regime': predicted_regime.value,
            'shocked_spread': shocked_spread,
            'shocked_depth': shocked_depth,
            'impact_assessment': 'severe' if shock_intensity > 0.8 else 'moderate',
            'recovery_estimate_hours': self._estimate_regime_duration(predicted_regime)
        }