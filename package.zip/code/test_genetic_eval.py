#!/usr/bin/env python3
"""
Genetic Program Tree Evaluation Test
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'code', 'genetic_engine'))

import numpy as np
from core.engine import create_engine, EvolutionConfig
from utils.test_data import generate_sample_data

def test_genetic_program_evaluation():
    """Genetic program tree evaluation test"""
    print("🧪 Genetic Program Tree Evaluation Test")
    print("=" * 50)
    
    # Test data oluştur
    data = generate_sample_data(n_periods=100)
    print(f"✅ Test data oluşturuldu: {len(data['close'])} period")
    
    # Engine oluştur
    config = EvolutionConfig(
        population_size=50,
        generations=5,
        crossover_prob=0.8,
        mutation_prob=0.1
    )
    
    engine = create_engine(config)
    print("✅ Engine oluşturuldu")
    
    # Test individual oluştur
    test_individual = [
        "GT",  # Greater than operator
        ["SMA", "CLOSE", 10],  # SMA(close, 10)
        ["SMA", "CLOSE", 20]   # SMA(close, 20)
    ]
    
    print(f"📊 Test individual: {test_individual}")
    
    # Test evaluation
    try:
        signals = engine.parallel_evaluator._evaluate_individual(test_individual, data)
        print(f"✅ Signals generated: {len(signals)} values")
        print(f"Signal range: [{np.min(signals):.3f}, {np.max(signals):.3f}]")
        print(f"Signal mean: {np.mean(signals):.3f}")
        
        # Fitness calculation test
        fitness = engine._evaluate_individual(test_individual, data)
        print(f"🎯 Fitness değeri: {fitness[0]:.4f}")
        
        if fitness[0] > 0:
            print("✅ Fitness değeri pozitif - gerçek trading performance hesaplanıyor!")
        else:
            print("⚠️  Fitness değeri hala 0 - detaylı debugging gerekli")
        
        # Test with another individual
        test_individual_2 = [
            "ADD",  # Add operator
            "CLOSE",  # Close price
            ["MUL", 0.05, ["RSI", "CLOSE", 14]]  # 0.05 * RSI(close, 14)
        ]
        
        print(f"\n📊 Test individual 2: {test_individual_2}")
        signals_2 = engine.parallel_evaluator._evaluate_individual(test_individual_2, data)
        fitness_2 = engine._evaluate_individual(test_individual_2, data)
        
        print(f"✅ Signals 2: {len(signals_2)} values")
        print(f"Signal 2 range: [{np.min(signals_2):.3f}, {np.max(signals_2):.3f}]")
        print(f"🎯 Fitness 2 değeri: {fitness_2[0]:.4f}")
        
        # Full evolution test
        print(f"\n🚀 Full Evolution Test (5 generation)")
        stats = engine.run_evolution(data, checkpoint_interval=100)
        
        if stats:
            final_stats = stats[-1]
            print(f"✅ Evolution completed: {final_stats.generation} generations")
            print(f"Best fitness: {final_stats.best_fitness:.4f}")
            print(f"Average fitness: {final_stats.avg_fitness:.4f}")
            
            if final_stats.best_fitness > 0:
                print("🎉 SUCCESS: Gerçek fitness değerleri hesaplanıyor!")
            else:
                print("❌ Hala 0.0 fitness - ek debugging gerekli")
        
        return True
        
    except Exception as e:
        print(f"❌ Test error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    test_genetic_program_evaluation()