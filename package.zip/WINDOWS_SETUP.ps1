# 🚀 Windows PowerShell - Tek Komut Setup

Write-Host "🚀 Crypto Trading System - Windows Setup" -ForegroundColor Green
Write-Host "=============================================" -ForegroundColor Green

# 1. Python kontrolü
Write-Host "[1/5] Python kontrol ediliyor..." -ForegroundColor Yellow
try {
    python --version
    Write-Host "✅ Python bulundu" -ForegroundColor Green
} catch {
    Write-Host "❌ Python bulunamadı! Python 3.9+ gerekli" -ForegroundColor Red
    exit 1
}

# 2. Virtual environment oluştur
Write-Host "`n[2/5] Virtual environment oluşturuluyor..." -ForegroundColor Yellow
if (Test-Path "venv") {
    Write-Host "⚠️  Virtual environment zaten mevcut" -ForegroundColor Yellow
} else {
    python -m venv venv
    Write-Host "✅ Virtual environment oluşturuldu" -ForegroundColor Green
}

# 3. Dependencies yükle
Write-Host "`n[3/5] Dependencies yükleniyor..." -ForegroundColor Yellow
.\venv\Scripts\python.exe -m pip install --upgrade pip

if (Test-Path "requirements-dev.txt") {
    .\venv\Scripts\python.exe -m pip install -r requirements-dev.txt
    Write-Host "✅ Dev dependencies yüklendi" -ForegroundColor Green
} elseif (Test-Path "requirements.txt") {
    .\venv\Scripts\python.exe -m pip install -r requirements.txt
    Write-Host "✅ Requirements yüklendi" -ForegroundColor Green
} else {
    Write-Host "ℹ️  Temel paketler yükleniyor..." -ForegroundColor Blue
    .\venv\Scripts\python.exe -m pip install numpy pandas scikit-learn matplotlib seaborn requests fastapi uvicorn pytest
    Write-Host "✅ Temel paketler yüklendi" -ForegroundColor Green
}

# 4. Sistem testleri
Write-Host "`n[4/5] Sistem testleri çalıştırılıyor..." -ForegroundColor Yellow

# DVK Test
if (Test-Path "test_dvk_algorithm.py") {
    Write-Host "  🔬 DVK Algorithm testi..." -ForegroundColor Blue
    .\venv\Scripts\python.exe test_dvk_algorithm.py
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  ✅ DVK testi başarılı" -ForegroundColor Green
    } else {
        Write-Host "  ⚠️  DVK testi başarısız (kritik değil)" -ForegroundColor Yellow
    }
}

# Quick Test
if (Test-Path "quick_test.py") {
    Write-Host "  🔬 Hızlı sistem testi..." -ForegroundColor Blue
    .\venv\Scripts\python.exe quick_test.py
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  ✅ Hızlı test başarılı" -ForegroundColor Green
    } else {
        Write-Host "  ⚠️  Hızlı test başarısız (kritik değil)" -ForegroundColor Yellow
    }
}

# Code modül import test
if (Test-Path "code") {
    Write-Host "  🔬 Trading modülleri testi..." -ForegroundColor Blue
    try {
        .\venv\Scripts\python.exe -c "import sys; sys.path.append('code'); print('✅ Trading modülleri çalışıyor')"
        Write-Host "  ✅ Code modülleri başarılı" -ForegroundColor Green
    } catch {
        Write-Host "  ⚠️  Code modülleri uyarısı" -ForegroundColor Yellow
    }
}

# 5. Sonuç
Write-Host "`n[5/5] Kurulum tamamlandı!" -ForegroundColor Green
Write-Host "🎉" -ForegroundColor Green -NoNewline
Write-Host " Tüm işlemler başarıyla tamamlandı!" -ForegroundColor Green

Write-Host "`n📋 Sonraki Adımlar:" -ForegroundColor Yellow
Write-Host "1. VS Code interpreter: .\venv\Scripts\python.exe" -ForegroundColor White
Write-Host "2. Debug test: F5 ile debug başlat" -ForegroundColor White
Write-Host "3. Manuel test: python test_dvk_algorithm.py" -ForegroundColor White

Write-Host "`n💡 Artık sistem hazır! İyi çalışmalar! 🚀" -ForegroundColor Green