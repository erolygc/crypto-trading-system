# 📦 Crypto Trading System - İndirme Rehberi

## 🚀 Sisteminizi İndirin

### 📁 İndirilebilir Dosyalar

#### 1. **Tam Sistem Arşivi** (Recommended)
```bash
# crypto-trading-system-v1.0.0.tar.gz (3.3MB)
# Tam sistem, production-ready, Azure deployment included
```

#### 2. **ZIP Arşivi** (Windows kullanıcıları için)
```bash
# crypto-trading-system-v1.0.0.zip
# Windows compatible archive
```

#### 3. **Git Repository**
```bash
git clone <repository-url>
# Full version control, easy updates
```

## 📋 İndirme Seçenekleri

### 🎯 Hızlı İndirme

#### **Option 1: Arşiv Dosyası**
1. `crypto-trading-system-v1.0.0.tar.gz` dosyasını indirin
2. Extract edin: `tar -xzf crypto-trading-system-v1.0.0.tar.gz`
3. Klasöre gidin: `cd crypto-trading-system-v1.0.0`

#### **Option 2: Git Clone**
```bash
git clone <repository-url> crypto-trading-system
cd crypto-trading-system
```

### 🔧 Sistem Gereksinimleri

#### **Minimum Gereksinimler:**
- **OS**: Linux (Ubuntu 18.04+), macOS (10.14+), Windows 10+
- **RAM**: 8GB
- **CPU**: 4 cores
- **Disk**: 10GB free space
- **Network**: Stable internet connection

#### **Azure Deployment:**
- Azure hesabı + subscription
- Azure CLI v2.30+
- kubectl v1.20+
- Docker v20.10+

## ⚡ Hızlı Başlangıç

### 1. **Sistemi Çıkarın**
```bash
# Linux/macOS
tar -xzf crypto-trading-system-v1.0.0.tar.gz
cd crypto-trading-system-v1.0.0

# Windows (use 7-Zip or WinRAR)
# Extract the .tar.gz file to crypto-trading-system-v1.0.0
```

### 2. **Azure Setup**
```bash
# Azure CLI kurulumu
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

# Giriş yapın
az login

# Tek komutla deployment
./azure-deployment-master.sh production eastus
```

### 3. **Development Setup**
```bash
# Python environment
python3 -m venv venv
source venv/bin/activate  # Linux/macOS
# veya
venv\Scripts\activate     # Windows

# Dependencies
pip install -r requirements-dev.txt

# VS Code workspace
code .
```

### 4. **Docker Development**
```bash
# Tüm servisleri başlat
docker-compose up -d

# Service status
docker-compose ps
```

## 📊 İçerik Özeti

### 🎯 **348+ Python Dosyası**
```
📁 code/ - Trading Engines
├── 📁 backtester/ (17 dosya) - Event-driven backtesting
├── 📁 dvk_engine/ (5 dosya) - Dynamic asset characterization  
├── 📁 genetic_engine/ (10 dosya) - Genetic programming
├── 📁 signal_scoring/ (9 dosya) - Multi-factor signals
├── 📁 portfolio_optimization/ (12 dosya) - Portfolio theory
├── 📁 correlation_engine/ (12 dosya) - Correlation analysis
├── 📁 macro_regime_system/ (6 dosya) - Market regime detection
├── 📁 risk_budget_management/ (10 dosya) - Risk management
├── 📁 smart_order_router/ (15 dosya) - Order routing
├── 📁 iceberg_detection/ (11 dosya) - Hidden order detection
├── 📁 twap_vwap_execution/ (8 dosya) - Execution algorithms
├── 📁 slippage_minimization/ (11 dosya) - Market impact
├── 📁 meta_learning_engine/ (15 dosya) - Self-learning
├── 📁 performance_monitoring/ (18 dosya) - Real-time monitoring
├── 📁 strategy_calibration/ (12 dosya) - Strategy optimization
└── 📁 self_improving_loop/ (25 dosya) - Continuous improvement
```

### 📁 **Infrastructure & DevOps**
```
📁 kubernetes/ (21 dosya) - Azure AKS manifests
📁 azure/ (14 dosya) - Azure services configuration
📁 docker/ (19 Dockerfile + compose files)
📁 monitoring/ (20 dosya) - Prometheus, Grafana, ELK
📁 security/ (25+ dosya) - GDPR, SOC2 compliance
📁 scripts/ (9 automation scripts)
📁 .github/ (6 workflow files) - CI/CD pipelines
📁 .vscode/ (9 dosya) - VS Code workspace setup
```

### 📚 **Documentation**
```
📁 docs/ (25+ markdown files)
├── System architecture documents
├── API references
├── Deployment guides
├── Security policies
└── Troubleshooting guides
```

## 🔧 Konfigürasyon

### Environment Variables
```bash
# Azure services
export AZURE_CLIENT_ID="your-client-id"
export AZURE_CLIENT_SECRET="your-client-secret"
export AZURE_TENANT_ID="your-tenant-id"

# Trading APIs
export BINANCE_API_KEY="your-binance-key"
export BINANCE_SECRET_KEY="your-binance-secret"

# Database connections
export POSTGRES_CONNECTION_STRING="your-connection-string"
export COSMOS_DB_CONNECTION_STRING="your-cosmos-connection"
```

### Azure Key Vault Setup
```bash
# API keys güvenli şekilde saklayın
az keyvault secret set \
  --vault-name crypto-trading-kv \
  --name binance-api-key \
  --value "your-api-key"

az keyvault secret set \
  --vault-name crypto-trading-kv \
  --name glassnode-api-key \
  --value "your-glassnode-key"
```

## 🧪 Test & Validation

### Health Check
```bash
# Tüm servislerin durumunu kontrol edin
./scripts/health-check.sh

# Manual test
kubectl get pods -n trading-system
curl http://localhost:8080/health
```

### Performance Test
```bash
# Load testing
kubectl run load-test --image=loadimpact/k6 --rm -i \
  --restart=Never -- run - <<< "http.get('http://smart-order-router:8080/health')"

# Database performance
python -m code.backtester.performance_test
```

## 🚨 Troubleshooting

### Common Issues

#### **Azure Connection Problems**
```bash
# Login tekrar yapın
az login --use-device-code

# Subscription kontrolü
az account list --output table

# AKS cluster credentials
az aks get-credentials --resource-group crypto-trading-bot-production-rg
```

#### **Docker Build Issues**
```bash
# ACR login
az acr login --name your-registry.azurecr.io

# Manual image build
docker build -t your-registry.azurecr.io/backtester:latest -f docker/Dockerfile.backtester .
docker push your-registry.azurecr.io/backtester:latest
```

#### **Database Connection**
```bash
# Firewall rules kontrolü
az postgres server firewall-rule list --resource-group your-rg --server your-server

# Test connection
psql "host=your-server.postgres.database.azure.com port=5432 dbname=trading user=tradinguser password=yourpassword"
```

### Log Analysis
```bash
# Pod logs
kubectl logs -f deployment/backtester -n trading-system

# System events
kubectl get events -n trading-system --sort-by='.lastTimestamp'

# Azure Monitor logs
az monitor log-analytics query \
  --workspace your-workspace \
  --analytics-query "KubePodInventory | where Namespace == 'trading-system'"
```

## 🎯 Production Checklist

### Pre-Deployment
- [ ] Azure subscription aktif
- [ ] API keys'ler Azure Key Vault'te
- [ ] Resource quotas ayarlanmış
- [ ] Monitoring dashboard'lar hazır

### Deployment
- [ ] Master script çalıştırıldı
- [ ] Tüm pod'lar running status
- [ ] Health checks geçiyor
- [ ] External access working

### Post-Deployment  
- [ ] Grafana dashboards accessible
- [ ] Alert rules configured
- [ ] Backup strategy active
- [ ] SSL certificates installed

## 📞 Destek & Yardım

### Getting Help
1. **GitHub Issues**: Bug reports & feature requests
2. **Documentation**: Comprehensive guides in `docs/`
3. **Logs**: Check system logs for debugging

### Best Practices
- **Always backup** before major changes
- **Monitor** system resources continuously  
- **Update** dependencies regularly
- **Test** strategies in paper trading mode first

---

## 🎉 Hoş Geldiniz!

**Crypto Trading Sisteminiz** artık indirildi ve kullanıma hazır! 

**Next Steps:**
1. Azure hesabınızı oluşturun
2. API keys'inizi alın (Binance, Glassnode)
3. Tek komutla deployment başlatın
4. Trading'e başlayın! 🚀

**🎯 Happy Trading! 📈**