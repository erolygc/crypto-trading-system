#!/bin/bash

# 🚀 Crypto Trading System - Otomatik Setup Script
# Bu script sistemi tek komutla başlatır

echo "🚀 Crypto Trading System - Otomatik Setup Başlıyor..."
echo "================================================"

# Renkli output için
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function for colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Adım 1: Python Environment Kontrolü
print_status "Python environment kontrol ediliyor..."
if command -v python3 &> /dev/null; then
    PYTHON_VERSION=$(python3 --version 2>&1)
    print_success "Python bulundu: $PYTHON_VERSION"
else
    print_error "Python3 bulunamadı! Python 3.9+ gerekli"
    exit 1
fi

# Adım 2: Virtual Environment Oluşturma
print_status "Virtual environment oluşturuluyor..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
    print_success "Virtual environment oluşturuldu"
else
    print_warning "Virtual environment zaten mevcut"
fi

# Adım 3: Virtual Environment Aktifleştirme
print_status "Virtual environment aktifleştiriliyor..."
source venv/bin/activate
print_success "Virtual environment aktif"

# Adım 4: Dependencies Yükleme
print_status "Python dependencies yükleniyor..."
if [ -f "requirements-dev.txt" ]; then
    pip install --upgrade pip
    pip install -r requirements-dev.txt
    print_success "Dependencies yüklendi (dev)"
elif [ -f "requirements.txt" ]; then
    pip install --upgrade pip
    pip install -r requirements.txt
    print_success "Dependencies yüklendi"
else
    print_warning "Requirements dosyası bulunamadı, temel paketler yükleniyor"
    pip install --upgrade pip
    pip install numpy pandas scikit-learn matplotlib seaborn requests fastapi uvicorn pytest jupyter
    print_success "Temel paketler yüklendi"
fi

# Adım 5: Sistem Testleri
print_status "Temel sistem testleri çalıştırılıyor..."

# DVK Algorithm Test
if [ -f "test_dvk_algorithm.py" ]; then
    print_status "DVK Algorithm testi çalıştırılıyor..."
    python test_dvk_algorithm.py
    if [ $? -eq 0 ]; then
        print_success "DVK Algorithm testi başarılı"
    else
        print_warning "DVK Algorithm testi başarısız (kritik değil)"
    fi
fi

# Quick Test
if [ -f "quick_test.py" ]; then
    print_status "Hızlı sistem testi çalıştırılıyor..."
    python quick_test.py
    if [ $? -eq 0 ]; then
        print_success "Hızlı test başarılı"
    else
        print_warning "Hızlı test başarısız (kritik değil)"
    fi
fi

# Adım 6: Code Module Testleri
if [ -d "code" ]; then
    print_status "Trading modülleri test ediliyor..."
    cd code
    
    # DVK Engine Test
    if [ -d "dvk_engine" ]; then
        print_status "DVK Engine test ediliyor..."
        if [ -f "dvk_engine/__init__.py" ]; then
            python -c "import dvk_engine; print('DVK Engine imported successfully')"
            print_success "DVK Engine çalışıyor"
        fi
    fi
    
    # Genetic Engine Test
    if [ -d "genetic_engine" ]; then
        print_status "Genetic Engine test ediliyor..."
        if [ -f "genetic_engine/__init__.py" ]; then
            python -c "import genetic_engine; print('Genetic Engine imported successfully')"
            print_success "Genetic Engine çalışıyor"
        fi
    fi
    
    # Backtester Test
    if [ -d "backtester" ]; then
        print_status "Backtesting Engine test ediliyor..."
        if [ -f "backtester/__init__.py" ]; then
            python -c "import backtester; print('Backtester imported successfully')"
            print_success "Backtester çalışıyor"
        fi
    fi
    
    cd ..
fi

# Adım 7: Docker Durum Kontrolü
print_status "Docker durumu kontrol ediliyor..."
if command -v docker &> /dev/null; then
    print_success "Docker bulundu"
    
    if [ -f "docker-compose.yml" ]; then
        print_status "Docker Compose servisleri kontrol ediliyor..."
        docker-compose ps
        print_success "Docker Compose hazır"
    fi
else
    print_warning "Docker bulunamadı (opsiyonel)"
fi

# Adım 8: Monitoring Durum Kontrolü
if [ -d "monitoring" ]; then
    print_status "Monitoring servisleri kontrol ediliyor..."
    if [ -f "monitoring/docker-compose.yml" ]; then
        print_success "Monitoring dosyaları mevcut"
    fi
fi

# Adım 9: Configuration Kontrolü
print_status "Konfigürasyon dosyaları kontrol ediliyor..."

# Environment dosyalarını kontrol et
if [ -f ".env.example" ]; then
    if [ ! -f ".env" ]; then
        print_warning ".env dosyası bulunamadı, .env.example'dan kopyalanıyor..."
        cp .env.example .env
        print_success ".env dosyası oluşturuldu"
    fi
fi

# Adım 10: Final Summary
echo ""
echo "🎉 Setup Tamamlandı!"
echo "==================="
print_success "✅ Python environment kuruldu"
print_success "✅ Dependencies yüklendi"
print_success "✅ Temel testler çalıştırıldı"
print_success "✅ Trading modülleri kontrol edildi"

echo ""
echo "📋 Sonraki Adımlar:"
echo "==================="
echo "1. VS Code'da Python interpreter seçin: (venv/bin/python)"
echo "2. Debug modunda test çalıştırın (F5)"
echo "3. Trading motorlarını test edin:"
echo "   - python test_dvk_algorithm.py"
echo "   - python test_genetic_final.py"
echo "   - python test_sor_demo.py"
echo ""
echo "4. Docker ile full stack çalıştırın:"
echo "   - docker-compose up -d"
echo ""
echo "5. Monitoring başlatın:"
echo "   - cd monitoring && docker-compose up -d"
echo ""
echo "6. Azure deployment (opsiyonel):"
echo "   - chmod +x azure-deployment-master.sh"
echo "   - ./azure-deployment-master.sh"

echo ""
print_success "🚀 Sistem hazır! İyi çalışmalar!"
echo ""

# Virtual environment'ı aktif tut
echo "💡 İpucu: Virtual environment'ınız aktif halde kaldı"
echo "Terminal'de 'deactivate' yazarak kapatabilirsiniz"