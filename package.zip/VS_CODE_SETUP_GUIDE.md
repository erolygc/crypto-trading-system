# 🔧 Visual Studio Code Kurulum ve Kullanım Rehberi

## 🚀 Hızlı Başlangıç

### 1. GitHub Repository'sinden Klonlama
```bash
# Repository'yi klonlayın
git clone https://github.com/YOUR_USERNAME/crypto-trading-system.git

# Dizine geçin
cd crypto-trading-system

# VS Code'da açın
code .
```

### 2. VS Code Extensions Kurulumu
VS Code'da açıldıktan sonra aşağıdaki extensions'ları yükleyin:

**Zorunlu Extensions:**
- **Python** (Microsoft) - Python dil desteği
- **Pylance** (Microsoft) - IntelliSense ve type checking
- **Python Debugger** (Microsoft) - Debugging desteği
- **GitLens** (GitKraken) - Git entegrasyonu
- **Docker** (Microsoft) - Docker desteği

**Önerilen Extensions:**
- **Python Docstring Generator** - Dokümantasyon oluşturma
- **Auto Rename Tag** - HTML tag'lerini otomatik güncelleme
- **Prettier - Code formatter** - Kod formatlama
- **ESLint** - JavaScript linting
- **YAML** - YAML dosya desteği

### 3. Python Environment Kurulumu

#### Virtual Environment Oluşturma
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# macOS/Linux
python3 -m venv venv
source venv/bin/activate
```

#### Dependencies Yükleme
```bash
# Geliştirme dependencies'lerini yükleyin
uv pip install -r requirements-dev.txt

# Veya tüm sistem dependencies'lerini yükleyin
uv pip install -r requirements.txt
```

### 4. VS Code Workspace Konfigürasyonu

#### Python Interpreter Seçimi
1. `Ctrl+Shift+P` (Command Palette)
2. "Python: Select Interpreter" yazın
3. Virtual environment'daki Python'u seçin: `./venv/bin/python`

#### Workspace Settings
VS Code `.vscode/settings.json` dosyası otomatik yüklenecek ve şu özellikler aktif olacak:
- ✅ Auto-formatting (Black formatter)
- ✅ Linting (Flake8, Pylint)
- ✅ Type checking (MyPy)
- ✅ IntelliSense
- ✅ Debug konfigürasyonları

### 5. Debug Konfigürasyonları

`.vscode/launch.json` dosyasında 15 farklı debug konfigürasyonu mevcut:

**Trading System Debug:**
- `Test DVK Algorithm` - DVK algoritma testleri
- `Test Genetic Engine` - Genetik programlama testleri
- `Test Backtesting Engine` - Backtesting motoru
- `Test Signal Scoring` - Sinyal skorlama testleri
- `Test Portfolio Optimization` - Portföy optimizasyonu

**Development Debug:**
- `Python: Current File` - Mevcut dosyayı debug et
- `Python: Module` - Modül debug
- `Python: Django` - Django debug (eğer kullanılırsa)

**Production Debug:**
- `Production Server` - Production environment debug
- `Kubernetes Pod` - K8s pod debug

**🚀 Debug Başlatma:**
1. Debug sekmesine gidin (Sol sidebar)
2. Konfigürasyon seçin
3. F5 ile başlatın

### 6. Görevler (Tasks)

VS Code tasks (.vscode/tasks.json) ile şu komutları çalıştırabilirsiniz:

- **Build System**: `Ctrl+Shift+P` → "Tasks: Run Build Task"
- **Run Tests**: `Ctrl+Shift+P` → "Tasks: Run Test Task"  
- **Linting**: `Ctrl+Shift+P` → "Tasks: Run Lint Task"
- **Format Code**: `Ctrl+Shift+P` → "Tasks: Run Format Task"
- **Docker Build**: `Ctrl+Shift+P` → "Tasks: Docker Build"

### 7. Git Entegrasyonu

**Source Control:**
- Sol sidebar'da Source Control ikonu (Ctrl+Shift+G)
- GitLens ile enhanced Git özellikleri
- Inline blame, history, comparisons

**Common Git Commands:**
```bash
# Status kontrolü
git status

# Değişiklikleri staged'e ekle
git add .

# Commit yapma
git commit -m "Your message"

# GitHub'a push
git push origin main

# Git history görüntüleme
git log --oneline
```

### 8. Docker Development

**Docker Extensions ile:**
- Container'ları VS Code'da yönetme
- Dockerfile'ları editing
- Docker Compose ile multi-container development

**Useful Commands:**
```bash
# Tüm servisleri başlatma
docker-compose up -d

# Logs görüntüleme
docker-compose logs -f [service_name]

# Container'a bağlanma
docker-compose exec [service_name] bash

# Sistemi durdurma
docker-compose down
```

### 9. Azure Development

**Azure Extensions:**
- Azure Account
- Azure Container Instances
- Azure Kubernetes Service
- Azure Database for PostgreSQL

**Azure CLI Setup:**
```bash
# Azure CLI yükleme
curl -sL https://aka.ms/InstallAzureCLIDeb | sudo bash

# Login
az login

# Azure deployment
./azure-deployment-master.sh
```

### 10. Troubleshooting

**Python Import Errors:**
```bash
# Virtual environment'ı yeniden oluştur
rm -rf venv
python -m venv venv
source venv/bin/activate
uv pip install -r requirements-dev.txt
```

**VS Code Not Recognizing Python:**
1. `Ctrl+Shift+P` → "Python: Select Interpreter"
2. Virtual environment'daki Python'u seçin
3. VS Code'u yeniden başlatın

**Git Permission Errors:**
```bash
# Git credentials ayarlama
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"

# SSH key ayarlama (önerilen)
ssh-keygen -t ed25519 -C "your.email@example.com"
```

### 11. Performance Tips

**Large File Support:**
- `Ctrl+Shift+P` → "Preferences: Open Settings"
- "files.largeFileThreshold" ayarını kontrol edin

**Search Performance:**
- `.gitignore`'da gereksiz dosyaları ignore edin
- Search indexing'i optimize edin

**Memory Usage:**
- Extensions'ları sadece ihtiyaç halinde yükleyin
- Large workspace'ler için workspace folder'ları bölün

### 12. Deployment Pipeline

**Local Development:**
1. Kod yazma → `Ctrl+S` (auto-save)
2. Test etme → F5 (debug) veya `Ctrl+Shift+P` → "Tasks: Run Test"
3. Commit → `Ctrl+Shift+G`
4. Push → `Ctrl+Shift+P` → "Git: Push"

**Production Deployment:**
1. GitHub Actions otomatik test
2. Azure DevOps deployment pipeline
3. Kubernetes cluster'a otomatik deploy

---

## 🎯 Next Steps

1. **Repository Setup:** Yukarıdaki adımları takip edin
2. **Environment:** Virtual environment oluşturun
3. **Test Run:** Bir trading component'i test edin
4. **Azure Deploy:** Production'a deploy edin
5. **Monitor:** Grafana dashboard'ları ile takip edin

**İhtiyaç duyduğunuz herhangi bir noktada yardım isteyebilirsiniz!** 🚀
