# 🚀 Crypto Trading System - Windows PowerShell Kurulum

## Seçenek 1: PowerShell ile Manuel Setup

PowerShell'de şu komutları sırayla çalıştırın:

```powershell
# 1. Python environment oluştur
python -m venv venv

# 2. Virtual environment'ı aktifleştir
.\venv\Scripts\Activate.ps1

# 3. Dependencies yükle
pip install -r requirements-dev.txt

# 4. DVK Algorithm test et
python test_dvk_algorithm.py

# 5. Genetic Engine test et
python test_genetic_final.py

# 6. Hızlı test çalıştır
python quick_test.py
```

## Seçenek 2: Git Bash ile (Eğer Git yüklüyse)

```bash
# Git Bash'te çalıştır
./BASLA.sh
```

## Seçenek 3: Windows Batch Script (.bat)

Aşağıdaki `BASLA.bat` dosyasını kullanabilirsiniz.
