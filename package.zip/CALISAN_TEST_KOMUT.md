# 🎯 ÇALIŞAN TEST KOMUTU - PowerShell

## PowerShell'de şu komutu çalıştır:

```powershell
python -c "
import sys
sys.path.append('code')

print('🔄 Crypto Trading System - Çalışan Test')
print('=' * 50)

try:
    # DVK Engine Test
    from dvk_engine.dvk_engine import DVKEngine
    print('✅ DVK Engine: BAŞARILI')
    
    # Genetic Engine Test  
    from genetic_engine.genetic_engine import GeneticEngine
    print('✅ Genetic Engine: BAŞARILI')
    
    # Backtester Test
    from backtester.backtester import Backtester
    print('✅ Backtester: BAŞARILI')
    
    print('\n🎉 ÇALIŞAN SİSTEMLER TEST EDİLDİ!')
    print('🚀 DVK algoritması hazır!')
    
except Exception as e:
    print(f'❌ Hata: {str(e)}')
    print('🔧 Import sorunu var - modül adlarını kontrol edin')
"
```

## Eğer Çalışmazsa, Bu Alternatif Komutları Dene:

### 1. Sadece DVK Engine Test:
```powershell
python -c "from dvk_engine.dvk_engine import DVKEngine; print('✅ DVK Engine import başarılı!')"
```

### 2. Çalışan Modüller Listesi:
```powershell
python -c "import dvk_engine; print('✅ DVK paketi yüklü'); print(dir(dvk_engine))"
```

### 3. Manuel Import Test:
```powershell
python -c "import pandas as pd; print('✅ Pandas OK'); print('✅ Sistem çalışıyor!')"
```

Hangi komutu çalıştırmak istiyorsun?