"""
Bitwisers 2.0 Event-Driven Backtester Motoru
Kurumsal seviyede tick-by-tick backtesting sistemi
"""

__version__ = "2.0.0"
__author__ = "Bitwisers Team"

from .core.event_system import Event, EventBus, EventType
from .core.tick_engine import TickEngine
from .core.order_book import Portfolio
from .engines.simulation_engine import SimulationEngine
from .engines.backtest_engine import BacktestEngine

__all__ = [
    'Event', 'EventBus', 'EventType',
    'TickEngine', 'Portfolio',
    'SimulationEngine', 'BacktestEngine'
]