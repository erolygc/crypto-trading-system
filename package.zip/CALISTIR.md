# 🚀 Crypto Trading System - Hızlı Başlangıç (Windows)
# Sistem zaten kurulu, şimdi çalıştırma zamanı!

## Adım 1: Virtual Environment Kontrol
```powershell
python --version
pip list
```

## Adım 2: Trading Modüllerini Test Et
```powershell
# DVK Algorithm test
python test_dvk_algorithm.py

# Genetic Engine test
python test_genetic_final.py

# Smart Order Router demo
python test_sor_demo.py

# Hızlı sistem kontrolü
python quick_test.py
```

## Adım 3: Code Modüllerini Import Et
```powershell
cd code
python -c "from dvk_engine import DVKEngine; print('✅ DVK Engine çalışıyor')"
python -c "from genetic_engine import GeneticEngine; print('✅ Genetic Engine çalışıyor')"
python -c "from backtester import Backtester; print('✅ Backtester çalışıyor')"
```

## Adım 4: Trading Sisteminin API'sini Başlat
```powershell
# API server başlat
cd /code
uvicorn api.main:app --host 0.0.0.0 --port 8080 --reload
```

## Adım 5: Web Dashboard (Opsiyonel)
```powershell
# Web arayüzü için
cd monitoring
docker-compose up -d grafana prometheus

# Dashboard'lar:
# - Grafana: http://localhost:3000 (admin/admin)
# - Prometheus: http://localhost:9090
```

## Adım 6: VS Code Debug Test
1. F5 ile debug başlat
2. Breakpoint koyun `test_dvk_algorithm.py`'de
3. Değişkenleri inceleyin

## Adım 7: Azure Deployment (İsteğe Bağlı)
```powershell
./azure-deployment-master.sh
```

## 🎯 Hızlı Test (1 Komut)
```powershell
python -c "
import sys
sys.path.append('code')
print('🔄 Sistem testi başlatılıyor...')
try:
    from dvk_engine import DVKEngine
    print('✅ DVK Engine: OK')
    from genetic_engine import GeneticEngine
    print('✅ Genetic Engine: OK')
    from backtester import Backtester
    print('✅ Backtester: OK')
    print('🎉 Tüm sistemler çalışıyor!')
except Exception as e:
    print(f'❌ Hata: {e}')
"
```
