# Makro Rejim Filtreleme Sistemi

Gelişmiş otomatik hedge modu ve makro rejim filtreleme sistemi.

## 🚀 Özellikler

- **Otomatik Hedge Mode**: Mevcut HEDGE MODE ON'un iyileştirilmesi
- **Market Regime Classification**: Trend, Range, Volatil, Kriz rejimlerinin otomatik tespiti
- **Macro Indicators Integration**: VIX, faiz oranları, likidite ve risk iştahı entegrasyonu
- **Regime-specific Strategy Activation**: Rejime özgü strateji aktivasyonları
- **Risk-on/Risk-off Detection**: Otomatik risk açma/kapama tespiti
- **Volatility Regime Detection**: Volatilite rejim tespiti
- **Liquidity Stress Detection**: Likidite stres tespiti
- **Real-time Regime Monitoring**: 7/24 canlı rejim izleme
- **Regime Persistence Analysis**: Rejim kalıcılığı analizi
- **Strategy Adaptation**: Rejime göre dinamik strateji adaptasyonu

## 📊 Sistem Mimarisi

```
┌─────────────────────────────────────────────────────────┐
│                 Makro Rejim Filtreleme Sistemi          │
├─────────────────────────────────────────────────────────┤
│  Main Controller (main.py)                              │
├─────────────────────────────────────────────────────────┤
│  ┌─────────────────┐  ┌─────────────────┐               │
│  │  Regime Engine  │  │ Real-time Monitor│               │
│  │                 │  │                 │               │
│  │ • Regime Class. │  │ • Data Collection│               │
│  │ • Macro Indic.  │  │ • Alert System  │               │
│  │ • Hedge Manager │  │ • Risk Monitor  │               │
│  │ • Strategy Act. │  │                 │               │
│  └─────────────────┘  └─────────────────┘               │
├─────────────────────────────────────────────────────────┤
│  Core Components                                        │
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐     │
│  │ Volatility   │ │ Liquidity    │ │ Strategy     │     │
│  │ Detector     │ │ Detector     │ │ Activator    │     │
│  └──────────────┘ └──────────────┘ └──────────────┘     │
└─────────────────────────────────────────────────────────┘
```

## 🛠️ Kurulum

### Gereksinimler

- Python 3.8+
- pip
- 4GB RAM
- İnternet bağlantısı

### Kurulum Adımları

1. **Repoyu klonlayın:**
```bash
git clone <repo-url>
cd macro_regime_system
```

2. **Sanal ortam oluşturun:**
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# veya
venv\Scripts\activate  # Windows
```

3. **Gereksinimleri yükleyin:**
```bash
pip install -r requirements.txt
```

4. **Test edin:**
```bash
python examples/demo.py test
```

## 🎯 Hızlı Başlangıç

### Temel Kullanım

```python
import asyncio
from macro_regime_system.main import MacroRegemeSystem

async def main():
    # Sistem oluştur
    system = MacroRegimeSystem("config/config.yaml")
    
    # Callback'ler ekle
    async def on_regime_change(old_regime, new_signal):
        print(f"Rejim değişti: {old_regime.value} -> {new_signal.regime.value}")
    
    system.add_callback('regime_change', on_regime_change)
    
    # Sistemi başlat
    if await system.start():
        print("Sistem çalışıyor...")
        
        # Ana döngü
        while system.is_running:
            status = system.get_system_status()
            print(f"Mevcut rejim: {status['components']['regime_engine']['current_regime']}")
            await asyncio.sleep(60)
    
    await system.stop()

# Çalıştır
asyncio.run(main())
```

### Demo Çalıştırma

```bash
# Tam demo
python examples/demo.py

# Sadece testler
python examples/demo.py test
```

### Bileşen Testi

```python
from macro_regime_system import RegimeClassifier
import pandas as pd
import numpy as np

# Market verisi oluştur
data = pd.DataFrame({
    'timestamp': pd.date_range('2023-01-01', periods=100, freq='1H'),
    'open': np.random.randn(100).cumsum() + 100,
    'high': np.random.randn(100).cumsum() + 105,
    'low': np.random.randn(100).cumsum() + 95,
    'close': np.random.randn(100).cumsum() + 100,
    'volume': np.random.randint(1000, 10000, 100)
})

# Rejim tespiti
classifier = RegimeClassifier()
signal = classifier.classify_regime(data)

print(f"Rejim: {signal.regime.value}")
print(f"Güven: {signal.confidence:.2%}")
```

## 📈 Sistem Bileşenleri

### 1. Regime Classifier
Market rejimlerini tespit eden temel sınıflandırıcı.

```python
from macro_regime_system import RegimeClassifier

classifier = RegimeClassifier()
signal = classifier.classify_regime(market_data)
# signal.regime: TRENDING_UP, TRENDING_DOWN, RANGING, VOLATILE, CRISIS
```

### 2. Regime Engine
Sistem koordinatörü ve ana motor.

```python
from macro_regime_system import RegimeEngine, RegimeConfig

config = RegimeConfig(auto_hedge_enabled=True)
engine = RegimeEngine(config)
await engine.start_monitoring()
```

### 3. Macro Indicators
Makro göstergeler entegrasyonu.

```python
from macro_regime_system import MacroIndicators

macro = MacroIndicators()
data = await macro.get_latest_data()
# data: {vix, sp500, treasury_10y, dxy, gold, oil, ...}
```

### 4. Hedge Manager
Otomatik hedge pozisyon yönetimi.

```python
from macro_regime_system import HedgeManager
from core.regime_engine import HedgeSignal

manager = HedgeManager(sensitivity=0.8)
signal = HedgeSignal("increase", 0.2, 0.8, "Volatility increase")
result = await manager.execute_hedge_signal(signal)
```

### 5. Strategy Activator
Rejime göre strateji aktivasyonu.

```python
from macro_regime_system import StrategyActivator

activator = StrategyActivator()
allocations = await activator.update_allocations(regime_signal)
# allocations: {strategy_name: allocation_percentage}
```

### 6. Real-time Monitor
Canlı sistem izleme ve uyarılar.

```python
from macro_regime_system import RealTimeMonitor

monitor = RealTimeMonitor()
monitor.add_alert_callback(alert_handler)
await monitor.start()
```

## ⚙️ Konfigürasyon

`config/config.yaml` dosyasını düzenleyin:

```yaml
system:
  name: "Makro Rejim Filtreleme Sistemi"
  version: "1.0.0"
  environment: "production"
  update_interval: 60

regime_engine:
  volatility_threshold: 2.0
  trend_threshold: 0.7
  crisis_threshold: 3.0
  hedge_sensitivity: 0.8
  auto_hedge_enabled: true
  strategy_rotation_enabled: true
  risk_limit_percent: 10.0

monitoring:
  update_interval: 30
  alert_thresholds:
    regime_change_confidence: 0.8
    volatility_spike: 2.0
    liquidity_stress: 0.7
    risk_level_high: 0.8
```

## 📊 Risk Yönetimi

### Hedge Stratejileri

- **Static Hedge**: Sabit hedge oranı
- **Dynamic Hedge**: Piyasa koşullarına göre dinamik hedge
- **Volatility Hedge**: Volatilite bazlı hedge
- **Protective Put**: Koruyucu put opsiyonları
- **Collar**: Alt-üst sınır stratejisi
- **Tail Risk Hedge**: Kuyruk riski hedge'i

### Rejim-Strateji Mapping

| Rejim | Ana Stratejiler | Hedge Oranı |
|-------|----------------|-------------|
| **Trending Up** | Momentum Long, Growth Stocks | 20-30% |
| **Trending Down** | Value Hunting, Short Strategy | 60-80% |
| **Ranging** | Mean Reversion, Market Neutral | 30-40% |
| **Volatile** | Volatility Trading, Hedged | 80-100% |
| **Crisis** | Capital Preservation, Safe Havens | 100% |

## 🔔 Monitoring ve Alertler

### Alert Türleri

- **regime_change**: Rejim değişikliği
- **volatility_spike**: Volatilite sıçraması
- **liquidity_stress**: Likidite stresi
- **risk_level**: Risk seviyesi uyarısı
- **volume_spike**: Hacim sıçraması

### Sistem Durumu

```python
# Sistem durumu
status = system.get_system_status()
print(f"Çalışma süresi: {status['system']['uptime_seconds']:.0f} saniye")
print(f"Mevcut rejim: {status['components']['regime_engine']['current_regime']}")

# Rejim özeti
summary = system.get_regime_summary()
print(f"Risk seviyesi: {summary['risk_level']:.2%}")
print(f"Hedge oranı: {summary['hedge_ratio']:.2%}")
```

## 🧪 Test ve Geliştirme

### Test Çalıştırma

```bash
# Tüm testler
pytest code/macro_regime_system/tests/ -v

# Belirli test
pytest code/macro_regime_system/tests/test_system.py::TestRegimeClassifier::test_classify_regime -v

# Coverage raporu
pytest code/macro_regime_system/tests/ --cov=macro_regime_system --cov-report=html
```

### Demo ve Örnekler

```bash
# Interaktif demo
python examples/demo.py

# Sadece testler
python examples/demo.py test

# Belirli bileşen demosu
python -c "
import asyncio
from macro_regime_system.examples.demo import SystemDemo
demo = SystemDemo()
asyncio.run(demo.demo_regime_classifier())
"
```

## 📝 Dokümantasyon

Detaylı dokümantasyon için: [`docs/makro_rejim_filtresi.md`](docs/makro_rejim_filtresi.md)

### API Referansı

- [MacroRegimeSystem](#macroregimesystem)
- [RegimeEngine](#regimeengine)
- [RegimeClassifier](#regimeclassifier)
- [HedgeManager](#hedgemanager)
- [StrategyActivator](#strategyactivator)
- [RealTimeMonitor](#realtimemonitor)

## 🐛 Troubleshooting

### Yaygın Sorunlar

#### Sistem Başlamıyor
```python
# Log dosyalarını kontrol edin
import os
log_files = [f for f in os.listdir('logs') if f.endswith('.log')]
print("Log files:", log_files)

# Konfigürasyonu doğrulayın
from macro_regime_system.utils.helpers import ConfigManager
config = ConfigManager.load_config('config/config.yaml')
```

#### Makro Veriler Alınamıyor
```python
# İnternet bağlantısını test edin
import aiohttp
try:
    async with aiohttp.ClientSession() as session:
        async with session.get('https://finance.yahoo.com') as response:
            print(f"Yahoo Finance: {response.status}")
except Exception as e:
    print(f"Bağlantı hatası: {e}")
```

#### Yüksek Kaynak Kullanımı
```yaml
# config.yaml'de parametreleri azaltın
data_retention_days: 7        # 30'dan 7'ye
max_data_points: 500         # 1000'den 500'e
update_interval: 120         # 60'dan 120'ye
```

### Debug Modu

```yaml
# config.yaml
system:
  debug_mode: true
  log_level: DEBUG
```

## 📊 Performance

### Optimizasyon İpuçları

1. **Memory Management**: Veri saklama limitlerini ayarlayın
2. **Update Interval**: Update sıklığını gereksinime göre ayarlayın
3. **Data Sampling**: Yüksek frekanslı veriler için sampling kullanın
4. **Async Processing**: Paralel işlemler için asyncio kullanın

### Benchmark Sonuçları

- **CPU Kullanımı**: < 10% (normal koşullarda)
- **Memory Kullanımı**: < 500MB
- **Response Time**: < 100ms (rejim tespiti)
- **Alert Latency**: < 5 saniye

## 🤝 Katkıda Bulunma

1. Fork yapın
2. Feature branch oluşturun (`git checkout -b feature/amazing-feature`)
3. Değişikliklerinizi commit edin (`git commit -m 'Add amazing feature'`)
4. Branch'i push edin (`git push origin feature/amazing-feature`)
5. Pull Request oluşturun

### Kod Standartları

- **Black**: Kod formatı
- **Flake8**: Kod kalitesi
- **MyPy**: Tip kontrolü
- **Pytest**: Test coverage > 80%

## 📄 Lisans

Bu proje lisanslıdır. Detaylar için `LICENSE` dosyasına bakınız.

## 📞 Destek

- **Issues**: GitHub Issues
- **Dokümantasyon**: `docs/` dizini
- **Demo**: `examples/demo.py`
- **Test**: `pytest code/macro_regime_system/tests/`

## 🔄 Changelog

### v1.0.0 (2025-10-30)
- ✨ İlk sürüm
- 🎯 Regime classification sistemi
- 🛡️ Otomatik hedge management
- 📊 Real-time monitoring
- 🔄 Strategy activation engine
- 📈 Macro indicators integration
- 🧪 Kapsamlı test suite

---

**Son Güncelleme**: 2025-10-30  
**Versiyon**: 1.0.0