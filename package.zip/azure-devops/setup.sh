#!/bin/bash

# Enterprise Azure DevOps Setup Script
# Bu script Azure DevOps environment'ını kurar ve yapılandırır

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
CONFIG_FILE="azure-devops-setup.conf"
LOG_FILE="azure-devops-setup.log"

# Function to print colored output
print_log() {
    local level=$1
    local message=$2
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    case $level in
        "INFO")  echo -e "${BLUE}[INFO]${NC} $timestamp - $message" ;;
        "WARN")  echo -e "${YELLOW}[WARN]${NC} $timestamp - $message" ;;
        "ERROR") echo -e "${RED}[ERROR]${NC} $timestamp - $message" ;;
        "SUCCESS") echo -e "${GREEN}[SUCCESS]${NC} $timestamp - $message" ;;
    esac
    
    echo "[$timestamp] [$level] $message" >> $LOG_FILE
}

# Function to check prerequisites
check_prerequisites() {
    print_log "INFO" "Checking prerequisites..."
    
    # Check Azure CLI
    if ! command -v az &> /dev/null; then
        print_log "ERROR" "Azure CLI is not installed. Please install it first."
        exit 1
    fi
    
    # Check Azure DevOps CLI
    if ! command -v azdo &> /dev/null; then
        print_log "WARN" "Azure DevOps CLI is not installed. Installing..."
        npm install -g azure-devops-cli
    fi
    
    # Check PowerShell
    if ! command -v pwsh &> /dev/null; then
        print_log "WARN" "PowerShell is not installed. Some scripts may not work."
    fi
    
    # Check Docker
    if ! command -v docker &> /dev/null; then
        print_log "WARN" "Docker is not installed. Container builds will fail."
    fi
    
    print_log "SUCCESS" "Prerequisites check completed"
}

# Function to create configuration
create_config() {
    print_log "INFO" "Creating configuration file..."
    
    cat > $CONFIG_FILE << EOF
# Azure DevOps Enterprise Configuration
# Bu dosya Azure DevOps kurulumu için gerekli bilgileri içerir

# Azure DevOps Organization
AZURE_DEVOPS_ORG="your-organization"
AZURE_DEVOPS_PROJECT="Enterprise DevOps"

# Azure Subscription
AZURE_SUBSCRIPTION_ID="your-subscription-id"
AZURE_TENANT_ID="your-tenant-id"

# Resource Groups
RG_DEV="rg-enterprise-dev"
RG_QA="rg-enterprise-qa"
RG_STAGING="rg-enterprise-staging"
RG_PROD="rg-enterprise-prod"

# Container Registry
ACR_NAME="yourregistry"

# Application Names
APP_NAME_DEV="enterprise-app-dev"
APP_NAME_QA="enterprise-app-qa"
APP_NAME_STAGING="enterprise-app-staging"
APP_NAME_PROD="enterprise-app"

# Database Names
DB_SERVER_DEV="enterprise-db-dev"
DB_SERVER_QA="enterprise-db-qa"
DB_SERVER_PROD="enterprise-db-prod"

# Key Vault Names
KV_DEV="enterprise-kv-dev"
KV_PROD="enterprise-kv-prod"

# Email Configuration
SMTP_SERVER="smtp.company.com"
SMTP_PORT="587"
NOTIFICATION_EMAIL="devops@company.com"

# Notification Channels
TEAMS_WEBHOOK="https://outlook.office.com/webhook/..."
SLACK_WEBHOOK="https://hooks.slack.com/services/..."
EOF
    
    print_log "SUCCESS" "Configuration file created: $CONFIG_FILE"
    print_log "INFO" "Please edit $CONFIG_FILE with your actual values before proceeding"
}

# Function to setup Azure resources
setup_azure_resources() {
    print_log "INFO" "Setting up Azure resources..."
    
    source $CONFIG_FILE
    
    # Login to Azure
    print_log "INFO" "Logging in to Azure..."
    az login
    
    # Set subscription
    az account set --subscription $AZURE_SUBSCRIPTION_ID
    
    # Create Resource Groups
    print_log "INFO" "Creating resource groups..."
    az group create --name $RG_DEV --location westeurope
    az group create --name $RG_QA --location westeurope
    az group create --name $RG_STAGING --location westeurope
    az group create --name $RG_PROD --location westeurope
    
    # Create App Service Plans
    print_log "INFO" "Creating App Service Plans..."
    az appservice plan create --name "asp-enterprise-dev" --resource-group $RG_DEV --sku P1V3
    az appservice plan create --name "asp-enterprise-qa" --resource-group $RG_QA --sku P2V3
    az appservice plan create --name "asp-enterprise-staging" --resource-group $RG_STAGING --sku P3V3
    az appservice plan create --name "asp-enterprise-prod" --resource-group $RG_PROD --sku P3V3
    
    # Create Web Apps
    print_log "INFO" "Creating Web Apps..."
    az webapp create --name $APP_NAME_DEV --resource-group $RG_DEV --plan "asp-enterprise-dev"
    az webapp create --name $APP_NAME_QA --resource-group $RG_QA --plan "asp-enterprise-qa"
    az webapp create --name $APP_NAME_STAGING --resource-group $RG_STAGING --plan "asp-enterprise-staging"
    az webapp create --name $APP_NAME_PROD --resource-group $RG_PROD --plan "asp-enterprise-prod"
    
    # Create SQL Servers
    print_log "INFO" "Creating SQL Servers..."
    az sql server create --name $DB_SERVER_DEV --resource-group $RG_DEV --location westeurope --admin-user devadmin --admin-password 'YourPassword123!'
    az sql server create --name $DB_SERVER_QA --resource-group $RG_QA --location westeurope --admin-user qaadmin --admin-password 'YourPassword123!'
    az sql server create --name $DB_SERVER_PROD --resource-group $RG_PROD --location westeurope --admin-user prodadmin --admin-password 'YourPassword123!'
    
    # Create databases
    print_log "INFO" "Creating SQL Databases..."
    az sql db create --resource-group $RG_DEV --server $DB_SERVER_DEV --name enterprise_db_dev --service-objective S2
    az sql db create --resource-group $RG_QA --server $DB_SERVER_QA --name enterprise_db_qa --service-objective S4
    az sql db create --resource-group $RG_PROD --server $DB_SERVER_PROD --name enterprise_db_prod --service-objective P4
    
    # Create Container Registry
    print_log "INFO" "Creating Container Registry..."
    az acr create --resource-group $RG_PROD --name $ACR_NAME --sku Basic
    
    # Create Key Vaults
    print_log "INFO" "Creating Key Vaults..."
    az keyvault create --name $KV_DEV --resource-group $RG_DEV --location westeurope
    az keyvault create --name $KV_PROD --resource-group $RG_PROD --location westeurope
    
    # Create Storage Accounts
    print_log "INFO" "Creating Storage Accounts..."
    az storage account create --name "enterpriseauddev" --resource-group $RG_DEV --location westeurope --sku Standard_LRS
    az storage account create --name "enterpriseaudqa" --resource-group $RG_QA --location westeurope --sku Standard_LRS
    az storage account create --name "enterpriseaudstaging" --resource-group $RG_STAGING --location westeurope --sku Standard_LRS
    az storage account create --name "enterpriseaudprod" --resource-group $RG_PROD --location westeurope --sku Standard_GRS
    
    print_log "SUCCESS" "Azure resources setup completed"
}

# Function to configure Azure DevOps
configure_azure_devops() {
    print_log "INFO" "Configuring Azure DevOps..."
    
    source $CONFIG_FILE
    
    # Create variable groups (requires manual creation via CLI or UI)
    print_log "INFO" "Variable groups need to be created manually in Azure DevOps portal"
    print_log "INFO" "Please create the following variable groups:"
    print_log "INFO" "  - enterprise-shared-variables"
    print_log "INFO" "  - dev-environment-variables"
    print_log "INFO" "  - qa-environment-variables"
    print_log "INFO" "  - staging-environment-variables"
    print_log "INFO" "  - prod-environment-variables"
    print_log "INFO" "  - security-variables"
    print_log "INFO" "  - monitoring-variables"
    
    # Create environments
    print_log "INFO" "Creating environments..."
    az pipelines environment create --name "Development" --organization https://dev.azure.com/$AZURE_DEVOPS_ORG --project $AZURE_DEVOPS_PROJECT
    az pipelines environment create --name "QA" --organization https://dev.azure.com/$AZURE_DEVOPS_ORG --project $AZURE_DEVOPS_PROJECT
    az pipelines environment create --name "Staging" --organization https://dev.azure.com/$AZURE_DEVOPS_ORG --project $AZURE_DEVOPS_PROJECT
    az pipelines environment create --name "Production" --organization https://dev.azure.com/$AZURE_DEVOPS_ORG --project $AZURE_DEVOPS_PROJECT
    
    # Configure approvals for environments
    print_log "INFO" "Configuring environment approvals..."
    # Production environment requires manual approval
    # This would typically be done through the Azure DevOps UI
    
    print_log "SUCCESS" "Azure DevOps configuration completed"
}

# Function to setup monitoring
setup_monitoring() {
    print_log "INFO" "Setting up monitoring..."
    
    source $CONFIG_FILE
    
    # Create Log Analytics workspace
    print_log "INFO" "Creating Log Analytics workspace..."
    az monitor log-analytics workspace create --workspace-name "enterprise-log-analytics" --resource-group $RG_PROD --location westeurope
    
    # Create Application Insights
    print_log "INFO" "Creating Application Insights..."
    az monitor app-insights component create --app "enterprise-app-insights" --location westeurope --resource-group $RG_PROD --application-type web
    
    # Enable diagnostics on resources
    print_log "INFO" "Enabling diagnostics..."
    # Enable diagnostics for SQL databases
    az monitor diagnostic-settings create --resource /subscriptions/$AZURE_SUBSCRIPTION_ID/resourceGroups/$RG_DEV/providers/Microsoft.Sql/servers/$DB_SERVER_DEV/databases/enterprise_db_dev --name "sql-diagnostics" --workspace /subscriptions/$AZURE_SUBSCRIPTION_ID/resourceGroups/$RG_PROD/providers/Microsoft.OperationalInsights/workspaces/enterprise-log-analytics
    
    print_log "SUCCESS" "Monitoring setup completed"
}

# Function to deploy ARM templates
deploy_arm_templates() {
    print_log "INFO" "Deploying ARM templates..."
    
    source $CONFIG_FILE
    
    # Deploy infrastructure templates
    print_log "INFO" "Deploying infrastructure to Development..."
    az group deployment create --resource-group $RG_DEV --template-file infrastructure/template.json --parameters infrastructure/parameters-dev.json
    
    print_log "INFO" "Deploying infrastructure to QA..."
    az group deployment create --resource-group $RG_QA --template-file infrastructure/template.json --parameters infrastructure/parameters-qa.json
    
    print_log "INFO" "Deploying infrastructure to Staging..."
    az group deployment create --resource-group $RG_STAGING --template-file infrastructure/template.json --parameters infrastructure/parameters-staging.json
    
    print_log "INFO" "Deploying infrastructure to Production..."
    az group deployment create --resource-group $RG_PROD --template-file infrastructure/template.json --parameters infrastructure/parameters-prod.json
    
    print_log "SUCCESS" "ARM template deployment completed"
}

# Function to run tests
run_tests() {
    print_log "INFO" "Running setup validation tests..."
    
    # Test connectivity
    source $CONFIG_FILE
    
    # Test application endpoints
    print_log "INFO" "Testing application endpoints..."
    
    endpoints=(
        "https://$APP_NAME_DEV.azurewebsites.net/health"
        "https://$APP_NAME_QA.azurewebsites.net/health"
        "https://$APP_NAME_STAGING.azurewebsites.net/health"
        "https://$APP_NAME_PROD.azurewebsites.net/health"
    )
    
    for endpoint in "${endpoints[@]}"; do
        if curl -f -s "$endpoint" > /dev/null; then
            print_log "SUCCESS" "Health check passed for $endpoint"
        else
            print_log "WARN" "Health check failed for $endpoint"
        fi
    done
    
    print_log "SUCCESS" "Setup validation tests completed"
}

# Function to cleanup
cleanup() {
    print_log "INFO" "Cleaning up temporary files..."
    rm -f $LOG_FILE
    print_log "SUCCESS" "Cleanup completed"
}

# Function to show help
show_help() {
    echo "Azure DevOps Enterprise Setup Script"
    echo ""
    echo "Usage: $0 [COMMAND]"
    echo ""
    echo "Commands:"
    echo "  check          Check prerequisites"
    echo "  config         Create configuration file"
    echo "  setup          Setup Azure resources"
    echo "  devops         Configure Azure DevOps"
    echo "  monitoring     Setup monitoring"
    echo "  arm            Deploy ARM templates"
    echo "  test           Run validation tests"
    echo "  full           Run full setup"
    echo "  cleanup        Clean up temporary files"
    echo "  help           Show this help"
    echo ""
    echo "Examples:"
    echo "  $0 config      # Create configuration"
    echo "  $0 full        # Run complete setup"
    echo ""
}

# Main function
main() {
    case "${1:-help}" in
        "check")
            check_prerequisites
            ;;
        "config")
            check_prerequisites
            create_config
            ;;
        "setup")
            source $CONFIG_FILE
            setup_azure_resources
            ;;
        "devops")
            source $CONFIG_FILE
            configure_azure_devops
            ;;
        "monitoring")
            source $CONFIG_FILE
            setup_monitoring
            ;;
        "arm")
            source $CONFIG_FILE
            deploy_arm_templates
            ;;
        "test")
            source $CONFIG_FILE
            run_tests
            ;;
        "full")
            print_log "INFO" "Starting full Azure DevOps enterprise setup..."
            check_prerequisites
            create_config
            read -p "Edit configuration file now and press enter to continue..."
            setup_azure_resources
            configure_azure_devops
            setup_monitoring
            deploy_arm_templates
            run_tests
            print_log "SUCCESS" "Full setup completed successfully!"
            ;;
        "cleanup")
            cleanup
            ;;
        "help"|*)
            show_help
            ;;
    esac
}

# Run main function with all arguments
main "$@"