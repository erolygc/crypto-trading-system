# QA Environment Functional Tests
# Bu script QA environment için kapsamlı fonksiyonel testleri çalıştırır

param(
    [Parameter(Mandatory = $true)]
    [string]$AppName,
    
    [Parameter(Mandatory = $true)]
    [string]$Environment,
    
    [Parameter(Mandatory = $false)]
    [int]$Timeout = 1800,
    
    [Parameter(Mandatory = $false)]
    [switch]$Verbose
)

# Script Configuration
$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

# Test Configuration
$TestScenarios = @{
    Authentication = @{
        Tests = @(
            @{ Name = "User Registration"; Endpoint = "/api/auth/register"; Method = "POST" }
            @{ Name = "User Login"; Endpoint = "/api/auth/login"; Method = "POST" }
            @{ Name = "User Logout"; Endpoint = "/api/auth/logout"; Method = "POST" }
            @{ Name = "Token Refresh"; Endpoint = "/api/auth/refresh"; Method = "POST" }
            @{ Name = "Password Reset"; Endpoint = "/api/auth/forgot-password"; Method = "POST" }
        )
        Timeout = 300
        Description = "Authentication flow tests"
    }
    
    UserManagement = @{
        Tests = @(
            @{ Name = "Get User Profile"; Endpoint = "/api/users/profile"; Method = "GET" }
            @{ Name = "Update User Profile"; Endpoint = "/api/users/profile"; Method = "PUT" }
            @{ Name = "Change Password"; Endpoint = "/api/users/change-password"; Method = "POST" }
            @{ Name = "User Preferences"; Endpoint = "/api/users/preferences"; Method = "GET" }
            @{ Name = "Update Preferences"; Endpoint = "/api/users/preferences"; Method = "PUT" }
        )
        Timeout = 300
        Description = "User management functionality"
    }
    
    CRUDOperations = @{
        Tests = @(
            @{ Name = "Create Resource"; Endpoint = "/api/resources"; Method = "POST" }
            @{ Name = "Get Resource"; Endpoint = "/api/resources/{id}"; Method = "GET" }
            @{ Name = "Update Resource"; Endpoint = "/api/resources/{id}"; Method = "PUT" }
            @{ Name = "Delete Resource"; Endpoint = "/api/resources/{id}"; Method = "DELETE" }
            @{ Name = "List Resources"; Endpoint = "/api/resources"; Method = "GET" }
        )
        Timeout = 600
        Description = "CRUD operations testing"
    }
    
    SearchFunctionality = @{
        Tests = @(
            @{ Name = "Simple Search"; Endpoint = "/api/search?q=test"; Method = "GET" }
            @{ Name = "Advanced Search"; Endpoint = "/api/search/advanced"; Method = "POST" }
            @{ Name = "Filter Search"; Endpoint = "/api/search/filter"; Method = "POST" }
            @{ Name = "Search Suggestions"; Endpoint = "/api/search/suggestions"; Method = "GET" }
        )
        Timeout = 300
        Description = "Search and filtering features"
    }
    
    ReportGeneration = @{
        Tests = @(
            @{ Name = "Generate PDF Report"; Endpoint = "/api/reports/pdf"; Method = "POST" }
            @{ Name = "Generate Excel Report"; Endpoint = "/api/reports/excel"; Method = "POST" }
            @{ Name = "Get Report List"; Endpoint = "/api/reports"; Method = "GET" }
            @{ Name = "Download Report"; Endpoint = "/api/reports/{id}/download"; Method = "GET" }
        )
        Timeout = 900
        Description = "Report generation functionality"
    }
    
    DataValidation = @{
        Tests = @(
            @{ Name = "Input Validation"; Endpoint = "/api/validation/test"; Method = "POST" }
            @{ Name = "File Upload"; Endpoint = "/api/upload"; Method = "POST" }
            @{ Name = "Data Sanitization"; Endpoint = "/api/sanitize/test"; Method = "POST" }
            @{ Name = "Business Rule Validation"; Endpoint = "/api/rules/validate"; Method = "POST" }
        )
        Timeout = 300
        Description = "Data validation and sanitization"
    }
    
    ErrorHandling = @{
        Tests = @(
            @{ Name = "404 Error Handling"; Endpoint = "/api/nonexistent"; Method = "GET" }
            @{ Name = "400 Bad Request"; Endpoint = "/api/test/validation"; Method = "POST" }
            @{ Name = "401 Unauthorized"; Endpoint = "/api/protected"; Method = "GET" }
            @{ Name = "403 Forbidden"; Endpoint = "/api/forbidden"; Method = "GET" }
            @{ Name = "500 Server Error"; Endpoint = "/api/test/error"; Method = "GET" }
        )
        Timeout = 300
        Description = "Error handling and HTTP status codes"
    }
    
    PerformanceTests = @{
        Tests = @(
            @{ Name = "Load Test - 10 Users"; Endpoint = "/api/performance/load"; Method = "POST"; LoadTest = @{ Users = 10; Duration = 300 } }
            @{ Name = "Stress Test - 50 Users"; Endpoint = "/api/performance/stress"; Method = "POST"; LoadTest = @{ Users = 50; Duration = 600 } }
            @{ Name = "Spike Test"; Endpoint = "/api/performance/spike"; Method = "POST"; LoadTest = @{ PeakUsers = 100; Duration = 300 } }
        )
        Timeout = 1800
        Description = "Performance and load testing"
    }
}

$TestResults = @()
$StartTime = Get-Date

function Write-TestLog {
    param(
        [string]$Message,
        [string]$Level = "INFO"
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logMessage = "[$timestamp] [$Level] $Message"
    
    switch ($Level) {
        "INFO" { Write-Host $logMessage -ForegroundColor Green }
        "WARN" { Write-Host $logMessage -ForegroundColor Yellow }
        "ERROR" { Write-Host $logMessage -ForegroundColor Red }
        "SUCCESS" { Write-Host $logMessage -ForegroundColor Cyan }
        "TEST" { Write-Host $logMessage -ForegroundColor Magenta }
    }
    
    $script:TestResults += [PSCustomObject]@{
        Timestamp = $timestamp
        Level = $Level
        Message = $Message
    }
}

function Initialize-TestData {
    try {
        Write-TestLog "Initializing test data for QA environment" "INFO"
        
        # Create test user
        $testUser = @{
            username = "test.qa.user@company.com"
            password = "TestQA123!"
            email = "test.qa.user@company.com"
            firstName = "Test"
            lastName = "QAUser"
        }
        
        # Simulate test data creation
        Write-TestLog "Test user created: $($testUser.username)" "SUCCESS"
        
        # Create test resources
        $testResources = @(
            @{ name = "Test Resource 1"; type = "document"; status = "active" }
            @{ name = "Test Resource 2"; type = "image"; status = "active" }
            @{ name = "Test Resource 3"; type = "video"; status = "draft" }
        )
        
        Write-TestLog "Test resources created: $($testResources.Count) items" "SUCCESS"
        
        return @{
            TestUser = $testUser
            TestResources = $testResources
        }
    }
    catch {
        Write-TestLog "Failed to initialize test data: $($_.Exception.Message)" "ERROR"
        throw
    }
}

function Invoke-FunctionalTest {
    param(
        [string]$TestName,
        [string]$Endpoint,
        [string]$Method = "GET",
        [hashtable]$Body = $null,
        [hashtable]$Headers = @{},
        [int]$TimeoutSec = 30,
        [hashtable]$LoadTest = $null
    )
    
    try {
        $testStartTime = Get-Date
        Write-TestLog "Starting test: $TestName" "TEST"
        Write-TestLog "Endpoint: $Method $Endpoint" "TEST"
        
        $baseUrl = "https://$AppName.azurewebsites.net"
        $url = "$baseUrl$Endpoint"
        
        # Default headers
        $defaultHeaders = @{
            "User-Agent" = "Azure-DevOps-QATest/1.0"
            "Accept" = "application/json"
            "Content-Type" = "application/json"
            "X-Environment" = $Environment
            "X-Test-Run" = "true"
        }
        
        # Merge headers
        foreach ($key in $Headers.Keys) {
            $defaultHeaders[$key] = $Headers[$key]
        }
        
        # Request parameters
        $requestParams = @{
            Uri = $url
            Method = $Method
            Headers = $defaultHeaders
            TimeoutSec = $TimeoutSec
        }
        
        # Add body for POST/PUT requests
        if ($Method -in @("POST", "PUT") -and $Body) {
            $requestParams.Body = $Body | ConvertTo-Json -Compress
        }
        
        # Execute test
        $response = Invoke-RestMethod @requestParams
        $testDuration = (Get-Date) - $testStartTime
        
        # Validate response
        $isValid = $false
        if ($response) {
            # Basic validation logic
            if ($response.success -eq $true -or $response.status -eq "success" -or $response.id) {
                $isValid = $true
            }
        }
        
        if ($isValid) {
            Write-TestLog "Test PASSED: $TestName (Duration: $($testDuration.TotalSeconds)s)" "SUCCESS"
            
            return @{
                TestName = $TestName
                Status = "PASSED"
                Duration = [math]::Round($testDuration.TotalSeconds, 2)
                ResponseTime = [math]::Round($testDuration.TotalMilliseconds, 0)
                Timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
                Endpoint = $Endpoint
                Method = $Method
                Response = $response
            }
        } else {
            Write-TestLog "Test FAILED: $TestName - Invalid response" "ERROR"
            
            return @{
                TestName = $TestName
                Status = "FAILED"
                Duration = [math]::Round($testDuration.TotalSeconds, 2)
                Error = "Invalid response"
                Timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
                Endpoint = $Endpoint
                Method = $Method
            }
        }
    }
    catch {
        $testDuration = (Get-Date) - $testStartTime
        Write-TestLog "Test FAILED: $TestName - $($_.Exception.Message)" "ERROR"
        
        return @{
            TestName = $TestName
            Status = "FAILED"
            Duration = [math]::Round($testDuration.TotalSeconds, 2)
            Error = $_.Exception.Message
            Timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
            Endpoint = $Endpoint
            Method = $Method
        }
    }
}

function Start-TestScenario {
    param(
        [string]$ScenarioName,
        [hashtable]$ScenarioConfig
    )
    
    Write-TestLog "`n=================================================================" "INFO"
    Write-TestLog "Starting Test Scenario: $ScenarioName" "INFO"
    Write-TestLog "Description: $($ScenarioConfig.Description)" "INFO"
    Write-TestLog "=================================================================" "INFO"
    
    $scenarioResults = @()
    $scenarioStartTime = Get-Date
    
    foreach ($test in $ScenarioConfig.Tests) {
        $testResult = Invoke-FunctionalTest @test
        $scenarioResults += $testResult
        
        # Pause between tests
        Start-Sleep -Seconds 1
    }
    
    $scenarioDuration = (Get-Date) - $scenarioStartTime
    $passedTests = ($scenarioResults | Where-Object { $_.Status -eq "PASSED" }).Count
    $totalTests = $scenarioResults.Count
    $successRate = if ($totalTests -gt 0) { [math]::Round(($passedTests / $totalTests) * 100, 2) } else { 0 }
    
    Write-TestLog "Scenario '$ScenarioName' completed in $($scenarioDuration.TotalSeconds)s" "INFO"
    Write-TestLog "Results: $passedTests/$totalTests tests passed ($successRate%)" "INFO"
    
    return @{
        ScenarioName = $ScenarioName
        Status = if ($passedTests -eq $totalTests) { "PASSED" } else { "FAILED" }
        Duration = $scenarioDuration.TotalSeconds
        TotalTests = $totalTests
        PassedTests = $passedTests
        SuccessRate = "$successRate%"
        TestResults = $scenarioResults
    }
}

function Generate-QATestReport {
    param(
        [array]$ScenarioResults,
        [datetime]$StartTime,
        [string]$Environment,
        [string]$AppName
    )
    
    $endTime = Get-Date
    $totalDuration = ($endTime - $StartTime).TotalSeconds
    
    $allPassedTests = ($ScenarioResults.TestResults | Where-Object { $_.Status -eq "PASSED" }).Count
    $allFailedTests = ($ScenarioResults.TestResults | Where-Object { $_.Status -eq "FAILED" }).Count
    $totalTests = ($ScenarioResults.TestResults | Measure-Object).Count
    
    $overallSuccessRate = if ($totalTests -gt 0) { [math]::Round(($allPassedTests / $totalTests) * 100, 2) } else { 0 }
    
    $report = @{
        TestSuite = "QA Functional Tests"
        Environment = $Environment
        Application = $AppName
        StartTime = $StartTime.ToString("yyyy-MM-dd HH:mm:ss")
        EndTime = $endTime.ToString("yyyy-MM-dd HH:mm:ss")
        TotalDuration = [math]::Round($totalDuration, 2)
        Summary = @{
            TotalTests = $totalTests
            Passed = $allPassedTests
            Failed = $allFailedTests
            SuccessRate = "$overallSuccessRate%"
            ScenariosExecuted = $ScenarioResults.Count
        }
        Scenarios = $ScenarioResults
        OverallStatus = if ($allFailedTests -eq 0) { "PASSED" } else { "FAILED" }
    }
    
    return $report
}

# Main Execution
try {
    Write-TestLog "Starting QA functional test suite for $Environment environment" "INFO"
    Write-TestLog "Application: $AppName" "INFO"
    Write-TestLog "Timeout: $Timeout seconds" "INFO"
    
    # Initialize test data
    $testData = Initialize-TestData
    
    # Store results for all scenarios
    $allScenarioResults = @()
    
    # Run all test scenarios
    foreach ($scenarioName in $TestScenarios.Keys) {
        $scenarioConfig = $TestScenarios[$scenarioName]
        
        # Check if we have enough time remaining
        $elapsedTime = (Get-Date) - $StartTime
        if ($elapsedTime.TotalSeconds -gt ($Timeout - 300)) {  # 5 minutes buffer
            Write-TestLog "Timeout approaching, skipping remaining scenarios" "WARN"
            break
        }
        
        $scenarioResult = Start-TestScenario -ScenarioName $scenarioName -ScenarioConfig $scenarioConfig
        $allScenarioResults += $scenarioResult
        
        # Brief pause between scenarios
        Start-Sleep -Seconds 5
    }
    
    # Generate comprehensive test report
    $report = Generate-QATestReport -ScenarioResults $allScenarioResults -StartTime $StartTime -Environment $Environment -AppName $AppName
    
    # Output detailed report
    Write-Host "`n" -NoNewline
    Write-Host "=================================================================" -ForegroundColor Cyan
    Write-Host "QA FUNCTIONAL TEST REPORT" -ForegroundColor Cyan
    Write-Host "=================================================================" -ForegroundColor Cyan
    Write-Host "Environment: $($report.Environment)" -ForegroundColor White
    Write-Host "Application: $($report.Application)" -ForegroundColor White
    Write-Host "Test Suite: $($report.TestSuite)" -ForegroundColor White
    Write-Host "Start Time: $($report.StartTime)" -ForegroundColor White
    Write-Host "End Time: $($report.EndTime)" -ForegroundColor White
    Write-Host "Total Duration: $($report.TotalDuration) seconds" -ForegroundColor White
    Write-Host "`n" -NoNewline
    Write-Host "SUMMARY:" -ForegroundColor Yellow
    Write-Host "Total Tests: $($report.Summary.TotalTests)" -ForegroundColor White
    Write-Host "Passed: $($report.Summary.Passed)" -ForegroundColor Green
    Write-Host "Failed: $($report.Summary.Failed)" -ForegroundColor Red
    Write-Host "Success Rate: $($report.Summary.SuccessRate)" -ForegroundColor Cyan
    Write-Host "Scenarios Executed: $($report.Summary.ScenariosExecuted)" -ForegroundColor White
    Write-Host "Overall Status: $($report.OverallStatus)" -ForegroundColor $(if ($report.OverallStatus -eq "PASSED") { "Green" } else { "Red" })
    Write-Host "`n" -NoNewline
    Write-Host "SCENARIO BREAKDOWN:" -ForegroundColor Yellow
    
    foreach ($scenario in $report.Scenarios) {
        $scenarioColor = if ($scenario.Status -eq "PASSED") { "Green" } else { "Red" }
        Write-Host "  $($scenario.ScenarioName): $($scenario.Status) ($($scenario.PassedTests)/$($scenario.TotalTests) - $($scenario.SuccessRate))" -ForegroundColor $scenarioColor
    }
    
    Write-Host "=================================================================" -ForegroundColor Cyan
    
    # Save detailed results to file
    $reportFile = "qa-functional-test-results-$Environment-$(Get-Date -Format 'yyyyMMdd-HHmmss').json"
    $report | ConvertTo-Json -Depth 10 | Out-File -FilePath $reportFile -Encoding UTF8
    Write-TestLog "Detailed test report saved to: $reportFile" "INFO"
    
    # Save CSV summary for easy analysis
    $csvFile = "qa-functional-test-summary-$Environment-$(Get-Date -Format 'yyyyMMdd-HHmmss').csv"
    $csvData = $report.Scenarios.TestResults | Select-Object TestName, Status, Duration, Endpoint, Method, Timestamp | Export-Csv -Path $csvFile -NoTypeInformation
    Write-TestLog "CSV summary saved to: $csvFile" "INFO"
    
    # Overall test result
    if ($report.OverallStatus -eq "PASSED") {
        Write-TestLog "All QA functional tests PASSED successfully!" "SUCCESS"
        exit 0
    } else {
        Write-TestLog "QA functional tests FAILED - Please review the detailed results above" "ERROR"
        Write-TestLog "Failed tests: $($report.Summary.Failed)" "ERROR"
        exit 1
    }
}
catch {
    Write-TestLog "Fatal error during QA functional test execution: $($_.Exception.Message)" "ERROR"
    Write-TestLog "Stack trace: $($_.ScriptStackTrace)" "ERROR"
    exit 2
}