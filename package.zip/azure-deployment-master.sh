#!/bin/bash

################################################################################
# Kripto Trading Sistemi - Azure Deployment Master Script
# Bu script tüm sistemi Azure'da tek komutla kurar
# Usage: ./azure-deployment-master.sh [environment] [region]
################################################################################

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Configuration
ENVIRONMENT=${1:-"production"}
REGION=${2:-"eastus"}
PROJECT_NAME="kripto-trading-bot"
DOMAIN="trading.example.com"

echo -e "${BLUE}🚀 Crypto Trading System - Azure Deployment${NC}"
echo -e "${BLUE}================================================${NC}"
echo -e "Environment: ${GREEN}$ENVIRONMENT${NC}"
echo -e "Region: ${GREEN}$REGION${NC}"
echo -e "Project: ${GREEN}$PROJECT_NAME${NC}"
echo ""

# Function to print status
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check prerequisites
check_prerequisites() {
    print_status "Prerequisites kontrolü yapılıyor..."
    
    # Check Azure CLI
    if ! command -v az &> /dev/null; then
        print_error "Azure CLI bulunamadı. Lütfen Azure CLI'yi kurun: https://docs.microsoft.com/en-us/cli/azure/install-azure-cli"
        exit 1
    fi
    
    # Check kubectl
    if ! command -v kubectl &> /dev/null; then
        print_error "kubectl bulunamadı. Lütfen kubectl'i kurun: https://kubernetes.io/docs/tasks/tools/"
        exit 1
    fi
    
    # Check docker
    if ! command -v docker &> /dev/null; then
        print_error "Docker bulunamadı. Lütfen Docker'ı kurun: https://docs.docker.com/get-docker/"
        exit 1
    fi
    
    # Check if logged in to Azure
    if ! az account show &> /dev/null; then
        print_error "Azure'a giriş yapılmamış. Lütfen 'az login' komutu ile giriş yapın."
        exit 1
    fi
    
    print_success "Prerequisites başarılı!"
}

# Azure login and subscription setup
setup_azure() {
    print_status "Azure subscription ayarlanıyor..."
    
    # Set default subscription
    SUBSCRIPTION_ID=$(az account show --query id -o tsv)
    print_status "Subscription ID: $SUBSCRIPTION_ID"
    
    # Register required providers
    print_status "Required providers kaydediliyor..."
    az provider register --namespace Microsoft.ContainerService --wait
    az provider register --namespace Microsoft.KeyVault --wait
    az provider register --namespace Microsoft.Insights --wait
    az provider register --namespace Microsoft.DocumentDB --wait
    az provider register --namespace Microsoft.DBforPostgreSQL --wait
    az provider register --namespace Microsoft.Cache --wait
    
    print_success "Azure setup tamamlandı!"
}

# Create Resource Group
create_resource_group() {
    print_status "Resource Group oluşturuluyor..."
    
    RESOURCE_GROUP_NAME="${PROJECT_NAME}-${ENVIRONMENT}-rg"
    
    az group create \
        --name "$RESOURCE_GROUP_NAME" \
        --location "$REGION" \
        --tags "project=$PROJECT_NAME" "environment=$ENVIRONMENT" \
        || print_warning "Resource Group zaten mevcut olabilir"
    
    print_success "Resource Group: $RESOURCE_GROUP_NAME"
}

# Create Azure Services
create_azure_services() {
    print_status "Azure Services oluşturuluyor..."
    
    # Container Registry
    print_status "Azure Container Registry oluşturuluyor..."
    ACR_NAME="${PROJECT_NAME}${ENVIRONMENT}acr"
    az acr create \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --name "$ACR_NAME" \
        --sku Standard \
        --admin-enabled true \
        || print_warning "ACR zaten mevcut olabilir"
    
    # Database for PostgreSQL
    print_status "Azure Database for PostgreSQL oluşturuluyor..."
    PG_SERVER="${PROJECT_NAME}-${ENVIRONMENT}-pg"
    PG_USERNAME="tradinguser"
    PG_PASSWORD=$(openssl rand -base64 32)
    
    az postgres server create \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --name "$PG_SERVER" \
        --location "$REGION" \
        --admin-user "$PG_USERNAME" \
        --admin-password "$PG_PASSWORD" \
        --sku-name GP_Gen5_2 \
        --storage-size 51200 \
        || print_warning "PostgreSQL server zaten mevcut olabilir"
    
    # Cosmos DB
    print_status "Azure Cosmos DB oluşturuluyor..."
    COSMOS_NAME="${PROJECT_NAME}-${ENVIRONMENT}-cosmos"
    
    az cosmosdb create \
        --name "$COSMOS_NAME" \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --locations regionName="$REGION" failoverPriority=0 \
        --capabilities EnableServerless \
        || print_warning "Cosmos DB zaten mevcut olabilir"
    
    # Redis Cache
    print_status "Azure Redis Cache oluşturuluyor..."
    REDIS_NAME="${PROJECT_NAME}-${ENVIRONMENT}-redis"
    
    az redis create \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --name "$REDIS_NAME" \
        --location "$REGION" \
        --sku Basic \
        --vm-size c0 \
        || print_warning "Redis Cache zaten mevcut olabilir"
    
    # Key Vault
    print_status "Azure Key Vault oluşturuluyor..."
    KV_NAME="${PROJECT_NAME}-${ENVIRONMENT}-kv"
    
    az keyvault create \
        --name "$KV_NAME" \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --location "$REGION" \
        --enabled-for-deployment \
        --enabled-for-template-deployment \
        --enabled-for-disk-encryption \
        || print_warning "Key Vault zaten mevcut olabilir"
    
    # Event Hubs
    print_status "Azure Event Hubs oluşturuluyor..."
    EH_NAMESPACE="${PROJECT_NAME}-${ENVIRONMENT}-eh"
    EH_NAME="trading-events"
    
    az eventhubs namespace create \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --name "$EH_NAMESPACE" \
        --location "$REGION" \
        --sku Standard \
        --capacity 1 \
        || print_warning "Event Hubs namespace zaten mevcut olabilir"
    
    az eventhubs eventhub create \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --namespace-name "$EH_NAMESPACE" \
        --name "$EH_NAME" \
        --message-retention 1 \
        --partition-count 2 \
        || print_warning "Event Hub zaten mevcut olabilir"
    
    print_success "Azure Services oluşturuldu!"
}

# Setup AKS Cluster
setup_aks() {
    print_status "Azure Kubernetes Service kurulumu yapılıyor..."
    
    AKS_NAME="${PROJECT_NAME}-${ENVIRONMENT}-aks"
    
    # Create AKS cluster
    az aks create \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --name "$AKS_NAME" \
        --location "$REGION" \
        --node-count 3 \
        --node-vm-size Standard_D4s_v3 \
        --enable-addons monitoring \
        --generate-ssh-keys \
        --enable-cluster-autoscaler \
        --min-count 2 \
        --max-count 10 \
        --network-plugin azure \
        --network-policy azure \
        --enable-managed-identity \
        || print_warning "AKS cluster zaten mevcut olabilir"
    
    # Get credentials
    az aks get-credentials \
        --resource-group "$RESOURCE_GROUP_NAME" \
        --name "$AKS_NAME" \
        --overwrite-existing
    
    print_success "AKS cluster kuruldu!"
}

# Build and push Docker images
build_and_push_images() {
    print_status "Docker imajları oluşturulup ACR'ye push ediliyor..."
    
    # Login to ACR
    az acr login --name "$ACR_NAME"
    
    # Build all images
    IMAGES=(
        "backtester:latest"
        "correlation_engine:latest"
        "genetic_engine:latest"
        "dvk_engine:latest"
        "smart_order_router:latest"
        "iceberg_detection:latest"
        "risk_management:latest"
        "portfolio_optimization:latest"
        "meta_learning_engine:latest"
        "performance_monitoring:latest"
    )
    
    for image in "${IMAGES[@]}"; do
        print_status "Building $image..."
        docker build -f "docker/Dockerfile.${image%%:*}" -t "$ACR_NAME.azurecr.io/$image" .
        docker push "$ACR_NAME.azurecr.io/$image"
    done
    
    print_success "Docker imajları ACR'ye push edildi!"
}

# Deploy to Kubernetes
deploy_to_kubernetes() {
    print_status "Kubernetes'e deployment yapılıyor..."
    
    # Create namespace
    kubectl create namespace trading-system || print_warning "Namespace zaten mevcut"
    
    # Apply all Kubernetes manifests
    kubectl apply -f kubernetes/namespaces/
    kubectl apply -f kubernetes/config/
    kubectl apply -f kubernetes/storage/
    kubectl apply -f kubernetes/apps/
    kubectl apply -f kubernetes/network/
    kubectl apply -f kubernetes/policies/
    
    # Wait for deployments
    print_status "Deployment'ların tamamlanması bekleniyor..."
    kubectl rollout status deployment/backtester -n trading-system --timeout=300s
    kubectl rollout status deployment/smart-order-router -n trading-system --timeout=300s
    kubectl rollout status deployment/performance-monitor -n trading-system --timeout=300s
    
    print_success "Kubernetes deployment tamamlandı!"
}

# Setup monitoring
setup_monitoring() {
    print_status "Monitoring stack kurulumu yapılıyor..."
    
    # Deploy Prometheus and Grafana
    kubectl apply -f monitoring/prometheus/
    kubectl apply -f monitoring/grafana/
    
    print_success "Monitoring stack kuruldu!"
}

# Final verification
verify_deployment() {
    print_status "Deployment doğrulanıyor..."
    
    # Check pods
    kubectl get pods -n trading-system
    
    # Check services
    kubectl get services -n trading-system
    
    # Get load balancer IP
    EXTERNAL_IP=$(kubectl get service smart-order-router -n trading-system -o jsonpath='{.status.loadBalancer.ingress[0].ip}' || echo "N/A")
    
    print_success "Deployment doğrulandı!"
    echo -e "${GREEN}🎉 Crypto Trading System başarıyla kuruldu!${NC}"
    echo -e "${BLUE}📊 Smart Order Router: ${GREEN}http://$EXTERNAL_IP:8080${NC}"
    echo -e "${BLUE}📈 Performance Monitor: ${GREEN}http://$EXTERNAL_IP:3000${NC}"
    echo -e "${BLUE}🔍 Grafana Dashboard: ${GREEN}http://$EXTERNAL_IP:3030${NC}"
    echo ""
    print_warning "Önemli bilgiler:"
    echo "- PostgreSQL Server: $PG_SERVER"
    echo "- PostgreSQL Password: $PG_PASSWORD"
    echo "- Cosmos DB: $COSMOS_NAME"
    echo "- Redis Cache: $REDIS_NAME"
    echo "- Key Vault: $KV_NAME"
    echo "- ACR: $ACR_NAME.azurecr.io"
    echo "- AKS: $AKS_NAME"
    echo ""
    print_warning "Lütfen bu bilgileri güvenli bir yerde saklayın!"
}

# Main execution
main() {
    echo -e "${BLUE}Crypto Trading System Azure Deployment başlatılıyor...${NC}"
    echo ""
    
    check_prerequisites
    setup_azure
    create_resource_group
    create_azure_services
    setup_aks
    build_and_push_images
    deploy_to_kubernetes
    setup_monitoring
    verify_deployment
    
    echo -e "${GREEN}✅ Deployment başarıyla tamamlandı!${NC}"
    echo -e "${BLUE}💡 Next Steps:${NC}"
    echo "1. Config dosyalarını güncelleyin (API keys, database URLs)"
    echo "2. SSL sertifikalarını kurun"
    echo "3. Monitoring dashboard'larını kontrol edin"
    echo "4. Backup stratejilerini aktifleştirin"
    echo ""
    echo -e "${YELLOW}📚 Daha fazla bilgi için README.md dosyasına bakın${NC}"
}

# Error handling
trap 'print_error "Deployment başarısız oldu!"; exit 1' ERR

# Execute main function
main "$@"