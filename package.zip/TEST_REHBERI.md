# 🔍 Mevcut Test Dosyaları Kontrol Rehberi

## PowerShell'de Çalıştırılabilir Testler:

### 1. DVK Algorithm Testi (ÇALIŞIYOR ✅):
```powershell
python test_dvk_algorithm.py
```

### 2. Tüm Sistem Testleri (ÇALIŞIYOR ✅):
```powershell
python test_sistem_final.py
```

### 3. Genetic Algorithm Test:
```powershell
python test_genetic_final.py
```

### 4. Smart Order Router Demo:
```powershell
python test_sor_demo.py
```

## ⚠️ Düzeltme Gerekli:
`test_genetic_final.py` "No module named 'core'" hatası veriyor. Bu import sorunu.

## 💡 Çözüm Önerileri:

### Seçenek 1: Core Modülünü Bul
```powershell
# Core modülünü arayalım:
Get-ChildItem -Recurse -Name "core*" | Where-Object { $_ -match "\.py$" }
```

### Seçenek 2: Import Path'i Düzelt
```powershell
# Python path'ine code klasörünü ekle:
$env:PYTHONPATH = "$pwd\code;$env:PYTHONPATH"
python test_genetic_final.py
```

### Seçenek 3: Direct Import Test
```powershell
# Çalışan dosyaları listele:
dir *.py
```

## 🎯 Önerilen Test Sırası:
1. `python test_dvk_algorithm.py` (ÇALIŞIYOR)
2. `python test_sistem_final.py` (ÇALIŞIYOR)
3. `python test_sor_demo.py` (DENE)
4. `python test_genetic_final.py` (CORE SORUNU VAR)

Hangi test dosyasını çalıştırmak istiyorsun?