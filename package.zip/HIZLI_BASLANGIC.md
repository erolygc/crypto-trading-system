# 🚀 Crypto Trading System - Hızlı Başlangıç Rehberi

## 1. Python Environment Kurulumu

### Terminal'de komutları sırayla çalıştırın:

```bash
# Python 3.9+ kontrol
python3 --version

# Virtual environment oluştur
python3 -m venv venv

# Virtual environment'ı aktifleştir
source venv/bin/activate  # Linux/macOS
# veya venv\Scripts\activate  # Windows

# Dependencies yükle
pip install -r requirements-dev.txt

# Alternatif: Tüm requirements'ları yükle
pip install -r requirements.txt
```

## 2. Sistem Test Etme

### DVK Algorithm Test
```bash
# DVK algoritmasını test et
python test_dvk_algorithm.py
```

### Genetic Engine Test
```bash
# Genetik motorunu test et
python test_genetic_final.py
```

### Smart Order Router Test
```bash
# Smart order routing'i test et
python test_sor_demo.py
```

### Hızlı Test
```bash
# Tüm sistemin temel fonksiyonlarını test et
python quick_test.py
```

## 3. Trading Motorlarını Test Etme

### Code klasörüne gidin:
```bash
cd code
```

### Backtesting Engine
```bash
python -m backtester.test_backtester
```

### Signal Scoring
```bash
python -m signal_scoring.test_scoring
```

### Portfolio Optimization
```bash
python -m portfolio_optimization.test_portfolio
```

## 4. Docker ile Çalıştırma

### Sistem Docker'da çalıştır:
```bash
# Tüm servisleri başlat
docker-compose up -d

# Logs görüntüle
docker-compose logs -f

# Belirli servisi görüntüle
docker-compose logs -f trading_engine
```

## 5. Monitoring Başlatma

### Grafana ve Prometheus
```bash
cd monitoring
docker-compose up -d

# Monitoring arayüzleri:
# - Prometheus: http://localhost:9090
# - Grafana: http://localhost:3000 (admin/admin)
```

## 6. Azure Deployment (Opsiyonel)

### Azure Deployment Script
```bash
# Azure deployment script'ini çalıştır
chmod +x azure-deployment-master.sh
./azure-deployment-master.sh
```

## 7. VS Code Debugging

### Python Interpreter Seçimi
1. `Ctrl+Shift+P` → "Python: Select Interpreter"
2. `venv/bin/python` seçin

### Debug Konfigürasyonları:
- F5 ile debug başlatma
- Test'leri debug modunda çalıştırma
- Breakpoint koyma

## 8. Sistem Bileşenleri

### Ana Trading Motorları:
- ✅ **DVK Engine**: Dinamik varlık karakterizasyonu
- ✅ **Genetic Engine**: Genetik programlama optimizasyonu
- ✅ **Backtesting Engine**: Event-driven backtesting
- ✅ **Portfolio Optimization**: Markowitz, Black-Litterman
- ✅ **Risk Management**: VaR/CVaR, stress testing
- ✅ **Smart Order Router**: Multi-exchange optimization

### Infrastructure:
- ✅ **Docker**: Containerization
- ✅ **Kubernetes**: Orchestration
- ✅ **Azure Services**: PostgreSQL, Cosmos DB
- ✅ **Monitoring**: Prometheus, Grafana, ELK Stack
- ✅ **CI/CD**: GitHub Actions, Azure DevOps

## 9. Hızlı Çalıştırma Scriptleri

### Tek Komutla Tüm Sistem:
```bash
# Sistemi tam olarak başlat
chmod +x setup_workspace.sh
./setup_workspace.sh
```

### Test Suite Çalıştırma:
```bash
# Tüm testleri çalıştır
python -m pytest tests/ -v --tb=short
```

## 10. Başlatma Sonrası Kontrol

### Sistem Durumu:
```bash
# Sistem servislerinin durumunu kontrol
curl http://localhost:8080/health

# Monitoring dashboard'ları kontrol et
echo "Grafana: http://localhost:3000"
echo "Prometheus: http://localhost:9090"
```

## 🎯 Önerilen Başlatma Sırası:

1. **Environment Setup**: Virtual environment oluştur
2. **Dependencies**: requirements yükle
3. **Basic Tests**: DVK ve genetic engine test et
4. **Docker**: Full stack'i Docker'da çalıştır
5. **Monitoring**: Grafana dashboard'larını aç
6. **Trading Tests**: Trading motorlarını test et

**İyi çalışmalar! 🚀**